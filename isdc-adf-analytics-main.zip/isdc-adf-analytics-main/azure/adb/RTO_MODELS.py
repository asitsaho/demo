# Databricks notebook source
# MAGIC %md
# MAGIC **Install R packages**

# COMMAND ----------

# MAGIC %r
# MAGIC install.packages("ggplot2",repos="http://cran.rstudio.com")
# MAGIC install.packages("crayon",repos="http://cran.rstudio.com")
# MAGIC install.packages("openxlsx",repos="http://cran.rstudio.com")
# MAGIC install.packages("withr",repos="http://cran.rstudio.com")
# MAGIC install.packages("tidyr",repos="http://cran.rstudio.com")
# MAGIC install.packages("dplyr",repos="http://cran.rstudio.com")
# MAGIC install.packages("lubridate",repos="http://cran.rstudio.com")
# MAGIC install.packages("readxl",repos="http://cran.rstudio.com")
# MAGIC install.packages("MASS",repos="http://cran.rstudio.com")
# MAGIC install.packages("caret",repos="http://cran.rstudio.com")
# MAGIC install.packages("e1071",repos="http://cran.rstudio.com")
# MAGIC install.packages("ClustOfVar",repos="http://cran.rstudio.com")
# MAGIC install.packages("randomForest",repos="http://cran.rstudio.com")
# MAGIC install.packages("nnet",repos="http://cran.rstudio.com")
# MAGIC install.packages("h2o",type="source", repos="https://h2o-release.s3.amazonaws.com/h2o/rel-zermelo/1/R")
# MAGIC install.packages("xml2",repos="http://cran.rstudio.com")
# MAGIC install.packages("devtools",repos="http://cran.rstudio.com")
# MAGIC install.packages("caTools",repos="http://cran.rstudio.com")
# MAGIC install.packages("cli",repos="http://cran.rstudio.com")
# MAGIC # install.packages("/mapr/datalake/optum/optuminsight/p_dlz/ism/prd/p_scripts/deep_processes/rto_models/rcode/packages/caTools_1.17.tar.gz", repos = NULL, type="source",lib="/dbfs/mnt/saisdcnonprod/isdc/dev/R_Models/packages_4")
# MAGIC
# MAGIC install.packages("RCurl",repos="http://cran.rstudio.com")
# MAGIC
# MAGIC install.packages("DBI",repos="http://cran.rstudio.com")
# MAGIC install.packages("rJava",repos="http://cran.rstudio.com")
# MAGIC install.packages("RJDBC",repos="http://cran.rstudio.com")
