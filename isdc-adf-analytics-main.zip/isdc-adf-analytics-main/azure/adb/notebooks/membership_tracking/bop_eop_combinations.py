# Databricks notebook source
from dateutil import rrule
from datetime import datetime
from pyspark.sql.functions import split,explode,replace,trim,col,date_format
# from snowflake import snowflake
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization
import re 
import math
import os

env=os.getenv('env_var')
account_name="saisdcnonprod" if env=="dev" or env=="tst" else "saisdcprod"

def get_private_key():
    private_key_content = dbutils.secrets.get(scope=f"databricks_sc_{env}", key=f"isdc-sf-{env}-p8")
    # get the encryption password from the secret scope
    encryption_password = dbutils.secrets.get(scope=f"databricks_sc_{env}", key=f"isdc-sf-{env}-p8-pwd")
    #load the private key
    p_key = serialization.load_pem_private_key(private_key_content.encode(), password=encryption_password.encode(), backend=default_backend())
    pkb = p_key.private_bytes(encoding=serialization.Encoding.PEM, format=serialization.PrivateFormat.PKCS8, encryption_algorithm=serialization.NoEncryption())
    pkb = pkb.decode("UTF-8")
    pkb = re.sub("-*(BEGIN|END) PRIVATE KEY-*\n", "", pkb).replace("\n", "")
    return pkb

#gets input params of type str
def get_job_params(arg,default="",return_type=str):
    try:
        return return_type(dbutils.widgets.get(arg))
    except Exception:
        return return_type(default)


#create snowflake connection dict
def get_read_params():
    read_dict={}
    read_dict['snowflake_url']=get_job_params('snowflake_url')
    read_dict['snowflake_database']=get_job_params('snowflake_database')
    read_dict['snowflake_schema']=get_job_params('snowflake_schema')
    read_dict['snowflake_warehouse']=get_job_params('snowflake_warehouse')
    read_dict['snowflake_role']=get_job_params('snowflake_role')
    read_dict['snowflake_userid']=get_job_params('snowflake_userid')
    return read_dict

#create snowflake connection 
def get_snowflake_options():
    pk = get_private_key()
    read_params=get_read_params()
    options={
    "sfUrl":read_params["snowflake_url"],
    "sfUser":read_params["snowflake_userid"],
    "pem_private_key": pk,
    "sfDatabase":read_params["snowflake_database"],
    "sfSchema":read_params["snowflake_schema"],
    "sfWarehouse":read_params["snowflake_warehouse"],
    "sfRole":read_params["snowflake_role"]
    }
    return options

def createDatePair(erlst_dt_str,start_dt_str,end_dt_str):
    erlst_dt=datetime.strptime(erlst_dt_str,'%Y-%m-%d').date()
    start_dt=datetime.strptime(start_dt_str,'%Y-%m-%d').date()
    end_dt=datetime.strptime(end_dt_str,'%Y-%m-%d').date()
    print(f"Earliest Start Date : {erlst_dt}")
    print(f"Process Start Date : {start_dt}")
    print(f"Process End Date : {end_dt}")

    date_lst=[]
    for dt in rrule.rrule(rrule.MONTHLY, dtstart=start_dt, until=end_dt):
        end_date=dt.date()
        for dt2 in rrule.rrule(rrule.MONTHLY, dtstart=erlst_dt, until=end_date):
            start_date=dt2.date()
            if start_date < end_date:
                date_pair = f'{start_date};{end_date}'
                date_lst.append(date_pair)
            else:
                pass
    return(date_lst)

def createMapping(date_lst):
    sf_options=get_snowflake_options()
    total_lt=math.ceil(len(date_lst)/25)
    print(f"Total date pairs : {len(date_lst)}")
    print(f"Date pairs per loop : {total_lt}")
    name_lst=['a1', 'b1', 'c1', 'd1', 'e1', 'f1', 'g1', 'h1', 'i1', 'j1', 'k1', 'l1', 'm1', 'n1', 'o1', 'p1', 'q1', 'r1', 's1', 't1', 'u1', 'v1', 'w1', 'x1', 'y1', 'z1' ]
    for val in range(25):
        new_lst = date_lst[val*total_lt:(val+1)*total_lt]
        new_lst_str = str(new_lst).replace(",", "").replace("[", "").replace("]", "").replace("'","")
        mapping = {"ID": name_lst[val], "date_pairs": new_lst_str}
        df = spark.createDataFrame([mapping])
        df = df.withColumn("date_pairs", explode(split(df["date_pairs"], " ")))
        df = df.withColumn("start_date",split(df["date_pairs"], ";").getItem(0).cast("date")) \
            .withColumn("end_date",split(df["date_pairs"], ";").getItem(1).cast("date")) \
            .drop("date_pairs")
        df=df.withColumn("monthyear_1",date_format(df['start_date'], "MMM-yyyy")) \
            .withColumn("monthyearattached_1",date_format(df['start_date'],'MMMyy')) \
            .withColumn("monthyear_2",date_format(df['end_date'], 'MMM-yyyy')) \
            .withColumn("monthyearattached_2",date_format(df['end_date'], 'MMMyy')) 
        df.write.format("snowflake").options(**sf_options).option("dbtable","BDR_FFP_DA_WRK.BOP_EOP_DATE_LIST").mode("append").save()


def main():
    current_date = datetime.now()
    truncated_date = current_date.replace(day=1) 
    erlst_dt_str='2017-12-01'
    start_dt_str='2017-12-01'
    # end_dt_str='2024-01-01'
    end_dt_str=truncated_date.strftime("%Y-%m-%d")
    date_pair=createDatePair(erlst_dt_str,start_dt_str,end_dt_str)
    createMapping(date_pair)
    
if __name__ == "__main__":
    main()
