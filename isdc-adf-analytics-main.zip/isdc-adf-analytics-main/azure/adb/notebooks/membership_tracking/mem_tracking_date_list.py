# Databricks notebook source
from datetime import datetime, timedelta
from pyspark.sql.functions import explode,split,monotonically_increasing_id
from pyspark.sql import Row
from dateutil.relativedelta import relativedelta
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization
import re
import os

env=os.getenv('env_var')

def get_private_key():
    private_key_content = dbutils.secrets.get(scope=f"databricks_sc_{env}", key=f"isdc-sf-{env}-p8")
    # get the encryption password from the secret scope
    encryption_password = dbutils.secrets.get(scope=f"databricks_sc_{env}", key=f"isdc-sf-{env}-p8-pwd")
    #load the private key
    p_key = serialization.load_pem_private_key(private_key_content.encode(), password=encryption_password.encode(), backend=default_backend())
    pkb = p_key.private_bytes(encoding=serialization.Encoding.PEM, format=serialization.PrivateFormat.PKCS8, encryption_algorithm=serialization.NoEncryption())
    pkb = pkb.decode("UTF-8")
    pkb = re.sub("-*(BEGIN|END) PRIVATE KEY-*\n", "", pkb).replace("\n", "")
    return pkb

#gets input params of type str
def get_job_params(arg,default="",return_type=str):
    try:
        return return_type(dbutils.widgets.get(arg))
    except Exception:
        return return_type(default)


#create snowflake connection dict
def get_read_params():
    read_dict={}
    read_dict['snowflake_url']=get_job_params('snowflake_url')
    read_dict['snowflake_database']=get_job_params('snowflake_database')
    read_dict['snowflake_schema']=get_job_params('snowflake_schema')
    read_dict['snowflake_warehouse']=get_job_params('snowflake_warehouse')
    read_dict['snowflake_role']=get_job_params('snowflake_role')
    read_dict['snowflake_userid']=get_job_params('snowflake_userid')
    return read_dict

#create snowflake connection 
def get_snowflake_options():
    pk = get_private_key()
    read_params=get_read_params()
    options={
    "sfUrl":read_params["snowflake_url"],
    "sfUser":read_params["snowflake_userid"],
    "pem_private_key": pk,
    "sfDatabase":read_params["snowflake_database"],
    "sfSchema":read_params["snowflake_schema"],
    "sfWarehouse":read_params["snowflake_warehouse"],
    "sfRole":read_params["snowflake_role"]
    }
    return options

def get_thirteen_months():
    next_month_start_date = (datetime.now() + relativedelta(months=1)).replace(day=1)
    all_thirteen_months = []

    # Loop through the past 13 months
    for i in range(13):
        # Calculate the first day of the month
        first_day_of_month = (next_month_start_date - relativedelta(months=i)).replace(day=1)
        # Append the first day in the format YYYY-MM-DD to the list
        all_thirteen_months.append(first_day_of_month.strftime("%Y-%m-%d"))
    return all_thirteen_months

def create_sf_table(thirteen_months):
    sf_options=get_snowflake_options()
    rows=[]
    for date_str in thirteen_months:
        mydatetime = datetime.strptime(date_str, '%Y-%m-%d')
        mydate=date_str
        date1 = (mydatetime - relativedelta(months=1, seconds=1)).strftime('%Y-%m-%d')
        date2 = (mydatetime - relativedelta(months=0,seconds=1)).strftime('%Y-%m-%d')
        monthyear1 = (mydatetime - relativedelta(months=1)).strftime('%b-%Y')
        monthyearattached = (mydatetime - relativedelta(months=1)).strftime('%b%y')
        rows.append(Row(mydate=mydate, date1=date1, date2=date2, monthyear1=monthyear1, monthyearattached=monthyearattached))
    df=spark.createDataFrame(rows)
    # Add a temporary column for ordering
    df = df.withColumn("order_id", monotonically_increasing_id())
    # Order by the temporary column
    df = df.orderBy("order_id",ascending=False).drop("order_id")
    df.write.format("snowflake").options(**sf_options).option("dbtable","bdr_ffp_da_wrk.membership_tracking_date_list" ).mode("overwrite").save()

if __name__=="__main__":
    get_months=get_thirteen_months()
    create_sf_table(get_months)

