# Databricks notebook source
from datetime import datetime, timedelta
from pyspark.sql.functions import explode,split,monotonically_increasing_id
from pyspark.sql import Row
from pyspark.sql.types import StringType
from dateutil.relativedelta import relativedelta
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization
import re
import os

env=os.getenv('env_var')

def get_private_key():
    private_key_content = dbutils.secrets.get(scope=f"databricks_sc_{env}", key=f"isdc-sf-{env}-p8")
    # get the encryption password from the secret scope
    encryption_password = dbutils.secrets.get(scope=f"databricks_sc_{env}", key=f"isdc-sf-{env}-p8-pwd")
    #load the private key
    p_key = serialization.load_pem_private_key(private_key_content.encode(), password=encryption_password.encode(), backend=default_backend())
    pkb = p_key.private_bytes(encoding=serialization.Encoding.PEM, format=serialization.PrivateFormat.PKCS8, encryption_algorithm=serialization.NoEncryption())
    pkb = pkb.decode("UTF-8")
    pkb = re.sub("-*(BEGIN|END) PRIVATE KEY-*\n", "", pkb).replace("\n", "")
    return pkb

#gets input params of type str
def get_job_params(arg,default="",return_type=str):
    try:
        return return_type(dbutils.widgets.get(arg))
    except Exception:
        return return_type(default)


#create snowflake connection dict
def get_read_params():
    read_dict={}
    read_dict['snowflake_url']=get_job_params('snowflake_url')
    read_dict['snowflake_database']=get_job_params('snowflake_database')
    read_dict['snowflake_schema']=get_job_params('snowflake_schema')
    read_dict['snowflake_warehouse']=get_job_params('snowflake_warehouse')
    read_dict['snowflake_role']=get_job_params('snowflake_role')
    read_dict['snowflake_userid']=get_job_params('snowflake_userid')
    return read_dict

#create snowflake connection 
def get_snowflake_options():
    pk = get_private_key()
    read_params=get_read_params()
    options={
    "sfUrl":read_params["snowflake_url"],
    "sfUser":read_params["snowflake_userid"],
    "pem_private_key": pk,
    "sfDatabase":read_params["snowflake_database"],
    "sfSchema":read_params["snowflake_schema"],
    "sfWarehouse":read_params["snowflake_warehouse"],
    "sfRole":read_params["snowflake_role"]
    }
    return options

def read_query(query):
    df=spark.read.format('snowflake').options(**get_snowflake_options()).option('query',query).load()
    df=df.schema.fieldNames()
    return df

def build_query(table_name, columns):
    group_by_column = columns[0]
    select_columns = [f"max({col}) as {col}" for col in columns[1:]]
    select_statement = f"select {group_by_column}, " + ", ".join(select_columns)
    query = f"{select_statement} from {table_name} group by {group_by_column}"
    return query

if __name__=="__main__":
    plan_query="select * from bdr_ffp_da_wrk.mem_tracking_master_plan"
    plan_all_columns=read_query(plan_query)
    state_query="select * from bdr_ffp_da_wrk.mem_tracking_master_state"
    state_all_columns=read_query(state_query)
    full_plan_query=build_query("bdr_ffp_da_wrk.mem_tracking_master_plan",plan_all_columns)
    full_state_query=build_query("bdr_ffp_da_wrk.mem_tracking_master_state",state_all_columns)
    list_queries=[full_plan_query,full_state_query]
    df = spark.createDataFrame(list_queries, StringType()).toDF("max_queries")
    df.write.format("snowflake").options(**get_snowflake_options()).option("dbtable","bdr_ffp_da_wrk.mem_tracking_max").mode("overwrite").save()
