# Databricks notebook source
# MAGIC %md
# MAGIC Snowflake Connectivity and data retrival from snowflake 

# COMMAND ----------

# DBTITLE 1,Dynamic_Parameters
from datetime import datetime
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization
import re

def get_private_key():
    private_key_content = dbutils.secrets.get(scope="databricks_sc_dev", key="isdc-sf-dev-p8")
    # get the encryption password from the secret scope
    encryption_password = dbutils.secrets.get(scope="databricks_sc_dev", key="isdc-sf-dev-p8-pwd")
    #load the private key
    p_key = serialization.load_pem_private_key(private_key_content.encode(), password=encryption_password.encode(), backend=default_backend())
    pkb = p_key.private_bytes(encoding=serialization.Encoding.PEM, format=serialization.PrivateFormat.PKCS8, encryption_algorithm=serialization.NoEncryption())
    pkb = pkb.decode("UTF-8")
    pkb = re.sub("-*(BEGIN|END) PRIVATE KEY-*\n", "", pkb).replace("\n", "")
    return pkb

#gets input params of type str
def get_job_params(arg,default="",return_type=str):
    try:
        return return_type(dbutils.widgets.get(arg))
    except Exception:
        return return_type(default)

#create snowflake connection dict
def get_read_params():
    read_dict={}
    read_dict['snowflake_url']=get_job_params('snowflake_url')
    read_dict['snowflake_database']=get_job_params('snowflake_database')
    read_dict['snowflake_schema']=get_job_params('snowflake_schema')
    read_dict['snowflake_warehouse']=get_job_params('snowflake_warehouse')
    read_dict['snowflake_role']=get_job_params('snowflake_role')
    read_dict['snowflake_userid']=get_job_params('snowflake_userid')
    read_dict['snowflake_table']=get_job_params('snowflake_table')
    return read_dict

#create snowflake connection 
def get_snowflake_options():
    pk = get_private_key()
    read_params=get_read_params()
    options={
    "sfUrl":read_params["snowflake_url"],
    "sfUser":read_params["snowflake_userid"],
    "pem_private_key": pk,
    "sfDatabase":read_params["snowflake_database"],
    "sfSchema":read_params["snowflake_schema"],
    "sfWarehouse":read_params["snowflake_warehouse"],
    "sfRole":read_params["snowflake_role"],
    "sfTable":read_params["snowflake_table"]
    }
    return options

#create spark dataframe
def read_snowflake_query():
    sf_options=get_snowflake_options()
    params=get_read_params()
    try:
        print(f"Read table from Snowflake started {datetime.now().replace(microsecond=0)}")
        table_name=f"{params['snowflake_database']}.{params['snowflake_schema']}.{params['snowflake_table']}"
        df = spark.read.format("snowflake").options(**sf_options).option("dbtable", table_name).load()
        df=df.count()
        print(f"count is {df}")
        return df
    except Exception as e:
        raise e

if __name__ == "__main__":
    df=read_snowflake_query()
    print("process completed")

# COMMAND ----------

# DBTITLE 1,Static_Parameters
from datetime import datetime
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization
import re

def get_private_key():
    with open(r"/dbfs/mnt/saisdcnonprod/isdc/dev/analytics/inbox/private_keys/rsa_key_dev.p8", "rb") as key_file:
        p_key = serialization.load_pem_private_key(key_file.read(), password="ISDC2024".encode(), backend=default_backend())

    pkb = p_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )

    pkb = pkb.decode("UTF-8")
    pkb = re.sub("-*(BEGIN|END) PRIVATE KEY-*\n", "", pkb).replace("\n", "")
    return pkb


def get_snowflake_options():
    snowflake_url = "https://uhgdwaas.east-us-2.azure.snowflakecomputing.com/"
    snowflake_database = "UBLIA_TST_ISDC_DEV_DB"
    snowflake_schema = "BDR_FFP_DA_WRK"
    snowflake_warehouse = "UBLIA_TST_ETL_XS_WH"
    snowflake_role = "AZU_SDRP_UBLIA_TST_DEVELOPER_ROLE"
    snowflake_userid = "ISDC_DEV_DW@OPTUM.COM"
    pkb = get_private_key()
    options = {
        "sfUrl": snowflake_url,
        "sfUser": snowflake_userid,
        "pem_private_key": pkb,
        "sfDatabase": snowflake_database,
        "sfSchema": snowflake_schema,
        "sfWarehouse": snowflake_warehouse,
        "sfRole": snowflake_role,
    }
    return options

def read_snowflake(query):
    snow_options = get_snowflake_options()
    print("Read from Snowflake")
    df = spark.read.format("snowflake").options(**snow_options).option("query", query).load()
    return df


if __name__ == "__main__":
    snowflake_table="BDR_FFP_DA.LOSS_RATIO_ISDW_EFF_SALES_DASHBOARD"
    query = f"select * from {snowflake_table}"
    df = read_snowflake(query)
    df.display()

# COMMAND ----------

df.filter(df['PREM_DUE_MO_ID']=="202311").display()


# COMMAND ----------

df.createOrReplaceTempView("loss_ratio_isdw_eff_sales_dashboard")
df=spark.sql("select * from loss_ratio_isdw_eff_sales_dashboard")
df.display()

# COMMAND ----------


