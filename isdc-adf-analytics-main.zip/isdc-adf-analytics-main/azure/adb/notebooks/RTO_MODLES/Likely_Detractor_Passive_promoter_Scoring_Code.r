# Databricks notebook source
#setwd("/dbfs/mnt/saisdcnonprod/isdc/dev/R_Models/")
setwd("/dbfs/mnt/isdc_analytics/outbox/rto_models/")
score1<-read.csv("SCORE1.csv",stringsAsFactors = F,as.is = T,na.strings = "")
score2<-read.csv("SCORE2.csv",stringsAsFactors = F,as.is = T,na.strings = "")
score3<-read.csv("SCORE3.csv",stringsAsFactors = F,as.is = T,na.strings = "")
scoring_data<-rbind(score1,score2,score3)
#scoring_data<-rbind(score1)

# COMMAND ----------

check_var <- c("PLAN_CODE",
        "RET",
        "paid_net_memb_cont_amt_6_mnths",
        "tenure",
        "avg_proc_days",
        "tot_benefit_amt",
        "a_ECC_claim_total_app_6_mnths",
        "CHARGE_amount",
        "a_ECC_claim_total_charge",
        "max_proc_days",
        "tot_COVERED_EXPENSE",
        "ECC_claim_total_amt_paid",
        "avg_MEDICARE_APP_amount",
        "a_ECC_claim_total_deuct",
        "avg_MEDICARE_PAY_amount",
        "HOMVAL",
        "ECC_BL_payment_amount_3_mnths",
        "ECC_coins_amount_3_mnths",
        "PERSON_ID",
        "age",
        "application_processing_time",
        "avg_Benefit_amount",
        "avg_CHARGE_amount",
        "avg_DEDUCTIBLE_amount",
        "avg_PART_B_DEDUCT",
        "a_ECC_claim_total_amt_paid",
        "a_ECC_claim_total_app_amt",
        "a_ECC_clm_tot_inelig_amt",
        "a_ECC_coins_amount",
        "income",
        "NETWORK_HOSP_DIST",
        "networth",
        "no_calls",
        "no_claims",
        "paid_net_memb_cont_amt",
        "PLAN_CODE_N",
        "tot_EFT_disc_amount",
        "tot_loyalty_disc_amount",
        "MSUP_NUM_LAPSES",
        "Bank_Card_Single",
        "INDIVIDUAL_PREMIUM_AMOUNT",
        "OPPRTNTY_INQ_call",
        "MEDICARE_APP_amount",
        "avg_CHARGE_amount_6_mnths",
        "tot_benefit_amt_6_mnths",
        "MEDICARE_PAY_amount_12_mnths",
        "ECC_claim_total_deuct",
        "Gender_F",
        "new_member_fg",
        "tot_proc_days",
        "PART_B_DEDUCT",
        "RDC_1"
)

for (i in 1:length(check_var)) {
print(i)
if(tolower(check_var[i]) %in% tolower(colnames(scoring_data))){
names(scoring_data)[tolower(colnames(scoring_data)) == tolower(check_var[i])] = check_var[i]
}}


rm(score1)
rm(score2)
rm(score3)

# COMMAND ----------

# cHECKING WHICH COLUMNS STILL HAVE NA

col_names<-colnames(scoring_data)[colSums(is.na(scoring_data)) > 0]
col_names
scoring_data1<-scoring_data
scoring_data1[which(substr(scoring_data$PLAN_CODE,1,1)=='F'), "PLAN_CODE_F"] = 1
scoring_data1[which(substr(scoring_data$PLAN_CODE,1,1)!='F'), "PLAN_CODE_F"] = 0
scoring_data1[which(substr(scoring_data$PLAN_CODE,1,1)=='N'), "PLAN_CODE_N"] = 1
scoring_data1[which(substr(scoring_data$PLAN_CODE,1,1)!='N'), "PLAN_CODE_N"] = 0
rm(scoring_data)
col_names<-colnames(scoring_data1)[colSums(is.na(scoring_data1)) > 0]
col_names
# mode function--------------
Mode = function(x){
  ta = table(x)
  tam = max(ta)
  if (all(ta == tam))
    mod = NA
  else
    if(is.numeric(x))
      mod = as.numeric(names(ta)[ta == tam])
  else
    mod = names(ta)[ta == tam]
  return(mod)
}

#----------------------------

col_names
scoring_data1[is.na(scoring_data1$RET),"RET"]=as.numeric(Mode(scoring_data1[,"RET"]))
col_names<-colnames(scoring_data1)[colSums(is.na(scoring_data1)) > 0]
col_names
rm(col_names)
rm(Mode)

# COMMAND ----------

lapply(scoring_data1,class)

# COMMAND ----------

install.packages("randomForest",repos="http://cran.rstudio.com")
install.packages("dplyr",repos="http://cran.rstudio.com")

# COMMAND ----------

library(randomForest)
library(dplyr)
# install.packages("tidyr",repos="http://cran.rstudio.com")
# library(tidyr)
#load("/dbfs/mnt/saisdcnonprod/isdc/dev/R_Models/model_object/NPS_modeling_code_pass_prom_isd_object.R.RData")
load("/dbfs/mnt/isdc_analytics/R_Models/model_object/NPS_modeling_code_pass_prom_isd_object.R.RData")

# COMMAND ----------

library(randomForest)
library(dplyr)
# install.packages("tidyr",repos="http://cran.rstudio.com")
# library(tidyr)
load("/dbfs/mnt/isdc_analytics/R_Models/model_object/NPS_modeling_code_pass_prom_isd_object.R.RData")
pass_pred = predict(pas_model, tbl_df(scoring_data1[,varlist_NPS_Passive]),type='prob')
pass_pred

# COMMAND ----------

scoring_data1$passive_prob = pass_pred[,2]

rm(pass_pred)
rm(pas_model)

# COMMAND ----------


prom_pred = predict(prom_model, tbl_df(scoring_data1),type='prob')
scoring_data1$promoter_prob = prom_pred[,2]
#rm(prom_pred)
#rm(prom_model)
prom_pred

# COMMAND ----------

load("/dbfs/mnt/isdc_analytics/R_Models/NPS_detractor_model_new_isd_object.R.RData")
det_pred = predict(detractor_model,  tbl_df(scoring_data1),type='prob')
scoring_data1$detractor_prob = det_pred[,2]
det_pred
NPS_scored<-scoring_data1[,c("PERSON_ID","passive_prob","promoter_prob","detractor_prob")]
head(NPS_scored)
col_names<-colnames(NPS_scored)[colSums(is.na(NPS_scored)) > 0]
col_names
write.csv(NPS_scored,"scored_NPS.csv")

rm(detractor_model)
rm(varlist_NPS_Passive)
rm(varlist_NPS_Promoter)
