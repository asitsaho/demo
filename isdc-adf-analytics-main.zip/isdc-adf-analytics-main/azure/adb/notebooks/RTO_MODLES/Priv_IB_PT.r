# Databricks notebook source
# %r   
# if (system.file(package="h2o") == "")
# {print("no package")}
# else
# {detach("package:h2o", unload = TRUE)
# remove.packages("h2o")}


# COMMAND ----------

# MAGIC %python
# MAGIC from datetime import datetime,date
# MAGIC from cryptography.hazmat.backends import default_backend
# MAGIC from cryptography.hazmat.primitives import serialization
# MAGIC from pyspark.sql.functions import lit,ceil,col,when,greatest,monotonically_increasing_id
# MAGIC import re 
# MAGIC import math
# MAGIC import os
# MAGIC
# MAGIC env=os.getenv('env_var')
# MAGIC if env=="dev":
# MAGIC     account_name='saisdcnonprod'
# MAGIC elif env=="tst":
# MAGIC     account_name='saisdcnonprod'
# MAGIC else:
# MAGIC     account_name='saisdcprod'
# MAGIC
# MAGIC def get_private_key():
# MAGIC     private_key_content = dbutils.secrets.get(scope=f"databricks_sc_{env}", key=f"isdc-sf-{env}-p8")
# MAGIC     # get the encryption password from the secret scope
# MAGIC     encryption_password = dbutils.secrets.get(scope=f"databricks_sc_{env}", key=f"isdc-sf-{env}-p8-pwd")
# MAGIC     #load the private key
# MAGIC     p_key = serialization.load_pem_private_key(private_key_content.encode(), password=encryption_password.encode(), backend=default_backend())
# MAGIC     pkb = p_key.private_bytes(encoding=serialization.Encoding.PEM, format=serialization.PrivateFormat.PKCS8, encryption_algorithm=serialization.NoEncryption())
# MAGIC
# MAGIC     pkb = pkb.decode("UTF-8")
# MAGIC     pkb = re.sub("-*(BEGIN|END) PRIVATE KEY-*\n", "", pkb).replace("\n", "")
# MAGIC     return pkb
# MAGIC
# MAGIC #gets input params of type str
# MAGIC def get_job_params(arg,default="",return_type=str):
# MAGIC     try:
# MAGIC         return return_type(dbutils.widgets.get(arg))
# MAGIC     except Exception:
# MAGIC         return return_type(default)
# MAGIC
# MAGIC #create snowflake connection dict
# MAGIC def get_read_params():
# MAGIC     read_dict={}
# MAGIC     read_dict['snowflake_url']=get_job_params('snowflake_url')
# MAGIC     read_dict['snowflake_database']=get_job_params('snowflake_database')
# MAGIC     read_dict['snowflake_schema']=get_job_params('snowflake_schema')
# MAGIC     read_dict['snowflake_warehouse']=get_job_params('snowflake_warehouse')
# MAGIC     read_dict['snowflake_role']=get_job_params('snowflake_role')
# MAGIC     read_dict['snowflake_userid']=get_job_params('snowflake_userid')
# MAGIC     read_dict['snowflake_table']=get_job_params('snowflake_table')
# MAGIC     return read_dict
# MAGIC
# MAGIC #create snowflake connection 
# MAGIC def get_snowflake_options():
# MAGIC     pk = get_private_key()
# MAGIC     read_params=get_read_params()
# MAGIC     options={
# MAGIC     "sfUrl":read_params["snowflake_url"],
# MAGIC     "sfUser":read_params["snowflake_userid"],
# MAGIC     "pem_private_key": pk,
# MAGIC     "sfDatabase":read_params["snowflake_database"],
# MAGIC     "sfSchema":read_params["snowflake_schema"],
# MAGIC     "sfWarehouse":read_params["snowflake_warehouse"],
# MAGIC     "sfRole":read_params["snowflake_role"],
# MAGIC     "sfTable":read_params["snowflake_table"]
# MAGIC     }
# MAGIC     return options
# MAGIC
# MAGIC #create spark dataframe
# MAGIC def read_snowflake_query():
# MAGIC     sf_options=get_snowflake_options()
# MAGIC     params=get_read_params()
# MAGIC     try:
# MAGIC         print(f"Read table from Snowflake started {datetime.now().replace(microsecond=0)}")
# MAGIC         table_name=f"{params['snowflake_database']}.{params['snowflake_schema']}.{params['snowflake_table']}"
# MAGIC         RTO_MODELS_EFT_SYS_FINAL_DATASET9 = spark.read.format("snowflake").options(**sf_options).option("dbtable", table_name).load()
# MAGIC         # df_count=df.count()
# MAGIC         return RTO_MODELS_EFT_SYS_FINAL_DATASET9
# MAGIC     except Exception as e:
# MAGIC         raise e
# MAGIC
# MAGIC if __name__ == "__main__":
# MAGIC     RTO_MODELS_EFT_SYS_FINAL_DATASET9=read_snowflake_query()
# MAGIC     print("process completed")
# MAGIC     
# MAGIC RTO_MODELS_EFT_SYS_FINAL_DATASET9.createOrReplaceTempView("RTO_MODELS_EFT_PRIV_SS_FINAL_DATASET9")
# MAGIC RTO_MODELS_EFT_SYS_FINAL_DATASET9.write.format("csv").option("header", "true").mode("overwrite").save("/mnt/isdc_analytics/outbox/rto_models/RTO_MODELS_EFT_SYS_FINAL_DATASET9.csv")

# COMMAND ----------

install.packages("h2o",repos="http://cran.rstudio.com")
library(h2o)
detach("package:h2o", unload = TRUE)
remove.packages("h2o")

# COMMAND ----------

setwd("/dbfs/mnt/isdc_analytics/outbox/rto_models/RTO_MODELS_EFT_SYS_FINAL_DATASET9.csv")
files <- list.files(pattern = "part-.*\\.csv$")
scoring_data <- do.call(rbind, lapply(files, function(x) read.csv(x, stringsAsFactors = FALSE, as.is = TRUE, na.strings = "")))

# COMMAND ----------

library(SparkR)
library(stringr)
#RTO_MODELS_EFT_SYS_FINAL_DATASET9 <- sql("SELECT * FROM RTO_MODELS_EFT_PRIV_SS_FINAL_DATASET9")
# Convert Spark DataFrame to R DataFrame
#scoring_data  <- as.data.frame(collect(RTO_MODELS_EFT_SYS_FINAL_DATASET9))
# display(scoring_data)
scoring_data

# COMMAND ----------

col_names <- sapply(names(scoring_data), function(name) {
  parts <- unlist(strsplit(name, "\\.", fixed = TRUE))
  if(length(parts) > 1) parts[2] else parts[1]
})
names(scoring_data) <- col_names

# COMMAND ----------

check_var <- c("MSUP_NUM_LAPSES",
               "tot_EFT_disc_amount_6_mnths",
               "MSUP_ACTIVE_PROD_DURATION",
               "no_premium",
               "HOMVAL",
               "tot_Spouse_disc_amt_6_mnths",
               "FAMP_F",
               "DEDUCTIBLE_amount_3_mnths",
               "RET",
               "no_nba_camp_sent_before",
               "tot_premium_amt_6_mnths",
               "pdp_fg_final",
               "a_ECC_coins_amount_3_mnths",
               "no_pres_WEB_REG",
               "age",
               "no_calls_6_mnths",
               "no_treatment_3_mnths",
               "PERSON_ID")

for (i in 1:length(check_var)) {
  print(i)
  if(tolower(check_var[i]) %in% tolower(colnames(scoring_data))){
    names(scoring_data)[tolower(colnames(scoring_data)) == tolower(check_var[i])] = check_var[i]
  }}

# COMMAND ----------

# install.packages("h2o", type = "source", repos = "http://h2o-release.s3.amazonaws.com/h2o/rel-zahradnik/1/R")
h2o_version <- "3.32.0.1"
install.packages(
  paste0("https://cran.r-project.org/src/contrib/Archive/h2o/h2o_", h2o_version, ".tar.gz"),
  repos = NULL,
  type = "source"
)

library(h2o)

# COMMAND ----------

# keeping relevant columns in data
scoring_data = scoring_data[,check_var]
h2o.init(port = 54321)
options(scipen = 999)
prv_auth_dt <- as.h2o(scoring_data)

# COMMAND ----------

rm(scoring_data)
gc()

# COMMAND ----------

# Converting variables to factor
factor_var <- c("FAMP_F",
                "RET",
                "pdp_fg_final")				

prv_auth_dt[,factor_var] <- as.factor(prv_auth_dt[,factor_var])
rm(factor_var)

# Converting variables to numeric
num_var <- c("MSUP_NUM_LAPSES",
             "tot_EFT_disc_amount_6_mnths",
             "MSUP_ACTIVE_PROD_DURATION",
             "no_premium",
             "HOMVAL",
             "tot_Spouse_disc_amt_6_mnths",
             "DEDUCTIBLE_amount_3_mnths",
             "no_nba_camp_sent_before",
             "tot_premium_amt_6_mnths",
             "a_ECC_coins_amount_3_mnths",
             "no_pres_WEB_REG",
             "age",
             "no_calls_6_mnths",
             "no_treatment_3_mnths"
             )				

prv_auth_dt[,num_var] <- as.numeric(prv_auth_dt[,num_var])
rm(num_var)

#List of independent variables
independent_var <- c("MSUP_NUM_LAPSES",
                     "tot_EFT_disc_amount_6_mnths",
                     "MSUP_ACTIVE_PROD_DURATION",
                     "no_premium",
                     "HOMVAL",
                     "tot_Spouse_disc_amt_6_mnths",
                     "FAMP_F",
                     "DEDUCTIBLE_amount_3_mnths",
                     "RET",
                     "no_nba_camp_sent_before",
                     "tot_premium_amt_6_mnths",
                     "pdp_fg_final",
                     "a_ECC_coins_amount_3_mnths",
                     "no_pres_WEB_REG",
                     "age",
                     "no_calls_6_mnths",
                     "no_treatment_3_mnths")

# COMMAND ----------

#load model
#install.packages("h2o",lib="/mapr/datalake/optum/optuminsight/p_dlz/ism/prd/p_scripts/deep_processes/rto_models/rcode/packages_4",type="source", repos="https://h2o-release.s3.amazonaws.com/h2o/rel-zermelo/1/R")
model_priv_nba <- h2o.loadModel("/dbfs/mnt/isdc_analytics/R_Models/gbm_model_r_1623924447516_146")
print("completed model load")

# COMMAND ----------

predi<-h2o.predict(object =model_priv_nba,prv_auth_dt[,independent_var])
print("completed predict")

prv_auth_dt = h2o.cbind(prv_auth_dt,predi)
print("completed cbind")

priv_PT_scored<-prv_auth_dt[,c('PERSON_ID','predict','Yes','cal_Yes')]
names(priv_PT_scored) <- c('PERSON_ID','predict','prob_yes','priv_PT_probab')
priv_PT_scored = as.data.frame(priv_PT_scored)
setwd("/dbfs/mnt/isdc_analytics/outbox/rto_models/")
write.csv(priv_PT_scored,"priv_PT_scored.csv")

h2o.shutdown(prompt=FALSE)
