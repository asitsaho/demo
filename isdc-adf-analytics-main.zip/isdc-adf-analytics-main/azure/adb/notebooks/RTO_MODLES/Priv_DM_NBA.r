# Databricks notebook source
install.packages("h2o",repos="http://cran.rstudio.com")
library(h2o)
detach("package:h2o", unload = TRUE)
remove.packages("h2o")

setwd("/dbfs/mnt/isdc_analytics/R_Models")
data<-read.csv("NBA_DATA_4_2.csv",stringsAsFactors = F,as.is = T,na.strings = c(""))
setwd("/dbfs/mnt/isdc_analytics/outbox/rto_models/")

# COMMAND ----------

Mode = function(x){
  ta = table(x)
  tam = max(ta)
  if (all(ta == tam))
    mod = NA
  else
    if(is.numeric(x))
      mod = as.numeric(names(ta)[ta == tam])
  else
    mod = names(ta)[ta == tam]
  return(mod)
}


col_names<-colnames(data)[colSums(is.na(data)) > 0]


data[is.na(data$RET),"RET"]=as.numeric(Mode(data[,"RET"]))

data$PLAN_CODE_C=NULL
data[which(substr(data$PLAN_CODE,1,1)=='C'), "PLAN_CODE_C"] = 1
data[is.na(data$PLAN_CODE_C),"PLAN_CODE_C"]=0



data$PLAN_CODE_F=NULL

data[which(substr(data$PLAN_CODE,1,1)=='F'), "PLAN_CODE_F"] = 1
data[is.na(data$PLAN_CODE_F),"PLAN_CODE_F"]=0




data$PLAN_CODE_J=NULL

data[which(substr(data$PLAN_CODE,1,1)=='J'), "PLAN_CODE_J"] = 1
data[is.na(data$PLAN_CODE_J),"PLAN_CODE_J"]=0



data$PLAN_CODE_N=NULL

data[which(substr(data$PLAN_CODE,1,1)=='N'), "PLAN_CODE_N"] = 1
data[is.na(data$PLAN_CODE_N),"PLAN_CODE_N"]=0






data$ACTUAL_DROP_DATE<-NULL
data$datevar<-NULL
data$PERSON_ID<-NULL
# data$ACCOUNT_NUMBER<-NULL
data$INDIVIDUAL_ID<-NULL
data$product_type_code<-NULL
# data$Msup_benefit_mod_IND<-NULL
# data$AARP_ACCOUNT_NUMBER<-NULL
#data$s_q2<-NULL
# data$Survey_id<-NULL
# data$f_month_year<-NULL
# data$survey_month<-NULL
# data$survey_date<-NULL
# data$survey_date_1<-NULL
# data$DISCOUNT_KEY<-NULL
# data$zip_code_num<-NULL
data$ZIP_CODE<-NULL
data$PLAN_ID<-NULL
data$INS_PLAN_SWITCHER_IND<-NULL
data$SPECIFICATION_NAME<-NULL
data$PRODUCT_SECONDARY_VAR_CODE<-NULL
data$PLAN_CODE<-NULL
data$ORAC<-NULL
data$GENDER_CODE<-NULL
data$BC<-NULL
data$DISABLED_IND<-NULL
data$SMOKER_IND<-NULL
data$PRODUCT_TYPE_CODE<-NULL
data$PRODUCT_TYPE_VAR<-NULL



col_names<-colnames(data)[colSums(is.na(data)) > 0]

data$Target<-as.factor(data$Target)

class(data$Target)

# COMMAND ----------

install.packages("caret",repos="http://cran.rstudio.com")
library(caret)
set.seed(123)
trainIndex <- createDataPartition(data$Target, p = .7, 
                                  list = FALSE, 
                                  times = 1)

train_data<-data[trainIndex,]



test_data<-data[-trainIndex,]


s0 = train_data[train_data$Target==0,]
s1 = train_data[train_data$Target==1,]


s00 = s0[sample(1:nrow(s0), 4868,replace = F), ]
s11 = s1[sample(1:nrow(s1), 4868,replace = F), ]


newData_train_sample = rbind(s00,s11)


priv_NBA_varlist <- c( "Target",
                       "no_premium_6_mnths",
                       "ECC_claim_total_deuct_6_mnths",
                       "avg_DEDUCTIBLE_amount",
                       "paid_net_memb_cont_amt_3_mnths",
                       "PART_B_DEDUCT",
                       "income",
                       "tenure",
                       "RET",
                       "HOMVAL",
                       "tot_EFT_disc_amount_3_mnths",
                       "no_calls_3_mnths",
                       "no_treatment_3_mnths",
                       "INDIVIDUAL_PREMIUM_AMOUNT",
                       "a_ECC_claim_total_app_amt",
                       "tot_Spouse_disc_amt_3_mnths",
                       "age",
                       "no_claims"
                       
)

# COMMAND ----------

install.packages("RCurl",repos="http://cran.rstudio.com")
library(RCurl)

# COMMAND ----------

h2o_version <- "3.32.0.1"
install.packages(
  paste0("https://cran.r-project.org/src/contrib/Archive/h2o/h2o_", h2o_version, ".tar.gz"),
  repos = NULL,
  type = "source"
)

library(h2o)

# COMMAND ----------

# system("java -version")
packageVersion("h2o")
# h2o.getVersion()

# COMMAND ----------

#h2o.init(nthreads=-1, max_mem_size = "144G",ip= "localhost", port = 54544)
h2o.init(nthreads=-1, max_mem_size = "144G")

train<-as.h2o(newData_train_sample[,priv_NBA_varlist])

model_priv_nba<-h2o.randomForest( training_frame = train, y="Target",model_id = "rf9", 
                                  balance_classes=F, 
                                  stopping_metric= "AUC", 
                                  max_depth = 20 ,nfolds=5,ntrees = 400, 
                                  min_rows= .01*nrow(train), 
                                  sample_rate=0.8, 
                                  min_split_improvement=1e-06, 
                                  mtries=8,col_sample_rate_per_tree=0.6, 
                                  binomial_double_trees=TRUE, 
                                  stopping_tolerance=0.0001, 
                                  stopping_rounds=2, 
                                  score_each_iteration = T,seed = 1110)


importancee<-h2o.varimp(model_priv_nba)

test<-as.h2o(test_data[priv_NBA_varlist])

predi<-h2o.predict(model_priv_nba,test)
h2o.varimp(model_priv_nba)
pred<-as.data.frame(predi)
head(pred)
test<-as.data.frame(test)


lift = cbind(pred$p1,as.numeric(as.character(test$Target)))
lift = as.data.frame(lift)
colnames(lift)=c('prob' ,'promoter_flag')

# COMMAND ----------

#install.packages("dplyr",repos="http://cran.rstudio.com")
library(dplyr)
lift$decile = ntile(desc(lift$prob), 10)
decile_p = lift$decile
temp2 <- lift %>%
  group_by(decile) %>%
  arrange(decile) %>%
  mutate(event_count = sum(promoter_flag), counts = n()) %>%
  distinct(decile, event_count, counts)
temp2$lift <- temp2$event_count / sum(temp2$event_count) * 100
temp2$response_rate <-  temp2$event_count/temp2$counts * 100
temp2

rm(data)

# COMMAND ----------

save.image("/dbfs/mnt/isdc_analytics/R_Models/priv_nba_new_isd_object.R.RData")


# COMMAND ----------

model_path <- h2o.saveModel(object=model_priv_nba, path=getwd(), force=TRUE)


saved_model <- h2o.loadModel(model_path)

# COMMAND ----------

setwd("/dbfs/mnt/isdc_analytics/outbox/rto_models/")
score1<-read.csv("SCORE1.csv",stringsAsFactors = F,as.is = T,na.strings = "")
score2<-read.csv("SCORE2.csv",stringsAsFactors = F,as.is = T,na.strings = "")
score3<-read.csv("SCORE3.csv",stringsAsFactors = F,as.is = T,na.strings = "")

# COMMAND ----------
names(score1)[names(score1)=="AGE"] <-tolower("age")
names(score2)[names(score2)=="AGE"] <-tolower("age")
names(score3)[names(score3)=="AGE"] <-tolower("age")

# COMMAND ----------
score1$age <- as.numeric(score1$age)
score2$age <- as.numeric(score2$age)
score3$age <- as.numeric(score3$age)

# COMMAND ----------

score1$RET<-as.numeric(score1$RET)
score2$RET<-as.numeric(score2$RET)
score3$RET<-as.numeric(score3$RET)

score1<-score1[!is.na(score1$PLAN_CODE),]
score2<-score2[!is.na(score2$PLAN_CODE),]
score3<-score3[!is.na(score3$PLAN_CODE),]


#h2o.init(nthreads=-1, max_mem_size = "144G",ip= "localhost", port = 54544)
h2o.init(nthreads=-1, max_mem_size = "144G")

Mode = function(x){
  ta = table(x)
  tam = max(ta)
  if (all(ta == tam))
    mod = NA
  else
    if(is.numeric(x))
      mod = as.numeric(names(ta)[ta == tam])
  else
    mod = names(ta)[ta == tam]
  return(mod)
}


#----------------------------

score1[is.na(score1$RET),"RET"]=as.numeric(Mode(score1[,"RET"]))
score2[is.na(score2$RET),"RET"]=as.numeric(Mode(score2[,"RET"]))
score3[is.na(score3$RET),"RET"]=as.numeric(Mode(score3[,"RET"]))



score1[which(substr(score1$PLAN_CODE,1,1)=='F'), "PLAN_CODE_F"] = 1
score1[which(substr(score1$PLAN_CODE,1,1)!='F'), "PLAN_CODE_F"] = 0
score1[which(substr(score1$PLAN_CODE,1,1)=='N'), "PLAN_CODE_N"] = 1
score1[which(substr(score1$PLAN_CODE,1,1)!='N'), "PLAN_CODE_N"] = 0

score2[which(substr(score2$PLAN_CODE,1,1)=='F'), "PLAN_CODE_F"] = 1
score2[which(substr(score2$PLAN_CODE,1,1)!='F'), "PLAN_CODE_F"] = 0
score2[which(substr(score2$PLAN_CODE,1,1)=='N'), "PLAN_CODE_N"] = 1
score2[which(substr(score2$PLAN_CODE,1,1)!='N'), "PLAN_CODE_N"] = 0

score3[which(substr(score3$PLAN_CODE,1,1)=='F'), "PLAN_CODE_F"] = 1
score3[which(substr(score3$PLAN_CODE,1,1)!='F'), "PLAN_CODE_F"] = 0
score3[which(substr(score3$PLAN_CODE,1,1)=='N'), "PLAN_CODE_N"] = 1
score3[which(substr(score3$PLAN_CODE,1,1)!='N'), "PLAN_CODE_N"] = 0



scoring_data<-rbind(score1,score2,score3)
#scoring_data<-rbind(score1)

library(dplyr)
check_var <- c("no_premium_6_mnths",
        "ECC_claim_total_deuct_6_mnths",
        "avg_DEDUCTIBLE_amount",
        "paid_net_memb_cont_amt_3_mnths",
        "PART_B_DEDUCT",
        "income",
        "tenure",
        "RET",
        "HOMVAL",
        "tot_EFT_disc_amount_3_mnths",
        "no_calls_3_mnths",
        "no_treatment_3_mnths",
        "INDIVIDUAL_PREMIUM_AMOUNT",
        "a_ECC_claim_total_app_amt",
        "tot_Spouse_disc_amt_3_mnths",
        "age",
        "no_claims",
        "PERSON_ID",
        "PLAN_CODE")


for (i in 1:length(check_var)) {
  print(i)
  if(tolower(check_var[i]) %in% tolower(colnames(scoring_data))){
    names(scoring_data)[tolower(colnames(scoring_data)) == tolower(check_var[i])] = check_var[i]
  }}



col_names<-colnames(scoring_data)[colSums(is.na(scoring_data)) > 0]

col_names

scoring_data[is.na(scoring_data$RET),"RET"]=as.numeric(Mode(scoring_data[,"RET"]))


col_names<-colnames(scoring_data)[colSums(is.na(scoring_data)) > 0]

col_names


priv_NBA_varlist1<-priv_NBA_varlist[2:18]

scoring_data2<-as.h2o(scoring_data[priv_NBA_varlist1])

predi<-h2o.predict(model_priv_nba,scoring_data2)

pred<-as.data.frame(predi)
head(pred)

scoring_data$priv_nba_prob<-pred$p1

priv_nba_scored<-scoring_data[,c("PERSON_ID","priv_nba_prob")]

head(priv_nba_scored)

col_names<-colnames(priv_nba_scored)[colSums(is.na(priv_nba_scored)) > 0]

col_names

write.csv(priv_nba_scored,"priv_nba_scored.csv")

h2o.shutdown(prompt = FALSE)

