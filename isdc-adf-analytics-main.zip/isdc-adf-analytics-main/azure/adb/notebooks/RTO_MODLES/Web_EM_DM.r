# Databricks notebook source
setwd("/dbfs/mnt/isdc_analytics/outbox/rto_models/")
score1<-read.csv("SCORE1.csv",stringsAsFactors = F,as.is = T,na.strings = "")
score2<-read.csv("SCORE2.csv",stringsAsFactors = F,as.is = T,na.strings = "")
score3<-read.csv("SCORE3.csv",stringsAsFactors = F,as.is = T,na.strings = "")
scoring_data<-rbind(score1,score2,score3)
#scoring_data<-rbind(score1)

# COMMAND ----------

check_var <- c("tenure",
        "no_camp_C000003601_360days",
        "pdp_fg_final",
        "no_premium_6_mnths",
        "age",
        "paid_net_memb_cont_amt",
        "INDIVIDUAL_PREMIUM_AMOUNT",
        "no_calls_6_mnths",
        "MEDICARE_APP_amount_6_mnths",
        "OPPRTNTY_INQ_call",
        "a_ECC_coins_amount",
        "tot_premium_amt_3_mnths",
        "income",
        "ECC_claim_total_deuct",
        "HOMVAL",
        "a_ECC_claim_total_app_3_mnths",
        "PLAN_CODE",
        "RET",
        "PERSON_ID",
        "ECC_claim_total_app_3_mnths",
        "no_calls",
        "no_premium_3_mnths",
        "tot_premium_amt_6_mnths",
        "tot_loyalty_disc_amount",
        "MEDICARE_PAY_amount_6_mnths",
        "PAID_CERT_QNTY",
        "avg_COVERED_EXPENSE_6_mnths",
        "ECC_claim_total_deuct_6_mnths",
        "ECC_BL_payment_amount_3_mnths",
        "a_ECC_coins_amount_3_mnths"
)

for (i in 1:length(check_var)) {
print(i)
if(tolower(check_var[i]) %in% tolower(colnames(scoring_data))){
names(scoring_data)[tolower(colnames(scoring_data)) == tolower(check_var[i])] = check_var[i]
}}


rm(score1)
rm(score2)
rm(score3)

# COMMAND ----------


# cHECKING WHICH COLUMNS STILL HAVE NA

col_names<-colnames(scoring_data)[colSums(is.na(scoring_data)) > 0]

col_names

#scoring_data1<-scoring_data[!is.na(scoring_data$PLAN_CODE),]


#col_names<-colnames(scoring_data1)[colSums(is.na(scoring_data1)) > 0]

scoring_data1<-scoring_data

scoring_data1[which(substr(scoring_data$PLAN_CODE,1,1)=='F'), "PLAN_CODE_F"] = 1
scoring_data1[which(substr(scoring_data$PLAN_CODE,1,1)!='F'), "PLAN_CODE_F"] = 0
scoring_data1[which(substr(scoring_data$PLAN_CODE,1,1)=='N'), "PLAN_CODE_N"] = 1
scoring_data1[which(substr(scoring_data$PLAN_CODE,1,1)!='N'), "PLAN_CODE_N"] = 0



rm(scoring_data)

# COMMAND ----------

col_names<-colnames(scoring_data1)[colSums(is.na(scoring_data1)) > 0]
col_names

# mode function--------------

Mode = function(x){
  ta = table(x)
  tam = max(ta)
  if (all(ta == tam))
    mod = NA
  else
    if(is.numeric(x))
      mod = as.numeric(names(ta)[ta == tam])
  else
    mod = names(ta)[ta == tam]
  return(mod)
}


#----------------------------

col_names

scoring_data1[is.na(scoring_data1$RET),"RET"]=as.numeric(Mode(scoring_data1[,"RET"]))


col_names<-colnames(scoring_data1)[colSums(is.na(scoring_data1)) > 0]

col_names

rm(col_names)
rm(Mode)

# COMMAND ----------

########################### Web DM #################################################
install.packages("randomForest",repos="http://cran.rstudio.com")
library(randomForest)
load("/dbfs/mnt/isdc_analytics/R_Models/web_DM_ISD_model_object.R.RData")
pred_WEB_DM_score = predict(model_web_DM, scoring_data1,type='prob')
scoring_data1$WEB_DM_prob<-pred_WEB_DM_score[,2]
WEB_DM_scored<-scoring_data1[,c("PERSON_ID","WEB_DM_prob")]
col_names<-colnames(WEB_DM_scored)[colSums(is.na(WEB_DM_scored)) > 0]
col_names
head(WEB_DM_scored)
write.csv(WEB_DM_scored,"scored_WEB_DM.csv")
rm(model_web_DM)

# COMMAND ----------


load("/dbfs/mnt/isdc_analytics/R_Models/web_EM_ISD_model_object.R.RData")

pred_WEB_EM_score = predict(model_web_EM, scoring_data1,type='prob')
scoring_data1$WEB_EM_prob<-pred_WEB_EM_score[,2]

WEB_EM_scored<-scoring_data1[,c("PERSON_ID","WEB_EM_prob")]
col_names<-colnames(WEB_EM_scored)[colSums(is.na(WEB_EM_scored)) > 0]
col_names

head(WEB_EM_scored)
write.csv(WEB_EM_scored,"scored_WEB_EM.csv")
rm(model_web_EM)
