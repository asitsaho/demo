# Databricks notebook source
# MAGIC %sh
# MAGIC  python -m spacy download en_core_web_sm

# COMMAND ----------

# MAGIC %sh
# MAGIC python -m spacy validate

# COMMAND ----------

from pathlib import Path
from datetime import datetime,date
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization
from pyspark.sql.functions import split,explode,replace,udf,date_format
from pyspark.sql.types import StringType
import re,string,spacy,contractions
import os

env=os.getenv('env_var')
if env=="dev":
    account_name='saisdcnonprod'
elif env=="tst":
    account_name='saisdcnonprod'
else:
    account_name='saisdcprod'

report_date=date.today().strftime("%Y-%m-%d")
ref_date=date.fromisoformat(report_date)
file_path = Path(f"dbfs:/mnt/{account_name}/isdc/{env}/analytics/outbox/transcript_lemmatization/interactions_lemmatized_{report_date}.csv")
query=f"select interactionid,start_offset,end_offset,calluuid,party,phrase,inserted_on from src_ocss.aarp_uhc_srvc_intercation_transcripts where date(inserted_on) >= '{ref_date}'"

#decrypt and read private key
def get_private_key():
    private_key_content = dbutils.secrets.get(scope=f"databricks_sc_{env}", key=f"isdc-sf-{env}-p8")
    # get the encryption password from the secret scope
    encryption_password = dbutils.secrets.get(scope=f"databricks_sc_{env}", key=f"isdc-sf-{env}-p8-pwd")
    #load the private key
    p_key = serialization.load_pem_private_key(private_key_content.encode(), password=encryption_password.encode(), backend=default_backend())
    pkb = p_key.private_bytes(encoding=serialization.Encoding.PEM, format=serialization.PrivateFormat.PKCS8, encryption_algorithm=serialization.NoEncryption())
    pkb = pkb.decode("UTF-8")
    pkb = re.sub("-*(BEGIN|END) PRIVATE KEY-*\n", "", pkb).replace("\n", "")
    return pkb
    
#gets input params of type str
def get_job_params(arg,default="",return_type=str):
    try:
        return return_type(dbutils.widgets.get(arg))
    except Exception:
        return return_type(default)

#create snowflake connection dict
def get_read_params():
    read_dict={}
    read_dict['snowflake_url']=get_job_params('snowflake_url')
    read_dict['snowflake_database']=get_job_params('snowflake_database')
    read_dict['snowflake_schema']=get_job_params('snowflake_schema')
    read_dict['snowflake_warehouse']=get_job_params('snowflake_warehouse')
    read_dict['snowflake_role']=get_job_params('snowflake_role')
    read_dict['snowflake_userid']=get_job_params('snowflake_userid')
    return read_dict

#create snowflake connection 
def get_snowflake_options():
    pk = get_private_key()
    read_params=get_read_params()
    options={
    "sfUrl":read_params["snowflake_url"],
    "sfUser":read_params["snowflake_userid"],
    "pem_private_key": pk,
    "sfDatabase":read_params["snowflake_database"],
    "sfSchema":read_params["snowflake_schema"],
    "sfWarehouse":read_params["snowflake_warehouse"],
    "sfRole":read_params["snowflake_role"]
    }
    return options

# Define a UDF to remove punctuation
def remove_punct(text):
    return text.translate(str.maketrans('', '', string.punctuation))

# Register the UDF with Spark
remove_punct_udf = udf(remove_punct, StringType())

#supports only spacy version 3.3.0 
#load the spacy model 
nlp = spacy.load("en_core_web_sm")

# Define a UDF for lemmatization
def lemmatization(text):
    if len(text) == 0:
        return ''
    else:
        text = text.lower()
        text = contractions.fix(text)
        text = remove_punct(text)
        doc = nlp(text)
        return " ".join(str(token.lemma_) for token in doc)
    
# Register the UDF with Spark
lemmatization_udf = udf(lemmatization, StringType())


#Read snowflake table and write to csv file
def read_sf_write_csv():
    sf_options=get_snowflake_options()
    if file_path.exists():
        print(f"Date: {report_date} This file already exists")
    else:
        print("Read table from snowflake")
        df = spark.read.format("snowflake").options(**sf_options).option("query", query).load()
        df_count=df.count()
        
        if df_count>0:
            df = df.withColumn("phrase_lemmatized", lemmatization_udf(df["phrase"])).drop("phrase")
            # Adjust the DataFrame transformation to maintain the original timestamp format
            df = df.withColumn("inserted_on", date_format(df["inserted_on"],"yyyy-MM-dd HH:mm:ss.SSS"))
            df.write.format("csv").mode("overwrite").option("header", "true").option("sep",",").save(f"{file_path}") 
        else:
            print("Date: "+ report_date + " No data for this date")
            next
if __name__ == "__main__":
   read_sf_write_csv()
