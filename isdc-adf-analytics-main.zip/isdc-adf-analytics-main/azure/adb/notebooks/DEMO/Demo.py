# Databricks notebook source
# MAGIC %md
# MAGIC Snowflake Connectivity and data retrival from snowflake 

# COMMAND ----------

from datetime import datetime
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization
import re

def get_private_key():
    with open(r"/dbfs/mnt/saisdcnonprod/isdc/dev/analytics/inbox/private_keys/rsa_key_dev.p8", "rb") as key_file:
        p_key = serialization.load_pem_private_key(key_file.read(), password="ISDC2024".encode(), backend=default_backend())

    pkb = p_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )

    pkb = pkb.decode("UTF-8")
    pkb = re.sub("-*(BEGIN|END) PRIVATE KEY-*\n", "", pkb).replace("\n", "")
    return pkb


def get_snowflake_options():
    snowflake_url = "https://uhgdwaas.east-us-2.azure.snowflakecomputing.com/"
    snowflake_database = "UBLIA_TST_ISDC_DEV_DB"
    snowflake_schema = "BDR_FFP_DA_WRK"
    snowflake_warehouse = "UBLIA_TST_ETL_XS_WH"
    snowflake_role = "AZU_SDRP_UBLIA_TST_DEVELOPER_ROLE"
    snowflake_userid = "ISDC_DEV_DW@OPTUM.COM"
    pkb = get_private_key()
    options = {
        "sfUrl": snowflake_url,
        "sfUser": snowflake_userid,
        "pem_private_key": pkb,
        "sfDatabase": snowflake_database,
        "sfSchema": snowflake_schema,
        "sfWarehouse": snowflake_warehouse,
        "sfRole": snowflake_role,
    }
    return options

def read_snowflake(query):
    snow_options = get_snowflake_options()
    print("Read from Snowflake")
    df = spark.read.format("snowflake").options(**snow_options).option("query", query).load()
    return df


if __name__ == "__main__":
    snowflake_table="BDR_FFP_DA.LOSS_RATIO_ISDW_EFF_SALES_DASHBOARD"
    query = f"select * from {snowflake_table}"
    df = read_snowflake(query)
    df.display()

# COMMAND ----------

df.filter(df.D_ST_CD=='AZ').display()
