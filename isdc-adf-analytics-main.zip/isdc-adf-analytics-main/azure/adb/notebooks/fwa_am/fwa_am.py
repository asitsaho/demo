from pathlib import Path
from datetime import datetime, date
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization
from pyspark.sql.functions import split, explode, replace, udf, date_format
from pyspark.sql.types import StringType
import re, string, spacy, contractions
import os
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from difflib import SequenceMatcher
#import textdistance
#from fuzzywuzzy import fuzz
import re

from pyspark.sql import SparkSession

# Initialize Spark session
spark = SparkSession.builder.appName("SnowflakeIntegration").getOrCreate()

# Function to get the private key from a file
env=os.getenv('env_var')
account_name="saisdcnonprod" if env=="dev" or env=="tst" else "saisdcprod"

def get_private_key():
    private_key_content = dbutils.secrets.get(scope=f"databricks_sc_{env}", key=f"isdc-sf-{env}-p8")
    # get the encryption password from the secret scope
    encryption_password = dbutils.secrets.get(scope=f"databricks_sc_{env}", key=f"isdc-sf-{env}-p8-pwd")
    #load the private key
    p_key = serialization.load_pem_private_key(private_key_content.encode(), password=encryption_password.encode(), backend=default_backend())
    pkb = p_key.private_bytes(encoding=serialization.Encoding.PEM, format=serialization.PrivateFormat.PKCS8, encryption_algorithm=serialization.NoEncryption())
    pkb = pkb.decode("UTF-8")
    pkb = re.sub("-*(BEGIN|END) PRIVATE KEY-*\n", "", pkb).replace("\n", "")
    return pkb

#gets input params of type str
def get_job_params(arg,default="",return_type=str):
    try:
        return return_type(dbutils.widgets.get(arg))
    except Exception:
        return return_type(default)


#create snowflake connection dict
def get_read_params():
    read_dict={}
    read_dict['snowflake_url']=get_job_params('snowflake_url')
    read_dict['snowflake_database']=get_job_params('snowflake_database')
    read_dict['snowflake_schema']=get_job_params('snowflake_schema')
    read_dict['snowflake_warehouse']=get_job_params('snowflake_warehouse')
    read_dict['snowflake_role']=get_job_params('snowflake_role')
    read_dict['snowflake_userid']=get_job_params('snowflake_userid')
    return read_dict

#create snowflake connection 
def get_snowflake_options():
    pk = get_private_key()
    read_params=get_read_params()
    options={
    "sfUrl":read_params["snowflake_url"],
    "sfUser":read_params["snowflake_userid"],
    "pem_private_key": pk,
    "sfDatabase":read_params["snowflake_database"],
    "sfSchema":read_params["snowflake_schema"],
    "sfWarehouse":read_params["snowflake_warehouse"],
    "sfRole":read_params["snowflake_role"]
    }
    return options

# Function to read data from Snowflake using a query
def read_snowflake(query):
    # Get Snowflake connection options
    snow_options = get_snowflake_options()
    print("Read from Snowflake")
    
    # Read data from Snowflake using the provided query
    df = spark.read.format("snowflake").options(**snow_options).option("query", query).load()
    return df

# Define the Snowflake table to query
snowflake_table = "BDR_FFP_DA_WRK.FWA_AM_1"
# Create a query to select all rows from the table
query = f"select * from {snowflake_table}"
# Read data from Snowflake and store it in a DataFrame
df = read_snowflake(query)

# Define a function to calculate Jaccard similarity between two strings
def jaccard_similarity(str1, str2):
    if str1 is None or str2 is None:
        return 0.0
    a = set(str1.split()) if str1 else set()
    b = set(str2.split()) if str2 else set()
    intersection = len(a.intersection(b))
    union = len(a) + len(b) - intersection
    if union == 0:
        return 0.0
    return intersection / union

# Define a function to calculate similarity ratio between business names
def sim_ratio_business_name(row):
    seq1 = row['L_PROVIDER_BUSINESS_NAME_NPI']
    seq2 = row['L_BUSINESS_NAME_FWA']
    if seq1 is not None and seq2 is not None:
        matcher = SequenceMatcher(None, seq1, seq2)
        return matcher.ratio()
    else:
        return 0.0

# Convert Spark DataFrame to Pandas DataFrame for similarity calculations
df_pandas = df.toPandas()

# Calculate similarity scores for address, full name, and business name
df_pandas['JS_address'] = df_pandas.apply(lambda row: jaccard_similarity(row['KEY1_NPI'], row['KEY2_FWA']), axis=1)
df_pandas['SIM_Full_Name'] = df_pandas.apply(lambda row: jaccard_similarity(row['PROVIDER_FULLNAME_NPI'], row['PROVIDER_FULL_NAME_FWA']), axis=1)
df_pandas['Sim_BusinessName'] = df_pandas.apply(sim_ratio_business_name, axis=1)

# Filter the data based on similarity scores
shortlisted = [
    'NPI_FWA',
    'KEY2_FWA',
    'L_BUSINESS_NAME_FWA',
    'PROVIDER_FULL_NAME_FWA',
    'NPI',
    'KEY1_NPI',
    'L_PROVIDER_BUSINESS_NAME_NPI',
    'PROVIDER_FULLNAME_NPI',
    'JS_address',
    'Sim_BusinessName',
    'SIM_Full_Name'
]

# Select rows with high similarity scores
final = df_pandas[(df_pandas['JS_address'] > 0.85) | (df_pandas['Sim_BusinessName'] > 0.85) | (df_pandas['SIM_Full_Name'] > 0.85)][shortlisted]

# Check if the final DataFrame is empty before converting to Spark DataFrame
if not final.empty:
    # Convert Pandas DataFrame back to Spark DataFrame
    df_spark = spark.createDataFrame(final)
    
    # Write the Spark DataFrame to Snowflake
    df_spark.write.format("snowflake").options(**get_snowflake_options()).option("sfSchema", "BDR_FFP_DA_WRK").option("dbtable", "FWA_AM_NPI_FINAL_RAW_DEEP").mode("overwrite").save()
else:
    print("The final DataFrame is empty. No data to write to Snowflake.")