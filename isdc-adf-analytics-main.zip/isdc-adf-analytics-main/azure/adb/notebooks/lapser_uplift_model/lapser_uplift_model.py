# Databricks notebook source
# MAGIC %md
# MAGIC Snowflake Connection from R

# COMMAND ----------

from datetime import datetime
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization
import re
import os

env=os.getenv('env_var')

def get_private_key():
    private_key_content = dbutils.secrets.get(scope=f"databricks_sc_{env}", key=f"isdc-sf-{env}-p8")
    # get the encryption password from the secret scope
    encryption_password = dbutils.secrets.get(scope=f"databricks_sc_{env}", key=f"isdc-sf-{env}-p8-pwd")
    #load the private key
    p_key = serialization.load_pem_private_key(private_key_content.encode(), password=encryption_password.encode(), backend=default_backend())
    pkb = p_key.private_bytes(encoding=serialization.Encoding.PEM, format=serialization.PrivateFormat.PKCS8, encryption_algorithm=serialization.NoEncryption())
    pkb = pkb.decode("UTF-8")
    pkb = re.sub("-*(BEGIN|END) PRIVATE KEY-*\n", "", pkb).replace("\n", "")
    return pkb

#gets input params of type str
def get_job_params(arg,default="",return_type=str):
    try:
        return return_type(dbutils.widgets.get(arg))
    except Exception:
        return return_type(default)


#create snowflake connection dict
def get_read_params():
    read_dict={}
    read_dict['snowflake_url']=get_job_params('snowflake_url')
    read_dict['snowflake_database']=get_job_params('snowflake_database')
    read_dict['snowflake_schema']=get_job_params('snowflake_schema')
    read_dict['snowflake_warehouse']=get_job_params('snowflake_warehouse')
    read_dict['snowflake_role']=get_job_params('snowflake_role')
    read_dict['snowflake_userid']=get_job_params('snowflake_userid')
    return read_dict

#create snowflake connection 
def get_snowflake_options():
    pk = get_private_key()
    read_params=get_read_params()
    options={
    "sfUrl":read_params["snowflake_url"],
    "sfUser":read_params["snowflake_userid"],
    "pem_private_key": pk,
    "sfDatabase":read_params["snowflake_database"],
    "sfSchema":read_params["snowflake_schema"],
    "sfWarehouse":read_params["snowflake_warehouse"],
    "sfRole":read_params["snowflake_role"]
    }
    return options

def read_snowflake(table):
    snow_options = get_snowflake_options()
    print("Read from Snowflake")
    df = spark.read.format("snowflake").options(**snow_options).option("dbtable", table).load()
    return df

if __name__ == "__main__":
    Table1="CHANGE_HISTORY"
    MP_COMBINED_SET_FINAL = read_snowflake("bdr_ffp_da_wrk.MP_COMBINED_SET_FINAL")
    UPLIFT_STG3_MODUNIV_BOTH_PERS_FINAL = read_snowflake("bdr_ffp_da_wrk.uplift_stg3_moduniv_both_pers_final")


MP_COMBINED_SET_FINAL.createOrReplaceTempView("MPCMB_SET_FINAL")
UPLIFT_STG3_MODUNIV_BOTH_PERS_FINAL.createOrReplaceTempView("UPLIFT_STG3_FINAL")

MP_COMBINED_SET_FINAL.write.mode("overwrite").option("header", "true").csv('/mnt/isdc_analytics/inbox/lapser_uplift_model/MPCMB_SET_FINAL_1/')

UPLIFT_STG3_MODUNIV_BOTH_PERS_FINAL.write.mode("overwrite").option("header", "true").csv('/mnt/isdc_analytics/inbox/lapser_uplift_model/UPLIFT_STG3_MODUNIV_BOTH_PERS_FINAL/')


# COMMAND ----------

# MAGIC %r  
# MAGIC install.packages("h2o",repos="http://cran.rstudio.com")
# MAGIC library(h2o)
# MAGIC detach("package:h2o", unload = TRUE)
# MAGIC remove.packages("h2o")

# COMMAND ----------

# MAGIC %r
# MAGIC if (!require(data.table)) install.packages('data.table', dependencies=c("Depends", "Suggests"))
# MAGIC
# MAGIC # Check if h2o is installed, if not, install it
# MAGIC if (!require(h2o)) install.packages('h2o', dependencies=TRUE)
# MAGIC
# MAGIC library(data.table); setDTthreads(percent = 65)
# MAGIC library(DBI)
# MAGIC library(stringr)
# MAGIC library(plyr)
# MAGIC library(dplyr)
# MAGIC library(magrittr)
# MAGIC library(rlang)
# MAGIC library(h2o)
# MAGIC library(plyr)
# MAGIC library(dplyr)
# MAGIC library(ggplot2)
# MAGIC
# MAGIC currentDate <- Sys.Date() 

# COMMAND ----------

# MAGIC %r
# MAGIC library(SparkR)
# MAGIC library(stringr)
# MAGIC library(dplyr)
# MAGIC # Access the Spark DataFrame from the temporary view in R
# MAGIC #MPCMB_SET_FINAL_1 <- SparkR::sql("SELECT * FROM MPCMB_SET_FINAL")
# MAGIC #UPLIFT_STG3_FINAL <- SparkR::sql("SELECT * FROM UPLIFT_STG3_FINAL")
# MAGIC
# MAGIC file_list <- list.files(path = "/dbfs/mnt/isdc_analytics/inbox/lapser_uplift_model/MPCMB_SET_FINAL_1/", pattern = "*.csv", full.names = TRUE)
# MAGIC
# MAGIC data_v2 <- do.call(rbind, lapply(file_list, read.csv))
# MAGIC
# MAGIC file_list_loyalty <- list.files(path = "/dbfs/mnt/isdc_analytics/inbox/lapser_uplift_model/UPLIFT_STG3_MODUNIV_BOTH_PERS_FINAL/", pattern = "*.csv", full.names = TRUE)
# MAGIC
# MAGIC data_loyalty <- do.call(rbind, lapply(file_list_loyalty, read.csv))
# MAGIC
# MAGIC # Convert Spark DataFrame to R DataFrame
# MAGIC #data_v2  <- as.data.frame(collect(MPCMB_SET_FINAL_1))
# MAGIC #data_loyalty  <- as.data.frame(collect(UPLIFT_STG3_FINAL))
# MAGIC
# MAGIC
# MAGIC names(data_v2) <- str_replace_all(names(data_v2), c("mp_combined_set_final." = ""))
# MAGIC
# MAGIC
# MAGIC names(data_loyalty) <- str_replace_all(names(data_loyalty), c("uplift_stg3_moduniv_both_pers_final." = ""))
# MAGIC
# MAGIC head(data_loyalty)

# COMMAND ----------

# MAGIC %r
# MAGIC library(plyr)
# MAGIC library(dplyr)
# MAGIC
# MAGIC if (!require(data.table)) install.packages('data.table', dependencies=c("Depends", "Suggests"))
# MAGIC library(data.table)  # LOAD DATA.TABLE FOR AIDING IMPORT SPEED IN H2O.
# MAGIC
# MAGIC data.table::setDT(data_loyalty)
# MAGIC data.table::setDT(data_v2) 
# MAGIC
# MAGIC ### Left Join to get the updated 8 Loyalty column values.
# MAGIC data_v2$PERSON_ID <- as.numeric(data_v2$PERSON_ID)
# MAGIC data_loyalty$PERSON_ID <- as.numeric(data_loyalty$PERSON_ID)
# MAGIC data_v2a <- merge(x=data_v2, y=data_loyalty, by.x = "PERSON_ID", by.y = "PERSON_ID", all.x = FALSE, all.y = FALSE)

# COMMAND ----------

# MAGIC %r
# MAGIC data_v2x  <- data_v2a[, c("PERSON_ID"
# MAGIC                          ,"ADJ_BEN_AMT"
# MAGIC                          ,"ADJ_BEN_AMT_2YR"
# MAGIC                          ,"AGE"
# MAGIC                          ,"AGE_EXTRACT"
# MAGIC                          ,"AGE_FIRST_INDIVIDUAL"
# MAGIC                          ,"AGENT_APPT_REQUESTS_1YR"
# MAGIC                          ,"APPREC"
# MAGIC                          ,"APPS1YR"
# MAGIC                          ,"APPS1YR_AE"
# MAGIC                          ,"APPS1YR_DTC"
# MAGIC                          ,"APPS2YR"
# MAGIC                          ,"APPS2YR_AE"
# MAGIC                          ,"APPS2YR_DTC"
# MAGIC                          ,"BEN_B3"
# MAGIC                          ,"BEN_B4"
# MAGIC                          ,"BEN_B4_1YR"
# MAGIC                          ,"BEN_B4_2YR"
# MAGIC                          ,"CLAIM_COUNT"
# MAGIC                          ,"CLAIMS_2YR_SUM"
# MAGIC                          ,"CLM_PD_1YR"
# MAGIC                          ,"CONSTRUCTIONLOAN"
# MAGIC                          ,"COV_EXPN_AMT"
# MAGIC                          ,"CPT_CAT1"
# MAGIC                          ,"CPT_CAT1_2YR"
# MAGIC                          ,"CPT_CAT20"
# MAGIC                          ,"CPT_CAT22"
# MAGIC                          ,"CPT_CAT7"
# MAGIC                          ,"CPT_CATG"
# MAGIC                          ,"CPT_CATL"
# MAGIC                          ,"CPT_CATZ"
# MAGIC                          ,"CUR_ADJUD_RECENCY_DAY"
# MAGIC                          ,"CUR_ADJUD_RECENCY_MTH"
# MAGIC                          ,"CUR_ADJUD_RECENCY_YRS"
# MAGIC                          ,"CUR_PLAN_RECENCY_DAY"
# MAGIC                          ,"CUR_PLAN_RECENCY_MTH"
# MAGIC                          ,"CUR_PLAN_RECENCY_YRS"
# MAGIC                          ,"DED_AMT"
# MAGIC                          ,"DED_AMT_1YR"
# MAGIC                          ,"DED_AMT_2YR"
# MAGIC                          ,"DELQ_CERTS"
# MAGIC                          ,"DELQ_CERTS_1YR"
# MAGIC                          ,"DELQ_CERTS_2YR"
# MAGIC                          ,"DISPLAY_PLAN_CODE_CURR"
# MAGIC                          ,"EE_3YR"
# MAGIC                          ,"EE_3YR_1YR"
# MAGIC                          ,"EE_3YR_2YR"
# MAGIC                          ,"EE_3YR_EX"
# MAGIC                          ,"EE_6MO_1YR"
# MAGIC                          ,"EE_6MO_2YR"
# MAGIC                          ,"EE_6YR_1YR"
# MAGIC                          ,"EE_6YR_2YR"
# MAGIC                          ,"EMAIL_REQUESTS_1YR"
# MAGIC                          ,"EMAIL_REQUESTS_2YR"
# MAGIC                          ,"EMP_DELQ_PREM"
# MAGIC                          ,"EMP_DELQ_PREM_1YR"
# MAGIC                          ,"EMP_DELQ_PREM_2YR"
# MAGIC                          ,"EMPLOYER_ACCT_IND"
# MAGIC                          ,"EVC_INS_IND"
# MAGIC                          ,"EVC_MONTHS_W_PRODUCT"
# MAGIC                          ,"EVERACT_2YR"
# MAGIC                          ,"GENDER_RATE_TYPE_CD_CURR"
# MAGIC                          ,"GENERS20"
# MAGIC                          ,"GLOBAL_SUPP_IND"
# MAGIC                          ,"GRADUATEDLOAN"
# MAGIC                          ,"HCO_1YR"
# MAGIC                          ,"HCO_2YR"
# MAGIC                          ,"HCO_INBOUND_1YR"
# MAGIC                          ,"HCO_OPPORTUNITY_1YR"
# MAGIC                          ,"HCO_OPPORTUNITY_2YR"
# MAGIC                          ,"HCO_REASON_18"
# MAGIC                          ,"HCO_REASON_32"
# MAGIC                          ,"HCO_REASON_36"
# MAGIC                          ,"HCO_REASON_4"
# MAGIC                          ,"HCO_REASON_5"
# MAGIC                          ,"HCO_RESP_PROD_NOT_AVAIL_1YR"
# MAGIC                          ,"HCO_SUCC_OPP_1YR"
# MAGIC                          ,"HCO_SUCC_OPP_2YR"
# MAGIC                          ,"HCO_TOUCHPOINT_1YR"
# MAGIC                          ,"HCO_TOUCHPOINT_2YR"
# MAGIC                          ,"HH_CURR_INS_OTHPER_V2_MS"
# MAGIC                          ,"HOME_ASSESSED_VALUE_RANGES"
# MAGIC                          ,"ICD_CCS12"
# MAGIC                          ,"ICD_CCS17"
# MAGIC                          ,"ICD_CCS6"
# MAGIC                          ,"IM_PEN_MEM_50_OV"
# MAGIC                          ,"IM_PEN_MEM_65_OV"
# MAGIC                          ,"INQREC"
# MAGIC                          ,"K0083_COMB"
# MAGIC                          ,"K0464_COMB"
# MAGIC                          ,"LOYALTY_PROGRAM_CODE_CURR"
# MAGIC                          ,"MA_INDIV_PL_CH_DENIALS1YR"
# MAGIC                          ,"MA_INDIV_PL_CH_DENIALS2YR"
# MAGIC                          ,"MA_PL_CH_DENIALS1YR"
# MAGIC                          ,"MARKETING_CHANNEL_CURR"
# MAGIC                          ,"MBR_PD_PREM"
# MAGIC                          ,"MBR_PD_PREM_1YR"
# MAGIC                          ,"MBR_PD_PREM_2YR"
# MAGIC                          ,"MEDB_COVERAGE_DAYS"
# MAGIC                          ,"MEDB_COVERAGE_MTHS"
# MAGIC                          ,"MEDB_COVERAGE_YRS"
# MAGIC                          ,"MNT_SNC_APP_AG"
# MAGIC                          ,"MNT_SNC_APP_DTC"
# MAGIC                          ,"MNT_SNC_MS_APP_AG"
# MAGIC                          ,"MNT_SNC_MS_APP_DTC"
# MAGIC                          ,"MNTH_SNC_MS_APP_OTHPER_V2"
# MAGIC                          ,"MNTHS_SINC_PRD_NOT_AVL"
# MAGIC                          ,"MNTHS_SINC_TP_ENROLL_INQ"
# MAGIC                          ,"MNTHS_SINCE_PDP_INDIV_NEW_APP"
# MAGIC                          ,"MNTHS_SINCE_PDP_NEW_APP"
# MAGIC                          ,"MONTHS_SINC_MS_APP_OTHRPRS"
# MAGIC                          ,"MONTHS_SINCE_APP_OTHERPERS"
# MAGIC                          ,"MONTHS_SINCE_B4"
# MAGIC                          ,"MONTHS_SINCE_OPPORTUNITY"
# MAGIC                          ,"MONTHS_SINCE_PENSIVE"
# MAGIC                          ,"MONTHS_SINCE_PENSIVE2"
# MAGIC                          ,"MONTHS_SINCE_SUC_OPPORT"
# MAGIC                          ,"MONTHS_SINCE_TM_CONTACT"
# MAGIC                          ,"MONTHS_SINCE_TREAT_NOT"
# MAGIC                          ,"MONTHS_SINCE_TREAT_PRES"
# MAGIC                          ,"MONTHS_SINCE_TREATMENT"
# MAGIC                          ,"MONTHS_SINCE_WEB_REG"
# MAGIC                          ,"MSAPPREC"
# MAGIC                          ,"MSAPPS"
# MAGIC                          ,"MSAPPS1YR"
# MAGIC                          ,"MSAPPS1YR_AE"
# MAGIC                          ,"MSAPPS1YR_DTC"
# MAGIC                          ,"MSAPPS2YR"
# MAGIC                          ,"MSAPPS2YR_AE"
# MAGIC                          ,"MSAPPS2YR_DTC"
# MAGIC                          ,"MSINQREC"
# MAGIC                          ,"NBR_MS_PLANS_LIFETIME"
# MAGIC                          ,"NETW19"
# MAGIC                          ,"NURSE_FAC_DENIAL"
# MAGIC                          ,"OLD_DELQ_CERTS"
# MAGIC                          ,"OLD_DELQ_CERTS_1YR"
# MAGIC                          ,"OLD_DELQ_CERTS_2YR"
# MAGIC                          ,"OLD_PD_CERTS"
# MAGIC                          ,"OLD_PD_CERTS_1YR"
# MAGIC                          ,"OLD_PD_CERTS_2YR"
# MAGIC                          ,"OLD_TERM_CERTS_1YR"
# MAGIC                          ,"OLD_TERM_CERTS_2YR"
# MAGIC                          ,"PART_B_DED_AMT"
# MAGIC                          ,"PART_B_DED_AMT_2YR"
# MAGIC                          ,"PD_CERTS"
# MAGIC                          ,"PD_CERTS_1YR"
# MAGIC                          ,"PD_CERTS_2YR"
# MAGIC                          ,"PD_PREM"
# MAGIC                          ,"PD_PREM_1YR"
# MAGIC                          ,"PD_PREM_2YR"
# MAGIC                          ,"PDP_INS_IND"
# MAGIC                          ,"PDP_MONTHS_W_PRODUCT"
# MAGIC                          ,"PDPREMS_2YR_SUM"
# MAGIC                          ,"PENSIVE_CONTACTS_1YR"
# MAGIC                          ,"PENSIVE_CONTACTS_1YR2"
# MAGIC                          ,"PERSCLUST70"
# MAGIC                          ,"PRIOR_EFFECTIVE_DATE_MTHS"
# MAGIC                          ,"PRIOR_TERMINATION_DATE_MTHS"
# MAGIC                          ,"REV_DELQ_CERTS"
# MAGIC                          ,"REV_DELQ_CERTS_1YR"
# MAGIC                          ,"REV_DELQ_CERTS_2YR"
# MAGIC                          ,"SALES"
# MAGIC                          ,"SALES1YR"
# MAGIC                          ,"SALES2YR"
# MAGIC                          ,"SECLERICAL"
# MAGIC                          ,"SEMGMT"
# MAGIC                          ,"SEMGMT2"
# MAGIC                          ,"SEMGMTB"
# MAGIC                          ,"SEOTHER"
# MAGIC                          ,"SEOTHER2"
# MAGIC                          ,"SEOTHERB"
# MAGIC                          ,"SESTUDENT"
# MAGIC                          ,"SESTUDENT2"
# MAGIC                          ,"SESTUDENTB"
# MAGIC                          ,"SNIC"
# MAGIC                          ,"SNP_PL_CH_APPS"
# MAGIC                          ,"SNP_PL_CH_APPS1YR"
# MAGIC                          ,"SNP_PL_CH_APPS2YR"
# MAGIC                          ,"SNP_PL_CH_DENIALS"
# MAGIC                          ,"SNP_PL_CH_DENIALS1YR"
# MAGIC                          ,"SNP_PL_CH_DENIALS2YR"
# MAGIC                          ,"SNP_PL_CH_SALES"
# MAGIC                          ,"SNP_PL_CH_SALES1YR"
# MAGIC                          ,"SNP_PL_CH_SALES2YR"
# MAGIC                          ,"SRVC_FROM_1YR"
# MAGIC                          ,"SRVC_TO_1YR"
# MAGIC                          ,"TERM_CERTS_1YR"
# MAGIC                          ,"TERM_CERTS_2YR"
# MAGIC                          ,"TERM_REC"
# MAGIC                          ,"TERM_REC_MS"
# MAGIC                          ,"TIMESHARE"
# MAGIC                          ,"TOS_B"
# MAGIC                          ,"TOS_B_1YR"
# MAGIC                          ,"UHC_MS_LOYALTY_DAYS"
# MAGIC                          ,"UHC_MS_LOYALTY_MTHS"
# MAGIC                          ,"UHC_MS_LOYALTY_PCT"
# MAGIC                          ,"UHC_MS_LOYALTY_YRS"
# MAGIC                          ,"UNDERWRITING_RATE_UP_IND_CURR")]
# MAGIC

# COMMAND ----------

# MAGIC %r
# MAGIC data_v2a

# COMMAND ----------

# MAGIC %r
# MAGIC data_v2x$PERSON_ID                     <- as.numeric(data_v2a$PERSON_ID )
# MAGIC data_v2x$ADJ_BEN_AMT                   <- as.numeric(data_v2a$ADJ_BEN_AMT)
# MAGIC data_v2x$ADJ_BEN_AMT_2YR               <- as.numeric(data_v2a$ADJ_BEN_AMT_2YR)
# MAGIC data_v2x$AGE                           <- as.numeric(data_v2a$AGE)
# MAGIC data_v2x$AGE_EXTRACT                   <- as.numeric(data_v2a$AGE_EXTRACT)
# MAGIC data_v2x$AGENT_APPT_REQUESTS_1YR       <- as.numeric(data_v2a$AGENT_APPT_REQUESTS_1YR)
# MAGIC data_v2x$APPREC                        <- as.numeric(data_v2a$APPREC)
# MAGIC data_v2x$APPS1YR                       <- as.numeric(data_v2a$APPS1YR)
# MAGIC data_v2x$APPS1YR_AE                    <- as.numeric(data_v2a$APPS1YR_AE )
# MAGIC data_v2x$APPS1YR_DTC                   <- as.numeric(data_v2a$APPS1YR_DTC)
# MAGIC data_v2x$APPS2YR                       <- as.numeric(data_v2a$APPS2YR)
# MAGIC data_v2x$APPS2YR_AE                    <- as.numeric(data_v2a$APPS2YR_AE )
# MAGIC data_v2x$APPS2YR_DTC                   <- as.numeric(data_v2a$APPS2YR_DTC)
# MAGIC data_v2x$BEN_B3                        <- as.numeric(data_v2a$BEN_B3)
# MAGIC data_v2x$BEN_B4                        <- as.numeric(data_v2a$BEN_B4)
# MAGIC data_v2x$BEN_B4_1YR                    <- as.numeric(data_v2a$BEN_B4_1YR )
# MAGIC data_v2x$BEN_B4_2YR                    <- as.numeric(data_v2a$BEN_B4_2YR )
# MAGIC data_v2x$CLAIM_COUNT                   <- as.numeric(data_v2a$CLAIM_COUNT)
# MAGIC data_v2x$CLAIMS_2YR_SUM                <- as.numeric(data_v2a$CLAIMS_2YR_SUM)
# MAGIC data_v2x$CLM_PD_1YR                    <- as.numeric(data_v2a$CLM_PD_1YR )
# MAGIC data_v2x$CONSTRUCTIONLOAN              <- as.numeric(data_v2a$CONSTRUCTIONLOAN)
# MAGIC data_v2x$COV_EXPN_AMT                  <- as.numeric(data_v2a$COV_EXPN_AMT)
# MAGIC data_v2x$CPT_CAT1                      <- as.numeric(data_v2a$CPT_CAT1   )
# MAGIC data_v2x$CPT_CAT1_2YR                  <- as.numeric(data_v2a$CPT_CAT1_2YR)
# MAGIC data_v2x$CPT_CAT20                     <- as.numeric(data_v2a$CPT_CAT20)
# MAGIC data_v2x$CPT_CAT22                     <- as.numeric(data_v2a$CPT_CAT22)
# MAGIC data_v2x$CPT_CAT7                      <- as.numeric(data_v2a$CPT_CAT7 )
# MAGIC data_v2x$CPT_CATG                      <- as.numeric(data_v2a$CPT_CATG )
# MAGIC data_v2x$CPT_CATL                      <- as.numeric(data_v2a$CPT_CATL )
# MAGIC data_v2x$CPT_CATZ                      <- as.numeric(data_v2a$CPT_CATZ )
# MAGIC data_v2x$CUR_ADJUD_RECENCY_DAY         <- as.numeric(data_v2a$CUR_ADJUD_RECENCY_DAY)
# MAGIC data_v2x$CUR_ADJUD_RECENCY_MTH         <- as.numeric(data_v2a$CUR_ADJUD_RECENCY_MTH)
# MAGIC data_v2x$CUR_ADJUD_RECENCY_YRS         <- as.numeric(data_v2a$CUR_ADJUD_RECENCY_YRS)
# MAGIC data_v2x$CUR_PLAN_RECENCY_DAY          <- as.numeric(data_v2a$CUR_PLAN_RECENCY_DAY )
# MAGIC data_v2x$CUR_PLAN_RECENCY_MTH          <- as.numeric(data_v2a$CUR_PLAN_RECENCY_MTH )
# MAGIC data_v2x$CUR_PLAN_RECENCY_YRS          <- as.numeric(data_v2a$CUR_PLAN_RECENCY_YRS )
# MAGIC data_v2x$DED_AMT                       <- as.numeric(data_v2a$DED_AMT    )
# MAGIC data_v2x$DED_AMT_1YR                   <- as.numeric(data_v2a$DED_AMT_1YR)
# MAGIC data_v2x$DED_AMT_2YR                   <- as.numeric(data_v2a$DED_AMT_2YR)
# MAGIC data_v2x$DELQ_CERTS                    <- as.numeric(data_v2a$DELQ_CERTS )
# MAGIC data_v2x$DELQ_CERTS_1YR                <- as.numeric(data_v2a$DELQ_CERTS_1YR)
# MAGIC data_v2x$DELQ_CERTS_2YR                <- as.numeric(data_v2a$DELQ_CERTS_2YR)
# MAGIC # data_v2x$DISPLAY_PLAN_CODE_CURR        <- as.numeric(data_v2a$DISPLAY_PLAN_CODE_CURR)
# MAGIC data_v2x$EE_3YR                        <- as.numeric(data_v2a$EE_3YR)
# MAGIC data_v2x$EE_3YR_1YR                    <- as.numeric(data_v2a$EE_3YR_1YR )
# MAGIC data_v2x$EE_3YR_2YR                    <- as.numeric(data_v2a$EE_3YR_2YR )
# MAGIC data_v2x$EE_3YR_EX                     <- as.numeric(data_v2a$EE_3YR_EX  )
# MAGIC data_v2x$EE_6MO_1YR                    <- as.numeric(data_v2a$EE_6MO_1YR )
# MAGIC data_v2x$EE_6MO_2YR                    <- as.numeric(data_v2a$EE_6MO_2YR )
# MAGIC data_v2x$EE_6YR_1YR                    <- as.numeric(data_v2a$EE_6YR_1YR )
# MAGIC data_v2x$EE_6YR_2YR                    <- as.numeric(data_v2a$EE_6YR_2YR )
# MAGIC data_v2x$EMAIL_REQUESTS_1YR            <- as.numeric(data_v2a$EMAIL_REQUESTS_1YR)
# MAGIC data_v2x$EMAIL_REQUESTS_2YR            <- as.numeric(data_v2a$EMAIL_REQUESTS_2YR)
# MAGIC data_v2x$EMP_DELQ_PREM                 <- as.numeric(data_v2a$EMP_DELQ_PREM     )
# MAGIC data_v2x$EMP_DELQ_PREM_1YR             <- as.numeric(data_v2a$EMP_DELQ_PREM_1YR )
# MAGIC data_v2x$EMP_DELQ_PREM_2YR             <- as.numeric(data_v2a$EMP_DELQ_PREM_2YR )
# MAGIC data_v2x$EMPLOYER_ACCT_IND             <- as.numeric(data_v2a$EMPLOYER_ACCT_IND )
# MAGIC data_v2x$EVC_INS_IND                   <- as.numeric(data_v2a$EVC_INS_IND)
# MAGIC data_v2x$EVC_MONTHS_W_PRODUCT          <- as.numeric(data_v2a$EVC_MONTHS_W_PRODUCT)
# MAGIC data_v2x$EVERACT_2YR                   <- as.numeric(data_v2a$EVERACT_2YR)
# MAGIC # data_v2x$gender_rate_type_cd_curr      <- as.numeric(data_v2a$GENDER_RATE_TYPE_CD_CURR)
# MAGIC # data_v2x$geners20                      <- as.numeric(data_v2a$GENERS20   )
# MAGIC data_v2x$GLOBAL_SUPP_IND               <- as.numeric(data_v2a$GLOBAL_SUPP_IND   )
# MAGIC data_v2x$GRADUATEDLOAN                 <- as.numeric(data_v2a$GRADUATEDLOAN     )
# MAGIC data_v2x$HCO_1YR                       <- as.numeric(data_v2a$HCO_1YR    )
# MAGIC data_v2x$HCO_2YR                       <- as.numeric(data_v2a$HCO_2YR    )
# MAGIC data_v2x$HCO_INBOUND_1YR               <- as.numeric(data_v2a$HCO_INBOUND_1YR   )
# MAGIC data_v2x$HCO_OPPORTUNITY_1YR           <- as.numeric(data_v2a$HCO_OPPORTUNITY_1YR)
# MAGIC data_v2x$HCO_OPPORTUNITY_2YR           <- as.numeric(data_v2a$HCO_OPPORTUNITY_2YR)
# MAGIC data_v2x$HCO_REASON_18                 <- as.numeric(data_v2a$HCO_REASON_18)
# MAGIC data_v2x$HCO_REASON_32                 <- as.numeric(data_v2a$HCO_REASON_32)
# MAGIC data_v2x$HCO_REASON_36                 <- as.numeric(data_v2a$HCO_REASON_36)
# MAGIC data_v2x$HCO_REASON_4                  <- as.numeric(data_v2a$HCO_REASON_4 )
# MAGIC data_v2x$HCO_REASON_5                  <- as.numeric(data_v2a$HCO_REASON_5 )
# MAGIC data_v2x$HCO_RESP_PROD_NOT_AVAIL_1YR   <- as.numeric(data_v2a$HCO_RESP_PROD_NOT_AVAIL_1YR)
# MAGIC data_v2x$HCO_SUCC_OPP_1YR              <- as.numeric(data_v2a$HCO_SUCC_OPP_1YR)
# MAGIC data_v2x$HCO_SUCC_OPP_2YR              <- as.numeric(data_v2a$HCO_SUCC_OPP_2YR)
# MAGIC data_v2x$HCO_TOUCHPOINT_1YR            <- as.numeric(data_v2a$HCO_TOUCHPOINT_1YR)
# MAGIC data_v2x$HCO_TOUCHPOINT_2YR            <- as.numeric(data_v2a$HCO_TOUCHPOINT_2YR)
# MAGIC data_v2x$HH_CURR_INS_OTHPER_V2_MS      <- as.numeric(data_v2a$HH_CURR_INS_OTHPER_V2_MS)
# MAGIC # data_v2x$home_assessed_value_ranges    <- as.numeric(data_v2a$HOME_ASSESSED_VALUE_RANGES )
# MAGIC data_v2x$ICD_CCS12                     <- as.numeric(data_v2a$ICD_CCS12)
# MAGIC data_v2x$ICD_CCS17                     <- as.numeric(data_v2a$ICD_CCS17)
# MAGIC data_v2x$ICD_CCS6                      <- as.numeric(data_v2a$ICD_CCS6 )
# MAGIC data_v2x$IM_PEN_MEM_50_OV              <- as.numeric(data_v2a$IM_PEN_MEM_50_OV)
# MAGIC data_v2x$IM_PEN_MEM_65_OV              <- as.numeric(data_v2a$IM_PEN_MEM_65_OV)
# MAGIC data_v2x$INQREC                        <- as.numeric(data_v2a$INQREC)
# MAGIC # data_v2x$k0083_comb                    <- as.numeric(data_v2a$K0083_COMB )
# MAGIC # data_v2x$k0464_comb                    <- as.numeric(data_v2a$K0464_COMB )
# MAGIC data_v2x$LOYALTY_PROGRAM_CODE_CURR     <- as.numeric(data_v2a$LOYALTY_PROGRAM_CODE_CURR  )
# MAGIC data_v2x$MA_INDIV_PL_CH_DENIALS1YR     <- as.numeric(data_v2a$MA_INDIV_PL_CH_DENIALS1YR  )
# MAGIC data_v2x$MA_INDIV_PL_CH_DENIALS2YR     <- as.numeric(data_v2a$MA_INDIV_PL_CH_DENIALS2YR  )
# MAGIC data_v2x$MA_PL_CH_DENIALS1YR           <- as.numeric(data_v2a$MA_PL_CH_DENIALS1YR)
# MAGIC # data_v2x$marketing_channel_curr        <- as.numeric(data_v2a$MARKETING_CHANNEL_CURR)
# MAGIC data_v2x$MBR_PD_PREM                   <- as.numeric(data_v2a$MBR_PD_PREM)
# MAGIC data_v2x$MBR_PD_PREM_1YR               <- as.numeric(data_v2a$MBR_PD_PREM_1YR )
# MAGIC data_v2x$MBR_PD_PREM_2YR               <- as.numeric(data_v2a$MBR_PD_PREM_2YR )
# MAGIC data_v2x$MEDB_COVERAGE_DAYS            <- as.numeric(data_v2a$MEDB_COVERAGE_DAYS)
# MAGIC data_v2x$MEDB_COVERAGE_MTHS            <- as.numeric(data_v2a$MEDB_COVERAGE_MTHS)
# MAGIC data_v2x$MEDB_COVERAGE_YRS             <- as.numeric(data_v2a$MEDB_COVERAGE_YRS )
# MAGIC data_v2x$MNT_SNC_APP_AG                <- as.numeric(data_v2a$MNT_SNC_APP_AG  )
# MAGIC data_v2x$MNT_SNC_APP_DTC               <- as.numeric(data_v2a$MNT_SNC_APP_DTC )
# MAGIC data_v2x$MNT_SNC_MS_APP_AG             <- as.numeric(data_v2a$MNT_SNC_MS_APP_AG )
# MAGIC data_v2x$MNT_SNC_MS_APP_DTC            <- as.numeric(data_v2a$MNT_SNC_MS_APP_DTC)
# MAGIC data_v2x$MNTH_SNC_MS_APP_OTHPER_V2     <- as.numeric(data_v2a$MNTH_SNC_MS_APP_OTHPER_V2  )
# MAGIC data_v2x$MNTHS_SINC_PRD_NOT_AVL        <- as.numeric(data_v2a$MNTHS_SINC_PRD_NOT_AVL)
# MAGIC data_v2x$MNTHS_SINC_TP_ENROLL_INQ      <- as.numeric(data_v2a$MNTHS_SINC_TP_ENROLL_INQ)
# MAGIC data_v2x$MNTHS_SINCE_PDP_INDIV_NEW_APP <- as.numeric(data_v2a$MNTHS_SINCE_PDP_INDIV_NEW_APP)
# MAGIC data_v2x$MNTHS_SINCE_PDP_NEW_APP       <- as.numeric(data_v2a$MNTHS_SINCE_PDP_NEW_APP )
# MAGIC data_v2x$MONTHS_SINC_MS_APP_OTHRPRS    <- as.numeric(data_v2a$MONTHS_SINC_MS_APP_OTHRPRS )
# MAGIC data_v2x$MONTHS_SINCE_APP_OTHERPERS    <- as.numeric(data_v2a$MONTHS_SINCE_APP_OTHERPERS )
# MAGIC data_v2x$MONTHS_SINCE_B4               <- as.numeric(data_v2a$MONTHS_SINCE_B4 )
# MAGIC ##  data_v2x$months_since_cpt_cat13        <- as.numeric(data_V2A$MONTHS_SINCE_CPT_CAT13)
# MAGIC ##  data_v2x$months_since_cpt_cat15        <- as.numeric(data_V2A$MONTHS_SINCE_CPT_CAT15)
# MAGIC ##  data_v2x$months_since_e2               <- as.numeric(data_V2A$MONTHS_SINCE_E2 )
# MAGIC ##  data_v2x$months_since_e4               <- as.numeric(data_V2A$MONTHS_SINCE_E4 )
# MAGIC data_v2x$MONTHS_SINCE_OPPORTUNITY      <- as.numeric(data_v2a$MONTHS_SINCE_OPPORTUNITY)
# MAGIC data_v2x$MONTHS_SINCE_PENSIVE          <- as.numeric(data_v2a$MONTHS_SINCE_PENSIVE  )
# MAGIC data_v2x$MONTHS_SINCE_PENSIVE2         <- as.numeric(data_v2a$MONTHS_SINCE_PENSIVE2 )
# MAGIC data_v2x$MONTHS_SINCE_SUC_OPPORT       <- as.numeric(data_v2a$MONTHS_SINCE_SUC_OPPORT )
# MAGIC data_v2x$MONTHS_SINCE_TM_CONTACT       <- as.numeric(data_v2a$MONTHS_SINCE_TM_CONTACT )
# MAGIC ##  data_v2x$months_since_tos_d            <- as.numeric(data_V2A$MONTHS_SINCE_TOS_D)
# MAGIC data_v2x$MONTHS_SINCE_TREAT_NOT        <- as.numeric(data_v2a$MONTHS_SINCE_TREAT_NOT)
# MAGIC data_v2x$MONTHS_SINCE_TREAT_PRES       <- as.numeric(data_v2a$MONTHS_SINCE_TREAT_PRES )
# MAGIC data_v2x$MONTHS_SINCE_TREATMENT        <- as.numeric(data_v2a$MONTHS_SINCE_TREATMENT)
# MAGIC ##  data_v2x$months_since_wa               <- as.numeric(data_V2a$MONTHS_SINCE_WA )
# MAGIC data_v2x$MONTHS_SINCE_WEB_REG          <- as.numeric(data_v2a$MONTHS_SINCE_WEB_REG  )
# MAGIC data_v2x$MSAPPREC                      <- as.numeric(data_v2a$MSAPPREC )
# MAGIC data_v2x$MSAPPS                        <- as.numeric(data_v2a$MSAPPS)
# MAGIC data_v2x$MSAPPS1YR                     <- as.numeric(data_v2a$MSAPPS1YR)
# MAGIC data_v2x$MSAPPS1YR_AE                  <- as.numeric(data_v2a$MSAPPS1YR_AE )
# MAGIC data_v2x$MSAPPS1YR_DTC                 <- as.numeric(data_v2a$MSAPPS1YR_DTC)
# MAGIC data_v2x$MSAPPS2YR                     <- as.numeric(data_v2a$MSAPPS2YR)
# MAGIC data_v2x$MSAPPS2YR_AE                  <- as.numeric(data_v2a$MSAPPS2YR_AE )
# MAGIC data_v2x$MSAPPS2YR_DTC                 <- as.numeric(data_v2a$MSAPPS2YR_DTC)
# MAGIC data_v2x$MSINQREC                      <- as.numeric(data_v2a$MSINQREC )
# MAGIC data_v2x$NBR_MS_PLANS_LIFETIME         <- as.numeric(data_v2a$NBR_MS_PLANS_LIFETIME )
# MAGIC # data_v2x$netw19                        <- as.numeric(data_v2a$NETW19)
# MAGIC data_v2x$NURSE_FAC_DENIAL              <- as.numeric(data_v2a$NURSE_FAC_DENIAL)
# MAGIC data_v2x$OLD_DELQ_CERTS                <- as.numeric(data_v2a$OLD_DELQ_CERTS  )
# MAGIC data_v2x$OLD_DELQ_CERTS_1YR            <- as.numeric(data_v2a$OLD_DELQ_CERTS_1YR)
# MAGIC data_v2x$OLD_DELQ_CERTS_2YR            <- as.numeric(data_v2a$OLD_DELQ_CERTS_2YR)
# MAGIC data_v2x$OLD_PD_CERTS                  <- as.numeric(data_v2a$OLD_PD_CERTS )
# MAGIC data_v2x$OLD_PD_CERTS_1YR              <- as.numeric(data_v2a$OLD_PD_CERTS_1YR)
# MAGIC data_v2x$OLD_PD_CERTS_2YR              <- as.numeric(data_v2a$OLD_PD_CERTS_2YR)
# MAGIC data_v2x$OLD_TERM_CERTS_1YR            <- as.numeric(data_v2a$OLD_TERM_CERTS_1YR)
# MAGIC data_v2x$OLD_TERM_CERTS_2YR            <- as.numeric(data_v2a$OLD_TERM_CERTS_2YR)
# MAGIC data_v2x$PART_B_DED_AMT                <- as.numeric(data_v2a$PART_B_DED_AMT  )
# MAGIC data_v2x$PART_B_DED_AMT_2YR            <- as.numeric(data_v2a$PART_B_DED_AMT_2YR)
# MAGIC data_v2x$PD_CERTS                      <- as.numeric(data_v2a$PD_CERTS )
# MAGIC data_v2x$PD_CERTS_1YR                  <- as.numeric(data_v2a$PD_CERTS_1YR )
# MAGIC data_v2x$PD_CERTS_2YR                  <- as.numeric(data_v2a$PD_CERTS_2YR )
# MAGIC data_v2x$PD_PREM                       <- as.numeric(data_v2a$PD_PREM  )
# MAGIC data_v2x$PD_PREM_1YR                   <- as.numeric(data_v2a$PD_PREM_1YR)
# MAGIC data_v2x$PD_PREM_2YR                   <- as.numeric(data_v2a$PD_PREM_2YR)
# MAGIC data_v2x$PDP_INS_IND                   <- as.numeric(data_v2a$PDP_INS_IND)
# MAGIC data_v2x$PDP_MONTHS_W_PRODUCT          <- as.numeric(data_v2a$PDP_MONTHS_W_PRODUCT  )
# MAGIC data_v2x$PDPREMS_2YR_SUM               <- as.numeric(data_v2a$PDPREMS_2YR_SUM )
# MAGIC data_v2x$PENSIVE_CONTACTS_1YR          <- as.numeric(data_v2a$PENSIVE_CONTACTS_1YR  )
# MAGIC data_v2x$PENSIVE_CONTACTS_1YR2         <- as.numeric(data_v2a$PENSIVE_CONTACTS_1YR2 )
# MAGIC data_v2x$PERSCLUST70                   <- as.numeric(data_v2a$PERSCLUST70)
# MAGIC data_v2x$PRIOR_EFFECTIVE_DATE_MTHS     <- as.numeric(data_v2a$PRIOR_EFFECTIVE_DATE_MTHS  )
# MAGIC data_v2x$PRIOR_TERMINATION_DATE_MTHS   <- as.numeric(data_v2a$PRIOR_TERMINATION_DATE_MTHS)
# MAGIC data_v2x$REV_DELQ_CERTS                <- as.numeric(data_v2a$REV_DELQ_CERTS  )
# MAGIC data_v2x$REV_DELQ_CERTS_1YR            <- as.numeric(data_v2a$REV_DELQ_CERTS_1YR)
# MAGIC data_v2x$REV_DELQ_CERTS_2YR            <- as.numeric(data_v2a$REV_DELQ_CERTS_2YR)
# MAGIC data_v2x$SALES                         <- as.numeric(data_v2a$SALES )
# MAGIC data_v2x$SALES1YR                      <- as.numeric(data_v2a$SALES1YR )
# MAGIC data_v2x$SALES2YR                      <- as.numeric(data_v2a$SALES2YR )
# MAGIC data_v2x$SECLERICAL                    <- as.numeric(data_v2a$SECLERICAL )
# MAGIC data_v2x$SEMGMT                        <- as.numeric(data_v2a$SEMGMT)
# MAGIC data_v2x$SEMGMT2                       <- as.numeric(data_v2a$SEMGMT2  )
# MAGIC data_v2x$SEMGMTB                       <- as.numeric(data_v2a$SEMGMTB  )
# MAGIC data_v2x$SEOTHER                       <- as.numeric(data_v2a$SEOTHER  )
# MAGIC data_v2x$SEOTHER2                      <- as.numeric(data_v2a$SEOTHER2 )
# MAGIC data_v2x$SEOTHERB                      <- as.numeric(data_v2a$SEOTHERB )
# MAGIC data_v2x$SESTUDENT                     <- as.numeric(data_v2a$SESTUDENT)
# MAGIC data_v2x$SESTUDENT2                    <- as.numeric(data_v2a$SESTUDENT2 )
# MAGIC data_v2x$SESTUDENTB                    <- as.numeric(data_v2a$SESTUDENTB )
# MAGIC # data_v2x$snic                          <- as.numeric(data_v2a$SNIC)
# MAGIC data_v2x$SNP_PL_CH_APPS                <- as.numeric(data_v2a$SNP_PL_CH_APPS  )
# MAGIC data_v2x$SNP_PL_CH_APPS1YR             <- as.numeric(data_v2a$SNP_PL_CH_APPS1YR )
# MAGIC data_v2x$SNP_PL_CH_APPS2YR             <- as.numeric(data_v2a$SNP_PL_CH_APPS2YR )
# MAGIC data_v2x$SNP_PL_CH_DENIALS             <- as.numeric(data_v2a$SNP_PL_CH_DENIALS )
# MAGIC data_v2x$SNP_PL_CH_DENIALS1YR          <- as.numeric(data_v2a$SNP_PL_CH_DENIALS1YR  )
# MAGIC data_v2x$SNP_PL_CH_DENIALS2YR          <- as.numeric(data_v2a$SNP_PL_CH_DENIALS2YR  )
# MAGIC data_v2x$SNP_PL_CH_SALES               <- as.numeric(data_v2a$SNP_PL_CH_SALES )
# MAGIC data_v2x$SNP_PL_CH_SALES1YR            <- as.numeric(data_v2a$SNP_PL_CH_SALES1YR)
# MAGIC data_v2x$SNP_PL_CH_SALES2YR            <- as.numeric(data_v2a$SNP_PL_CH_SALES2YR)
# MAGIC data_v2x$SRVC_FROM_1YR                 <- as.numeric(data_v2a$SRVC_FROM_1YR)
# MAGIC data_v2x$SRVC_TO_1YR                   <- as.numeric(data_v2a$SRVC_TO_1YR)
# MAGIC data_v2x$TERM_CERTS_1YR                <- as.numeric(data_v2a$TERM_CERTS_1YR  )
# MAGIC data_v2x$TERM_CERTS_2YR                <- as.numeric(data_v2a$TERM_CERTS_2YR  )
# MAGIC data_v2x$TERM_REC                      <- as.numeric(data_v2a$TERM_REC )
# MAGIC data_v2x$TERM_REC_MS                   <- as.numeric(data_v2a$TERM_REC_MS)
# MAGIC data_v2x$TIMESHARE                     <- as.numeric(data_v2a$TIMESHARE)
# MAGIC data_v2x$TOS_B                         <- as.numeric(data_v2a$TOS_B )
# MAGIC data_v2x$TOS_B_1YR                     <- as.numeric(data_v2a$TOS_B_1YR)
# MAGIC data_v2x$UHC_MS_LOYALTY_DAYS           <- as.numeric(data_v2a$UHC_MS_LOYALTY_DAYS)
# MAGIC data_v2x$UHC_MS_LOYALTY_MTHS           <- as.numeric(data_v2a$UHC_MS_LOYALTY_MTHS)
# MAGIC data_v2x$UHC_MS_LOYALTY_PCT            <- as.numeric(data_v2a$UHC_MS_LOYALTY_PCT)
# MAGIC data_v2x$UHC_MS_LOYALTY_YRS            <- as.numeric(data_v2a$UHC_MS_LOYALTY_YRS)
# MAGIC # data_v2x$underwriting_rate_up_ind_curr <- as.numeric(data_v2a$UNDERWRITING_RATE_UP_IND_CURR)
# MAGIC

# COMMAND ----------

# MAGIC %r
# MAGIC system.time(data_v3a <- setorder(data_v2x, PERSON_ID))

# COMMAND ----------

# MAGIC %r
# MAGIC names(data_v3a) <- tolower(names(data_v3a))

# COMMAND ----------

# MAGIC %r
# MAGIC head(data_v3a)

# COMMAND ----------

# MAGIC %r
# MAGIC library(plyr)
# MAGIC library(dplyr)
# MAGIC library(magrittr)
# MAGIC library(rlang)
# MAGIC
# MAGIC head(data_v3a)
# MAGIC dim(data_v3a)
# MAGIC
# MAGIC env <- Sys.getenv('env_var')
# MAGIC account_name <- ifelse(env == 'dev' | env == 'tst', 'saisdcnonprod', 'saisdcprod')
# MAGIC currentDate <- Sys.Date()
# MAGIC csvFileName1 <- paste0("/dbfs/mnt/isdc_analytics/outbox/lapser_uplift_model/R_Models/prelapser_to_score_", currentDate, ".csv", sep="")
# MAGIC data.table::fwrite(data_v3a,csvFileName1)

# COMMAND ----------

# MAGIC %r
# MAGIC library(h2o)
# MAGIC library(plyr)
# MAGIC library(dplyr)
# MAGIC library(magrittr)
# MAGIC library(ggplot2)
# MAGIC
# MAGIC try(find.package("h2o"))
# MAGIC packageVersion("h2o")
# MAGIC
# MAGIC h2o.init(nthreads=-1, max_mem_size = "120G", ip = "localhost", port = 54330, bind_to_localhost = FALSE)  # Use port 54321 if using lares package (R dataframes only)
# MAGIC h2o.removeAll()   # Used to recover as much memory as possible.
# MAGIC
# MAGIC h2o.clusterStatus()
# MAGIC h2o.clusterInfo()
# MAGIC
# MAGIC # h2o.flow()
# MAGIC
# MAGIC options("h2o.use.data.table" = TRUE)
# MAGIC env <- Sys.getenv('env_var')
# MAGIC account_name <- ifelse(env == 'dev' | env == 'tst', 'saisdcnonprod', 'saisdcprod')
# MAGIC currentDate <- Sys.Date()
# MAGIC csvFileName1 <- paste0("/dbfs/mnt/isdc_analytics/outbox/lapser_uplift_model/R_Models/prelapser_to_score_", currentDate, ".csv", sep="")
# MAGIC
# MAGIC prelapser_to_score <- h2o.importFile(csvFileName1, na.strings = c("NA", "NULL", ""))
# MAGIC
# MAGIC prelapser_to_score$PDP_ins_ind <- prelapser_to_score$pdp_ins_ind  
# MAGIC head(prelapser_to_score$PDP_ins_ind)
# MAGIC
# MAGIC dim(prelapser_to_score)
# MAGIC head(prelapser_to_score)

# COMMAND ----------

# MAGIC %r
# MAGIC env <- Sys.getenv('env_var')
# MAGIC account_name <- ifelse(env == 'dev' | env == 'tst', 'saisdcnonprod', 'saisdcprod')
# MAGIC mojo_model_1_file_path <- paste0("/dbfs/mnt/isdc_analytics/R_Models/StackedEnsemble_AllModels_AutoML_20220811_114510.zip")
# MAGIC mojo_model_1 <- h2o.upload_mojo(mojo_model_1_file_path)

# COMMAND ----------

# MAGIC %r
# MAGIC # List all models in the H2O cluster
# MAGIC h2o.ls()

# COMMAND ----------

# MAGIC %r
# MAGIC prelapser_is_scored <- h2o.predict(mojo_model_1, prelapser_to_score)
# MAGIC head(prelapser_is_scored)
# MAGIC env <- Sys.getenv('env_var')
# MAGIC account_name <- ifelse(env == 'dev' | env == 'tst', 'saisdcnonprod', 'saisdcprod')
# MAGIC csvFileName2 <- paste("/dbfs/mnt/isdc_analytics/outbox/lapser_uplift_model/R_Models/prelapser_is_scored_",currentDate,".csv",sep="")
# MAGIC h2o.exportFile(prelapser_is_scored, path = csvFileName2, force = TRUE)
# MAGIC
# MAGIC names(prelapser_is_scored)[1] = c("bau_lapse_predict")
# MAGIC names(prelapser_is_scored)[2] = c("bau_reten_score")
# MAGIC names(prelapser_is_scored)[3] = c("bau_lapse_score")
# MAGIC
# MAGIC dim(prelapser_is_scored)
# MAGIC head(prelapser_is_scored)
# MAGIC
# MAGIC print(h2o.isfactor(prelapser_is_scored["bau_lapse_predict"]))
# MAGIC
# MAGIC # Per H2O, first change enum/factor column to charater... then to numeric.
# MAGIC prelapser_is_scored["bau_lapse_predict"] <- as.character(prelapser_is_scored["bau_lapse_predict"])
# MAGIC prelapser_is_scored["bau_lapse_predict"] <- as.numeric(prelapser_is_scored["bau_lapse_predict"])
# MAGIC
# MAGIC uplift_to_score <- h2o.cbind(prelapser_to_score, prelapser_is_scored)

# COMMAND ----------

# MAGIC %r
# MAGIC
# MAGIC # These 2 lines underneath can be used to help compare monthly scoring files to catch drifting anomalies over time.
# MAGIC # currentDate <- Sys.Date()
# MAGIC env <- Sys.getenv('env_var')
# MAGIC account_name <- ifelse(env == 'dev' | env == 'tst', 'saisdcnonprod', 'saisdcprod')
# MAGIC csvFileName3 <- paste("/dbfs/mnt/isdc_analytics/outbox/lapser_uplift_model/R_Models/uplift_to_score_",currentDate,".csv",sep="")
# MAGIC h2o.exportFile(uplift_to_score, path = csvFileName3, force = TRUE)
# MAGIC
# MAGIC # Use the new uplift model built w/o most_recent_drop variable and w/o retail_purch_activity_dt_cat vars (5).
# MAGIC mojo_model_2_file_path <- paste0("/dbfs/mnt/isdc_analytics/R_Models/StackedEnsemble_AllModels_AutoML_20221028_175300.zip")
# MAGIC mojo_model_2 <- h2o.upload_mojo(mojo_model_2_file_path)
# MAGIC # mojo_model <- h2o.upload_mojo("/mapr/datalake/optum/optuminsight/t_dlz/ism/tst/developer/kching1/R/Models/Prelapser_2022_03/Saved_Models/Mktg_RetUplift_1mm_401/MOJO/StackedEnsemble_AllModels_AutoML_20220815_153036.zip")

# COMMAND ----------

# MAGIC %r
# MAGIC #######
# MAGIC uplift_is_scored <- h2o.predict(mojo_model_2, uplift_to_score)
# MAGIC #######
# MAGIC head(uplift_is_scored)
# MAGIC
# MAGIC uplift_is_scored$person_id         <- uplift_to_score$person_id
# MAGIC uplift_is_scored$bau_lapse_predict <- uplift_to_score$bau_lapse_predict
# MAGIC uplift_is_scored$bau_lapse_score   <- uplift_to_score$bau_lapse_score
# MAGIC uplift_is_scored$bau_reten_score   <- uplift_to_score$bau_reten_score

# COMMAND ----------

# MAGIC %r
# MAGIC # currentDate <- Sys.Date()
# MAGIC env <- Sys.getenv('env_var')
# MAGIC account_name <- ifelse(env == 'dev' | env == 'tst', 'saisdcnonprod', 'saisdcprod')
# MAGIC csvFileName4 <- paste("/dbfs/mnt/isdc_analytics/outbox/lapser_uplift_model/R_Models/uplift_is_scored",currentDate,".csv",sep="")
# MAGIC h2o.exportFile(uplift_is_scored, path = csvFileName4, force = TRUE)
# MAGIC
# MAGIC dim(uplift_is_scored)

# COMMAND ----------

# MAGIC %r
# MAGIC #csvFileName5 <- paste("/mapr/datalake/optum/optuminsight/p_dlz/ism/prd/p_scripts/deep_processes/lapser_uplift_model/data/uplift_is_scored_rr",currentDate,".csv",sep="")
# MAGIC #h2o.exportFile(uplift_is_scored, path = csvFileName5, force = TRUE)
# MAGIC
# MAGIC ## Evidently AI ==> https://www.youtube.com/watch?v=g0Z2e-IqmmU
# MAGIC ## The code below will be useful since Evidently.AI does not require a join by "person_id" (i.e. if aggregate-level metric comparisons are used for Target-required graphs).
# MAGIC ## "To run some of the evaluations (e.g. Data Drift), you need input features only. In other cases (e.g. Target Drift, Classification Performance), you need Target and/or Prediction."
# MAGIC env <- Sys.getenv('env_var')
# MAGIC account_name <- ifelse(env == 'dev' | env == 'tst', 'saisdcnonprod', 'saisdcprod')
# MAGIC uplift_combo_vars <- uplift_to_score
# MAGIC uplift_combo_vars$predict       <- uplift_is_scored$predict
# MAGIC uplift_combo_vars$"Don't Dstrb" <- uplift_is_scored$"Don't Dstrb"
# MAGIC uplift_combo_vars$"Lost Causes" <- uplift_is_scored$"Lost Causes"
# MAGIC uplift_combo_vars$"Persuadable" <- uplift_is_scored$"Persuadable"
# MAGIC uplift_combo_vars$"Sure Things" <- uplift_is_scored$"Sure Things"
# MAGIC csvFileName5 <-  paste("/dbfs/mnt/isdc_analytics/outbox/lapser_uplift_model/R_Models/uplift_combo_vars_",currentDate,".csv",sep="")
# MAGIC h2o.exportFile(uplift_combo_vars, path = csvFileName5, force = TRUE)
