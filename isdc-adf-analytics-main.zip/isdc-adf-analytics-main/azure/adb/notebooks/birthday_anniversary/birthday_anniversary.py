# Databricks notebook source
import os
env=os.getenv('env_var')
if env=="dev":
    account_name='saisdcnonprod'
elif env=="tst":
    account_name='saisdcnonprod'
else:
    account_name='saisdcprod'

# COMMAND ----------

import shutil

#shutil.copy(f'/dbfs/mnt/{account_name}/isdc/{env}/analytics/inbox/birthday_anniversary/Birthday_Anniversary_Emails.xlsx','./Birthday_Anniversary_Emails.xlsx')
shutil.copy('/dbfs/mnt/isdc_analytics/inbox/birthday_anniversary/Birthday_Anniversary_Emails.xlsx','./Birthday_Anniversary_Emails.xlsx')


# COMMAND ----------

from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization
from pyspark.sql.types import StructType, StructField, StringType
import pandas as pd
import glob
import openpyxl
import re

#decrypt and read private key
def get_private_key():
    private_key_content = dbutils.secrets.get(scope=f"databricks_sc_{env}", key=f"isdc-sf-{env}-p8")
    # get the encryption password from the secret scope
    encryption_password = dbutils.secrets.get(scope=f"databricks_sc_{env}", key=f"isdc-sf-{env}-p8-pwd")
    #load the private key
    p_key = serialization.load_pem_private_key(private_key_content.encode(), password=encryption_password.encode(), backend=default_backend())
    pkb = p_key.private_bytes(encoding=serialization.Encoding.PEM, format=serialization.PrivateFormat.PKCS8, encryption_algorithm=serialization.NoEncryption())
    pkb = pkb.decode("UTF-8")
    pkb = re.sub("-*(BEGIN|END) PRIVATE KEY-*\n", "", pkb).replace("\n", "")
    return pkb
    
#gets input params of type str
def get_job_params(arg,default="",return_type=str):
    try:
        return return_type(dbutils.widgets.get(arg))
    except Exception:
        return return_type(default)

#create snowflake connection dict
def get_read_params():
    read_dict={}
    read_dict['snowflake_url']=get_job_params('snowflake_url')
    read_dict['snowflake_database']=get_job_params('snowflake_database')
    read_dict['snowflake_schema']=get_job_params('snowflake_schema')
    read_dict['snowflake_warehouse']=get_job_params('snowflake_warehouse')
    read_dict['snowflake_role']=get_job_params('snowflake_role')
    read_dict['snowflake_userid']=get_job_params('snowflake_userid')
    return read_dict

#create snowflake connection 
def get_snowflake_options():
    pk = get_private_key()
    read_params=get_read_params()
    options={
    "sfUrl":read_params["snowflake_url"],
    "sfUser":read_params["snowflake_userid"],
    "pem_private_key": pk,
    "sfDatabase":read_params["snowflake_database"],
    "sfSchema":read_params["snowflake_schema"],
    "sfWarehouse":read_params["snowflake_warehouse"],
    "sfRole":read_params["snowflake_role"]
    }
    return options

def write_excel(sheet_name,df):  
    excel_path='./Birthday_Anniversary_Emails.xlsx'
    with pd.ExcelWriter(excel_path,mode='a',if_sheet_exists='replace') as writer:
        df.to_excel(writer,sheet_name=sheet_name,index=False)

def get_dates():
    today = datetime.today().replace(day=1)
    # Calculate the first day of the last month
    first_day_last_month = today - timedelta(days=1)
    first_day_last_month = first_day_last_month.replace(day=1).strftime('%d-%b-%y')
    # Calculate the last day of the current month
    today=datetime.now().strftime('%d-%b-%y')
    # Create a list of tuples representing the rows
    data = [(today, first_day_last_month)]
    return data

def create_datedf():
    data=get_dates()
    schema = StructType([
        StructField("today_date", StringType(), True),
        StructField("report_month", StringType(), True)
    ])
    # Create DataFrame
    datedf = spark.createDataFrame(data, schema)
    datedf=datedf.toPandas()
    write_date_csv=datedf.to_csv('/dbfs/mnt/isdc_analytics/outbox/birthday_anniversary/Birthday_Anniversary_Emails_Date.csv', header=True, index=False, mode='w')
    write_excel('date',datedf)
    
def create_snowflakedf():
    options = get_snowflake_options()
    query="select * from BDR_FFP_DA.BDAY_ANNIV order by CAMPAIGN_EVENT asc,month"
    sf_df=spark.read.format("snowflake").options(**options).option("query", query).load()
    sf_df=sf_df.toPandas()
    write_summary_csv=sf_df.to_csv('/dbfs/mnt/isdc_analytics/outbox/birthday_anniversary/Birthday_Anniversary_Emails_Summary.csv', header=True, index=False, mode='w')
    write_excel('SUMMARY',sf_df)

if __name__=="__main__":
    create_datedf()
    print("Date sheet is updated")
    create_snowflakedf()
    print("Summary sheet is updated")

# COMMAND ----------

import shutil
from datetime import datetime,date

report_date=date.today().strftime("%Y-%m-%d")

shutil.move('./Birthday_Anniversary_Emails.xlsx', '/dbfs/mnt/isdc_analytics/outbox/birthday_anniversary/Birthday_Anniversary_Emails_'+report_date+'.xlsx')
