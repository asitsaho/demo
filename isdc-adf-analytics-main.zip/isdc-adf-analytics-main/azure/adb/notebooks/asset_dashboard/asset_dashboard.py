# Databricks notebook source
from datetime import datetime,date
import pandas as pd
import glob
import openpyxl
import os

report_date=date.today().strftime("%Y-%m-%d")
env=os.getenv('env_var')
if env=="dev":
    account_name='saisdcnonprod'
elif env=="tst":
    account_name='saisdcnonprod'
else:
    account_name='saisdcprod'

source_file_path='/dbfs/mnt/isdc_analytics/inbox/asset_dashboard/ListofDashboards.xlsx'
output_file_path='/dbfs/mnt/isdc_analytics/outbox/asset_dashboard/ListofDashboards_'+report_date+'.csv'
workbook = openpyxl.load_workbook(source_file_path)
workbook_list = workbook.sheetnames
if "InfoAssetCatalog" in workbook_list:
    for excel_file in glob.glob(source_file_path):
        print(excel_file)
        data_xls = pd.read_excel(excel_file, sheet_name="InfoAssetCatalog")
        data_xls1=data_xls.replace('\r|\n', '', regex=True)
        data_xls1.fillna('', inplace=True)
        data_xls1.to_csv(output_file_path,index=False,header=True,mode='w')
    print("CSV file is created successfully")
else:
    print("InfoAssetCatalog is not present in workbook_list. Please check ListofDashboards.xlsx file")
    exit(1)

# COMMAND ----------


