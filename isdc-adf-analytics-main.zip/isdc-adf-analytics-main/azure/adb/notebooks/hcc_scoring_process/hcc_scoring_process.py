# Databricks notebook source
from datetime import datetime,date
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization
from pyspark.sql.functions import lit,ceil,col,when,greatest,monotonically_increasing_id
import re 
import math
import os

env=os.getenv('env_var')
if env=="dev":
    account_name='saisdcnonprod'
elif env=="tst":
    account_name='saisdcnonprod'
else:
    account_name='saisdcprod'

def get_private_key():
    private_key_content = dbutils.secrets.get(scope=f"databricks_sc_{env}", key=f"isdc-sf-{env}-p8")
    # get the encryption password from the secret scope
    encryption_password = dbutils.secrets.get(scope=f"databricks_sc_{env}", key=f"isdc-sf-{env}-p8-pwd")
    #load the private key
    p_key = serialization.load_pem_private_key(private_key_content.encode(), password=encryption_password.encode(), backend=default_backend())
    pkb = p_key.private_bytes(encoding=serialization.Encoding.PEM, format=serialization.PrivateFormat.PKCS8, encryption_algorithm=serialization.NoEncryption())

    pkb = pkb.decode("UTF-8")
    pkb = re.sub("-*(BEGIN|END) PRIVATE KEY-*\n", "", pkb).replace("\n", "")
    return pkb

#gets input params of type str
def get_job_params(arg,default="",return_type=str):
    try:
        return return_type(dbutils.widgets.get(arg))
    except Exception:
        return return_type(default)

#create snowflake connection dict
def get_read_params():
    read_dict={}
    read_dict['snowflake_url']=get_job_params('snowflake_url')
    read_dict['snowflake_database']=get_job_params('snowflake_database')
    read_dict['snowflake_schema']=get_job_params('snowflake_schema')
    read_dict['snowflake_warehouse']=get_job_params('snowflake_warehouse')
    read_dict['snowflake_role']=get_job_params('snowflake_role')
    read_dict['snowflake_userid']=get_job_params('snowflake_userid')
    read_dict['snowflake_table']=get_job_params('snowflake_table')
    return read_dict

#create snowflake connection 
def get_snowflake_options():
    pk = get_private_key()
    read_params=get_read_params()
    options={
    "sfUrl":read_params["snowflake_url"],
    "sfUser":read_params["snowflake_userid"],
    "pem_private_key": pk,
    "sfDatabase":read_params["snowflake_database"],
    "sfSchema":read_params["snowflake_schema"],
    "sfWarehouse":read_params["snowflake_warehouse"],
    "sfRole":read_params["snowflake_role"],
    "sfTable":read_params["snowflake_table"]
    }
    return options

#create spark dataframe
def read_snowflake_query():
    sf_options=get_snowflake_options()
    params=get_read_params()
    try:
        print(f"Read table from Snowflake started {datetime.now().replace(microsecond=0)}")
        table_name=f"{params['snowflake_database']}.{params['snowflake_schema']}.{params['snowflake_table']}"
        df = spark.read.format("snowflake").options(**sf_options).option("dbtable", table_name).load()
        # df_count=df.count()
        return df
    except Exception as e:
        raise e

#create column 'hcc' using column 'cc'
def create_colm_defval_hcc(dataframe):
    for iter in range(1, 205):
        dataframe = dataframe.withColumn(f"HCC{iter}", dataframe[f"CC{iter}"])
    return dataframe

#create column 'd' with deafult value 0
def create_colm_defval_d(dataframe):
    for iter in range(1, 10):
        dataframe = dataframe.withColumn(f"D{iter}", lit(0))
    return dataframe


def feature_eng(dataframe):
    hcc_val_df=create_colm_defval_hcc(dataframe)
    d_val_df=create_colm_defval_d(hcc_val_df)
    df=d_val_df.withColumn('D10P', lit(0))    
    hcc_rules = {
    'HCC8': ['HCC9', 'HCC10', 'HCC11', 'HCC12'],'HCC9': ['HCC10', 'HCC11', 'HCC12'],'HCC10': ['HCC11', 'HCC12'],'HCC11': ['HCC12'],'HCC17': ['HCC18', 'HCC19'],'HCC18': ['HCC19'],
    'HCC27': ['HCC28', 'HCC29', 'HCC80'],'HCC28': ['HCC29'],'HCC46': ['HCC48'],'HCC51': ['HCC52'],'HCC54': ['HCC55', 'HCC56'],'HCC55': ['HCC56'],'HCC57': ['HCC58', 'HCC59', 'HCC60'],'HCC58': ['HCC59', 'HCC60'],'HCC59': ['HCC60'],'HCC70': ['HCC71', 'HCC72', 'HCC103', 'HCC104', 'HCC169'],'HCC71': ['HCC72', 'HCC104', 'HCC169'],'HCC72': ['HCC169'],
    'HCC82': ['HCC83', 'HCC84'],'HCC83': ['HCC84'],'HCC86': ['HCC87', 'HCC88'],'HCC87': ['HCC88'],'HCC99': ['HCC100'],'HCC103': ['HCC104'], 'HCC106': ['HCC107', 'HCC108', 'HCC161', 'HCC189'],'HCC107': ['HCC108'],'HCC110': ['HCC111', 'HCC112'],'HCC111': ['HCC112'],'HCC114': ['HCC115'],'HCC134': ['HCC135', 'HCC136', 'HCC137', 'HCC138'], 'HCC135': ['HCC136', 'HCC137', 'HCC138'],'HCC136': ['HCC137', 'HCC138'],'HCC137': ['HCC138'],'HCC157': ['HCC158', 'HCC159', 'HCC161'],'HCC158': ['HCC159', 'HCC161'],'HCC159': ['HCC161'],
    'HCC166': ['HCC80', 'HCC167']}
    
    for condition_col, affected_cols in hcc_rules.items():
        for affected_col in affected_cols:
            df = df.withColumn(affected_col, when(col(condition_col) == 1, 0).otherwise(col(affected_col)))

    df = df.withColumn('PRESSURE_ULCER', greatest(col('HCC157'), col('HCC158'),col('HCC159'))) \
        .withColumn('CANCER', greatest(col('HCC8'),col('HCC9'),col('HCC10'), col('HCC11'),col('HCC12'))) \
        .withColumn('DIABETES', greatest(col('HCC17'), col('HCC18'),col('HCC19'))) \
        .withColumn('CARD_RESP_FAIL', greatest(col('HCC82'),col('HCC83'),col('HCC84'))) \
        .withColumn('CHF', col('HCC85')) \
        .withColumn('gCopdCF', greatest(col('HCC110'),col('HCC111'),col('HCC112'))) \
        .withColumn('RENAL_V24', greatest(col('HCC134'),col('HCC135'),col('HCC136'),col('HCC137'),col('HCC138'))) \
        .withColumn('gSubstanceUseDisorder_V24', greatest(col('HCC54'),col('HCC55'),col('HCC56'))) \
	    .withColumn('gPsychiatric_V24',greatest(col('HCC57'),col('HCC58'),col('HCC59'),col('HCC60'))) \
        .withColumn('HCC47_gCancer',col('HCC47') * col('CANCER')) \
        .withColumn('DIABETES_CHF',col('DIABETES') * col('CHF')) \
        .withColumn('CHF_gCopdCF',col('CHF') * col('gCopdCF')) \
        .withColumn('HCC85_gRenal_V24',col('HCC85') * col('RENAL_V24')) \
        .withColumn('gCopdCF_CARD_RESP_FAIL',col('gCopdCF') * col('CARD_RESP_FAIL')) \
        .withColumn('HCC85_HCC96',col('HCC85') * col('HCC96')) \
        .withColumn('SEPSIS',col('HCC2')) \
        .withColumn('gSubstanceUseDisorder_gPsych',col('gSubstanceUseDisorder_V24') * col('gPsychiatric_V24')) \
        .withColumn('SEPSIS_PRESSURE_ULCER',col('SEPSIS') * col('PRESSURE_ULCER')) \
        .withColumn('SEPSIS_ARTIF_OPENINGS',col('SEPSIS') * col('HCC188')) \
        .withColumn('ART_OPENINGS_PRESS_ULCER',col('HCC188') * col('PRESSURE_ULCER')) \
        .withColumn('gCopdCF_ASP_SPEC_B_PNEUM',col('gCopdCF') * col('HCC114')) \
        .withColumn('ASP_SPEC_B_PNEUM_PRES_ULC',col('HCC114') * col('PRESSURE_ULCER')) \
        .withColumn('SEPSIS_ASP_SPEC_BACT_PNEUM',col('SEPSIS') * col('HCC114')) \
        .withColumn('SCHIZOPHRENIA_gCopdCF',col('HCC57') * col('gCopdCF')) \
        .withColumn('SCHIZOPHRENIA_CHF',col('HCC57') * col('CHF')) \
        .withColumn('SCHIZOPHRENIA_SEIZURES',col('HCC57') * col('HCC79')) \
        .withColumn('DISABLED_HCC85',col('DISABL') * col('HCC85')) \
        .withColumn('DISABLED_PRESSURE_ULCER',col('DISABL') * col('PRESSURE_ULCER')) \
        .withColumn('DISABLED_HCC161',col('DISABL') * col('HCC161')) \
        .withColumn('DISABLED_HCC39',col('DISABL') * col('HCC39')) \
        .withColumn('DISABLED_HCC77',col('DISABL') * col('HCC77')) \
        .withColumn('DISABLED_HCC6',col('DISABL') * col('HCC6'))

    columns_to_sum = ["HCC1","HCC2","HCC6","HCC8","HCC9","HCC10","HCC11","HCC12","HCC17","HCC18","HCC19","HCC21","HCC22","HCC23","HCC27","HCC28","HCC29","HCC33","HCC34","HCC35","HCC39","HCC40","HCC46","HCC47","HCC48","HCC51","HCC52","HCC54","HCC55","HCC56","HCC57","HCC58","HCC59","HCC60","HCC70","HCC71","HCC72","HCC73","HCC74","HCC75","HCC76","HCC77","HCC78","HCC79","HCC80","HCC82","HCC83","HCC84","HCC85","HCC86","HCC87","HCC88","HCC96","HCC99","HCC100","HCC103","HCC104","HCC106","HCC107","HCC108","HCC110","HCC111","HCC112","HCC114","HCC115","HCC122","HCC124","HCC134","HCC135","HCC136","HCC137","HCC138","HCC157","HCC158","HCC159","HCC161","HCC162","HCC166","HCC167","HCC169","HCC170","HCC173","HCC176","HCC186","HCC188","HCC189"]

    df = df.withColumn("HCC_PYMT", sum(col(c) for c in columns_to_sum))

    for i in range(1, 10):
        df=df.withColumn(f'D{i}',when(col('HCC_PYMT')==i,1).otherwise(col(f'D{i}')))
    
    df=df.withColumn('D10P', when(col('HCC_PYMT') >= 10, 1).otherwise(0))

    pfg_condition = col('PER_NOTIN_DIAG_FG') == 0
    cols_to_update_hcc=[f"HCC{i}" for i in range(1,205)]
    for col_name in cols_to_update_hcc:
        df = df.withColumn(col_name, when(pfg_condition, 0).otherwise(col(col_name)))
    
    cols_to_update=["CANCER","DIABETES","CARD_RESP_FAIL","CHF","gCopdCF","RENAL_V24","SEPSIS","gSubstanceUseDisorder_V24","gPsychiatric_V24","HCC47_gCancer","DIABETES_CHF","CHF_gCopdCF","HCC85_gRenal_V24","gCopdCF_CARD_RESP_FAIL","HCC85_HCC96","gSubstanceUseDisorder_gPsych","PRESSURE_ULCER","SEPSIS_PRESSURE_ULCER","SEPSIS_ARTIF_OPENINGS","ART_OPENINGS_PRESS_ULCER","gCopdCF_ASP_SPEC_B_PNEUM","ASP_SPEC_B_PNEUM_PRES_ULC","SEPSIS_ASP_SPEC_BACT_PNEUM","SCHIZOPHRENIA_gCopdCF","SCHIZOPHRENIA_CHF","SCHIZOPHRENIA_SEIZURES","DISABLED_HCC85","DISABLED_PRESSURE_ULCER","DISABLED_HCC161","DISABLED_HCC39","DISABLED_HCC77","DISABLED_HCC6"]
    for col_name in cols_to_update:
        df = df.withColumn(col_name, when(pfg_condition, 0).otherwise(col(col_name)))
    print(f"Write data to csv has started {datetime.now().replace(microsecond=0)}")

    df.write.format("csv").mode("overwrite").option("header", "true").save(f"dbfs:/mnt/{account_name}/isdc/{env}/analytics/outbox/hcc_scoring/hcc_scoring_{datetime.now().strftime('%Y-%m-%d')}/hcc_other_var_1.csv")


if __name__ == "__main__":
    spark_df=read_snowflake_query()
    feature_eng(spark_df)
    print("process completed")


# COMMAND ----------


