# Databricks notebook source
from datetime import datetime
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization
import re
import pandas as pd
import openpyxl
import shutil

reportdate=datetime.now().strftime("%Y-%m-%d")
import os

env=os.getenv('env_var')
if env=="dev":
    account_name='saisdcnonprod'
elif env=="tst":
    account_name='saisdcnonprod'
else:
    account_name='saisdcprod'
    
def get_private_key():
    private_key_content = dbutils.secrets.get(scope=f"databricks_sc_{env}", key=f"isdc-sf-{env}-p8")
    # get the encryption password from the secret scope
    encryption_password = dbutils.secrets.get(scope=f"databricks_sc_{env}", key=f"isdc-sf-{env}-p8-pwd")
    #load the private key
    p_key = serialization.load_pem_private_key(private_key_content.encode(), password=encryption_password.encode(), backend=default_backend())
    pkb = p_key.private_bytes(encoding=serialization.Encoding.PEM, format=serialization.PrivateFormat.PKCS8, encryption_algorithm=serialization.NoEncryption())
    pkb = pkb.decode("UTF-8")
    pkb = re.sub("-*(BEGIN|END) PRIVATE KEY-*\n", "", pkb).replace("\n", "")
    return pkb
 
#gets input params of type str
def get_job_params(arg,default="",return_type=str):
    try:
        return return_type(dbutils.widgets.get(arg))
    except Exception:
        return return_type(default)
    

#create snowflake connection dict
def get_read_params():
    read_dict={}
    read_dict['snowflake_url']=get_job_params('snowflake_url')
    read_dict['snowflake_database']=get_job_params('snowflake_database')
    read_dict['snowflake_schema']=get_job_params('snowflake_schema')
    read_dict['snowflake_warehouse']=get_job_params('snowflake_warehouse')
    read_dict['snowflake_role']=get_job_params('snowflake_role')
    read_dict['snowflake_userid']=get_job_params('snowflake_userid')
    return read_dict

#create snowflake connection 
def get_snowflake_options():
    pk = get_private_key()
    read_params=get_read_params()
    options={
    "sfUrl":read_params["snowflake_url"],
    "sfUser":read_params["snowflake_userid"],
    "pem_private_key": pk,
    "sfDatabase":read_params["snowflake_database"],
    "sfSchema":read_params["snowflake_schema"],
    "sfWarehouse":read_params["snowflake_warehouse"],
    "sfRole":read_params["snowflake_role"]
    }
    return options



def read_snowflake(query):
    snow_options = get_snowflake_options()
    print("Read from Snowflake")
    df = spark.read.format("snowflake").options(**snow_options).option("query", query).load()
    return df
 
 
if __name__ == "__main__":
    snowflake_table="IPS_IPS_TRANSACTION7"
    query = f"select * from {snowflake_table}"
    df = read_snowflake(query)
    # df.display()   


    pandas_df=df.toPandas()
    df_copy=pandas_df.copy()
    df_copy.fillna('',inplace=True)

    #df_copy.to_excel('/dbfs/mnt/isdc_analytics/IPS_Transaction_'+reportdate+'.xlsx', index = False)
    local_path = '/tmp/IPS_Transaction_' + reportdate + '.xlsx'
    df_copy.to_excel(local_path, index=False)

    dbfs_path = '/dbfs/mnt/isdc_analytics/outbox/ips_transaction/IPS_Transaction_' + reportdate + '.xlsx'
    shutil.move(local_path, dbfs_path)


