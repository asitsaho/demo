# Databricks notebook source
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization
from pyspark.sql.functions import trim,col,regexp_replace, to_date
from datetime import datetime,date
import re 
import math
import os

report_date=date.today().strftime("%Y-%m-%d")
env=os.getenv('env_var')
if env=="dev":
    account_name='saisdcnonprod'
elif env=="tst":
    account_name='saisdcnonprod'
else:
    account_name='saisdcprod'

def get_private_key():
    private_key_content = dbutils.secrets.get(scope=f"databricks_sc_{env}", key=f"isdc-sf-{env}-p8")
    # get the encryption password from the secret scope
    encryption_password = dbutils.secrets.get(scope=f"databricks_sc_{env}", key=f"isdc-sf-{env}-p8-pwd")
    #load the private key
    p_key = serialization.load_pem_private_key(private_key_content.encode(), password=encryption_password.encode(), backend=default_backend())
    pkb = p_key.private_bytes(encoding=serialization.Encoding.PEM, format=serialization.PrivateFormat.PKCS8, encryption_algorithm=serialization.NoEncryption())
    pkb = pkb.decode("UTF-8")
    pkb = re.sub("-*(BEGIN|END) PRIVATE KEY-*\n", "", pkb).replace("\n", "")
    return pkb

#gets input params of type str
def get_job_params(arg,default="",return_type=str):
    try:
        return return_type(dbutils.widgets.get(arg))
    except Exception:
        return return_type(default)

#create snowflake connection dict
def get_read_params():
    read_dict={}
    read_dict['snowflake_url']=get_job_params('snowflake_url')
    read_dict['snowflake_database']=get_job_params('snowflake_database')
    read_dict['snowflake_schema']=get_job_params('snowflake_schema')
    read_dict['snowflake_warehouse']=get_job_params('snowflake_warehouse')
    read_dict['snowflake_role']=get_job_params('snowflake_role')
    read_dict['snowflake_userid']=get_job_params('snowflake_userid')
    read_dict['snowflake_table']=get_job_params('snowflake_table')
    return read_dict

#create snowflake connection 
def get_snowflake_options():
    pk = get_private_key()
    read_params=get_read_params()
    options={
    "sfUrl":read_params["snowflake_url"],
    "sfUser":read_params["snowflake_userid"],
    "pem_private_key": pk,
    "sfDatabase":read_params["snowflake_database"],
    "sfSchema":read_params["snowflake_schema"],
    "sfWarehouse":read_params["snowflake_warehouse"],
    "sfRole":read_params["snowflake_role"],
    "sfTable":read_params["snowflake_table"]
    }
    return options

def get_file_path():
    df=dbutils.fs.ls(f"dbfs:/mnt/{account_name}/isdc/{env}/analytics/inbox/service_calls_dashboard/source_codes/")
    file_path=df[0][0]
    return file_path

def write_to_snowflake(file):
    sf_options=get_snowflake_options()
    params=get_read_params()
    df = spark.read.csv(file, header=True, multiLine=True,escape='"', quote='"',sep=",")
    table_name=f"{params['snowflake_database']}.{params['snowflake_schema']}.{params['snowflake_table']}"
    df.write.format("snowflake").options(**sf_options).option("dbtable",table_name ).mode("overwrite").save()
    print("Data ingested in Snowflake table")

def archive_source_file(file):
    df_archive=dbutils.fs.mv(f"{file}",f"dbfs:/mnt/{account_name}/isdc/{env}/analytics/archive/service_calls_dashboard/all_source_code_tfn_type_{report_date}.csv")
    print("source file archived successfully")

if __name__=="__main__":
   get_file=get_file_path()
   write_to_snowflake(get_file)
   archive_source_file(get_file)
