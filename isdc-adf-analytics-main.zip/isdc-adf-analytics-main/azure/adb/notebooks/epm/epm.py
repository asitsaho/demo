# Databricks notebook source
from datetime import datetime
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization
import re
import os
import shutil
import pandas as pd
from pyspark.sql.functions import lit,input_file_name

env=os.getenv('env_var')
account_name="saisdcnonprod" if env=="dev" or env=="tst" else "saisdcprod"

def get_private_key():
    private_key_content = dbutils.secrets.get(scope=f"databricks_sc_{env}", key=f"isdc-sf-{env}-p8")
    # get the encryption password from the secret scope
    encryption_password = dbutils.secrets.get(scope=f"databricks_sc_{env}", key=f"isdc-sf-{env}-p8-pwd")
    #load the private key
    p_key = serialization.load_pem_private_key(private_key_content.encode(), password=encryption_password.encode(), backend=default_backend())
    pkb = p_key.private_bytes(encoding=serialization.Encoding.PEM, format=serialization.PrivateFormat.PKCS8, encryption_algorithm=serialization.NoEncryption())
    pkb = pkb.decode("UTF-8")
    pkb = re.sub("-*(BEGIN|END) PRIVATE KEY-*\n", "", pkb).replace("\n", "")
    return pkb

#gets input params of type str
def get_job_params(arg,default="",return_type=str):
    try:
        return return_type(dbutils.widgets.get(arg))
    except Exception:
        return return_type(default)


#create snowflake connection dict
def get_read_params():
    read_dict={}
    read_dict['snowflake_url']=get_job_params('snowflake_url')
    read_dict['snowflake_database']=get_job_params('snowflake_database')
    read_dict['snowflake_schema']=get_job_params('snowflake_schema')
    read_dict['snowflake_warehouse']=get_job_params('snowflake_warehouse')
    read_dict['snowflake_role']=get_job_params('snowflake_role')
    read_dict['snowflake_userid']=get_job_params('snowflake_userid')
    return read_dict

#create snowflake connection 
def get_snowflake_options():
    pk = get_private_key()
    read_params=get_read_params()
    options={
    "sfUrl":read_params["snowflake_url"],
    "sfUser":read_params["snowflake_userid"],
    "pem_private_key": pk,
    "sfDatabase":read_params["snowflake_database"],
    "sfSchema":read_params["snowflake_schema"],
    "sfWarehouse":read_params["snowflake_warehouse"],
    "sfRole":read_params["snowflake_role"]
    }
    return options

def read_snowflake(table):
    snow_options = get_snowflake_options()
    print("Read from Snowflake")
    df = spark.read.format("snowflake").options(**snow_options).option("dbtable", table).load()
    return df

if __name__ == "__main__":
    Table1="CHANGE_HISTORY"
    df_emp_tab = read_snowflake("bdr_ffp_da.EPM_DF_EMP")
    df_quename_tab = read_snowflake("bdr_ffp_da_wrk.EPM_DF_QUENAME")
    df_work_queue_action_log_tab = read_snowflake("src_compas.WORK_QUEUE_ACTION_LOG")    
    df_work_queue_type_tab = read_snowflake("src_compas.work_queue_type")   
    df_work_queue_rec_id_tab = read_snowflake("src_compas.WORK_QUEUE_REC_ID")  
    df_application_tab = read_snowflake("src_compas.application")
    df_application_agent_tab = read_snowflake("src_compas.application_agent")
    df_arc_work_queue_action_log_tab = read_snowflake("src_compas.arc_WORK_QUEUE_ACTION_LOG")
    df_arc_work_queue_rec_id_tab = read_snowflake("src_compas.arc_WORK_QUEUE_REC_ID")
    df_timesheet_tab = read_snowflake("src_apex.TIMESHEET")
    df_app_user_tab = read_snowflake("src_apex.app_user")
    df_aux_tab = read_snowflake("src_apex.aux")
    df_time_period_tab = read_snowflake("src_apex.time_period")
    df_business_system_tab = read_snowflake("src_apex.business_system")
    df_department_tab = read_snowflake("src_apex.department")   
    
     
df_emp_tab.createOrReplaceTempView("df_emp")
df_quename_tab.createOrReplaceTempView("df_quename")   
df_work_queue_action_log_tab.createOrReplaceTempView("df_work_queue_action_log")
df_work_queue_type_tab.createOrReplaceTempView("df_work_queue_type")    
df_work_queue_rec_id_tab.createOrReplaceTempView("df_work_queue_rec_id")
df_application_tab.createOrReplaceTempView("df_application")    
df_application_agent_tab.createOrReplaceTempView("df_application_agent")
df_arc_work_queue_action_log_tab.createOrReplaceTempView("df_arc_work_queue_action_log")
df_arc_work_queue_rec_id_tab.createOrReplaceTempView("df_arc_work_queue_rec_id")
df_timesheet_tab.createOrReplaceTempView("df_timesheet")
df_app_user_tab.createOrReplaceTempView("df_app_user")
df_aux_tab.createOrReplaceTempView("df_aux")
df_time_period_tab.createOrReplaceTempView("df_time_period")
df_business_system_tab.createOrReplaceTempView("df_business_system")
df_department_tab.createOrReplaceTempView("df_department")



from  datetime import datetime
import pandas as pd
#current_date = datetime.now().strftime('%y%m')
#folder_path = pd.read_csv(f"/dbfs/mnt/{account_name}/isdc/{env}/analytics/inbox/epm/df_pch_{current_date}.csv")


# pd.read_csv(f"/dbfs/mnt/{account_name}/isdc/{env}/analytics/inbox/epm/df_pch")
# folder_path = "/dbfs/mnt/saisdcnonprod/isdc/dev/analytics/inbox/epm/df_pch"
#folder_path = f"/dbfs/mnt/{account_name}/isdc/{env}/analytics/inbox/epm/df_pch"
folder_path = "/dbfs/mnt/isdc_analytics/inbox/epm/df_pch/"
# archive_path = "/dbfs/mnt/saisdcnonprod/isdc/dev/analytics/inbox/epm/pch_archive"
archive_path = "/dbfs/mnt/isdc_analytics/archive/epm/df_pch/"  #need to create this folder
#archive_path = f"/dbfs/mnt/{account_name}/isdc/{env}/analytics/archive/epm/df_pch"  #need to create this folder

current_date = datetime.now()
current_month = current_date.strftime("%Y%m")
# Define the filter condition
filter_condition = f"FILE_MONTH != '{current_month}'"
# Filter the data to be deleted
snow_options = get_snowflake_options()
df_pch_snowflake = spark.read.format("snowflake").options(**snow_options).option("dbtable", "df_pch").load()

for filename in os.listdir(folder_path):
    if filename.endswith('.csv'):
        if filename.startswith('df_pch_'):
            source = os.path.join(folder_path, filename)
            archive = os.path.join(archive_path, filename)
            df_pch_tmp = pd.read_csv(source)
            df_pch_tmp['FILE_MONTH'] = filename
            # print(filename)
            spark_df_tdf_pch_tmp = spark.createDataFrame(df_pch_tmp)
            FILE_MONTH = spark_df_tdf_pch_tmp.select("FILE_MONTH").distinct().rdd.flatMap(lambda x: x).collect()
            print(FILE_MONTH)
            # Filter the DataFrame based on the extracted values
            spark_df_tdf_pch_tmp_History = df_pch_snowflake.filter(~df_pch_snowflake["FILE_MONTH"].isin(FILE_MONTH))
            spark_df_tdf_pch_tmp = spark_df_tdf_pch_tmp.union(spark_df_tdf_pch_tmp_History)
            snow_options = get_snowflake_options()
            spark_df_tdf_pch_tmp.write.format("snowflake").options(**snow_options).option("dbtable","df_pch").mode("overwrite").save()
            shutil.move(source, archive)
 
df_pch_tab = read_snowflake("bdr_ffp_da_wrk.df_pch")
df_pch_pd = df_pch_tab.toPandas()
df_pch_0 = df_pch_pd.rename(columns={'"Queue Name"':'queue_name', '"Image Number"':'image_number', "ACTION":"string", 'ACTIONDATE':'action_date', 'USERNAME':'user_name', '"Date Completed"':'date_completed'})
df_pch = df_pch_0
#df_pch = df_pch_0[df_pch_0['string'].str.contains('Complete')]
# display(df_pch)
# df_pch_tst = df_pch.toPandas()
snow_options = get_snowflake_options()
spark.createDataFrame(df_pch).write.format("snowflake").options(**snow_options).option("sfSchema", "BDR_FFP_DA_WRK").option("dbtable","df_pch_CHECK").mode("overwrite").save()

#df_tt_2_temp = pd.read_csv(f"/dbfs/mnt/{account_name}/isdc/{env}/analytics/inbox/epm/df_tt_2_temp.csv")
df_tt_2_temp = pd.read_csv("/dbfs/mnt/isdc_analytics/inbox/epm/df_tt_2_temp.csv")
df_list2 = pd.read_csv('/dbfs/mnt/isdc_analytics/inbox/epm/user_name_compas.csv')
lst2=tuple([x[0] for x in df_list2[['User_Name']].values.tolist()])

# display(df_emp_tab)
# resu = spark.sql("select APPL_IMAGE_NUM_CURR from df_application limit 10")

qq = """with base as (
select WQ_Family, tracking_number, appl_image_num_curr, Agent_Ind, work_queue_user_id, type_id_start, type_desc_start, 
       StartDate, min(DateTimeIn) as min_DateTimeIn, sum(nvl(completed, 0)) as completed,
       sum(nvl(pend_finished, 0)) as pend_finished, sum(nvl(suspend_finished, 0)) as suspend_finished,
       sum(nvl(forward_finished, 0)) as forward_finished, sum(nvl(other, 0)) as other
       from 
(select WQ_Family, tracking_number, appl_image_num_curr, Agent_Ind, lower(work_queue_user_id) as work_queue_user_id, type_id_start,
type_desc_start,StartDate, DateTimeIn,
CASE when  action_desc='COMPLETED' then sum(processtime) end as COMPLETED,
CASE when  action_desc='PEND_FINISHED' then sum(processtime) end as PEND_FINISHED,
CASE when  action_desc='Other' then sum(processtime) end as Other,
CASE when  action_desc='SUSPEND_FINISHED' then sum(processtime)  end as SUSPEND_FINISHED,
CASE when  action_desc='FORWARD_FINISHED' then sum(processtime)  end as FORWARD_FINISHED  	  
from 
(
select 'ENROLLMENT SUB-FAMILY QUEUE' as WQ_Family
,wqal.tracking_number
,a.appl_image_num_curr
,case when aag_2.agent_id is null then 'Non Agent'
when aag_2.agent_id='EHEA111' THEN 'E-Alliance'
WHEN aag_2.agent_id='ETQ1111' THEN 'E-Alliance'
WHEN aag_2.agent_id='EXT1111' THEN 'E-Alliance'
WHEN aag_2.agent_id='GHI1111' THEN 'E-Alliance'
WHEN aag_2.agent_id='2140505' THEN 'E-Alliance'
WHEN aag_2.agent_id='INS1111' THEN 'E-Alliance'
WHEN aag_2.agent_id='2099352' THEN 'E-Alliance'
WHEN aag_2.agent_id='2097836' THEN 'E-Alliance'
WHEN aag_2.agent_id='SQS1111' THEN 'E-Alliance'
WHEN aag_2.agent_id='SQS2222' THEN 'E-Alliance'
WHEN aag_2.agent_id='BG0000' THEN 'E-Alliance'
WHEN aag_2.agent_id='2008052' THEN 'E-Alliance'
WHEN aag_2.agent_id='2161623' THEN 'E-Alliance'
WHEN aag_2.agent_id='SPR1111' THEN 'E-Alliance'
WHEN aag_2.agent_id='2109060' THEN 'E-Alliance'
WHEN aag_2.agent_id='TIB1111' THEN 'E-Alliance'
WHEN aag_2.agent_id='2034019' THEN 'E-Alliance'
WHEN aag_2.agent_id='2118752' THEN 'E-Alliance'
WHEN aag_2.agent_id='EHC11111' THEN 'E-Alliance'
WHEN aag_2.agent_id='EHC1111' THEN 'E-Alliance'
else 'Agent' end as Agent_Ind
,lower(wqal.work_queue_user_id) as work_queue_user_id
,to_date(wqal.start_time) as StartDate
,min(wqal.start_time) as DateTimeIn
 ,wqt_1.type_id type_id_start
,wqt_1.type_desc as type_desc_start
,CASE WQAL.WORK_QUEUE_DISPOSITION_ID WHEN 5 THEN 'COMPLETED'
       WHEN 7 THEN 'PEND_FINISHED'
                                      WHEN 8 THEN 'SUSPEND_FINISHED'
                                      WHEN 6 THEN 'FORWARD_FINISHED'
                                      ELSE 'Other'
    end as Action_Desc
 ,sum(extract(minute from (cast(wqal.end_time as timestamp) - cast(wqal.start_time as timestamp))) 
   + round(extract(Second from (cast(wqal.end_time as timestamp) - cast(wqal.start_time as timestamp)))/60, 2) 
    ) as ProcessTime
from df_WORK_QUEUE_ACTION_LOG wqal
left join df_work_queue_type wqt_1 on wqt_1.type_id = wqal.type_id_start
left join df_work_queue_type wqt_2 on wqt_2.type_id = wqal.type_id_end
left join df_work_queue_rec_id wqri on wqri.tracking_number=wqal.Tracking_Number 
left join df_application a on a.application_id = wqri.identifier_value
left join df_application_agent aag_2 on aag_2.application_id = a.application_id and aag_2.agent_type_id =2
where wqal.type_id_start in (2001, 2002, 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 
                            2024, 2025, 2026, 2027, 2028, 2030, 2032, 2033, 2034, 2036, 2037, 2038, 2041, 2044, 2045, 2046, 2056)
and wqal.end_time is not null
and wqal.start_time >= date'2020-01-01'  
--and extract(MONTH from wqal.start_time)>=extract(month from current_date())-5
and lower(wqal.work_queue_user_id) in {}
                               
group by wqal.tracking_number,a.appl_image_num_curr, aag_2.agent_id,wqal.work_queue_user_id
,to_date(wqal.start_time),wqt_1.type_id,wqt_1.type_desc,WQAL.WORK_QUEUE_DISPOSITION_ID
                                      
union
 select 'ENROLLMENT SUB-FAMILY QUEUE' as WQ_Family
,wqal.tracking_number,a.appl_image_num_curr
,case when aag_2.agent_id is null then 'Non Agent'
 when aag_2.agent_id='EHEA111' THEN 'E-Alliance'
 WHEN aag_2.agent_id='ETQ1111' THEN 'E-Alliance'
 WHEN aag_2.agent_id='EXT1111' THEN 'E-Alliance'
 WHEN aag_2.agent_id='GHI1111' THEN 'E-Alliance'
 WHEN aag_2.agent_id='2140505' THEN 'E-Alliance'
 WHEN aag_2.agent_id='INS1111' THEN 'E-Alliance'
 WHEN aag_2.agent_id='2099352' THEN 'E-Alliance'
 WHEN aag_2.agent_id='2097836' THEN 'E-Alliance'
 WHEN aag_2.agent_id='SQS1111' THEN 'E-Alliance'
 WHEN aag_2.agent_id='SQS2222' THEN 'E-Alliance'
 WHEN aag_2.agent_id='BG0000' THEN 'E-Alliance'
 WHEN aag_2.agent_id='2008052' THEN 'E-Alliance'
 WHEN aag_2.agent_id='2161623' THEN 'E-Alliance'
 WHEN aag_2.agent_id='SPR1111' THEN 'E-Alliance'
 WHEN aag_2.agent_id='2109060' THEN 'E-Alliance'
 WHEN aag_2.agent_id='TIB1111' THEN 'E-Alliance'
 WHEN aag_2.agent_id='2034019' THEN 'E-Alliance'
 WHEN aag_2.agent_id='2118752' THEN 'E-Alliance'
 WHEN aag_2.agent_id='EHC11111' THEN 'E-Alliance'
 WHEN aag_2.agent_id='EHC1111' THEN 'E-Alliance'
 else 'Agent' end as Agent_Ind ,wqal.work_queue_user_id,to_date(wqal.start_time) as StartDate
 ,min(wqal.start_time) as DateTimeIn ,wqt_1.type_id type_id_start ,wqt_1.type_desc as type_desc_start
,CASE WQAL.WORK_QUEUE_DISPOSITION_ID WHEN 5 THEN 'COMPLETED'
 WHEN 7 THEN 'PEND_FINISHED'
WHEN 8 THEN 'SUSPEND_FINISHED'
 WHEN 6 THEN 'FORWARD_FINISHED'
 ELSE 'Other'
end as Action_Desc
 ,sum(extract(minute from (cast(wqal.end_time as timestamp) - cast(wqal.start_time as timestamp))) 
+ round(extract(Second from (cast(wqal.end_time as timestamp) - cast(wqal.start_time as timestamp)))/60, 2) 
) as ProcessTime
from df_arc_WORK_QUEUE_ACTION_LOG wqal
left join df_work_queue_type wqt_1 on wqt_1.type_id = wqal.type_id_start
left join df_work_queue_type wqt_2 on wqt_2.type_id = wqal.type_id_end
left join df_arc_work_queue_rec_id wqri on wqri.tracking_number=wqal.Tracking_Number 
left join df_application a on a.application_id = wqri.identifier_value
left join df_application_agent aag_2 on aag_2.application_id = a.application_id and aag_2.agent_type_id =2
where wqal.type_id_start in (2001, 2002, 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 
                       2024, 2025, 2026, 2027, 2028, 2030, 2032, 2033, 2034, 2036, 2037, 2038, 2041, 2044, 2045, 2046, 2056)
and wqal.end_time is not null
and wqal.start_time>=date '2018-12-30' 
and extract(year from wqal.start_time)>=extract(year from current_date())-2
and lower(wqal.work_queue_user_id) in {}

--and wqal.tracking_number =56749271
group by wqal.tracking_number,a.appl_image_num_curr,aag_2.agent_id,wqal.work_queue_user_id ,
to_date(wqal.start_time),wqt_1.type_id,wqt_1.type_desc,WQAL.WORK_QUEUE_DISPOSITION_ID 
)basebl
group by WQ_Family, tracking_number, appl_image_num_curr, Agent_Ind, work_queue_user_id, type_id_start,
type_desc_start,StartDate, DateTimeIn	, action_desc
)b
group by WQ_Family, tracking_number, appl_image_num_curr, Agent_Ind, work_queue_user_id, type_id_start, type_desc_start, 
       StartDate

)
select bb2.WQ_Family WQ_Family, bb2.tracking_number tracking_number, bb2.appl_image_num_curr appl_image_num_curr, bb2.Agent_Ind Agent_Ind, bb2.work_queue_user_id work_queue_user_id, bb2.StartDate StartDate, bb2.min_DateTimeIn min_DateTimeIn, b2.type_desc_start type_desc_start, bb2.completed completed, bb2.pend_finished pend_finished, 
       bb2.suspend_finished suspend_finished, bb2.forward_finished forward_finished, bb2.other other
from base b2
right join
(select b1.WQ_Family, b1.tracking_number, b1.appl_image_num_curr, b1.Agent_Ind, b1.work_queue_user_id, b1.StartDate, min(b1.min_DateTimeIn) as min_DateTimeIn, sum(b1.completed) as completed, sum(b1.pend_finished) as pend_finished, 
       sum(b1.suspend_finished) as suspend_finished, sum(b1.forward_finished) as forward_finished, sum(b1.other) as other
 from base b1
 group by b1.WQ_Family, b1.tracking_number, b1.appl_image_num_curr, b1.Agent_Ind, b1.work_queue_user_id, b1.StartDate
 ) bb2 on b2.tracking_number = bb2.tracking_number and b2.work_queue_user_id = bb2.work_queue_user_id and b2.min_DateTimeIn = bb2.min_DateTimeIn 
where bb2.completed + bb2.pend_finished + bb2.suspend_finished + bb2.forward_finished >0""".format(lst2,lst2)

df_compas = spark.sql(qq)

df_list3 = pd.read_csv('/dbfs/mnt/isdc_analytics/inbox/epm/user_name_compas_helper.csv')
lst1=tuple([x[0] for x in df_list3[['User_Name']].values.tolist()])

qq2 = """with base as (
select WQ_Family, tracking_number, appl_image_num_curr, Agent_Ind, lower(work_queue_user_id) as work_queue_user_id, type_id_start, type_desc_start, 
       StartDate, min(DateTimeIn) as min_DateTimeIn, sum(nvl(completed, 0)) as completed,
       sum(nvl(pend_finished, 0)) as pend_finished, sum(nvl(suspend_finished, 0)) as suspend_finished,
       sum(nvl(forward_finished, 0)) as forward_finished, sum(nvl(other, 0)) as other
from 
( select WQ_Family, tracking_number, appl_image_num_curr, Agent_Ind, lower(work_queue_user_id) as work_queue_user_id, type_id_start,
type_desc_start,StartDate, DateTimeIn,
CASE when  action_desc='COMPLETED' then sum(processtime) end as COMPLETED,
CASE when  action_desc='PEND_FINISHED' then sum(processtime) end as PEND_FINISHED,
CASE when  action_desc='Other' then sum(processtime) end as Other,
CASE when  action_desc='SUSPEND_FINISHED' then sum(processtime)  end as SUSPEND_FINISHED,
CASE when  action_desc='FORWARD_FINISHED' then sum(processtime)  end as FORWARD_FINISHED  	  
from  
 (                                 
 select 'ENROLLMENT SUB-FAMILY QUEUE' as WQ_Family
      ,wqal.tracking_number
      ,a.appl_image_num_curr
      ,case when aag_2.agent_id is null then 'Non Agent'
            when aag_2.agent_id='EHEA111' THEN 'E-Alliance'
            WHEN aag_2.agent_id='ETQ1111' THEN 'E-Alliance'
            WHEN aag_2.agent_id='EXT1111' THEN 'E-Alliance'
            WHEN aag_2.agent_id='GHI1111' THEN 'E-Alliance'
            WHEN aag_2.agent_id='2140505' THEN 'E-Alliance'
            WHEN aag_2.agent_id='INS1111' THEN 'E-Alliance'
            WHEN aag_2.agent_id='2099352' THEN 'E-Alliance'
            WHEN aag_2.agent_id='2097836' THEN 'E-Alliance'
            WHEN aag_2.agent_id='SQS1111' THEN 'E-Alliance'
            WHEN aag_2.agent_id='SQS2222' THEN 'E-Alliance'
            WHEN aag_2.agent_id='BG0000' THEN 'E-Alliance'
            WHEN aag_2.agent_id='2008052' THEN 'E-Alliance'
            WHEN aag_2.agent_id='2161623' THEN 'E-Alliance'
            WHEN aag_2.agent_id='SPR1111' THEN 'E-Alliance'
            WHEN aag_2.agent_id='2109060' THEN 'E-Alliance'
            WHEN aag_2.agent_id='TIB1111' THEN 'E-Alliance'
            WHEN aag_2.agent_id='2034019' THEN 'E-Alliance'
            WHEN aag_2.agent_id='2118752' THEN 'E-Alliance'
            WHEN aag_2.agent_id='EHC11111' THEN 'E-Alliance'
            WHEN aag_2.agent_id='EHC1111' THEN 'E-Alliance'
       else 'Agent' end as Agent_Ind      
      ,wqal.work_queue_user_id
      ,to_date(wqal.start_time) as StartDate
      ,min(wqal.start_time) as DateTimeIn
      ,wqt_1.type_id type_id_start
      ,wqt_1.type_desc as type_desc_start
      ,CASE WQAL.WORK_QUEUE_DISPOSITION_ID WHEN 5 THEN 'COMPLETED'
                                           WHEN 7 THEN 'PEND_FINISHED'
                                           WHEN 8 THEN 'SUSPEND_FINISHED'
                                           WHEN 6 THEN 'FORWARD_FINISHED'
                                           ELSE 'Other'
       end as Action_Desc
      ,sum(extract(minute from (cast(wqal.end_time as timestamp) - cast(wqal.start_time as timestamp))) 
           + round(extract(Second from (cast(wqal.end_time as timestamp) - cast(wqal.start_time as timestamp)))/60, 2) 
           ) as ProcessTime
from df_WORK_QUEUE_ACTION_LOG wqal
left join df_work_queue_type wqt_1 on wqt_1.type_id = wqal.type_id_start
left join df_work_queue_type wqt_2 on wqt_2.type_id = wqal.type_id_end
left join df_WORK_QUEUE_REC_ID wqri on wqri.tracking_number=wqal.Tracking_Number 
left join df_application a on a.application_id = wqri.identifier_value
left join df_application_agent aag_2 on aag_2.application_id = a.application_id and aag_2.agent_type_id =2
where wqal.type_id_start in (2001, 2002, 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 
                             2024, 2025, 2026, 2027, 2028, 2030, 2032, 2033, 2034, 2036, 2037, 2038, 2041, 2044, 2045, 2046, 2056)
and wqal.end_time is not null
and wqal.start_time >= date '2020-01-01' 
and extract(MONTH from wqal.start_time)>=extract(month from current_date())-5
and lower(wqal.work_queue_user_id) in {}
group by wqal.tracking_number,a.appl_image_num_curr, aag_2.agent_id,wqal.work_queue_user_id,to_date(wqal.start_time)
        ,wqt_1.type_id,wqt_1.type_desc,WQAL.WORK_QUEUE_DISPOSITION_ID 
union
select 'ENROLLMENT SUB-FAMILY QUEUE' as WQ_Family
      ,wqal.tracking_number
      ,a.appl_image_num_curr
      ,case when aag_2.agent_id is null then 'Non Agent'
            when aag_2.agent_id='EHEA111' THEN 'E-Alliance'
            WHEN aag_2.agent_id='ETQ1111' THEN 'E-Alliance'
            WHEN aag_2.agent_id='EXT1111' THEN 'E-Alliance'
            WHEN aag_2.agent_id='GHI1111' THEN 'E-Alliance'
            WHEN aag_2.agent_id='2140505' THEN 'E-Alliance'
            WHEN aag_2.agent_id='INS1111' THEN 'E-Alliance'
            WHEN aag_2.agent_id='2099352' THEN 'E-Alliance'
            WHEN aag_2.agent_id='2097836' THEN 'E-Alliance'
            WHEN aag_2.agent_id='SQS1111' THEN 'E-Alliance'
            WHEN aag_2.agent_id='SQS2222' THEN 'E-Alliance'
            WHEN aag_2.agent_id='BG0000' THEN 'E-Alliance'
            WHEN aag_2.agent_id='2008052' THEN 'E-Alliance'
            WHEN aag_2.agent_id='2161623' THEN 'E-Alliance'
            WHEN aag_2.agent_id='SPR1111' THEN 'E-Alliance'
            WHEN aag_2.agent_id='2109060' THEN 'E-Alliance'
            WHEN aag_2.agent_id='TIB1111' THEN 'E-Alliance'
            WHEN aag_2.agent_id='2034019' THEN 'E-Alliance'
            WHEN aag_2.agent_id='2118752' THEN 'E-Alliance'
            WHEN aag_2.agent_id='EHC11111' THEN 'E-Alliance'
            WHEN aag_2.agent_id='EHC1111' THEN 'E-Alliance'
       else 'Agent' end as Agent_Ind      
      ,wqal.work_queue_user_id
      ,to_date(wqal.start_time) as StartDate
      ,min(wqal.start_time) as DateTimeIn
      ,wqt_1.type_id type_id_start
      ,wqt_1.type_desc as type_desc_start
      ,CASE WQAL.WORK_QUEUE_DISPOSITION_ID WHEN 5 THEN 'COMPLETED'
                                           WHEN 7 THEN 'PEND_FINISHED'
                                           WHEN 8 THEN 'SUSPEND_FINISHED'
                                           WHEN 6 THEN 'FORWARD_FINISHED'
                                           ELSE 'Other'
       end as Action_Desc
      ,sum(extract(minute from (cast(wqal.end_time as timestamp) - cast(wqal.start_time as timestamp))) 
           + round(extract(Second from (cast(wqal.end_time as timestamp) - cast(wqal.start_time as timestamp)))/60, 2) 
           ) as ProcessTime
from df_arc_WORK_QUEUE_ACTION_LOG wqal
left join df_work_queue_type wqt_1 on wqt_1.type_id = wqal.type_id_start
left join df_work_queue_type wqt_2 on wqt_2.type_id = wqal.type_id_end
left join df_arc_WORK_QUEUE_REC_ID wqri on wqri.tracking_number=wqal.Tracking_Number 
left join df_application a on a.application_id = wqri.identifier_value
left join df_application_agent aag_2 on aag_2.application_id = a.application_id and aag_2.agent_type_id =2
where wqal.type_id_start in (2001, 2002, 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 
                             2024, 2025, 2026, 2027, 2028, 2030, 2032, 2033, 2034, 2036, 2037, 2038, 2041, 2044, 2045, 2046, 2056)
and wqal.end_time is not null
and wqal.start_time >= date '2018-12-30' 
and extract(year from wqal.start_time)>=extract(year from current_date())-2
and lower(wqal.work_queue_user_id) in {}
group by wqal.tracking_number,a.appl_image_num_curr,aag_2.agent_id ,wqal.work_queue_user_id
        ,to_date(wqal.start_time),wqt_1.type_id ,wqt_1.type_desc ,WQAL.WORK_QUEUE_DISPOSITION_ID
) basetbl

group by WQ_Family, tracking_number, appl_image_num_curr, Agent_Ind,work_queue_user_id, type_id_start,
type_desc_start,StartDate, DateTimeIn,action_desc
)b
      
      group by WQ_Family, tracking_number, appl_image_num_curr, Agent_Ind, work_queue_user_id, type_id_start, type_desc_start, StartDate
      --having nvl(sum(completed), 0) + nvl(sum(pend_finished), 0) + nvl(sum(suspend_finished), 0) + nvl(sum(forward_finished), 0)>0
)
select bb2.WQ_Family WQ_Family, bb2.tracking_number tracking_number, bb2.appl_image_num_curr appl_image_num_curr,  bb2.Agent_Ind Agent_Ind, bb2.work_queue_user_id work_queue_user_id, 
bb2.StartDate StartDate, bb2.min_DateTimeIn min_DateTimeIn, b2.type_desc_start type_desc_start, bb2.completed completed, bb2.pend_finished pend_finished, 
       bb2.suspend_finished suspend_finished, bb2.forward_finished forward_finished, bb2.other other
from base b2
right join
(select b1.WQ_Family, b1.tracking_number, b1.appl_image_num_curr, b1.Agent_Ind, b1.work_queue_user_id, b1.StartDate, min(b1.min_DateTimeIn) as min_DateTimeIn, sum(b1.completed) as completed, sum(b1.pend_finished) as pend_finished, 
       sum(b1.suspend_finished) as suspend_finished, sum(b1.forward_finished) as forward_finished, sum(b1.other) as other
 from base b1
 group by b1.WQ_Family, b1.tracking_number, b1.appl_image_num_curr, b1.Agent_Ind, b1.work_queue_user_id, b1.StartDate
 ) bb2 on b2.tracking_number = bb2.tracking_number and b2.work_queue_user_id = bb2.work_queue_user_id and b2.min_DateTimeIn = bb2.min_DateTimeIn 
where bb2.completed + bb2.pend_finished + bb2.suspend_finished + bb2.forward_finished >0  """.format(lst1,lst1)

sql_compas_helper = spark.sql(qq2)
snow_options = get_snowflake_options()
sql_compas_helper.write.format("snowflake").options(**snow_options).option("sfSchema", "BDR_FFP_DA_WRK").option("dbtable","sql_compas_helper").mode("overwrite").save()


# COMMAND ----------

import os

env=os.getenv('env_var')
account_name="saisdcnonprod" if env=="dev" or env=="tst" else "saisdcprod"

sql_compas_helper = sql_compas_helper.toPandas()
display(len(sql_compas_helper))



sql_compas_helper1 = pd.merge(sql_compas_helper, df_list3, left_on = 'work_queue_user_id', right_on = 'User_Name', how='left')
#df_list1 = pd.read_csv(f'/dbfs/mnt/{account_name}/isdc/{env}/analytics/inbox/epm/user_name_apex.csv')
df_list1 = pd.read_csv('/dbfs/mnt/isdc_analytics/inbox/epm/user_name_apex.csv')
lst=tuple([x[0] for x in df_list1[['User_Name']].values.tolist()])
# import sqlite3
# display(lst)
lst_df = spark.createDataFrame([(i,) for i in lst], ["User_Name"])
snow_options = get_snowflake_options()
lst_df.write.format("snowflake").options(**snow_options).option("sfSchema", "BDR_FFP_DA_WRK").option("dbtable","lst").mode("overwrite").save()


# COMMAND ----------


qq3 = """ select created_by,
time_in,time_out ,system, aux_code
from (select distinct lower(t.SRC_REC_CREATED_BY) as created_by,
time_in,time_out ,
bs.system, a.aux_code
from df_TIMESHEET t
left join df_app_user u on t.id = u.id
left join df_aux a on t.aux_id = a.id
left join df_time_period tp on t.time_period_id = tp.id
left join df_business_system bs on bs.id = a.business_system_id
left join df_department d on d.id = u.DEPARTMENT_ID
where lower(t.SRC_REC_CREATED_BY)in {}
and t.time_in >=  date '2019-09-11' )a
 """.format(lst)
 
df_tt_1 = spark.sql(qq3)

# COMMAND ----------


snow_options = get_snowflake_options()
df_emp_tab.write.format("snowflake").options(**snow_options).option("sfSchema", "BDR_FFP_DA_WRK").option("dbtable","df_emp_tab").mode("overwrite").save()
df_emp_tab_pd = df_emp_tab.toPandas() #df_emp_tab is a spark dataframe
display(len(df_emp_tab_pd))

df_tt_2 = pd.merge(df_tt_2_temp, df_emp_tab_pd, left_on = 'created_by', right_on = 'USER_ID', how='left')
display(len(df_tt_2_temp))
display(len(df_tt_2))

df_tt_2_temp_spark = spark.createDataFrame(df_tt_2_temp)
df_tt_2_spark = spark.createDataFrame(df_tt_2)

df_tt_2_temp_spark.write.format("snowflake").options(**snow_options).option("sfSchema", "BDR_FFP_DA_WRK").option("dbtable","df_tt_2_temp").mode("overwrite").save()

df_tt_2_spark.write.format("snowflake").options(**snow_options).option("sfSchema", "BDR_FFP_DA_WRK").option("dbtable","df_tt_2").mode("overwrite").save()

# COMMAND ----------



df_tt_2['time_out'] = pd.to_datetime(df_tt_2['time_out'])
df_tt_2['time_in'] = pd.to_datetime(df_tt_2['time_in'])
df_tt_2.rename(columns={'system_1':'system'},inplace=True)

df_tt_2.loc[df_tt_2['TIME_ZONE']=='EST', 'DateTimeInNew']=df_tt_2['time_in']+pd.Timedelta(hours=-1)
df_tt_2.loc[df_tt_2['TIME_ZONE']=='CT', 'DateTimeInNew']=df_tt_2['time_in']+pd.Timedelta(hours=0)
df_tt_2.loc[df_tt_2['TIME_ZONE']=='EST', 'DateTimeOutNew']=df_tt_2['time_out']+pd.Timedelta(hours=-1)
df_tt_2.loc[df_tt_2['TIME_ZONE']=='CT', 'DateTimeOutNew']=df_tt_2['time_out']+pd.Timedelta(hours=0)
spark_df_tt_2 = spark.createDataFrame(df_tt_2)
snow_options = get_snowflake_options()
spark_df_tt_2.write.format("snowflake").options(**snow_options).option("sfSchema", "BDR_FFP_DA_WRK").option("dbtable","df_tt_2_222").mode("overwrite").save()

# display(len(df_tt_2))

# COMMAND ----------


quename = df_quename_tab.toPandas()
a_c = quename[['AUXCODE_1', 'AUXCODE_2']].drop_duplicates(subset=None, keep='first', inplace=False)
a_c['AUXCODE_1'] = a_c['AUXCODE_2'].str.lower()
df_tt_2['aux_code'] = df_tt_2['aux_code'].str.lower()
df_tt_2c = pd.merge(df_tt_2, a_c, left_on = 'aux_code', right_on = 'AUXCODE_1', how='right')

df_tt_2c_spark = spark.createDataFrame(df_tt_2c)
snow_options = get_snowflake_options()
df_tt_2c_spark.write.format("snowflake").options(**snow_options).option("sfSchema", "BDR_FFP_DA_WRK").option("dbtable","df_tt_2c").mode("overwrite").save()

# display(len(df_tt_2c))

df_tt_2d = df_tt_2c[['created_by', 'DateTimeInNew', 'DateTimeOutNew', 'system', 'AUXCODE_2']]
df_tt_2d = df_tt_2d.rename(columns={"DateTimeInNew": "time_in", "DateTimeOutNew": "time_out", "AUXCODE_2":"aux_code"})
df_tt_1 = df_tt_1.toPandas()
df_tt = pd.concat([df_tt_1, df_tt_2d], sort=False)

df_tt_spark = spark.createDataFrame(df_tt)
df_tt_spark.write.format("snowflake").options(**snow_options).option("sfSchema", "BDR_FFP_DA_WRK").option("dbtable","df_tt").mode("overwrite").save()

# display(len(df_tt))

# COMMAND ----------


#spark_df_tdf_pch_tmp = spark.createDataFrame(df_pch_tmp)
#snow_options = get_snowflake_options()
#spark_df_tdf_pch_tmp.write.format("snowflake").options(**snow_options).option("dbtable","df_pch").mode("overwrite").save()
#df_pch = df_pch_tmp[df_pch_tmp['Action'].str.contains('Complete')]
# df_pch

# COMMAND ----------


df_tt['date_in'] = pd.to_datetime(df_tt['time_in']).dt.date
df_compas = df_compas.toPandas()
df_compas_2 = pd.merge(df_compas, df_emp_tab_pd[['USER_ID', 'PCH_NAME', 'EMP_TYPE', 'COMPAS_NAME']], left_on =['work_queue_user_id'], right_on=['USER_ID'], how='left')

snow_options = get_snowflake_options()

# display(len(df_compas_2))
df_compas_2['StartDate'] = pd.to_datetime(df_compas_2['StartDate']).dt.date

df_compas_2_spark = spark.createDataFrame(df_compas_2)
df_compas_2_spark.write.format("snowflake").options(**snow_options).option("sfSchema", "BDR_FFP_DA_WRK").option("dbtable","df_compas_2").mode("overwrite").save()

df_compas_3 = pd.merge(df_compas_2, df_tt[df_tt['system'] =='COMPAS'], left_on=['work_queue_user_id', 'StartDate'], right_on=['created_by', 'date_in'], how='left')

df_compas_3_spark = spark.createDataFrame(df_compas_3)
df_compas_3_spark.write.format("snowflake").options(**snow_options).option("sfSchema", "BDR_FFP_DA_WRK").option("dbtable","df_compas_3").mode("overwrite").save()

# display(len(df_compas_3))

df_compas_4 = df_compas_3[(df_compas_3['min_DateTimeIn']<=df_compas_3['time_out']) & (df_compas_3['min_DateTimeIn']>=df_compas_3['time_in'])]

df_compas_4_spark = spark.createDataFrame(df_compas_4)
df_compas_4_spark.write.format("snowflake").options(**snow_options).option("sfSchema", "BDR_FFP_DA_WRK").option("dbtable","df_compas_4").mode("overwrite").save()

# display(len(df_compas_4))

df_compas_4 = df_compas_4.assign(**{'SOURCE':'COMPAS'})
df_compas_4_spark2 = spark.createDataFrame(df_compas_4)
df_compas_4_spark2.write.format("snowflake").options(**snow_options).option("sfSchema", "BDR_FFP_DA_WRK").option("dbtable","df_compas_4_22").mode("overwrite").save()

# display(len(df_compas_4))

# COMMAND ----------


df_compas_4 = df_compas_4.rename(columns={"tracking_number":"TN", "appl_image_num_curr":"IMAGENUM", "agent_ind":"Agent_Ind", "type_desc_start":"QUEUENAME", "work_queue_user_id":"UID", "COMPAS_NAME":"UName", "StartDate":"DATE_COMPLETED", "aux_code":"AUXCODE", "min_DateTimeIn":"Min_COMPAS_DT_In", "time_in":"TT_DT_IN", "time_out":"TT_DT_OUT", 
                                         "completed":"COMPLETED_TIME", "pend_finished":"PEND_TIME", "suspend_finished":"SUSP_TIME", "forward_finished":"FORWARD_TIME", "other":"OTHER_TIME"})


# display(len(df_compas_4))


# COMMAND ----------



df_compas_f = df_compas_4[['SOURCE', 'TN', 'IMAGENUM', 'Agent_Ind', 'QUEUENAME', 'UID', 'UName', 'DATE_COMPLETED', 'AUXCODE','Min_COMPAS_DT_In','TT_DT_IN','TT_DT_OUT','COMPLETED_TIME','PEND_TIME','SUSP_TIME','FORWARD_TIME', 'OTHER_TIME', 'USER_ID', 'EMP_TYPE']]


# COMMAND ----------


df_pch = df_pch.rename(columns={"Queue Name":"queue_name", "Image Number":"image_number", "Action":"string", "ActionDate":"action_date", "UserName":"user_name", "Date Completed":"date_completed"})

df_pch_2 = pd.merge(df_pch, df_emp_tab_pd[['USER_ID', 'PCH_NAME', 'EMP_TYPE', 'COMPAS_NAME']], left_on =['user_name'], right_on=['PCH_NAME'], how='right')

df_pch_2_spark = spark.createDataFrame(df_pch_2)
snow_options = get_snowflake_options()
df_pch_2_spark.write.format("snowflake").options(**snow_options).option("sfSchema", "BDR_FFP_DA_WRK").option("dbtable","df_pch_2").mode("overwrite").save()


# display(len(df_pch_2))

df_pch_2['ActionDate_d'] = pd.to_datetime(df_pch_2['action_date']).dt.date
df_pch_2['ActionDate_dt'] = pd.to_datetime(df_pch_2['action_date'])


# COMMAND ----------


# Convert columns to datetime
df_pch_2['ActionDate_d'] = pd.to_datetime(df_pch_2['ActionDate_d'])
df_tt['date_in'] = pd.to_datetime(df_tt['date_in'])

df_pch_3 = pd.merge(df_pch_2, df_tt[df_tt['system'] =='COMPAS'], left_on=['USER_ID', 'ActionDate_d'], right_on=['created_by', 'date_in'], how='left')

df_pch_3_spark = spark.createDataFrame(df_pch_3)
snow_options = get_snowflake_options()
df_pch_3_spark.write.format("snowflake").options(**snow_options).option("sfSchema", "BDR_FFP_DA_WRK").option("dbtable","df_pch_3").mode("overwrite").save()

# display(len(df_pch_3))

is_compas_tm = (df_pch_3['ActionDate_dt']<=df_pch_3['time_out']) & (df_pch_3['ActionDate_dt']>=df_pch_3['time_in'])
# is_compas_tm_spark = spark.createDataFrame(is_compas_tm)
# is_compas_tm_spark.write.format("snowflake").options(**snow_options).option("sfSchema", "BDR_FFP_DA_WRK").option("dbtable","is_compas_tm").mode("overwrite").save()


# display(len(is_compas_tm))

# COMMAND ----------



df_pch_4 = df_pch_3[-is_compas_tm]

df_pch_4_spark = spark.createDataFrame(df_pch_4)
snow_options = get_snowflake_options()
df_pch_4_spark.write.format("snowflake").options(**snow_options).option("sfSchema", "BDR_FFP_DA_WRK").option("dbtable","df_pch_4").mode("overwrite").save()


# display(len(df_pch_4))

df_pch_4 = df_pch_4.assign(**{'time_in':'9999-12-31', 'time_out':'9999-12-31', 'ts':0, 'aux_code':'na'})
df_pch_4.drop_duplicates(subset=None, keep='first', inplace=True)

df_pch_4_spark2 = spark.createDataFrame(df_pch_4)
df_pch_4_spark2.write.format("snowflake").options(**snow_options).option("sfSchema", "BDR_FFP_DA_WRK").option("dbtable","df_pch_4_22").mode("overwrite").save()

# df_pch_4.to_csv("/dbfs/mnt/saisdcnonprod/isdc/dev/epm/df_pch_4_snflk_op_df_dropdup.csv", sep=',', header=True, index=False) #checkpoint

# display(len(df_pch_4))


# COMMAND ----------


df_pch_5 = pd.merge(df_pch_4, quename, left_on=['queue_name'], right_on=['PCH_NAMING'], how='right')

# df_pch_5_spark = spark.createDataFrame(df_pch_5)
# snow_options = get_snowflake_options()
# df_pch_5_spark.write.format("snowflake").options(**snow_options).option("sfSchema", "BDR_FFP_DA_WRK").option("dbtable","df_pch_5").mode("overwrite").save()

# display(len(df_pch_5))
# df_pch_5.to_csv("/dbfs/mnt/saisdcnonprod/isdc/dev/epm/df_pch_5_snflk.csv", sep=',', header=True, index=False) #checkpoint

# COMMAND ----------


df_pch_5['UID'] = df_pch_5['USER_ID']

df_pch_f = df_pch_5.assign(**{'SOURCE':'PCH', 'TN':'NA', 'Agent_Ind':'NA', 'COMPLETED_TIME':'NA', 'PEND_TIME':'NA', 'SUSP_TIME':'NA', 'FORWARD_TIME':'NA', 'OTHER_TIME':'NA'})
df_pch_f = df_pch_f.rename(columns={"image_number":"IMAGENUM", "queue_name":"QUEUENAME", "COMPAS_NAME":"UName", "ActionDate_d":"DATE_COMPLETED", "AUXCODE_2":"AUXCODE", "ActionDate_dt":"Min_COMPAS_DT_In", "time_in":"TT_DT_IN", "time_out":"TT_DT_OUT" })



# COMMAND ----------


df_pch_f=df_pch_f[['SOURCE', 'TN', 'IMAGENUM', 'Agent_Ind', 'QUEUENAME', 'UID', 'UName', 'DATE_COMPLETED', 'AUXCODE','Min_COMPAS_DT_In','TT_DT_IN','TT_DT_OUT','COMPLETED_TIME','PEND_TIME','SUSP_TIME','FORWARD_TIME', 'OTHER_TIME', 'USER_ID', 'EMP_TYPE']]

l_f = [df_compas_f, df_pch_f]

df_compas_f_spark = spark.createDataFrame(df_compas_f)
snow_options = get_snowflake_options()
df_compas_f_spark.write.format("snowflake").options(**snow_options).option("sfSchema", "BDR_FFP_DA_WRK").option("dbtable","df_compas_f").mode("overwrite").save()
df_pch_f_spark = spark.createDataFrame(df_pch_f)
df_pch_f_spark.write.format("snowflake").options(**snow_options).option("sfSchema", "BDR_FFP_DA_WRK").option("dbtable","df_pch_f").mode("overwrite").save()


df_f = pd.concat(l_f)

# display(len(df_f))

# COMMAND ----------


df_tt['ts']=df_tt['time_out']-df_tt['time_in']
df_tt_f = df_tt.groupby(['created_by', 'date_in', 'aux_code'], as_index=False).agg({"ts": "sum"})

# df_tt_f_spark = spark.createDataFrame(df_tt_f)
# snow_options = get_snowflake_options()
# df_tt_f_spark.write.format("snowflake").options(**snow_options).option("sfSchema", "BDR_FFP_DA_WRK").option("dbtable","df_tt_f").mode("overwrite").save()

# display(len(df_tt_f))

df_tt_f = df_tt_f.rename(columns={"created_by":"COMPAS ID", "date_in":"DateIn", "aux_code":"Aux Code"})
df_tt_f['time spent'] = df_tt_f.ts.dt.total_seconds()/3600
df_tt_f=df_tt_f[['COMPAS ID', 'DateIn', 'Aux Code', 'time spent']]

# COMMAND ----------


# display(df_f.dtypes)
df_f = df_f.astype(str)
sql_compas_helper1 = sql_compas_helper1.astype(str)
df_tt_f = df_tt_f.astype(str)

# COMMAND ----------


# df_f.to_csv('/dbfs/mnt/saisdcnonprod/isdc/dev/epm/Data_for_Tableau.csv', sep=',', header=True, index=False)
# sql_compas_helper1.to_csv('/dbfs/mnt/saisdcnonprod/isdc/dev/epm/Data_for_Tableau_helper.csv', sep=',', header=True, index=False)
# df_tt_f.to_csv('/dbfs/mnt/saisdcnonprod/isdc/dev/epm/tblTime_3.csv', sep=',', header=True, index=False)
spark_df_f = spark.createDataFrame(df_f)
spark_sql_compas_helper1 = spark.createDataFrame(sql_compas_helper1)
spark_df_tt_f = spark.createDataFrame(df_tt_f)
snow_options = get_snowflake_options()
spark_df_f.write.format("snowflake").options(**snow_options).option("sfSchema", "BDR_FFP_DA").option("dbtable","EPM_Data_for_Tableau").mode("overwrite").save()
spark_sql_compas_helper1.write.format("snowflake").options(**snow_options).option("sfSchema", "BDR_FFP_DA").option("dbtable","EPM_Data_for_Tableau_helper").mode("overwrite").save()
spark_df_tt_f.write.format("snowflake").options(**snow_options).option("sfSchema", "BDR_FFP_DA").option("dbtable","EPM_tblTime_3").mode("overwrite").save()


