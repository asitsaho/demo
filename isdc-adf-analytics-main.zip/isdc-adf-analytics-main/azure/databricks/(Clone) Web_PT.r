# Databricks notebook source
Sys.setenv(JAVA_HOME="/usr/lib/jvm/zulu8-ca-amd64/jre/")

# COMMAND ----------

install.packages("h2o",repos="http://cran.rstudio.com")
library(h2o)
detach("package:h2o", unload = TRUE)
remove.packages("h2o")

# COMMAND ----------

h2o_version <- "3.32.0.1"
install.packages(
  paste0("https://cran.r-project.org/src/contrib/Archive/h2o/h2o_", h2o_version, ".tar.gz"),
  repos = NULL,
  type = "source"
)

library(h2o)

# COMMAND ----------

h2o.init(max_mem_size = "144G",ip= "localhost", port = 54544)

# COMMAND ----------

setwd("/dbfs/mnt/saisdcnonprod/isdc/dev/R_Models/")
model <-h2o.loadModel("/dbfs/mnt/saisdcnonprod/isdc/dev/R_Models/GBM_model_R_1623337866900_32")

# COMMAND ----------

setwd("/dbfs/mnt/saisdcnonprod/isdc/dev/R_Models/")
score1<-read.csv("SCORE1.csv",stringsAsFactors = F,as.is = T,na.strings = "")
# score2<-read.csv("SCORE2.csv",stringsAsFactors = F,as.is = T,na.strings = "")
# score3<-read.csv("SCORE3.csv",stringsAsFactors = F,as.is = T,na.strings = "")
# scoring_data<-rbind(score1,score2,score3)
scoring_data<-rbind(score1)

# COMMAND ----------

#sapply(scoring_data,class)
#scoring_data$AGE <- as.numeric(scoring_data$AGE)
#sapply(scoring_data,class)

# COMMAND ----------

check_var <- c("PLAN_CODE_1",
                "MSUP_ACTIVE_PROD_DURATION",
                "tot_EFT_disc_amount",
                "no_camp_C000003460_180days",
                "no_premium",
                "age",
                "no_claims",
                "HOMVAL",
                "income",
                "avg_DEDUCTIBLE_amount",
                "tot_premium_amt",
                "INDIVIDUAL_PREMIUM_AMOUNT",
                "paid_net_memb_cont_amt_3_mnths",
                "no_treatment",
                "max_proc_days",
                "PERSON_ID")


for (i in 1:length(check_var)) {
print(i)
if(tolower(check_var[i]) %in% tolower(colnames(scoring_data))){
names(scoring_data)[tolower(colnames(scoring_data)) == tolower(check_var[i])] = check_var[i]
}}


scoring_data$PLAN_CODE_1 <- as.factor(substr(scoring_data$PLAN_CODE,1, 1))

rm(score1)

# COMMAND ----------

web_PT_vars<-c("Target","PLAN_CODE_1",
               "MSUP_ACTIVE_PROD_DURATION",
               "tot_EFT_disc_amount",
               "no_camp_C000003460_180days",
               "no_premium",
               "no_claims",
               "HOMVAL",
               "income",
               "avg_DEDUCTIBLE_amount",
               "tot_premium_amt",
               "INDIVIDUAL_PREMIUM_AMOUNT",
               "paid_net_memb_cont_amt_3_mnths",
               "no_treatment",
               "max_proc_days"
)

web_PT_vars<-web_PT_vars[2:15]

scoring_data_PT<-scoring_data[,web_PT_vars]

# cHECKING WHICH COLUMNS STILL HAVE NA

col_names<-colnames(scoring_data_PT)[colSums(is.na(scoring_data_PT)) > 0]

# COMMAND ----------

#scoring_data_PT$age <- as.numeric(scoring_data_PT$age)
pred_web_PT <- as.data.frame(h2o.predict(model,as.h2o(scoring_data_PT)))
scoring_data$Probability<-pred_web_PT$p1
WEB_PT_SCORED_DATA<-scoring_data[,c("PERSON_ID","Probability")]
head(WEB_PT_SCORED_DATA)
col_names<-colnames(WEB_PT_SCORED_DATA)[colSums(is.na(WEB_PT_SCORED_DATA)) > 0]
col_names
write.csv(WEB_PT_SCORED_DATA,"Web_PT_Scored_data.csv",row.names = F)
h2o.shutdown(prompt=FALSE)
# scoring_data_PT
# sapply(scoring_data_PT, class)
# colnames(scoring_data_PT)
# head(scoring_data_PT)
