# Databricks notebook source
# MAGIC %r    
# MAGIC install.packages("randomForest",repos="http://cran.rstudio.com")
# MAGIC setwd("/dbfs/mnt/saisdcnonprod/isdc/dev/R_Models/")
# MAGIC score1<-read.csv("SCORE1.csv",stringsAsFactors = F,as.is = T,na.strings = "")
# MAGIC #score2<-read.csv("SCORE2.csv",stringsAsFactors = F,as.is = T,na.strings = "")
# MAGIC #score3<-read.csv("SCORE3.csv",stringsAsFactors = F,as.is = T,na.strings = "")
# MAGIC #scoring_data<-rbind(score1,score2,score3)
# MAGIC scoring_data<-rbind(score1)
# MAGIC # file_path <- "/dbfs/mnt/saisdcnonprod/isdc/dev/R_Models/scoring_data.csv"
# MAGIC # write.csv(scoring_data, file = file_path, row.names = FALSE)

# COMMAND ----------

# MAGIC %r
# MAGIC check_var <- c("no_calls_3_mnths",
# MAGIC         "no_camp_C000002230_180days",
# MAGIC         "previous_recc_EFT_360days",
# MAGIC         "no_1timeEFT_6mths",
# MAGIC         "tenure",
# MAGIC         "BILL_PAY_INQ_call",
# MAGIC         "INDIVIDUAL_PREMIUM_AMOUNT",
# MAGIC         "paid_net_memb_cont_amt",
# MAGIC         "no_late_12_mnths",
# MAGIC         "ECC_claim_total_app_amt",
# MAGIC         "tot_benefit_amt",
# MAGIC         "no_treatment",
# MAGIC         "tot_proc_days",
# MAGIC         "PLAN_CODE",
# MAGIC         "RET",
# MAGIC         "PERSON_ID")
# MAGIC
# MAGIC for (i in 1:length(check_var)) {
# MAGIC print(i)
# MAGIC if(tolower(check_var[i]) %in% tolower(colnames(scoring_data))){
# MAGIC names(scoring_data)[tolower(colnames(scoring_data)) == tolower(check_var[i])] = check_var[i]
# MAGIC }}
# MAGIC rm(score1)
# MAGIC rm(score2)
# MAGIC rm(score3)
# MAGIC col_names<-colnames(scoring_data)[colSums(is.na(scoring_data)) > 0]
# MAGIC # col_names
# MAGIC scoring_data1<-scoring_data
# MAGIC scoring_data1[which(substr(scoring_data$PLAN_CODE,1,1)=='F'), "PLAN_CODE_F"] = 1
# MAGIC scoring_data1[which(substr(scoring_data$PLAN_CODE,1,1)!='F'), "PLAN_CODE_F"] = 0
# MAGIC scoring_data1[which(substr(scoring_data$PLAN_CODE,1,1)=='N'), "PLAN_CODE_N"] = 1
# MAGIC scoring_data1[which(substr(scoring_data$PLAN_CODE,1,1)!='N'), "PLAN_CODE_N"] = 0
# MAGIC rm(scoring_data)
# MAGIC col_names<-colnames(scoring_data1)[colSums(is.na(scoring_data1)) > 0]
# MAGIC col_names
# MAGIC Mode = function(x){
# MAGIC   ta = table(x)
# MAGIC   tam = max(ta)
# MAGIC   if (all(ta == tam))
# MAGIC     mod = NA
# MAGIC   else
# MAGIC     if(is.numeric(x))
# MAGIC       mod = as.numeric(names(ta)[ta == tam])
# MAGIC   else
# MAGIC     mod = names(ta)[ta == tam]
# MAGIC   return(mod)
# MAGIC }
# MAGIC
# MAGIC col_names
# MAGIC scoring_data1[is.na(scoring_data1$RET),"RET"]=as.numeric(Mode(scoring_data1[,"RET"]))
# MAGIC col_names<-colnames(scoring_data1)[colSums(is.na(scoring_data1)) > 0]
# MAGIC col_names
# MAGIC rm(col_names)
# MAGIC rm(Mode)  

# COMMAND ----------

# MAGIC %r
# MAGIC library(randomForest)
# MAGIC load("EFT_FINAL_MODEL_OBJECT_ISDW.RData")
# MAGIC pred_EFT_score = predict(model_EFT, scoring_data1,type='prob')
# MAGIC scoring_data1$EFT_prob<-pred_EFT_score[,2]
# MAGIC EFT_scored<-scoring_data1[,c("PERSON_ID","EFT_prob")]
# MAGIC col_names<-colnames(EFT_scored)[colSums(is.na(EFT_scored)) > 0]
# MAGIC col_names
# MAGIC head(EFT_scored)
# MAGIC write.csv(EFT_scored,"scored_EFT.csv")
# MAGIC rm(model_EFT)

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC
