CREATE OR REPLACE PROCEDURE BDR_BI.SP_ISB_SF_BIL14B_MNT_STMT_OF_ACCT("PV_REPORTSTARTDATE" DATE, "PV_REPORTSTOPDATE" DATE, "DB_NAME" VARCHAR(16777216) DEFAULT '', "TGT_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "TGT2_SC" VARCHAR(16777216) DEFAULT '', "SRC_SC" VARCHAR(16777216) DEFAULT 'SRC_DWADM', "SRC2_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "SRC3_SC" VARCHAR(16777216) DEFAULT 'BDR_MSOA', "UTIL_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "PIPELINE_ID" VARCHAR(16777216) DEFAULT '', "PIPELINE_NAME" VARCHAR(16777216) DEFAULT 'SP_ISB_SF_BIL14B_MNT_STMT_OF_ACCT')
RETURNS TABLE ()
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

        gv_ReportStartDate                DATE := DATE(pv_ReportStartDate);
        gv_ReportStopDate                DATE := DATE(pv_ReportStopDate);
        gv_Log_id                          NUMBER;
        gv_error_code                     VARCHAR(200);      



V_START_TIME TIMESTAMP;

V_STEP VARCHAR;
V_LAST_QUERY_ID    VARCHAR;
V_ROWS_LOADED   VARCHAR;
V_PROCESS_NAME   VARCHAR DEFAULT ''SP_ISB_SF_BIL14B_MNT_STMT_OF_ACCT'';
V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''SP_ISB_SF_BIL14B_MNT_STMT_OF_ACCT'';
V_STEP_NAME        VARCHAR;
V_ROWS_PARSED      INTEGER;
V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := COALESCE(:UTIL_SC, ''BDR_BI'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';
BEGIN
----MSOA.WRK_RIA_MSOA_MONTHLY_PREMIUM
----.
LET V_WRK_RIA_MSOA_MONTHLY_PREMIUM VARCHAR :=  :SRC3_SC || ''.WRK_RIA_MSOA_MONTHLY_PREMIUM'';

----MSOA.WRK_RIA_MSOA_MONTHLY_OTHER
----.
LET V_WRK_RIA_MSOA_MONTHLY_OTHER VARCHAR :=  :SRC3_SC || ''.WRK_RIA_MSOA_MONTHLY_OTHER'';

----PV_REPORTRESULT
----PV_REPORTRESULT
LET V_PV_REPORTRESULT VARCHAR :=  :TGT_SC || ''.PV_REPORTRESULT'';

----PRIOR_MONTHS_SUMMARY_OTHER
----PRIOR_MONTHS_SUMMARY_OTHER
LET V_PRIOR_MONTHS_SUMMARY_OTHER VARCHAR :=  :TGT_SC || ''.PRIOR_MONTHS_SUMMARY_OTHER'';

----CURRENT_MONTHS_SUMMARY_OTHER
----CURRENT_MONTHS_SUMMARY_OTHER
LET V_CURRENT_MONTHS_SUMMARY_OTHER VARCHAR :=  :TGT_SC || ''.CURRENT_MONTHS_SUMMARY_OTHER'';

----PRIOR_MONTHS_SUMMARY
----PRIOR_MONTHS_SUMMARY
LET V_PRIOR_MONTHS_SUMMARY VARCHAR :=  :TGT_SC || ''.PRIOR_MONTHS_SUMMARY'';

----CURRENT_MONTHS_SUMMARY
----CURRENT_MONTHS_SUMMARY
LET V_CURRENT_MONTHS_SUMMARY VARCHAR :=  :TGT_SC || ''.CURRENT_MONTHS_SUMMARY'';




--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP1'';
V_STEP_NAME :=  ''call BDR_BI.FN_ISB_SF_GET_LOG_ID()'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

call BDR_BI.FN_ISB_SF_GET_LOG_ID()
    into :gv_Log_id;

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0 ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP2'';
V_STEP_NAME :=  ''CALL BDR_BI.SP_ISB_SF_INSERT_JOB_LOG()'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CALL BDR_BI.SP_ISB_SF_INSERT_JOB_LOG(:gv_Log_id,''BI.PKG_ISB_BILL_REPORTS.SP_ISB_MTHLY_STMT_OF_ACCTS_PARTB'',''BIL0014B_ISB_Mthly_Stmt_Of_Accts'');

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0 ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP3'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE PRIOR_MONTHS_SUMMARY'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


 	
    	
	CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_PRIOR_MONTHS_SUMMARY) AS
	    (   SELECT
	            a.msoa_dt,
	            a.PAY_STAT,
	            CASE
	                WHEN add_months(date_trunc(MONTH, to_date(:gv_ReportStopDate)),-1) = a.due_date
	                THEN ''Current Month''
	                WHEN add_months(date_trunc(MONTH, to_date(:gv_ReportStopDate)),-1) > a.due_date
	                THEN ''Prior Months''
	                WHEN add_months(date_trunc(MONTH, to_date(:gv_ReportStopDate)),-1) < a.due_date
	                THEN ''Future Months''
	                ELSE ''Unknown''
	            END                             AS category,
	            COUNT(DISTINCT a.INDIVIDUAL_ID) AS individual_count,
	            SUM(a.pay_amt)                  AS pay_amt
	        FROM
	            IDENTIFIER(:V_WRK_RIA_MSOA_MONTHLY_PREMIUM) a
	        WHERE
	            a.msoa_dt = add_months(date_trunc(MONTH, to_date(:gv_ReportStopDate)),-2)
	        GROUP BY
	            a.msoa_dt,
	            a.due_date,
	            a.PAY_STAT
	    );

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM  IDENTIFIER(:V_PRIOR_MONTHS_SUMMARY)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP4'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE CURRENT_MONTHS_SUMMARY'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_CURRENT_MONTHS_SUMMARY) AS
	    (   SELECT
	            a.msoa_dt,
	            a.PAY_STAT,
	            CASE
	                WHEN add_months(date_trunc(MONTH, to_date(:gv_ReportStopDate)),-1) = a.due_date
	                THEN ''Current Month''
	                WHEN add_months(date_trunc(MONTH, to_date(:gv_ReportStopDate)),-1) > a.due_date
	                THEN ''Prior Months''
	                WHEN add_months(date_trunc(MONTH, to_date(:gv_ReportStopDate)),-1) < a.due_date
	                THEN ''Future Months''
	                ELSE ''Unknown''
	            END                             AS category,
	            COUNT(DISTINCT a.INDIVIDUAL_ID) AS individual_count,
	            SUM(a.pay_amt)                  AS pay_amt
	        FROM
	            IDENTIFIER(:V_WRK_RIA_MSOA_MONTHLY_PREMIUM) a
	        WHERE
	            a.msoa_dt = add_months(date_trunc(MONTH, to_date(:gv_ReportStopDate)),-1)
	        GROUP BY
	            a.msoa_dt,
	            a.due_date ,
	            a.PAY_STAT
	    );
	    
	   CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_prior_months_summary_other) AS
	    (   SELECT
	            a.msoa_dt,
	            a.CATEGORY,
	            COUNT(DISTINCT a.INDIVIDUAL_ID) AS individual_count,
	            SUM(a.pay_amt)                  AS pay_amt
	        FROM
	            IDENTIFIER(:V_WRK_RIA_MSOA_MONTHLY_OTHER) a
	        WHERE
	            a.msoa_dt = add_months(date_trunc(MONTH, to_date(:gv_ReportStopDate)),-2)
	        GROUP BY
	            a.msoa_dt,
	            a.CATEGORY
	    );

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_CURRENT_MONTHS_SUMMARY)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP5'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE CURRENT_MONTHS_SUMMARY_OTHER'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_CURRENT_MONTHS_SUMMARY_OTHER) AS
	    (   SELECT
	            a.msoa_dt,
	            a.CATEGORY,
	            COUNT(DISTINCT a.INDIVIDUAL_ID) AS individual_count,
	            SUM(a.pay_amt)                  AS pay_amt
	        FROM
	            IDENTIFIER(:V_WRK_RIA_MSOA_MONTHLY_OTHER) a
	        WHERE
	            a.msoa_dt = add_months(date_trunc(MONTH, to_date(:gv_ReportStopDate)),-1)
	        GROUP BY
	            a.msoa_dt,
	            a.CATEGORY
	    );

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_CURRENT_MONTHS_SUMMARY_OTHER)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP6'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE PV_REPORTRESULT'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_PV_REPORTRESULT) as
SELECT
    CATEGORY, 
    SUM(PRIOR_MONTHS_PAY_AMT) AS PRIOR_MONTHS_PAY_AMT, 
    SUM(CURRENT_MONTHS_PAY_AMT) AS CURRENT_MONTHS_PAY_AMT, 
    SUM(DOLLARS_NET_CHANGE) AS DOLLARS_NET_CHANGE,
    :gv_ReportStartDate AS START_DATE,
    :gv_ReportStopDate AS END_DATE,
    current_timestamp() AS RUN_DATE
FROM
(
	SELECT
	    CASE
	        WHEN COALESCE(a.pay_stat, b.pay_stat) IN (''Unknown'',
	                                                  ''Membership'')
	        THEN ''Unknown''
	        WHEN COALESCE(a.category, b.category) IN (''Current Month'',
	                                                  ''Prior Months'')
	        AND COALESCE(a.pay_stat, b.pay_stat) = ''Partially Paid''
	        THEN ''Current and Net Change Prior Period''
	        ELSE COALESCE(a.category, b.category)
	    END ||
	    CASE
	        WHEN COALESCE(a.pay_stat, b.pay_stat) IN (''Fully Paid'',
	                                                  ''Partially Paid'')
	        THEN '' - ''
	        ELSE NULL
	    END ||
	    CASE
	        WHEN COALESCE(a.pay_stat, b.pay_stat) IN (''Fully Paid'',
	                                                  ''Partially Paid'')
	        THEN COALESCE(a.pay_stat, b.pay_stat)
	        ELSE NULL
	    END                                                      AS Category,
	    SUM(NVL(b.individual_count,0))                                  AS prior_months_individuals,
	    SUM(NVL(b.pay_amt,0))                                           AS prior_months_pay_amt,
	    SUM(NVL(a.individual_count,0))                                  AS current_months_individuals,
	    SUM(NVL(a.pay_amt,0))                                           AS current_months_pay_amt,
	    SUM(NVL(a.individual_count,0)) - SUM(NVL(b.individual_count,0)) AS individual_net_change,
	    SUM(NVL(a.pay_amt,0)) - SUM(NVL(b.pay_amt,0))                   AS dollars_net_change,
       :gv_ReportStartDate AS START_DATE,
       :gv_ReportStopDate AS END_DATE,
       CURRENT_TIMESTAMP AS RUN_DATE
	FROM
	    IDENTIFIER(:V_CURRENT_MONTHS_SUMMARY) a
	FULL OUTER JOIN
	    IDENTIFIER(:V_PRIOR_MONTHS_SUMMARY) b
	ON
	    a.category = b.category
	AND a.pay_stat = b.pay_stat
	GROUP BY
	    a.pay_stat, b.pay_stat,a.category, b.category
	
	UNION ALL
	
	SELECT
	    CASE 
	        WHEN COALESCE(a.category, b.category) = ''NAF'' 
	        THEN ''On-Account''
	        WHEN COALESCE(a.category, b.category) = ''SUS'' 
	        THEN ''General Suspense''
	        ELSE COALESCE(a.category, b.category) 
	    END                                                      AS category,
	    SUM(NVL(b.individual_count,0))                             AS PRIOR_MONTHS_INDIVIDUALS,
	    SUM(NVL(b.pay_amt,0))                                      AS PRIOR_MONTHS_PAY_AMT,
	    SUM(NVL(a.individual_count,0))                             AS CURRENT_MONTHS_INDIVIDUALS,
	    SUM(NVL(a.pay_amt,0))                                      AS current_months_pay_amt,
	    SUM(NVL(a.individual_count,0) - NVL(b.individual_count,0)) AS INDIVIDUALS_NET_CHANGE,
	    SUM(NVL(a.pay_amt,0) - NVL(b.pay_amt,0))                   AS dollars_net_change,
        :gv_ReportStartDate AS START_DATE,
       :gv_ReportStopDate AS END_DATE,
       CURRENT_TIMESTAMP() AS RUN_DATE
	FROM
	    IDENTIFIER(:V_CURRENT_MONTHS_SUMMARY_OTHER) a
	FULL OUTER JOIN
	    IDENTIFIER(:V_PRIOR_MONTHS_SUMMARY_OTHER) b
	ON
	    a.category = b.category
	GROUP BY
	    a.category, b.category 
)
    GROUP BY
        CATEGORY;

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_PV_REPORTRESULT)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP7'';
V_STEP_NAME :=  ''CALL BDR_BI.SP_ISB_SF_LOG_INSERT_COMPLETE(:gv_Log_id)'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CALL BDR_BI.SP_ISB_SF_LOG_INSERT_COMPLETE(:gv_Log_id);

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0 ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




let res_set RESULTSET;
let select_statement1 := ''SELECT * FROM pv_ReportResult'';
res_set := (EXECUTE IMMEDIATE :select_statement1);
RETURN TABLE(res_set);

EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);

gv_error_code := SQLERRM;
CALL BDR_BI.SP_ISB_SF_LOG_INSERT_ERROR(:gv_Log_id, :gv_error_code);

RAISE;


END;

';