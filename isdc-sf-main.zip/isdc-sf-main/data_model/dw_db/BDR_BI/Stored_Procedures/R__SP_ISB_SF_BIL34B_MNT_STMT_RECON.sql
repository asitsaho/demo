USE SCHEMA BDR_BI; CREATE OR REPLACE PROCEDURE "SP_ISB_SF_BIL34B_MNT_STMT_RECON"("PV_REPORTSTARTDATE" DATE, "PV_REPORTSTOPDATE" DATE, "DB_NAME" VARCHAR(16777216) DEFAULT '', "TGT_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "TGT2_SC" VARCHAR(16777216) DEFAULT '', "SRC_SC" VARCHAR(16777216) DEFAULT 'SRC_DWADM', "SRC2_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "UTIL_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "PIPELINE_ID" VARCHAR(16777216) DEFAULT '', "PIPELINE_NAME" VARCHAR(16777216) DEFAULT 'SP_ISB_SF_BIL34B_MNT_STMT_RECON')
RETURNS TABLE ()
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

  gv_ReportStartDate                DATE := DATE(Pv_ReportStartDate);
  gv_ReportStopDate                DATE := DATE(Pv_ReportStopDate);
  gv_Log_id                         NUMBER;
  gv_error_code                     varchar(200);



V_START_TIME TIMESTAMP;

V_STEP VARCHAR;
V_LAST_QUERY_ID    VARCHAR;
V_ROWS_LOADED   VARCHAR;
V_PROCESS_NAME   VARCHAR DEFAULT ''SP_ISB_SF_BIL34B_MNT_STMT_RECON'';
V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''SP_ISB_SF_BIL34B_MNT_STMT_RECON'';
V_STEP_NAME        VARCHAR;
V_ROWS_PARSED      INTEGER;
V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := COALESCE(:UTIL_SC, ''BDR_BI'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';
BEGIN
----DWADM.PAYMENT_FACT
----SRC_DWADM.PAYMENT_FACT
LET V_PAYMENT_FACT VARCHAR :=  :SRC_SC || ''.PAYMENT_FACT'';

----PRESCRIPTION
----PRESCRIPTION
LET V_PRESCRIPTION VARCHAR :=  :TGT_SC || ''.PRESCRIPTION'';

----PV_REPORTRESULT
----PV_REPORTRESULT
LET V_PV_REPORTRESULT VARCHAR :=  :TGT_SC || ''.PV_REPORTRESULT'';

----DWADM.TNDR_SRC_DIM
----SRC_DWADM.TNDR_SRC_DIM
LET V_TNDR_SRC_DIM VARCHAR :=  :SRC_SC || ''.TNDR_SRC_DIM'';

----DWADM.ACCOUNT_DIM
----SRC_DWADM.ACCOUNT_DIM
LET V_ACCOUNT_DIM VARCHAR :=  :SRC_SC || ''.ACCOUNT_DIM'';

----DWADM.PAYMENT_TENDERS_FACT
----SRC_DWADM.PAYMENT_TENDERS_FACT
LET V_PAYMENT_TENDERS_FACT VARCHAR :=  :SRC_SC || ''.PAYMENT_TENDERS_FACT'';

----PDP
----PDP
LET V_PDP VARCHAR :=  :TGT_SC || ''.PDP'';

----CLAIM
----CLAIM
LET V_CLAIM VARCHAR :=  :TGT_SC || ''.CLAIM'';

----PNZ
----PNZ
LET V_PNZ VARCHAR :=  :TGT_SC || ''.PNZ'';

----DWADM.CONTRACT_DIM
----SRC_DWADM.CONTRACT_DIM
LET V_CONTRACT_DIM VARCHAR :=  :SRC_SC || ''.CONTRACT_DIM'';

----COMPARE_RESULTS
----COMPARE_RESULTS
LET V_COMPARE_RESULTS VARCHAR :=  :TGT_SC || ''.COMPARE_RESULTS'';

----MONTHLY_PAYMENT_COHORT
----MONTHLY_PAYMENT_COHORT
LET V_MONTHLY_PAYMENT_COHORT VARCHAR :=  :TGT_SC || ''.MONTHLY_PAYMENT_COHORT'';

----DWADM.TNDR_TYPE_DIM
----SRC_DWADM.TNDR_TYPE_DIM
LET V_TNDR_TYPE_DIM VARCHAR :=  :SRC_SC || ''.TNDR_TYPE_DIM'';

----MONTHLY_PAYMENT_TENDERS_COHORT
----MONTHLY_PAYMENT_TENDERS_COHORT
LET V_MONTHLY_PAYMENT_TENDERS_COHORT VARCHAR :=  :TGT_SC || ''.MONTHLY_PAYMENT_TENDERS_COHORT'';

----MONTHLY_COHORT
----MONTHLY_COHORT
LET V_MONTHLY_COHORT VARCHAR :=  :TGT_SC || ''.MONTHLY_COHORT'';




--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP1'';
V_STEP_NAME :=  ''call BDR_BI.FN_ISB_SF_GET_LOG_ID()'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

call BDR_BI.FN_ISB_SF_GET_LOG_ID()
    into :gv_Log_id;

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0 ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP2'';
V_STEP_NAME :=  ''CALL BDR_BI.SP_ISB_SF_INSERT_JOB_LOG()'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CALL BDR_BI.SP_ISB_SF_INSERT_JOB_LOG(:gv_Log_id,''BI.PKG_ISB_BILL_REPORTS.SP_ISB_MONTHLY_STATEMENT_RECON'',''BIL0034B_ISB_Monthly_Statement_Recon'');

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0 ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP3'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE MONTHLY_PAYMENT_TENDERS_COHORT'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_MONTHLY_PAYMENT_TENDERS_COHORT) AS
    (   SELECT
                A.SRC_PAY_TNDR_ID,
                DATE(A.PAY_EVENT_CREATE_DT) AS PAY_EVENT_CREATE_DT,
                A.SRC_TNDR_STATUS_DESCR,
                B.TNDR_TYPE_DESCR,
                B.GENERATE_APAY_SW,
                C.TNDR_SOURCE_DESCR,
                C.EXT_SOURCE_ID,
                C.TNDR_SOURCE_TYPE_DESCR,
                CASE
                    WHEN AD.ACCT_NBR_TYPE = ''EMPBLGID''
                    THEN ''Yes''
                    ELSE NULL
                END AS EMPLOYER_ACCT,
                CASE
                    WHEN A.SRC_TNDR_STATUS_DESCR = ''Canceled''
                    THEN A.TNDR_AMT
                    ELSE 0
                END AS CNCL_TNDR_AMT,
                CASE
                    WHEN A.SRC_TNDR_STATUS_DESCR <> ''Canceled''
                    THEN A.TNDR_AMT
                    ELSE 0
                END AS TNDR_AMT
        FROM
                IDENTIFIER(:V_PAYMENT_TENDERS_FACT) A
        LEFT OUTER JOIN
            IDENTIFIER(:V_TNDR_TYPE_DIM) B
        ON
            A.TNDR_TYPE_CURR_KEY = B.TNDR_TYPE_CURR_KEY
        AND B.CURR_REC_FLAG = ''Y''
        LEFT OUTER JOIN
            IDENTIFIER(:V_TNDR_SRC_DIM) C
        ON
            A.TNDR_SRC_CURR_KEY = C.TNDR_SRC_CURR_KEY
        AND C.CURR_REC_FLAG = ''Y''
        LEFT OUTER JOIN
            IDENTIFIER(:V_ACCOUNT_DIM) AD
        ON
            A.ACCT_CURR_KEY = AD.ACCT_CURR_KEY
        AND AD.CURR_REC_FLAG = ''Y''
        WHERE
            trunc(A.PAY_EVENT_CREATE_DT::DATE,''mm'') =  TRUNC(:gv_ReportStopDate::DATE,''mm'')
        AND A.CDC_STATUS_FLAG <> ''D''  
    );

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_MONTHLY_PAYMENT_TENDERS_COHORT)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP4'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE MONTHLY_PAYMENT_COHORT'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE  IDENTIFIER(:V_MONTHLY_PAYMENT_COHORT) AS
    (   SELECT
            B.SRC_PAY_TNDR_ID,
            B.UDDGEN18,
            B.UDDGEN19,
            MAX(
            CASE
                WHEN C.SA_TYPE_DESC = ''Retroactivity''
                THEN ''Yes''
                ELSE ''No''
            END)                                       AS RETROACTIVITY,
            MIN(DATE(B.FREEZE_DT))                    AS MIN_FREEZE_DT,
            MAX(DATE(B.FREEZE_DT))                    AS MAX_FREEZE_DT,
            MAX(NVL(DATE(B.CANCEL_DT),''01-Jan-1980'')) AS MAX_CANCEL_DT,
            SUM(
            CASE
                WHEN SIGN(NVL(B.PAY_AMT,0)) = 1
                THEN NVL(B.PAY_AMT,0)
                ELSE 0
            END) AS POS_PAY_AMT,
            SUM(
            CASE
                WHEN SIGN(NVL(B.PAY_AMT,0)) = -1
                THEN NVL(B.PAY_AMT,0)
                ELSE 0
            END)                  AS NEG_PAY_AMT,
            SUM(NVL(B.PAY_AMT,0)) AS PAY_AMT,
            SUM(
            CASE
                WHEN B.SRC_MATCH_TYPE_CD = ''XFO''
                THEN B.PAY_AMT
                ELSE 0
            END) AS XFO_AMT,
            SUM(
            CASE
                WHEN B.SRC_MATCH_TYPE_CD = ''XFERMEMF''
                THEN B.PAY_AMT
                ELSE 0
            END) AS XFERMEMF_AMT,
            SUM(
            CASE
                WHEN B.SRC_MATCH_TYPE_CD = ''SUS''
                THEN B.PAY_AMT
                ELSE 0
            END) AS SUS_AMT,
            SUM(
            CASE
                WHEN B.SRC_MATCH_TYPE_CD = ''BILWPRPD''
                THEN B.PAY_AMT
                ELSE 0
            END) AS BILWPRPD_AMT,
            SUM(
            CASE
                WHEN B.SRC_MATCH_TYPE_CD = ''BINDPY''
                THEN B.PAY_AMT
                ELSE 0
            END) AS BINDPY_AMT,
            SUM(
            CASE
                WHEN B.SRC_MATCH_TYPE_CD = ''NAF''
                THEN B.PAY_AMT
                ELSE 0
            END) AS NAF_AMT,
            SUM(
            CASE
                WHEN B.SRC_MATCH_TYPE_CD = ''XFERADRS''
                THEN B.PAY_AMT
                ELSE 0
            END) AS XFERADRS_AMT,
            SUM(
            CASE
                WHEN B.SRC_MATCH_TYPE_CD NOT IN (''XFO'',
                                                 ''XFERMEMF'',
                                                 ''SUS'',
                                                 ''BILWPRPD'',
                                                 ''BINDPY'',
                                                 ''NAF'',
                                                 ''XFERADRS'')
                THEN B.PAY_AMT
                ELSE 0
            END) AS OTHER_AMT
        FROM
            IDENTIFIER(:V_PAYMENT_FACT) B
        LEFT OUTER JOIN
            IDENTIFIER(:V_CONTRACT_DIM) C
        ON
            B.CONTRACT_CURR_KEY = C.CONTRACT_CURR_KEY
        AND C.CURR_REC_FLAG = ''Y''
        WHERE
            B.CDC_STATUS_FLAG <> ''D''
        AND trunc(B.FREEZE_DT::DATE,''month'') =  trunc(:gv_ReportStopDate,''mm'')
        GROUP BY
            B.SRC_PAY_TNDR_ID,
            B.UDDGEN18,
            B.UDDGEN19
    );

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_MONTHLY_PAYMENT_COHORT)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP5'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE COMPARE_RESULTS'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE  IDENTIFIER(:V_COMPARE_RESULTS) AS
    (   SELECT
            COALESCE (A.SRC_PAY_TNDR_ID, B.SRC_PAY_TNDR_ID) AS SRC_PAY_TNDR_ID,
            B.SRC_TNDR_STATUS_DESCR,
            B.TNDR_TYPE_DESCR,
            B.GENERATE_APAY_SW,
            B.TNDR_SOURCE_DESCR,
            B.EXT_SOURCE_ID,
            B.TNDR_SOURCE_TYPE_DESCR,
            B.EMPLOYER_ACCT,
            A.UDDGEN18,
            A.UDDGEN19,
            A.RETROACTIVITY,
            NVL(B.TNDR_AMT,0)      AS TNDR_AMT,
            NVL(B.CNCL_TNDR_AMT,0) AS CNCL_TNDR_AMT,
            B.PAY_EVENT_CREATE_DT,
            A.MIN_FREEZE_DT,
            A.MAX_FREEZE_DT,
            A.MAX_CANCEL_DT,
            CASE
                WHEN A.SRC_PAY_TNDR_ID IS NULL
                THEN ''Yes''
                ELSE NULL
            END AS TENDER_ONLY,
            CASE
                WHEN B.SRC_PAY_TNDR_ID IS NULL
                THEN ''Yes''
                ELSE NULL
            END                                                   AS PAYMENT_ONLY,
            NVL(A.POS_PAY_AMT,0)                                              AS POS_PAY_AMT,
            NVL(A.NEG_PAY_AMT,0)                                              AS NEG_PAY_AMT,
            NVL(A.PAY_AMT,0)                                                  AS PAY_AMT,
            NVL(A.XFO_AMT,0)                                                  AS XFO_AMT,
            NVL(A.XFERMEMF_AMT,0)                                             AS XFERMEMF_AMT,
            NVL(A.SUS_AMT,0)                                                  AS SUS_AMT,
            NVL(A.BILWPRPD_AMT,0)                                             AS BILWPRPD_AMT,
            NVL(A.BINDPY_AMT,0)                                               AS BINDPY_AMT,
            NVL(A.NAF_AMT,0)                                                  AS NAF_AMT,
            NVL(A.XFERADRS_AMT,0)                                             AS XFERADRS_AMT,
            NVL(A.OTHER_AMT,0)                                                AS OTHER_AMT ,
            (NVL(A.POS_PAY_AMT,0) + NVL(A.NEG_PAY_AMT,0)) - NVL(B.TNDR_AMT,0) AS DIFF
        FROM
            IDENTIFIER(:V_MONTHLY_PAYMENT_COHORT) A
        FULL OUTER JOIN
            IDENTIFIER(:V_MONTHLY_PAYMENT_TENDERS_COHORT) B
        ON
            A.SRC_PAY_TNDR_ID = B.SRC_PAY_TNDR_ID
    );

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_COMPARE_RESULTS)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP6'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE MONTHLY_COHORT'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_MONTHLY_COHORT) AS
    (   SELECT
            A.PAY_EVENT_CREATE_DT,
            A.SRC_TNDR_STATUS_DESCR,
            A.TNDR_TYPE_DESCR,
            A.GENERATE_APAY_SW,
            A.TNDR_SOURCE_DESCR,
            A.EXT_SOURCE_ID,
            A.TNDR_SOURCE_TYPE_DESCR,
            A.EMPLOYER_ACCT,
            A.UDDGEN18,
            A.UDDGEN19,
            A.RETROACTIVITY,
            A.MIN_FREEZE_DT,
            A.MAX_FREEZE_DT,
            CASE
                WHEN A.MAX_CANCEL_DT = ''01-Jan-1980''
                THEN NULL
                ELSE A.MAX_CANCEL_DT
            END AS MAX_CANCEL_DT,
            TENDER_ONLY,
            PAYMENT_ONLY,
            COUNT(DISTINCT A.SRC_PAY_TNDR_ID) AS REC_CNT,
            SUM(A.TNDR_AMT)                   AS TNDR_AMT,
            SUM(A.CNCL_TNDR_AMT)              AS CNCL_TNDR_AMT,
            SUM(A.POS_PAY_AMT)                AS POS_PAY_AMT,
            SUM(A.NEG_PAY_AMT)                AS NEG_PAY_AMT,
            SUM(A.PAY_AMT)                    AS PAY_AMT,
            SUM(A.XFO_AMT)                    AS XFO_AMT,
            SUM(A.XFERMEMF_AMT)               AS XFERMEMF_AMT,
            SUM(A.SUS_AMT)                    AS SUS_AMT,
            SUM(A.BILWPRPD_AMT)               AS BILWPRPD_AMT,
            SUM(A.BINDPY_AMT)                 AS BINDPY_AMT,
            SUM(A.NAF_AMT)                    AS NAF_AMT,
            SUM(A.XFERADRS_AMT)               AS XFERADRS_AMT,
            SUM(A.OTHER_AMT)                  AS OTHER_AMT ,
            SUM(A.DIFF)                       AS DIFF
        FROM
            IDENTIFIER(:V_COMPARE_RESULTS) A
        GROUP BY
            A.PAY_EVENT_CREATE_DT,
            A.SRC_TNDR_STATUS_DESCR,
            A.TNDR_TYPE_DESCR,
            A.GENERATE_APAY_SW,
            A.TNDR_SOURCE_DESCR,
            A.EXT_SOURCE_ID,
            A.TNDR_SOURCE_TYPE_DESCR,
            A.EMPLOYER_ACCT,
            A.UDDGEN18,
            A.UDDGEN19,
            A.RETROACTIVITY,
            A.MIN_FREEZE_DT,
            A.MAX_FREEZE_DT,
            CASE
                WHEN A.MAX_CANCEL_DT = ''01-Jan-1980''
                THEN NULL
                ELSE A.MAX_CANCEL_DT
            END,
            TENDER_ONLY,
            PAYMENT_ONLY
    );

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_MONTHLY_COHORT)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP7'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE pv_ReportResult'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_pv_ReportResult) As
SELECT 
    CASE
        WHEN A.TNDR_SOURCE_DESCR = ''JP Morgan - Transfers''
        THEN ''Transfer - JPMC''
        WHEN A.TNDR_SOURCE_DESCR = ''MISSING''
        THEN ''Missing''
        WHEN A.EXT_SOURCE_ID = ''EXSIDCOMPAS''
        THEN ''COMPAS''
        WHEN A.TNDR_TYPE_DESCR = ''CHK - Check''
        AND A.TNDR_SOURCE_DESCR IN (''BNY Lockbox - Pittsburgh'',
                                    ''BNY Lockbox - Dallas'' )
        THEN ''Lockbox''
        WHEN (
                A.TNDR_SOURCE_TYPE_DESCR = ''Auto Pay''
            OR  A.TNDR_TYPE_DESCR IN (''Automatic Payment - Checking'',
                                      ''Automatic Payment - Saving''))
        AND A.TNDR_SOURCE_DESCR <> ''PENSION PAYER''
        THEN ''EFT''
        WHEN A.TNDR_SOURCE_DESCR = ''Enrollment Payments''
        THEN ''Enrollment''
        WHEN A.TNDR_TYPE_DESCR = ''3rd Party''
        THEN ''Third Party''
        WHEN A.TNDR_TYPE_DESCR = ''Credit Card''
        AND A.TNDR_SOURCE_DESCR = ''JPM CC''
        AND A.UDDGEN19 NOT IN (''WEB'',
                               ''WEB-QUICKPAY'')
        AND A.UDDGEN18 =''ONETIMECCSYS''
        THEN ''Credit Card - Automated''
        WHEN A.TNDR_TYPE_DESCR = ''Credit Card''
        AND A.TNDR_SOURCE_DESCR = ''JPM CC''
        AND A.UDDGEN19 IN (''WEB'',
                           ''WEB-QUICKPAY'')
        AND A.UDDGEN18 =''ONETIMECCSYS''
        THEN ''One-time Credit Card''
        WHEN A.TNDR_TYPE_DESCR = ''Credit Card''
        AND A.TNDR_SOURCE_DESCR = ''JPM CC''
        AND A.UDDGEN19 IS NULL
        THEN ''Credit Card - Add Payment''
        WHEN A.TNDR_SOURCE_DESCR = ''Transfer from Prescription Drug Program''
        THEN ''From IDENTIFIER(:V_PDP)''
        WHEN A.TNDR_TYPE_DESCR = ''Pension Payment - Saving''
        THEN ''Pension''
        WHEN A.TNDR_SOURCE_DESCR = ''Transfer from IDENTIFIER(:V_PNZ)/EZ IDENTIFIER(:V_CLAIM)''
        THEN ''From Claim''
        WHEN A.TNDR_TYPE_DESCR = ''Wire Payment - Checking''
        THEN ''Wire''
        ELSE ''Other''
    END AS SOURCE ,
    SUM(A.REC_CNT)       AS CNT,
    SUM(A.TNDR_AMT)      AS TNDER_AMT,
    SUM(A.CNCL_TNDR_AMT) AS CNCL_TNDR_AMT,
    SUM(A.PAY_AMT)       AS PAY_AMT,
    SUM(DIFF)            AS DIFF_TNDR_AND_PAYMENT_AMT,
    SUM(
    CASE
        WHEN A.TENDER_ONLY = ''Yes''
        THEN A.TNDR_AMT
        ELSE 0
    END) AS TNDR_ONLY_AMT,
    SUM(
    CASE
        WHEN A.PAYMENT_ONLY = ''Yes''
        THEN A.PAY_AMT
        ELSE 0
    END) AS PAYMENT_ONLY_AMT,
    SUM(
    CASE
        WHEN A.TNDR_AMT = 0
        AND A.PAY_AMT <> 0
        THEN A.PAY_AMT
        ELSE 0
    END)   AS REMAIN_PAYMENT_CNCL_TNDR_AMT,
    SUM(XFO_AMT)      AS TRANSFERRED_OUT_AMT,
    SUM(XFERMEMF_AMT) AS MEMBERSHIP_AMT,
    SUM(SUS_AMT)      AS GENERAL_SUSPENSE_AMT,
    SUM(BILWPRPD_AMT) AS PREMIUM_AMT,
    SUM(BINDPY_AMT)   AS ENROLLMENT_AMT,
    SUM(NAF_AMT)      AS ON_ACCOUNT_AMT,
    SUM(XFERADRS_AMT) AS ANDRUS_AMT,
    SUM(OTHER_AMT)    AS OTHER_AMT,
    CURRENT_TIMESTAMP AS RUN_DATE,
    trunc(:gv_ReportStopDate,''mm'') AS START_DATE,
    :gv_ReportStopDate AS END_DATE
FROM
    IDENTIFIER(:V_MONTHLY_COHORT) A
GROUP BY 
    CASE
        WHEN A.TNDR_SOURCE_DESCR = ''JP Morgan - Transfers''
        THEN ''Transfer - JPMC''
        WHEN A.TNDR_SOURCE_DESCR = ''MISSING''
        THEN ''Missing''
        WHEN A.EXT_SOURCE_ID = ''EXSIDCOMPAS''
        THEN ''COMPAS''
        WHEN A.TNDR_TYPE_DESCR = ''CHK - Check''
        AND A.TNDR_SOURCE_DESCR IN (''BNY Lockbox - Pittsburgh'',
                                    ''BNY Lockbox - Dallas'' )
        THEN ''Lockbox''
        WHEN (
                A.TNDR_SOURCE_TYPE_DESCR = ''Auto Pay''
            OR  A.TNDR_TYPE_DESCR IN (''Automatic Payment - Checking'',
                                      ''Automatic Payment - Saving''))
        AND A.TNDR_SOURCE_DESCR <> ''PENSION PAYER''
        THEN ''EFT''
        WHEN A.TNDR_SOURCE_DESCR = ''Enrollment Payments''
        THEN ''Enrollment''
        WHEN A.TNDR_TYPE_DESCR = ''3rd Party''
        THEN ''Third Party''
        WHEN A.TNDR_TYPE_DESCR = ''Credit Card''
        AND A.TNDR_SOURCE_DESCR = ''JPM CC''
        AND A.UDDGEN19 NOT IN (''WEB'',
                               ''WEB-QUICKPAY'')
        AND A.UDDGEN18 =''ONETIMECCSYS''
        THEN ''Credit Card - Automated''
        WHEN A.TNDR_TYPE_DESCR = ''Credit Card''
        AND A.TNDR_SOURCE_DESCR = ''JPM CC''
        AND A.UDDGEN19 IN (''WEB'',
                           ''WEB-QUICKPAY'')
        AND A.UDDGEN18 =''ONETIMECCSYS''
        THEN ''One-time Credit Card''
        WHEN A.TNDR_TYPE_DESCR = ''Credit Card''
        AND A.TNDR_SOURCE_DESCR = ''JPM CC''
        AND A.UDDGEN19 IS NULL
        THEN ''Credit Card - Add Payment''
        WHEN A.TNDR_SOURCE_DESCR = ''Transfer from Prescription Drug Program''
        THEN ''From IDENTIFIER(:V_PDP)''
        WHEN A.TNDR_TYPE_DESCR = ''Pension Payment - Saving''
        THEN ''Pension''
        WHEN A.TNDR_SOURCE_DESCR = ''Transfer from IDENTIFIER(:V_PNZ)/EZ IDENTIFIER(:V_CLAIM)''
        THEN ''From Claim''
        WHEN A.TNDR_TYPE_DESCR = ''Wire Payment - Checking''
        THEN ''Wire''
        ELSE ''Other''
    END 
ORDER BY 1,2;

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_PV_REPORTRESULT)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP8'';
V_STEP_NAME :=  ''CALL BDR_BI.SP_ISB_SF_LOG_INSERT_COMPLETE(:gv_Log_id)'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CALL BDR_BI.SP_ISB_SF_LOG_INSERT_COMPLETE(:gv_Log_id);

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0 ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);






let res_set RESULTSET;
let select_statement1 := ''SELECT * FROM pv_ReportResult'';
res_set := (EXECUTE IMMEDIATE :select_statement1);
RETURN TABLE(res_set);

EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);

gv_error_code := SQLERRM;
CALL BDR_BI.SP_ISB_SF_LOG_INSERT_ERROR(:gv_Log_id, :gv_error_code);

RAISE;

END;

';