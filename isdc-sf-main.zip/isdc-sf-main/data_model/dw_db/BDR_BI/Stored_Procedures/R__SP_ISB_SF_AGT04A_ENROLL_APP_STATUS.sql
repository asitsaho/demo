CREATE OR REPLACE PROCEDURE BDR_BI.SP_ISB_SF_AGT04A_ENROLL_APP_STATUS("PV_REPORTSTARTDATE" DATE, "PV_FREQUENCY" VARCHAR(1), "PV_AGENT_ID1" VARCHAR(16777216), "PV_AGENT_ID2" VARCHAR(16777216), "PV_AGENT_ID3" VARCHAR(16777216), "PV_AGENT_ID4" VARCHAR(16777216), "PV_AGENT_ID5" VARCHAR(16777216), "DB_NAME" VARCHAR(16777216) DEFAULT '', "TGT_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "TGT2_SC" VARCHAR(16777216) DEFAULT '', "SRC_SC" VARCHAR(16777216) DEFAULT 'SRC_COMPAS_D', "SRC2_SC" VARCHAR(16777216) DEFAULT 'SRC_DWADM', "SRC3_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "UTIL_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "PIPELINE_ID" VARCHAR(16777216) DEFAULT '', "PIPELINE_NAME" VARCHAR(16777216) DEFAULT 'SP_ISB_SF_AGT04A_ENROLL_APP_STATUS')
RETURNS TABLE ()
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE
res_lt RESULTSET;
select_statement VARCHAR;
V_CURRENT_DATE DATE := CURRENT_DATE();


M1 number;
I1 number;
																												 
															 

V_START_TIME TIMESTAMP;

V_STEP VARCHAR;
V_LAST_QUERY_ID    VARCHAR;
V_ROWS_LOADED   VARCHAR;
V_PROCESS_NAME   VARCHAR DEFAULT ''SP_ISB_SF_AGT04A_ENROLL_APP_STATUS'';
V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''SP_ISB_SF_AGT04A_ENROLL_APP_STATUS'';
V_STEP_NAME        VARCHAR;
V_ROWS_PARSED      INTEGER;
V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := COALESCE(:UTIL_SC, ''BDR_BI'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';

BEGIN

LET gv_Log_id  NUMBER := NULL;
LET gv_error_code    VARCHAR(200) := NULL;  
LET gv_frequency VARCHAR;

gv_frequency := pv_frequency; 


LET gv_ReportStartDate  DATE := :pv_ReportStartDate::DATE;

---New
----DWADM.CUSTOMER_DIM
----SRC_DWADM.CUSTOMER_DIM
LET V_CUSTOMER_DIM VARCHAR :=  :SRC2_SC || ''.CUSTOMER_DIM'';

----COMPAS.PAYMENT_METHOD_TYPE
----SRC_COMPAS_D.V_TT_PAYMENT_METHOD_TYPE
LET V_PAYMENT_METHOD_TYPE VARCHAR :=  :SRC_SC || ''.PAYMENT_METHOD_TYPE'';

----COMPAS.TITLE
----SRC_COMPAS.TITLE
LET V_TITLE VARCHAR :=  :SRC_SC || ''.TITLE'';

----COMPAS.APPLICATION_ACTOR
----SRC_COMPAS_D.V_TT_APPLICATION_ACTOR
LET V_APPLICATION_ACTOR VARCHAR :=  :SRC_SC || ''.APPLICATION_ACTOR'';

----COMPAS.AGENT_CHAR
----SRC_COMPAS.AGENT_CHAR
LET V_AGENT_CHAR VARCHAR :=  :SRC_SC || ''.AGENT_CHAR'';

----BI.VW_ADT_APPLICATION
----BDR_BI.VW_ADT_APPLICATION
LET V_VW_ADT_APPLICATION VARCHAR :=  :SRC3_SC || ''.VW_ADT_APPLICATION'';

----DWADM.MEMBERSHIP_DIM
----SRC_DWADM.MEMBERSHIP_DIM
LET V_MEMBERSHIP_DIM VARCHAR :=  :SRC2_SC || ''.MEMBERSHIP_DIM'';

----COMPAS.APPLICATION_REASON
----SRC_COMPAS_D.V_TT_APPLICATION_REASON
LET V_APPLICATION_REASON VARCHAR :=  :SRC_SC || ''.APPLICATION_REASON'';

							  
										 
																						  

----COMPAS.INDIVIDUAL
----COMPAS.INDIVIDUAL
LET V_INDIVIDUAL VARCHAR :=  :SRC_SC || ''.INDIVIDUAL'';

----COMPAS.HOUSEHOLD
----SRC_COMPAS_D.V_TT_HOUSEHOLD
LET V_HOUSEHOLD VARCHAR :=  :SRC_SC || ''.HOUSEHOLD'';

----PREM_BLOCK
----PREM_BLOCK
LET V_PREM_BLOCK VARCHAR :=  :TGT_SC || ''.PREM_BLOCK'';

----COMPAS.APPLICATION
----SRC_COMPAS_D.V_TT_APPLICATION
LET V_APPLICATION VARCHAR :=  :SRC_SC || ''.APPLICATION'';

----INDIVIDUAL_BILLING_BUCKET
----INDIVIDUAL_BILLING_BUCKET
LET V_INDIVIDUAL_BILLING_BUCKET VARCHAR :=  :TGT_SC || ''.INDIVIDUAL_BILLING_BUCKET'';

----COMPAS.HOUSEHOLD_BILLING_PROFILE
----SRC_COMPAS_D.V_TT_HOUSEHOLD_BILLING_PROFILE
LET V_HOUSEHOLD_BILLING_PROFILE VARCHAR :=  :SRC_SC || ''.HOUSEHOLD_BILLING_PROFILE'';

----COMPAS.PLAN_TYPE
----SRC_COMPAS_D.V_TT_PLAN_TYPE
LET V_PLAN_TYPE VARCHAR :=  :SRC_SC || ''.PLAN_TYPE'';

----COMPAS.APPLICATION_AGENT
----SRC_COMPAS_D.V_TT_APPLICATION_AGENT
LET V_APPLICATION_AGENT VARCHAR :=  :SRC_SC || ''.APPLICATION_AGENT'';

----COMPAS.REASON
----SRC_COMPAS_D.V_TT_REASON
LET V_REASON VARCHAR :=  :SRC_SC || ''.REASON'';

----COMPAS.TERMINATION_REASON
----SRC_COMPAS_D.V_TT_TERMINATION_REASON
LET V_TERMINATION_REASON VARCHAR :=  :SRC_SC || ''.TERMINATION_REASON'';

----DWADM.MEMBERSHIP_PER_BRIDGE
----SRC_DWADM.MEMBERSHIP_PER_BRIDGE
LET V_MEMBERSHIP_PER_BRIDGE VARCHAR :=  :SRC2_SC || ''.MEMBERSHIP_PER_BRIDGE'';

----COMPAS.APPLICATION_INDIVIDUAL
----SRC_COMPAS_D.V_TT_APPLICATION_INDIVIDUAL
LET V_APPLICATION_INDIVIDUAL VARCHAR :=  :SRC_SC || ''.APPLICATION_INDIVIDUAL'';

					  
						  
																			

----PV_REPORTRESULT
----PV_REPORTRESULT
LET V_PV_REPORTRESULT VARCHAR :=  :TGT_SC || ''.PV_REPORTRESULT'';

----COMPAS.APPLICATION_QUESTION
----SRC_COMPAS_D.V_TT_APPLICATION_QUESTION
LET V_APPLICATION_QUESTION VARCHAR :=  :SRC_SC || ''.APPLICATION_QUESTION'';

----COMPAS.INSURED_PLAN_PROFILE
----SRC_COMPAS_D.V_TT_INSURED_PLAN_PROFILE
LET V_INSURED_PLAN_PROFILE VARCHAR :=  :SRC_SC || ''.INSURED_PLAN_PROFILE'';

					 
					 
																		

							
									   
																					  

----COMPAS.INSURED_PLAN
----SRC_COMPAS_D.V_TT_INSURED_PLAN
LET V_INSURED_PLAN VARCHAR :=  :SRC_SC || ''.INSURED_PLAN'';

----APPLICATION_DATA
----APPLICATION_DATA
LET V_APPLICATION_DATA VARCHAR :=  :TGT_SC || ''.APPLICATION_DATA1'';

----COMPAS.HOUSEHOLD_MEMBER
----SRC_COMPAS_D.V_TT_HOUSEHOLD_MEMBER
LET V_HOUSEHOLD_MEMBER VARCHAR :=  :SRC_SC || ''.HOUSEHOLD_MEMBER'';

									
											   
																									  

----COMPAS.PLAN
----SRC_COMPAS_D.V_TT_PLAN
LET V_PLAN VARCHAR :=  :SRC_SC || ''.PLAN'';

----DWADM.BILL_FACT
----SRC_DWADM.BILL_FACT
LET V_BILL_FACT VARCHAR :=  :SRC2_SC || ''.BILL_FACT'';

----PLAN_DET
----PLAN_DET
LET V_PLAN_DET VARCHAR :=  :TGT_SC || ''.PLAN_DET'';

----COMPAS.AUTH_CHANNEL_TYPE
----SRC_COMPAS_D.V_TT_AUTH_CHANNEL_TYPE
LET V_AUTH_CHANNEL_TYPE VARCHAR :=  :SRC_SC || ''.AUTH_CHANNEL_TYPE'';

----COMPAS.INS_PLAN_BILLING_BUCKET
----COMPAS.INS_PLAN_BILLING_BUCKET
LET V_INS_PLAN_BILLING_BUCKET VARCHAR :=  :SRC_SC || ''.INS_PLAN_BILLING_BUCKET'';

							 
										
																						

----COMPAS.CONSERVATION_REASON
----SRC_COMPAS_D.V_TT_CONSERVATION_REASON
LET V_CONSERVATION_REASON VARCHAR :=  :SRC_SC || ''.CONSERVATION_REASON'';

----APP_DET
----APP_DET
LET V_APP_DET VARCHAR :=  :TGT_SC || ''.APP_DET'';

							
									   
LET V_FN_ISB_SF_CHK_MBR_PLN_CD VARCHAR :=  :TGT_SC || ''.'' || ''FN_ISB_SF_CHK_MBR_PLN_CD'';																					  

				
				
															  


--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP1'';
V_STEP_NAME :=  ''call BDR_BI.FN_ISB_SF_GET_LOG_ID() into'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

call BDR_BI.FN_ISB_SF_GET_LOG_ID()
    into :gv_Log_id;

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0 ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP2'';
V_STEP_NAME :=  ''CASE gv_frequency'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


CASE gv_frequency WHEN ''S'' THEN

call BDR_BI.SP_ISB_SF_INSERT_JOB_LOG(:gv_Log_id,''BI.PKG_ISB_EMPLOYER_REPORTS.SP_EA_NEW_RETIREES'',''AGT0004A_Enrollment_Application_Status_Spring_Smart_Match'');      
    
WHEN ''E'' THEN     
call BDR_BI.SP_ISB_SF_INSERT_JOB_LOG(:gv_Log_id,''BI.PKG_ISB_AGENT_REPORTS.SP_ISB_Enroll_App_Status'',''AGT0004A_Enrollment_Application_Status_Entrecor''); 
    
WHEN ''I'' THEN
call BDR_BI.SP_ISB_SF_INSERT_JOB_LOG(:gv_Log_id,''BI.PKG_ISB_AGENT_REPORTS.SP_ISB_Enroll_App_Status'',''AGT0004A_Enrollment_Application_Status_Insuractive'');  
END CASE;

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0 ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP3'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE PLAN_DET'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_PLAN_DET) AS											
    (											
    SELECT distinct p.PLAN_CD											
    FROM IDENTIFIER(:V_PLAN) P											
    JOIN IDENTIFIER(:V_plan_type) pt											
    on ( P.PLAN_TYPE_ID  = pt.PLAN_TYPE_ID											
    and pt.PLAN_CATEGORY_ID =1)											
    );

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_PLAN_DET)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP4'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE APPLICATION_DATA'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_APPLICATION_DATA) AS											
    ( SELECT distinct											
    a.*,											
    case when b.AGENT_TYPE_ID  = 2 then  b.AGENT_ID end  SELLING_AGENT_ID,      										
    ag.agent_id WRITTING_AGENT_ID,											
    ag1.agent_id Referral_Agent_ID,											
    least(adta.LAST_MODIFIED_DATE) AS withdrawn_date,											
    LISTAGG(R.EXTERNAL_FACING_REASON_TEXT, ''|'') WITHIN GROUP (ORDER BY ar.creation_date) OVER (PARTITION BY a.application_id) APPLICATION_REASON    										
    FROM IDENTIFIER(:V_application)  a											
    JOIN IDENTIFIER(:V_PLAN_DET) PD											
    on ( a.PLAN_REQUEST_1 = pd.plan_cd											
    and a.APPL_RECEIPT_DATE <= :gv_ReportStartDate    											
			  
    )											
    JOIN IDENTIFIER(:V_application_agent) b											
    ON (a.application_id = b.application_id											
    and b.AGENT_TYPE_ID in ( 2,5)      										
	   
			 
    and b.agent_id in (:pv_agent_id1,:pv_agent_id2,:pv_agent_id3,:pv_agent_id4)    										
    )											
                                                
    left join IDENTIFIER(:V_APPLICATION_REASON) AR											
    on (        a.application_id = ar.application_id											
    )											
    left join IDENTIFIER(:V_REASON) R											
    on ( AR.REASON_ID  = R.REASON_ID)											
    left join IDENTIFIER(:V_APPLICATION_AGENT) AG											
					 
 
    on ( a.application_id  = ag.application_id											
    and ag.agent_type_id = 1)											
    --											
    left join IDENTIFIER(:V_APPLICATION_AGENT) AG1               											
                    on ( a.application_id  = ag1.application_id     						
                         and ag1.agent_type_id = 5)                 					
    --											
    left join IDENTIFIER(:V_vw_adt_application)  adta											
    on ( a.application_id  = adta.application_id											
    and a.ADJUDICATION_CD = adta.ADJUDICATION_CD											
    and a.ADJUDICATION_CD = ''W'')											
    );

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_APPLICATION_DATA)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP5'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE INDIVIDUAL_BILLING_BUCKET'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_INDIVIDUAL_BILLING_BUCKET) as											
	(											
	select application_id, PREMIUM_DUE_AMT											
	from (											
 
	--#DIV/0!											
	select application_id , 											
							PREMIUM_DUE_AMT ,					
							row_number() over ( partition by  application_id order by BILLING_BUCKET_START_DATE desc) r_billing					
							from 					
					(							
	--#DIV/0!											
	select ad.application_id ,											
	IPBB.PREMIUM_DUE_AMT ,											
	--#NAME?											
	IPBB.BILLING_BUCKET_START_DATE	    --SCR79516/SCR79519										
	from											
	IDENTIFIER(:V_APPLICATION_DATA) AD											
	JOIN IDENTIFIER(:V_insured_plan) IP on											
	(  ip.individual_id = ad.individual_id											
	and ip.plan_cd = ad.PLAN_REQUEST_1											
	and ad.application_id = ip.application_id											
	)											
	join IDENTIFIER(:V_ins_plan_billing_bucket) IPBB											
	on (ip.INSURED_PLAN_ID = ipbb.INSURED_PLAN_ID											
	and ipbb.household_id = ad.household_id											
	and least(DATE_TRUNC(''day'', :V_CURRENT_DATE),IPBB.BILLING_BUCKET_STOP_DATE) between  
    IPBB.BILLING_BUCKET_START_DATE and IPBB.BILLING_BUCKET_STOP_DATE	--#DIV/0!										
	))) where r_billing =1  --SCR79516/SCR79519											
	);

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_INDIVIDUAL_BILLING_BUCKET)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

 



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP6'';
V_STEP_NAME :=  ''create or replace temporary table application_data123'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


 --------------------------------block added to incorporate function -> FN_CHECK_MEMBER_PLAN_CODE functionality



    create or replace temporary table application_data123 as select membership_number,insured_cd from IDENTIFIER(:V_Application_data);

    alter table application_data123 add column V_PLAN_CODE_IND1   varchar;

    LET c1 CURSOR FOR (SELECT * FROM application_data123);

    FOR record IN C1 DO
      M1 := record.MEMBERSHIP_NUMBER;
      I1 := record.INSURED_CD;
      call IDENTIFIER(:V_FN_ISB_SF_CHK_MBR_PLN_CD)(:M1,:I1);--IDENTIFIER(:V_FN_ISB_SF_CHK_MBR_PLN_CD)
    END FOR;

    ---------------------------------------------------------------------------------------------------------------

																		  

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM application_data123) ;
									 
							  
							
			

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

 



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP7'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE APP_DET'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());



CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_APP_DET) as											
    (
    SELECT  DISTINCT											
    ap.application_id ID_NUMBER,											
    ap.APPL_IMAGE_NUM_CURR as DCN,											
    case when ap.membership_number is null then NULL											
    else lpad(ap.membership_number,9,0)||''-''||ap.association_id||ap.insured_cd											
    END Membership_number ,											
    ''MS'' as PLAN_TYPE,											
    ap.APPL_RECEIPT_DATE as Application_Receipt_Date,											
    ap.ADJUDICATION_DATE AS Application_Adjudication_Date,ap.ADJUDICATION_DATE,											
    IP.INSURED_PLAN_TERMINATION_DATE as TERMINATION_DATE,											
    ip.insured_plan_id,											
    ind.individual_id AS individual_id,											
    ai.GENDER_CD GENDER,
    --(select t.TITLE_NAME from compas.title t where t.TITLE_ID = nvl( ai.NAME_SUFFIX,-9999)) AS Suffix
    CASE WHEN 
        ai.NAME_SUFFIX IS NOT NULL AND ai.NAME_SUFFIX <> '' '' 
        -- THEN (select t.TITLE_NAME from compas.title t where t.TITLE_ID = nvl( ai.NAME_SUFFIX,-9999)) 
		then t.TITLE_NAME				 
        END AS Suffix,											
    ap.DAY_PHONE_NUM    TELEPHONE_NUMBER,											
    ap.STREET_ADDRESS_1 ADDRESS_LINE_1,											
    ap.STREET_ADDRESS_2 ADDRESS_LINE_2,											
    ap.city ,											
    ap.state_cd STATE,											
    case when											
    Ap.INSURED_PLAN_EFFECTIVE_DATE between greatest(add_months(date_trunc(''MONTH'',AI.DATE_OF_BIRTH::DATE - 1),65*12), AI.PART_B_EFFECTIVE_DATE) and add_months(greatest(add_months(date_trunc(''MONTH'',AI.DATE_OF_BIRTH::date - 1),65*12), AI.PART_B_EFFECTIVE_DATE),7)											
    THEN ''OPEN ENROLLMENT''											
    when aq.QUESTION_ID =28 and aq.RESPONSE = ''Y''      											
    THEN ''Gauranteed Issue''											
    ELSE ''Underwritten''											
    END Enrollment_Type,											
    ap.zip_cd ZIP_CODE,											
    tr.termination_reason_name,										
    cr.CONSERVATION_REASON_NAME,											
    ap.APPLICATION_REASON,											
    ai.FIRST_NAME                             AS First_Name,											
    ai.LAST_NAME                              AS Last_Name,											
    ai.Middle_name                            AS Middle_Name,											
    to_CHAR(ai.date_of_birth,''MM/DD/YYYY'')    As Date_OF_Birth,											
    ind.MEDICARE_CLAIM_NUM                     AS "HICN/MBI",											
    case when ac.AUTH_CHANNEL_NAME = ''PPD''											
    THEN ''PAPER''											
    WHEN ac.AUTH_CHANNEL_NAME =  ''TEL''											
    then ''PHONE''											
    ELSE AC.AUTH_CHANNEL_NAME end  Application_Type,											
    case when ac.AUTH_CHANNEL_NAME = ''WEB'' and aa.APPLICATION_ACTOR_ID = 1 then ''Y''											
    ELSE ''N'' END Consumer_Self_Enroll_IND,											
    to_char( ip.INSURED_PLAN_EFFECTIVE_DATE,''MM/DD/YYYY'')        AS Effective_Date,--request is for latest state of plan											
    to_char( ap.withdrawn_date,''MM/DD/YYYY'') AS withdrawn_date,											
    case when aq.QUESTION_ID = 72 and aq.RESPONSE = ''Y''											
    THEN											
    ''Y''											
    ELSE ''N''											
    END TOBACO_USAGE,											
    case  ap.adjudication_cd											
    when ''A'' THEN ''ACCEPTED''											
    WHEN ''D'' THEN ''DENIED''											
    WHEN ''P'' THEN ''PENDING''											
    WHEN ''W'' THEN ''WITHDRAWN''											
    END  AS "STATUS" ,											
    ap.WRITTING_AGENT_ID as Writting_Agent_ID,											
    ap.SELLING_AGENT_ID as Selling_Agent_ID,											
    ap.Referral_Agent_ID as Referral_Agent_ID,    											
    ap.PLAN_REQUEST_1  AS Insured_Plan_Code ,											
    to_char(ipbb.PREMIUM_DUE_AMT)  as compas_Initial_Premium,											
    to_char(IBB.PREMIUM_DUE_AMT) as compas_Monthly_Premium,											
    ipp.RATE_DETERMINATION_CODE_ID AS compas_RDC,											
    pt.PAYMENT_METHOD_NAME,											
    to_char(hh.HHOLD_PAID_THROUGH_DATE ,''MM/DD/YYYY'') PAID_THROUGH_DATE,											
    ind.policy_number,
    CASE WHEN AP.ADJUDICATION_CD <> ''A'' THEN NULL

  --  ELSE BI.PKG_MSTR_FUNCTIONS.fn_check_member_plan_code(AP.membership_number, AP.insured_cd)
	ELSE ad123.V_PLAN_CODE_IND1						   
	
    END AS Plan_Change_Ind,
    row_number() over (partition by ap.application_id, IP.insured_plan_id order by ap.application_id,  ap.APPL_RECEIPT_DATE) r_mem  										
    FROM IDENTIFIER(:V_APPLICATION_DATA)  ap											

-- join added here

    JOIN Application_data123 ad123
    On ap.MEMBERSHIP_NUMBER=ad123.MEMBERSHIP_NUMBER and ap.INSURED_CD=ad123.INSURED_CD

-------------------
	
    JOIN IDENTIFIER(:V_application_individual) ai											
    ON (aP.application_id = ai.application_id)											
	LEFT JOIN identifier(:v_title) t on t.TITLE_ID::varchar = nvl( ai.NAME_SUFFIX,-9999)																				
    left JOIN IDENTIFIER(:V_Application_question) AQ											
    ON (aq.application_id = ap.application_id )											
    LEFT JOIN IDENTIFIER(:V_HOUSEHOLD_MEMBER) hm											
    on											
    (  hm.HOUSEHOLD_ID = ap.HOUSEHOLD_ID											
    and hm.INSURED_CD = ap.insured_cd											
															 
									  
									  
    and :gv_ReportStartDate::DATE + 1 between hm.HHOLD_MEMBER_START_DATE  and hm.HHOLD_MEMBER_STOP_DATE											
    )											
    LEFT JOIN IDENTIFIER(:V_HOUSEHOLD) HH											
    on											
    (  hm.HOUSEHOLD_ID = HH.HOUSEHOLD_ID											
    )											
    LEFT JOIN IDENTIFIER(:V_individual) IND											
    on											
    (  hm.individual_id = ind.individual_id											
    and ap.individual_id = ind.individual_id																						
    )											
    LEFT JOIN IDENTIFIER(:V_insured_plan) IP on											
    (  ip.individual_id = ind.individual_id											
    and ip.plan_cd = ap.PLAN_REQUEST_1											
    and ap.application_id = ip.application_id											
    )											
    left join IDENTIFIER(:V_ins_plan_billing_bucket) IPBB											
    on (ip.INSURED_PLAN_ID = ipbb.INSURED_PLAN_ID											
    and ipbb.household_id = ap.household_id											
    and ip.insured_plan_effective_date between IPBB.BILLING_BUCKET_START_DATE  and IPBB.BILLING_BUCKET_STOP_DATE											
    )																					
    left join IDENTIFIER(:V_INDIVIDUAL_BILLING_BUCKET) ibb	
on ( ap.application_id = ibb.application_id)
    left join IDENTIFIER(:V_insured_plan_profile) ipp	
on (ind.individual_id = ipp.individual_id	
and ip.insured_plan_id = ipp.insured_plan_id	
)
    left join IDENTIFIER(:V_TERMINATION_REASON) TR											
    on ( IP.TERMINATION_REASON_ID = TR.TERMINATION_REASON_ID)											
    LEFT JOIN IDENTIFIER(:V_CONSERVATION_REASON) CR											
    on ( ip.CONSERVATION_REASON_ID = CR.CONSERVATION_REASON_ID)											
    LEFT JOIN IDENTIFIER(:V_AUTH_CHANNEL_TYPE) AC											
    on ( ap.APPL_CHANNEL_ID = AC.AUTH_CHANNEL_TYPE_ID)											
    LEFT JOIN IDENTIFIER(:V_APPLICATION_ACTOR) AA											
    on ( ap.APPL_ACTOR_ID = AA.APPLICATION_ACTOR_ID)											
    left join IDENTIFIER(:V_agent_char)  AC1											
    on (											
    ac1.agent_id =  ap.SELLING_AGENT_ID											
    and ac1.AGENT_CHAR_TYPE_ID = 1											
    )											
    LEFT JOIN IDENTIFIER(:V_HOUSEHOLD_BILLING_PROFILE) HBP											
    ON (ap.household_id = hbp.household_id											
																	  
    AND :gv_ReportStartDate+1 BETWEEN hbp.HHOLD_BILLING_START_DATE										
    AND hbp.HHOLD_BILLING_STOP_DATE											
    )											
    LEFT JOIN IDENTIFIER(:V_PAYMENT_METHOD_TYPE) pt											
    ON (HBP.PAYMENT_METHOD_TYPE_ID = pt.PAYMENT_METHOD_TYPE_ID)
    );

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_APP_DET)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP8'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE PREM_BLOCK'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_PREM_BLOCK) AS 
    (
        SELECT 
            CUST_CURR_KEY,SUM(CALC_AMT) AS CALC_AMT,BF.BSEG_START_DT,BSEG_END_DT,CDDGEN1_VAL
        FROM 
								 
            IDENTIFIER(:V_BILL_FACT) BF
			
        WHERE 
            CDC_STATUS_FLAG<>''D'' AND BF.BILL_STATUS=''Complete'' -- Completed Bills
        GROUP BY 
            CUST_CURR_KEY,BF.BSEG_START_DT,BSEG_END_DT,CDDGEN1_VAL
    );

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_PREM_BLOCK)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP9'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE PV_REPORTRESULT'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_PV_REPORTRESULT) AS 
    select  AD.Membership_number as Membership_Number,											
    AD.Suffix,										
    AD.First_Name,											
    AD.Last_Name,											
    AD.Middle_Name,											
    AD.Date_OF_Birth,											
    AD."HICN/MBI",											
    AD.STATUS ,											
    AD.Writting_Agent_ID,											
    AD.Selling_Agent_ID,											
    AD.Referral_Agent_ID ,									
    AD.Insured_Plan_Code ,											
    CASE WHEN 
        SUM(INI_BF.CALC_AMT) IS NULL
        THEN sum(AD.compas_Initial_Premium)
        ELSE SUM(INI_BF.CALC_AMT)
    END AS Individual_Initial_Premium,
    CASE WHEN 
        SUM(CUR_BF.CALC_AMT) IS NULL AND SUM(INI_BF.CALC_AMT) IS NULL
        THEN sum(AD.compas_Monthly_Premium)
        ELSE SUM(CUR_BF.CALC_AMT)
    END AS Current_Monthly_Premium,											
    nvl(MD.CDF15_VAL,ad.compas_rdc) AS RDC,											
    AD.policy_number,											
    to_CHAR(AD.ID_NUMBER) AS ID_NUMBER,											
    AD.PLAN_TYPE,											
    to_char(AD.Application_Receipt_Date,''MM/DD/YYYY'') AS Application_Receipt_Date ,											
    withdrawn_date,											
    to_char(AD.Application_Adjudication_Date,''MM/DD/YYYY'') AS Issue_Date ,--changed column name to issue date											
    AD.Effective_Date,											
    to_char(AD.TERMINATION_DATE,''MM/DD/YYYY'') AS TERMINATION_DATE,											
    AD.TELEPHONE_NUMBER,											
    AD.ADDRESS_LINE_1,											
    AD.ADDRESS_LINE_2,											
    AD.CITY,											
    AD.STATE,											
    AD.ZIP_CODE,											
    AD.TERMINATION_REASON_NAME as TERMINATION_REASON,											
    AD.CONSERVATION_REASON_NAME as CONSERVATION_REASON,											
    AD.DCN,											
    Application_Type,											
    REGEXP_SUBSTR (AD.APPLICATION_REASON,''([^|]*)(\\\\\\\\\\\\\\\\||$)'',1,1,NULL,1) Reason_Description_1,											
    REGEXP_SUBSTR (AD.APPLICATION_REASON,''([^|]*)(\\\\\\\\\\\\\\\\||$)'',1,2,NULL,1) Reason_Description_2,											
    REGEXP_SUBSTR (AD.APPLICATION_REASON,''([^|]*)(\\\\\\\\\\\\\\\\||$)'',1,3,NULL,1) Reason_Description_3,											
    REGEXP_SUBSTR (AD.APPLICATION_REASON,''([^|]*)(\\\\\\\\\\\\\\\\||$)'',1,4,NULL,1) Reason_Description_4,											
    REGEXP_SUBSTR (AD.APPLICATION_REASON,''([^|]*)(\\\\\\\\\\\\\\\\||$)'',1,5,NULL,1) Reason_Description_5,											
    Consumer_Self_Enroll_IND,											
    AD.Enrollment_Type,											
    AD.GENDER,											
    AD.TOBACO_USAGE,
    CASE WHEN
        CD.CDF17_VAL IS NOT NULL AND TO_DATE(''01-''||TO_NUMBER(substr(CD.CDF17_VAL,6,2))||''-''||TO_NUMBER(substr(CD.CDF17_VAL,0,4)),''DD-MM-YYYY'')>=ADJUDICATION_DATE 
                AND AD.STATUS=''ACCEPTED'' 
                THEN ''Y'' ELSE ''N'' END AS Initial_Payment_Ind,										
    AD.PAYMENT_METHOD_NAME AS Payment_Type ,											
    AD.PAID_THROUGH_DATE,
    AD.Plan_Change_Ind as Previously_Enrolled,
    AD.Selling_Agent_ID as agent_id
    ,CURRENT_TIMESTAMP AS RUN_DATE   
    ,:gv_ReportStartDate AS gv_ReportStartDate
    FROM IDENTIFIER(:V_APP_DET) AD											
     LEFT OUTER JOIN IDENTIFIER(:V_CUSTOMER_DIM) CD ON CD.ID_VAL::STRING = AD.individual_id::STRING
						AND CD.ID_TYPE_CD = ''INDID''  -- INDIVIDUAL IDENTIFIER
						AND CD.CURR_REC_FLAG=''Y'' 	  -- ''Y'' Fetch Always Latest Records
  LEFT JOIN IDENTIFIER(:V_MEMBERSHIP_PER_BRIDGE) MPB ON MPB.PER_ID = CD.SRC_CUST_ID 
						AND MPB.MAIN_CUST_SW=''Y''    -- ''Y'' Fetch Always Latest Records
						AND MPB.CURR_REC_FLAG = ''Y''   -- ''Y'' Fetch Always Latest Records      
    LEFT JOIN IDENTIFIER(:V_MEMBERSHIP_DIM) MD ON MD.SRC_MEMBERSHIP_ID = MPB.SRC_MEMBERSHIP_ID 
						AND ad.insured_plan_id = MD.EXT_MEMBER_ID
						AND MD.CURR_REC_FLAG = ''Y'' -- ''Y'' Fetch Always Latest Records
    LEFT OUTER JOIN IDENTIFIER(:V_PREM_BLOCK) INI_BF ON CD.CUST_CURR_KEY=INI_BF.CUST_CURR_KEY 
						AND MD.MEMBERSHIP_START_DT BETWEEN INI_BF.BSEG_START_DT AND INI_BF.BSEG_END_DT
						AND INI_BF.CDDGEN1_VAL=MD.SRC_MEMBERSHIP_ID
    LEFT OUTER JOIN IDENTIFIER(:V_PREM_BLOCK) CUR_BF ON CD.CUST_CURR_KEY=CUR_BF.CUST_CURR_KEY 
						AND :gv_ReportStartDate BETWEEN CUR_BF.BSEG_START_DT AND CUR_BF.BSEG_END_DT
						and CUR_BF.CDDGEN1_VAL=MD.SRC_MEMBERSHIP_ID
    where r_mem = 1	
         AND AD.Selling_Agent_ID IN (:pv_agent_id1,:pv_agent_id2,:pv_agent_id3,:pv_agent_id4) 
    GROUP BY
        AD.Membership_number,											
        AD.Suffix,										
        AD.First_Name,											
        AD.Last_Name,											
        AD.Middle_Name,											
        AD.Date_OF_Birth,											
        AD."HICN/MBI",											
        AD.STATUS ,											
        AD.Writting_Agent_ID,											
        AD.Selling_Agent_ID,											
        AD.Referral_Agent_ID ,									
        AD.Insured_Plan_Code ,											
        MD.CDF15_VAL,		        
        ad.compas_rdc,
        AD.policy_number,											
        AD.ID_NUMBER,											
        AD.PLAN_TYPE,											
        AD.Application_Receipt_Date,											
        withdrawn_date,											
        AD.Application_Adjudication_Date,--changed column name to issue date											
        AD.Effective_Date,											
        AD.TERMINATION_DATE,											
        AD.TELEPHONE_NUMBER,											
        AD.ADDRESS_LINE_1,											
        AD.ADDRESS_LINE_2,											
        AD.CITY,											
        AD.STATE,											
        AD.ZIP_CODE,											
        AD.TERMINATION_REASON_NAME,											
        AD.CONSERVATION_REASON_NAME,											
        AD.DCN,											
        Application_Type,											
        AD.APPLICATION_REASON,										
        Consumer_Self_Enroll_IND,											
        AD.Enrollment_Type,											
        AD.GENDER,											
        AD.TOBACO_USAGE,
        -- CD.CDF17_VAL,
        Initial_Payment_Ind,
        AD.STATUS,										
        AD.PAYMENT_METHOD_NAME,											
        AD.PAID_THROUGH_DATE,
        AD.Plan_Change_Ind,
        AD.Selling_Agent_ID     
    order by Membership_Number;

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
					  
							

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_PV_REPORTRESULT)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
									

			

				  

--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP12'';
V_STEP_NAME :=  ''CALL BDR_BI.SP_ISB_SF_LOG_INSERT_COMPLETE(:gv_Log_id)'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CALL BDR_BI.SP_ISB_SF_LOG_INSERT_COMPLETE(:gv_Log_id);

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0 ;
   

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

	
						 
			
let res_set RESULTSET;
let select_statement1 := ''SELECT * FROM pv_ReportResult'';
res_set := (EXECUTE IMMEDIATE :select_statement1);
RETURN TABLE(res_set);																							  
																	
										  
									 
																	   
													  

EXCEPTION

WHEN OTHER THEN
											 
			  
											  
			 
																		 
							

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);

gv_error_code := SQLERRM;
CALL BDR_BI.SP_ISB_SF_LOG_INSERT_ERROR(:gv_Log_id, :gv_error_code);

RAISE;

END;

';