USE SCHEMA BDR_BI; CREATE OR REPLACE PROCEDURE "SP_ISB_SF_EMP32A_EMPL_BILL_CRT_UNBILL"("PV_REPORTSTARTDATE" DATE, "PV_REPORTSTOPDATE" DATE, "DB_NAME" VARCHAR(16777216) DEFAULT '', "TGT_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "TGT2_SC" VARCHAR(16777216) DEFAULT '', "SRC_SC" VARCHAR(16777216) DEFAULT 'SRC_DWADM', "SRC2_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "UTIL_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "PIPELINE_ID" VARCHAR(16777216) DEFAULT '', "PIPELINE_NAME" VARCHAR(16777216) DEFAULT 'SP_ISB_SF_EMP32A_EMPL_BILL_CRT_UNBILL')
RETURNS TABLE ()
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

    gv_ReportStartDate                DATE := DATE(pv_ReportStartDate);
    gv_ReportStopDate                 DATE := DATE(pv_ReportStopDate);
    gv_Log_id                         NUMBER;
    gv_error_code                     varchar(200);




V_START_TIME TIMESTAMP;

V_STEP VARCHAR;
V_LAST_QUERY_ID    VARCHAR;
V_ROWS_LOADED   VARCHAR;
V_PROCESS_NAME   VARCHAR DEFAULT ''SP_ISB_SF_EMP32A_EMPL_BILL_CRT_UNBILL'';
V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''SP_ISB_SF_EMP32A_EMPL_BILL_CRT_UNBILL'';
V_STEP_NAME        VARCHAR;
V_ROWS_PARSED      INTEGER;
V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := COALESCE(:UTIL_SC, ''BDR_BI'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';
BEGIN
----DWADM.CUSTOMER_DIM
----SRC_DWADM.CUSTOMER_DIM
LET V_CUSTOMER_DIM VARCHAR :=  :SRC_SC || ''.CUSTOMER_DIM'';

----MEMBERSHIP_DETAILS
----MEMBERSHIP_DETAILS
LET V_MEMBERSHIP_DETAILS VARCHAR :=  :TGT_SC || ''.MEMBERSHIP_DETAILS'';

----DWADM.FT_FACT
----SRC_DWADM.FT_FACT
LET V_FT_FACT VARCHAR :=  :SRC_SC || ''.FT_FACT'';

----DWADM.MEMBERSHIP_PER_BRIDGE
----SRC_DWADM.MEMBERSHIP_PER_BRIDGE
LET V_MEMBERSHIP_PER_BRIDGE VARCHAR :=  :SRC_SC || ''.MEMBERSHIP_PER_BRIDGE'';

----PV_REPORTRESULT
----PV_REPORTRESULT
LET V_PV_REPORTRESULT VARCHAR :=  :TGT_SC || ''.PV_REPORTRESULT'';

----DWADM.ADJUSTMENT_FACT
----SRC_DWADM.ADJUSTMENT_FACT
LET V_ADJUSTMENT_FACT VARCHAR :=  :SRC_SC || ''.ADJUSTMENT_FACT'';

----DWADM.CONTRACT_DIM
----SRC_DWADM.CONTRACT_DIM
LET V_CONTRACT_DIM VARCHAR :=  :SRC_SC || ''.CONTRACT_DIM'';

----FINAL_DTL
----FINAL_DTL
LET V_FINAL_DTL VARCHAR :=  :TGT_SC || ''.FINAL_DTL'';

----DWADM.ADJ_TYPE_DIM
----SRC_DWADM.ADJ_TYPE_DIM
LET V_ADJ_TYPE_DIM VARCHAR :=  :SRC_SC || ''.ADJ_TYPE_DIM'';

----PREV_DUE_CRED_DITS
----PREV_DUE_CRED_DITS
LET V_PREV_DUE_CRED_DITS VARCHAR :=  :TGT_SC || ''.PREV_DUE_CRED_DITS'';

----PREMIUM_DETAILS
----PREMIUM_DETAILS
LET V_PREMIUM_DETAILS VARCHAR :=  :TGT_SC || ''.PREMIUM_DETAILS'';

----DWADM.MEMBERSHIP_DIM
----SRC_DWADM.MEMBERSHIP_DIM
LET V_MEMBERSHIP_DIM VARCHAR :=  :SRC_SC || ''.MEMBERSHIP_DIM'';

----DWADM.BCHG_FACT
----SRC_DWADM.BCHG_FACT
LET V_BCHG_FACT VARCHAR :=  :SRC_SC || ''.BCHG_FACT'';

----DWADM.BILL_FACT
----SRC_DWADM.BILL_FACT
LET V_BILL_FACT VARCHAR :=  :SRC_SC || ''.BILL_FACT'';




--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP1'';
V_STEP_NAME :=  ''call BDR_BI.FN_ISB_SF_GET_LOG_ID()'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

call BDR_BI.FN_ISB_SF_GET_LOG_ID()
    into :gv_Log_id;

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0 ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP2'';
V_STEP_NAME :=  ''CALL BDR_BI.SP_ISB_SF_INSERT_JOB_LOG()'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CALL BDR_BI.SP_ISB_SF_INSERT_JOB_LOG(:gv_Log_id,''BI.PKG_ISB_EMPLOYER_REPORTS.SP_EMPLOYER_BILL_CREDIT_AND_UNBILLED'',''EMP0032A_ISB_Employer_Bill_Credit_and_Unbilled'');

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0 ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP3'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE PREMIUM_DETAILS'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

/*To fetch Records only for Premium Amount */
    CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_PREMIUM_DETAILS) AS
    (
    SELECT 
        CD.SRC_CUST_ID,
        BF.CDDGEN1_VAL AS MEMBERSHIP_ID,
        BF.DESCR_ON_BILL,
        SUM(BF.SVC_QTY) AS PREMIUM_AMT    
    FROM 
        IDENTIFIER(:V_BCHG_FACT) BF
        INNER JOIN IDENTIFIER(:V_CONTRACT_DIM) CO ON CO.CONTRACT_CURR_KEY = BF.CONTRACT_CURR_KEY
                AND CO.CURR_REC_FLAG = ''Y''
        INNER JOIN IDENTIFIER(:V_CUSTOMER_DIM) CD ON
                CD.SRC_CUST_ID = CO.CUST_ID
                AND CD.CURR_REC_FLAG = ''Y''-- ''Y'' Fetch Always Latest Records
                AND CD.ID_TYPE_CD = ''EMPID''
    WHERE 
        BF.BILLABLE_CHG_STAT= ''10'' 
        AND BF.CDC_STATUS_FLAG<>''D''
        AND ADD_MONTHS(:gv_ReportStartDate,2) BETWEEN DATE(BF.START_DT) AND DATE(BF.END_DT) 
    GROUP BY 
        CD.SRC_CUST_ID,BF.DESCR_ON_BILL,
        BF.CDDGEN1_VAL
    
    );

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_PREMIUM_DETAILS)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP4'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE PREV_DUE_CRED_DITS'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

/*To fetch Records only for Previous Premium Due */
    CREATE OR REPLACE TEMPORARY TABLE  IDENTIFIER(:V_PREV_DUE_CRED_DITS) AS
    (   
    SELECT * FROM
    (
    SELECT
        SRC_CUST_ID,
        MEMBERSHIP_ID,
        CASE 
                WHEN SUM(NVL(CALC_AMT,0)) > 0
                THEN SUM(NVL(CALC_AMT,0))
            END AS PRE_PREMIUM_DUE_AMT,
        CASE       
                WHEN SUM(NVL(CALC_AMT,0)) < 0
                THEN SUM(NVL(CALC_AMT,0))
            END AS CREDIT_AMOUNT
    FROM
        (
            SELECT
                SRC_CUST_ID,
                CDDGEN1_VAL AS MEMBERSHIP_ID, 
                START_DT,
                END_DT,
                SRC_BILLABLE_CHG_ID,
                NVL(SUM(SVC_QTY),0) AS CALC_AMT
            FROM
                (

                WITH date_cte AS (
   SELECT 
                                BCHG_FACT.START_DT, 
                                BCHG_FACT.END_DT, 
                                BCHG_FACT.PRICEITEM_CD, 
                                BCHG_FACT.SVC_QTY,
                                BCHG_FACT.CDDGEN1_VAL,
                                CUSTOMER_DIM.ID_TYPE_CD,
                                CUSTOMER_DIM.SRC_CUST_ID,
                                BCHG_FACT.SRC_BILLABLE_CHG_ID,
                            DATEDIFF(MONTH, start_dt, end_dt) + 1 AS month_diff
                            FROM 
                                IDENTIFIER(:V_BCHG_FACT) BCHG_FACT
                                INNER JOIN IDENTIFIER(:V_CONTRACT_DIM) CONTRACT_DIM ON
                                                   CONTRACT_DIM.CONTRACT_CURR_KEY = BCHG_FACT.CONTRACT_CURR_KEY          
                                                   AND CONTRACT_DIM.STATUS_DESCR = ''Active'' -- Active Contracts Only
                                                   AND CONTRACT_DIM.CURR_REC_FLAG=''Y'' -- ''Y'' Fetch Always Latest Records 
                                INNER JOIN IDENTIFIER(:V_CUSTOMER_DIM) CUSTOMER_DIM ON 
                                                   CUSTOMER_DIM.SRC_CUST_ID = CONTRACT_DIM.CUST_ID  
                                                   AND CUSTOMER_DIM.CURR_REC_FLAG=''Y''	-- ''Y'' Fetch Always Latest Records
                                                   AND CUSTOMER_DIM.ID_TYPE_CD = ''EMPID''
                            WHERE BCHG_FACT.BILLABLE_CHG_STAT=''10''
                            AND BCHG_FACT.CDC_STATUS_FLAG=''Y''
) 
SELECT 
    case when d.start_dt >= DATE_TRUNC(month,DATEADD(MONTH, row_num , d.start_dt)) then d.start_dt else DATE_TRUNC(month,DATEADD(MONTH, row_num , d.start_dt)) end AS start_dt,
case when start_dt >= LAST_DAY(DATEADD(MONTH, row_num , d.start_dt)) then start_dt else LAST_DAY(DATEADD(MONTH, row_num , d.start_dt)) end   AS end_dt,
    priceitem_cd,svc_qty,CDDGEN1_VAL,id_type_cd,SRC_CUST_ID,SRC_BILLABLE_CHG_ID
FROM date_cte d
JOIN (
    SELECT ROW_NUMBER() OVER (order by null) - 1 AS row_num
    FROM TABLE(GENERATOR(ROWCOUNT => 1000))
) seq_table
ON row_num < d.month_diff
ORDER BY  start_dt
                
                    -- SELECT
                    --             CASE
                    --                 WHEN 
                    --                     START_DT >= DATE(add_months(START_DT, - 1)) -- COLUMN_VALUE
                    --                 THEN 
                    --                    START_DT
                    --                 ELSE 
                    --                     TO_DATE(TO_CHAR(add_months(START_DT, - 1),''DD-MM-YYYY''),''DD-MM-YYYY'')
                    --             END START_DT,
                    --             CASE
                    --                 WHEN
                    --                     START_DT >= LAST_DAY(DATE(add_months(START_DT, - 1)))
                    --                 THEN 
                    --                    START_DT
                    --                 ELSE 
                    --                     TO_DATE(TO_CHAR(LAST_DAY(add_months(START_DT, - 1)),''DD-MM-YYYY''),''DD-MM-YYYY'')
                    --             END END_DT,
                    --             PRICEITEM_CD, SVC_QTY,CDDGEN1_VAL,ID_TYPE_CD,SRC_CUST_ID,SRC_BILLABLE_CHG_ID
                    --     FROM
                    --         (
                            -- SELECT 
                            --     BCHG_FACT.START_DT, 
                            --     BCHG_FACT.END_DT, 
                            --     BCHG_FACT.PRICEITEM_CD, 
                            --     BCHG_FACT.SVC_QTY,
                            --     BCHG_FACT.CDDGEN1_VAL,
                            --     CUSTOMER_DIM.ID_TYPE_CD,
                            --     CUSTOMER_DIM.SRC_CUST_ID,
                            --     BCHG_FACT.SRC_BILLABLE_CHG_ID,
                            -- DATEDIFF(MONTH, start_dt, end_dt) + 1 AS month_diff
                            -- FROM 
                            --     IDENTIFIER(:V_BCHG_FACT) BCHG_FACT
                            --     INNER JOIN IDENTIFIER(:V_CONTRACT_DIM) CONTRACT_DIM ON
                            --                        CONTRACT_DIM.CONTRACT_CURR_KEY = BCHG_FACT.CONTRACT_CURR_KEY          
                            --                        AND CONTRACT_DIM.STATUS_DESCR = ''Active'' -- Active Contracts Only
                            --                        AND CONTRACT_DIM.CURR_REC_FLAG=''Y'' -- ''Y'' Fetch Always Latest Records 
                            --     INNER JOIN IDENTIFIER(:V_CUSTOMER_DIM) CUSTOMER_DIM ON 
                            --                        CUSTOMER_DIM.SRC_CUST_ID = CONTRACT_DIM.CUST_ID  
                            --                        AND CUSTOMER_DIM.CURR_REC_FLAG=''Y''	-- ''Y'' Fetch Always Latest Records
                            --                        AND CUSTOMER_DIM.ID_TYPE_CD = ''EMPID''
                            -- WHERE BCHG_FACT.BILLABLE_CHG_STAT=''10''
                            -- AND BCHG_FACT.CDC_STATUS_FLAG=''Y''
                           
                    --         )
                            -- ,
                    --     TABLE(
                    --             CAST(
                    --                  MULTISET
                    --                          (SELECT LEVEL
                    --                           FROM DUAL
                    --                  CONNECT BY ADD_MONTHS(DATE(START_DT,''MM''),LEVEL - 1) <= END_DT
                    --                          ) AS SYS.ODCINUMBERLIST
                    --                 )
                    --            ) 

                    
                    ) BF
                     WHERE
                    BF.START_DT <= ADD_MONTHS(:gv_ReportStartDate,1)
                    AND NOT EXISTS (SELECT 1 FROM IDENTIFIER(:V_BILL_FACT) BF1 WHERE BF.SRC_BILLABLE_CHG_ID = BF1.SRC_BILLABLE_CHG_ID
                                                                                    AND DATE(BF1.BSEG_START_DT)= BF.START_DT --AND BF.END_DT 
                                                                                    AND BF1.BILL_STATUS = ''Complete'')
                GROUP BY
                    SRC_CUST_ID,
                    CDDGEN1_VAL,
                    START_DT,
                    END_DT,
                   SRC_BILLABLE_CHG_ID
         
         UNION ALL
         
            SELECT 
                CD.SRC_CUST_ID,
                BF.CDDGEN1_VAL AS MEMBERSHIP_ID,
                DATE(BF.BSEG_START_DT) AS START_DT,
                DATE(BF.BSEG_END_DT) AS END_DT,
                BF.SRC_BILLABLE_CHG_ID , 
                NVL(SUM(BF.CALC_AMT),0) AS CALC_AMT
            FROM 
                IDENTIFIER(:V_BILL_FACT) BF   
                INNER JOIN IDENTIFIER(:V_CUSTOMER_DIM) CD ON
                            CD.CUST_CURR_KEY = BF.CUST_CURR_KEY
                            AND CD.CURR_REC_FLAG = ''Y''-- ''Y'' Fetch Always Latest Records
                            AND CD.ID_TYPE_CD = ''EMPID''
                            AND (BF.MEVT_STATUS_FLG <> ''B'' OR BF.MEVT_STATUS_FLG IS NULL)--OPEN
            WHERE 
                BF.UDDGEN17 IS NULL 
				AND BF.FT_TYPE = ''BX''
                AND BF.CDC_STATUS_FLAG<>''D''
                AND BF.BILL_STATUS = ''Complete'' -- Fetching Complete Bills 
                AND DATE(BF.BSEG_START_DT) <= ADD_MONTHS(:gv_ReportStartDate,1)
            GROUP BY 
                CD.SRC_CUST_ID,
                BF.CDDGEN1_VAL,
                BF.BSEG_START_DT,
                BF.BSEG_END_DT,
                BF.SRC_BILLABLE_CHG_ID
        )        
        GROUP BY
            SRC_CUST_ID,
            MEMBERSHIP_ID
        )
    );

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_PREV_DUE_CRED_DITS)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP5'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE MEMBERSHIP_DETAILS'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

/*To fetch Records only for Membership Amount */
    CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_MEMBERSHIP_DETAILS) AS
    (
            SELECT
                AF.CDDGEN2_VAL AS MEMBER_NBR,
                TRIM(AF.CDDGEN3_VAL) AS INSURED_CD,
                SUM(FT.CUR_AMT) AS MEMBERSHIP_FEE
            FROM
                IDENTIFIER(:V_ADJUSTMENT_FACT) AF
                INNER JOIN IDENTIFIER(:V_ADJ_TYPE_DIM) ATD ON AF.ADJ_TYPE_CURR_KEY = ATD.ADJ_TYPE_CURR_KEY
                            AND ATD.CURR_REC_FLAG = ''Y''
                            AND ATD.SRC_ADJ_TYPE_CD = ''CMAARPAD''
                            AND AF.CDC_STATUS_FLAG<>''D''
                            AND AF.ADJ_STATUS_DESCR = ''Frozen''
                INNER JOIN IDENTIFIER(:V_FT_FACT) FT ON FT.SRC_FT_ID=AF.SRC_FT_ID 
                            AND FT.CDC_STATUS_FLAG<>''D''
                            AND FT.SRC_BILL_ID IS NULL
                INNER JOIN IDENTIFIER(:V_CUSTOMER_DIM) CUSTOMER_DIM ON
                            CUSTOMER_DIM.CUST_CURR_KEY = AF.CUST_CURR_KEY AND CUSTOMER_DIM.ID_TYPE_CD=''EMPID''
                            AND CUSTOMER_DIM.CURR_REC_FLAG = ''Y''-- ''Y'' Fetch Always Latest Records
             WHERE
                 DATE(AF.FREEZE_DT) BETWEEN ADD_MONTHS(:gv_ReportStartDate,1) AND ADD_MONTHS(:pv_ReportStopDate,1)
            GROUP BY
                AF.CDDGEN2_VAL,AF.CDDGEN3_VAL
    );

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_MEMBERSHIP_DETAILS)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP6'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE FINAL_DTL'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE  IDENTIFIER(:V_FINAL_DTL) AS 
    (
        SELECT 
            COMMENTS,
            EMPLOYER_ID,
            MEMBERSHIP_NUMBER,
            PERSON1_NAME,
            DEATH_INDICATOR,
            HOUSEHOLD_ID,
            NVL(SUM(PREMIUM_AMOUNT),0) AS PREMIUM_AMOUNT,
            NVL(SUM(PREV_PREMIUM_DUE_AMOUNT),0) AS PREV_PREMIUM_DUE_AMOUNT,
            NVL(SUM(CREDIT_AMOUNT),0) AS CREDIT_AMOUNT,        
            NVL(SUM(MEMBERSHIP_AMOUNT),0) AS MEMBERSHIP_AMOUNT,
            (( NVL(SUM(PREMIUM_AMOUNT),0) +
                NVL(SUM(PREV_PREMIUM_DUE_AMOUNT),0) +
                NVL(SUM(CREDIT_AMOUNT),0)) + NVL(SUM(MEMBERSHIP_AMOUNT),0) 
            ) AS TOTAL_DUE_AMOUNT,
            CURRENT_TIMESTAMP AS REPORT_DATE,
            :gv_ReportStartDate AS START_DATE,
            :pv_ReportStopDate AS END_DATE
        FROM
            (
            SELECT 
                '' '' AS COMMENTS,
                EMP.EMPLOYER_ID,
                (CUST.CDF3_VAL || ''-'' || CUST.CDF12_VAL || CUST.CDF5_VAL) AS MEMBERSHIP_NUMBER,
                CUST.NAME AS PERSON1_NAME,
                CASE
                    WHEN 
                        CUST.CDF9_VAL IS NOT NULL 
                    THEN ''Y'' 
                    ELSE '' '' 
                END AS DEATH_INDICATOR,
                CUST.CDF4_VAL AS HOUSEHOLD_ID,
                NVL(SUM(PREMIUM_DETAILS.PREMIUM_AMT),0) AS PREMIUM_AMOUNT,
                CASE
                    WHEN 
                        NVL(SUM(PREV_DUE_CRED_DITS.PRE_PREMIUM_DUE_AMT),0) + NVL(SUM(PREV_DUE_CRED_DITS.CREDIT_AMOUNT),0) > 0
                    THEN
                        NVL(SUM(PREV_DUE_CRED_DITS.PRE_PREMIUM_DUE_AMT),0) + NVL(SUM(PREV_DUE_CRED_DITS.CREDIT_AMOUNT),0)
                    ELSE 0    
                END AS PREV_PREMIUM_DUE_AMOUNT,
                CASE
                    WHEN 
                        NVL(SUM(PREV_DUE_CRED_DITS.PRE_PREMIUM_DUE_AMT),0) + NVL(SUM(PREV_DUE_CRED_DITS.CREDIT_AMOUNT),0) < 0
                    THEN
                        NVL(SUM(PREV_DUE_CRED_DITS.PRE_PREMIUM_DUE_AMT),0) + NVL(SUM(PREV_DUE_CRED_DITS.CREDIT_AMOUNT),0)
                    ELSE 0    
                END AS CREDIT_AMOUNT,        
                TO_NUMBER(0) AS MEMBERSHIP_AMOUNT
            FROM
            IDENTIFIER(:V_CUSTOMER_DIM) CUST
            INNER JOIN 
                (
                SELECT
                    CUSTOMER_EMP.ID_VAL_3 AS EMPLOYER_ID,
                    CUSTOMER_EMP.NAME AS EMPLOYER_NAME,
                    CUSTOMER_EMP.SRC_CUST_ID,
                    CUSTOMER_EMP.CUST_CURR_KEY
                FROM
                    IDENTIFIER(:V_CUSTOMER_DIM) CUSTOMER_EMP
                WHERE 
                    CUSTOMER_EMP.CUST_TYPE = ''Parent Customer'' 
                    AND CUSTOMER_EMP.CURR_REC_FLAG=''Y''-- ''Y'' Fetch Always Latest Records
                    AND CUSTOMER_EMP.ID_TYPE_CD = ''EMPID'' -- Fetching Only Employer
                ) EMP ON CUST.PARENT_CUST_ID = EMP.SRC_CUST_ID
            INNER JOIN IDENTIFIER(:V_MEMBERSHIP_PER_BRIDGE) MPB ON MPB.PER_ID = CUST.SRC_CUST_ID AND MPB.CURR_REC_FLAG=''Y''
            INNER JOIN IDENTIFIER(:V_MEMBERSHIP_DIM) MD ON MD.SRC_MEMBERSHIP_ID = MPB.SRC_MEMBERSHIP_ID AND MD.CURR_REC_FLAG=''Y''
            LEFT JOIN IDENTIFIER(:V_PREMIUM_DETAILS) PREMIUM_DETAILS ON
                PREMIUM_DETAILS.SRC_CUST_ID = EMP.SRC_CUST_ID AND MD.SRC_MEMBERSHIP_ID = PREMIUM_DETAILS.MEMBERSHIP_ID
           LEFT JOIN IDENTIFIER(:V_PREV_DUE_CRED_DITS) PREV_DUE_CRED_DITS ON
                PREV_DUE_CRED_DITS.SRC_CUST_ID = EMP.SRC_CUST_ID AND MD.SRC_MEMBERSHIP_ID = PREV_DUE_CRED_DITS.MEMBERSHIP_ID       
            WHERE
                CUST.CDF11_VAL IN (''1'',''2'') and -- Exclude Non-Affiliated Members
                CUST.ID_TYPE_CD = ''INDID'' AND -- Individual Identifier
                CUST.CURR_REC_FLAG=''Y'' -- ''Y'' Fetch Always Latest Records
            GROUP BY
                EMP.EMPLOYER_ID,
                CUST.CDF3_VAL,
                CUST.CDF5_VAL,
                CUST.NAME,
                CUST.CDF9_VAL,
                CUST.CDF4_VAL,
                CUST.CDF12_VAL
                
            UNION ALL
            
            SELECT 
                '' '' AS COMMENTS,
                EMP.EMPLOYER_ID,
                (CUST.CDF3_VAL || ''-'' || CUST.CDF12_VAL || CUST.CDF5_VAL) AS MEMBERSHIP_NUMBER,
                CUST.NAME AS PERSON1_NAME,
                CASE
                    WHEN 
                        CUST.CDF9_VAL IS NOT NULL 
                    THEN ''Y'' 
                    ELSE '' '' 
                END AS DEATH_INDICATOR,
                CUST.CDF4_VAL AS HOUSEHOLD_ID,
                TO_NUMBER(0) AS PREMIUM_AMOUNT,
                TO_NUMBER(0) AS PREV_PREMIUM_DUE_AMOUNT,
                TO_NUMBER(0) AS CREDIT_AMOUNT,        
                NVL(SUM(MEMBERSHIP_DETAILS.MEMBERSHIP_FEE),0) AS MEMBERSHIP_AMOUNT
            FROM
            IDENTIFIER(:V_CUSTOMER_DIM) CUST
            INNER JOIN 
                (
                SELECT
                    CUSTOMER_EMP.ID_VAL_3 AS EMPLOYER_ID,
                    CUSTOMER_EMP.NAME AS EMPLOYER_NAME,
                    CUSTOMER_EMP.SRC_CUST_ID,
                    CUSTOMER_EMP.CUST_CURR_KEY
                FROM
                    IDENTIFIER(:V_CUSTOMER_DIM) CUSTOMER_EMP
                WHERE 
                    CUSTOMER_EMP.CUST_TYPE = ''Parent Customer'' 
                    AND CUSTOMER_EMP.CURR_REC_FLAG=''Y''-- ''Y'' Fetch Always Latest Records
                    AND CUSTOMER_EMP.ID_TYPE_CD = ''EMPID'' -- Fetching Only Employer
                ) EMP ON CUST.PARENT_CUST_ID = EMP.SRC_CUST_ID
            LEFT JOIN IDENTIFIER(:V_MEMBERSHIP_DETAILS) MEMBERSHIP_DETAILS ON 
            MEMBERSHIP_DETAILS.MEMBER_NBR = CUST.CDF3_VAL AND MEMBERSHIP_DETAILS.INSURED_CD = CUST.CDF5_VAL
            WHERE
                CUST.CDF11_VAL IN (''1'',''2'') and -- Exclude Non-Affiliated Members
                CUST.ID_TYPE_CD = ''INDID'' AND -- Individual Identifier
                CUST.CURR_REC_FLAG=''Y'' -- ''Y'' Fetch Always Latest Records
            GROUP BY
                EMP.EMPLOYER_ID,
                CUST.CDF3_VAL,
                CUST.CDF5_VAL,
                CUST.NAME,
                CUST.CDF9_VAL,
                CUST.CDF4_VAL,
                CUST.CDF12_VAL
            )
        
            GROUP BY
            COMMENTS,
            EMPLOYER_ID,
            MEMBERSHIP_NUMBER,
            PERSON1_NAME,
            DEATH_INDICATOR,
            HOUSEHOLD_ID
            ORDER BY CREDIT_AMOUNT DESC, PREV_PREMIUM_DUE_AMOUNT ASC
   );

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_FINAL_DTL)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP7'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE PV_REPORTRESULT'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_PV_REPORTRESULT) AS
    SELECT
         * 
    FROM 
        IDENTIFIER(:V_FINAL_DTL)
    WHERE 
        TOTAL_DUE_AMOUNT <> 0 AND (PREV_PREMIUM_DUE_AMOUNT <> 0 OR CREDIT_AMOUNT <> 0 );

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_PV_REPORTRESULT)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP8'';
V_STEP_NAME :=  ''CALL BDR_BI.SP_ISB_SF_LOG_INSERT_COMPLETE(:gv_Log_id)'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CALL BDR_BI.SP_ISB_SF_LOG_INSERT_COMPLETE(:gv_Log_id);

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0 ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);





let res_set RESULTSET;
let select_statement1 := ''SELECT * FROM pv_ReportResult'';
res_set := (EXECUTE IMMEDIATE :select_statement1);
RETURN TABLE(res_set);

EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);

gv_error_code := SQLERRM;
CALL BDR_BI.SP_ISB_SF_LOG_INSERT_ERROR(:gv_Log_id, :gv_error_code);

RAISE;

END;

';