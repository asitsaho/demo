USE SCHEMA BDR_BI; CREATE OR REPLACE PROCEDURE "ZZHIP"()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE
  V_CURRENT_DATE DATE :=  CURRENT_DATE();
    last_saturday DATE;
    first_date_last_month DATE;
    last_date_last_month DATE;
    last_sunday DATE;
    V_LAST_SATURDAY_DATE VARCHAR(16777216);
    V_FIRST_DATE_OF_LAST_MONTH VARCHAR(16777216);
    V_LAST_DATE_OF_LAST_MONTH VARCHAR(16777216);
    V_LAST_SUNDAY_DATE VARCHAR(16777216);
BEGIN
 
    last_saturday := DATEADD(''day'', -((DAYOFWEEK(V_CURRENT_DATE) + 1) % 7), V_CURRENT_DATE);

    first_date_last_month := DATE_TRUNC(''month'', DATEADD(''month'', -1, V_CURRENT_DATE));

    last_date_last_month := DATE_TRUNC(''month'', V_CURRENT_DATE) - INTERVAL ''1 day'';

    last_sunday := DATEADD(''day'', -((DAYOFWEEK(V_CURRENT_DATE) % 7)), V_CURRENT_DATE);

    V_LAST_SATURDAY_DATE := TO_CHAR(last_saturday, ''YYYY-MM-DD'');
    V_FIRST_DATE_OF_LAST_MONTH := TO_CHAR(first_date_last_month, ''YYYY-MM-DD'');
    V_LAST_DATE_OF_LAST_MONTH := TO_CHAR(last_date_last_month, ''YYYY-MM-DD'');
    V_LAST_SUNDAY_DATE := TO_CHAR(last_sunday, ''YYYY-MM-DD'');
  
   --stmt := select * from  UBLIA_TST_ISDC_DEV_DB.SRC_FOX.FOXIMPORT limit 100;
   RETURN V_LAST_SATURDAY_DATE;

END;
 
';