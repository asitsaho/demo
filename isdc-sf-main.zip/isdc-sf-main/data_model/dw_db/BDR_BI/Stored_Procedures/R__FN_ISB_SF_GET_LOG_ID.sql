CREATE OR REPLACE PROCEDURE BDR_BI.FN_ISB_SF_GET_LOG_ID()
RETURNS NUMBER(38,0)
LANGUAGE SQL
EXECUTE AS CALLER
AS '
BEGIN
let V_Job_id Number;

create  sequence if not exists BDR_BI.Seq_CMP_Report_Log start with 10000 increment by 1 order;

SELECT BDR_BI.Seq_CMP_Report_Log.NEXTVAL INTO :V_Job_id;
INSERT INTO BDR_BI.FUNCTION_VARIABLE_MAP VALUES (''FN_GET_LOG_ID'',''V_Job_id'',''NUMBER'',:V_Job_id);
RETURN :V_Job_id;
	   
EXCEPTION
    WHEN OTHER THEN 
        V_Job_id := 0;
        INSERT INTO BDR_BI.FUNCTION_VARIABLE_MAP VALUES (''FN_GET_LOG_ID'',''V_Job_id'',''NUMBER'',:V_Job_id);
        RETURN :V_Job_id;
END;
';