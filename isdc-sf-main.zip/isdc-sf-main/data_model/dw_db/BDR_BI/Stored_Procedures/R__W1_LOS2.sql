USE SCHEMA BDR_BI;



CREATE OR REPLACE PROCEDURE "W1_LOS"("DB_NAME" VARCHAR(16777216), "UTIL_SC" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

V_STEP VARCHAR;
V_LAST_QUERY_ID    VARCHAR;
V_ROWS_LOADED   VARCHAR;
V_PROCESS_NAME   VARCHAR DEFAULT ''W1_LOS'';
V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''W1_LOS'';
V_STEP_NAME        VARCHAR;
V_ROWS_PARSED      INTEGER;
--V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := :DB_NAME||''.''||COALESCE(:UTIL_SC, ''UTIL'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';
V_START_TIME       VARCHAR;

--------------------------------------------------------------------------------------

BEGIN

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP1'';

--V_STEP_NAME :=  ''CREATE TABLE W1_Claims_17_23'';

V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE W1_Claims_17_23 AS SELECT 
 clmbl.D_MBR_INFO_SK
,clmbl.clm_nbr
,clmbl.Incur_dt_id
,clmbl.Clm_pd_dt_id
,pln.PRDCT_TYP
,pln.pln_lvl as plan
,rt.ST_CD as state
,clmbl.tos_cd 
,sum(clmbl.adj_ben_amt) as adj_ben_amt
,sum(clmbl.Hosp_day_ben_amt) as Hosp_day_ben_amt

from bdr_dm.V_F_CLM_BIL_LN_HIST clmbl 
join bdr_conf.v_D_BEN           ben  on clmbl.D_BEN_SK = ben.D_BEN_SK
JOIN bdr_conf.V_D_PLN_BEN_MOD 	pln  ON clmbl.D_PLN_BEN_MOD_SK = pln.D_PLN_BEN_MOD_SK
JOIN bdr_conf.V_D_CALC_RT 		  rt   on clmbl.D_CALC_RT_SK=rt.D_CALC_RT_SK

WHERE clmbl.CLM_PD_DT_ID  <= 20240431
  and clmbl.INCUR_DT_ID   >= 20170101
  and pln.prdct = ''Med Supp''
  and ben.ben_lvl in (''W1'',''WQ'')
  and ADJ_BEN_AMT >0  
  and D_MBR_INFO_SK>0
group by
 clmbl.D_MBR_INFO_SK
,clmbl.clm_nbr
,clmbl.Incur_dt_id
,clmbl.Clm_pd_dt_id
,pln.PRDCT_TYP
,pln.pln_lvl 
,rt.ST_CD  
,clmbl.tos_cd 
order by 
clmbl.D_MBR_INFO_SK
,clmbl.clm_nbr
,clmbl.Incur_dt_id;


V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
--V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:)) ;

--CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISDW'', :PIPELINE_ID, --:PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
--                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, --:V_ROWS_LOADED, NULL, NULL, NULL);




EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);


RAISE;
    
END;
';