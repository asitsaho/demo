CREATE OR REPLACE PROCEDURE BDR_BI.SP_ISB_SF_BIL67A_PREM_PAY_TRANS_T4("PV_REPORTSTARTDATE" DATE, "PV_REPORTSTOPDATE" DATE, "DB_NAME" VARCHAR DEFAULT '', "TGT_SC" VARCHAR DEFAULT 'BDR_BI', "TGT2_SC" VARCHAR DEFAULT '', "SRC_SC" VARCHAR DEFAULT 'SRC_DWADM', "SRC2_SC" VARCHAR DEFAULT 'SRC_DWADM', "SRC3_SC" VARCHAR DEFAULT 'SRC_COMPAS_D', "UTIL_SC" VARCHAR DEFAULT 'BDR_BI', "PIPELINE_ID" VARCHAR DEFAULT '', "PIPELINE_NAME" VARCHAR DEFAULT 'SP_ISB_SF_BIL67A_PREM_PAY_TRANS_T4')
RETURNS TABLE ()
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

  gv_ReportStartDate                DATE := DATE(pv_ReportStartDate);
  gv_ReportStopDate                 DATE := DATE(pv_ReportStopDate);
  gv_Log_id                         NUMBER;
  gv_error_code                     varchar(200);





V_START_TIME TIMESTAMP;

V_STEP VARCHAR;
V_LAST_QUERY_ID    VARCHAR;
V_ROWS_LOADED   VARCHAR;
V_PROCESS_NAME   VARCHAR DEFAULT ''SP_ISB_SF_BIL67A_PREM_PAY_TRANS_T4'';
V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''SP_ISB_SF_BIL67A_PREM_PAY_TRANS_T4'';
V_STEP_NAME        VARCHAR;
V_ROWS_PARSED      INTEGER;
V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := COALESCE(:UTIL_SC, ''BDR_BI'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';
BEGIN
----DWADM.TNDR_TYPE_DIM
----SRC_DWADM.TNDR_TYPE_DIM
LET V_TNDR_TYPE_DIM VARCHAR :=  :SRC_SC || ''.TNDR_TYPE_DIM'';

----COMPAS.HOUSEHOLD_PROFILE
----SRC_COMPAS_D.V_TT_HOUSEHOLD_PROFILE
LET V_HOUSEHOLD_PROFILE VARCHAR :=  :SRC3_SC || ''.HOUSEHOLD_PROFILE'';

----DWADM.CI_APAY_CLR_STG_VW
----BDR_BI.CI_APAY_CLR_STG_VW
LET V_CI_APAY_CLR_STG_VW VARCHAR :=  :SRC2_SC || ''.CI_APAY_CLR_STG_VW'';

----DWADM.PAYMENT_FACT
----SRC_DWADM.PAYMENT_FACT
LET V_PAYMENT_FACT VARCHAR :=  :SRC_SC || ''.PAYMENT_FACT'';

----MAIN_TAB4
----MAIN_TAB4
LET V_MAIN_TAB4 VARCHAR :=  :TGT_SC || ''.MAIN_TAB4'';

----PV_REPORTRESULT
----PV_REPORTRESULT
LET V_PV_REPORTRESULT VARCHAR :=  :TGT_SC || ''.PV_REPORTRESULT'';

----DWADM.CI_ACCT_APAY_VW
----BDR_BI.CI_ACCT_APAY_VW
LET V_CI_ACCT_APAY_VW VARCHAR :=  :SRC2_SC || ''.CI_ACCT_APAY_VW'';

----PAYMENT_DTLS
----PAYMENT_DTLS
LET V_PAYMENT_DTLS VARCHAR :=  :TGT_SC || ''.PAYMENT_DTLS'';

----DWADM.CUSTOMER_DIM
----SRC_DWADM.CUSTOMER_DIM
LET V_CUSTOMER_DIM VARCHAR :=  :SRC_SC || ''.CUSTOMER_DIM'';




--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP1'';
V_STEP_NAME :=  ''call BDR_BI.FN_ISB_SF_GET_LOG_ID()'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

call BDR_BI.FN_ISB_SF_GET_LOG_ID()
    into :gv_Log_id;

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0 ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP2'';
V_STEP_NAME :=  ''CALL BDR_BI.SP_ISB_SF_INSERT_JOB_LOG(:gv_Log_id)'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CALL BDR_BI.SP_ISB_SF_INSERT_JOB_LOG(:gv_Log_id,''BI.PKG_ISB_BILL_REPORTS.SP_ISB_SHIP_Premium_Payment_Transactions_T4'',''BIL0067A_ISB_ SHIP Premium Payment Transactions TAB4'');

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0 ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP3'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE PAYMENT_DTLS'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_PAYMENT_DTLS) AS 
    (
        SELECT 
            SRC_FT_ID,
            SRC_PAY_EVENT_ID,
            SRC_PAY_TNDR_ID 
        FROM (
            SELECT 
                SRC_PAY_EVENT_ID,
                SRC_FT_ID,
                SRC_MATCH_TYPE_CD,
                SRC_PAY_TNDR_ID,
                FREEZE_DT,
                ROW_NUMBER() OVER (PARTITION BY SRC_PAY_EVENT_ID ORDER BY FREEZE_DT) AS RNK 
            FROM 
                IDENTIFIER(:V_PAYMENT_FACT)
            WHERE
                CDC_STATUS_FLAG <> ''D'' 
			 AND EXTRACT(YEAR FROM FREEZE_DT) BETWEEN EXTRACT(YEAR FROM ADD_MONTHS(:gv_ReportStartDate,-13)) and EXTRACT(YEAR FROM :gv_ReportStartDate)   --US150301
            ORDER BY
                SRC_PAY_EVENT_ID,FREEZE_DT  --US150301
            ) 
        WHERE RNK=1
    );

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_PAYMENT_DTLS)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP4'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE MAIN_TAB4'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_MAIN_TAB4) AS
(
    SELECT
        MONTH_YEAR,
        SUM("Web 1x CC Transactions") AS "Web 1x CC Transactions",
        SUM("Quickpay1x CC Transactions") AS "Quickpay1x CC Transactions",
        SUM("Total number of Optum CSS 1X CC payments") AS "Total number of Optum CSS 1X CC payments",
        SUM(TOTAL_PAYMENT) AS TOTAL_PAYMENT,
        CASE WHEN 
            SUM(TOTAL_PAYMENT) = 0
            THEN 1
            ELSE SUM(TOTAL_PAYMENT)
        END AS TOTAL,
        SUM("Total Recurring EFT Transactions (all payment sources)") AS "Total Recurring EFT Transactions (all payment sources)"
FROM
    (
    SELECT
        --MEMBER_NUMBER,    --US150301
        SRC_PAY_EVENT_ID,
        MONTH_YEAR,
        SUM("Web 1x CC Transactions") AS "Web 1x CC Transactions",
        SUM("Quickpay1x CC Transactions") AS "Quickpay1x CC Transactions",
        SUM("Total number of Optum CSS 1X CC payments") AS "Total number of Optum CSS 1X CC payments",
        (SUM("Web 1x CC Transactions") +
        SUM("Quickpay1x CC Transactions") +
        SUM("Total number of Optum CSS 1X CC payments")) AS TOTAL_PAYMENT,
        SUM("Total Recurring EFT Transactions (all payment sources)") AS "Total Recurring EFT Transactions (all payment sources)"
        FROM
        (
        --SELECT DISTINCT   --US150301
        SELECT --US150301
        --(CD.CDF3_VAL || ''-'' || CD.CDF5_VAL) AS MEMBER_NUMBER, --US150301
        PF.SRC_PAY_EVENT_ID,
        TO_DATE(''01/''||TO_CHAR(PF.FREEZE_DT,''MON/YYYY''),''DD/MON/YYYY'') AS MONTH_YEAR,
        CASE
            WHEN PF.TNDR_TYPE_CD IN (''ACHS'',''ACHC'') AND EXISTS (select 1 from IDENTIFIER(:V_CI_APAY_CLR_STG_VW) where ACCT_APAY_ID <>'' '' and APAY_SRC_CD<>''PENSION-FRS''
                                        and SCHED_EXTRACT_DT is not null AND CDC_FLAG <> ''D'' AND pay_tender_id = pf.src_pay_tndr_id)
            THEN 1
            ELSE 0
        END AS "Total Recurring EFT Transactions (all payment sources)",
        CASE
            WHEN PF.UDDGEN19 IN (''WEB'') AND PF.TNDR_TYPE_CD IN (''CCAP'') AND PF.UDDGEN18 IN (''ONETIMECCSYS'')
            THEN 1
            ELSE 0
        END AS "Web 1x CC Transactions",
        CASE
            WHEN PF.UDDGEN19 IN (''WEB-QUICKPAY'') AND PF.TNDR_SRC_CD = ''JPMCC'' 
            THEN 1
            ELSE 0
        END AS "Quickpay1x CC Transactions",
        CASE
            WHEN PF.UDDGEN19 IN (''IVR'',''TEL'',''PHONE'') AND PF.TNDR_TYPE_CD IN (''CCAP'') AND PF.UDDGEN18 IN (''ONETIMECCSYS'')
            THEN 1
            ELSE 0
        END AS "Total number of Optum CSS 1X CC payments",
        ROW_NUMBER() OVER(PARTITION BY PF.SRC_PAY_EVENT_ID,PF.SRC_PAY_TNDR_ID ORDER BY PF.FREEZE_DT) AS RNK --US150301
        FROM
        IDENTIFIER(:V_PAYMENT_FACT) PF
        INNER JOIN IDENTIFIER(:V_PAYMENT_DTLS) PAYMENT_DTLS ON PAYMENT_DTLS.SRC_FT_ID=PF.SRC_FT_ID 
                                        AND PAYMENT_DTLS.SRC_PAY_EVENT_ID=PF.SRC_PAY_EVENT_ID  
                                        AND PAYMENT_DTLS.SRC_PAY_TNDR_ID=PF.SRC_PAY_TNDR_ID 
        INNER JOIN IDENTIFIER(:V_TNDR_TYPE_DIM) TTD ON TTD.SRC_TNDR_TYPE_CD = PF.TNDR_TYPE_CD
                    AND TTD.CURR_REC_FLAG = ''Y'' -- ''Y'' Fetch Always Latest Records
                    AND PF.FT_TYPE = ''Pay Segment'' 
                    AND PF.CDC_STATUS_FLAG <> ''D''  
    --                AND PF.TNDR_SRC_CD <> ''TI_CMPS''
        LEFT JOIN   IDENTIFIER(:V_CI_APAY_CLR_STG_VW) CLRSTG ON CLRSTG.PAY_TENDER_ID=PF.SRC_PAY_TNDR_ID                 
                            AND CLRSTG.SCHED_EXTRACT_DT IS NOT NULL
                            AND CLRSTG.ACCT_APAY_ID <>'' ''
                            AND CLRSTG.CDC_FLAG <> ''D''
        LEFT JOIN IDENTIFIER(:V_CI_ACCT_APAY_VW) AAV ON AAV.ACCT_APAY_ID = CLRSTG.ACCT_APAY_ID
                    AND AAV.AUTH_CHANNEL_TYPE_ID IN (''1'',''2'',''5'',''6'')
        INNER JOIN IDENTIFIER(:V_CUSTOMER_DIM) CD ON CD.CUST_CURR_KEY = PF.CUST_CURR_KEY 
                                AND CD.CURR_REC_FLAG = ''Y'' -- ''Y'' Fetch Always Latest Records
        LEFT JOIN IDENTIFIER(:V_HOUSEHOLD_PROFILE) HP ON HP.HOUSEHOLD_ID = CD.CDF4_VAL
                                AND HP.DELETE_IND <> ''Y'' -- ''Y'' Fetch Always Latest Records
                                AND :gv_ReportStartDate BETWEEN date(HP.HHOLD_PROFILE_START_DATE) AND date(HP.HHOLD_PROFILE_STOP_DATE)
                                
        
        WHERE    
        --to_char(add_months(PF.FREEZE_DT,-0),''yyyy'') BETWEEN TO_CHAR(ADD_MONTHS(:gv_ReportStartDate,-13),''yyyy'') AND TO_CHAR(:gv_ReportStartDate,''YYYY'')   --US150301
        EXTRACT(YEAR FROM PF.FREEZE_DT) BETWEEN EXTRACT(YEAR FROM ADD_MONTHS(:gv_ReportStartDate,-13)) and EXTRACT(YEAR FROM :gv_ReportStartDate)   --US150301
    )
    GROUP BY
     --MEMBER_NUMBER,
     SRC_PAY_EVENT_ID,
        MONTH_YEAR
    HAVING
    ((SUM("Web 1x CC Transactions") +
        SUM("Quickpay1x CC Transactions") +
        SUM("Total number of Optum CSS 1X CC payments")) <> ''0''
     OR 
     SUM("Total Recurring EFT Transactions (all payment sources)") <> ''0'')

------------------#### resolution is below
    --     UNION ALL
    -- /*To get Default 13 Months*/
    -- SELECT DISTINCT
    --     ''000000000-0'' AS MEMBER_NUMBER,
    --     '''' AS SRC_PAY_EVENT_ID,
    --     CASE
    --     WHEN 
    --         start_date >= DATE(add_months(start_date,COLUMN_VALUE - 1),''MM'')
    --     THEN 
    --        start_date
    --     ELSE 
    --         TO_DATE(TO_CHAR(DATE(add_months(start_date,COLUMN_VALUE - 1),''MM''),''DD-MM-YYYY''),''DD-MM-YYYY'')
    --     END MONTH_YEAR,
    --     TO_NUMBER(0) AS "Web 1x CC Transactions",
    --     TO_NUMBER(0) AS "Quickpay1x CC Transactions",
    --     TO_NUMBER(0) AS "Total number of Optum CSS 1X CC payments",
    --     TO_NUMBER(''0'') AS TOTAL_PAYMENT,
    --     TO_NUMBER(0) AS "Total Recurring EFT Transactions (all payment sources)"
        
    -- FROM 
    --     (
    --         SELECT 
    --             ADD_MONTHS(DATE(:gv_ReportStartDate,''MM''),-12) AS START_DATE,
    --             LAST_DAY(:gv_ReportStartDate) AS END_DATE 
            
                
    --     ),
    --     /*Sample date is splited into monthly basis and nested using multiset operator*/
    -- TABLE(
    --     CAST(
    --          MULTISET
    --                  (SELECT LEVEL,dummy from  (select ''X'' dummy ) DUAL
    --          CONNECT BY ADD_MONTHS(date(START_DATE,''MM''),PRIOR LEVEL - 1) <= END_DATE) AS --SYS.ODCINUMBERLIST
    --         )
    --    )
------------------#### resolution is below
    UNION ALL
    SELECT DISTINCT
        --''000000000-0'' AS MEMBER_NUMBER,   --US150301
        '''' AS SRC_PAY_EVENT_ID,
        ADD_MONTHS(DATE_TRUNC(''month'',ADD_MONTHS(:gv_ReportStartDate,-12)),(row_number()over(order by null)-1)) as MONTH_YEAR,
        TO_NUMBER(0) AS "Web 1x CC Transactions",
        TO_NUMBER(0) AS "Quickpay1x CC Transactions",
        TO_NUMBER(0) AS "Total number of Optum CSS 1X CC payments",
        TO_NUMBER(''0'') AS TOTAL_PAYMENT,
        TO_NUMBER(0) AS "Total Recurring EFT Transactions (all payment sources)"
         
FROM table(generator(rowcount => 13))


    ) 
    --WHERE --US150301
    --MONTH_YEAR BETWEEN ADD_MONTHS(:gv_ReportStartDate,-12) AND :gv_ReportStartDate    --US150301
        GROUP BY
        MONTH_YEAR
        ORDER BY MONTH_YEAR DESC
);

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_MAIN_TAB4)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP5'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE PV_REPORTRESULT'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_PV_REPORTRESULT) AS
    SELECT
        MONTH_YEAR,
        "Web 1x CC Transactions",
        ROUND(NVL(("Web 1x CC Transactions"/TOTAL),0) * 100,2) AS "% of Web 1x CC Payments",
        "Quickpay1x CC Transactions",
        ROUND(NVL(("Quickpay1x CC Transactions"/TOTAL),0) * 100,2) AS "% of QuickPay 1x CC Payments",
        "Total number of Optum CSS 1X CC payments",
        ROUND(NVL(("Total number of Optum CSS 1X CC payments"/TOTAL),0) * 100,2) AS "% of OCSS 1x CC Payments",
        "Total 1x CC Transactions",
        "Total Recurring EFT Transactions (all payment sources)",
        (NVL(round((("Total Recurring EFT Transactions (all payment sources)" - LEAD("Total Recurring EFT Transactions (all payment sources)") OVER(ORDER BY MONTH_YEAR desc)) 
            /"Total Recurring EFT Transactions") * 100,2),0)) AS "Recurring EFT  % Change (Month Over Month)",
        CURRENT_TIMESTAMP() AS RUN_DATE,
        :gv_ReportStartDate AS START_DATE,
        :gv_ReportStopDate AS END_DATE
    FROM
        (
            SELECT
                MONTH_YEAR,
                SUM("Web 1x CC Transactions") AS "Web 1x CC Transactions",
                SUM("Quickpay1x CC Transactions") AS "Quickpay1x CC Transactions",
                SUM("Total number of Optum CSS 1X CC payments") AS "Total number of Optum CSS 1X CC payments",
                SUM(NVL(TOTAL_PAYMENT,0)) AS "Total 1x CC Transactions",
                SUM(TOTAL) AS TOTAL,
                SUM("Total Recurring EFT Transactions (all payment sources)") AS "Total Recurring EFT Transactions (all payment sources)",
                SUM(CASE WHEN 
                    "Total Recurring EFT Transactions (all payment sources)" = 0 
                    THEN 1
                    ELSE "Total Recurring EFT Transactions (all payment sources)"
                END) AS "Total Recurring EFT Transactions"
            FROM
                IDENTIFIER(:V_MAIN_TAB4)
            GROUP BY
                MONTH_YEAR
        )
        WHERE MONTH_YEAR BETWEEN ADD_MONTHS(:gv_ReportStartDate,-12) AND :gv_ReportStartDate    --US150301
        ;

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_PV_REPORTRESULT)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP6'';
V_STEP_NAME :=  ''CALL BDR_BI.SP_ISB_SF_LOG_INSERT_COMPLETE(:gv_Log_id)'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CALL BDR_BI.SP_ISB_SF_LOG_INSERT_COMPLETE(:gv_Log_id);

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0 ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);





let res_set RESULTSET;
let select_statement1 := ''SELECT * FROM pv_ReportResult'';
res_set := (EXECUTE IMMEDIATE :select_statement1);
RETURN TABLE(res_set);

EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);

gv_error_code := SQLERRM;
CALL BDR_BI.SP_ISB_SF_LOG_INSERT_ERROR(:gv_Log_id, :gv_error_code);

RAISE;

END;

';