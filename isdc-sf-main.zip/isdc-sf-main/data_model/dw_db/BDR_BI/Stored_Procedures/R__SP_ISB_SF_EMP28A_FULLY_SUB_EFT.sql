USE SCHEMA BDR_BI; CREATE OR REPLACE PROCEDURE "SP_ISB_SF_EMP28A_FULLY_SUB_EFT"("PV_REPORTSTARTDATE" DATE, "DB_NAME" VARCHAR(16777216) DEFAULT '', "TGT_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "TGT2_SC" VARCHAR(16777216) DEFAULT '', "SRC_SC" VARCHAR(16777216) DEFAULT 'SRC_DWADM', "SRC2_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "UTIL_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "PIPELINE_ID" VARCHAR(16777216) DEFAULT '', "PIPELINE_NAME" VARCHAR(16777216) DEFAULT 'SP_ISB_SF_EMP28A_FULLY_SUB_EFT')
RETURNS TABLE ()
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

    gv_ReportStartDate                DATE := DATE(pv_ReportStartDate);
    gv_Log_id                         NUMBER;
    gv_error_code                     varchar(200);
    v_Current_Year                    VARCHAR :=  TO_CHAR(DATE(pv_ReportStartDate),''YYYY'');
    v_Previous_Year                   VARCHAR :=  TO_CHAR(DATE(pv_ReportStartDate),''YYYY'')-1;
    v_Month                           VARCHAR :=  TO_CHAR(DATE(pv_ReportStartDate),''MON'');
    v_StartDate                        DATE;
    v_EndDate                          DATE;
    


V_START_TIME TIMESTAMP;

V_STEP VARCHAR;
V_LAST_QUERY_ID    VARCHAR;
V_ROWS_LOADED   VARCHAR;
V_PROCESS_NAME   VARCHAR DEFAULT ''SP_ISB_SF_EMP28A_FULLY_SUB_EFT'';
V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''SP_ISB_SF_EMP28A_FULLY_SUB_EFT'';
V_STEP_NAME        VARCHAR;
V_ROWS_PARSED      INTEGER;
V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := COALESCE(:UTIL_SC, ''BDR_BI'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';
BEGIN
----DWADM.BILL_FACT
----SRC_DWADM.BILL_FACT
LET V_BILL_FACT VARCHAR :=  :SRC_SC || ''.BILL_FACT'';

----DWADM.CI_ACCT_APAY_VW
----BDR_BI.CI_ACCT_APAY_VW
LET V_CI_ACCT_APAY_VW VARCHAR :=  :SRC2_SC || ''.CI_ACCT_APAY_VW'';

----DWADM.CUSTOMER_DIM
----SRC_DWADM.CUSTOMER_DIM
LET V_CUSTOMER_DIM VARCHAR :=  :SRC_SC || ''.CUSTOMER_DIM'';

----DWADM.ACCOUNT_DIM
----SRC_DWADM.ACCOUNT_DIM
LET V_ACCOUNT_DIM VARCHAR :=  :SRC_SC || ''.ACCOUNT_DIM'';

----PV_REPORTRESULT
----PV_REPORTRESULT
LET V_PV_REPORTRESULT VARCHAR :=  :TGT_SC || ''.PV_REPORTRESULT'';




--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP1'';
V_STEP_NAME :=  ''call BDR_BI.FN_ISB_SF_GET_LOG_ID()'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

call BDR_BI.FN_ISB_SF_GET_LOG_ID()
    into :gv_Log_id;

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0 ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP2'';
V_STEP_NAME :=  ''CALL BDR_BI.SP_ISB_SF_INSERT_JOB_LOG()'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CALL BDR_BI.SP_ISB_SF_INSERT_JOB_LOG(:gv_Log_id,''BI.PKG_ISB_EMPLOYER_REPORTS.SP_ISB_FULLY_SUBSIDIZED'',''EMP0028A_ISB_Fully_Subsidized_With_EFT'');

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0 ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP3'';
V_STEP_NAME :=  ''IF  :v_Month IN '';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

IF  (v_Month IN (''JAN'',''FEB'',''MAR'')) THEN
                 v_StartDate := ''01-OCT-''|| :v_Previous_Year;
                 v_EndDate  := ''31-DEC-''|| :v_Previous_Year;
             ELSEIF (v_Month IN (''APR'',''MAY'',''JUN'')) THEN
                    v_StartDate := ''01-JAN-''|| :v_Current_Year;
                    v_EndDate  := ''31-MAR-''|| :v_Current_Year;
             ELSEIF (v_Month IN (''JUL'',''AUG'',''SEP'')) THEN
                    v_StartDate := ''01-APR-''|| :v_Current_Year;
                    v_EndDate  := ''30-JUN-''|| :v_Current_Year;
              ELSEIF (v_Month IN (''OCT'',''NOV'',''DEC'')) THEN
                   v_StartDate := ''01-JUL-''|| :v_Current_Year;
                   v_EndDate  := ''30-SEP-''|| :v_Current_Year;
             END IF;

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0 ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);





--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP4'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE PV_REPORTRESULT'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_PV_REPORTRESULT) AS
        
   SELECT  DISTINCT
    MEMBERSHIP_NUMBER,
    EMPLOYER_ID,
    EMPLOYER_NAME,
    NAME,
    HHOLD_BILL_START_DATE,
    CURRENT_TIMESTAMP AS RUN_DATE,

    :v_StartDate AS BILL_START_DATE,
    :v_EndDate AS BILL_END_DATE
    
    
        FROM (
                SELECT
                (CD.CDF3_VAL ||''-''||CD.CDF12_VAL || CD.CDF5_VAL) AS MEMBERSHIP_NUMBER,
                CD.NAME,
                EMP.EMPLOYER_ID,
                EMP.EMPLOYER_NAME,
                CD.CDF4_VAL AS HOUSEHOLD_ID,
                BF.BILL_DT,
                AAV.START_DT AS HHOLD_BILL_START_DATE,
                BF.SRC_BILL_ID,
                SUM(BF.CALC_AMT) AS BILL_AMT
                FROM
                IDENTIFIER(:V_BILL_FACT) BF
                INNER JOIN IDENTIFIER(:V_CUSTOMER_DIM) CD ON CD.CUST_CURR_KEY = BF.CUST_CURR_KEY
                                AND CD.CURR_REC_FLAG = ''Y'' -- ''Y'' Fetch Always Latest Records
                                AND CD.ID_TYPE_CD = ''INDID'' -- Individual Identifier
                                AND BF.BILL_STATUS = ''Complete'' -- Complete Bills
                                AND BF.CDC_STATUS_FLAG <> ''D''
                INNER JOIN IDENTIFIER(:V_ACCOUNT_DIM) AD ON AD.CUST_ID = CD.SRC_CUST_ID
                                AND AD.CURR_REC_FLAG = ''Y'' -- ''Y'' Fetch Always Latest Records
                INNER JOIN IDENTIFIER(:V_CI_ACCT_APAY_VW) AAV ON AAV.ACCT_ID = AD.SRC_ACCT_ID 
                                AND (AAV.END_DT IS NULL OR AAV.END_DT >= current_timestamp)
                                AND AAV.PAYMENT_METHOD_TYPE_ID = ''3'' -- Payment Method Type EFT
                INNER JOIN (
                            SELECT
                            CUSTOMER_EMP.ID_VAL AS EMPLOYER_ID,
                            CUSTOMER_EMP.NAME AS EMPLOYER_NAME,
                            CUSTOMER_EMP.SRC_CUST_ID
                            FROM
                            IDENTIFIER(:V_CUSTOMER_DIM) CUSTOMER_EMP
                            WHERE CUSTOMER_EMP.CUST_TYPE = ''Parent Customer'' 
                                AND CUSTOMER_EMP.CURR_REC_FLAG=''Y'' -- ''Y'' Fetch Always Latest Records
                                AND CUSTOMER_EMP.ID_TYPE_CD = ''EMPID''  -- Employer Identifier
                            ) EMP ON CD.PARENT_CUST_ID = EMP.SRC_CUST_ID 
              WHERE (DATE(BSEG_START_DT) >= :v_StartDate 
                        AND DATE(BSEG_END_DT)<= :v_EndDate
                      )
            AND EXISTS /*Households that have not used their EFT for 4 consecutive months*/
            (
                SELECT
                COUNT(*)
                FROM
                        (
                            SELECT 
                            BF1.BSEG_START_DT,NVL(SUM(BF1.CALC_AMT),1) AS AMT
                            FROM
                            IDENTIFIER(:V_BILL_FACT) BF1
                            WHERE 
                            BF1.BSEG_START_DT BETWEEN ADD_MONTHS(:v_StartDate,-1) AND :v_EndDate
                            AND BF1.CUST_CURR_KEY = CD.CUST_CURR_KEY
--                            AND BF1.MEMBERSHIP_CURR_KEY = BF.MEMBERSHIP_CURR_KEY
                            AND BF1.BILL_STATUS = ''Complete'' -- Complete Bills
                            AND BF1.BSEG_STAT_FLG = 50 -- Cancellation Statue of Bill Segemnets
                            AND BF1.CDC_STATUS_FLAG <> ''D''
                            GROUP BY
                            BF1.BSEG_START_DT
                            HAVING 
                            NVL(SUM(BF1.CALC_AMT),1) = 0 
                        )
                        HAVING
            COUNT(*) = 4 --Households that have not used their EFT for 4 consecutive months
            )
            
            AND EXISTS
           (
           SELECT * FROM (
                SELECT
                ROUND(MONTHS_BETWEEN(:v_EndDate,AV.START_DT),0) Months
                FROM
                IDENTIFIER(:V_CI_ACCT_APAY_VW) AV
                WHERE
                AV.ACCT_APAY_ID = AAV.ACCT_APAY_ID                 
                )
            WHERE
                Months >= 4
           
           )
        GROUP BY
        CD.CDF3_VAL,
        CD.CDF12_VAL,
        CD.CDF5_VAL,
        CD.NAME,
        EMP.EMPLOYER_ID,
        EMP.EMPLOYER_NAME,
        CD.CDF4_VAL,
        BF.BILL_DT,
        AAV.START_DT,
        BF.SRC_BILL_ID
        )
    WHERE 
    BILL_AMT = 0;

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_PV_REPORTRESULT)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);






let res_set RESULTSET;
let select_statement1 := ''SELECT * FROM pv_ReportResult'';
res_set := (EXECUTE IMMEDIATE :select_statement1);
RETURN TABLE(res_set);

EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);

gv_error_code := SQLERRM;
CALL BDR_BI.SP_ISB_SF_LOG_INSERT_ERROR(:gv_Log_id, :gv_error_code);

RAISE;

END;

';