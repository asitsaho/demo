CREATE OR REPLACE PROCEDURE BDR_BI.SP_ISB_SF_BIL67A_PREM_PAY_TRANS_T1("PV_REPORTSTARTDATE" DATE, "PV_REPORTSTOPDATE" DATE, "DB_NAME" VARCHAR(16777216) DEFAULT '', "TGT_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "TGT2_SC" VARCHAR(16777216) DEFAULT '', "SRC_SC" VARCHAR(16777216) DEFAULT 'SRC_DWADM', "SRC2_SC" VARCHAR(16777216) DEFAULT 'SRC_COMPAS_D', "SRC3_SC" VARCHAR(16777216) DEFAULT 'SRC_DWADM', "UTIL_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "PIPELINE_ID" VARCHAR(16777216) DEFAULT '', "PIPELINE_NAME" VARCHAR(16777216) DEFAULT 'SP_ISB_SF_BIL67A_PREM_PAY_TRANS_T1')
RETURNS TABLE ()
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DecLARE

  GV_REPORTSTARTDATE                DATE := DATE(pv_ReportStartDate);
  gv_ReportStopDate                 DATE := DATE(pv_ReportStopDate);
  gv_Log_id                         NUMBER;
  gv_error_code                     varchar(200);




V_START_TIME TIMESTAMP;

V_STEP VARCHAR;
V_LAST_QUERY_ID    VARCHAR;
V_ROWS_LOADED   VARCHAR;
V_PROCESS_NAME   VARCHAR DEFAULT ''SP_ISB_SF_BIL67A_PREM_PAY_TRANS_T1'';
V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''SP_ISB_SF_BIL67A_PREM_PAY_TRANS_T1'';
V_STEP_NAME        VARCHAR;
V_ROWS_PARSED      INTEGER;
V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := COALESCE(:UTIL_SC, ''BDR_BI'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';
BEGIN
----COMPAS.HOUSEHOLD_PROFILE
----SRC_COMPAS.HOUSEHOLD_PROFILE
LET V_HOUSEHOLD_PROFILE VARCHAR :=  :SRC2_SC || ''.HOUSEHOLD_PROFILE'';

----MAIN_DTL
----MAIN_DTL
LET V_MAIN_DTL VARCHAR :=  :TGT_SC || ''.MAIN_DTL'';

----MAIN
----MAIN
LET V_MAIN VARCHAR :=  :TGT_SC || ''.MAIN'';

----DWADM.ACCOUNT_DIM
----SRC_DWADM.ACCOUNT_DIM
LET V_ACCOUNT_DIM VARCHAR :=  :SRC_SC || ''.ACCOUNT_DIM'';

----DWADM.CI_ACCT_APAY_VW
----SRC_BDR_BI.CI_ACCT_APAY_VW
LET V_CI_ACCT_APAY_VW VARCHAR :=  :SRC3_SC || ''.CI_ACCT_APAY_VW'';

----DWADM.CUSTOMER_DIM
----SRC_DWADM.CUSTOMER_DIM
LET V_CUSTOMER_DIM VARCHAR :=  :SRC_SC || ''.CUSTOMER_DIM'';

----PV_REPORTRESULT
----PV_REPORTRESULT
LET V_PV_REPORTRESULT VARCHAR :=  :TGT_SC || ''.PV_REPORTRESULT'';




--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP1'';
V_STEP_NAME :=  ''call BDR_BI.FN_ISB_SF_GET_LOG_ID()'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

call BDR_BI.FN_ISB_SF_GET_LOG_ID()
    into :gv_Log_id;

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0 ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP2'';
V_STEP_NAME :=  ''CALL BDR_BI.SP_ISB_SF_INSERT_JOB_LOG()'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CALL BDR_BI.SP_ISB_SF_INSERT_JOB_LOG(:gv_Log_id,''BI.PKG_ISB_BILL_REPORTS.SP_ISB_SHIP_Premium_Payment_Transactions_T1'',''BIL0067A_ISB_ SHIP Premium Payment Transactions TAB1'');

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0 ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP3'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE MAIN_DTL'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_MAIN_DTL) AS
(
   SELECT
   MON,SETUP_DT,END_DT,CURRENT_YEAR,
   "OLE","Member Web","OCSS CSR Voice Signature","OCSS POS Voice Signature",
    CASE WHEN
         ("OLE" IS NULL AND "Member Web" IS NULL AND "OCSS CSR Voice Signature" IS NULL AND "OCSS POS Voice Signature" IS NULL)
         THEN MEM_CNT
    END AS "Paper",
    CASE
        WHEN "OLE" = "OLE"
        THEN ''OLE''
        WHEN "Member Web" = "Member Web"
        THEN ''Member Web''
        WHEN "OCSS CSR Voice Signature" = "OCSS CSR Voice Signature"
        THEN ''OCSS CSR Voice Signature''
        WHEN "OCSS POS Voice Signature" = "OCSS POS Voice Signature"
        THEN ''OCSS POS Voice Signature''
        WHEN ("OLE" IS NULL AND "Member Web" IS NULL AND "OCSS CSR Voice Signature" IS NULL AND "OCSS POS Voice Signature" IS NULL)
        THEN ''Paper''
    END AS "RECURRING EFT CHANNEL"
   FROM
    (           
            SELECT 
            UPPER(MONTH(:GV_REPORTSTARTDATE)) AS MON,
            DATE(AAV.SETUP_DT) AS SETUP_DT,
            DATE(AAV.END_DT) AS END_DT,
            YEAR(AAV.SETUP_DT) AS CURRENT_YEAR,
            CASE 
            WHEN SUBSTR(AAV.AUTH_IMAGE_NUMBER ,6,2) = ''WB'' 
            THEN COUNT(CD.CDF3_VAL || ''-'' || CD.CDF5_VAL)
            END AS "OLE", 
            CASE 
            WHEN substr(AAV.AUTH_IMAGE_NUMBER,-10)=''MEMBER_WEB'' 
            THEN COUNT(CD.CDF3_VAL || ''-'' || CD.CDF5_VAL) 
            END AS "Member Web",
            CASE 
            WHEN substr(AAV.AUTH_IMAGE_NUMBER,-6)=''SIEBEL'' 
            THEN COUNT(CD.CDF3_VAL || ''-'' || CD.CDF5_VAL)
            END AS "OCSS CSR Voice Signature",
            CASE 
            WHEN substr(AAV.AUTH_IMAGE_NUMBER,-3)=''POS''
            THEN COUNT(CD.CDF3_VAL || ''-'' || CD.CDF5_VAL)
            END AS "OCSS POS Voice Signature",
            COUNT(CD.CDF3_VAL || ''-'' || CD.CDF5_VAL) AS MEM_CNT
            FROM
            IDENTIFIER(:V_CI_ACCT_APAY_VW) AAV 
            INNER JOIN IDENTIFIER(:V_ACCOUNT_DIM) AD ON AAV.ACCT_ID = AD.SRC_ACCT_ID 
                                AND AD.CURR_REC_FLAG = ''Y'' 
                                AND AAV.AUTH_CHANNEL_TYPE_ID IN (''1'',''2'',''3'')
                               AND AAV.AUTH_IMAGE_NUMBER NOT LIKE ''%N''	 
            INNER JOIN IDENTIFIER(:V_CUSTOMER_DIM) CD ON CD.SRC_CUST_ID = AD.CUST_ID 
                                AND CD.CURR_REC_FLAG = ''Y''
            INNER JOIN IDENTIFIER(:V_HOUSEHOLD_PROFILE) HP ON HP.HOUSEHOLD_ID = CD.CDF4_VAL
                                AND HP.DELETE_IND <> ''Y''
            WHERE 
            :GV_REPORTSTARTDATE BETWEEN DATE(HP.HHOLD_PROFILE_START_DATE) AND DATE(HP.HHOLD_PROFILE_STOP_DATE)	AND
            YEAR(AAV.SETUP_DT) BETWEEN YEAR(ADD_MONTHS(:GV_REPORTSTARTDATE::DATE,-12)) AND YEAR(:gv_ReportStopDate::DATE)
            GROUP BY
            CD.CDF3_VAL,
            CD.CDF5_VAL,
            AAV.SETUP_DT,
            AAV.END_DT,
            AAV.AUTH_IMAGE_NUMBER
    ) 
);

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_MAIN_DTL)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP4'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE MAIN'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_MAIN) AS
(
SELECT
SETUP_DATE,
"RECURRING EFT CHANNEL",
"RECURRING EFT ENROLLMENTS BY CHANNEL",  
SUM(NVL("Current Month",0)) AS "Current Month",
SUM(NVL("QTR 1",0)) AS "QTR 1",
SUM(NVL("QTR 2",0)) AS "QTR 2",
SUM(NVL("QTR 3",0)) AS "QTR 3",
SUM(NVL("QTR 4",0)) AS "QTR 4",
SUM(NVL("YTD",0)) AS "YTD",
CURRENT_TIMESTAMP() AS RUN_DATE,
:GV_REPORTSTARTDATE AS START_DATE,
:gv_ReportStopDate as END_DATE
FROM
(
SELECT
    SETUP_DT AS SETUP_DATE,
    "RECURRING EFT CHANNEL",
    CASE
        WHEN "RECURRING EFT CHANNEL" = ''OLE'' 
        THEN ''OLE''
        WHEN "RECURRING EFT CHANNEL" = ''Member Web'' 
        THEN ''Member Web''
        WHEN "RECURRING EFT CHANNEL" = ''OCSS CSR Voice Signature'' 
        THEN ''OCSS CSR Voice Signature''
        WHEN "RECURRING EFT CHANNEL" = ''OCSS POS Voice Signature'' 
        THEN ''OCSS POS Voice Signature''
        WHEN "RECURRING EFT CHANNEL" = ''Paper'' 
        THEN ''Paper''
    END AS  "RECURRING EFT ENROLLMENTS BY CHANNEL",
    CASE
        WHEN
        "RECURRING EFT CHANNEL" = ''OLE'' AND
        to_char(SETUP_DT,''Mon'') in (SELECT TO_CHAR(:GV_REPORTSTARTDATE,''Mon'') FROM DUAL)
        THEN COUNT("OLE")
        WHEN
        "RECURRING EFT CHANNEL" = ''Member Web'' AND
        to_char(SETUP_DT,''Mon'') in (SELECT TO_CHAR(:GV_REPORTSTARTDATE,''Mon'') FROM DUAL)
        THEN COUNT("Member Web")
        WHEN
        "RECURRING EFT CHANNEL" = ''OCSS CSR Voice Signature'' AND
        to_char(SETUP_DT,''Mon'') in (SELECT TO_CHAR(:GV_REPORTSTARTDATE,''Mon'') FROM DUAL)
        THEN COUNT("OCSS CSR Voice Signature")
        WHEN
        "RECURRING EFT CHANNEL" = ''OCSS POS Voice Signature'' AND
        to_char(SETUP_DT,''Mon'') in (SELECT TO_CHAR(:GV_REPORTSTARTDATE,''Mon'') FROM DUAL)
        THEN COUNT("OCSS POS Voice Signature")
        WHEN
        "RECURRING EFT CHANNEL" = ''Paper'' AND
        to_char(SETUP_DT,''Mon'') in (SELECT TO_CHAR(:GV_REPORTSTARTDATE,''Mon'') FROM DUAL)
        THEN COUNT("Paper")
    END AS "Current Month",
    CASE
        WHEN
        "RECURRING EFT CHANNEL" = ''OLE'' AND
        TO_CHAR(SETUP_DT,''MON'') in (''Jan'',''Feb'',''Mar'')  
        THEN COUNT("OLE")
        WHEN
        "RECURRING EFT CHANNEL" = ''Member Web'' AND
        TO_CHAR(SETUP_DT,''MON'') in (''Jan'',''Feb'',''Mar'')  
        THEN COUNT("Member Web")
        WHEN
        "RECURRING EFT CHANNEL" = ''OCSS CSR Voice Signature'' AND
        TO_CHAR(SETUP_DT,''MON'') in (''Jan'',''Feb'',''Mar'')  
        THEN COUNT("OCSS CSR Voice Signature")
        WHEN
        "RECURRING EFT CHANNEL" = ''OCSS POS Voice Signature'' AND
        TO_CHAR(SETUP_DT,''MON'') in (''Jan'',''Feb'',''Mar'')  
        THEN COUNT("OCSS POS Voice Signature")
        WHEN
        "RECURRING EFT CHANNEL" = ''Paper'' AND
        TO_CHAR(SETUP_DT,''MON'') in (''Jan'',''Feb'',''Mar'')  
        THEN COUNT("Paper")
    END AS "QTR 1",
    CASE
        WHEN
        "RECURRING EFT CHANNEL" = ''OLE'' AND
        TO_CHAR(SETUP_DT,''MON'') in (''Apr'',''May'',''Jun'')
        THEN COUNT("OLE")
        WHEN
        "RECURRING EFT CHANNEL" = ''Member Web'' AND
        TO_CHAR(SETUP_DT,''MON'') in (''Apr'',''May'',''Jun'') 
        THEN COUNT("Member Web")
        WHEN
        "RECURRING EFT CHANNEL" = ''OCSS CSR Voice Signature'' AND
        TO_CHAR(SETUP_DT,''MON'') in (''Apr'',''May'',''Jun'') 
        THEN COUNT("OCSS CSR Voice Signature")
        WHEN
        "RECURRING EFT CHANNEL" = ''OCSS POS Voice Signature'' AND
        TO_CHAR(SETUP_DT,''MON'') in (''Apr'',''May'',''Jun'')
        THEN COUNT("OCSS POS Voice Signature")
        WHEN
        "RECURRING EFT CHANNEL" = ''Paper'' AND
        TO_CHAR(SETUP_DT,''MON'') in (''Apr'',''May'',''Jun'') 
        THEN COUNT("Paper")
    END AS "QTR 2",
     CASE
        WHEN
        "RECURRING EFT CHANNEL" = ''OLE'' AND
        TO_CHAR(SETUP_DT,''MON'') in (''Jul'',''Aug'',''Sep'')
        THEN COUNT("OLE")
        WHEN
        "RECURRING EFT CHANNEL" = ''Member Web'' AND
        TO_CHAR(SETUP_DT,''MON'') in (''Jul'',''Aug'',''Sep'') 
        THEN COUNT("Member Web")
        WHEN
        "RECURRING EFT CHANNEL" = ''OCSS CSR Voice Signature'' AND
        TO_CHAR(SETUP_DT,''MON'') in (''Jul'',''Aug'',''Sep'')
        THEN COUNT("OCSS CSR Voice Signature")
        WHEN
        "RECURRING EFT CHANNEL" = ''OCSS POS Voice Signature'' AND
        TO_CHAR(SETUP_DT,''MON'') in (''Jul'',''Aug'',''Sep'')
        THEN COUNT("OCSS POS Voice Signature")
        WHEN
        "RECURRING EFT CHANNEL" = ''Paper'' AND
        TO_CHAR(SETUP_DT,''MON'') in (''Jul'',''Aug'',''Sep'')
        THEN COUNT("Paper")
    END AS "QTR 3",
    CASE
        WHEN
        "RECURRING EFT CHANNEL" = ''OLE'' AND
        TO_CHAR(SETUP_DT,''MON'') IN (''Oct'',''Nov'',''Dec'') 
        THEN COUNT("OLE")
        WHEN
        "RECURRING EFT CHANNEL" = ''Member Web'' AND
        TO_CHAR(SETUP_DT,''MON'') IN (''Oct'',''Nov'',''Dec'')  
        THEN COUNT("Member Web")
        WHEN
        "RECURRING EFT CHANNEL" = ''OCSS CSR Voice Signature'' AND
        TO_CHAR(SETUP_DT,''MON'') IN (''Oct'',''Nov'',''Dec'') 
        THEN COUNT("OCSS CSR Voice Signature")
        WHEN
        "RECURRING EFT CHANNEL" = ''OCSS POS Voice Signature'' AND
        TO_CHAR(SETUP_DT,''MON'') IN (''Oct'',''Nov'',''Dec'') 
        THEN COUNT("OCSS POS Voice Signature")
        WHEN
        "RECURRING EFT CHANNEL" = ''Paper'' AND
        TO_CHAR(SETUP_DT,''MON'') IN (''Oct'',''Nov'',''Dec'') 
        THEN COUNT("Paper")
    END AS "QTR 4",
     CASE
        WHEN
        "RECURRING EFT CHANNEL" = ''OLE'' AND
         TO_CHAR(SETUP_DT,''MON'') IN (''Jan'',''Feb'',''Mar'',''Apr'',''May'',''Jun'',''Jul'',''Aug'',''Sep'',''Oct'',''Nov'',''Dec'')  
        THEN COUNT("OLE")
        WHEN
        "RECURRING EFT CHANNEL" = ''Member Web'' AND
        TO_CHAR(SETUP_DT,''MON'') IN (''Jan'',''Feb'',''Mar'',''Apr'',''May'',''Jun'',''Jul'',''Aug'',''Sep'',''Oct'',''Nov'',''Dec'')    
        THEN COUNT("Member Web")
        WHEN
        "RECURRING EFT CHANNEL" = ''OCSS CSR Voice Signature'' AND
         TO_CHAR(SETUP_DT,''MON'') IN (''Jan'',''Feb'',''Mar'',''Apr'',''May'',''Jun'',''Jul'',''Aug'',''Sep'',''Oct'',''Nov'',''Dec'')    
        THEN COUNT("OCSS CSR Voice Signature")
        WHEN
        "RECURRING EFT CHANNEL" = ''OCSS POS Voice Signature'' AND
         TO_CHAR(SETUP_DT,''MON'') IN (''Jan'',''Feb'',''Mar'',''Apr'',''May'',''Jun'',''Jul'',''Aug'',''Sep'',''Oct'',''Nov'',''Dec'')   
        THEN COUNT("OCSS POS Voice Signature")
        WHEN
        "RECURRING EFT CHANNEL" = ''Paper'' AND
        TO_CHAR(SETUP_DT,''MON'') IN (''Jan'',''Feb'',''Mar'',''Apr'',''May'',''Jun'',''Jul'',''Aug'',''Sep'',''Oct'',''Nov'',''Dec'')  
        THEN COUNT("Paper")
    END AS "YTD"
FROM
IDENTIFIER(:V_MAIN_DTL)
GROUP BY
"RECURRING EFT CHANNEL",
SETUP_DT,
END_DT,
SETUP_DT

)
GROUP BY
SETUP_DATE,
"RECURRING EFT CHANNEL" ,
"RECURRING EFT ENROLLMENTS BY CHANNEL"
--YEAR
);

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_MAIN)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP5'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE pv_ReportResult'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_pv_ReportResult) AS
SELECT
    "RECURRING EFT ENROLLMENTS BY CHANNEL", 
    YEAR,
    CASE
        WHEN EFT_MONTH = ''Current Month''
        THEN ''Current Month: ''|| TO_CHAR(:GV_REPORTSTARTDATE,''Mon'')
        ELSE EFT_MONTH
    END AS EFT_MONTH, 
    TOTAL_CNT, 
    CURRENT_TIMESTAMP() AS RUN_DATE,
    :GV_REPORTSTARTDATE AS START_DATE,
    :gv_ReportStopDate as END_DATE
FROM
        (
        SELECT 
        
                    "RECURRING EFT ENROLLMENTS BY CHANNEL",
                    YEAR,
                    SUM("Current Month") AS "Current Month", 
                    SUM("QTR 1") AS "QTR 1", 
                    SUM("QTR 2") AS "QTR 2", 
                    SUM("QTR 3") AS "QTR 3", 
                    SUM("QTR 4") AS "QTR 4",
                    SUM(YTD) AS YTD 
        FROM            
        (
            SELECT 
                    "RECURRING EFT ENROLLMENTS BY CHANNEL",
                    ''Current Year:'' ||TO_CHAR(:GV_REPORTSTARTDATE,''YYYY'') AS YEAR,
                    "Current Month", 
                    "QTR 1", 
                    "QTR 2", 
                    "QTR 3", 
                    "QTR 4",
                     YTD 
            FROM IDENTIFIER(:V_MAIN)
            WHERE 
            YEAR(ADD_MONTHS(SETUP_DATE,-0)) = YEAR(:GV_REPORTSTARTDATE::DATE)
            AND SETUP_DATE <= :gv_ReportStopDate
            
            
            UNION ALL
        
--            SELECT
--                CASE
--                        WHEN "RECURRING EFT CHANNEL" = ''OLE'' 
--                        THEN ''OLE''
--                        WHEN "RECURRING EFT CHANNEL" = ''Member Web'' 
--                        THEN ''Member Web''
--                        WHEN "RECURRING EFT CHANNEL" = ''OCSS CSR Voice Signature'' 
--                        THEN ''OCSS CSR Voice Signature''
--                        WHEN "RECURRING EFT CHANNEL" = ''OCSS POS Voice Signature'' 
--                        THEN ''OCSS POS Voice Signature''
--                        WHEN "RECURRING EFT CHANNEL" = ''Paper'' 
--                        THEN ''Paper''
--                END AS  "RECURRING EFT ENROLLMENTS BY CHANNEL",
--                ''Current Year:'' ||TO_CHAR(:GV_REPORTSTARTDATE,''YYYY'') AS YEAR,
--                TO_NUMBER(''0'') AS "Current Month",
--                TO_NUMBER(''0'') AS "QTR 1",
--                TO_NUMBER(''0'') AS "QTR 2",
--                TO_NUMBER(''0'') AS "QTR 3",
--                TO_NUMBER(''0'') AS "QTR 4",
--                TO_NUMBER(''0'') AS "YTD"	
--            FROM IDENTIFIER(:V_MAIN)
         
             SELECT DISTINCT              
                    ''OLE'' AS  "RECURRING EFT ENROLLMENTS BY CHANNEL",
                    ''Current Year:'' ||TO_CHAR(:GV_REPORTSTARTDATE,''YYYY'') AS YEAR,
                    TO_NUMBER(''0'') AS "Current Month",
                    TO_NUMBER(''0'') AS "QTR 1",
                    TO_NUMBER(''0'') AS "QTR 2",
                    TO_NUMBER(''0'') AS "QTR 3",
                    TO_NUMBER(''0'') AS "QTR 4",
                    TO_NUMBER(''0'') AS "YTD"	
                FROM IDENTIFIER(:V_MAIN) 
                
            UNION ALL
            
            SELECT DISTINCT
                    ''Member Web'' AS  "RECURRING EFT ENROLLMENTS BY CHANNEL",
                    ''Current Year:'' ||TO_CHAR(:GV_REPORTSTARTDATE,''YYYY'') AS YEAR,
                    TO_NUMBER(''0'') AS "Current Month",
                    TO_NUMBER(''0'') AS "QTR 1",
                    TO_NUMBER(''0'') AS "QTR 2",
                    TO_NUMBER(''0'') AS "QTR 3",
                    TO_NUMBER(''0'') AS "QTR 4",
                    TO_NUMBER(''0'') AS "YTD"	
                FROM IDENTIFIER(:V_MAIN)
            
            UNION ALL
            
            SELECT DISTINCT
                    ''OCSS CSR Voice Signature'' AS  "RECURRING EFT ENROLLMENTS BY CHANNEL",
                    ''Current Year:'' ||TO_CHAR(:GV_REPORTSTARTDATE,''YYYY'') AS YEAR,
                    TO_NUMBER(''0'') AS "Current Month",
                    TO_NUMBER(''0'') AS "QTR 1",
                    TO_NUMBER(''0'') AS "QTR 2",
                    TO_NUMBER(''0'') AS "QTR 3",
                    TO_NUMBER(''0'') AS "QTR 4",
                    TO_NUMBER(''0'') AS "YTD"	
                FROM IDENTIFIER(:V_MAIN)
                        
            UNION ALL
            
            SELECT DISTINCT
                    ''OCSS POS Voice Signature'' AS  "RECURRING EFT ENROLLMENTS BY CHANNEL",
                    ''Current Year:'' ||TO_CHAR(:GV_REPORTSTARTDATE,''YYYY'') AS YEAR,
                    TO_NUMBER(''0'') AS "Current Month",
                    TO_NUMBER(''0'') AS "QTR 1",
                    TO_NUMBER(''0'') AS "QTR 2",
                    TO_NUMBER(''0'') AS "QTR 3",
                    TO_NUMBER(''0'') AS "QTR 4",
                    TO_NUMBER(''0'') AS "YTD"	
                FROM IDENTIFIER(:V_MAIN)
                        
            UNION ALL
            
            SELECT DISTINCT
                    ''Paper'' AS  "RECURRING EFT ENROLLMENTS BY CHANNEL",
                    ''Current Year:'' ||YEAR(:GV_REPORTSTARTDATE::DATE) AS YEAR,
                    TO_NUMBER(''0'') AS "Current Month",
                    TO_NUMBER(''0'') AS "QTR 1",
                    TO_NUMBER(''0'') AS "QTR 2",
                    TO_NUMBER(''0'') AS "QTR 3",
                    TO_NUMBER(''0'') AS "QTR 4",
                    TO_NUMBER(''0'') AS "YTD"	
                FROM IDENTIFIER(:V_MAIN)        
            
            UNION ALL
            
            SELECT 
                    "RECURRING EFT ENROLLMENTS BY CHANNEL",
                    ''Previous Year:'' ||YEAR(ADD_MONTHS(:GV_REPORTSTARTDATE::DATE,-12)) AS YEAR,
                    "Current Month", 
                    "QTR 1", 
                    "QTR 2", 
                    "QTR 3", 
                    "QTR 4",
                     YTD 
            FROM IDENTIFIER(:V_MAIN)
            WHERE 
            YEAR(add_months(SETUP_DATE,-0)) = YEAR(ADD_MONTHS(:GV_REPORTSTARTDATE::DATE,-12))
            AND SETUP_DATE <= ADD_MONTHS(:gv_ReportStopDate::DATE,-12)
          
          UNION ALL
          
--            SELECT
--                CASE
--                        WHEN "RECURRING EFT CHANNEL" = ''OLE'' 
--                        THEN ''OLE''
--                        WHEN "RECURRING EFT CHANNEL" = ''Member Web'' 
--                        THEN ''Member Web''
--                        WHEN "RECURRING EFT CHANNEL" = ''OCSS CSR Voice Signature'' 
--                        THEN ''OCSS CSR Voice Signature''
--                        WHEN "RECURRING EFT CHANNEL" = ''OCSS POS Voice Signature'' 
--                        THEN ''OCSS POS Voice Signature''
--                        WHEN "RECURRING EFT CHANNEL" = ''Paper'' 
--                        THEN ''Paper''
--                END AS  "RECURRING EFT ENROLLMENTS BY CHANNEL",
--               ''Previous Year:'' ||TO_CHAR(ADD_MONTHS(:GV_REPORTSTARTDATE,-12),''yyyy'') AS YEAR,
--                TO_NUMBER(''0'') AS "Current Month",
--                TO_NUMBER(''0'') AS "QTR 1",
--                TO_NUMBER(''0'') AS "QTR 2",
--                TO_NUMBER(''0'') AS "QTR 3",
--                TO_NUMBER(''0'') AS "QTR 4",
--                TO_NUMBER(''0'') AS "YTD"	
--            FROM IDENTIFIER(:V_MAIN)
          
           SELECT DISTINCT              
                ''OLE'' AS  "RECURRING EFT ENROLLMENTS BY CHANNEL",
                ''Previous Year:'' ||TO_CHAR(ADD_MONTHS(:GV_REPORTSTARTDATE,-12),''yyyy'') AS YEAR,
                TO_NUMBER(''0'') AS "Current Month",
                TO_NUMBER(''0'') AS "QTR 1",
                TO_NUMBER(''0'') AS "QTR 2",
                TO_NUMBER(''0'') AS "QTR 3",
                TO_NUMBER(''0'') AS "QTR 4",
                TO_NUMBER(''0'') AS "YTD"	
            FROM IDENTIFIER(:V_MAIN) 
    
        UNION ALL
        
        SELECT DISTINCT
                ''Member Web'' AS  "RECURRING EFT ENROLLMENTS BY CHANNEL",
                ''Previous Year:'' ||TO_CHAR(ADD_MONTHS(:GV_REPORTSTARTDATE,-12),''yyyy'') AS YEAR,
                TO_NUMBER(''0'') AS "Current Month",
                TO_NUMBER(''0'') AS "QTR 1",
                TO_NUMBER(''0'') AS "QTR 2",
                TO_NUMBER(''0'') AS "QTR 3",
                TO_NUMBER(''0'') AS "QTR 4",
                TO_NUMBER(''0'') AS "YTD"	
            FROM IDENTIFIER(:V_MAIN)
        
        UNION ALL
        
        SELECT DISTINCT
                ''OCSS CSR Voice Signature'' AS  "RECURRING EFT ENROLLMENTS BY CHANNEL",
                ''Previous Year:'' ||TO_CHAR(ADD_MONTHS(:GV_REPORTSTARTDATE,-12),''yyyy'') AS YEAR,
                TO_NUMBER(''0'') AS "Current Month",
                TO_NUMBER(''0'') AS "QTR 1",
                TO_NUMBER(''0'') AS "QTR 2",
                TO_NUMBER(''0'') AS "QTR 3",
                TO_NUMBER(''0'') AS "QTR 4",
                TO_NUMBER(''0'') AS "YTD"	
            FROM IDENTIFIER(:V_MAIN)
            
        UNION ALL
        
        SELECT DISTINCT
                ''OCSS POS Voice Signature'' AS  "RECURRING EFT ENROLLMENTS BY CHANNEL",
                ''Previous Year:'' ||TO_CHAR(ADD_MONTHS(:GV_REPORTSTARTDATE,-12),''yyyy'') AS YEAR,
                TO_NUMBER(''0'') AS "Current Month",
                TO_NUMBER(''0'') AS "QTR 1",
                TO_NUMBER(''0'') AS "QTR 2",
                TO_NUMBER(''0'') AS "QTR 3",
                TO_NUMBER(''0'') AS "QTR 4",
                TO_NUMBER(''0'') AS "YTD"	
            FROM IDENTIFIER(:V_MAIN)
            
        UNION ALL
        
        SELECT DISTINCT
                ''Paper'' AS  "RECURRING EFT ENROLLMENTS BY CHANNEL",
                ''Previous Year:'' ||TO_CHAR(ADD_MONTHS(:GV_REPORTSTARTDATE,-12),''yyyy'') AS YEAR,
                TO_NUMBER(''0'') AS "Current Month",
                TO_NUMBER(''0'') AS "QTR 1",
                TO_NUMBER(''0'') AS "QTR 2",
                TO_NUMBER(''0'') AS "QTR 3",
                TO_NUMBER(''0'') AS "QTR 4",
                TO_NUMBER(''0'') AS "YTD"	
            FROM IDENTIFIER(:V_MAIN)
        )    
        GROUP BY
            "RECURRING EFT ENROLLMENTS BY CHANNEL",
            YEAR    
        )
        UNPIVOT 
            ( TOTAL_CNT FOR EFT_MONTH 
                IN ("Current Month","QTR 1", "QTR 2", "QTR 3", "QTR 4", YTD)) TAB1;

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_pv_ReportResult)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP6'';
V_STEP_NAME :=  ''CALL BDR_BI.SP_ISB_SF_LOG_INSERT_COMPLETE(:gv_Log_id)'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CALL BDR_BI.SP_ISB_SF_LOG_INSERT_COMPLETE(:gv_Log_id);

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0 ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



let res_set RESULTSET;
let select_statement1 := ''SELECT * FROM pv_ReportResult'';
res_set := (EXECUTE IMMEDIATE :select_statement1);
RETURN TABLE(res_set);

EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);

gv_error_code := SQLERRM;
CALL BDR_BI.SP_ISB_SF_LOG_INSERT_ERROR(:gv_Log_id, :gv_error_code);

RAISE;

END;

';