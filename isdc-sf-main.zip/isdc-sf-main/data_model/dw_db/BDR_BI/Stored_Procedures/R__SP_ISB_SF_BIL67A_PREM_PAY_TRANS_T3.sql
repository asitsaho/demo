CREATE OR REPLACE PROCEDURE BDR_BI.SP_ISB_SF_BIL67A_PREM_PAY_TRANS_T3("PV_REPORTSTARTDATE" DATE, "PV_REPORTSTOPDATE" DATE, "DB_NAME" VARCHAR(16777216) DEFAULT '', "TGT_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "TGT2_SC" VARCHAR(16777216) DEFAULT '', "SRC_SC" VARCHAR(16777216) DEFAULT 'SRC_DWADM', "SRC2_SC" VARCHAR(16777216) DEFAULT 'SRC_COMPAS_D', "SRC3_SC" VARCHAR(16777216) DEFAULT 'SRC_DWADM', "UTIL_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "PIPELINE_ID" VARCHAR(16777216) DEFAULT '', "PIPELINE_NAME" VARCHAR(16777216) DEFAULT 'SP_ISB_SF_BIL67A_PREM_PAY_TRANS_T3')
RETURNS TABLE ()
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

  gv_ReportStartDate                DATE := DATE(pv_ReportStartDate);
  gv_ReportStopDate                 DATE := DATE(pv_ReportStopDate);
  gv_Log_id                         NUMBER;
  gv_error_code                     varchar(200);




V_START_TIME TIMESTAMP;

V_STEP VARCHAR;
V_LAST_QUERY_ID    VARCHAR;
V_ROWS_LOADED   VARCHAR;
V_PROCESS_NAME   VARCHAR DEFAULT ''SP_ISB_SF_BIL67A_PREM_PAY_TRANS_T3'';
V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''SP_ISB_SF_BIL67A_PREM_PAY_TRANS_T3'';
V_STEP_NAME        VARCHAR;
V_ROWS_PARSED      INTEGER;
V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := COALESCE(:UTIL_SC, ''BDR_BI'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';
BEGIN
----COMPAS.HOUSEHOLD_PROFILE
----SRC_COMPAS_D.V_TT_HOUSEHOLD_PROFILE
LET V_HOUSEHOLD_PROFILE VARCHAR :=  :SRC2_SC || ''.HOUSEHOLD_PROFILE'';

----MAIN_PAY_DTL
----MAIN_PAY_DTL
LET V_MAIN_PAY_DTL VARCHAR :=  :TGT_SC || ''.MAIN_PAY_DTL'';

----DWADM.CI_ACCT_APAY_VW
----BDR_BI.CI_ACCT_APAY_VW
LET V_CI_ACCT_APAY_VW VARCHAR :=  :SRC3_SC || ''.CI_ACCT_APAY_VW'';

----DWADM.CUSTOMER_DIM
----SRC_DWADM.CUSTOMER_DIM
LET V_CUSTOMER_DIM VARCHAR :=  :SRC_SC || ''.CUSTOMER_DIM'';

----DWADM.CI_APAY_CLR_STG_VW
----BDR_BI.CI_APAY_CLR_STG_VW
LET V_CI_APAY_CLR_STG_VW VARCHAR :=  :SRC3_SC || ''.CI_APAY_CLR_STG_VW'';

----DWADM.TNDR_TYPE_DIM
----SRC_DWADM.TNDR_TYPE_DIM
LET V_TNDR_TYPE_DIM VARCHAR :=  :SRC_SC || ''.TNDR_TYPE_DIM'';

----PV_REPORTRESULT
----PV_REPORTRESULT
LET V_PV_REPORTRESULT VARCHAR :=  :TGT_SC || ''.PV_REPORTRESULT'';

----MAIN_TAB3
----MAIN_TAB3
LET V_MAIN_TAB3 VARCHAR :=  :TGT_SC || ''.MAIN_TAB3'';

----DWADM.PAYMENT_FACT
----SRC_DWADM.PAYMENT_FACT
LET V_PAYMENT_FACT VARCHAR :=  :SRC_SC || ''.PAYMENT_FACT'';




--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP1'';
V_STEP_NAME :=  ''call BDR_BI.FN_ISB_SF_GET_LOG_ID()'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

call BDR_BI.FN_ISB_SF_GET_LOG_ID()
    into :gv_Log_id;

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0 ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP2'';
V_STEP_NAME :=  ''CALL BDR_BI.SP_ISB_SF_INSERT_JOB_LOG()'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CALL BDR_BI.SP_ISB_SF_INSERT_JOB_LOG(:gv_Log_id,''BI.PKG_ISB_BILL_REPORTS.SP_ISB_SHIP_Premium_Payment_Transactions_T3'',''BIL0067A_ISB_ SHIP Premium Payment Transactions TAB3'');

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP3'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE MAIN_PAY_DTL'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_MAIN_PAY_DTL) AS 
        (
        SELECT * FROM 
        (
        SELECT
            SUM("Total number of Recurring EFT payments") +
            SUM("Total number of paper check payments") +
            SUM("Total number of Optum CSS 1X EFT payments") +
            SUM("Total number of Optum CSS 1X CC payments") +
            SUM("Total number of Web 1X CC payments") +
            SUM("Total number of Web 1X EFT payments") +
            SUM("Total number of Quickpay 1x CC Payment") +
            SUM("Total number of Quickpay 1x EFT Payment") AS "Total household payment transactions (e.g. CC, Check, ENR, EFT, Online etc..)",
            SUM("Total number of Recurring EFT payments") AS "Total number of Recurring EFT payments",
            SUM("Total number of paper check payments") AS "Total number of paper check payments",
            SUM("Total number of Optum CSS 1X EFT payments") AS "Total number of Optum CSS 1X EFT payments",
            SUM("Total number of Optum CSS 1X CC payments") AS "Total number of Optum CSS 1X CC payments",
            SUM("Total number of Web 1X CC payments") AS "Total number of Web 1X CC payments",
            SUM("Total number of Web 1X EFT payments") AS "Total number of Web 1X EFT payments",
            SUM("Total number of Quickpay 1x CC Payment") AS "Total number of Quickpay 1x CC Payment",
            SUM("Total number of Quickpay 1x EFT Payment") AS "Total number of Quickpay 1x EFT Payment",
            SUM("Total number of Recurring EFT payments") +
            SUM("Total number of paper check payments") +
            SUM("Total number of Optum CSS 1X EFT payments") +
            SUM("Total number of Optum CSS 1X CC payments") +
            SUM("Total number of Web 1X CC payments") +
            SUM("Total number of Web 1X EFT payments") +
            SUM("Total number of Quickpay 1x CC Payment") +
            SUM("Total number of Quickpay 1x EFT Payment")AS TOTAL_PAYMENT,
            MON,
            CURRENT_YEAR,
            MONTH_YEAR
            
        FROM
        (
        SELECT
                    (CASE 
                        WHEN PF.TNDR_TYPE_CD IN (''ACHC'',''ACHS'') AND EXISTS (select 1 from IDENTIFIER(:V_CI_APAY_CLR_STG_VW) where LENGTH(TRIM(ACCT_APAY_ID)) > 0 and APAY_SRC_CD<>''PENSION-FRS''
                                        and SCHED_EXTRACT_DT is not null AND CDC_FLAG <> ''D'' AND pay_tender_id = pf.src_pay_tndr_id)
                                        
                        THEN 1 
                        ELSE 0 
                    END) AS "Total number of Recurring EFT payments",
                    (CASE 
                        WHEN PF.TNDR_TYPE_CD = ''CHK''
                        THEN 1 
                        ELSE 0					
                    END )AS  "Total number of paper check payments",
                    CASE
                        WHEN PF.UDDGEN18 IN (''ONETIMEEFTMANUAL'',''ONETIMEEFTSYSTEM'') AND substr(PF.UDDGEN20,-6) = ''SIEBEL'' AND 
                                PF.TNDR_TYPE_CD IN (''ACHC'',''ACHS'')
                        THEN 1
                        ELSE 0
                    END AS "Total number of Optum CSS 1X EFT payments",
                    CASE
                        WHEN PF.UDDGEN19 IN (''IVR'',''TEL'',''PHONE'') AND PF.TNDR_TYPE_CD IN (''CCAP'') AND PF.UDDGEN18 IN (''ONETIMECCSYS'')
                        THEN 1
                        ELSE 0
                    END AS "Total number of Optum CSS 1X CC payments",
                    CASE
                        WHEN PF.UDDGEN19 IN (''WEB'') AND PF.TNDR_TYPE_CD IN (''CCAP'') AND PF.UDDGEN18 IN (''ONETIMECCSYS'')
                        THEN 1
                        ELSE 0
                    END AS "Total number of Web 1X CC payments",
                    CASE
                        WHEN PF.UDDGEN18 IN (''ONETIMEEFTMANUAL'',''ONETIMEEFTSYSTEM'') AND substr(PF.UDDGEN20,-10) = ''MEMBER_WEB'' 
                                AND PF.TNDR_TYPE_CD IN (''ACHC'',''ACHS'')
                        THEN 1
                        ELSE 0
                    END AS "Total number of Web 1X EFT payments",
                    CASE
                    WHEN PF.UDDGEN19 IN (''WEB-QUICKPAY'') AND PF.UDDGEN18 IN (''ONETIMECCSYS'') AND PF.TNDR_SRC_CD = ''JPMCC'' 
                    THEN 1
                    ELSE 0
                    END AS "Total number of Quickpay 1x CC Payment",
                    CASE
                    WHEN PF.UDDGEN19 IN (''WEB-QUICKPAY'') AND PF.UDDGEN18 IN (''ONETIMEEFTSYSTEM'') 
                    THEN 1
                    ELSE 0
                    END AS "Total number of Quickpay 1x EFT Payment",
                    COUNT(*) AS TOTAL_PAYMENT,
                    TO_CHAR(MIN(PF.FREEZE_DT) ,''Mon'') AS MON,
                    to_char(add_months(MIN(PF.FREEZE_DT),-0),''yyyy'') AS CURRENT_YEAR,
                    to_char(add_months(MIN(PF.FREEZE_DT),-0),''MON/YYYY'') AS MONTH_YEAR,
                    PF.SRC_PAY_EVENT_ID
        FROM
                IDENTIFIER(:V_PAYMENT_FACT) PF
                INNER JOIN IDENTIFIER(:V_TNDR_TYPE_DIM) TTD ON TTD.SRC_TNDR_TYPE_CD = PF.TNDR_TYPE_CD
                            AND TTD.CURR_REC_FLAG = ''Y'' -- ''Y'' Fetch Always Latest Records
                            AND PF.FT_TYPE = ''Pay Segment'' 
                            AND PF.CDC_STATUS_FLAG <> ''D'' 
                           
                LEFT JOIN   IDENTIFIER(:V_CI_APAY_CLR_STG_VW) CLRSTG ON CLRSTG.PAY_TENDER_ID=PF.SRC_PAY_TNDR_ID                 
                                    AND CLRSTG.SCHED_EXTRACT_DT IS NOT NULL
                                    --AND CLRSTG.ACCT_APAY_ID <>'' ''
									AND LENGTH(TRIM(CLRSTG.ACCT_APAY_ID)) > 0
                                    AND CLRSTG.CDC_FLAG <> ''D''
                LEFT JOIN IDENTIFIER(:V_CI_ACCT_APAY_VW) AAV ON AAV.ACCT_APAY_ID = CLRSTG.ACCT_APAY_ID
                            AND AAV.AUTH_CHANNEL_TYPE_ID IN (''1'',''2'',''5'',''6'')
                INNER JOIN IDENTIFIER(:V_CUSTOMER_DIM) CD ON CD.CUST_CURR_KEY = PF.CUST_CURR_KEY 
                                        AND CD.CURR_REC_FLAG = ''Y'' -- ''Y'' Fetch Always Latest Records
                LEFT JOIN IDENTIFIER(:V_HOUSEHOLD_PROFILE) HP ON HP.HOUSEHOLD_ID = CD.CDF4_VAL
                                        AND HP.DELETE_IND <> ''Y''  -- ''Y'' Fetch Always Latest Records
                                        AND :gv_ReportStartDate BETWEEN DATE(HP.HHOLD_PROFILE_START_DATE) AND DATE(HP.HHOLD_PROFILE_STOP_DATE)	
        WHERE                     
                     to_char(add_months(PF.FREEZE_DT,-0),''yyyy'') BETWEEN TO_CHAR(ADD_MONTHS(:gv_ReportStartDate,-12),''yyyy'') AND TO_CHAR(:gv_ReportStartDate,''YYYY'')
--                     AND TNDR_SRC_CD <> ''TI_CMPS''
        GROUP BY
        PF.SRC_PAY_EVENT_ID,
        PF.UDDGEN18,
        PF.UDDGEN19,
        PF.UDDGEN20,
        PF.TNDR_TYPE_CD,
        PF.TNDR_SRC_CD,
        PF.SRC_PAY_TNDR_ID
        )
        GROUP BY
        MON,
        CURRENT_YEAR,
        MONTH_YEAR
        )
        WHERE
            TOTAL_PAYMENT <> ''0''
        );

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_MAIN_PAY_DTL)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP4'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE MAIN_TAB3'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_MAIN_TAB3) AS
        (
        SELECT
        PAYMENT_MONTH,
        Year,
        CASE 
            WHEN
                SUM(TOTAL_PAYMENT) = 0
            THEN 1
            ELSE
            SUM(TOTAL_PAYMENT) 
        END AS TOTAL_PAYMENT,
        SUM("Total household payment transactions (e.g. CC, Check, ENR, EFT, Online etc..)") AS "Total household payment transactions (e.g. CC, Check, ENR, EFT, Online etc..)",
        SUM("Total number of Recurring EFT payments") AS "Total number of Recurring EFT payments",
        SUM("Total number of paper check payments") AS "Total number of paper check payments",
        SUM("Total number of Optum CSS 1X EFT payments") AS "Total number of Optum CSS 1X EFT payments",
        SUM("Total number of Optum CSS 1X CC payments") AS "Total number of Optum CSS 1X CC payments",
        SUM("Total number of Web 1X CC payments") AS "Total number of Web 1X CC payments",
        SUM("Total number of Web 1X EFT payments") AS "Total number of Web 1X EFT payments",
        SUM("Total number of Quickpay 1x CC Payment") AS "Total number of Quickpay 1x CC Payment",
        SUM("Total number of Quickpay 1x EFT Payment") AS "Total number of Quickpay 1x EFT Payment"
        FROM
        (
        SELECT 
        ''Current Month: ''||to_char(:gv_ReportStartDate,''Mon'') AS PAYMENT_MONTH,
        ''Current Year: ''||to_char(:gv_ReportStartDate,''yyyy'') as Year,
        TOTAL_PAYMENT,
        "Total household payment transactions (e.g. CC, Check, ENR, EFT, Online etc..)",
        "Total number of Recurring EFT payments",
        "Total number of paper check payments",
        "Total number of Optum CSS 1X EFT payments",
        "Total number of Optum CSS 1X CC payments",
        "Total number of Web 1X CC payments",
        "Total number of Web 1X EFT payments",
        "Total number of Quickpay 1x CC Payment",
        "Total number of Quickpay 1x EFT Payment"
        FROM 
        IDENTIFIER(:V_MAIN_PAY_DTL)
        WHERE 
        MON = to_char(add_months(:gv_ReportStartDate,-0),''Mon'') 
        AND CURRENT_YEAR = TO_CHAR(:gv_ReportStartDate,''YYYY'')
        AND TO_DATE(''01/''||MONTH_YEAR,''DD/MON/YYYY'') <= :gv_ReportStopDate
        
        UNION ALL
        
        SELECT  
        ''Current Month: ''||to_char(add_months(:gv_ReportStartDate,-0),''Mon'') AS PAYMENT_MONTH,
        ''Current Year: ''||to_char(:gv_ReportStartDate,''yyyy'') as Year,
        TO_NUMBER(''0'') AS TOTAL_PAYMENT,
        TO_NUMBER(''0'') AS "Total household payment transactions (e.g. CC, Check, ENR, EFT, Online etc..)",
        TO_NUMBER(''0'') AS "Total number of Recurring EFT payments",
        TO_NUMBER(''0'') AS "Total number of paper check payments",
        TO_NUMBER(''0'') AS "Total number of Optum CSS 1X EFT payments",
        TO_NUMBER(''0'') AS "Total number of Optum CSS 1X CC payments",
        TO_NUMBER(''0'') AS "Total number of Web 1X CC payments",
        TO_NUMBER(''0'') AS "Total number of Web 1X EFT payments",
        TO_NUMBER(''0'') AS "Total number of Quickpay 1x CC Payment",
        TO_NUMBER(''0'') AS "Total number of Quickpay 1x EFT Payment"
        FROM 
        IDENTIFIER(:V_MAIN_PAY_DTL)
        
        UNION ALL
        
        SELECT 
        ''Current Month: ''||to_char(add_months(:gv_ReportStartDate,-0),''Mon'') AS PAYMENT_MONTH,
        ''Previous Year:'' ||TO_CHAR(ADD_MONTHS(:gv_ReportStartDate,-12),''yyyy'') AS YEAR,
        TOTAL_PAYMENT,
        "Total household payment transactions (e.g. CC, Check, ENR, EFT, Online etc..)",
        "Total number of Recurring EFT payments",
        "Total number of paper check payments",
        "Total number of Optum CSS 1X EFT payments",
        "Total number of Optum CSS 1X CC payments",
        "Total number of Web 1X CC payments",
        "Total number of Web 1X EFT payments",
        "Total number of Quickpay 1x CC Payment",
        "Total number of Quickpay 1x EFT Payment"
        FROM 
        IDENTIFIER(:V_MAIN_PAY_DTL)
        WHERE 
        MON = to_char(:gv_ReportStartDate,''Mon'') 
        AND CURRENT_YEAR = TO_CHAR(ADD_MONTHS(:gv_ReportStartDate,-12),''yyyy'')
        AND TO_DATE(''01/''||MONTH_YEAR,''DD/MON/YYYY'') <= ADD_MONTHS(:gv_ReportStopDate ,-12)
        
        UNION ALL
        
        SELECT  
        ''Current Month: ''||to_char(add_months(:gv_ReportStartDate,-0),''Mon'') AS PAYMENT_MONTH,
        ''Previous Year:'' ||TO_CHAR(ADD_MONTHS(:gv_ReportStartDate,-12),''yyyy'') AS YEAR,
        TO_NUMBER(''0'') AS TOTAL_PAYMENT,
        TO_NUMBER(''0'') AS "Total household payment transactions (e.g. CC, Check, ENR, EFT, Online etc..)",
        TO_NUMBER(''0'') AS "Total number of Recurring EFT payments",
        TO_NUMBER(''0'') AS "Total number of paper check payments",
        TO_NUMBER(''0'') AS "Total number of Optum CSS 1X EFT payments",
        TO_NUMBER(''0'') AS "Total number of Optum CSS 1X CC payments",
        TO_NUMBER(''0'') AS "Total number of Web 1X CC payments",
        TO_NUMBER(''0'') AS "Total number of Web 1X EFT payments",
        TO_NUMBER(''0'') AS "Total number of Quickpay 1x CC Payment",
        TO_NUMBER(''0'') AS "Total number of Quickpay 1x EFT Payment"
        FROM 
        IDENTIFIER(:V_MAIN_PAY_DTL)
        
        UNION ALL
        
        SELECT 
        ''QTR 1'' AS PAYMENT_MONTH,
        ''Current Year: ''||to_char(:gv_ReportStartDate,''yyyy'') as Year,
        TOTAL_PAYMENT,
        "Total household payment transactions (e.g. CC, Check, ENR, EFT, Online etc..)",
        "Total number of Recurring EFT payments",
        "Total number of paper check payments",
        "Total number of Optum CSS 1X EFT payments",
        "Total number of Optum CSS 1X CC payments",
        "Total number of Web 1X CC payments",
        "Total number of Web 1X EFT payments",
        "Total number of Quickpay 1x CC Payment",
        "Total number of Quickpay 1x EFT Payment"
        FROM 
        IDENTIFIER(:V_MAIN_PAY_DTL)
        WHERE 
        MON in (''Jan'',''Feb'',''Mar'') 
        AND CURRENT_YEAR = TO_CHAR(:gv_ReportStartDate,''YYYY'')
        AND TO_DATE(''01/''||MONTH_YEAR,''DD/MON/YYYY'') <= :gv_ReportStopDate
        
        UNION ALL
        
        SELECT  
        ''QTR 1'' AS PAYMENT_MONTH,
        ''Current Year: ''||to_char(:gv_ReportStartDate,''yyyy'') as Year,
        TO_NUMBER(''0'') AS TOTAL_PAYMENT,
        TO_NUMBER(''0'') AS "Total household payment transactions (e.g. CC, Check, ENR, EFT, Online etc..)",
        TO_NUMBER(''0'') AS "Total number of Recurring EFT payments",
        TO_NUMBER(''0'') AS "Total number of paper check payments",
        TO_NUMBER(''0'') AS "Total number of Optum CSS 1X EFT payments",
        TO_NUMBER(''0'') AS "Total number of Optum CSS 1X CC payments",
        TO_NUMBER(''0'') AS "Total number of Web 1X CC payments",
        TO_NUMBER(''0'') AS "Total number of Web 1X EFT payments",
        TO_NUMBER(''0'') AS "Total number of Quickpay 1x CC Payment",
        TO_NUMBER(''0'') AS "Total number of Quickpay 1x EFT Payment"
        FROM 
        IDENTIFIER(:V_MAIN_PAY_DTL)
        
        UNION ALL
        
        SELECT 
        ''QTR 1'' AS PAYMENT_MONTH,
        ''Previous Year:'' ||TO_CHAR(ADD_MONTHS(:gv_ReportStartDate,-12),''yyyy'') AS YEAR,
        TOTAL_PAYMENT,
        "Total household payment transactions (e.g. CC, Check, ENR, EFT, Online etc..)",
        "Total number of Recurring EFT payments",
        "Total number of paper check payments",
        "Total number of Optum CSS 1X EFT payments",
        "Total number of Optum CSS 1X CC payments",
        "Total number of Web 1X CC payments",
        "Total number of Web 1X EFT payments",
        "Total number of Quickpay 1x CC Payment",
        "Total number of Quickpay 1x EFT Payment"
        FROM 
        IDENTIFIER(:V_MAIN_PAY_DTL)
        WHERE 
        MON in (''Jan'',''Feb'',''Mar'') 
        AND CURRENT_YEAR = TO_CHAR(ADD_MONTHS(:gv_ReportStartDate,-12),''yyyy'')
        AND TO_DATE(''01/''||MONTH_YEAR,''DD/MON/YYYY'') <= ADD_MONTHS(:gv_ReportStopDate ,-12)
        
        UNION ALL
        
        SELECT  
        ''QTR 1'' AS PAYMENT_MONTH,
        ''Previous Year:'' ||TO_CHAR(ADD_MONTHS(:gv_ReportStartDate,-12),''yyyy'') AS YEAR,
        TO_NUMBER(''0'') AS TOTAL_PAYMENT,
        TO_NUMBER(''0'') AS "Total household payment transactions (e.g. CC, Check, ENR, EFT, Online etc..)",
        TO_NUMBER(''0'') AS "Total number of Recurring EFT payments",
        TO_NUMBER(''0'') AS "Total number of paper check payments",
        TO_NUMBER(''0'') AS "Total number of Optum CSS 1X EFT payments",
        TO_NUMBER(''0'') AS "Total number of Optum CSS 1X CC payments",
        TO_NUMBER(''0'') AS "Total number of Web 1X CC payments",
        TO_NUMBER(''0'') AS "Total number of Web 1X EFT payments",
        TO_NUMBER(''0'') AS "Total number of Quickpay 1x CC Payment",
        TO_NUMBER(''0'') AS "Total number of Quickpay 1x EFT Payment"
        FROM 
        IDENTIFIER(:V_MAIN_PAY_DTL)
        
        UNION ALL
        
        SELECT 
        ''QTR 2'' AS PAYMENT_MONTH,
        ''Current Year: ''||to_char(:gv_ReportStartDate,''yyyy'') as Year,
        TOTAL_PAYMENT,
        "Total household payment transactions (e.g. CC, Check, ENR, EFT, Online etc..)",
        "Total number of Recurring EFT payments",
        "Total number of paper check payments",
        "Total number of Optum CSS 1X EFT payments",
        "Total number of Optum CSS 1X CC payments",
        "Total number of Web 1X CC payments",
        "Total number of Web 1X EFT payments",
        "Total number of Quickpay 1x CC Payment",
        "Total number of Quickpay 1x EFT Payment"
        FROM 
        IDENTIFIER(:V_MAIN_PAY_DTL)
        WHERE 
        MON in (''Apr'',''May'',''Jun'') 
        AND CURRENT_YEAR = TO_CHAR(:gv_ReportStartDate,''YYYY'')
        AND TO_DATE(''01/''||MONTH_YEAR,''DD/MON/YYYY'') <= :gv_ReportStopDate
        
        UNION ALL
        
        SELECT  
        ''QTR 2'' AS PAYMENT_MONTH,
        ''Current Year: ''||to_char(:gv_ReportStartDate,''yyyy'') as Year,
        TO_NUMBER(''0'') AS TOTAL_PAYMENT,
        TO_NUMBER(''0'') AS "Total household payment transactions (e.g. CC, Check, ENR, EFT, Online etc..)",
        TO_NUMBER(''0'') AS "Total number of Recurring EFT payments",
        TO_NUMBER(''0'') AS "Total number of paper check payments",
        TO_NUMBER(''0'') AS "Total number of Optum CSS 1X EFT payments",
        TO_NUMBER(''0'') AS "Total number of Optum CSS 1X CC payments",
        TO_NUMBER(''0'') AS "Total number of Web 1X CC payments",
        TO_NUMBER(''0'') AS "Total number of Web 1X EFT payments",
        TO_NUMBER(''0'') AS "Total number of Quickpay 1x CC Payment",
        TO_NUMBER(''0'') AS "Total number of Quickpay 1x EFT Payment"
        FROM 
        IDENTIFIER(:V_MAIN_PAY_DTL)
        
        UNION ALL
        
        SELECT 
        ''QTR 2'' AS PAYMENT_MONTH,
        ''Previous Year:'' ||TO_CHAR(ADD_MONTHS(:gv_ReportStartDate,-12),''yyyy'') AS YEAR,
        TOTAL_PAYMENT,
        "Total household payment transactions (e.g. CC, Check, ENR, EFT, Online etc..)",
        "Total number of Recurring EFT payments",
        "Total number of paper check payments",
        "Total number of Optum CSS 1X EFT payments",
        "Total number of Optum CSS 1X CC payments",
        "Total number of Web 1X CC payments",
        "Total number of Web 1X EFT payments",
        "Total number of Quickpay 1x CC Payment",
        "Total number of Quickpay 1x EFT Payment"
        FROM 
        IDENTIFIER(:V_MAIN_PAY_DTL)
        WHERE 
        MON in (''Apr'',''May'',''Jun'') 
        AND CURRENT_YEAR = TO_CHAR(ADD_MONTHS(:gv_ReportStartDate,-12),''yyyy'')
        AND TO_DATE(''01/''||MONTH_YEAR,''DD/MON/YYYY'') <= ADD_MONTHS(:gv_ReportStopDate ,-12)
        
        UNION ALL
        
        SELECT  
        ''QTR 2'' AS PAYMENT_MONTH,
        ''Previous Year:'' ||TO_CHAR(ADD_MONTHS(:gv_ReportStartDate,-12),''yyyy'') AS YEAR,
        TO_NUMBER(''0'') AS TOTAL_PAYMENT,
        TO_NUMBER(''0'') AS "Total household payment transactions (e.g. CC, Check, ENR, EFT, Online etc..)",
        TO_NUMBER(''0'') AS "Total number of Recurring EFT payments",
        TO_NUMBER(''0'') AS "Total number of paper check payments",
        TO_NUMBER(''0'') AS "Total number of Optum CSS 1X EFT payments",
        TO_NUMBER(''0'') AS "Total number of Optum CSS 1X CC payments",
        TO_NUMBER(''0'') AS "Total number of Web 1X CC payments",
        TO_NUMBER(''0'') AS "Total number of Web 1X EFT payments",
        TO_NUMBER(''0'') AS "Total number of Quickpay 1x CC Payment",
        TO_NUMBER(''0'') AS "Total number of Quickpay 1x EFT Payment"
        FROM 
        IDENTIFIER(:V_MAIN_PAY_DTL)
        
        UNION ALL
        
        SELECT 
        ''QTR 3'' AS PAYMENT_MONTH,
        ''Current Year: ''||to_char(:gv_ReportStartDate,''yyyy'') as Year,
        TOTAL_PAYMENT,
        "Total household payment transactions (e.g. CC, Check, ENR, EFT, Online etc..)",
        "Total number of Recurring EFT payments",
        "Total number of paper check payments",
        "Total number of Optum CSS 1X EFT payments",
        "Total number of Optum CSS 1X CC payments",
        "Total number of Web 1X CC payments",
        "Total number of Web 1X EFT payments",
        "Total number of Quickpay 1x CC Payment",
        "Total number of Quickpay 1x EFT Payment"
        FROM 
        IDENTIFIER(:V_MAIN_PAY_DTL)
        WHERE 
        MON in (''Jul'',''Aug'',''Sep'')
        AND CURRENT_YEAR = TO_CHAR(:gv_ReportStartDate,''YYYY'')
        AND TO_DATE(''01/''||MONTH_YEAR,''DD/MON/YYYY'') <= :gv_ReportStopDate
        
        UNION ALL
        
        SELECT  
        ''QTR 3'' AS PAYMENT_MONTH,
        ''Current Year: ''||to_char(:gv_ReportStartDate,''yyyy'') as Year,
        TO_NUMBER(''0'') AS TOTAL_PAYMENT,
        TO_NUMBER(''0'') AS "Total household payment transactions (e.g. CC, Check, ENR, EFT, Online etc..)",
        TO_NUMBER(''0'') AS "Total number of Recurring EFT payments",
        TO_NUMBER(''0'') AS "Total number of paper check payments",
        TO_NUMBER(''0'') AS "Total number of Optum CSS 1X EFT payments",
        TO_NUMBER(''0'') AS "Total number of Optum CSS 1X CC payments",
        TO_NUMBER(''0'') AS "Total number of Web 1X CC payments",
        TO_NUMBER(''0'') AS "Total number of Web 1X EFT payments",
        TO_NUMBER(''0'') AS "Total number of Quickpay 1x CC Payment",
        TO_NUMBER(''0'') AS "Total number of Quickpay 1x EFT Payment"
        FROM 
        IDENTIFIER(:V_MAIN_PAY_DTL)
        
        UNION ALL
        
        SELECT 
        ''QTR 3'' AS PAYMENT_MONTH,
        ''Previous Year:'' ||TO_CHAR(ADD_MONTHS(:gv_ReportStartDate,-12),''yyyy'') AS YEAR,
        TOTAL_PAYMENT,
        "Total household payment transactions (e.g. CC, Check, ENR, EFT, Online etc..)",
        "Total number of Recurring EFT payments",
        "Total number of paper check payments",
        "Total number of Optum CSS 1X EFT payments",
        "Total number of Optum CSS 1X CC payments",
        "Total number of Web 1X CC payments",
        "Total number of Web 1X EFT payments",
        "Total number of Quickpay 1x CC Payment",
        "Total number of Quickpay 1x EFT Payment"
        FROM 
        IDENTIFIER(:V_MAIN_PAY_DTL)
        WHERE 
        MON in (''Jul'',''Aug'',''Sep'')
        AND CURRENT_YEAR = TO_CHAR(ADD_MONTHS(:gv_ReportStartDate,-12),''yyyy'')
        AND TO_DATE(''01/''||MONTH_YEAR,''DD/MON/YYYY'') <= ADD_MONTHS(:gv_ReportStopDate ,-12)
        
        UNION ALL
        
        SELECT  
        ''QTR 3'' AS PAYMENT_MONTH,
        ''Previous Year:'' ||TO_CHAR(ADD_MONTHS(:gv_ReportStartDate,-12),''yyyy'') AS YEAR,
        TO_NUMBER(''0'') AS TOTAL_PAYMENT,
        TO_NUMBER(''0'') AS "Total household payment transactions (e.g. CC, Check, ENR, EFT, Online etc..)",
        TO_NUMBER(''0'') AS "Total number of Recurring EFT payments",
        TO_NUMBER(''0'') AS "Total number of paper check payments",
        TO_NUMBER(''0'') AS "Total number of Optum CSS 1X EFT payments",
        TO_NUMBER(''0'') AS "Total number of Optum CSS 1X CC payments",
        TO_NUMBER(''0'') AS "Total number of Web 1X CC payments",
        TO_NUMBER(''0'') AS "Total number of Web 1X EFT payments",
        TO_NUMBER(''0'') AS "Total number of Quickpay 1x CC Payment",
        TO_NUMBER(''0'') AS "Total number of Quickpay 1x EFT Payment"
        FROM 
        IDENTIFIER(:V_MAIN_PAY_DTL)
        
        UNION ALL
        
        SELECT 
        ''QTR 4'' AS PAYMENT_MONTH,
        ''Current Year: ''||to_char(:gv_ReportStartDate,''yyyy'') as Year,
        TOTAL_PAYMENT,
        "Total household payment transactions (e.g. CC, Check, ENR, EFT, Online etc..)",
        "Total number of Recurring EFT payments",
        "Total number of paper check payments",
        "Total number of Optum CSS 1X EFT payments",
        "Total number of Optum CSS 1X CC payments",
        "Total number of Web 1X CC payments",
        "Total number of Web 1X EFT payments",
        "Total number of Quickpay 1x CC Payment",
        "Total number of Quickpay 1x EFT Payment"
        FROM 
        IDENTIFIER(:V_MAIN_PAY_DTL)
        WHERE 
        MON in (''Oct'',''Nov'',''Dec'') 
        AND CURRENT_YEAR = TO_CHAR(:gv_ReportStartDate,''YYYY'')
        AND TO_DATE(''01/''||MONTH_YEAR,''DD/MON/YYYY'') <= :gv_ReportStopDate
        
        UNION ALL
        
        SELECT  
        ''QTR 4'' AS PAYMENT_MONTH,
        ''Current Year: ''||to_char(:gv_ReportStartDate,''yyyy'') as Year,
        TO_NUMBER(''0'') AS TOTAL_PAYMENT,
        TO_NUMBER(''0'') AS "Total household payment transactions (e.g. CC, Check, ENR, EFT, Online etc..)",
        TO_NUMBER(''0'') AS "Total number of Recurring EFT payments",
        TO_NUMBER(''0'') AS "Total number of paper check payments",
        TO_NUMBER(''0'') AS "Total number of Optum CSS 1X EFT payments",
        TO_NUMBER(''0'') AS "Total number of Optum CSS 1X CC payments",
        TO_NUMBER(''0'') AS "Total number of Web 1X CC payments",
        TO_NUMBER(''0'') AS "Total number of Web 1X EFT payments",
        TO_NUMBER(''0'') AS "Total number of Quickpay 1x CC Payment",
        TO_NUMBER(''0'') AS "Total number of Quickpay 1x EFT Payment"
        FROM 
        IDENTIFIER(:V_MAIN_PAY_DTL)
        
        UNION ALL
        
        SELECT 
        ''QTR 4'' AS PAYMENT_MONTH,
        ''Previous Year:'' ||TO_CHAR(ADD_MONTHS(:gv_ReportStartDate,-12),''yyyy'') AS YEAR,
        TOTAL_PAYMENT,
        "Total household payment transactions (e.g. CC, Check, ENR, EFT, Online etc..)",
        "Total number of Recurring EFT payments",
        "Total number of paper check payments",
        "Total number of Optum CSS 1X EFT payments",
        "Total number of Optum CSS 1X CC payments",
        "Total number of Web 1X CC payments",
        "Total number of Web 1X EFT payments",
        "Total number of Quickpay 1x CC Payment",
        "Total number of Quickpay 1x EFT Payment"
        FROM 
        MAIN_PAY_DTL
        WHERE 
        MON in (''Oct'',''Nov'',''Dec'') 
        AND CURRENT_YEAR = TO_CHAR(ADD_MONTHS(:gv_ReportStartDate,-12),''yyyy'')
        AND TO_DATE(''01/''||MONTH_YEAR,''DD/MON/YYYY'') <= ADD_MONTHS(:gv_ReportStopDate ,-12)
        
        UNION ALL
        
        SELECT  
        ''QTR 4'' AS PAYMENT_MONTH,
        ''Previous Year:'' ||TO_CHAR(ADD_MONTHS(:gv_ReportStartDate,-12),''yyyy'') AS YEAR,
        TO_NUMBER(''0'') AS TOTAL_PAYMENT,
        TO_NUMBER(''0'') AS "Total household payment transactions (e.g. CC, Check, ENR, EFT, Online etc..)",
        TO_NUMBER(''0'') AS "Total number of Recurring EFT payments",
        TO_NUMBER(''0'') AS "Total number of paper check payments",
        TO_NUMBER(''0'') AS "Total number of Optum CSS 1X EFT payments",
        TO_NUMBER(''0'') AS "Total number of Optum CSS 1X CC payments",
        TO_NUMBER(''0'') AS "Total number of Web 1X CC payments",
        TO_NUMBER(''0'') AS "Total number of Web 1X EFT payments",
        TO_NUMBER(''0'') AS "Total number of Quickpay 1x CC Payment",
        TO_NUMBER(''0'') AS "Total number of Quickpay 1x EFT Payment"
        FROM 
        MAIN_PAY_DTL
        
        UNION ALL
        
        SELECT 
        ''YTD'' AS PAYMENT_MONTH,
        ''Current Year: ''||to_char(:gv_ReportStartDate,''yyyy'') as Year,
        TOTAL_PAYMENT,
        "Total household payment transactions (e.g. CC, Check, ENR, EFT, Online etc..)",
        "Total number of Recurring EFT payments",
        "Total number of paper check payments",
        "Total number of Optum CSS 1X EFT payments",
        "Total number of Optum CSS 1X CC payments",
        "Total number of Web 1X CC payments",
        "Total number of Web 1X EFT payments",
        "Total number of Quickpay 1x CC Payment",
        "Total number of Quickpay 1x EFT Payment"
        FROM 
        MAIN_PAY_DTL
        WHERE 
        MON in (''Jan'',''Feb'',''Mar'',''Apr'',''May'',''Jun'',''Jul'',''Aug'',''Sep'',''Oct'',''Nov'',''Dec'')  
        AND CURRENT_YEAR = TO_CHAR(:gv_ReportStartDate,''YYYY'')
        AND TO_DATE(''01/''||MONTH_YEAR,''DD/MON/YYYY'') <= :gv_ReportStopDate
        
        UNION ALL
        
        SELECT  
        ''YTD'' AS PAYMENT_MONTH,
        ''Current Year: ''||to_char(:gv_ReportStartDate,''yyyy'') as Year,
        TO_NUMBER(''0'') AS TOTAL_PAYMENT,
        TO_NUMBER(''0'') AS "Total household payment transactions (e.g. CC, Check, ENR, EFT, Online etc..)",
        TO_NUMBER(''0'') AS "Total number of Recurring EFT payments",
        TO_NUMBER(''0'') AS "Total number of paper check payments",
        TO_NUMBER(''0'') AS "Total number of Optum CSS 1X EFT payments",
        TO_NUMBER(''0'') AS "Total number of Optum CSS 1X CC payments",
        TO_NUMBER(''0'') AS "Total number of Web 1X CC payments",
        TO_NUMBER(''0'') AS "Total number of Web 1X EFT payments",
        TO_NUMBER(''0'') AS "Total number of Quickpay 1x CC Payment",
        TO_NUMBER(''0'') AS "Total number of Quickpay 1x EFT Payment"
        FROM 
        MAIN_PAY_DTL
        
        UNION ALL
        
        SELECT 
        ''YTD'' AS PAYMENT_MONTH,
        ''Previous Year:'' ||TO_CHAR(ADD_MONTHS(:gv_ReportStartDate,-12),''yyyy'') AS YEAR,
        TOTAL_PAYMENT,
        "Total household payment transactions (e.g. CC, Check, ENR, EFT, Online etc..)",
        "Total number of Recurring EFT payments",
        "Total number of paper check payments",
        "Total number of Optum CSS 1X EFT payments",
        "Total number of Optum CSS 1X CC payments",
        "Total number of Web 1X CC payments",
        "Total number of Web 1X EFT payments",
        "Total number of Quickpay 1x CC Payment",
        "Total number of Quickpay 1x EFT Payment"
        FROM 
        MAIN_PAY_DTL
        WHERE 
        MON in (''Jan'',''Feb'',''Mar'',''Apr'',''May'',''Jun'',''Jul'',''Aug'',''Sep'',''Oct'',''Nov'',''Dec'')  
        AND CURRENT_YEAR = TO_CHAR(ADD_MONTHS(:gv_ReportStartDate,-12),''yyyy'')
        AND TO_DATE(''01/''||MONTH_YEAR,''DD/MON/YYYY'') <= ADD_MONTHS(:gv_ReportStopDate ,-12)
        
        UNION ALL
        
        SELECT  
        ''YTD'' AS PAYMENT_MONTH,
        ''Previous Year:'' ||TO_CHAR(ADD_MONTHS(:gv_ReportStartDate,-12),''yyyy'') AS YEAR,
        TO_NUMBER(''0'') AS TOTAL_PAYMENT,
        TO_NUMBER(''0'') AS "Total household payment transactions (e.g. CC, Check, ENR, EFT, Online etc..)",
        TO_NUMBER(''0'') AS "Total number of Recurring EFT payments",
        TO_NUMBER(''0'') AS "Total number of paper check payments",
        TO_NUMBER(''0'') AS "Total number of Optum CSS 1X EFT payments",
        TO_NUMBER(''0'') AS "Total number of Optum CSS 1X CC payments",
        TO_NUMBER(''0'') AS "Total number of Web 1X CC payments",
        TO_NUMBER(''0'') AS "Total number of Web 1X EFT payments",
        TO_NUMBER(''0'') AS "Total number of Quickpay 1x CC Payment",
        TO_NUMBER(''0'') AS "Total number of Quickpay 1x EFT Payment"
        FROM 
        MAIN_PAY_DTL
        )
        GROUP BY
        PAYMENT_MONTH,
        Year
        );

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_MAIN_TAB3)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP5'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE  IDENTIFIER(:V_pv_ReportResult) as 
        SELECT 
        PAYMENT_MONTH,
        YEAR,
        "Total household payment transactions (e.g. CC, Check, ENR, EFT, Online etc..)",
        "Total number of Recurring EFT payments",
        ("Total number of Recurring EFT payments"/TOTAL_PAYMENT) * 100 AS "% of payments that are Recurring EFT",
        "Total number of paper check payments",
        ("Total number of paper check payments"/TOTAL_PAYMENT) * 100 AS "% of payments that are paper check",
        "Total number of Optum CSS 1X EFT payments",
        ("Total number of Optum CSS 1X EFT payments"/TOTAL_PAYMENT) * 100 AS "% of payments that are Optum CSS 1X EFT",
        "Total number of Optum CSS 1X CC payments",
        ("Total number of Optum CSS 1X CC payments"/TOTAL_PAYMENT) * 100 AS "% of payments that are Optum CSS 1X CC",
        "Total number of Web 1X CC payments",
        ("Total number of Web 1X CC payments"/TOTAL_PAYMENT) * 100 AS "% of payments that are Member Web 1X CC",
        "Total number of Web 1X EFT payments",
        ("Total number of Web 1X EFT payments"/TOTAL_PAYMENT) * 100 AS "% of payments that are Member Web 1X EFT",
        "Total number of Quickpay 1x CC Payment",
        ("Total number of Quickpay 1x CC Payment"/TOTAL_PAYMENT) * 100 AS "% of payments that are Quickpay 1x CC Payment",
        "Total number of Quickpay 1x EFT Payment",
        ("Total number of Quickpay 1x EFT Payment"/TOTAL_PAYMENT) * 100 AS "% of payments that are Quickpay 1x EFT Payment",
        CURRENT_TIMESTAMP() AS RUN_DATE,
        :gv_ReportStartDate AS START_DATE,
        :gv_ReportStopDate AS END_DATE
        FROM
        IDENTIFIER(:V_MAIN_TAB3);

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_pv_ReportResult)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP6'';
V_STEP_NAME :=  ''CALL BDR_BI.SP_ISB_SF_LOG_INSERT_COMPLETE(:gv_Log_id)'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CALL BDR_BI.SP_ISB_SF_LOG_INSERT_COMPLETE(:gv_Log_id);

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0 ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




let res_set RESULTSET;
let select_statement1 := ''SELECT * FROM pv_ReportResult'';
res_set := (EXECUTE IMMEDIATE :select_statement1);
RETURN TABLE(res_set);

EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);

gv_error_code := SQLERRM;
CALL BDR_BI.SP_ISB_SF_LOG_INSERT_ERROR(:gv_Log_id, :gv_error_code);

RAISE;

END;

';