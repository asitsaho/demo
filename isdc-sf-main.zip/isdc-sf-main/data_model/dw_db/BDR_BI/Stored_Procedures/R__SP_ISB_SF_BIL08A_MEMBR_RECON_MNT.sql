USE SCHEMA BDR_BI; CREATE OR REPLACE PROCEDURE "SP_ISB_SF_BIL08A_MEMBR_RECON_MNT"("PV_REPORTSTARTDATE" DATE, "PV_REPORTSTOPDATE" DATE, "PV_FREQUENCY" VARCHAR(1), "DB_NAME" VARCHAR(16777216) DEFAULT '', "TGT_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "TGT2_SC" VARCHAR(16777216) DEFAULT '', "SRC_SC" VARCHAR(16777216) DEFAULT 'SRC_DWADM', "SRC2_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "UTIL_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "PIPELINE_ID" VARCHAR(16777216) DEFAULT '', "PIPELINE_NAME" VARCHAR(16777216) DEFAULT 'SP_ISB_SF_BIL08A_MEMBR_RECON_MNT')
RETURNS TABLE ()
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

  gv_ReportStartDate                DATE := DATE(pv_ReportStartDate);
  gv_ReportStopDate                 DATE := DATE(pv_ReportStopDate);
  gv_frequency                      CHAR := pv_frequency;
  gv_Log_id                         NUMBER;
  gv_error_code                     varchar(200);
  gv_day                             VARCHAR(10);



V_START_TIME TIMESTAMP;

V_STEP VARCHAR;
V_LAST_QUERY_ID    VARCHAR;
V_ROWS_LOADED   VARCHAR;
V_PROCESS_NAME   VARCHAR DEFAULT ''SP_ISB_SF_BIL08A_MEMBR_RECON_MNT'';
V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''SP_ISB_SF_BIL08A_MEMBR_RECON_MNT'';
V_STEP_NAME        VARCHAR;
V_ROWS_PARSED      INTEGER;
V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := COALESCE(:UTIL_SC, ''BDR_BI'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';
BEGIN
----DWADM.ADJ_TYPE_DIM
----SRC_DWADM.ADJ_TYPE_DIM
LET V_ADJ_TYPE_DIM VARCHAR :=  :SRC_SC || ''.ADJ_TYPE_DIM'';

----DWADM.PRICE_ASSGN_DIM
----DWADM.PRICE_ASSGN_DIM
LET V_PRICE_ASSGN_DIM VARCHAR :=  :SRC_SC || ''.PRICE_ASSGN_DIM'';

----DWADM.PAYMENT_FACT
----SRC_DWADM.PAYMENT_FACT
LET V_PAYMENT_FACT VARCHAR :=  :SRC_SC || ''.PAYMENT_FACT'';

----PV_REPORTRESULT
----PV_REPORTRESULT
LET V_PV_REPORTRESULT VARCHAR :=  :TGT_SC || ''.PV_REPORTRESULT'';

----DWADM.FT_FACT
----SRC_DWADM.FT_FACT
LET V_FT_FACT VARCHAR :=  :SRC_SC || ''.FT_FACT'';

----DWADM.PAYMENT_TENDERS_FACT
----SRC_DWADM.PAYMENT_TENDERS_FACT
LET V_PAYMENT_TENDERS_FACT VARCHAR :=  :SRC_SC || ''.PAYMENT_TENDERS_FACT'';

----DWADM.CM_MEM_FEE_DL_STG_VW
----BDR_BI.CM_MEM_FEE_DL_STG_VW
LET V_CM_MEM_FEE_DL_STG_VW VARCHAR :=  :SRC2_SC || ''.CM_MEM_FEE_DL_STG_VW'';

----DWADM.ADJUSTMENT_FACT
----SRC_DWADM.ADJUSTMENT_FACT
LET V_ADJUSTMENT_FACT VARCHAR :=  :SRC_SC || ''.ADJUSTMENT_FACT'';




--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP1'';
V_STEP_NAME :=  ''call BDR_BI.FN_ISB_SF_GET_LOG_ID()'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

call BDR_BI.FN_ISB_SF_GET_LOG_ID()
    into :gv_Log_id;

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP2'';
V_STEP_NAME :=  ''CALL BDR_BI.SP_ISB_SF_INSERT_JOB_LOG()'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CALL BDR_BI.SP_ISB_SF_INSERT_JOB_LOG(:gv_Log_id,''BI.PKG_ISB_BILL_REPORTS.SP_ISB_Membership_Reconcilliation_Monthly'',''BIL0008A_ISB_Membership_Reconcilliation_Monthly'');

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0 ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP3'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE pv_ReportResult'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_pv_ReportResult) AS
    
   SELECT 
    SUM(NVL(MEMBERSHIP,0)) AS MEMBERSHIP,
    SUM(NVL(Employer_Business_Membership_Employer,0)) AS Employer_Business_Membership_Employer,
    SUM(NVL(Employer_Business_Membership_Insurance_Solutions,0)) AS Employer_Business_Membership_Insurance_Solutions,
    SUM(NVL(Andrus,0)) AS Andrus,
    SUM(NVL(Funds_Redistributed_to_Membership,0)) AS Funds_Redistributed_to_Membership,
    SUM(NVL(Funds_Redistributed_to_Andrus,0)) AS Funds_Redistributed_to_Andrus,
    SUM(NVL(PROTESTED_MEMBERSHIP,0)) AS PROTESTED_MEMBERSHIP,
    SUM(NVL(PROTESTED_ANDRUS,0)) AS PROTESTED_ANDRUS,
    SUM(NVL(Funds_Reversed_from_Membership,0)) AS Funds_Reversed_from_Membership,
    SUM(NVL(Funds_Reversed_from_Andrus,0)) AS Funds_Reversed_from_Andrus,
    SUM(NVL(Employer_Business_Reversals_Employer,0)) AS Employer_Business_Reversals_Employer,
    SUM(NVL(Employer_Business_Reversals_Insurance_Solutions,0)) AS Employer_Business_Reversals_Insurance_Solutions,
    CURRENT_TIMESTAMP() AS REPORT_RUN_DATE,
    :gv_ReportStartDate AS START_DATE,
    :gv_ReportStopDate AS END_DATE
FROM
    (
        SELECT 

            0 AS MEMBERSHIP,
            0 AS Employer_Business_Membership_Employer,
            0 AS Employer_Business_Membership_Insurance_Solutions,
            0 AS Andrus,
            0 AS Funds_Redistributed_to_Membership,
            0 AS Funds_Redistributed_to_Andrus,
            CASE 
                WHEN PF.FT_TYPE=''Pay Cancellation'' AND PF.SRC_MATCH_TYPE_CD IN (''XFERMEMF'',''XFO'') and PTF.SRC_TNDR_STATUS_DESCR=''Canceled''
                THEN NVL(PF.PAY_AMT,0)
            END AS PROTESTED_MEMBERSHIP,
            CASE
                WHEN PF.FT_TYPE=''Pay Cancellation'' AND PF.SRC_MATCH_TYPE_CD=''XFERADRS'' and PTF.SRC_TNDR_STATUS_DESCR=''Canceled''
                THEN NVL(PF.PAY_AMT,0)
            END AS PROTESTED_ANDRUS, 
            CASE
                WHEN PF.FT_TYPE=''Pay Cancellation'' AND PF.SRC_MATCH_TYPE_CD IN (''XFERMEMF'',''XFO'') and PTF.SRC_TNDR_STATUS_DESCR=''Valid''
                THEN NVL(PF.PAY_AMT,0)                
            END AS Funds_Reversed_from_Membership, 
            CASE
                WHEN
                PF.FT_TYPE = ''Pay Cancellation'' AND PF.SRC_MATCH_TYPE_CD=''XFERADRS'' and PTF.SRC_TNDR_STATUS_DESCR=''Valid''
                THEN NVL(PF.PAY_AMT,0)
            END AS Funds_Reversed_from_Andrus,
            0 AS Employer_Business_Reversals_Employer,
            0 AS Employer_Business_Reversals_Insurance_Solutions
        FROM
        IDENTIFIER(:V_PAYMENT_FACT) PF
        LEFT JOIN IDENTIFIER(:V_PAYMENT_TENDERS_FACT) PTF ON PTF.SRC_PAY_TNDR_ID = PF.SRC_PAY_TNDR_ID
							AND PF.CDC_STATUS_FLAG <> ''D''
							AND PTF.CDC_STATUS_FLAG <> ''D''
        INNER JOIN IDENTIFIER(:V_ADJUSTMENT_FACT) AF ON AF.SRC_MATCH_EVENT_ID = PF.SRC_MATCH_EVENT_ID
                            AND AF.CDC_STATUS_FLAG <> ''D''                    
        WHERE
             AF.SRC_FT_ID IN (SELECT DISTINCT MF.FT_ID FROM IDENTIFIER(:V_CM_MEM_FEE_DL_STG_VW) MF WHERE MF.FT_ID = AF.SRC_FT_ID
	     										AND DATE(MF.CRE_DT) BETWEEN :gv_ReportStartDate AND :gv_ReportStopDate)
        
        UNION ALL
        
        SELECT  
            SUM(CASE WHEN CM_ALLOC_TYPE_FLG IN (''1'',''2'') AND FT_TYPE=''Adjustment'' AND SRC_ADJ_TYPE_CD IN (''ICAARP'',''ICANDRUS'') THEN CUR_AMT ELSE 0 END) AS MEMBERSHIP,
            0 AS Employer_Business_Membership_Employer,
            0 AS Employer_Business_Membership_Insurance_Solutions,
            SUM(CASE WHEN CM_ALLOC_TYPE_FLG IN (''3'') AND FT_TYPE=''Adjustment'' THEN CUR_AMT ELSE 0 END) AS Andrus,
            0 AS Funds_Redistributed_to_Membership,
            0 AS Funds_Redistributed_to_Andrus, 
            SUM(CASE WHEN CM_ALLOC_TYPE_FLG IN (''1'',''2'') AND FT_TYPE=''Adjustment Cancellation'' AND SRC_ADJ_TYPE_CD IN (''ICAARP'',''ICANDRUS'') THEN CUR_AMT ELSE 0 END) AS PROTESTED_MEMBERSHIP,
            SUM(CASE WHEN CM_ALLOC_TYPE_FLG IN (''3'') AND FT_TYPE=''Adjustment Cancellation'' THEN CUR_AMT ELSE 0 END) AS PROTESTED_ANDRUS,
            0 AS Funds_Reversed_from_Membership, 
            0 AS Funds_Reversed_from_Andrus,
            0 AS Employer_Business_Reversals_Employer,
            0 AS Employer_Business_Reversals_Insurance_Solutions
      FROM 
            (
                SELECT MF.FT_ID,
                MF.CM_ALLOC_TYPE_FLG,
                AF.FT_TYPE,
                CASE WHEN NVL(AF.CDDGEN4_VAL,PA.PARAM1_VAL)=''1'' AND AF.FT_TYPE=''Adjustment'' THEN ''Membership and Andrus Collected - 1 Year''
                     WHEN NVL(AF.CDDGEN4_VAL,PA.PARAM1_VAL)=''2'' AND AF.FT_TYPE=''Adjustment'' THEN ''Membership and Andrus Collected - 2 Year''
                     WHEN NVL(AF.CDDGEN4_VAL,PA.PARAM1_VAL)=''3'' AND AF.FT_TYPE=''Adjustment'' THEN ''Membership and Andrus Collected - 3 Year''
                     WHEN CM_ALLOC_TYPE_FLG IN (''1'',''2'') AND AF.FT_TYPE=''Adjustment Cancellation'' THEN ''Protested Membership''
                     WHEN CM_ALLOC_TYPE_FLG IN (''3'') AND AF.FT_TYPE=''Adjustment Cancellation'' THEN ''Protested Andrus''
                     ELSE ''Miscellaneous Membership and Andrus Collected'' END AS ACTIVITY,
                MF.CUR_AMT AS CUR_AMT,
		ATD.SRC_ADJ_TYPE_CD 
                FROM
                IDENTIFIER(:V_CM_MEM_FEE_DL_STG_VW) MF
                LEFT JOIN IDENTIFIER(:V_ADJUSTMENT_FACT) AF ON MF.FT_ID = AF.SRC_FT_ID 
                            AND AF.CDC_STATUS_FLAG <> ''D''
		LEFT OUTER JOIN IDENTIFIER(:V_ADJ_TYPE_DIM) ATD ON ATD.ADJ_TYPE_CURR_KEY=AF.ADJ_TYPE_CURR_KEY AND ATD.CURR_REC_FLAG = ''Y''
                LEFT JOIN IDENTIFIER(:V_PRICE_ASSGN_DIM) PA ON to_number(PA.UDF1_VAL) = MF.CUR_AMT  
                            AND PA.PRASSGN_PRICELIST_ID = ''8846370327'' AND PA.PRASSGN_PRITM_CD = ''AARPFEE''
                            AND PA.CURR_REC_FLAG = ''Y''
                            AND :gv_ReportStartDate BETWEEN DATE(EFF_START_DT) AND DATE(EFF_END_DT)
                WHERE
                    MF.CDC_FLAG <> ''D''
                    AND DATE(MF.CRE_DT) BETWEEN :gv_ReportStartDate AND :gv_ReportStopDate
            )
        
        UNION ALL
        
        SELECT 
            0 AS MEMBERSHIP,
            CASE
                WHEN ATD.SRC_ADJ_TYPE_CD = ''CMAARPAD'' AND FD.CUR_AMT > 0
                THEN FD.CUR_AMT
            END AS Employer_Business_Membership_Employer,
            CASE
                WHEN ATD.SRC_ADJ_TYPE_CD = ''CMAARP-O'' AND FD.CUR_AMT > 0
                THEN FD.CUR_AMT
            END AS Employer_Business_Membership_Insurance_Solutions,
            0 AS Andrus,
            0 AS Funds_Redistributed_to_Membership,
            0 AS Funds_Redistributed_to_Andrus,
            0 AS PROTESTED_MEMBERSHIP,
            0 AS PROTESTED_ANDRUS, 
            0 AS Funds_Reversed_from_Membership, 
            0 AS Funds_Reversed_from_Andrus,
            CASE
                WHEN ATD.SRC_ADJ_TYPE_CD = ''CMAARPAD'' AND FD.CUR_AMT < 0
                THEN FD.CUR_AMT
            END AS Employer_Business_Reversals_Employer,
            CASE
                WHEN ATD.SRC_ADJ_TYPE_CD = ''CMAARP-O'' AND FD.CUR_AMT < 0
                THEN FD.CUR_AMT
            END AS Employer_Business_Reversals_Insurance_Solutions
        FROM
        IDENTIFIER(:V_FT_FACT) FD
        INNER JOIN IDENTIFIER(:V_ADJUSTMENT_FACT) AD ON AD.SRC_FT_ID = FD.SRC_FT_ID
        INNER JOIN IDENTIFIER(:V_ADJ_TYPE_DIM) ATD ON AD.ADJ_TYPE_CURR_KEY = ATD.ADJ_TYPE_CURR_KEY 
					 AND ATD.CURR_REC_FLAG = ''Y''
                     AND ATD.SRC_ADJ_TYPE_CD IN (''CMAARPAD'',''CMAARP-O'')
					 AND FD.CDC_STATUS_FLAG <> ''D''
					 AND AD.CDC_STATUS_FLAG <> ''D''
					 
        WHERE
             FD.SRC_FT_ID IN (SELECT DISTINCT MF.FT_ID FROM IDENTIFIER(:V_CM_MEM_FEE_DL_STG_VW) MF WHERE MF.FT_ID = FD.SRC_FT_ID
	     										AND DATE(MF.CRE_DT) BETWEEN :gv_ReportStartDate AND :gv_ReportStopDate)               
    );

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_PV_REPORTRESULT)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP4'';
V_STEP_NAME :=  ''CALL BDR_BI.SP_ISB_SF_LOG_INSERT_COMPLETE(:gv_Log_id)'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CALL BDR_BI.SP_ISB_SF_LOG_INSERT_COMPLETE(:gv_Log_id);

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0 ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




let res_set RESULTSET;
let select_statement1 := ''SELECT * FROM pv_ReportResult'';
res_set := (EXECUTE IMMEDIATE :select_statement1);
RETURN TABLE(res_set);

EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);

gv_error_code := SQLERRM;
CALL BDR_BI.SP_ISB_SF_LOG_INSERT_ERROR(:gv_Log_id, :gv_error_code);

RAISE;

END;

';