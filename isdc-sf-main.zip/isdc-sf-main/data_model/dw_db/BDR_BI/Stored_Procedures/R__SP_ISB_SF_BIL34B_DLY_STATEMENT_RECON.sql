USE SCHEMA BDR_BI; CREATE OR REPLACE PROCEDURE "SP_ISB_SF_BIL34B_DLY_STATEMENT_RECON"("PV_REPORTSTARTDATE" DATE, "PV_REPORTSTOPDATE" DATE, "DB_NAME" VARCHAR(16777216) DEFAULT '', "TGT_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "TGT2_SC" VARCHAR(16777216) DEFAULT '', "SRC_SC" VARCHAR(16777216) DEFAULT 'SRC_DWADM', "SRC2_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "UTIL_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "PIPELINE_ID" VARCHAR(16777216) DEFAULT '', "PIPELINE_NAME" VARCHAR(16777216) DEFAULT 'SP_ISB_SF_BIL34B_DLY_STATEMENT_RECON')
RETURNS TABLE ()
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

  gv_ReportStartDate                DATE := DATE(pv_ReportStartDate);
  gv_ReportStopDate                DATE := DATE(Pv_ReportStopDate);
  gv_Log_id                         NUMBER;
  gv_error_code                     varchar(200);



V_START_TIME TIMESTAMP;

V_STEP VARCHAR;
V_LAST_QUERY_ID    VARCHAR;
V_ROWS_LOADED   VARCHAR;
V_PROCESS_NAME   VARCHAR DEFAULT ''SP_ISB_SF_BIL34B_DLY_STATEMENT_RECON'';
V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''SP_ISB_SF_BIL34B_DLY_STATEMENT_RECON'';
V_STEP_NAME        VARCHAR;
V_ROWS_PARSED      INTEGER;
V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := COALESCE(:UTIL_SC, ''BDR_BI'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';
BEGIN
----PNZ
----PNZ
LET V_PNZ VARCHAR :=  :TGT_SC || ''.PNZ'';

----PRESCRIPTION
----PRESCRIPTION
LET V_PRESCRIPTION VARCHAR :=  :TGT_SC || ''.PRESCRIPTION'';

----IDENTIFIER(:V_TNDR_TYPE_DIM
----SRC_IDENTIFIER(:V_TNDR_TYPE_DIM
LET V_TNDR_TYPE_DIM VARCHAR :=  :SRC_SC || ''.TNDR_TYPE_DIM'';

----IDENTIFIER(:V_PAYMENT_TENDERS_FACT
----SRC_IDENTIFIER(:V_PAYMENT_TENDERS_FACT
LET V_PAYMENT_TENDERS_FACT VARCHAR :=  :SRC_SC || ''.PAYMENT_TENDERS_FACT'';

----MONTHLY_PAYMENT_COHORT
----MONTHLY_PAYMENT_COHORT
LET V_MONTHLY_PAYMENT_COHORT VARCHAR :=  :TGT_SC || ''.MONTHLY_PAYMENT_COHORT'';

----IDENTIFIER(:V_PAYMENT_FACT
----SRC_IDENTIFIER(:V_PAYMENT_FACT
LET V_PAYMENT_FACT VARCHAR :=  :SRC_SC || ''.PAYMENT_FACT'';

----IDENTIFIER(:V_ACCOUNT_DIM
----SRC_IDENTIFIER(:V_ACCOUNT_DIM
LET V_ACCOUNT_DIM VARCHAR :=  :SRC_SC || ''.ACCOUNT_DIM'';

----PDP
----PDP
LET V_PDP VARCHAR :=  :TGT_SC || ''.PDP'';

----CLAIM
----CLAIM
LET V_CLAIM VARCHAR :=  :TGT_SC || ''.CLAIM'';

----MONTHLY_COHORT
----MONTHLY_COHORT
LET V_MONTHLY_COHORT VARCHAR :=  :TGT_SC || ''.MONTHLY_COHORT'';

----MONTHLY_PAYMENT_TENDERS_COHORT
----MONTHLY_PAYMENT_TENDERS_COHORT
LET V_MONTHLY_PAYMENT_TENDERS_COHORT VARCHAR :=  :TGT_SC || ''.MONTHLY_PAYMENT_TENDERS_COHORT'';

----COMPARE_RESULTS
----COMPARE_RESULTS
LET V_COMPARE_RESULTS VARCHAR :=  :TGT_SC || ''.COMPARE_RESULTS'';

----IDENTIFIER(:V_TNDR_SRC_DIM
----SRC_IDENTIFIER(:V_TNDR_SRC_DIM
LET V_TNDR_SRC_DIM VARCHAR :=  :SRC_SC || ''.TNDR_SRC_DIM'';

----PV_REPORTRESULT
----PV_REPORTRESULT
LET V_PV_REPORTRESULT VARCHAR :=  :TGT_SC || ''.PV_REPORTRESULT'';

----IDENTIFIER(:V_CONTRACT_DIM
----SRC_IDENTIFIER(:V_CONTRACT_DIM
LET V_CONTRACT_DIM VARCHAR :=  :SRC_SC || ''.CONTRACT_DIM'';




--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP1'';
V_STEP_NAME :=  ''call BDR_BI.FN_ISB_SF_GET_LOG_ID()'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

call BDR_BI.FN_ISB_SF_GET_LOG_ID()
    into :gv_Log_id;

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0 ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP2'';
V_STEP_NAME :=  ''CALL BDR_BI.SP_ISB_SF_INSERT_JOB_LOG()'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CALL BDR_BI.SP_ISB_SF_INSERT_JOB_LOG(:gv_Log_id,''BI.PKG_ISB_BILL_REPORTS.SP_ISB_DAILY_STATEMENT_RECON'',''BIL0034B_ISB_Daily_Statement_Recon'');

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0 ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP3'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE monthly_payment_tenders_cohort'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_monthly_payment_tenders_cohort) AS
    (   SELECT
            a.src_pay_tndr_id,
             DATE(a.PAY_EVENT_CREATE_DT) AS PAY_EVENT_CREATE_DT,
            a.SRC_TNDR_STATUS_DESCR,
            b.TNDR_TYPE_DESCR,
            b.GENERATE_APAY_SW,
            c.TNDR_SOURCE_DESCR,
            c.EXT_SOURCE_ID,
            c.TNDR_SOURCE_TYPE_DESCR,
            CASE
                WHEN ad.ACCT_NBR_TYPE = ''EMPBLGID''
                THEN ''Yes''
                ELSE NULL
            END AS EMPLOYER_ACCT,
            CASE
                WHEN a.SRC_TNDR_STATUS_DESCR = ''Canceled''
                THEN a.tndr_amt
                ELSE 0
            END AS cncl_tndr_amt,
            CASE
                WHEN a.SRC_TNDR_STATUS_DESCR <> ''Canceled''
                THEN a.tndr_amt
                ELSE 0
            END AS tndr_amt
        FROM
            IDENTIFIER(:V_payment_tenders_fact) a
        LEFT OUTER JOIN
            IDENTIFIER(:V_tndr_type_dim) b
        ON
            a.TNDR_TYPE_CURR_KEY = b.TNDR_TYPE_CURR_KEY
        AND b.curr_rec_flag = ''Y''
        LEFT OUTER JOIN
            IDENTIFIER(:V_TNDR_SRC_DIM) c
        ON
            a.TNDR_SRC_CURR_KEY = c.TNDR_SRC_CURR_KEY
        AND c.curr_rec_flag = ''Y''
        LEFT OUTER JOIN
            IDENTIFIER(:V_account_dim) ad
        ON
            a.acct_curr_key = ad.acct_curr_key
        AND ad.curr_rec_flag = ''Y''
        WHERE
            TRUNC(a.pay_event_create_dt::DATE,''month'') =  TRUNC(:gv_ReportStopDate::DATE,''mm'')
            /*    to_date ( TO_CHAR(DATE(a.PAY_EVENT_CREATE_DT),''mm/dd/yyyy hh24:mi:ss''),
            ''mm/dd/yyyy hh24:mi:ss'' ) BETWEEN to_date ( ''4/30/2024 10:30:18 PM'',
            ''MM/DD/YYYY hh:mi:ss PM'' ) AND to_date ( ''5/31/2024 11:50:19 PM'' ,
            ''MM/DD/YYYY hh:mi:ss PM'' )*/
        AND a.CDC_STATUS_FLAG <> ''D''
    );

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_monthly_payment_tenders_cohort)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP4'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE monthly_payment_cohort'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE  IDENTIFIER(:V_monthly_payment_cohort) AS
    (   SELECT
            b.SRC_PAY_TNDR_ID,
            b.UDDGEN18,
            b.UDDGEN19,
            MAX(
            CASE
                WHEN c.SA_TYPE_DESC = ''Retroactivity''
                THEN ''Yes''
                ELSE ''No''
            END)                                       AS retroactivity,
            MIN(DATE(b.FREEZE_DT))                    AS MIN_FREEZE_DT,
            MAX(DATE(b.FREEZE_DT))                    AS MAX_FREEZE_DT,
            MAX(NVL(DATE(B.CANCEL_DT),''01-Jan-1980'')) AS max_cancel_dt,
            SUM(
            CASE
                WHEN SIGN(NVL(b.pay_amt,0)) = 1
                THEN NVL(b.pay_amt,0)
                ELSE 0
            END) AS pos_pay_amt,
            SUM(
            CASE
                WHEN SIGN(NVL(b.pay_amt,0)) = -1
                THEN NVL(b.pay_amt,0)
                ELSE 0
            END)                  AS neg_pay_amt,
            SUM(NVL(b.pay_amt,0)) AS pay_amt,
            SUM(
            CASE
                WHEN b.SRC_MATCH_TYPE_CD = ''XFO''
                THEN b.pay_amt
                ELSE 0
            END) AS XFO_AMT,
            SUM(
            CASE
                WHEN b.SRC_MATCH_TYPE_CD = ''XFERMEMF''
                THEN b.pay_amt
                ELSE 0
            END) AS XFERMEMF_AMT,
            SUM(
            CASE
                WHEN b.SRC_MATCH_TYPE_CD = ''SUS''
                THEN b.pay_amt
                ELSE 0
            END) AS SUS_AMT,
            SUM(
            CASE
                WHEN b.SRC_MATCH_TYPE_CD = ''BILWPRPD''
                THEN b.pay_amt
                ELSE 0
            END) AS BILWPRPD_AMT,
            SUM(
            CASE
                WHEN b.SRC_MATCH_TYPE_CD = ''BINDPY''
                THEN b.pay_amt
                ELSE 0
            END) AS BINDPY_AMT,
            SUM(
            CASE
                WHEN b.SRC_MATCH_TYPE_CD = ''NAF''
                THEN b.pay_amt
                ELSE 0
            END) AS NAF_AMT,
            SUM(
            CASE
                WHEN b.SRC_MATCH_TYPE_CD = ''XFERADRS''
                THEN b.pay_amt
                ELSE 0
            END) AS XFERADRS_AMT,
            SUM(
            CASE
                WHEN b.SRC_MATCH_TYPE_CD NOT IN (''XFO'',
                                                 ''XFERMEMF'',
                                                 ''SUS'',
                                                 ''BILWPRPD'',
                                                 ''BINDPY'',
                                                 ''NAF'',
                                                 ''XFERADRS'')
                THEN b.pay_amt
                ELSE 0
            END) AS other_amt
        FROM
            IDENTIFIER(:V_payment_fact) b
        LEFT OUTER JOIN
            IDENTIFIER(:V_contract_dim) c
        ON
            b.CONTRACT_CURR_KEY = c.CONTRACT_CURR_KEY
        AND c.curr_rec_flag = ''Y''
        WHERE
            b.CDC_STATUS_FLAG <> ''D''
        AND TRUNC(b.freeze_dt::DATE,''month'') =  TRUNC(:gv_ReportStopDate::DATE,''mm'')
            /*      AND to_date ( TO_CHAR(DATE(b.freeze_dt),''mm/dd/yyyy hh24:mi:ss''),
            ''mm/dd/yyyy hh24:mi:ss'' ) BETWEEN to_date (''4/30/2024 10:30:18 PM'',
            ''MM/DD/YYYY hh:mi:ss PM'') AND to_date (''5/31/2024 11:50:19 PM'' ,
            ''MM/DD/YYYY hh:mi:ss PM'')*/
        GROUP BY
            b.SRC_PAY_TNDR_ID,
            b.UDDGEN18,
            b.UDDGEN19
    );

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_monthly_payment_cohort)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP5'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE compare_results'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE  IDENTIFIER(:V_compare_results) AS
    (   SELECT
            COALESCE (a.SRC_PAY_TNDR_ID, b.SRC_PAY_TNDR_ID) AS SRC_PAY_TNDR_ID,
            b.SRC_TNDR_STATUS_DESCR,
            b.TNDR_TYPE_DESCR,
            b.GENERATE_APAY_SW,
            b.TNDR_SOURCE_DESCR,
            b.EXT_SOURCE_ID,
            b.TNDR_SOURCE_TYPE_DESCR,
            b.EMPLOYER_ACCT,
            a.UDDGEN18,
            a.UDDGEN19,
            a.retroactivity,
            NVL(b.tndr_amt,0)      AS tndr_amt,
            NVL(b.cncl_tndr_amt,0) AS cncl_tndr_amt,
            b.PAY_EVENT_CREATE_DT,
            a.min_freeze_dt,
            a.max_freeze_dt,
            a.max_cancel_dt,
            CASE
                WHEN a.SRC_PAY_TNDR_ID IS NULL
                THEN ''Yes''
                ELSE NULL
            END AS Tender_Only,
            CASE
                WHEN b.SRC_PAY_TNDR_ID IS NULL
                THEN ''Yes''
                ELSE NULL
            END                                                   AS Payment_Only,
            NVL(a.pos_pay_amt,0)                                              AS pos_pay_amt,
            NVL(a.neg_pay_amt,0)                                              AS neg_pay_amt,
            NVL(a.pay_amt,0)                                                  AS pay_amt,
            NVL(a.XFO_AMT,0)                                                  AS XFO_AMT,
            NVL(a.XFERMEMF_AMT,0)                                             AS XFERMEMF_AMT,
            NVL(a.SUS_AMT,0)                                                  AS SUS_AMT,
            NVL(a.BILWPRPD_AMT,0)                                             AS BILWPRPD_AMT,
            NVL(a.BINDPY_AMT,0)                                               AS BINDPY_AMT,
            NVL(a.NAF_AMT,0)                                                  AS NAF_AMT,
            NVL(a.XFERADRS_AMT,0)                                             AS XFERADRS_AMT,
            NVL(a.other_amt,0)                                                AS OTHER_AMT ,
            (NVL(a.pos_pay_amt,0) + NVL(a.neg_pay_amt,0)) - NVL(b.tndr_amt,0) AS diff
        FROM
            IDENTIFIER(:V_monthly_payment_cohort) a
        FULL OUTER JOIN
            IDENTIFIER(:V_monthly_payment_tenders_cohort) b
        ON
            a.SRC_PAY_TNDR_ID = b.SRC_PAY_TNDR_ID
    );

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_compare_results)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP6'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE monthly_cohort'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE  IDENTIFIER(:V_monthly_cohort) AS
    (   SELECT
            a.PAY_EVENT_CREATE_DT,
            a.SRC_TNDR_STATUS_DESCR,
            a.TNDR_TYPE_DESCR,
            a.GENERATE_APAY_SW,
            a.TNDR_SOURCE_DESCR,
            a.EXT_SOURCE_ID,
            a.TNDR_SOURCE_TYPE_DESCR,
            a.EMPLOYER_ACCT,
            a.UDDGEN18,
            a.UDDGEN19,
            a.retroactivity,
            a.min_freeze_dt,
            a.max_freeze_dt,
            CASE
                WHEN a.max_cancel_dt = ''01-Jan-1980''
                THEN NULL
                ELSE a.max_cancel_dt
            END AS max_cancel_dt,
            tender_only,
            payment_only,
            COUNT(DISTINCT a.src_pay_tndr_id) AS rec_cnt,
            SUM(a.tndr_amt)                   AS tndr_amt,
            SUM(a.cncl_tndr_amt)              AS cncl_tndr_amt,
            SUM(a.pos_pay_amt)                AS pos_pay_amt,
            SUM(a.neg_pay_amt)                AS neg_pay_amt,
            SUM(a.pay_amt)                    AS pay_amt,
            SUM(a.XFO_AMT)                    AS XFO_AMT,
            SUM(a.XFERMEMF_AMT)               AS XFERMEMF_AMT,
            SUM(a.SUS_AMT)                    AS SUS_AMT,
            SUM(a.BILWPRPD_AMT)               AS BILWPRPD_AMT,
            SUM(a.BINDPY_AMT)                 AS BINDPY_AMT,
            SUM(a.NAF_AMT)                    AS NAF_AMT,
            SUM(a.XFERADRS_AMT)               AS XFERADRS_AMT,
            SUM(a.other_amt)                  AS OTHER_AMT ,
            SUM(a.diff)                       AS diff
        FROM
            IDENTIFIER(:V_compare_results) a
        GROUP BY
            a.PAY_EVENT_CREATE_DT,
            a.SRC_TNDR_STATUS_DESCR,
            a.TNDR_TYPE_DESCR,
            a.GENERATE_APAY_SW,
            a.TNDR_SOURCE_DESCR,
            a.EXT_SOURCE_ID,
            a.TNDR_SOURCE_TYPE_DESCR,
            a.EMPLOYER_ACCT,
            a.UDDGEN18,
            a.UDDGEN19,
            a.retroactivity,
            a.min_freeze_dt,
            a.max_freeze_dt,
            CASE
                WHEN a.max_cancel_dt = ''01-Jan-1980''
                THEN NULL
                ELSE a.max_cancel_dt
            END,
            tender_only,
            payment_only
    );

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_monthly_cohort)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP7'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE pv_ReportResult'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_pv_ReportResult) as
SELECT PAY_EVENT_CREATE_DT,
    CASE
        WHEN a.TNDR_SOURCE_DESCR = ''JP Morgan - Transfers''
        THEN ''Transfer - JPMC''
        WHEN a.TNDR_SOURCE_DESCR = ''MISSING''
        THEN ''Missing''
        WHEN a.ext_source_id = ''EXSIDCOMPAS''
        THEN ''COMPAS''
        WHEN a.tndr_type_descr = ''CHK - Check''
        AND a.tndr_source_descr IN (''BNY Lockbox - Pittsburgh'',
                                    ''BNY Lockbox - Dallas'' )
        THEN ''Lockbox''
        WHEN (
                a.TNDR_SOURCE_TYPE_DESCR = ''Auto Pay''
            OR  a.TNDR_TYPE_DESCR IN (''Automatic Payment - Checking'',
                                      ''Automatic Payment - Saving''))
        AND a.TNDR_SOURCE_DESCR <> ''PENSION PAYER''
        THEN ''EFT''
        WHEN a.TNDR_SOURCE_DESCR = ''Enrollment Payments''
        THEN ''Enrollment''
        WHEN a.TNDR_TYPE_DESCR = ''3rd Party''
        THEN ''Third Party''
        WHEN a.TNDR_TYPE_DESCR = ''Credit Card''
        AND a.TNDR_SOURCE_DESCR = ''JPM CC''
        AND a.UDDGEN19 NOT IN (''WEB'',
                               ''WEB-QUICKPAY'')
        AND a.UDDGEN18 =''ONETIMECCSYS''
        THEN ''Credit Card - Automated''
        WHEN a.TNDR_TYPE_DESCR = ''Credit Card''
        AND a.TNDR_SOURCE_DESCR = ''JPM CC''
        AND a.UDDGEN19 IN (''WEB'',
                           ''WEB-QUICKPAY'')
        AND a.UDDGEN18 =''ONETIMECCSYS''
        THEN ''One-time Credit Card''
        WHEN a.TNDR_TYPE_DESCR = ''Credit Card''
        AND a.TNDR_SOURCE_DESCR = ''JPM CC''
        AND a.UDDGEN19 IS NULL
        THEN ''Credit Card - Add Payment''
        WHEN a.TNDR_SOURCE_DESCR = ''Transfer from Prescription Drug Program''
        THEN ''From PDP''
        WHEN a.TNDR_TYPE_DESCR = ''Pension Payment - Saving''
        THEN ''Pension''
        WHEN a.TNDR_SOURCE_DESCR = ''Transfer from PNZ/EZ CLAIM''
        THEN ''From Claim''
        WHEN a.TNDR_TYPE_DESCR = ''Wire Payment - Checking''
        THEN ''Wire''
        ELSE ''Other''
    END AS Source ,
    --  a.employer_acct AS employer,
    --  a.retroactivity,
    SUM(a.rec_cnt)       AS cnt,
    SUM(a.tndr_amt)      AS tnder_amt,
    SUM(a.cncl_tndr_amt) AS cncl_tndr_amt,
    SUM(a.pay_amt)       AS pay_amt,
    SUM(diff)            AS diff_tndr_and_payment_amt,
    SUM(
    CASE
        WHEN a.tender_only = ''Yes''
        THEN a.tndr_amt
        ELSE 0
    END) AS tndr_only_amt,
    SUM(
    CASE
        WHEN a.payment_only = ''Yes''
        THEN a.pay_amt
        ELSE 0
    END) AS payment_only_amt,
    SUM(
    CASE
        WHEN a.tndr_amt = 0
        AND a.pay_amt <> 0
        THEN a.pay_amt
        ELSE 0
    END)              AS remain_payment_cncl_tndr_amt,
    SUM(XFO_AMT)      AS transferred_out_amt,
    SUM(XFERMEMF_AMT) AS membership_amt,
    SUM(SUS_AMT)      AS general_suspense_amt,
    SUM(BILWPRPD_AMT) AS premium_amt,
    SUM(BINDPY_AMT)   AS enrollment_amt,
    SUM(NAF_AMT)      AS on_account_amt,
    SUM(XFERADRS_AMT) AS andrus_amt,
    SUM(OTHER_AMT)    AS other_amt,
    CURRENT_TIMESTAMP AS RUN_DATE,
    TRUNC(:gv_ReportStopDate::DATE,''mm'') AS START_DATE,
    :gv_ReportStopDate AS END_DATE
FROM
    IDENTIFIER(:V_monthly_cohort) a
   
GROUP BY PAY_EVENT_CREATE_DT,Source
    -- CASE
    --     WHEN a.TNDR_SOURCE_DESCR = ''JP Morgan - Transfers''
    --     THEN ''Transfer - JPMC''
    --     WHEN a.TNDR_SOURCE_DESCR = ''MISSING''
    --     THEN ''Missing''
    --     WHEN a.ext_source_id = ''EXSIDCOMPAS''
    --     THEN ''COMPAS''
    --     WHEN a.tndr_type_descr = ''CHK - Check''
    --     AND a.tndr_source_descr IN (''BNY Lockbox - Pittsburgh'',
    --                                 ''BNY Lockbox - Dallas'' )
    --     THEN ''Lockbox''
    --     WHEN (
    --             a.TNDR_SOURCE_TYPE_DESCR = ''Auto Pay''
    --         OR  a.TNDR_TYPE_DESCR IN (''Automatic Payment - Checking'',
    --                                   ''Automatic Payment - Saving''))
    --     AND a.TNDR_SOURCE_DESCR <> ''PENSION PAYER''
    --     THEN ''EFT''
    --     WHEN a.TNDR_SOURCE_DESCR = ''Enrollment Payments''
    --     THEN ''Enrollment''
    --     WHEN a.TNDR_TYPE_DESCR = ''3rd Party''
    --     THEN ''Third Party''
    --     WHEN a.TNDR_TYPE_DESCR = ''Credit Card''
    --     AND a.TNDR_SOURCE_DESCR = ''JPM CC''
    --     AND a.UDDGEN19 NOT IN (''WEB'',
    --                            ''WEB-QUICKPAY'')
    --     AND a.UDDGEN18 =''ONETIMECCSYS''
    --     THEN ''Credit Card - Automated''
    --     WHEN a.TNDR_TYPE_DESCR = ''Credit Card''
    --     AND a.TNDR_SOURCE_DESCR = ''JPM CC''
    --     AND a.UDDGEN19 IN (''WEB'',
    --                        ''WEB-QUICKPAY'')
    --             AND a.UDDGEN18 =''ONETIMECCSYS''
    --     THEN ''One-time Credit Card''
    --     WHEN a.TNDR_TYPE_DESCR = ''Credit Card''
    --     AND a.TNDR_SOURCE_DESCR = ''JPM CC''
    --     AND a.UDDGEN19 IS NULL
    --     THEN ''Credit Card - Add Payment''
    --     WHEN a.TNDR_SOURCE_DESCR = ''Transfer from Prescription Drug Program''
    --     THEN ''From PDP''
    --     WHEN a.TNDR_TYPE_DESCR = ''Pension Payment - Saving''
    --     THEN ''Pension''
    --     WHEN a.TNDR_SOURCE_DESCR = ''Transfer from PNZ/EZ CLAIM''
    --     THEN ''From Claim''
    --     WHEN a.TNDR_TYPE_DESCR = ''Wire Payment - Checking''
    --     THEN ''Wire''
    --     ELSE ''Other''
    -- END --,
    --  a.employer_acct,
    --  a.retroactivity
order by 1,2;


 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_PV_REPORTRESULT)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP8'';
V_STEP_NAME :=  ''CALL BDR_BI.SP_ISB_SF_LOG_INSERT_COMPLETE(:gv_Log_id)'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CALL BDR_BI.SP_ISB_SF_LOG_INSERT_COMPLETE(:gv_Log_id);

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0 ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




let res_set RESULTSET;
let select_statement1 := ''SELECT * FROM pv_ReportResult'';
res_set := (EXECUTE IMMEDIATE :select_statement1);
RETURN TABLE(res_set);

EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);

gv_error_code := SQLERRM;
CALL BDR_BI.SP_ISB_SF_LOG_INSERT_ERROR(:gv_Log_id, :gv_error_code);

RAISE;

END;

';