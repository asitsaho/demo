CREATE OR REPLACE PROCEDURE BDR_BI.SP_ISB_SF_BIL34A_MNT_STMT_RECON("PV_REPORTSTARTDATE" DATE, "DB_NAME" VARCHAR(16777216) DEFAULT '', "TGT_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "TGT2_SC" VARCHAR(16777216) DEFAULT '', "SRC_SC" VARCHAR(16777216) DEFAULT 'BDR_DM', "SRC2_SC" VARCHAR(16777216) DEFAULT '', "UTIL_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "PIPELINE_ID" VARCHAR(16777216) DEFAULT '', "PIPELINE_NAME" VARCHAR(16777216) DEFAULT 'SP_ISB_SF_BIL34A_MNT_STMT_RECON')
RETURNS TABLE ()
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

  gv_ReportStartDate                DATE := DATE(pv_ReportStartDate);
  gv_Log_id                         NUMBER;
  gv_error_code                     varchar(200);




V_START_TIME TIMESTAMP;

V_STEP VARCHAR;
V_LAST_QUERY_ID    VARCHAR;
V_ROWS_LOADED   VARCHAR;
V_PROCESS_NAME   VARCHAR DEFAULT ''SP_ISB_SF_BIL34A_MNT_STMT_RECON'';
V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''SP_ISB_SF_BIL34A_MNT_STMT_RECON'';
V_STEP_NAME        VARCHAR;
V_ROWS_PARSED      INTEGER;
V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := COALESCE(:UTIL_SC, ''BDR_BI'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';
BEGIN
----PV_REPORTRESULT
----PV_REPORTRESULT
LET V_PV_REPORTRESULT VARCHAR :=  :TGT_SC || ''.PV_REPORTRESULT'';

----COMPAS_MO.RIA_DAILY_RECON
----COMPAS_MO.RIA_DAILY_RECON
LET V_RIA_DAILY_RECON VARCHAR :=  :SRC_SC || ''.RIA_DAILY_RECON'';




--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP1'';
V_STEP_NAME :=  ''call BDR_BI.FN_ISB_SF_GET_LOG_ID()'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

call BDR_BI.FN_ISB_SF_GET_LOG_ID()
    into :gv_Log_id;

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0 ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP2'';
V_STEP_NAME :=  ''CALL BDR_BI.SP_ISB_SF_INSERT_JOB_LOG()'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CALL BDR_BI.SP_ISB_SF_INSERT_JOB_LOG(:gv_Log_id,''BI.PKG_ISB_BILL_REPORTS.SP_ISB_MONTHLY_STATEMENT_RECONCILIATION'',''BIL0034A_ISB_Monthly_Statement_Reconciliation'');

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0 ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP3'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE pv_ReportResult'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_pv_ReportResult) AS
    
    SELECT
    lockbox_total_amt,
    eft_total_amt,
    enrollment_total_amt,
    thirdparty_total_amt,
    CREDITCARD_AUTO_AMT,
    CREDIT_ADDPAYMENT_TOTAL,
    pension_total,
    online_check_total_amt,
    online_wire_total_amt,
    online_misc_total_amt,
    transfer_from_pdp_total,
    
    refunds,
    manual_returns_total,
    eft_returns_total,				
    bank_adjustment_total,
    
    aa_misc_loss_total_amt,
    premium_waiver_total,
    aa_prorated_credit_total_amt,					
    aa_prorated_loss_total_amt,				
    aa_retro_credit_total_amt,				
    aa_retro_debit_total_amt,
    
    claims_total,
    unclaimed_norefunds_total,
    unclaimed_refunds,				
    membership_paid_total,				
    emp_membership_total,
    transfer_to_pdp_total,
    
    (lockbox_total_amt +
    eft_total_amt +
    enrollment_total_amt +
    thirdparty_total_amt +
    CREDITCARD_AUTO_AMT +
    CREDIT_ADDPAYMENT_TOTAL +
    pension_total +
    online_check_total_amt +
    online_wire_total_amt +
    online_misc_total_amt +
    transfer_from_pdp_total +
    refunds +
    manual_returns_total +
    eft_returns_total +				
    bank_adjustment_total +
    aa_misc_loss_total_amt +
    premium_waiver_total +
    aa_prorated_credit_total_amt +					
    aa_prorated_loss_total_amt +				
    aa_retro_credit_total_amt +				
    aa_retro_debit_total_amt +
    claims_total +
    unclaimed_norefunds_total +
    unclaimed_refunds +				
    membership_paid_total +				
    emp_membership_total +
    transfer_to_pdp_total) as subtotal_total_amount,
    
    ar_prior_to_retro_date,				
    households_waiting_recalc_amt,				
    On_Billing_Trans_Only, ---scr 36426 June 2012 release: corrected the calculation syntax				
    on_monetary_trans_only_total,				
    Overstated_employer_total,								
    overstated_reduced_Naf_total ,				
    protested_emp_credit_total,				
    EXCESS_PRORATED_CREDIT_total ,				
    added_fromPriormonth_total,
    
    (lockbox_total_amt +
    eft_total_amt +
    enrollment_total_amt +
    thirdparty_total_amt +
    CREDITCARD_AUTO_AMT +
    CREDIT_ADDPAYMENT_TOTAL +
    pension_total +
    online_check_total_amt +
    online_wire_total_amt +
    online_misc_total_amt +
    transfer_from_pdp_total +
    refunds +
    manual_returns_total +
    eft_returns_total +				
    bank_adjustment_total +
    aa_misc_loss_total_amt +
    premium_waiver_total +
    aa_prorated_credit_total_amt +					
    aa_prorated_loss_total_amt +				
    aa_retro_credit_total_amt +				
    aa_retro_debit_total_amt +
    claims_total +
    unclaimed_norefunds_total +
    unclaimed_refunds +				
    membership_paid_total +				
    emp_membership_total +
    transfer_to_pdp_total +
    ar_prior_to_retro_date +				
    households_waiting_recalc_amt +				
    On_Billing_Trans_Only + ---scr 36426 June 2012 release: corrected the calculation syntax				
    on_monetary_trans_only_total +				
    Overstated_employer_total +								
    overstated_reduced_Naf_total +				
    protested_emp_credit_total +				
    EXCESS_PRORATED_CREDIT_total +				
    added_fromPriormonth_total) as grand_total_of_total_amount,
    CURRENT_TIMESTAMP AS RUN_DATE,
    :gv_ReportStartDate AS START_DATE
    --gv_ReportStopDate AS END_DATE
    FROM
    (
        SELECT
            NVL(lockbox_total_amt,0) AS lockbox_total_amt,
            NVL(eft_total_amt,0) AS eft_total_amt,
            NVL(enrollment_total_amt,0) AS enrollment_total_amt,
            NVL(thirdparty_total_amt,0) AS thirdparty_total_amt,
            NVL(auto_credit_total_amt,0) as CREDITCARD_AUTO_AMT,
            NVL(online_credit_total_amt,0) as CREDIT_ADDPAYMENT_TOTAL,
            NVL(pension_payment,0) as pension_total,
            NVL(online_check_total_amt,0) AS online_check_total_amt,
            NVL(online_wire_total_amt,0) AS online_wire_total_amt,
            NVL(online_misc_total_amt,0) AS online_misc_total_amt,
            NVL(transfer_from_pdp_amt,0) + NVL(emp_transfer_from_pdp_amt,0) as transfer_from_pdp_total,
            
            NVL(refunds,0) *-1 as refunds,
            NVL(returns_total_amt,0) as manual_returns_total,
            NVL(eft_protest,0) as eft_returns_total,				
            NVL(bank_adjustment_amt,0) as bank_adjustment_total,
            
            NVL(aa_misc_loss_total_amt,0) AS aa_misc_loss_total_amt,
            NVL(aa_waiver_total_amt,0) as premium_waiver_total,
            NVL(aa_prorated_credit_total_amt,0) AS aa_prorated_credit_total_amt,					
            NVL(aa_prorated_loss_total_amt,0) AS aa_prorated_loss_total_amt,				
            NVL(aa_retro_credit_total_amt,0) AS aa_retro_credit_total_amt,				
            NVL(aa_retro_debit_total_amt,0) AS aa_retro_debit_total_amt,
            
            NVL(CLAIMS_TOTAL_AMT,0) * -1 as claims_total,
            NVL(UNCLAIMED_TOTAL_AMT,0) * -1 as  unclaimed_norefunds_total,
            NVL(UNCLAIMED_REFUND_AMT,0) * -1 as unclaimed_refunds,				
            NVL(MEMBERSHIP_ANDRUS_FUNDS_AMT,0) *  - 1 as  membership_paid_total,				
            NVL(EMP_MEMBERSHIP_PAID_AMT,0) *  - 1 as emp_membership_total,
            NVL(TRANSFER_TO_PDP_AMT,0) *  - 1 as transfer_to_pdp_total,
            
            NVL(PRE_RETRO_PAID_PREMIUM_PRIOR,0) - (NVL(PRE_RETRO_PAID_PREM_PRIOR_OT,0) + NVL(PRE_RETRO_PAID_PREMIUM_CURRENT,0) )as ar_prior_to_retro_date,				
            NVL(households_waiting_recalc_amt,0) AS households_waiting_recalc_amt,				
            (NVL(BTRAN_NO_MTRAN_TOTAL_AMT,0) + NVL(BTRAN_NO_MTRAN_EMPDIST_AMT,0)) * - 1 as On_Billing_Trans_Only, ---scr 36426 June 2012 release: corrected the calculation syntax				
            NVL(mtran_no_btran_amt,0) as on_monetary_trans_only_total,				
            TO_NUMBER(0) as Overstated_employer_total,								
            NVL(overstated_reduced_emp_credit,0)*-1 as overstated_reduced_Naf_total ,				
            NVL(protested_emp_acct_adj_amt,0)*-1 as protested_emp_credit_total,				
            NVL(excess_prorated_credit,0)*-1 as EXCESS_PRORATED_CREDIT_total ,				
            NVL(date_differ_prior_amt,0) as added_fromPriormonth_total,				
            CURRENT_TIMESTAMP AS RUN_DATE,
            :gv_ReportStartDate AS START_DATE
            --gv_ReportStopDate AS END_DATE
        FROM 
            IDENTIFIER(:V_RIA_daily_recon)
        WHERE
                REPORT_DATE = :gv_ReportStartDate
    );

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_pv_ReportResult)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP4'';
V_STEP_NAME :=  ''CALL BDR_BI.SP_ISB_SF_LOG_INSERT_COMPLETE(:gv_Log_id)'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CALL BDR_BI.SP_ISB_SF_LOG_INSERT_COMPLETE(:gv_Log_id);

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0 ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



let res_set RESULTSET;
let select_statement1 := ''SELECT * FROM pv_ReportResult'';
res_set := (EXECUTE IMMEDIATE :select_statement1);
RETURN TABLE(res_set);

EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);

gv_error_code := SQLERRM;
CALL BDR_BI.SP_ISB_SF_LOG_INSERT_ERROR(:gv_Log_id, :gv_error_code);

RAISE;

END;

';