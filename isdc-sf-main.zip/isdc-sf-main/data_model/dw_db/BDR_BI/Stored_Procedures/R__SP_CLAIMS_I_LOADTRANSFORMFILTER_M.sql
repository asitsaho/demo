USE SCHEMA BDR_BI; CREATE OR REPLACE PROCEDURE "SP_CLAIMS_I_LOADTRANSFORMFILTER_M"("DB_NAME" VARCHAR(16777216), "APPLICATION" VARCHAR(16777216), "WORKFLOW_NAME" VARCHAR(16777216), "OBJECT_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '

-- Original workflow: wkf_Claims_Fact_IXL_TargetLoad4_M
-- Original mapping: m_Claims_I_CLMPLNBENRLP_M
-- Original folder: Claims
-- Original filename: wkf_Claims_Fact_IXL_TargetLoad4_M.XML

DECLARE


V_ROWS_INSERTED  INTEGER;
V_ROWS_UPDATED INTEGER;
V_ROWS_DELETED INTEGER;
V_LAST_QUERY_ID VARCHAR;

V_WH VARCHAR;
V_BATCH_ID INTEGER;


V_BATCH_OBJECT_START_TIME        VARCHAR;
V_STEP_START_TIME    VARCHAR;
V_STEP_NAME VARCHAR;
V_STEP_SEQ INTEGER DEFAULT 0;
V_ETL_LST_BTCH_ID INTEGER;

lv_data_date   TIMESTAMP_NTZ := NULL;


BEGIN

EXECUTE IMMEDIATE ''USE DATABASE ''||:DB_NAME; 

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_BATCH_OBJECT_START_TIME := (SELECT CURRENT_TIMESTAMP());



LET res1 RESULTSET := 
(

SELECT 

WH ,
BATCH_ID
  
FROM UTIL.ETL_BATCH_OBJECT_CONTROL
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
FETCH FIRST 1 ROW ONLY

)
;


LET C1 CURSOR FOR res1;
open C1;
FETCH C1 into  V_WH,V_BATCH_ID ;
close C1;


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:V_WH;
USE SCHEMA BDR_DM;		--OAS ADD


INSERT INTO UTIL.ETL_BATCH_OBJECT_INCR_VALU (APPLICATION, WORKFLOW_NAME, OBJECT_NAME, INCR_COLUMN, INCR_COLUMN_VALUE )
SELECT * FROM (select :APPLICATION AS APPLICATION, :WORKFLOW_NAME AS WORKFLOW_NAME, :OBJECT_NAME AS OBJECT_NAME, ''ETL_LST_BTCH_ID'' AS INCR_COLUMN, -1 AS INCR_COLUMN_VALUE) A
WHERE NOT EXISTS (SELECT 1 FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU B WHERE B.APPLICATION = A.APPLICATION AND B.WORKFLOW_NAME = A.WORKFLOW_NAME AND B.OBJECT_NAME = A.OBJECT_NAME AND B.INCR_COLUMN = A.INCR_COLUMN)
;

V_ETL_LST_BTCH_ID :=(SELECT INCR_COLUMN_VALUE FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID'');
--COMMENTED BY OAS--
/*
CREATE OR REPLACE PROCEDURE BI.sp_clm_I_LoadTransformFilter_M
(
   iv_Dummy                IN NUMBER,
   P_ToContinueStatus      OUT VARCHAR2,
   P_ErrorYNFlg            OUT VARCHAR2,
   P_ErrorStr              OUT VARCHAR2
)
AUTHID CURRENT_USER AS
 ---------------------------------------------------------------------------
  --Purpose         : Used to populate the BI.DateTransformationFilters table each month
  --Application Ref : Program Global Dashboard
  --Called From     :
  --Author          : By CTS    Inital Date : 8/10/2017
  --Change History
  ---------------------------------------------------------------------------
  --    Date             Who Changed        What Changed
  -- 
  ---------------------------------------------------------------------------
  -- Begin Standard Declarations
  -- Begin Local Variables	

    lv_data_date   DATE := NULL;
    V_BTCH_ID NUMBER(10);
    V_PROC_NAME VARCHAR(50);
    V_ROWS_AFFTD NUMBER(20):=0;
BEGIN

SELECT MAX(BATCH_ID) INTO V_BTCH_ID FROM ETL.ETL_BATCH_LOG WHERE APPLICATION=''CDC'' AND BATCH_STATUS=''COMPLETE'';

V_PROC_NAME:=''SP_CLM_I_LOADTRANSFORMFILTER_M'';

INSERT INTO ETL.ETL_DETAIL_LOAD_INFO 
(APPLICATION , ETL_BATCH_ID, ETL_PROC_NAME , ACTION , STEP_INFO , ROWS_AFFECTED ,ETL_DATETIME)
VALUES(''MONTHLY_CLAIMS'',V_BTCH_ID,V_PROC_NAME,''START'',''PROCEDURE STARTS'',V_ROWS_AFFTD,SYSTIMESTAMP);*/
--COMMENTED BY OAS--
    /* IF
        lv_data_date IS NULL
    THEN
        lv_data_date := add_months(
            SYSDATE,
        -1);
    END IF; */		--OAS DELETE
	
	lv_data_date := (SELECT IFF(:lv_data_date IS NULL, ADD_MONTHS(CURRENT_TIMESTAMP, -1), NULL));
	
V_STEP_NAME    := ''INSERT - DATETRANSFORMATIONFILTERS'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

    INSERT INTO BDR_BI.datetransformationfilters (
        inputmonthid,
        reporttype,
        cypremiumduestartmonthid,
        cypremiumdueendmonthid,
        pypremiumduestartmonthid,
        pypremiumdueendmonthid,
        py2premiumduestartmonthid,
        py2premiumdueendmonthid,
        py3premiumduestartmonthid,
        py3premiumdueendmonthid,
        cyclaimpaidstartmonthid,
        cyclaimpaidendmonthid,
        pyclaimpaidstartmonthid,
        pyclaimpaidendmonthid,
        py2claimpaidstartmonthid,
        py2claimpaidendmonthid,
        py3claimpaidstartmonthid,
        py3claimpaidendmonthid,
        cyclaimincstartmonthid,
        cyclaimincendmonthid,
        pyclaimincstartmonthid,
        pyclaimincendmonthid,
        py2claimincstartmonthid,
        py2claimincendmonthid,
        py3claimincstartmonthid,
        py3claimincendmonthid,
        inputmonthstartdate,
        inputmonthstartdateid,
        inputmonthenddateid,
        cyactivitymonthid,
        pyactivitymonthid,
        py2activitymonthid,
        py3activitymonthid,
        dataavailableflg,
        etlrundate,
        cyactivitymonthstartid,
        cyactivitymonthendid,
        pyactivitymonthstartid,
        pyactivitymonthendid,
        py2activitymonthstartid,
        py2activitymonthendid,
        py3activitymonthstartid,
        py3activitymonthendid
    ) WITH dt AS (
        SELECT
            :lv_data_date datadate
        FROM
            dual
    ),dt1 AS (
        SELECT
            TO_CHAR(datadate,''YYYYMM'') inputmonth,
            trunc(datadate,''YEAR'') firstmonth,
            DATEADD(''DD'', -1, add_months(trunc(datadate,''YEAR''),12)) lastmonth,
            add_months(datadate,-12) previous1year,
            trunc(add_months(datadate,-12),''YEAR'') previous1year_firstmonth,
            DATEADD(''DD'', -1, trunc(datadate,''YEAR'')) previous1year_lastmonth,
            add_months(datadate,-24) previous2year,
            trunc(add_months(datadate,-24),''YEAR'') previous2year_firstmonth,
            DATEADD(''DD'', -1, add_months(trunc(datadate,''YEAR''),-12)) previous2year_lastmonth,
            add_months(datadate,-36) previous3year,
            trunc(add_months(datadate,-36),''YEAR'') previous3year_firstmonth,
            DATEADD(''DD'', -1, add_months(trunc(datadate,''YEAR''),-24)) previous3year_lastmonth,
            add_months(datadate,-48) previous4year,
            trunc(add_months(datadate,-48),''YEAR'') previous4year_firstmonth,
            DATEADD(''DD'', -1, add_months(trunc(datadate,''YEAR''),-36)) previous4year_lastmonth
        FROM
            dt
    ) SELECT
        inputmonth ytinputmonthid,
        ''YTD'' ytreporttype,
        TO_CHAR(firstmonth,''YYYYMM'') ytcypremiumduestartmonthid,
        inputmonth ytcypremiumdueendmonthid,
        TO_CHAR(previous1year_firstmonth,''YYYYMM'') ytpypremiumduestartmonthid,
        TO_CHAR(previous1year,''YYYYMM'') ytpypremiumdueendmonthid,
        TO_CHAR(previous2year_firstmonth,''YYYYMM'') ytpy2premiumduestartmonthid,
        TO_CHAR(previous2year,''YYYYMM'') ytpy2premiumdueendmonthid,
        TO_CHAR(previous3year_firstmonth,''YYYYMM'') ytpy3premiumduestartmonthid,
        TO_CHAR(previous3year,''YYYYMM'') ytpy3premiumdueendmonthid,
        TO_CHAR(firstmonth,''YYYYMM'') ytcyclaimpaidstartmonthid,
        inputmonth ytcyclaimpaidendmonthid,
        TO_CHAR(previous1year_firstmonth,''YYYYMM'') ytpyclaimpaidstartmonthid,
        TO_CHAR(previous1year,''YYYYMM'') ytpyclaimpaidendmonthid,
        TO_CHAR(previous2year_firstmonth,''YYYYMM'') ytpy2claimpaidstartmonthid,
        TO_CHAR(previous2year,''YYYYMM'') ytpy2claimpaidendmonthid,
        TO_CHAR(previous3year_firstmonth,''YYYYMM'') ytpy3claimpaidstartmonthid,
        TO_CHAR(previous3year,''YYYYMM'') ytpy3claimpaidendmonthid,
        TO_CHAR(firstmonth,''YYYYMM'') ytcyclaimincstartmonthid,
        inputmonth ytcyclaimincendmonthid,
        TO_CHAR(previous1year_firstmonth,''YYYYMM'') ytpyclaimincstartmonthid,
        TO_CHAR(previous1year,''YYYYMM'') ytpyclaimincendmonthid,
        TO_CHAR(previous2year_firstmonth,''YYYYMM'') ytpy2claimincstartmonthid,
        TO_CHAR(previous2year,''YYYYMM'') ytpy2claimincendmonthid,
        TO_CHAR(previous3year_firstmonth,''YYYYMM'') ytpy3claimincstartmonthid,
        TO_CHAR(previous3year,''YYYYMM'') ytpy3claimincendmonthid,
        trunc(datadate,''MONTH'') ytinputmonthstartdate,
        TO_CHAR(trunc(datadate,''MONTH''),''YYYYMMDD'') ytinputmonthstartdateid,
        TO_CHAR(last_day(datadate),''YYYYMMDD'') ytinputmonthenddateid,
        inputmonth ytcyactivitymonthid,
        TO_CHAR(previous1year,''YYYYMM'') ytpyactivitymonthid,
        TO_CHAR(previous2year,''YYYYMM'') ytpyactivitymonthid,
        TO_CHAR(previous3year,''YYYYMM'') ytpyactivitymonthid,
        ''Y'' ytdataavailableflg,
        --systimestamp ytetlrundate,		--OAS DELETE
		CURRENT_TIMESTAMP ytetlrundate,		--OAS ADD
        TO_CHAR(firstmonth,''YYYYMM'') ytcyactivitymonthstartid,
        inputmonth ytcyactivitymonthendid,
        TO_CHAR(previous1year_firstmonth,''YYYYMM'') ytpyactivitymonthstartid,
        inputmonth ytpyactivitymonthendid,
        TO_CHAR(previous2year_firstmonth,''YYYYMM'') ytpy2activitymonthstartid,
        inputmonth ytpy2activitymonthendid,
        TO_CHAR(previous3year_firstmonth,''YYYYMM'') ytpy3activitymonthstartid,
        inputmonth ytpy3activitymonthendid
    FROM
        dt1,
        dt
    UNION
    SELECT
        inputmonth clinputmonthid,
        ''CLY'' ytreporttype,
        TO_CHAR(previous1year_firstmonth,''YYYYMM'') clcypremiumduestartmonthid,
        TO_CHAR(previous1year_lastmonth,''YYYYMM'') clcypremiumdueendmonthid,
        TO_CHAR(previous2year_firstmonth,''YYYYMM'') clpypremiumduestartmonthid,
        TO_CHAR(previous2year_lastmonth,''YYYYMM'') clpypremiumdueendmonthid,
        TO_CHAR(previous3year_firstmonth,''YYYYMM'') clpy2premiumduestartmonthid,
        TO_CHAR(previous3year_lastmonth,''YYYYMM'') clpy2premiumdueendmonthid,
        TO_CHAR(previous4year_firstmonth,''YYYYMM'') clpy3premiumduestartmonthid,
        TO_CHAR(previous4year_lastmonth,''YYYYMM'') clpy3premiumdueendmonthid,
        TO_CHAR(previous1year_firstmonth,''YYYYMM'') clcyclaimpaidstartmonthid,
        TO_CHAR(previous1year_lastmonth,''YYYYMM'') clcyclaimpaidendmonthid,
        TO_CHAR(previous2year_firstmonth,''YYYYMM'') clpyclaimpaidstartmonthid,
        TO_CHAR(previous2year_lastmonth,''YYYYMM'') clpyclaimpaidendmonthid,
        TO_CHAR(previous3year_firstmonth,''YYYYMM'') clpy2claimpaidstartmonthid,
        TO_CHAR(previous3year_lastmonth,''YYYYMM'') clpy2claimpaidendmonthid,
        TO_CHAR(previous4year_firstmonth,''YYYYMM'') clpy3claimpaidstartmonthid,
        TO_CHAR(previous4year_lastmonth,''YYYYMM'') clpy3claimpaidendmonthid,
        TO_CHAR(previous1year_firstmonth,''YYYYMM'') clcyclaimincstartmonthid,
        TO_CHAR(previous1year_lastmonth,''YYYYMM'') clcyclaimincendmonthid,
        TO_CHAR(previous2year_firstmonth,''YYYYMM'') clpyclaimincstartmonthid,
        TO_CHAR(previous2year_lastmonth,''YYYYMM'') clpyclaimincendmonthid,
        TO_CHAR(previous3year_firstmonth,''YYYYMM'') clpy2claimincstartmonthid,
        TO_CHAR(previous3year_lastmonth,''YYYYMM'') clpy2claimincendmonthid,
        TO_CHAR(previous4year_firstmonth,''YYYYMM'') clpy3claimincstartmonthid,
        TO_CHAR(previous4year_lastmonth,''YYYYMM'') clpy3claimincendmonthid,
        trunc(datadate,''MONTH'') clinputmonthstartdate,
        TO_CHAR(trunc(datadate,''MONTH''),''YYYYMMDD'') clinputmonthstartdateid,
        TO_CHAR(last_day(datadate),''YYYYMMDD'') clinputmonthenddateid,
        inputmonth clcyactivitymonthid,
        TO_CHAR(previous1year,''YYYYMM'') clpyactivitymonthid,
        TO_CHAR(previous2year,''YYYYMM'') clpy2activitymonthid,
        TO_CHAR(previous3year,''YYYYMM'') clpy3activitymonthid,
        ''Y'' cldataavailableflg,
        --systimestamp cletlrundate,		--OAS DELETE
		CURRENT_TIMESTAMP cletlrundate,		--OAS ADD
        TO_CHAR(previous1year_firstmonth,''YYYYMM'') ytcyactivitymonthstartid,
        inputmonth ytcyactivitymonthendid,
        TO_CHAR(previous2year_firstmonth,''YYYYMM'') ytpyactivitymonthstartid,
        inputmonth ytpyactivitymonthendid,
        TO_CHAR(previous3year_firstmonth,''YYYYMM'') ytpy2activitymonthstartid,
        inputmonth ytpy2activitymonthendid,
        TO_CHAR(previous4year_firstmonth,''YYYYMM'') ytpy3activitymonthstartid,
        inputmonth ytpy3activitymonthendid
    FROM
        dt1,
        dt;
	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

 --COMMENTED BY OAS--
/*V_ROWS_AFFTD:=SQL%ROWCOUNT;
        
        INSERT INTO ETL.ETL_DETAIL_LOAD_INFO 
(APPLICATION , ETL_BATCH_ID, ETL_PROC_NAME , ACTION , STEP_INFO , ROWS_AFFECTED ,ETL_DATETIME)
VALUES(''MONTHLY_CLAIMS'',V_BTCH_ID,V_PROC_NAME,''INSERT'',''datetransformationfilters'',V_ROWS_AFFTD,SYSTIMESTAMP);

    INSERT INTO ETL.ETL_DETAIL_LOAD_INFO 
(APPLICATION , ETL_BATCH_ID, ETL_PROC_NAME , ACTION , STEP_INFO , ROWS_AFFECTED ,ETL_DATETIME)
VALUES(''MONTHLY_CLAIMS'',V_BTCH_ID,V_PROC_NAME,''END'',''PROCEDURE ENDS'',V_ROWS_AFFTD,SYSTIMESTAMP);

COMMIT;
  P_ToContinueStatus := ''Y'';
  P_ErrorYNFlg       := ''N'';
  P_ErrorStr         := '''';
  
  
EXCEPTION
WHEN OTHERS THEN
  P_ErrorStr         := ''ERROR: '' || SQLCODE || ''-'' || SQLERRM || ''-'' || DBMS_UTILITY.FORMAT_ERROR_STACK ();
  P_ToContinueStatus := ''N'';
  P_ErrorYNFlg       := ''Y'';
  ROLLBACK;
  
END;
/*/
--COMMENTED BY OAS--


CALL UTIL.SP_ETL_CHECK_CONSTRAINTS(:DB_NAME , :APPLICATION , :WORKFLOW_NAME , :OBJECT_NAME , :V_BATCH_ID );		---------OAS ADD


UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''COMPLETE'', ERROR_MSG = null, BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
;
UPDATE  UTIL.ETL_BATCH_OBJECT_INCR_VALU SET INCR_COLUMN_VALUE = :V_BATCH_ID, LST_MOD_DT = CURRENT_TIMESTAMP() 
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID''
;

EXCEPTION

WHEN OTHER THEN

UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''ERROR'', ERROR_MSG = :SQLERRM,  BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
;

INSERT INTO  UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ERROR_MSG, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''ERROR'', :V_STEP_NAME, :V_STEP_SEQ, :SQLERRM, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() )
;



RAISE;

END;

';