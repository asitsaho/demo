CREATE OR REPLACE PROCEDURE BDR_BI.SP_ISB_SF_BIL14A_MNT_STMT_OF_ACCT_P2("PV_REPORTSTARTDATE" DATE, "PV_REPORTSTOPDATE" DATE, "DB_NAME" VARCHAR(16777216) DEFAULT '', "TGT_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "TGT2_SC" VARCHAR(16777216) DEFAULT '', "SRC_SC" VARCHAR(16777216) DEFAULT 'SRC_COMPAS', "SRC2_SC" VARCHAR(16777216) DEFAULT 'BDR_MSOA', "UTIL_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "PIPELINE_ID" VARCHAR(16777216) DEFAULT '', "PIPELINE_NAME" VARCHAR(16777216) DEFAULT 'SP_ISB_SF_BIL14A_MNT_STMT_OF_ACCT_P2')
RETURNS TABLE ()
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

        gv_ReportStartDate                DATE := DATE(pv_ReportStartDate);
        gv_ReportStopDate                DATE := DATE(pv_ReportStopDate);
        gv_Log_id                          NUMBER;
        gv_error_code                     VARCHAR(200);      



V_START_TIME TIMESTAMP;

V_STEP VARCHAR;
V_LAST_QUERY_ID    VARCHAR;
V_ROWS_LOADED   VARCHAR;
V_PROCESS_NAME   VARCHAR DEFAULT ''SP_ISB_SF_BIL14A_MNT_STMT_OF_ACCT_P2'';
V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''SP_ISB_SF_BIL14A_MNT_STMT_OF_ACCT_P2'';
V_STEP_NAME        VARCHAR;
V_ROWS_PARSED      INTEGER;
V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := COALESCE(:UTIL_SC, ''BDR_BI'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';
BEGIN
----PV_REPORTRESULT
----PV_REPORTRESULT
LET V_PV_REPORTRESULT VARCHAR :=  :TGT_SC || ''.PV_REPORTRESULT'';

----COMPAS_MO.RIA_MONTHLY_STMT_OF_ACCOUNT
----COMPAS_MO.RIA_MONTHLY_STMT_OF_ACCOUNT
LET V_RIA_MONTHLY_STMT_OF_ACCOUNT VARCHAR :=  :SRC2_SC || ''.RIA_MONTHLY_STMT_OF_ACCOUNT'';

----A
----A
LET V_A VARCHAR :=  :SRC_SC || ''.A'';




--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP1'';
V_STEP_NAME :=  ''call BDR_BI.FN_ISB_SF_GET_LOG_ID()'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

call BDR_BI.FN_ISB_SF_GET_LOG_ID()
    into :gv_Log_id;

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0 ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP2'';
V_STEP_NAME :=  ''CALL BDR_BI.SP_ISB_SF_INSERT_JOB_LOG()'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CALL BDR_BI.SP_ISB_SF_INSERT_JOB_LOG(:gv_Log_id,''BI.PKG_ISB_BILL_REPORTS.SP_ISB_MTHLY_STMT_OF_ACCTS_PART2'',''BIL0014A_ISB_Mthly_Stmt_Of_Accts'');

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0 ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP3'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE  IDENTIFIER(:V_PV_REPORTRESULT) AS  
    
     select
	           --plan category all
	
	           NVL(full_data.onemonth_prior_household,0) AS onemonth_prior_household,
	           NVL(full_data.onemonth_cur_household,0) AS onemonth_cur_household,
	           NVL(full_data.one_net_changehhlds,0) AS one_net_changehhlds,
	
	           NVL(full_data.onemonth_prior_amount,0) AS onemonth_prior_amount,
	           NVL(full_data.onemonth_cur_amount,0) AS onemonth_cur_amount,
	           NVL(full_data.one_net_changeamt,0) AS one_net_changeamt,
	
	           NVL(full_data.twomonth_prior_household,0) AS twomonth_prior_household,
	           NVL(full_data.twomonth_cur_household,0) AS twomonth_cur_household,
	           NVL(full_data.two_net_changehhlds,0) AS two_net_changehhlds,
	
	           NVL(full_data.twomonth_prior_amount,0) AS twomonth_prior_amount,
	           NVL(full_data.twomonth_cur_amount,0) AS twomonth_cur_amount,
	           NVL(full_data.two_net_changeamt,0) AS two_net_changeamt,
	
	           NVL(full_data.threemonth_prior_household,0) AS threemonth_prior_household,
	           NVL(full_data.threemonth_cur_household,0) AS threemonth_cur_household,
	           NVL(full_data.three_net_changehhlds,0) AS three_net_changehhlds,
	
	           NVL(full_data.threemonth_prior_amount,0) AS threemonth_prior_amount,
	           NVL(full_data.threemonth_cur_amount,0) AS threemonth_cur_amount,
	           NVL(full_data.three_net_changeamt,0) AS three_net_changeamt,
	
	           NVL(full_data.fourmonth_prior_household,0) AS fourmonth_prior_household,
	           NVL(full_data.fourmonth_cur_household,0) AS fourmonth_cur_household,
	           NVL(full_data.four_net_changehhlds,0) AS four_net_changehhlds,
	
	           NVL(full_data.fourmonth_prior_amount,0) AS fourmonth_prior_amount,
	           NVL(full_data.fourmonth_cur_amount,0) AS fourmonth_cur_amount,
	           NVL(full_data.four_net_changeamt,0) AS four_net_changeamt,
	
	           NVL(full_data.fivemonth_prior_household,0) AS fivemonth_prior_household,
	           NVL(full_data.fivemonth_cur_household,0) AS fivemonth_cur_household,
	           NVL(full_data.five_net_changehhlds,0) AS five_net_changehhlds,
	
	           NVL(full_data.fivemonth_prior_amount,0) AS fivemonth_prior_amount,
	           NVL(full_data.fivemonth_cur_amount,0) AS fivemonth_cur_amount,
	           NVL(full_data.five_net_changeamt,0) AS five_net_changeamt,
	
	           NVL(full_data.sixmonth_prior_household,0) AS sixmonth_prior_household,
	           NVL(full_data.sixmonth_cur_household,0) AS sixmonth_cur_household,
	           NVL(full_data.six_net_changehhlds,0) AS six_net_changehhlds,
	
	           NVL(full_data.sixmonth_prior_amount,0) AS sixmonth_prior_amount,
	           NVL(full_data.sixmonth_cur_amount,0) AS sixmonth_cur_amount,
	           NVL(full_data.six_net_changeamt,0) AS six_net_changeamt,
	
	           ---total  plan category all
	           NVL(full_data.onemonth_prior_household,0)+NVL(full_data.twomonth_prior_household,0)+NVL(full_data.threemonth_prior_household,0)+NVL(full_data.fourmonth_prior_household,0)
	             +NVL(full_data.fivemonth_prior_household,0)+NVL(full_data.sixmonth_prior_household,0) as total_last_report_vol,
	
	           NVL(full_data.onemonth_prior_amount,0)+NVL(full_data.twomonth_prior_amount,0)+NVL(full_data.threemonth_prior_amount,0)+NVL(full_data.fourmonth_prior_amount,0)
	             +NVL(full_data.fivemonth_prior_amount,0)+NVL(full_data.sixmonth_prior_amount,0) as total_last_report_dollars,
	
	           NVL(full_data.onemonth_cur_household,0)+NVL(full_data.twomonth_cur_household,0)+NVL(full_data.threemonth_cur_household,0)+NVL(full_data.fourmonth_cur_household,0)
	             +NVL(full_data.fivemonth_cur_household,0)+NVL(full_data.sixmonth_cur_household,0) as tota_cur_report_vol,
	
	           NVL(full_data.onemonth_cur_amount,0)+NVL(full_data.twomonth_cur_amount,0)+NVL(full_data.threemonth_cur_amount,0)+NVL(full_data.fourmonth_cur_amount,0)
	             +NVL(full_data.fivemonth_cur_amount,0)+NVL(full_data.sixmonth_cur_amount,0) as total_cur_report_dollars,
	
	           NVL(full_data.one_net_changehhlds,0)+NVL(full_data.two_net_changehhlds,0)+NVL(full_data.three_net_changehhlds,0)+
	           NVL(full_data.four_net_changehhlds,0)+NVL(full_data.five_net_changehhlds,0)+NVL(full_data.six_net_changehhlds,0) as total_netchnage_vol,
	
	           NVL(full_data.one_net_changeamt,0)+NVL(full_data.two_net_changeamt,0)+NVL(full_data.three_net_changeamt,0)+
	           NVL(full_data.four_net_changeamt,0)+NVL(full_data.five_net_changeamt,0)+NVL(full_data.six_net_changeamt,0) as total_netchnage_amt,
	
	           --plan categoty PHIP
	
	           NVL(full_data.ppoone_prior_household,0) AS ppoone_prior_household,
	           NVL(full_data.ppoone_cur_household,0) AS ppoone_cur_household,
               (NVL(full_data.ppoone_cur_household,0) - NVL(full_data.ppoone_prior_household,0)) AS ppoone_net_changehhlds,
	
	           NVL(full_data.ppoone_prior_amount,0) AS ppoone_prior_amount,
	           NVL(full_data.ppoone_cur_amount,0) AS ppoone_cur_amount,
              (NVL(full_data.ppoone_cur_amount,0) - NVL(full_data.ppoone_prior_amount,0)) AS ppoone_net_changeamt,
	
	
	           NVL(full_data.ppotwo_prior_household,0) AS ppotwo_prior_household,
	           NVL(full_data.ppotwo_cur_household,0) AS ppotwo_cur_household,
               (NVL(full_data.ppotwo_cur_household,0)  -  NVL(full_data.ppotwo_prior_household,0)) AS ppotwo_net_changehhlds,
	
	           NVL(full_data.ppotwo_prior_amount,0) AS ppotwo_prior_amount,
	           NVL(full_data.ppotwo_cur_amount,0) AS ppotwo_cur_amount,
               (NVL(full_data.ppotwo_cur_amount,0) - NVL(full_data.ppotwo_prior_amount,0)) AS ppotwo_net_changeamt,
	
	           NVL(full_data.ppothree_prior_household,0) AS ppothree_prior_household,
	           NVL(full_data.ppothree_cur_household,0) AS ppothree_cur_household,
               (NVL(full_data.ppothree_cur_household,0) - NVL(full_data.ppothree_prior_household,0)) AS ppothree_net_changehhlds,
	
	           NVL(full_data.ppothree_prior_amount,0) AS ppothree_prior_amount,
	           NVL(full_data.ppothree_cur_amount,0) AS ppothree_cur_amount,
               (NVL(full_data.ppothree_cur_amount,0) - NVL(full_data.ppothree_prior_amount,0)) AS ppothree_net_changeamt,
	
	           NVL(full_data.ppofour_prior_household,0) AS ppofour_prior_household,
	           NVL(full_data.ppofour_cur_household,0) AS ppofour_cur_household,
               (NVL(full_data.ppofour_cur_household,0) - NVL(full_data.ppofour_prior_household,0)) AS ppofour_net_changehhlds,
	
	           NVL(full_data.ppofour_prior_amount,0) AS ppofour_prior_amount,
	           NVL(full_data.ppofour_cur_amount,0) AS ppofour_cur_amount,
               (NVL(full_data.ppofour_cur_amount,0) - NVL(full_data.ppofour_prior_amount,0)) AS ppofour_net_changeamt,
	
	           NVL(full_data.ppofive_prior_household,0) AS ppofive_prior_household,
	           NVL(full_data.ppofive_cur_household,0) AS ppofive_cur_household,
               (NVL(full_data.ppofive_cur_household,0) - NVL(full_data.ppofive_prior_household,0)) AS ppofive_net_changehhlds,
	
	           NVL(full_data.ppofive_prior_amount,0) AS ppofive_prior_amount,
	           NVL(full_data.ppofive_cur_amount,0) AS ppofive_cur_amount,
               (NVL(full_data.ppofive_cur_amount,0) - NVL(full_data.ppofive_prior_amount,0))  AS ppofive_net_changeamt,
	
	           NVL(full_data.pposix_prior_household,0) AS pposix_prior_household,
	           NVL(full_data.pposix_cur_household,0) AS pposix_cur_household,
               (NVL(full_data.pposix_cur_household,0) - NVL(full_data.pposix_prior_household,0)) AS pposix_net_changehhlds,
	
	           NVL(full_data.pposix_prior_amount,0) AS pposix_prior_amount,
	           NVL(full_data.pposix_cur_amount,0) AS pposix_cur_amount,
               (NVL(full_data.pposix_cur_amount,0) - NVL(full_data.pposix_prior_amount,0)) AS pposix_net_changeamt,
	
	           -- Phip total
	           NVL(full_data.ppoone_prior_household,0)+NVL(full_data.ppotwo_prior_household,0)+NVL(full_data.ppothree_prior_household,0)
	             +NVL(full_data.ppofour_prior_household,0) +NVL(full_data.ppofive_prior_household,0) +NVL(full_data.pposix_prior_household,0)  as Phip_total_last_vol,
	
	           NVL(full_data.ppoone_prior_amount,0)+NVL(full_data.ppotwo_prior_amount,0) +NVL(full_data.ppothree_prior_amount,0)
	             +NVL(full_data.ppofour_prior_amount,0) + NVL(full_data.ppofive_prior_amount,0)+NVL(full_data.pposix_prior_amount,0)  as Phip_total_last_amount,
	
	           NVL(full_data.ppoone_cur_household,0)+NVL(full_data.ppotwo_cur_household,0)+NVL(full_data.ppothree_cur_household,0)+
	           NVL(full_data.ppofour_cur_household,0)+NVL(full_data.ppofive_cur_household,0)+NVL(full_data.pposix_cur_household,0) as phip_total_cur_vol,
	
	           NVL(full_data.ppoone_cur_amount,0)+NVL(full_data.ppotwo_cur_amount,0)+NVL(full_data.ppothree_cur_amount,0)+
	           NVL(full_data.ppofour_cur_amount,0)+NVL(full_data.ppofive_cur_amount,0)+NVL(full_data.pposix_cur_amount,0) as phip_total_cur_dollar,
	
	            (
                (NVL(full_data.ppoone_cur_household,0) - NVL(full_data.ppoone_prior_household,0)) +
                (NVL(full_data.ppotwo_cur_household,0)  -  NVL(full_data.ppotwo_prior_household,0)) +
                (NVL(full_data.ppothree_cur_household,0) - NVL(full_data.ppothree_prior_household,0)) +
                (NVL(full_data.ppofour_cur_household,0) - NVL(full_data.ppofour_prior_household,0)) +
                (NVL(full_data.ppofive_cur_household,0) - NVL(full_data.ppofive_prior_household,0)) +
                (NVL(full_data.pposix_cur_household,0) - NVL(full_data.pposix_prior_household,0))
                )AS phip_total_netchange_vol,
	
	           (
                (NVL(full_data.ppoone_cur_amount,0) - NVL(full_data.ppoone_prior_amount,0)) +
                (NVL(full_data.ppotwo_cur_amount,0) - NVL(full_data.ppotwo_prior_amount,0)) +
                (NVL(full_data.ppothree_cur_amount,0) - NVL(full_data.ppothree_prior_amount,0)) +
                (NVL(full_data.ppofour_cur_amount,0) - NVL(full_data.ppofour_prior_amount,0)) +
                (NVL(full_data.ppofive_cur_amount,0) - NVL(full_data.ppofive_prior_amount,0)) +
                (NVL(full_data.pposix_cur_amount,0) - NVL(full_data.pposix_prior_amount,0))
                )as PHIP_TOTAL_NETCHANGE_DOLLAR
              ,CURRENT_TIMESTAMP() as RUN_DATE
              ,:gv_ReportStartDate gv_ReportStartDate,
	           :gv_ReportStopDate gv_ReportStopDate
	      from
	
	        (select
	           --prior  plan category all
	           sum(CASE WHEN ar_date=prior_one  and REPORT_DATE=last_month
	             AND AR_TYPE=''PREMIUM''  then number_of_households end) as onemonth_prior_household,
	           sum(CASE WHEN ar_date=prior_one   and REPORT_DATE=last_month
	             AND AR_TYPE=''PREMIUM''  then ar_amount end) as onemonth_prior_amount,
	
	           sum(CASE WHEN ar_date=prior_two  and REPORT_DATE=last_month
	             AND AR_TYPE=''PREMIUM''  then number_of_households end) as twomonth_prior_household,
	           sum(CASE WHEN ar_date=prior_two   and REPORT_DATE=last_month
	             AND AR_TYPE=''PREMIUM''  then ar_amount end) as twomonth_prior_amount ,
	
	           sum(CASE WHEN ar_date=prior_three  and REPORT_DATE=last_month
	             AND AR_TYPE=''PREMIUM''  then number_of_households end) as threemonth_prior_household,
	           sum(CASE WHEN ar_date=prior_three   and REPORT_DATE=last_month
	             AND AR_TYPE=''PREMIUM''  then ar_amount end) as threemonth_prior_amount,
	
	           sum(CASE WHEN ar_date=prior_four  and REPORT_DATE=last_month
	             AND AR_TYPE=''PREMIUM''  then number_of_households end) as fourmonth_prior_household,
	           sum(CASE WHEN ar_date=prior_four   and REPORT_DATE=last_month
	             AND AR_TYPE=''PREMIUM''  then ar_amount end) as fourmonth_prior_amount,
	
	           sum(CASE WHEN ar_date=prior_five  and REPORT_DATE=last_month
	             AND AR_TYPE=''PREMIUM''  then number_of_households end) as fivemonth_prior_household,
	           sum(CASE WHEN ar_date=prior_five   and REPORT_DATE=last_month
	             AND AR_TYPE=''PREMIUM''  then ar_amount end) as fivemonth_prior_amount ,
	
	           sum(CASE WHEN ar_date<prior_five  and REPORT_DATE=last_month
	             AND AR_TYPE=''PREMIUM''  then number_of_households end) as sixmonth_prior_household,   --not tieing
	           sum(CASE WHEN ar_date<prior_five   and REPORT_DATE=last_month
	             AND AR_TYPE=''PREMIUM''  then ar_amount end) as sixmonth_prior_amount ,     --not tieing
	           --current
	           sum(CASE WHEN ar_date=prior_one  and REPORT_DATE=curr_month
	             AND AR_TYPE=''PREMIUM''  then number_of_households end) as onemonth_cur_household,
	           sum(CASE WHEN ar_date=prior_one   and REPORT_DATE=curr_month
	             AND AR_TYPE=''PREMIUM''  then ar_amount end) as onemonth_cur_amount,
	
	           sum(CASE WHEN ar_date=prior_two  and REPORT_DATE=curr_month
	             AND AR_TYPE=''PREMIUM''  then number_of_households end) as twomonth_cur_household,
	           sum(CASE WHEN ar_date=prior_two   and REPORT_DATE=curr_month
	             AND AR_TYPE=''PREMIUM''  then ar_amount end) as twomonth_cur_amount ,
	
	           sum(CASE WHEN ar_date=prior_three  and REPORT_DATE=curr_month
	             AND AR_TYPE=''PREMIUM''  then number_of_households end) as threemonth_cur_household,
	           sum(CASE WHEN ar_date=prior_three   and REPORT_DATE=curr_month
	             AND AR_TYPE=''PREMIUM''  then ar_amount end) as threemonth_cur_amount,
	
	           sum(CASE WHEN ar_date=prior_four  and REPORT_DATE=curr_month
	             AND AR_TYPE=''PREMIUM''  then number_of_households end) as fourmonth_cur_household,
	           sum(CASE WHEN ar_date=prior_four   and REPORT_DATE=curr_month
	             AND AR_TYPE=''PREMIUM''  then ar_amount end) as fourmonth_cur_amount,
	
	           sum(CASE WHEN ar_date=prior_five  and REPORT_DATE=curr_month
	             AND AR_TYPE=''PREMIUM''  then number_of_households end) as fivemonth_cur_household,
	           sum(CASE WHEN ar_date=prior_five   and REPORT_DATE=curr_month
	             AND AR_TYPE=''PREMIUM''  then ar_amount end) as fivemonth_cur_amount ,
	
	           sum(CASE WHEN ar_date<prior_five and REPORT_DATE=curr_month
	             AND AR_TYPE=''PREMIUM''  then number_of_households end) as sixmonth_cur_household,   -- not tieing
	           sum(CASE WHEN ar_date<prior_five  and REPORT_DATE=curr_month
	             AND AR_TYPE=''PREMIUM''  then ar_amount end) as sixmonth_cur_amount,        -- not tieing
	           -- all plan category net change
	           (NVL(sum(CASE WHEN ar_date=prior_one  and REPORT_DATE=curr_month
	             AND AR_TYPE=''PREMIUM''  then NVL(number_of_households,0) end),0)-
	
	            NVL(sum(CASE WHEN ar_date=prior_one  and REPORT_DATE=last_month
	              AND AR_TYPE=''PREMIUM''  then NVL(number_of_households,0) end),0)) as one_net_changehhlds,
	
	           (NVL(sum(CASE WHEN ar_date=prior_one  and REPORT_DATE=curr_month
	             AND AR_TYPE=''PREMIUM''  then ar_amount end),0)-
	
	            NVL(sum(CASE WHEN ar_date=prior_one  and REPORT_DATE=last_month
	              AND AR_TYPE=''PREMIUM''  then ar_amount end),0)) as one_net_changeamt ,
	
	
	           ( NVL(sum(CASE WHEN ar_date=prior_two  and REPORT_DATE=curr_month
	             AND AR_TYPE=''PREMIUM''  then NVL(number_of_households,0) end),0)-
	
	             NVL(sum(CASE WHEN ar_date=prior_two  and REPORT_DATE=last_month
	              AND AR_TYPE=''PREMIUM''  then NVL(number_of_households,0) end),0)) as two_net_changehhlds,
	
	           ( NVL(sum(CASE WHEN ar_date=prior_two  and REPORT_DATE=curr_month
	             AND AR_TYPE=''PREMIUM''  then ar_amount end),0)-
	
	             NVL(sum(CASE WHEN ar_date=prior_two  and REPORT_DATE=last_month
	              AND AR_TYPE=''PREMIUM''  then ar_amount end),0)) as two_net_changeamt ,
	
	           ( NVL(sum(CASE WHEN ar_date=prior_three  and REPORT_DATE=curr_month
	             AND AR_TYPE=''PREMIUM''  then NVL(number_of_households,0) end),0)-
	
	             NVL(sum(CASE WHEN ar_date=prior_three  and REPORT_DATE=last_month
	              AND AR_TYPE=''PREMIUM''  then NVL(number_of_households,0) end),0)) as three_net_changehhlds,
	
	           ( NVL(sum(CASE WHEN ar_date=prior_three  and REPORT_DATE=curr_month
	             AND AR_TYPE=''PREMIUM''  then ar_amount end),0)-
	
	             NVL(sum(CASE WHEN ar_date=prior_three  and REPORT_DATE=last_month
	              AND AR_TYPE=''PREMIUM''  then ar_amount end),0)) as three_net_changeamt,
	
	           ( NVL(sum(CASE WHEN ar_date=prior_four  and REPORT_DATE=curr_month
	             AND AR_TYPE=''PREMIUM''  then NVL(number_of_households,0) end),0)-
	
	             NVL(sum(CASE WHEN ar_date=prior_four  and REPORT_DATE=last_month
	              AND AR_TYPE=''PREMIUM''  then NVL(number_of_households,0) end),0)) as four_net_changehhlds,
	
	           ( NVL(sum(CASE WHEN ar_date=prior_four  and REPORT_DATE=curr_month
	             AND AR_TYPE=''PREMIUM''  then ar_amount end),0)-
	
	             NVL(sum(CASE WHEN ar_date=prior_four  and REPORT_DATE=last_month
	              AND AR_TYPE=''PREMIUM''  then ar_amount end),0)) as four_net_changeamt,
	
	           ( NVL(sum(CASE WHEN ar_date=prior_five  and REPORT_DATE=curr_month
	             AND AR_TYPE=''PREMIUM''  then NVL(number_of_households,0) end),0)-
	
	             NVL(sum(CASE WHEN ar_date=prior_five  and REPORT_DATE=last_month
	              AND AR_TYPE=''PREMIUM''  then NVL(number_of_households,0) end),0)) as five_net_changehhlds,
	
	           ( NVL(sum(CASE WHEN ar_date=prior_five  and REPORT_DATE=curr_month
	             AND AR_TYPE=''PREMIUM''  then ar_amount end),0)-
	
	             NVL(sum(CASE WHEN ar_date=prior_five  and REPORT_DATE=last_month
	              AND AR_TYPE=''PREMIUM''  then ar_amount end),0)) as five_net_changeamt,
	
	           ( NVL(sum(CASE WHEN ar_date<prior_five  and REPORT_DATE=curr_month
	             AND AR_TYPE=''PREMIUM''  then NVL(number_of_households,0) end),0)-
	             NVL(sum(CASE WHEN ar_date<prior_five  and REPORT_DATE=last_month
	              AND AR_TYPE=''PREMIUM''  then NVL(number_of_households,0) end),0)) as six_net_changehhlds,
	
	           ( NVL(sum(CASE WHEN ar_date<prior_five and REPORT_DATE=curr_month
	             AND AR_TYPE=''PREMIUM''  then ar_amount end),0)-
	
	             NVL(sum(CASE WHEN ar_date<prior_five and REPORT_DATE=last_month
	              AND AR_TYPE=''PREMIUM''  then ar_amount end),0)) as six_net_changeamt,
	
	           ---plan categoy Phip
	
	           --prior  plan category all
	            NVL(sum(CASE WHEN ar_date=prior_one  and REPORT_DATE=last_month
	             AND AR_TYPE=''PPO''  then number_of_households end),0) as ppoone_prior_household,
	            NVL(sum(CASE WHEN ar_date=prior_one   and REPORT_DATE=last_month
	             AND AR_TYPE=''PPO''  then ar_amount end),0) as ppoone_prior_amount,
	
	           NVL(sum(CASE WHEN ar_date=prior_two  and REPORT_DATE=last_month
	             AND AR_TYPE=''PPO''  then number_of_households end),0) as ppotwo_prior_household,
	            NVL(sum(CASE WHEN ar_date=prior_two   and REPORT_DATE=last_month
	             AND AR_TYPE=''PPO''  then ar_amount end),0) as ppotwo_prior_amount ,
	
	            NVL(sum(CASE WHEN ar_date=prior_three  and REPORT_DATE=last_month
	             AND AR_TYPE=''PPO''  then number_of_households end),0) as ppothree_prior_household,
	            NVL(sum(CASE WHEN ar_date=prior_three   and REPORT_DATE=last_month
	             AND AR_TYPE=''PPO''  then ar_amount end),0) as ppothree_prior_amount,
	
	            NVL(sum(CASE WHEN ar_date=prior_four  and REPORT_DATE=last_month
	             AND AR_TYPE=''PPO''  then number_of_households end),0) as ppofour_prior_household,
	            NVL(sum(CASE WHEN ar_date=prior_four   and REPORT_DATE=last_month
	             AND AR_TYPE=''PPO''  then ar_amount end),0) as ppofour_prior_amount,
	
	            NVL(sum(CASE WHEN ar_date=prior_five  and REPORT_DATE=last_month
	             AND AR_TYPE=''PPO''  then number_of_households end),0) as ppofive_prior_household,
	            NVL(sum(CASE WHEN ar_date=prior_five   and REPORT_DATE=last_month
	             AND AR_TYPE=''PPO''  then ar_amount end),0) as ppofive_prior_amount ,
	
	            NVL(sum(CASE WHEN ar_date<prior_five  and REPORT_DATE=last_month
	             AND AR_TYPE=''PPO''  then number_of_households end),0) as pposix_prior_household,   --not tieing
	            NVL(sum(CASE WHEN ar_date<prior_five  and REPORT_DATE=last_month
	             AND AR_TYPE=''PPO''  then ar_amount end),0) as pposix_prior_amount ,     --not tieing
	
	
	           --current
	            NVL(sum(CASE WHEN ar_date=prior_one  and REPORT_DATE=curr_month
	             AND AR_TYPE=''PPO''  then number_of_households end),0) as ppoone_cur_household,
	            NVL(sum(CASE WHEN ar_date=prior_one   and REPORT_DATE=curr_month
	             AND AR_TYPE=''PPO''  then ar_amount end),0) as ppoone_cur_amount,
	
	           NVL(sum(CASE WHEN ar_date=prior_two  and REPORT_DATE=curr_month
	             AND AR_TYPE=''PPO''  then number_of_households end),0) as ppotwo_cur_household,
	           NVL(sum(CASE WHEN ar_date=prior_two   and REPORT_DATE=curr_month
	             AND AR_TYPE=''PPO''  then ar_amount end),0) as ppotwo_cur_amount ,
	
	           NVL(sum(CASE WHEN ar_date=prior_three  and REPORT_DATE=curr_month
	             AND AR_TYPE=''PPO''  then number_of_households end),0) as ppothree_cur_household,
	          NVL( sum(CASE WHEN ar_date=prior_three   and REPORT_DATE=curr_month
	             AND AR_TYPE=''PPO''  then ar_amount end),0) as ppothree_cur_amount,
	
	          NVL(sum(CASE WHEN ar_date=prior_four  and REPORT_DATE=curr_month
	             AND AR_TYPE=''PPO''  then number_of_households end),0) as ppofour_cur_household,
	           NVL(sum(CASE WHEN ar_date=prior_four   and REPORT_DATE=curr_month
	             AND AR_TYPE=''PPO''  then ar_amount end),0) as ppofour_cur_amount,
	
	           NVL(sum(CASE WHEN ar_date=prior_five  and REPORT_DATE=curr_month
	             AND AR_TYPE=''PPO''  then number_of_households end),0) as ppofive_cur_household,
	           NVL(sum(CASE WHEN ar_date=prior_five   and REPORT_DATE=curr_month
	             AND AR_TYPE=''PPO''  then ar_amount end),0) as ppofive_cur_amount ,
	
	           NVL(sum(CASE WHEN ar_date<prior_five and REPORT_DATE=curr_month
	             AND AR_TYPE=''PPO''  then number_of_households end),0) as pposix_cur_household,   -- not tieing
	           NVL(sum(CASE WHEN ar_date<prior_five  and REPORT_DATE=curr_month
	             AND AR_TYPE=''PPO''  then ar_amount end),0) as pposix_cur_amount ,       -- not tieing
	           -----------
	           -- phip category net change
	           (NVL(sum(CASE WHEN ar_date=prior_one  and REPORT_DATE=curr_month
	             AND AR_TYPE=''PPO''  then NVL(number_of_households,0) end),0)-
	
	            NVL(sum(CASE WHEN ar_date=prior_one  and REPORT_DATE=last_month
	              AND AR_TYPE=''PPO''  then NVL(number_of_households,0) end),0)) as ppoone_net_changehhlds,
	
	           (NVL(sum(CASE WHEN ar_date=prior_one  and REPORT_DATE=curr_month
	             AND AR_TYPE=''PPO''  then ar_amount end),0)-
	
	            NVL(sum(CASE WHEN ar_date=prior_one  and REPORT_DATE=last_month
	              AND AR_TYPE=''PPO''  then ar_amount end),0)) as ppoone_net_changeamt ,
	
	
	           (NVL(sum(CASE WHEN ar_date=prior_two  and REPORT_DATE=curr_month
	             AND AR_TYPE=''PPO''  then NVL(number_of_households,0) end),0)-
	
	            NVL(sum(CASE WHEN ar_date=prior_two  and REPORT_DATE=last_month
	              AND AR_TYPE=''PPO''  then NVL(number_of_households,0) end),0)) as ppotwo_net_changehhlds,
	
	           (NVL(sum(CASE WHEN ar_date=prior_two  and REPORT_DATE=curr_month
	             AND AR_TYPE=''PPO''  then ar_amount end),0)-
	
	            NVL(sum(CASE WHEN ar_date=prior_two  and REPORT_DATE=last_month
	              AND AR_TYPE=''PPO''  then ar_amount end),0)) as ppotwo_net_changeamt ,
	
	           (NVL(sum(CASE WHEN ar_date=prior_three  and REPORT_DATE=curr_month
	             AND AR_TYPE=''PPO''  then NVL(number_of_households,0) end),0)-
	
	            NVL(sum(CASE WHEN ar_date=prior_three  and REPORT_DATE=last_month
	              AND AR_TYPE=''PPO''  then NVL(number_of_households,0) end),0)) as ppothree_net_changehhlds,
	
	           (NVL(sum(CASE WHEN ar_date=prior_three  and REPORT_DATE=curr_month
	             AND AR_TYPE=''PPO''  then ar_amount end),0)-
	
	            NVL(sum(CASE WHEN ar_date=prior_three  and REPORT_DATE=last_month
	              AND AR_TYPE=''PPO''  then ar_amount end),0)) as ppothree_net_changeamt,
	
	           (NVL(sum(CASE WHEN ar_date=prior_four  and REPORT_DATE=curr_month
	             AND AR_TYPE=''PPO''  then NVL(number_of_households,0) end),0)-
	
	            NVL(sum(CASE WHEN ar_date=prior_four  and REPORT_DATE=last_month
	              AND AR_TYPE=''PPO''  then NVL(number_of_households,0) end),0)) as ppofour_net_changehhlds,
	
	           (NVL(sum(CASE WHEN ar_date=prior_four  and REPORT_DATE=curr_month
	             AND AR_TYPE=''PPO''  then ar_amount end),0)-
	
	            NVL(sum(CASE WHEN ar_date=prior_four  and REPORT_DATE=last_month
	              AND AR_TYPE=''PPO''  then ar_amount end),0)) as ppofour_net_changeamt,
	
	           (NVL(sum(CASE WHEN ar_date=prior_five  and REPORT_DATE=curr_month
	             AND AR_TYPE=''PPO''  then NVL(number_of_households,0) end),0)-
	
	            NVL(sum(CASE WHEN ar_date=prior_five  and REPORT_DATE=last_month
	              AND AR_TYPE=''PPO''  then NVL(number_of_households,0) end),0)) as ppofive_net_changehhlds,
	
	           (NVL(sum(CASE WHEN ar_date=prior_five  and REPORT_DATE=curr_month
	             AND AR_TYPE=''PPO''  then ar_amount end),0)-
	
	            NVL(sum(CASE WHEN ar_date=prior_five  and REPORT_DATE=last_month
	              AND AR_TYPE=''PPO''  then ar_amount end),0)) as ppofive_net_changeamt,
	
	           (NVL(sum(CASE WHEN ar_date<prior_five and REPORT_DATE=curr_month
	             AND AR_TYPE=''PPO''  then NVL(number_of_households,0) end),0)-
	            NVL(sum(CASE WHEN ar_date<prior_five  and REPORT_DATE=last_month
	              AND AR_TYPE=''PPO''  then NVL(number_of_households,0) end),0)) as pposix_net_changehhlds,
	
	           (NVL(sum(CASE WHEN ar_date<prior_five and REPORT_DATE=curr_month
	             AND AR_TYPE=''PPO''  then ar_amount end),0)-
	
	            NVL(sum(CASE WHEN ar_date<prior_five and REPORT_DATE=last_month
	              AND AR_TYPE=''PPO''  then ar_amount end),0)) as pposix_net_changeamt
	         from
	           (select number_of_households,
	                   ar_amount,
	                   ar_date,
	                   report_date,ar_type,
	                   -- to get the prior months
	                   ''01-''||to_char(add_months(:gv_ReportStopDate,-1),''mon'')||''-''||to_char(add_months(:gv_ReportStopDate,-1),''yyyy'')prior_one,
	                   ''01-''||to_char(add_months(:gv_ReportStopDate,-2),''mon'')||''-''||to_char(add_months(:gv_ReportStopDate,-2),''yyyy'')prior_two,
	                   ''01-''||to_char(add_months(:gv_ReportStopDate,-3),''mon'')||''-''||to_char(add_months(:gv_ReportStopDate,-3),''yyyy'')prior_three,
	                   ''01-''||to_char(add_months(:gv_ReportStopDate,-4),''mon'')||''-''||to_char(add_months(:gv_ReportStopDate,-4),''yyyy'')prior_four,
	                   ''01-''||to_char(add_months(:gv_ReportStopDate,-5),''mon'')||''-''||to_char(add_months(:gv_ReportStopDate,-5),''yyyy'')prior_five,
	                   :gv_ReportStartDate as last_month,
	                   :gv_ReportStopDate as curr_month
	
	            FROM
	              IDENTIFIER(:V_RIA_monthly_stmt_of_account)
	            WHERE (REPORT_DATE=:gv_ReportStartDate --''30-apr-2011''
	              or REPORT_DATE=:gv_ReportStopDate)) )  full_data;

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_PV_REPORTRESULT)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP4'';
V_STEP_NAME :=  ''CALL BDR_BI.SP_ISB_SF_LOG_INSERT_COMPLETE()'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


	        
     CALL BDR_BI.SP_ISB_SF_LOG_INSERT_COMPLETE(:gv_Log_id);

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0 ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);





let res_set RESULTSET;
let select_statement1 := ''SELECT * FROM pv_ReportResult'';
res_set := (EXECUTE IMMEDIATE :select_statement1);
RETURN TABLE(res_set);

EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);

gv_error_code := SQLERRM;
CALL BDR_BI.SP_ISB_SF_LOG_INSERT_ERROR(:gv_Log_id, :gv_error_code);

RAISE;

END;

';