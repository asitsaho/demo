CREATE OR REPLACE PROCEDURE BDR_BI.SP_ISB_SF_BIL28A_AR_DELINQUENCY("PV_REPORTSTARTDATE" DATE, "DB_NAME" VARCHAR(16777216) DEFAULT '', "TGT_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "TGT2_SC" VARCHAR(16777216) DEFAULT '', "SRC_SC" VARCHAR(16777216) DEFAULT 'BDR_DM', "SRC2_SC" VARCHAR(16777216) DEFAULT '', "UTIL_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "PIPELINE_ID" VARCHAR(16777216) DEFAULT '', "PIPELINE_NAME" VARCHAR(16777216) DEFAULT 'SP_ISB_SF_BIL28A_AR_DELINQUENCY')
RETURNS TABLE ()
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

  gv_ReportStartDate                DATE := DATE(pv_ReportStartDate);
  gv_Log_id                         NUMBER;
  gv_error_code                     varchar(200);




V_START_TIME TIMESTAMP;

V_STEP VARCHAR;
V_LAST_QUERY_ID    VARCHAR;
V_ROWS_LOADED   VARCHAR;
V_PROCESS_NAME   VARCHAR DEFAULT ''SP_ISB_SF_BIL28A_AR_DELINQUENCY'';
V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''SP_ISB_SF_BIL28A_AR_DELINQUENCY'';
V_STEP_NAME        VARCHAR;
V_ROWS_PARSED      INTEGER;
V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := COALESCE(:UTIL_SC, ''BDR_BI'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';
BEGIN
----COMPAS_MO.AR_RIA_AGING_ADW_SUMMARY
----.
LET V_AR_RIA_AGING_ADW_SUMMARY VARCHAR :=  :SRC_SC || ''.AR_RIA_AGING_ADW_SUMMARY'';

----PV_REPORTRESULT
----PV_REPORTRESULT
LET V_PV_REPORTRESULT VARCHAR :=  :TGT_SC || ''.PV_REPORTRESULT'';




--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP1'';
V_STEP_NAME :=  ''call BDR_BI.FN_ISB_SF_GET_LOG_ID()'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

call BDR_BI.FN_ISB_SF_GET_LOG_ID()
    into :gv_Log_id;

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP2'';
V_STEP_NAME :=  ''CALL BDR_BI.SP_ISB_SF_INSERT_JOB_LOG()'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CALL BDR_BI.SP_ISB_SF_INSERT_JOB_LOG(:gv_Log_id,''BI.PKG_ISB_BILL_REPORTS.SP_AR_DELINQUENCY'',''BIL0028A_AR_DELINQUENCY'');

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



---EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP3'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE pv_ReportResult'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_pv_ReportResult) AS
	
       SELECT delinquent_date,
             NVL(premium_current_month,0)    AS allplans_current_month,
             NVL(premium_prior_one_month,0)  AS allplans_prior_one_month,
             NVL(premium_prior_two_month,0)  AS allplans_prior_two_month,
             NVL(premium_prior_three_month,0)AS allplans_prior_three_month,
             NVL(premium_prior_four_month,0) AS allplans_prior_four_month,
             NVL(premium_prior_five_month,0) AS allplans_prior_five_month,
             NVL(premium_prior_six_month,0)  AS all_premium_prior_six_month,
             -- phip
             NVL(ppo_current_month,0)    AS phip_current_month,
             NVL(ppo_prior_one_month,0)  AS phip_prior_one_month,
             NVL(ppo_prior_two_month,0)  AS phip_prior_two_month,
             NVL(ppo_prior_three_month,0)AS phip_prior_three_month,
             NVL(ppo_prior_four_month,0) AS phip_prior_four_month,
             NVL(ppo_prior_five_month,0) AS phip_prior_five_month,
             NVL(ppo_prior_six_month,0)  AS phip_prior_six_month,
             -- without phip
             (NVL(premium_current_month,0)- NVL(ppo_current_month,0))       AS withoutphip_current_month,
             (NVL(premium_prior_one_month,0)-NVL(ppo_prior_one_month,0))    AS withoutphip_prior_one_month,
             (NVL(premium_prior_two_month,0)-NVL(ppo_prior_two_month,0))    AS withoutphip_prior_two_month,
             (NVL(premium_prior_three_month,0)- NVL(ppo_prior_three_month,0))AS withoutphip_prior_three_month,
             (NVL(premium_prior_four_month,0)-NVL(ppo_prior_four_month,0))   AS withoutphip_prior_four_month,
             (NVL(premium_prior_five_month,0)-NVL(ppo_prior_five_month,0))   AS withoutphip_prior_five_month,
             (NVL(premium_prior_six_month,0)- NVL(ppo_prior_six_month,0))    AS withoutphip_prior_six_month,
             --current plus five months

             ( NVL(premium_current_month,0)+ NVL(premium_prior_one_month,0)+NVL(premium_prior_two_month,0)+
               NVL(premium_prior_three_month,0)+NVL(premium_prior_four_month,0)+NVL(premium_prior_five_month,0)
               )AS all_current_plusfive,
             ( NVL(ppo_current_month,0)+NVL(ppo_prior_one_month,0)+NVL(ppo_prior_two_month,0)+
               NVL(ppo_prior_three_month,0)+NVL(ppo_prior_four_month,0)+ NVL(ppo_prior_five_month,0)
               )AS phip_current_plus_five,
             ( (NVL(premium_current_month,0)- NVL(ppo_current_month,0))+(NVL(premium_prior_one_month,0)-NVL(ppo_prior_one_month,0))+
               (NVL(premium_prior_two_month,0)-NVL(ppo_prior_two_month,0))+(NVL(premium_prior_three_month,0)- NVL(ppo_prior_three_month,0))+(NVL(premium_prior_four_month,0)-NVL(ppo_prior_four_month,0))+
               (NVL(premium_prior_five_month,0)-NVL(ppo_prior_five_month,0))
               )AS withoutphip_current_plus_five,
             -- total
             ((NVL(premium_current_month,0)+ NVL(premium_prior_one_month,0)+NVL(premium_prior_two_month,0)+
               NVL(premium_prior_three_month,0)+NVL(premium_prior_four_month,0)+NVL(premium_prior_five_month,0))+
              NVL(premium_prior_six_month,0)
               )AS total_all_plans,

             ((NVL(ppo_current_month,0)+NVL(ppo_prior_one_month,0)+NVL(ppo_prior_two_month,0)+
               NVL(ppo_prior_three_month,0)+NVL(ppo_prior_four_month,0)+ NVL(ppo_prior_five_month,0))+
              NVL(ppo_prior_six_month,0)
               )AS total_phip_plans,
             ( (NVL(premium_current_month,0)- NVL(ppo_current_month,0))+(NVL(premium_prior_one_month,0)-NVL(ppo_prior_one_month,0))+
               (NVL(premium_prior_two_month,0)-NVL(ppo_prior_two_month,0))+(NVL(premium_prior_three_month,0)- NVL(ppo_prior_three_month,0))+(NVL(premium_prior_four_month,0)-NVL(ppo_prior_four_month,0))+
               (NVL(premium_prior_five_month,0)-NVL(ppo_prior_five_month,0))+ (NVL(premium_prior_six_month,0)-NVL(ppo_prior_six_month,0)) --as per scr74062

               )AS total_withoutphip,
             :gv_ReportStartDate AS V_RPTSTARTDATE
             --gv_ReportStopDate AS V_RPTSTOPDATE
        FROM IDENTIFIER(:V_AR_RIA_AGING_ADW_SUMMARY)
        WHERE delinquent_date = :gv_ReportStartDate;

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_PV_REPORTRESULT)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP4'';
V_STEP_NAME :=  ''CALL BDR_BI.SP_ISB_SF_LOG_INSERT_COMPLETE(:gv_Log_id)'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CALL BDR_BI.SP_ISB_SF_LOG_INSERT_COMPLETE(:gv_Log_id);

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0 ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




let res_set RESULTSET;
let select_statement1 := ''SELECT * FROM pv_ReportResult'';
res_set := (EXECUTE IMMEDIATE :select_statement1);
RETURN TABLE(res_set);

EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);

gv_error_code := SQLERRM;
CALL BDR_BI.SP_ISB_SF_LOG_INSERT_ERROR(:gv_Log_id, :gv_error_code);

RAISE;

END;

';