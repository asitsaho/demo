USE SCHEMA BDR_BI; CREATE OR REPLACE PROCEDURE "SP_ISB_SF_BIL05A_DAILY_RECON"("PV_REPORTSTARTDATE" DATE, "PV_REPORTSTOPDATE" DATE, "DB_NAME" VARCHAR(16777216) DEFAULT '', "TGT_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "TGT2_SC" VARCHAR(16777216) DEFAULT '', "SRC_SC" VARCHAR(16777216) DEFAULT 'SRC_DWADM', "SRC2_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "UTIL_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "PIPELINE_ID" VARCHAR(16777216) DEFAULT '', "PIPELINE_NAME" VARCHAR(16777216) DEFAULT 'SP_ISB_SF_BIL05A_DAILY_RECON')
RETURNS TABLE ()
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

gv_ReportStartDate   DATE := pv_ReportStartDate::DATE;
gv_ReportStopDate   DATE := pv_ReportStopDate::DATE;
gv_Log_id             NUMBER;
gv_error_code        VARCHAR(200);      



V_START_TIME TIMESTAMP;
V_STEP VARCHAR;
V_LAST_QUERY_ID    VARCHAR;
V_ROWS_LOADED   VARCHAR;
V_PROCESS_NAME   VARCHAR DEFAULT ''SP_ISB_SF_BIL05A_DAILY_RECON'';
V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''SP_ISB_SF_BIL05A_DAILY_RECON'';
V_STEP_NAME        VARCHAR;
V_ROWS_PARSED      INTEGER;
V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := COALESCE(:UTIL_SC, ''BDR_BI'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';

BEGIN



------Tables
LET V_pv_ReportResult VARCHAR :=  :TGT_SC || ''.pv_ReportResult'';
LET V_PAYMENT_DTLS VARCHAR :=  :TGT_SC || ''.PAYMENT_DTLS'';
LET V_PAYMENT_FACT VARCHAR :=  :SRC_SC || ''.PAYMENT_FACT'';

LET V_TNDR_TYPE_DIM VARCHAR :=  :SRC_SC || ''.TNDR_TYPE_DIM'';
LET V_PAYMENT_TENDERS_FACT VARCHAR :=  :SRC_SC || ''.PAYMENT_TENDERS_FACT'';
LET V_TNDR_SRC_DIM VARCHAR :=  :SRC_SC || ''.TNDR_SRC_DIM VARCHAR'';
LET V_REASON_DIM VARCHAR :=  :SRC_SC || ''.REASON_DIM'';

LET V_ADJ_TYPE_DIM  VARCHAR :=  :SRC_SC || ''.ADJ_TYPE_DIM'';
LET V_ADJUSTMENT_FACT VARCHAR :=  :SRC_SC || ''.V_ADJUSTMENT_FACT'';







--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP1'';
V_STEP_NAME :=  ''call BDR_BI.FN_ISB_SF_GET_LOG_ID()'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

call BDR_BI.FN_ISB_SF_GET_LOG_ID()
    into :gv_Log_id;

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0 ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP2'';
V_STEP_NAME :=  ''CALL BDR_BI.SP_ISB_SF_INSERT_JOB_LOG()'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

call BDR_BI.SP_ISB_SF_INSERT_JOB_LOG(:gv_Log_id,''BI.PKG_ISB_BILL_REPORTS.SP_DAILY_RECON'',''BIL0005A_Daily_Recon''); 

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0 ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


     
 --EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP3'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE PAYMENT_DTLS'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_PAYMENT_DTLS) AS 
(
    SELECT 
        SRC_FT_ID,
        SRC_PAY_EVENT_ID,
        SRC_PAY_TNDR_ID 
    FROM (
        SELECT 
            SRC_PAY_EVENT_ID,
            SRC_FT_ID,
            SRC_MATCH_TYPE_CD,
            SRC_PAY_TNDR_ID,
            FREEZE_DT,
            ROW_NUMBER() OVER (PARTITION BY SRC_PAY_EVENT_ID ORDER BY FREEZE_DT) AS RNK 
        FROM 
            -- DWADM.PAYMENT_FACT
            IDENTIFIER(:V_PAYMENT_FACT)
        WHERE
            CDC_STATUS_FLAG <> ''D''  
        ORDER BY
            SRC_PAY_EVENT_ID
        ) 
    WHERE RNK=1
);
 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_PAYMENT_DTLS)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP4'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE pv_ReportResult'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());





 CREATE OR REPLACE TEMPORARY TABLE  IDENTIFIER(:V_pv_ReportResult) as  
SELECT   
         SUM(NVL("Lockbox Total # Transactions:",0)) AS "Lockbox Total # Transactions:",
         SUM(NVL("Lockbox Total Dollars:",0)) AS "Lockbox Total Dollars:",
         SUM(NVL("EFT Total # Transactions:",0)) AS "EFT Total # Transactions:",
         SUM(NVL("EFT Total Dollars:",0)) AS "EFT Total Dollars:",
         SUM(NVL("Pension Total # Transaction:",0)) AS "Pension Total # Transaction:",
         SUM(NVL("Pension Total Dollars:",0)) AS "Pension Total Dollars:",
         SUM(NVL("Enrollment Total # Transactions:",0)) AS "Enrollment Total # Transactions:",
         SUM(NVL("Enrollment Total Dollars:",0)) AS "Enrollment Total Dollars:",
         SUM(NVL("Third Party EFT Total # Transactions:",0)) AS "Third Party EFT Total # Transactions:",
         SUM(NVL("Third Party EFT Total Dollars:",0)) AS "Third Party EFT Total Dollars:",
         SUM(NVL("Credit Card Automated Total # Transactions:",0)) AS "Credit Card Automated Total # Transactions:",
         SUM(NVL("Credit Card Automated Total Dollars:",0)) AS "Credit Card Automated Total Dollars:",
         SUM(NVL("Credit Card Member Web Total # Transactions:",0)) AS "Credit Card Member Web Total # Transactions:",
         SUM(NVL("Credit Card Member Web Total Dollars:",0)) AS "Credit Card Member Web Total Dollars:",
         SUM(NVL("Credit Card - Add Payment Total # Transactions:",0)) AS "Credit Card - Add Payment Total # Transactions:",
         SUM(NVL("Credit Card - Add Payment Total Dollars:",0)) AS "Credit Card - Add Payment Total Dollars:",
         SUM(NVL("Online Payment Adjustment Total # Transactions:",0)) AS "Online Payment Adjustment Total # Transactions:",
         SUM(NVL("Online Payment Adjustment Total Dollars:",0)) AS "Online Payment Adjustment Total Dollars:",
         SUM(NVL("Encoding Credits Total # Transactions:",0)) AS "Encoding Credits Total # Transactions:",
         SUM(NVL("Encoding Credits Total Dollars:",0)) AS "Encoding Credits Total Dollars:",
         SUM(NVL("Pro-Rated Term Credit Total # Transactions:",0)) AS "Pro-Rated Term Credit Total # Transactions:",
         SUM(NVL("Pro-Rated Term Credit Total Dollars:",0)) AS "Pro-Rated Term Credit Total Dollars:",
         SUM(NVL("Retro-Active Credit Total # Transactions:",0)) AS "Retro-Active Credit Total # Transactions:",
         SUM(NVL("Retro-Active Credit Total Dollars:",0)) AS "Retro-Active Credit Total Dollars:",
         SUM(NVL("Pro-Rated Loss # Transactions:",0)) AS "Pro-Rated Loss # Transactions:",
         SUM(NVL("Pro-Rated Loss Total Dollars:",0)) AS "Pro-Rated Loss Total Dollars:",
         SUM(NVL("From Prescription Drug Total # Transactions:",0)) AS "From Prescription Drug Total # Transactions:",
         SUM(NVL("From Prescription Drug Total Dollars:",0)) AS "From Prescription Drug Total Dollars:",
         :gv_ReportStartDate AS Start_Date,
         :GV_REPORTSTOPDATE AS End_Date,
         current_timestamp() AS REPORT_RUN_DATE
FROM
    (   SELECT SRC_PAY_TNDR_ID,
        TO_NUMBER(0) AS "Lockbox Total Dollars:",
        TO_NUMBER(0) AS "Lockbox Total # Transactions:",
        TO_NUMBER(0) AS "EFT Total Dollars:",
        TO_NUMBER(0) AS "EFT Total # Transactions:",     
        TO_NUMBER(0) AS "Pension Total Dollars:",
        TO_NUMBER(0) AS "Pension Total # Transaction:",
        TO_NUMBER(0) AS "Enrollment Total Dollars:",
        TO_NUMBER(0) AS "Enrollment Total # Transactions:",
        TO_NUMBER(0) AS "Third Party EFT Total Dollars:",
        TO_NUMBER(0) AS "Third Party EFT Total # Transactions:",
        TO_NUMBER(0) AS "Credit Card Automated Total Dollars:",
        TO_NUMBER(0) AS "Credit Card Automated Total # Transactions:",
        TO_NUMBER(0) AS "Credit Card Member Web Total Dollars:",
        TO_NUMBER(0) AS "Credit Card Member Web Total # Transactions:",
        TO_NUMBER(0) AS "Credit Card - Add Payment Total Dollars:",
        TO_NUMBER(0) AS "Credit Card - Add Payment Total # Transactions:",
        TO_NUMBER(0) AS "Online Payment Adjustment Total Dollars:",
        TO_NUMBER(0) AS "Online Payment Adjustment Total # Transactions:",
        CASE
            WHEN 
                (PAY_AMT + TNDR_AMT) > 0
            THEN 
                (PAY_AMT + TNDR_AMT)
            ELSE 0
        END AS "Encoding Credits Total Dollars:",
        CASE
            WHEN 
                (PAY_AMT + TNDR_AMT) > 0
            THEN
               COUNT(DISTINCT SRC_PAY_TNDR_ID)
        END AS "Encoding Credits Total # Transactions:",
        TO_NUMBER(0)   AS "Pro-Rated Term Credit Total Dollars:",
        TO_NUMBER(0)   AS "Pro-Rated Term Credit Total # Transactions:",                        
        TO_NUMBER(0)   AS "Retro-Active Credit Total Dollars:",
        TO_NUMBER(0)   AS "Retro-Active Credit Total # Transactions:",               
        TO_NUMBER(0)   AS "Pro-Rated Loss Total Dollars:",
        TO_NUMBER(0)   AS "Pro-Rated Loss # Transactions:",
        TO_NUMBER(0)   AS "From Prescription Drug Total Dollars:",
        TO_NUMBER(0)   AS "From Prescription Drug Total # Transactions:"
    FROM
    (
    SELECT
    SUM(PF.PAY_AMT) AS PAY_AMT,
    PTF.TNDR_AMT,
    PTF.SRC_PAY_TNDR_ID
    FROM 
        SRC_DWADM.TNDR_TYPE_DIM TTD
        INNER JOIN SRC_DWADM.PAYMENT_FACT PF ON
                        PF.TNDR_TYPE_CD=TTD.SRC_TNDR_TYPE_CD
                        AND PF.CDC_STATUS_FLAG <> ''D''
                        AND TTD.CURR_REC_FLAG=''Y''
                        AND PF.FT_TYPE=''Pay Cancellation''
                        AND DATE(PF.FREEZE_DT) BETWEEN :gv_ReportStartDate AND :gv_ReportStopDate                  
        INNER JOIN  SRC_DWADM.PAYMENT_TENDERS_FACT PTF ON
                        PF.SRC_PAY_TNDR_ID=PTF.SRC_PAY_TNDR_ID
                        AND PTF.CDC_STATUS_FLAG <> ''D''
                        AND PTF.CDDGEN1_VAL IS NOT NULL
        LEFT OUTER JOIN SRC_DWADM.TNDR_SRC_DIM TS ON
                        PTF.TNDR_SRC_CURR_KEY=TS.TNDR_SRC_CURR_KEY
                        AND TS.CURR_REC_FLAG=''Y''  -- ''Y'' Fetch Always Latest Records
                        AND TS.TNDR_SRC_CURR_KEY NOT IN (''-1'',''0'') -- To Exclude Unknown and Missing Records 
        INNER JOIN SRC_DWADM.REASON_DIM RD ON RD.RSN_CURR_KEY = PF.RSN_CURR_KEY
                        AND RD.CURR_REC_FLAG = ''Y''
                        AND RD.SRC_RSN_CD IN (''EEBK'',''EEUH'')
    GROUP BY
        PTF.TNDR_AMT,
        PTF.SRC_PAY_TNDR_ID) GROUP BY
        PAY_AMT,
        TNDR_AMT,
        SRC_PAY_TNDR_ID

   UNION ALL
    
    
    SELECT PTF.SRC_PAY_TNDR_ID,
        CASE
            WHEN
                SRC_TNDR_SOURCE_CD IN (''BNYLBXDL'',''BNYLBXPB'')
                  AND PF.FT_TYPE=''Pay Segment''
            THEN
                NVL(SUM(PTF.TNDR_AMT),0)
        END AS "Lockbox Total Dollars:",
        CASE
            WHEN
                SRC_TNDR_SOURCE_CD IN (''BNYLBXDL'',''BNYLBXPB'')
                  AND PF.FT_TYPE=''Pay Segment''
            THEN
                COUNT(DISTINCT PTF.SRC_PAY_TNDR_ID)
        END AS "Lockbox Total # Transactions:",
        CASE
           WHEN
             SRC_TNDR_TYPE_CD IN (''ACHS'',''ACHC'')  AND (PF.TNDR_SRC_CD <> ''TI_PDP'' OR PF.TNDR_SRC_CD IS NULL)
--             AND SRC_TNDR_SOURCE_CD <> ''TI_CMPS''
            THEN
              NVL(SUM(PTF.TNDR_AMT),0)
        END AS "EFT Total Dollars:",
        CASE
            WHEN
             SRC_TNDR_TYPE_CD IN (''ACHS'',''ACHC'')  AND (PF.TNDR_SRC_CD <> ''TI_PDP'' OR PF.TNDR_SRC_CD IS NULL)
--             AND SRC_TNDR_SOURCE_CD <> ''TI_CMPS''
            THEN
                 COUNT(DISTINCT PTF.SRC_PAY_TNDR_ID) 
        END AS "EFT Total # Transactions:",
        CASE
           WHEN
                SRC_TNDR_TYPE_CD IN (''PENS'',''PENM'') --Manual Pension Payment,Pension Payment - Saving
                --AND SRC_TNDR_SOURCE_CD IS NULL
           THEN
                 NVL(SUM(PTF.TNDR_AMT),0)
        END AS "Pension Total Dollars:",
        CASE
           WHEN
                SRC_TNDR_TYPE_CD IN (''PENS'',''PENM'') --Manual Pension Payment,Pension Payment - Saving
                --AND SRC_TNDR_SOURCE_CD IS NULL
           THEN
                 COUNT(DISTINCT PTF.SRC_PAY_TNDR_ID)
        END AS "Pension Total # Transaction:",
        CASE
            WHEN
                SRC_TNDR_SOURCE_CD = ''ENROLL'' --ENROLLMENT
                --AND SRC_RSN_CD NOT IN (''EEBK'',''EEUH'',''BNKE'',''MISC'') --BANK ERROR,Encoding Error - Bank,Encoding Error - UHG,TRANSFER TO ANOTHER ACCOUNT 
                AND SRC_TNDR_TYPE_CD NOT IN (''CAS'') --CASH
--                AND SRC_TNDR_SOURCE_CD <> ''TI_CMPS''
            THEN
                NVL(SUM(PTF.TNDR_AMT),0)
        END AS "Enrollment Total Dollars:",
        CASE
            WHEN
                SRC_TNDR_SOURCE_CD = ''ENROLL'' --ENROLLMENT
                --AND SRC_RSN_CD NOT IN (''EEBK'',''EEUH'',''BNKE'',''MISC'') --BANK ERROR,Encoding Error - Bank,Encoding Error - UHG,TRANSFER TO ANOTHER ACCOUNT 
                AND SRC_TNDR_TYPE_CD NOT IN (''CAS'') --CASH
--                AND SRC_TNDR_SOURCE_CD <> ''TI_CMPS''
            THEN
               COUNT(DISTINCT PTF.SRC_PAY_TNDR_ID)
        END AS "Enrollment Total # Transactions:",
        CASE
            WHEN
                SRC_TNDR_TYPE_CD IN (''TPRY'') --3rd Party
                AND SRC_TNDR_SOURCE_CD IN (''JPMTPP'') --JPM - Third Party Payer
            THEN
                NVL(SUM(PTF.TNDR_AMT),0)
        END AS "Third Party EFT Total Dollars:",
        CASE
            WHEN
                SRC_TNDR_TYPE_CD IN (''TPRY'') --3rd Party
                AND SRC_TNDR_SOURCE_CD IN (''JPMTPP'') --JPM - Third Party Payer
            THEN
               COUNT(DISTINCT PTF.SRC_PAY_TNDR_ID)
        END AS "Third Party EFT Total # Transactions:",
        CASE
            WHEN
                SRC_TNDR_TYPE_CD IN (''CCAP'') -- CREDIT CARD
                AND SRC_TNDR_SOURCE_CD IN (''JPMCC'') --JPM CC
                AND PF.UDDGEN19 NOT IN (''WEB'',''WEB-QUICKPAY'') 
                AND PF.UDDGEN18 =''ONETIMECCSYS'' -- ONE TIME CREDIT CARD
            THEN
                 NVL(SUM(PTF.TNDR_AMT),0)
        END AS "Credit Card Automated Total Dollars:",
        CASE
            WHEN
                SRC_TNDR_TYPE_CD IN (''CCAP'') -- CREDIT CARD
                AND SRC_TNDR_SOURCE_CD IN (''JPMCC'') --JPM CC 
                AND PF.UDDGEN19 NOT IN (''WEB'',''WEB-QUICKPAY'')  
                AND PF.UDDGEN18 =''ONETIMECCSYS'' -- ONE TIME CREDIT CARD
            THEN
               COUNT(DISTINCT PTF.SRC_PAY_TNDR_ID)
        END AS "Credit Card Automated Total # Transactions:",
            CASE
            WHEN
                SRC_TNDR_TYPE_CD IN (''CCAP'') -- CREDIT CARD
                AND SRC_TNDR_SOURCE_CD IN (''JPMCC'') --JPM CC
                AND PF.UDDGEN19 IN (''WEB'',''WEB-QUICKPAY'') 
                AND PF.UDDGEN18 =''ONETIMECCSYS'' -- ONE TIME CREDIT CARD
            THEN
                 NVL(SUM(PTF.TNDR_AMT),0)
        END AS "Credit Card Member Web Total Dollars:",
        CASE
            WHEN
                SRC_TNDR_TYPE_CD IN (''CCAP'') -- CREDIT CARD
                AND SRC_TNDR_SOURCE_CD IN (''JPMCC'') --JPM CC
                AND PF.UDDGEN19 IN (''WEB'',''WEB-QUICKPAY'') 
                AND PF.UDDGEN18 =''ONETIMECCSYS'' -- ONE TIME CREDIT CARD
            THEN
               COUNT(DISTINCT PTF.SRC_PAY_TNDR_ID)
        END AS "Credit Card Member Web Total # Transactions:",
        CASE
            WHEN
                SRC_TNDR_TYPE_CD IN (''CCAP'') -- CREDIT CARD
                AND SRC_TNDR_SOURCE_CD IN (''JPMCC'') --JPM CC
                AND PF.UDDGEN19 IS NULL 
            THEN
                 NVL(SUM(PTF.TNDR_AMT),0)
        END AS "Credit Card - Add Payment Total Dollars:",
        CASE
            WHEN
                SRC_TNDR_TYPE_CD IN (''CCAP'') -- CREDIT CARD
                AND SRC_TNDR_SOURCE_CD IN (''JPMCC'') --JPM CC
                AND PF.UDDGEN19 IS NULL 
            THEN
               COUNT(DISTINCT PTF.SRC_PAY_TNDR_ID)
        END AS "Credit Card - Add Payment Total # Transactions:",
        CASE
            WHEN
                (SRC_TNDR_SOURCE_CD NOT IN (''BNYLBXDL'',''BNYLBXPB'',''TI_PDP'') AND SRC_TNDR_TYPE_CD IN (''WIRS'',''WIRC''))
        OR SRC_TNDR_SOURCE_CD IN (''JPMXFR'') -- US136258
            THEN
                NVL(SUM(PTF.TNDR_AMT),0)
        END AS "Online Payment Adjustment Total Dollars:",
        CASE
            WHEN
                (SRC_TNDR_SOURCE_CD NOT IN (''BNYLBXDL'',''BNYLBXPB'',''TI_PDP'') AND SRC_TNDR_TYPE_CD IN (''WIRS'',''WIRC''))
        OR SRC_TNDR_SOURCE_CD IN (''JPMXFR'') -- US136258
            THEN
                COUNT(DISTINCT PTF.SRC_PAY_TNDR_ID)
        END AS "Online Payment Adjustment Total # Transactions:",
        TO_NUMBER(0) AS "Encoding Credits Total Dollars:",
        TO_NUMBER(0) AS "Encoding Credits Total # Transactions:",
        TO_NUMBER(0) AS "Pro-Rated Term Credit Total Dollars:",
        TO_NUMBER(0) AS "Pro-Rated Term Credit Total # Transactions:",                        
        TO_NUMBER(0) AS "Retro-Active Credit Total Dollars:",
        TO_NUMBER(0) AS "Retro-Active Credit Total # Transactions:",               
        TO_NUMBER(0) AS "Pro-Rated Loss Total Dollars:",
        TO_NUMBER(0) AS "Pro-Rated Loss # Transactions:",
        CASE
            WHEN
                SRC_TNDR_SOURCE_CD IN (''TI_PDP'')
                  AND PF.FT_TYPE=''Pay Segment''
            THEN
                NVL(SUM(PTF.TNDR_AMT),0)
        END AS "From Prescription Drug Total Dollars:",
        CASE
            WHEN
                SRC_TNDR_SOURCE_CD IN (''TI_PDP'')
                  AND PF.FT_TYPE=''Pay Segment''
            THEN
                COUNT(DISTINCT PTF.SRC_PAY_TNDR_ID)
        END AS "From Prescription Drug Total # Transactions:"
    FROM 
        SRC_DWADM.TNDR_TYPE_DIM TTD
        LEFT OUTER JOIN SRC_DWADM.PAYMENT_FACT PF ON
                        PF.TNDR_TYPE_CD=TTD.SRC_TNDR_TYPE_CD
                        AND PF.CDC_STATUS_FLAG <> ''D''
                        AND PF.FT_TYPE=''Pay Segment''
                        AND date(PF.FREEZE_DT) BETWEEN :gv_ReportStartDate AND :gv_ReportStopDate
        INNER JOIN PAYMENT_DTLS ON PAYMENT_DTLS.SRC_FT_ID=PF.SRC_FT_ID 
                        AND PAYMENT_DTLS.SRC_PAY_EVENT_ID=PF.SRC_PAY_EVENT_ID  
                        AND PAYMENT_DTLS.SRC_PAY_TNDR_ID=PF.SRC_PAY_TNDR_ID
        LEFT OUTER JOIN  SRC_DWADM.PAYMENT_TENDERS_FACT PTF ON
                        PF.SRC_PAY_TNDR_ID=PTF.SRC_PAY_TNDR_ID
                        AND PTF.CDC_STATUS_FLAG <> ''D''
        LEFT OUTER JOIN SRC_DWADM.TNDR_SRC_DIM TS ON
                        PTF.TNDR_SRC_CURR_KEY=TS.TNDR_SRC_CURR_KEY
                        AND TS.CURR_REC_FLAG=''Y''  -- ''Y'' Fetch Always Latest Records
                        AND TS.TNDR_SRC_CURR_KEY NOT IN (''-1'',''0'') -- To Exclude Unknown and Missing Records 
        LEFT JOIN SRC_DWADM.REASON_DIM RD ON RD.RSN_CURR_KEY = PF.RSN_CURR_KEY
                        AND RD.CURR_REC_FLAG = ''Y''
    WHERE
        TTD.CURR_REC_FLAG=''Y'' 
    GROUP BY
        PF.FT_TYPE,
         PF.TNDR_SRC_CD,
        SRC_TNDR_SOURCE_CD,
        TTD.SRC_TNDR_TYPE_CD,
        PF.UDDGEN19,
        PF.UDDGEN18,
        PTF.SRC_PAY_TNDR_ID

  UNION ALL
    
    SELECT
        SRC_ADJ_ID,
        SUM("Lockbox Total Dollars:") AS "Lockbox Total Dollars:",
        SUM("Lockbox Total # Transactions:") AS "Lockbox Total # Transactions:",
        SUM("EFT Total Dollars:") AS "EFT Total Dollars:",
        SUM("EFT Total # Transactions:") AS "EFT Total # Transactions:",
        SUM("Pension Total Dollars:") AS "Pension Total Dollars:",
        SUM("Pension Total # Transaction:") AS "Pension Total # Transaction:",
        SUM("Enrollment Total Dollars:") AS "Enrollment Total Dollars:",
        SUM("Enrollment Total # Transactions:") AS "Enrollment Total # Transactions:",
        SUM("Third Party EFT Total Dollars:") AS "Third Party EFT Total Dollars:",
        SUM("Third Party EFT Total # Transactions:") AS "Third Party EFT Total # Transactions:",
        SUM("Credit Card Automated Total Dollars:") AS "Credit Card Automated Total Dollars:",
        SUM("Credit Card Automated Total # Transactions:") AS "Credit Card Automated Total # Transactions:",
        SUM("Credit Card Member Web Total Dollars:") AS "Credit Card Member Web Total Dollars:",
        SUM("Credit Card Member Web Total # Transactions:") AS "Credit Card Member Web Total # Transactions:",
        SUM("Credit Card - Add Payment Total Dollars:") AS "Credit Card - Add Payment Total Dollars:",
        SUM("Credit Card - Add Payment Total # Transactions:") AS "Credit Card - Add Payment Total # Transactions:",
        SUM("Online Payment Adjustment Total Dollars:") AS "Online Payment Adjustment Total Dollars:",
        SUM("Online Payment Adjustment Total # Transactions:") AS "Online Payment Adjustment Total # Transactions:",
        SUM("Encoding Credits Total Dollars:") AS "Encoding Credits Total Dollars:",
        SUM("Encoding Credits Total # Transactions:") AS "Encoding Credits Total # Transactions:",
        SUM("Pro-Rated Term Credit Total Dollars:") AS "Pro-Rated Term Credit Total Dollars:",
        SUM("Pro-Rated Term Credit Total # Transactions:") AS "Pro-Rated Term Credit Total # Transactions:",                       
        SUM("Retro-Active Credit Total Dollars:") AS "Retro-Active Credit Total Dollars:",
        SUM("Retro-Active Credit Total # Transactions:") AS "Retro-Active Credit Total # Transactions:",               
        SUM("Pro-Rated Loss Total Dollars:") AS "Pro-Rated Loss Total Dollars:",
        SUM("Pro-Rated Loss # Transactions:") AS "Pro-Rated Loss # Transactions:",
        SUM("From Prescription Drug Total Dollars:") AS "From Prescription Drug Total Dollars:",
        SUM("From Prescription Drug Total # Transactions:") AS "From Prescription Drug Total # Transactions:"
    FROM
        (
        SELECT AF.SRC_ADJ_ID AS SRC_ADJ_ID,DATE(AF.FREEZE_DT) AS FREEZE_DT,
                    TO_NUMBER(0) AS "Lockbox Total Dollars:",
                    TO_NUMBER(0) AS "Lockbox Total # Transactions:",
                    TO_NUMBER(0) AS "EFT Total Dollars:",
                    TO_NUMBER(0) AS "EFT Total # Transactions:",
                    TO_NUMBER(0) AS "Pension Total Dollars:",
                    TO_NUMBER(0) AS "Pension Total # Transaction:",
                    TO_NUMBER(0) AS "Enrollment Total Dollars:",
                    TO_NUMBER(0) AS "Enrollment Total # Transactions:",
                    TO_NUMBER(0) AS "Third Party EFT Total Dollars:",
                    TO_NUMBER(0) AS "Third Party EFT Total # Transactions:",
                    TO_NUMBER(0) AS "Credit Card Automated Total Dollars:",
                    TO_NUMBER(0) AS "Credit Card Automated Total # Transactions:",
                    TO_NUMBER(0) AS "Credit Card Member Web Total Dollars:",
                    TO_NUMBER(0) AS "Credit Card Member Web Total # Transactions:",
                    TO_NUMBER(0) AS "Credit Card - Add Payment Total Dollars:",
                    TO_NUMBER(0) AS "Credit Card - Add Payment Total # Transactions:",
                    CASE
                        WHEN
                            ATD.SRC_ADJ_TYPE_CD = ''WMISCLSS'' --Miscellaneous Loss
                            AND NVL(SUM(AF.ADJ_AMT),0) > 0
                        THEN
                            NVL(SUM(AF.ADJ_AMT),0)
                        ELSE 0              
                    END AS "Online Payment Adjustment Total Dollars:",
                    CASE
                        WHEN
                            ATD.SRC_ADJ_TYPE_CD = ''WMISCLSS'' -- Miscellaneous Loss
                            AND NVL(SUM(AF.ADJ_AMT),0) > 0
                        THEN
                            COUNT(DISTINCT AF.SRC_ADJ_ID)
                        ELSE 0    
                    END AS "Online Payment Adjustment Total # Transactions:",
                    TO_NUMBER(0) AS "Encoding Credits Total Dollars:",
                    TO_NUMBER(0) AS "Encoding Credits Total # Transactions:",
                    CASE
                        WHEN
                            ATD.SRC_ADJ_TYPE_CD = ''WPRRTDCR'' --Pro-rated Credit Write-Off
                        THEN
                            NVL(SUM(AF.ADJ_AMT),0)
                    END AS "Pro-Rated Term Credit Total Dollars:",
                    CASE
                        WHEN
                            ATD.SRC_ADJ_TYPE_CD = ''WPRRTDCR'' --Pro-rated Credit Write-Off
                        THEN
                            COUNT(DISTINCT AF.SRC_ADJ_ID) 
                    END AS "Pro-Rated Term Credit Total # Transactions:",                       
                    CASE
                        WHEN
                            ATD.SRC_ADJ_TYPE_CD = ''WRETROCR'' --Retroactive Credit Write-Off
                        THEN
                             NVL(SUM(AF.ADJ_AMT),0)
                    END AS "Retro-Active Credit Total Dollars:",
                    CASE
                        WHEN
                            ATD.SRC_ADJ_TYPE_CD = ''WRETROCR'' --Retroactive Credit Write-Off
                        THEN
                           COUNT(DISTINCT AF.SRC_ADJ_ID)  
                    END AS "Retro-Active Credit Total # Transactions:",               
                    CASE
                        WHEN
                            ATD.SRC_ADJ_TYPE_CD = ''WRPRTDLS'' --Pro Rated Loss Write-Off
                        THEN
                             NVL(SUM(AF.ADJ_AMT),0)
                    END AS "Pro-Rated Loss Total Dollars:",
                    CASE
                        WHEN
                            ATD.SRC_ADJ_TYPE_CD = ''WRPRTDLS'' --Pro Rated Loss Write-Off
                        THEN
                           COUNT(DISTINCT AF.SRC_ADJ_ID)  
                    END AS "Pro-Rated Loss # Transactions:",
                    TO_NUMBER(0) AS "From Prescription Drug Total Dollars:",
                    TO_NUMBER(0) AS "From Prescription Drug Total # Transactions:"
                FROM
                    SRC_DWADM.ADJ_TYPE_DIM ATD
                    LEFT JOIN SRC_DWADM.ADJUSTMENT_FACT AF ON ATD.ADJ_TYPE_CURR_KEY = AF.ADJ_TYPE_CURR_KEY
                                                    AND date(AF.FREEZE_DT) BETWEEN :gv_ReportStartDate AND :gv_ReportStopDate                                                  
                WHERE 
                    ATD.CURR_REC_FLAG = ''Y'' -- ''Y'' Fetch Always Latest Records
                    AND ATD.SRC_ADJ_TYPE_CD IN (''WRETROCR'',''WRPRTDLS'',''WPRRTDCR'',''WMISCLSS'')            
                GROUP BY
                    ATD.SRC_ADJ_TYPE_CD,AF.SRC_ADJ_ID,AF.FREEZE_DT)
       GROUP BY 
        SRC_ADJ_ID);


 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_pv_ReportResult)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP5'';
V_STEP_NAME :=  ''CALL BDR_BI.SP_ISB_SF_LOG_INSERT_COMPLETE(:gv_Log_id)'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CALL BDR_BI.SP_ISB_SF_LOG_INSERT_COMPLETE(:gv_Log_id);

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0 ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


 let res_set RESULTSET;
let select_statement1 := ''SELECT * FROM pv_ReportResult'';
res_set := (EXECUTE IMMEDIATE :select_statement1);
RETURN TABLE(res_set);


EXCEPTION
					
																				
																							
			   
																   
					   

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);

gv_error_code := SQLERRM;
CALL BDR_BI.SP_ISB_SF_LOG_INSERT_ERROR(:gv_Log_id, :gv_error_code);

RAISE;

END;

';