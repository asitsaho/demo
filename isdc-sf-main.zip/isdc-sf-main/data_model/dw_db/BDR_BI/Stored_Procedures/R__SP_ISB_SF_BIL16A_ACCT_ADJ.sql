USE SCHEMA BDR_BI; CREATE OR REPLACE PROCEDURE "SP_ISB_SF_BIL16A_ACCT_ADJ"("PV_REPORTSTARTDATE" DATE, "PV_REPORTSTOPDATE" DATE, "PV_FREQUENCY" VARCHAR(1), "DB_NAME" VARCHAR(16777216) DEFAULT '', "TGT_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "TGT2_SC" VARCHAR(16777216) DEFAULT '', "SRC_SC" VARCHAR(16777216) DEFAULT 'SRC_DWADM', "SRC2_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "UTIL_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "PIPELINE_ID" VARCHAR(16777216) DEFAULT '', "PIPELINE_NAME" VARCHAR(16777216) DEFAULT 'SP_ISB_SF_BIL16A_ACCT_ADJ')
RETURNS TABLE ()
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

  gv_ReportStartDate                DATE := DATE(pv_ReportStartDate);
  gv_ReportStopDate                DATE := DATE(pv_ReportStopDate);
  gv_frequency                     CHAR := pv_frequency; 
  gv_Log_id                          NUMBER;
  gv_error_code                     varchar(200);


V_START_TIME TIMESTAMP;
V_STEP VARCHAR;
V_LAST_QUERY_ID    VARCHAR;
V_ROWS_LOADED   VARCHAR;
V_PROCESS_NAME   VARCHAR DEFAULT ''SP_ISB_SF_BIL16A_ACCT_ADJ'';
V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''SP_ISB_SF_BIL16A_ACCT_ADJ'';
V_STEP_NAME        VARCHAR;
V_ROWS_PARSED      INTEGER;
V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := COALESCE(:UTIL_SC, ''BDR_BI'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';
BEGIN
----MEMBER
----MEMBER
LET V_MEMBER VARCHAR:=  :TGT_SC || ''.MEMBER'';

----DWADM.CI_APAY_CLR_STG_VW
----BDR_BI.CI_APAY_CLR_STG_VW
LET V_CI_APAY_CLR_STG_VW VARCHAR:=  :SRC2_SC || ''.CI_APAY_CLR_STG_VW'';

----DWADM.ADJ_TYPE_DIM
----SRC_DWADM.ADJ_TYPE_DIM
LET V_ADJ_TYPE_DIM VARCHAR:=  :SRC_SC || ''.ADJ_TYPE_DIM'';

----PAYOR
----PAYOR
LET V_PAYOR VARCHAR:=  :TGT_SC || ''.PAYOR'';

----DWADM.CI_ACCT_APAY_VW
----SRC_BDR_BI.CI_ACCT_APAY_VW
LET V_CI_ACCT_APAY_VW VARCHAR:=  :SRC2_SC || ''.CI_ACCT_APAY_VW'';

----DWADM.PAYMENT_FACT
----SRC_DWADM.PAYMENT_FACT
LET V_PAYMENT_FACT VARCHAR:=  :SRC_SC || ''.PAYMENT_FACT'';

----DWADM.ADDRESS_DIM
----SRC_DWADM.ADDRESS_DIM
LET V_ADDRESS_DIM VARCHAR:=  :SRC_SC || ''.ADDRESS_DIM'';

----DWADM.PAYMENT_TENDERS_FACT
----SRC_DWADM.PAYMENT_TENDERS_FACT
LET V_PAYMENT_TENDERS_FACT VARCHAR:=  :SRC_SC || ''.PAYMENT_TENDERS_FACT'';

----DWADM.REF_WO_REQ_VW
----SRC_DWADM.REF_WO_REQ_VW
LET V_REF_WO_REQ_VW VARCHAR:=  :SRC2_SC || ''.REF_WO_REQ_VW'';

----DWADM.CUSTOMER_DIM
----SRC_DWADM.CUSTOMER_DIM
LET V_CUSTOMER_DIM VARCHAR:=  :SRC_SC || ''.CUSTOMER_DIM'';

----PV_REPORTRESULT
----PV_REPORTRESULT
LET V_PV_REPORTRESULT VARCHAR:=  :TGT_SC || ''.PV_REPORTRESULT'';

----DWADM.ADJUSTMENT_FACT
----SRC_DWADM.ADJUSTMENT_FACT
LET V_ADJUSTMENT_FACT VARCHAR:=  :SRC_SC || ''.ADJUSTMENT_FACT'';

----DWADM.REASON_DIM
----SRC_DWADM.REASON_DIM
LET V_REASON_DIM VARCHAR:=  :SRC_SC || ''.REASON_DIM'';

----REF_WO_REQ
----REF_WO_REQ
LET V_REF_WO_REQ VARCHAR:=  :TGT_SC || ''.REF_WO_REQ'';

----DWADM.ACCOUNT_DIM
----SRC_DWADM.ACCOUNT_DIM
LET V_ACCOUNT_DIM VARCHAR:=  :SRC_SC || ''.ACCOUNT_DIM'';




--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP1'';
V_STEP_NAME :=  ''call BDR_BI.FN_ISB_SF_GET_LOG_ID()'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

call BDR_BI.FN_ISB_SF_GET_LOG_ID()
    into :gv_Log_id;

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP2'';
V_STEP_NAME :=  ''CASE gv_frequency'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CASE gv_frequency
    WHEN ''W''
    THEN
    CALL BDR_BI.SP_ISB_SF_INSERT_JOB_LOG(:gv_Log_id,''BI.PKG_ISB_BILL_REPORTS.SP_ISB_ACCOUNT_ADJUSTMENT'',''BIL0016A_ISB_Account_Adjustment-Wkly''); 
    ELSE
    CALL BDR_BI.SP_ISB_SF_INSERT_JOB_LOG(:gv_Log_id,''BI.PKG_ISB_BILL_REPORTS.SP_ISB_ACCOUNT_ADJUSTMENT'',''BIL0016A_ISB_Account_Adjustment-Mthly''); 
END CASE;

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0 ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP3'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE REF_WO_REQ'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_REF_WO_REQ) AS
(
   SELECT 
            COMMENTS, ADJ_ID
        FROM
            IDENTIFIER(:V_REF_WO_REQ_VW)
        WHERE
            BUS_OBJ_CD=''C1-WORequest'' -- Wirte Off Request only
            AND BO_STATUS_CD = ''PROCESSED'' AND LOG_BO_STATUS_CD = ''PROCESSED   ''
);

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_REF_WO_REQ)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP4'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE pv_ReportResult'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_pv_ReportResult) AS
   SELECT 
    ADJUSTMENT_TYPE,
    MAINTENANCE_PROCESS_DATE,
    TRANSACTION_NOTION,
    MEMBER_NUMBER,
    MEMBER_NAME,
    STATE,
    EMPLOYER_ID,
    SUM(ADJUSTMENT_AMOUNT) AS ADJUSTMENT_AMOUNT,
    :gv_ReportStartDate AS START_DATE,
    :gv_ReportStopDate AS END_DATE,
    CURRENT_TIMESTAMP() AS RUN_DATE
    FROM
    (
            /*Below block is for Individual Wirte-off*/
            SELECT 
            ATD.ADJ_TYPE_DESCR AS ADJUSTMENT_TYPE,
            AF.FREEZE_DT AS MAINTENANCE_PROCESS_DATE,
            RWR.COMMENTS AS TRANSACTION_NOTION,
            CASE
            WHEN
            CD.CDF3_VAL IS NULL
            THEN
            ''000000000-00''
            ELSE
            (CD.CDF3_VAL || ''-'' || CD.CDF12_VAL || CD.CDF5_VAL ) 
            END AS MEMBER_NUMBER,
            CD.NAME AS MEMBER_NAME,
            ADDR.STATE AS STATE,
            EMP.EMPLOYER_ID AS EMPLOYER_ID,
            SUM(AF.ADJ_AMT) AS ADJUSTMENT_AMOUNT,
            AF.SRC_ADJ_ID as SRC_ADJ_ID
            FROM
            IDENTIFIER(:V_ADJUSTMENT_FACT) AF
            INNER JOIN IDENTIFIER(:V_ADJ_TYPE_DIM) ATD ON ATD.ADJ_TYPE_CURR_KEY = AF.ADJ_TYPE_CURR_KEY
                                            AND ATD.CURR_REC_FLAG = ''Y'' -- ''Y'' Fetch Always Latest Records 
											AND AF.CDC_STATUS_FLAG<>''D''					
            INNER JOIN IDENTIFIER(:V_CUSTOMER_DIM) CD ON AF.CUST_CURR_KEY = CD.CUST_CURR_KEY
                                            AND CD.CURR_REC_FLAG = ''Y'' -- ''Y'' Fetch Always Latest Records 
                                            AND CD.ID_TYPE_CD = ''INDID'' -- INDIVIDUAL INDENTIFIER
            INNER JOIN (
                                    SELECT 
                                        AD.*,
                                        DENSE_RANK() OVER (ORDER BY AD.ADDRESS_TYPE_FLG ) AS ADDRESS_RANK
                                    FROM
                                        IDENTIFIER(:V_ADDRESS_DIM) AD
                                    WHERE AD.CURR_REC_FLAG=''Y''
                                        AND AD.EFFT_DT = (
                                                    SELECT  
                                                    MAX(A1.EFFT_DT) AS EFFT_DT
                                                    FROM 
                                                    IDENTIFIER(:V_ADDRESS_DIM) A1
                                                    WHERE TRIM(A1.ENTITY_ID) = TRIM(AD.ENTITY_ID)
													AND A1.CURR_REC_FLAG=''Y''
                                                    )
                                    ) ADDR ON TRIM(ADDR.ENTITY_ID) = CD.SRC_CUST_ID
                                     AND ADDR.ENTITY_FLG = ''PERS'' -- PERSONS ADDRESS
                                     AND ADDR.ADDRESS_RANK = 1
                                     AND ADDR.INACTIVE_DTTM IS NULL
            INNER JOIN IDENTIFIER(:V_REF_WO_REQ) RWR ON RWR.ADJ_ID = AF.SRC_ADJ_ID   
            LEFT JOIN (
                SELECT
                CUSTOMER_EMP.ID_VAL AS EMPLOYER_ID,
                CUSTOMER_EMP.NAME AS EMPLOYER_NAME,
                CUSTOMER_EMP.SRC_CUST_ID
                FROM
                IDENTIFIER(:V_CUSTOMER_DIM) CUSTOMER_EMP
                WHERE CUSTOMER_EMP.CUST_TYPE = ''Parent Customer'' 
                    AND CUSTOMER_EMP.CURR_REC_FLAG=''Y''
                    AND CUSTOMER_EMP.ID_TYPE_CD = ''EMPID''
        ) EMP ON CD.PARENT_CUST_ID = EMP.SRC_CUST_ID   
            WHERE
            AF.ADJ_STATUS_DESCR = ''Frozen'' -- Adjustment Status Frozen
            AND DATE(AF.FREEZE_DT) BETWEEN :gv_ReportStartDate AND :gv_ReportStopDate
            GROUP BY
            ATD.ADJ_TYPE_DESCR,
            AF.FREEZE_DT,
            AF.SRC_ADJ_ID,
            RWR.COMMENTS,
            EMP.EMPLOYER_ID,
            CD.CDF3_VAL,
            CD.CDF5_VAL,
            CD.CDF12_VAL,
            CD.NAME,
            ADDR.STATE
            
            
          UNION ALL
            /*Below block is for Employer Wirte-off*/
            SELECT 
            ATD.ADJ_TYPE_DESCR AS ADJUSTMENT_TYPE,
            AF.FREEZE_DT AS MAINTENANCE_PROCESS_DATE,
            RWR.COMMENTS AS TRANSACTION_NOTION,
            ''000000000-00'' AS MEMBER_NUMBER,
            NULL AS MEMBER_NAME,
            --NVL(PF.CDDGEN7_VAL,ADDR.STATE)
			NULL AS STATE,
            CD.ID_VAL AS EMPLOYER_ID,
            SUM(AF.ADJ_AMT) AS ADJUSTMENT_AMOUNT,
            AF.SRC_ADJ_ID as SRC_ADJ_ID
            
            FROM
            IDENTIFIER(:V_ADJUSTMENT_FACT) AF
            INNER JOIN IDENTIFIER(:V_ADJ_TYPE_DIM) ATD ON ATD.ADJ_TYPE_CURR_KEY = AF.ADJ_TYPE_CURR_KEY
                                            AND ATD.CURR_REC_FLAG = ''Y'' -- ''Y'' Fetch Always Latest Records 
											AND AF.CDC_STATUS_FLAG<>''D''
            INNER JOIN IDENTIFIER(:V_CUSTOMER_DIM) CD ON AF.CUST_CURR_KEY = CD.CUST_CURR_KEY
                                            AND CD.CURR_REC_FLAG = ''Y'' -- ''Y'' Fetch Always Latest Records 
                                            AND CD.ID_TYPE_CD = ''EMPID'' -- Employer Indentifier
            INNER JOIN REF_WO_REQ RWR ON RWR.ADJ_ID = AF.SRC_ADJ_ID                          
            WHERE
            AF.ADJ_STATUS_DESCR = ''Frozen'' -- Adjustment Status Frozen           
            AND DATE(AF.FREEZE_DT) BETWEEN :gv_ReportStartDate AND :gv_ReportStopDate
            GROUP BY
            ATD.ADJ_TYPE_DESCR,
            AF.FREEZE_DT,
            AF.SRC_ADJ_ID,
            RWR.COMMENTS,
            CD.ID_VAL
	
    UNION ALL
    /*Below block is for Claims and unclaims*/
        SELECT
        CASE WHEN AD.CDF6_VAL=''ICCLAIMS''THEN ''Claims''
             WHEN AD.CDF6_VAL=''ICESCHMT''THEN ''Unclaimed'' ELSE '''' END AS ADJUSTMENT_TYPE,
        PF.FREEZE_DT AS MAINTENANCE_PROCESS_DATE,
        PF.CDDGEN3_VAL AS TRANSACTION_NOTION,
        CASE
        WHEN
        CD.CDF3_VAL IS NULL
        THEN
        ''000000000-00''
        ELSE
        (CD.CDF3_VAL || ''-'' || CD.CDF12_VAL || CD.CDF5_VAL) 
        END AS MEMBER_NUMBER,
        CD.NAME AS MEMBER_NAME,
        NVL(PF.CDDGEN7_VAL,ADDR.STATE) AS STATE,
        NULL AS EMPLOYER_ID,
        SUM(PF.PAY_AMT) AS ADJUSTMENT_AMOUNT,
        NULL as SRC_ADJ_ID -- To add same no of columns in all unions.SRC ADJ ID is required to exact number of transactions even with sametimestamp
    FROM
        IDENTIFIER(:V_PAYMENT_FACT) PF
        INNER JOIN IDENTIFIER(:V_ACCOUNT_DIM) AD ON AD.ACCT_CURR_KEY = PF.ACCT_CURR_KEY AND AD.CDF6_VAL IN (''ICCLAIMS'',''ICESCHMT'')
                                                    AND AD.CURR_REC_FLAG = ''Y''
        /*As per enhancement pulling member info from payor account in case of transfer from member to other account*/
		INNER JOIN IDENTIFIER(:V_PAYMENT_TENDERS_FACT) PTF ON PTF.SRC_PAY_TNDR_ID=PF.SRC_PAY_TNDR_ID AND PTF.SRC_PAY_EVENT_ID=PF.SRC_PAY_EVENT_ID  
                                                    AND PF.CDC_STATUS_FLAG<>''D'' AND PTF.CDC_STATUS_FLAG<>''D''
        LEFT OUTER JOIN IDENTIFIER(:V_CUSTOMER_DIM) CD ON ((PF.CDDGEN4_VAL = CD.CDF3_VAL AND PF.CDDGEN9_VAL = CD.CDF5_VAL AND PF.CDDGEN4_VAL IS NOT NULL) OR PTF.CUST_CURR_KEY=CD.CUST_CURR_KEY)
                                                    AND CD.CURR_REC_FLAG = ''Y'' -- ''Y'' Fetch Always Latest Records 
                                                    AND CD.ID_TYPE_CD = ''INDID'' -- INDIVIDUAL INDENTIFIER
        LEFT OUTER JOIN (
                                SELECT 
                                    AD.*,
                                    DENSE_RANK() OVER (ORDER BY AD.ADDRESS_TYPE_FLG ) AS ADDRESS_RANK
                                FROM
                                    IDENTIFIER(:V_ADDRESS_DIM) AD
                                WHERE
                                    AD.EFFT_DT = (
                                                SELECT  
                                                MAX(A1.EFFT_DT) AS EFFT_DT
                                                FROM 
                                                IDENTIFIER(:V_ADDRESS_DIM) A1
                                                WHERE TRIM(A1.ENTITY_ID) = TRIM(AD.ENTITY_ID)
                                                )
                                ) ADDR ON TRIM(ADDR.ENTITY_ID) = CD.SRC_CUST_ID
                                 AND ADDR.ENTITY_FLG = ''PERS'' -- PERSONS ADDRESS
                                 AND ADDR.ADDRESS_RANK = 1
                                 AND ADDR.INACTIVE_DTTM IS NULL 
                   WHERE DATE(PF.FREEZE_DT) BETWEEN :gv_ReportStartDate AND :gv_ReportStopDate
    GROUP BY
        PF.FREEZE_DT,
        PF.CDDGEN3_VAL,
        CD.CDF3_VAL,
        CD.CDF5_VAL,
        CD.CDF12_VAL,
        CD.NAME,
        PF.CDDGEN7_VAL,
        ADDR.STATE,
        AD.CDF6_VAL
    
    UNION ALL
    /*Below block is for Pension*/
    SELECT
    ''PENSION'' AS ADJUSTMENT_TYPE,
    PF.FREEZE_DT AS MAINTENANCE_PROCESS_DATE,
    PF.CDDGEN3_VAL AS TRANSACTION_NOTION,
    CASE
    WHEN
    CD.CDF3_VAL IS NULL
    THEN
    ''000000000-00''
    ELSE
    (CD.CDF3_VAL || ''-'' || CD.CDF12_VAL || CD.CDF5_VAL) 
    END AS MEMBER_NUMBER,
    CD.NAME AS MEMBER_NAME,
    NVL(PF.CDDGEN7_VAL,ADDR.STATE) AS STATE,
    NULL AS EMPLOYER_ID,
    SUM(PF.PAY_AMT) *-1 AS ADJUSTMENT_AMOUNT,
    NULL as SRC_ADJ_ID -- To add same no of columns in all unions.SRC ADJ ID is required to exact number of transactions even with sametimestamp
FROM
    IDENTIFIER(:V_PAYMENT_FACT) PF
	INNER JOIN IDENTIFIER(:V_CI_APAY_CLR_STG_VW) STG ON STG.PAY_TENDER_ID=PF.SRC_PAY_TNDR_ID AND STG.CDC_FLAG<>''D'' AND PF.FT_TYPE = ''Pay Cancellation'' AND PF.CDC_STATUS_FLAG<>''D''
	INNER JOIN IDENTIFIER(:V_CI_ACCT_APAY_VW) APAY ON APAY.ACCT_APAY_ID=STG.ACCT_APAY_ID AND APAY.APAY_RTE_TYPE_CD =''PEN-FRS''
    INNER JOIN IDENTIFIER(:V_ACCOUNT_DIM) AD ON AD.ACCT_CURR_KEY = PF.ACCT_CURR_KEY
                                                AND AD.CURR_REC_FLAG = ''Y''
    INNER JOIN IDENTIFIER(:V_REASON_DIM) RD ON RD.RSN_CURR_KEY = PF.RSN_CURR_KEY 
                                AND RD.CURR_REC_FLAG = ''Y'' -- ''Y'' Fetch Always Latest Records 
                                AND RD.UDF1_VAL <> ''Y'' -- transfer Switch                                            
    LEFT OUTER JOIN IDENTIFIER(:V_CUSTOMER_DIM) CD ON PF.CUST_CURR_KEY = CD.CUST_CURR_KEY
                                                AND CD.CURR_REC_FLAG = ''Y'' -- ''Y'' Fetch Always Latest Records 
                                                AND CD.ID_TYPE_CD = ''INDID'' -- INDIVIDUAL INDENTIFIER
    LEFT OUTER JOIN (
                            SELECT 
                                AD.*,
                                DENSE_RANK() OVER (ORDER BY AD.ADDRESS_TYPE_FLG ) AS ADDRESS_RANK
                            FROM
                                IDENTIFIER(:V_ADDRESS_DIM) AD
                            WHERE
                                AD.EFFT_DT = (
                                            SELECT  
                                            MAX(A1.EFFT_DT) AS EFFT_DT
                                            FROM 
                                            IDENTIFIER(:V_ADDRESS_DIM) A1
                                            WHERE TRIM(A1.ENTITY_ID) = TRIM(AD.ENTITY_ID)
                                            )
                            ) ADDR ON TRIM(ADDR.ENTITY_ID) = CD.SRC_CUST_ID
                             AND ADDR.ENTITY_FLG = ''PERS'' -- PERSONS ADDRESS
                             AND ADDR.ADDRESS_RANK = 1
                             AND ADDR.INACTIVE_DTTM IS NULL 
               WHERE DATE(PF.FREEZE_DT) BETWEEN :gv_ReportStartDate AND :gv_ReportStopDate
    GROUP BY
        PF.FREEZE_DT,
        PF.CDDGEN3_VAL,
        CD.CDF3_VAL,
        CD.CDF5_VAL,
        CD.CDF12_VAL,
        CD.NAME,
        PF.CDDGEN7_VAL,
        ADDR.STATE
--        AD.CDF6_VAL
    
   UNION ALL
   /*Below block is for Misapplied - UHG*/
    SELECT
    ''Misapplied - UHG'' AS ADJUSTMENT_TYPE,
    PF.FREEZE_DT AS MAINTENANCE_PROCESS_DATE,
    PF.CDDGEN3_VAL AS TRANSACTION_NOTION,
    CASE
    WHEN
    CD.CDF3_VAL IS NULL
    THEN
    ''000000000-00''
    ELSE
    (CD.CDF3_VAL || ''-'' || CD.CDF12_VAL || CD.CDF5_VAL) 
    END AS MEMBER_NUMBER,
    CD.NAME AS MEMBER_NAME,
    NVL(PF.CDDGEN7_VAL,ADDR.STATE) AS STATE,
    NULL AS EMPLOYER_ID,
    SUM(PF.PAY_AMT)  AS ADJUSTMENT_AMOUNT,
    NULL as SRC_ADJ_ID -- To add same no of columns in all unions.SRC ADJ ID is required to exact number of transactions even with sametimestamp
    FROM
        IDENTIFIER(:V_PAYMENT_FACT) PF
        INNER JOIN IDENTIFIER(:V_CUSTOMER_DIM) CD ON PF.CUST_CURR_KEY = CD.CUST_CURR_KEY
                                                    AND CD.CURR_REC_FLAG = ''Y'' -- ''Y'' Fetch Always Latest Records 
                                                    AND CD.ID_TYPE_CD = ''INDID'' -- INDIVIDUAL INDENTIFIER
                                                    AND PF.FT_TYPE = ''Pay Cancellation''	
													AND PF.CDC_STATUS_FLAG<>''D''
        LEFT OUTER JOIN (
                                SELECT 
                                    AD.*,
                                    DENSE_RANK() OVER (ORDER BY AD.ADDRESS_TYPE_FLG ) AS ADDRESS_RANK
                                FROM
                                    IDENTIFIER(:V_ADDRESS_DIM) AD
                                WHERE AD.CURR_REC_FLAG=''Y''
                                    AND AD.EFFT_DT = (
                                                SELECT  
                                                MAX(A1.EFFT_DT) AS EFFT_DT
                                                FROM 
                                                IDENTIFIER(:V_ADDRESS_DIM) A1
                                                WHERE TRIM(A1.ENTITY_ID) = TRIM(AD.ENTITY_ID)
												AND A1.CURR_REC_FLAG=''Y''
                                                )
                                ) ADDR ON TRIM(ADDR.ENTITY_ID) = CD.SRC_CUST_ID
                                 AND ADDR.ENTITY_FLG = ''PERS'' -- PERSONS ADDRESS
                                 AND ADDR.ADDRESS_RANK = 1
                                 AND ADDR.INACTIVE_DTTM IS NULL 
         INNER JOIN IDENTIFIER(:V_REASON_DIM) RD ON RD.RSN_CURR_KEY = PF.RSN_CURR_KEY 
                                AND RD.CURR_REC_FLAG = ''Y'' -- ''Y'' Fetch Always Latest Records 
                                AND RD.SRC_RSN_CD NOT IN (''EEBK'',''BNKE'',''TPDP'') -- Exclusing Bank related Reason Codes
                                AND RD.UDF1_VAL = ''Y'' -- transfer Switch   
                                
             WHERE
             NOT EXISTS
            (SELECT 1 FROM IDENTIFIER(:V_ACCOUNT_DIM) AD WHERE AD.CDF6_VAL IN (''ICPDP'') AND AD.ACCT_CURR_KEY = PF.ACCT_CURR_KEY
            AND AD.CURR_REC_FLAG = ''Y'')                
           AND DATE(PF.FREEZE_DT) BETWEEN :gv_ReportStartDate AND :gv_ReportStopDate
    GROUP BY
        PF.FREEZE_DT,
        PF.CDDGEN3_VAL,
        CD.CDF3_VAL,
        CD.CDF5_VAL,
        CD.CDF12_VAL,
        CD.NAME,
        PF.CDDGEN7_VAL,
        ADDR.STATE
    
    )
    GROUP BY
    
        ADJUSTMENT_TYPE,
        MAINTENANCE_PROCESS_DATE,
        TRANSACTION_NOTION,
        MEMBER_NUMBER,
        MEMBER_NAME,
        STATE,
        EMPLOYER_ID,
        SRC_ADJ_ID
        
    HAVING 
        SUM(ADJUSTMENT_AMOUNT) <> ''0'';

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
		 
					
																				
																							
			   
																   
					   

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_pv_ReportResult)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

																			
						

										 

--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP5'';
V_STEP_NAME :=  ''CALL BDR_BI.SP_ISB_SF_LOG_INSERT_COMPLETE(:gv_Log_id)'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CALL BDR_BI.SP_ISB_SF_LOG_INSERT_COMPLETE(:gv_Log_id);
																				 
																									  
																												   

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0 ;
	
											  
											 
												   
	
																		  

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



let res_set RESULTSET;
let select_statement1 := ''SELECT * FROM pv_ReportResult'';
res_set := (EXECUTE IMMEDIATE :select_statement1);
RETURN TABLE(res_set);

EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);

gv_error_code := SQLERRM;
CALL BDR_BI.SP_ISB_SF_LOG_INSERT_ERROR(:gv_Log_id, :gv_error_code);

RAISE;

END;

';