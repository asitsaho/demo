CREATE OR REPLACE PROCEDURE BDR_BI.FN_ISB_SF_CHK_MBR_PLN_CD("P_MEMBERSHIP_NUMBER" NUMBER(38,0), "P_INSURED_CD" NUMBER(38,0), "DB_NAME" VARCHAR(16777216) DEFAULT '')
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '
begin
let v_count NUMBER := 0;
let v_plan_code_ind  VARCHAR(10);

LET V_APPLICATION VARCHAR :=  ''SRC_COMPAS_D.APPLICATION'';
LET  V_APPLICATION_INDIVIDUAL VARCHAR :=  ''SRC_COMPAS_D.APPLICATION_INDIVIDUAL'';

SELECT CASE WHEN v_count > 1  THEN  ''Y''
         ELSE NULL END AS v_plan_code_ind into :v_count
     FROM ( SELECT COUNT(*) AS v_count
    --INTO v_count
    FROM
      (SELECT MEMBERSHIP_NUMBER, PLAN_REQUEST_1
       FROM   IDENTIFIER(:V_APPLICATION) a JOIN IDENTIFIER(:V_APPLICATION_INDIVIDUAL) ai ON (a.application_id = ai.application_id)
       WHERE  MEMBERSHIP_NUMBER = lpad(:p_membership_number,9,0,9,0)
         AND  a.INSURED_CD = :p_insured_cd
         AND  a.ADJUDICATION_CD = ''A''
         AND  (datediff("day",current_date,ai.DATE_OF_BIRTH))/365 >= 65
       GROUP BY MEMBERSHIP_NUMBER,PLAN_REQUEST_1) AP);


       CASE WHEN v_count > 1 THEN 
            select ''Y'' into :v_plan_code_ind;
       ELSE   
            select NULL into :v_plan_code_ind;
    END CASE;
    update  application_data123 set V_PLAN_CODE_IND1 = :v_plan_code_ind where MEMBERSHIP_NUMBER =  :P_MEMBERSHIP_NUMBER and INSURED_CD = :P_INSURED_CD;
    RETURN :v_plan_code_ind;

EXCEPTION
  WHEN OTHER THEN
    select ''N'' into :v_plan_code_ind;
    update  application_data123 set V_PLAN_CODE_IND1 = :v_plan_code_ind where MEMBERSHIP_NUMBER =  :P_MEMBERSHIP_NUMBER and INSURED_CD = :P_INSURED_CD;

    RETURN :v_plan_code_ind;
end;
';