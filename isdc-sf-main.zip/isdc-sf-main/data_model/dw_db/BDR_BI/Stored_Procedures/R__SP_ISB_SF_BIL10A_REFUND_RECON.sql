USE SCHEMA BDR_BI; CREATE OR REPLACE PROCEDURE "SP_ISB_SF_BIL10A_REFUND_RECON"("PV_REPORTSTARTDATE" DATE, "PV_REPORTSTOPDATE" DATE, "DB_NAME" VARCHAR(16777216) DEFAULT 'UBLIA_TST_ISDC_DEV_DB', "WH" VARCHAR(16777216) DEFAULT 'UBLIA_TST_ETL_XS_WH', "TGT_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "TGT2_SC" VARCHAR(16777216) DEFAULT '', "SRC_SC" VARCHAR(16777216) DEFAULT 'SRC_DWADM', "SRC2_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "UTIL_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "PIPELINE_ID" VARCHAR(16777216) DEFAULT '', "PIPELINE_NAME" VARCHAR(16777216) DEFAULT 'SP_ISB_SF_BIL10A_REFUND_RECON')
RETURNS TABLE ()
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

  gv_ReportStartDate                DATE := DATE(pv_ReportStartDate);
  gv_ReportStopDate                 DATE := DATE(pv_ReportStopDate);
  gv_Log_id                         NUMBER;
  gv_error_code                     varchar(200);




V_START_TIME TIMESTAMP;

V_STEP VARCHAR;
V_LAST_QUERY_ID    VARCHAR;
V_ROWS_LOADED   VARCHAR;
V_PROCESS_NAME   VARCHAR DEFAULT ''SP_ISB_SF_BIL10A_REFUND_RECON'';
V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''SP_ISB_SF_BIL10A_REFUND_RECON'';
V_STEP_NAME        VARCHAR;
V_ROWS_PARSED      INTEGER;
V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := COALESCE(:UTIL_SC, ''BDR_BI'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';
BEGIN
----RQ_DETL
----RQ_DETL
LET V_RQ_DETL VARCHAR :=  :TGT_SC || ''.RQ_DETL'';

----REQUEST_DETL
----REQUEST_DETL
LET V_REQUEST_DETL VARCHAR :=  :TGT_SC || ''.REQUEST_DETL'';

----DWADM.ADJUSTMENT_FACT
----SRC_DWADM.ADJUSTMENT_FACT
LET V_ADJUSTMENT_FACT VARCHAR :=  :SRC_SC || ''.ADJUSTMENT_FACT'';

----DWADM.PAYMENT_TENDERS_FACT
----SRC_DWADM.PAYMENT_TENDERS_FACT
LET V_PAYMENT_TENDERS_FACT VARCHAR :=  :SRC_SC || ''.PAYMENT_TENDERS_FACT'';

----DWADM.CUSTOMER_DIM
----SRC_DWADM.CUSTOMER_DIM
LET V_CUSTOMER_DIM VARCHAR :=  :SRC_SC || ''.CUSTOMER_DIM'';

----DWADM.PAYMENT_FACT
----SRC_DWADM.PAYMENT_FACT
LET V_PAYMENT_FACT VARCHAR :=  :SRC_SC || ''.PAYMENT_FACT'';

----DWADM.CI_PER_NAME_VW
----BDR_BI.CI_PER_NAME_VW
LET V_CI_PER_NAME_VW VARCHAR :=  :SRC2_SC || ''.CI_PER_NAME_VW'';

----THE
----THE
LET V_THE VARCHAR :=  :TGT_SC || ''.THE'';

----DWADM.C1_REF_WO_REQ_CHAR
----SRC_SRC_DWADM.C1_REF_WO_REQ_CHAR
LET V_C1_REF_WO_REQ_CHAR VARCHAR :=  :SRC_SC || ''.C1_REF_WO_REQ_CHAR'';

----DWADM.TNDR_SRC_DIM
----SRC_DWADM.TNDR_SRC_DIM
LET V_TNDR_SRC_DIM VARCHAR :=  :SRC_SC || ''.TNDR_SRC_DIM'';

----DWADM.C1_REF_WO_REQ_LOG
----SRC_SRC_DWADM.C1_REF_WO_REQ_LOG
LET V_C1_REF_WO_REQ_LOG VARCHAR :=  :SRC_SC || ''.C1_REF_WO_REQ_LOG'';

----DWADM.C1_REF_WO_REQ
----SRC_DWADM.C1_REF_WO_REQ
LET V_C1_REF_WO_REQ VARCHAR :=  :SRC_SC || ''.C1_REF_WO_REQ'';

----DWADM.CI_ACCT_APAY
----SRC_DWADM.CI_ACCT_APAY
LET V_CI_ACCT_APAY VARCHAR :=  :SRC_SC || ''.CI_ACCT_APAY'';

----HOUSEHOLD
----HOUSEHOLD
LET V_HOUSEHOLD VARCHAR :=  :TGT_SC || ''.HOUSEHOLD'';

----PV_REPORTRESULT
----PV_REPORTRESULT
LET V_PV_REPORTRESULT VARCHAR :=  :TGT_SC || ''.PV_REPORTRESULT'';

----DWADM.ACCOUNT_DIM
----SRC_DWADM.ACCOUNT_DIM
LET V_ACCOUNT_DIM VARCHAR :=  :SRC_SC || ''.ACCOUNT_DIM'';

----DWADM.C1_REF_WO_REQ_DTLS
----SRC_SRC_DWADM.C1_REF_WO_REQ_DTLS
LET V_C1_REF_WO_REQ_DTLS VARCHAR :=  :SRC_SC || ''.C1_REF_WO_REQ_DTLS'';




--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP1'';
V_STEP_NAME :=  ''call BDR_BI.FN_ISB_SF_GET_LOG_ID()'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

call BDR_BI.FN_ISB_SF_GET_LOG_ID()
    into :gv_Log_id;

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0 ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP2'';
V_STEP_NAME :=  ''CALL BDR_BI.SP_ISB_SF_INSERT_JOB_LOG()'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CALL BDR_BI.SP_ISB_SF_INSERT_JOB_LOG(:gv_Log_id,''BI.PKG_ISB_BILL_REPORTS.SP_ISB_Refund_Recon'',''BIL0010A_ISB_Refund_Recon'');

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0 ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP3'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE RQ_DETL'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE  IDENTIFIER(:V_RQ_DETL) AS
    (
        SELECT
            REF_WO_REQ_ID,
            CUSTOMER_NAME,
            ADJ_ID, 
            FREEZE_DT, 
            FT_TYPE, 
            SRC_ADJ_ID, 
            ADJ_AMT,  
            ENTITY_ID,
            ACCT_ID,
            BUS_OBJ_CD,
            STATUS,
            MAX(SENT_DT) AS SENT_DT,
            MAX(CHEK_NBR) AS CHEK_NBR,
            CRE_DTTM,
            ENTITY_TYPE
        FROM
            (
                SELECT DISTINCT 
                        REQ.REF_WO_REQ_ID,
                        REQ.CUSTOMER_NAME,
                        DTL.ADJ_ID, 
                        DATE(AD.FREEZE_DT) AS FREEZE_DT, 
                        AD.FT_TYPE, 
                        AD.SRC_ADJ_ID, 
                        AD.ADJ_AMT, 
                        RWC.CHAR_TYPE_CD, 
                        TRIM(DTL.ENTITY_ID) AS ENTITY_ID,
                        REQ.ACCT_ID,
                        REQ.BUS_OBJ_CD,
                        CASE 
                            WHEN 
                                AD.FT_TYPE=''Adjustment'' 
                            THEN 
                                ''PROCESSED'' 
                            ELSE 
                                ''VOID'' 
                        END AS STATUS,
                        CASE 
                            WHEN
                                RWC.CHAR_TYPE_CD = ''CM-SNTDT''
                            THEN 
                                TO_CHAR(TO_DATE(RWC.SRCH_CHAR_VAL),''MM/DD/YYYY'') 
                        END AS SENT_DT,
                        CASE WHEN
                                RWC.CHAR_TYPE_CD = ''CMCHKNUM''
                            THEN
                                RWC.SRCH_CHAR_VAL 
                        END AS CHEK_NBR,
                        REQ.CRE_DTTM,
                        DTL.ENTITY_TYPE
                FROM 
                    IDENTIFIER(:V_C1_REF_WO_REQ) REQ
                    INNER JOIN IDENTIFIER(:V_C1_REF_WO_REQ_DTLS) DTL ON REQ.REF_WO_REQ_ID = DTL.REF_WO_REQ_ID
                            AND REQ.CDC_FLAG <> ''D''
                            AND DTL.CDC_FLAG <> ''D''
                    INNER JOIN IDENTIFIER(:V_ADJUSTMENT_FACT) AD ON AD.SRC_ADJ_ID = DTL.ADJ_ID
                    LEFT JOIN IDENTIFIER(:V_C1_REF_WO_REQ_CHAR) RWC ON REQ.REF_WO_REQ_ID = RWC.REF_WO_REQ_ID AND RWC.CDC_FLAG <> ''D''
                            AND RWC.CHAR_TYPE_CD in (''CMCHKNUM'',''CM-SNTDT'')
                WHERE 
                             NOT EXISTS (SELECT 1 
                                            FROM 
                                                IDENTIFIER(:V_C1_REF_WO_REQ_LOG) REF1 
                                            WHERE 
                                                REF1.CHAR_TYPE_CD = ''CMREFREQ''
                                                AND trim(REF1.CHAR_VAL_FK1) =REQ.REF_WO_REQ_ID 
                                                AND REQ.BO_STATUS_CD=''PROCESSED''
                                            )
            
            UNION ALL                                                
                                                            
                SELECT DISTINCT 
                        REQ.REF_WO_REQ_ID, 
                        REQ.CUSTOMER_NAME,
                        DTL.ADJ_ID, 
                        AD.FREEZE_DT, 
                        AD.FT_TYPE, 
                        AD.SRC_ADJ_ID, 
                        AD.ADJ_AMT, 
                        RWC.CHAR_TYPE_CD, 
                        TRIM(DTL.ENTITY_ID) AS ENTITY_ID,
                        REQ.ACCT_ID,
                        REQ.BUS_OBJ_CD,
                        ''REISSUE'' AS STATUS,
                        CASE 
                            WHEN
                                RWC.CHAR_TYPE_CD = ''CM-SNTDT''
                            THEN 
                                TO_CHAR(TRY_TO_DATE(RWC.SRCH_CHAR_VAL),''MM/DD/YYYY'') 
                        END AS SENT_DT,
                        CASE 
                            WHEN
                                RWC.CHAR_TYPE_CD = ''CMCHKNUM''
                            THEN 
                                RWC.SRCH_CHAR_VAL 
                        END AS CHEK_NBR,
                        REQ.CRE_DTTM,
                        DTL.ENTITY_TYPE
                FROM 
                    IDENTIFIER(:V_C1_REF_WO_REQ) REQ
                    INNER JOIN IDENTIFIER(:V_C1_REF_WO_REQ_DTLS) DTL ON REQ.REF_WO_REQ_ID = DTL.REF_WO_REQ_ID
                            AND REQ.CDC_FLAG <> ''D''
                            AND DTL.CDC_FLAG <> ''D''
                    INNER JOIN IDENTIFIER(:V_ADJUSTMENT_FACT) AD ON AD.SRC_ADJ_ID = DTL.ADJ_ID
                    LEFT JOIN IDENTIFIER(:V_C1_REF_WO_REQ_CHAR) RWC ON REQ.REF_WO_REQ_ID = RWC.REF_WO_REQ_ID 
                            AND RWC.CDC_FLAG <> ''D''
                            AND RWC.CHAR_TYPE_CD in (''CMCHKNUM'',''CM-SNTDT'')
                WHERE 
                     EXISTS (SELECT 1 
                                FROM 
                                    IDENTIFIER(:V_C1_REF_WO_REQ_LOG) REF1 
                                WHERE REF1.CHAR_TYPE_CD = ''CMREFREQ''
                                AND trim(REF1.CHAR_VAL_FK1) =REQ.REF_WO_REQ_ID 
                                AND REQ.BO_STATUS_CD=''PROCESSED''
                                )
            )
        GROUP BY
            REF_WO_REQ_ID,
            CUSTOMER_NAME,
            ADJ_ID, 
            FREEZE_DT, 
            FT_TYPE, 
            SRC_ADJ_ID, 
            ADJ_AMT,  
            ENTITY_ID,
            ACCT_ID,
            BUS_OBJ_CD,
            STATUS,
            CRE_DTTM,
            ENTITY_TYPE
    );

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_RQ_DETL)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP4'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE REQUEST_DETL'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_REQUEST_DETL) AS 
    (
        SELECT * FROM
            (
                SELECT DISTINCT
                            RW.ACCT_ID,
                            RW.CUSTOMER_NAME,
                            RW.REF_WO_REQ_ID,
                            RW.BUS_OBJ_CD,
                            RW.STATUS,
                            RW.ADJ_AMT,
                            AA.EXT_ACCT_ID AS "Bank_Account_#",
                            SUBSTR(AA.APAY_SRC_CD,1,9)AS "Bank_Routing_#",ADJ_ID,
                            CASE WHEN
                                    RW.STATUS <> ''VOID''
                                THEN 
                                    RW.SENT_DT        
                                END AS SENT_DATE,
                            RW.CHEK_NBR,
                            RW.FREEZE_DT,
                            CASE WHEN
                                    RW.STATUS = ''VOID''
                                THEN 
                                    DATE(RW.FREEZE_DT)        
                                END AS APPLIED_DATE,
                            TRIM(RW.ENTITY_ID) AS ENTITY_ID,
			    RW.ENTITY_TYPE		
                        FROM
                            IDENTIFIER(:V_RQ_DETL) RW
                            LEFT JOIN IDENTIFIER(:V_CI_ACCT_APAY) AA ON AA.ACCT_ID = RW.ACCT_ID
                                AND DATE(RW.CRE_DTTM) >= AA.START_DT AND (DATE(RW.CRE_DTTM) <= AA.END_DT OR AA.END_DT IS NULL)
                                AND AA.APAY_RTE_TYPE_CD <> ''PEN-FRS''
                                AND AA.CDC_FLAG <> ''D'' 
                        WHERE            
                                (RW.STATUS IN (''REISSUE'',''PROCESSED'',''VOID'') AND
                                RW.BUS_OBJ_CD IN (''CM-RefundReq'')
                                OR
                                RW.STATUS IN (''PROCESSED'',''VOID'') AND
                                RW.BUS_OBJ_CD IN (''CM-ACHRefundRequest''))-- CM-ACH(EFT) AND CM-REF (CHECK)
            )
            WHERE
                (TO_DATE(TO_CHAR(TO_DATE(SENT_DATE ,''MM/DD/YYYY''),''DD/MON/YYYY''),''DD/MON/YYYY'') BETWEEN :gv_ReportStartDate AND :gv_ReportStopDate
                                OR
                APPLIED_DATE BETWEEN :gv_ReportStartDate AND :gv_ReportStopDate)
    );

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_REQUEST_DETL)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP5'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE pv_ReportResult'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE pv_ReportResult as
    SELECT 
        Refund_Type,
        TType,
        Refund_Status,
        CASE
            WHEN
                Membership_Number = ''000000000-00''
            THEN
                PAY_MEMBER_NUMBER
            ELSE
                Membership_Number
        END AS Membership_Number,
        CASE 
            WHEN Refund_Status IN (''PROCESSED'',''REISSUE'')
            THEN Sent_Date
        END AS Sent_Date,
        Payee_Full_Name,
        CASE 
            WHEN Refund_Status IN (''VOID'')
            THEN Applied_Date
        END AS Applied_Date,
        CREATION_DATE ,
        Processing_Site_ID,
        "Refund_Check_#",
        Batch_Number,
        Employer_ID,
        "Item_SEQ_#",
        "Bank_Account_#",
        "Bank_Routing_#",
        ''1'' AS REF_COUNT,
        Refund_Amount,
        CURRENT_TIMESTAMP() AS RUN_DATE,
        :gv_ReportStartDate AS START_DATE,
        :gv_ReportStopDate AS END_DATE
    FROM
        (
            SELECT 
                CASE
                    WHEN
                    RQ_DETL.BUS_OBJ_CD LIKE ''%CM-Ref%''
                    THEN
                    ''CHECK''
                    WHEN
                    RQ_DETL.BUS_OBJ_CD LIKE ''%CM-ACH%''
                    THEN
                    ''EFT''
                END AS Refund_Type,
                CASE
                    WHEN
                    RQ_DETL.BUS_OBJ_CD LIKE ''%CM-Ref%''
                    THEN
                    ''CHECK (Less Void)''
                    WHEN
                    RQ_DETL.BUS_OBJ_CD LIKE ''%CM-ACH%''
                    THEN
                    ''EFT (Less Reapplied)''
                END AS TType,
                RQ_DETL.STATUS AS Refund_Status,
                NVL(CD.CDF3_VAL,''000000000'') || ''-'' || NVL(CD.CDF12_VAL,''0'') || NVL(CD.CDF5_VAL,''0'') AS Membership_Number,
                PF.CDDGEN4_VAL AS PAY_MEMBER_NUMBER,
                RQ_DETL.Sent_Date,
                RQ_DETL.CUSTOMER_NAME AS Payee_Full_Name,
                DECODE(CD.ID_TYPE_CD,''INDID'',PR.NAME,CD.NAME) AS Payee_Full_Name1,
                TO_CHAR(RQ_DETL.APPLIED_DATE,''MM/DD/YYYY'') AS APPLIED_DATE,
                DATE(RQ_DETL.FREEZE_DT) AS CREATION_DATE,
                CASE
                WHEN TSD.SRC_TNDR_SOURCE_CD = ''JPMTPP''
                THEN ''1''
                WHEN TSD.SRC_TNDR_SOURCE_CD = ''ENROLL''
                THEN ''2''
                WHEN TSD.SRC_TNDR_SOURCE_CD = ''BNYLBXPB''
                THEN ''7''
                WHEN TSD.SRC_TNDR_SOURCE_CD = ''BNYLBXDL''
                THEN ''8''
                END  AS Processing_Site_ID,
                RQ_DETL.CHEK_NBR AS "Refund_Check_#",
                SUBSTR(PTF.SRC_EXT_REFERENCE_ID,-9,6) AS Batch_Number,
                DECODE(CD.ID_TYPE_CD,''EMPID'',CD.ID_VAL,EMP.EMPLOYER_ID) AS Employer_ID,
                SUBSTR(PTF.SRC_EXT_REFERENCE_ID,-3) AS "Item_SEQ_#",
                RQ_DETL."Bank_Account_#",
                RQ_DETL."Bank_Routing_#",
                SUM(RQ_DETL.ADJ_AMT) AS Refund_Amount
            FROM
                IDENTIFIER(:V_REQUEST_DETL) RQ_DETL 
                LEFT JOIN IDENTIFIER(:V_PAYMENT_FACT) PF ON PF.SRC_PAY_ID = RQ_DETL.ENTITY_ID AND PF.FT_TYPE = ''Pay Segment'' AND RQ_DETL.ENTITY_TYPE IN (''PYID'',''PEID'')
                LEFT JOIN IDENTIFIER(:V_PAYMENT_TENDERS_FACT) PTF ON PTF.SRC_PAY_TNDR_ID = PF.SRC_PAY_TNDR_ID
                                AND PF.CDC_STATUS_FLAG <> ''D''
                                AND PTF.CDC_STATUS_FLAG <> ''D''
                LEFT JOIN IDENTIFIER(:V_TNDR_SRC_DIM) TSD ON TSD.TNDR_SRC_CURR_KEY = PTF.TNDR_SRC_CURR_KEY 
                                AND TSD.CURR_REC_FLAG = ''Y''
                INNER JOIN IDENTIFIER(:V_ACCOUNT_DIM) AD ON  RQ_DETL.ACCT_ID = AD.SRC_ACCT_ID
                --            AND CD.ID_TYPE_CD = ''INDID''  -- INDIVIDUAL IDENTIFIER
                        AND AD.CURR_REC_FLAG = ''Y''-- ''Y'' Fetch Always Latest Records
                INNER JOIN IDENTIFIER(:V_CUSTOMER_DIM) CD ON AD.CUST_ID = CD.SRC_CUST_ID
                            AND CD.CURR_REC_FLAG = ''Y''      
                LEFT JOIN (
                            SELECT
                        PER_ID, (MAX(LNAME) ||'' ''|| MAX(SUFX) || '' ''|| MAX(FRNM) || '' '' || MAX(MDLN) ) NAME
                        FROM
                        (
                        SELECT
                        PER_ID,
                        CASE WHEN PN.NAME_TYPE_FLG = ''LSNM''
                             THEN PN.ENTITY_NAME END AS LNAME,
                        CASE WHEN PN.NAME_TYPE_FLG = ''FRNM''
                             THEN PN.ENTITY_NAME END AS FRNM,
                        CASE WHEN PN.NAME_TYPE_FLG = ''MDLN''
                             THEN PN.ENTITY_NAME END AS MDLN,
                        CASE WHEN PN.NAME_TYPE_FLG = ''SUFX''
                             THEN PN.ENTITY_NAME END AS SUFX      
                        FROM IDENTIFIER(:V_CI_PER_NAME_VW) PN           
                        )
                        GROUP BY
                        PER_ID
                    ) PR ON PR.PER_ID = CD.SRC_CUST_ID
                LEFT JOIN (
                                SELECT
                                CUSTOMER_EMP.ID_VAL AS EMPLOYER_ID,
                                CUSTOMER_EMP.SRC_CUST_ID
                                FROM
                                IDENTIFIER(:V_CUSTOMER_DIM) CUSTOMER_EMP
                                WHERE CUSTOMER_EMP.CUST_TYPE = ''Parent Customer'' 
                                    AND CUSTOMER_EMP.CURR_REC_FLAG=''Y'' -- ''Y'' Fetch Always Latest Records 
                                    AND CUSTOMER_EMP.ID_TYPE_CD = ''EMPID'' 
                                    -- EMPLOYER IDENTIFIER
                                ) EMP ON CD.PARENT_CUST_ID = EMP.SRC_CUST_ID 
            WHERE
                RQ_DETL.STATUS IN (''REISSUE'',''PROCESSED'',''VOID'')
                AND ((RQ_DETL.STATUS IN (''REISSUE'',''PROCESSED'') AND RQ_DETL.SENT_DATE IS NOT NULL) OR RQ_DETL.STATUS IN (''VOID''))
            GROUP BY  
                    RQ_DETL.BUS_OBJ_CD ,
                    RQ_DETL.STATUS,
                    CD.CDF3_VAL,
                    CD.CDF5_VAL,
                    CD.CDF12_VAL,
                    CD.ID_TYPE_CD,
                    PR.NAME,CD.NAME,
                    PF.CDDGEN4_VAL,
                    CD.ID_VAL,
                    RQ_DETL.CUSTOMER_NAME,
                    RQ_DETL.SENT_DATE,
                    RQ_DETL.CHEK_NBR,
                    EMP.EMPLOYER_ID,
                    RQ_DETL.APPLIED_DATE,
                    RQ_DETL."Bank_Account_#",
                    RQ_DETL."Bank_Routing_#",
                    PTF.SRC_EXT_REFERENCE_ID,
                    TSD.SRC_TNDR_SOURCE_CD,
                    RQ_DETL.FREEZE_DT
            HAVING 
                    SUM(RQ_DETL.ADJ_AMT) <> 0
        );

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_pv_ReportResult)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP6'';
V_STEP_NAME :=  ''CALL BDR_BI.SP_ISB_SF_LOG_INSERT_COMPLETE(:gv_Log_id)'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CALL BDR_BI.SP_ISB_SF_LOG_INSERT_COMPLETE(:gv_Log_id);

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0 ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



let res_set RESULTSET;
let select_statement1 := ''SELECT * FROM pv_ReportResult'';
res_set := (EXECUTE IMMEDIATE :select_statement1);
RETURN TABLE(res_set);

EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);

gv_error_code := SQLERRM;
CALL BDR_BI.SP_ISB_SF_LOG_INSERT_ERROR(:gv_Log_id, :gv_error_code);

RAISE;

END;

';