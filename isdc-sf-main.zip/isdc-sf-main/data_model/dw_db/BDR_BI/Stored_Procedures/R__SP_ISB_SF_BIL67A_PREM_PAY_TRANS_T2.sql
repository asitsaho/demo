CREATE OR REPLACE PROCEDURE BDR_BI.SP_ISB_SF_BIL67A_PREM_PAY_TRANS_T2("PV_REPORTSTARTDATE" DATE, "PV_REPORTSTOPDATE" DATE, "DB_NAME" VARCHAR(16777216) DEFAULT '', "TGT_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "TGT2_SC" VARCHAR(16777216) DEFAULT '', "SRC_SC" VARCHAR(16777216) DEFAULT 'SRC_DWADM', "SRC2_SC" VARCHAR(16777216) DEFAULT 'SRC_COMPAS_D', "SRC3_SC" VARCHAR(16777216) DEFAULT 'SRC_DWADM', "UTIL_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "PIPELINE_ID" VARCHAR(16777216) DEFAULT '', "PIPELINE_NAME" VARCHAR(16777216) DEFAULT 'SP_ISB_SF_BIL67A_PREM_PAY_TRANS_T2')
RETURNS TABLE ()
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

  gv_ReportStartDate                DATE := DATE(pv_ReportStartDate);
  gv_ReportStopDate                 DATE := DATE(pv_ReportStopDate);
  gv_Log_id                         NUMBER;
  gv_error_code                     varchar(200);



V_START_TIME TIMESTAMP;

V_STEP VARCHAR;
V_LAST_QUERY_ID    VARCHAR;
V_ROWS_LOADED   VARCHAR;
V_PROCESS_NAME   VARCHAR DEFAULT ''SP_ISB_SF_BIL67A_PREM_PAY_TRANS_T2'';
V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''SP_ISB_SF_BIL67A_PREM_PAY_TRANS_T2'';
V_STEP_NAME        VARCHAR;
V_ROWS_PARSED      INTEGER;
V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := COALESCE(:UTIL_SC, ''BDR_BI'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';
BEGIN
----COMPAS.FULFILLMENT_REQUEST
----SRC_COMPAS_D.V_TT_FULFILLMENT_REQUEST
LET V_FULFILLMENT_REQUEST VARCHAR :=  :SRC2_SC || ''.FULFILLMENT_REQUEST'';

----DWADM.CUSTOMER_DIM
----SRC_DWADM.CUSTOMER_DIM
LET V_CUSTOMER_DIM VARCHAR :=  :SRC_SC || ''.CUSTOMER_DIM'';

----MAIN_PAPER
----MAIN_PAPER
LET V_MAIN_PAPER VARCHAR :=  :TGT_SC || ''.MAIN_PAPER'';

----COMPAS.FULFILLMENT_REQUEST_HIST
----SRC_COMPAS_D.V_TT_FULFILLMENT_REQUEST_HIST
LET V_FULFILLMENT_REQUEST_HIST VARCHAR :=  :SRC2_SC || ''.FULFILLMENT_REQUEST_HIST'';

----DWADM.CI_ACCT_APAY_VW
----SRC_BDR_BI.CI_ACCT_APAY_VW
LET V_CI_ACCT_APAY_VW VARCHAR :=  :SRC3_SC || ''.CI_ACCT_APAY_VW'';

----DWADM.ACCOUNT_DIM
----SRC_DWADM.ACCOUNT_DIM
LET V_ACCOUNT_DIM VARCHAR :=  :SRC_SC || ''.ACCOUNT_DIM'';

----MAIN_DTL_PAPER
----MAIN_DTL_PAPER
LET V_MAIN_DTL_PAPER VARCHAR :=  :TGT_SC || ''.MAIN_DTL_PAPER'';

----COMPAS.HOUSEHOLD_PROFILE
----SRC_COMPAS_D.V_TT_HOUSEHOLD_PROFILE
LET V_HOUSEHOLD_PROFILE VARCHAR :=  :SRC2_SC || ''.HOUSEHOLD_PROFILE'';

----PV_REPORTRESULT
----PV_REPORTRESULT
LET V_PV_REPORTRESULT VARCHAR :=  :TGT_SC || ''.PV_REPORTRESULT'';

----CI_ACCT_APAY_VW1
----CI_ACCT_APAY_VW1
LET V_CI_ACCT_APAY_VW1 VARCHAR :=  :TGT_SC || ''.CI_ACCT_APAY_VW1'';




--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP1'';
V_STEP_NAME :=  ''call BDR_BI.FN_ISB_SF_GET_LOG_ID()'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

call BDR_BI.FN_ISB_SF_GET_LOG_ID()
    into :gv_Log_id;

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0 ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP2'';
V_STEP_NAME :=  ''CALL BDR_BI.SP_ISB_SF_INSERT_JOB_LOG()'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CALL BDR_BI.SP_ISB_SF_INSERT_JOB_LOG(:gv_Log_id,''BI.PKG_ISB_BILL_REPORTS.SP_ISB_SHIP_Premium_Payment_Transactions_T2'',''BIL0067A_ISB_ SHIP Premium Payment Transactions TAB2'');

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP3'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE CI_ACCT_APAY_VW1'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_CI_ACCT_APAY_VW1) AS 
    (
     SELECT 
        ACCT_ID,
        AUTH_IMAGE_NUMBER,
        SETUP_DT,
        MON_SETUP_DT,
        END_DT,
        CURRENT_YEAR
    FROM (
            SELECT 
                AAV.ACCT_ID,
                AAV.AUTH_IMAGE_NUMBER,
                DATE(AAV.SETUP_DT) AS SETUP_DT,
                TO_DATE(TO_CHAR(AAV.SETUP_DT,''MON/YYYY''),''MON/YYYY'') AS MON_SETUP_DT,
                DATE(AAV.END_DT) AS END_DT,
                to_char(add_months(AAV.SETUP_DT,-0),''yyyy'') AS CURRENT_YEAR,
                CASE 
                    WHEN AAV.AUTH_IMAGE_NUMBER NOT LIKE ''%N''			
                        AND AAV.AUTH_IMAGE_NUMBER NOT LIKE ''%WB%''				
                        AND AAV.AUTH_IMAGE_NUMBER NOT LIKE ''%MEMBER_WEB''				
                        AND AAV.AUTH_IMAGE_NUMBER NOT LIKE ''%SIEBEL''				
                        AND AAV.AUTH_IMAGE_NUMBER NOT LIKE ''%POS''
                    THEN 1
                    ELSE 0
                END AS CNT
            FROM
                IDENTIFIER(:V_CI_ACCT_APAY_VW) AAV
             WHERE 
                AAV.AUTH_CHANNEL_TYPE_ID IN (''1'',''3'',''5'')
                AND to_char(add_months(AAV.SETUP_DT,-0),''yyyy'') BETWEEN TO_CHAR(ADD_MONTHS(:gv_ReportStartDate,-12),''yyyy'') AND TO_CHAR(:gv_ReportStopDate,''YYYY'')
            ) 
        WHERE CNT = 1
    );

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_CI_ACCT_APAY_VW1)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP4'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE MAIN_DTL_PAPER'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_MAIN_DTL_PAPER) AS
(
    SELECT   
            AAV.ACCT_ID,
            TO_CHAR( :gv_ReportStartDate ,''MON'') AS MON,
            AAV.SETUP_DT,
            AAV.MON_SETUP_DT,
            AAV.END_DT,
            AAV.CURRENT_YEAR,
             ''EFT paper forms received and processed''  as "EFT_Paper_Forms"
     FROM
        IDENTIFIER(:V_CI_ACCT_APAY_VW1) AAV 
        INNER JOIN IDENTIFIER(:V_ACCOUNT_DIM) AD ON AAV.ACCT_ID = AD.SRC_ACCT_ID 
                            AND AD.CURR_REC_FLAG = ''Y''                             
        INNER JOIN IDENTIFIER(:V_CUSTOMER_DIM) CD ON CD.SRC_CUST_ID = AD.CUST_ID 
                            AND CD.CURR_REC_FLAG = ''Y''
        INNER JOIN IDENTIFIER(:V_HOUSEHOLD_PROFILE) HP ON HP.HOUSEHOLD_ID = CD.CDF4_VAL
                            AND HP.DELETE_IND <> ''Y''
                            AND :gv_ReportStartDate BETWEEN DATE(HP.HHOLD_PROFILE_START_DATE) AND DATE(HP.HHOLD_PROFILE_STOP_DATE)	

);

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_MAIN_DTL_PAPER)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP5'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE MAIN_PAPER'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_MAIN_PAPER) AS (
SELECT
"EFT Paper Forms",
YEAR,   
SUM(NVL("Current Month",0)) AS "Current Month",
SUM(NVL("QTR 1",0)) AS "QTR 1",
SUM(NVL("QTR 2",0)) AS "QTR 2",
SUM(NVL("QTR 3",0)) AS "QTR 3",
SUM(NVL("QTR 4",0)) AS "QTR 4",
SUM(NVL("YTD",0)) AS "YTD",
CURRENT_TIMESTAMP() AS RUN_DATE,
:gv_ReportStartDate AS START_DATE,
:gv_ReportStopDate as END_DATE
FROM
(
SELECT
    ''EFT paper forms received and processed'' AS  "EFT Paper Forms",
    ''Current Year:'' ||TO_CHAR(:gv_ReportStartDate,''YYYY'') AS YEAR,
    CASE
        WHEN
        to_char(SETUP_DT,''MON'') in (SELECT TO_CHAR( :gv_ReportStartDate ,''MON''))
        THEN COUNT("EFT_Paper_Forms")
    END AS "Current Month",
    CASE
        WHEN
        to_char(SETUP_DT,''Mon'') in (''Jan'',''Feb'',''Mar'') 
        THEN COUNT("EFT_Paper_Forms")
    END AS "QTR 1",
    CASE
        WHEN
       to_char(SETUP_DT,''Mon'') in (''Apr'',''May'',''Jun'') 
        THEN COUNT("EFT_Paper_Forms")
    END AS "QTR 2",
    CASE
        WHEN
       to_char(SETUP_DT,''Mon'') in (''Jul'',''Aug'',''Sep'') 
        THEN COUNT("EFT_Paper_Forms")
    END AS "QTR 3",
    CASE
        WHEN
       to_char(SETUP_DT,''Mon'') in (''Oct'',''Nov'',''Dec'') 
        THEN COUNT("EFT_Paper_Forms")
    END AS "QTR 4",
    CASE
        WHEN
       to_char(SETUP_DT,''YYYY'') =  TO_CHAR(:gv_ReportStartDate,''YYYY'') 
        THEN COUNT("EFT_Paper_Forms")
    END AS "YTD"
FROM
IDENTIFIER(:V_MAIN_DTL_PAPER)
WHERE 
to_char(add_months(SETUP_DT,-0),''yyyy'') = TO_CHAR(:gv_ReportStartDate,''YYYY'')
AND SETUP_DT <= :gv_ReportStopDate
GROUP BY
SETUP_DT,
END_DT

UNION ALL

SELECT
 ''EFT paper forms received and processed'' AS "EFT Paper Forms",
 ''Current Year:'' ||TO_CHAR(:gv_ReportStartDate,''YYYY'') AS YEAR,
 TO_NUMBER(''0'') AS "Current Month",
 TO_NUMBER(''0'') AS "QTR 1",
 TO_NUMBER(''0'') AS "QTR 2",
 TO_NUMBER(''0'') AS "QTR 3",
 TO_NUMBER(''0'') AS "QTR 4",
 TO_NUMBER(''0'') AS "YTD"

UNION ALL

SELECT
    ''EFT paper forms received and processed'' AS  "EFT Paper Forms",
    ''Previous Year:'' ||TO_CHAR(ADD_MONTHS(:gv_ReportStartDate,-12),''yyyy'') AS YEAR,
    CASE
        WHEN
        to_char(SETUP_DT,''MON'') in (SELECT TO_CHAR( :gv_ReportStartDate ,''MON''))
        THEN COUNT("EFT_Paper_Forms")
    END AS "Current Month",
    CASE
        WHEN
        to_char(SETUP_DT,''Mon'') in (''Jan'',''Feb'',''Mar'') 
        THEN COUNT("EFT_Paper_Forms")
    END AS "QTR 1",
    CASE
        WHEN
       to_char(SETUP_DT,''Mon'') in (''Apr'',''May'',''Jun'') 
        THEN COUNT("EFT_Paper_Forms")
    END AS "QTR 2",
    CASE
        WHEN
       to_char(SETUP_DT,''Mon'') in (''Jul'',''Aug'',''Sep'') 
        THEN COUNT("EFT_Paper_Forms")
    END AS "QTR 3",
    CASE
        WHEN
       to_char(SETUP_DT,''Mon'') in (''Oct'',''Nov'',''Dec'') 
        THEN COUNT("EFT_Paper_Forms")
    END AS "QTR 4",
    CASE
        WHEN
       to_char(SETUP_DT,''YYYY'') =  TO_CHAR(ADD_MONTHS(:gv_ReportStartDate,-12),''yyyy'')
        THEN COUNT("EFT_Paper_Forms")
    END AS "YTD"
FROM
IDENTIFIER(:V_MAIN_DTL_PAPER)
WHERE 
to_char(add_months(SETUP_DT,-0),''yyyy'') = TO_CHAR(ADD_MONTHS(:gv_ReportStartDate,-12),''yyyy'')
AND SETUP_DT <= ADD_MONTHS(:gv_ReportStopDate ,-12)
GROUP BY
SETUP_DT,
END_DT

UNION ALL

SELECT
 ''EFT paper forms received and processed'' AS "EFT Paper Forms",
 ''Previous Year:'' ||TO_CHAR(ADD_MONTHS(:gv_ReportStartDate,-12),''yyyy'') AS YEAR,
 TO_NUMBER(''0'') AS "Current Month",
 TO_NUMBER(''0'') AS "QTR 1",
 TO_NUMBER(''0'') AS "QTR 2",
 TO_NUMBER(''0'') AS "QTR 3",
 TO_NUMBER(''0'') AS "QTR 4",
 TO_NUMBER(''0'') AS "YTD"	

UNION ALL

SELECT
 ''EFT paper forms fulfilled by COMPAS (brochures sent)'' AS "EFT Paper Forms",
 ''Current Year:'' ||TO_CHAR(:gv_ReportStartDate,''YYYY'') AS YEAR,
 CASE 
    WHEN TO_CHAR(DATE(TAB.PROCESS_DATE),''Mon'') IN (SELECT TO_CHAR( :gv_ReportStartDate ,''MON''))
    THEN NVL(COUNT(*),0)
  END AS "Current Month",
  CASE 
    WHEN TO_CHAR(DATE(TAB.PROCESS_DATE),''Mon'')IN (''Jan'',''Feb'',''Mar'') 
    THEN NVL(COUNT(*),0)
  END AS "QTR 1",
  CASE 
    WHEN TO_CHAR(DATE(TAB.PROCESS_DATE),''Mon'')IN (''Apr'',''May'',''Jun'') 
    THEN NVL(COUNT(*),0)
  END AS "QTR 2",
  CASE 
    WHEN TO_CHAR(DATE(TAB.PROCESS_DATE),''Mon'')IN (''Jul'',''Aug'',''Sep'') 
    THEN NVL(COUNT(*),0)
  END AS "QTR 3",
  CASE 
    WHEN TO_CHAR(DATE(TAB.PROCESS_DATE),''Mon'')IN (''Oct'',''Nov'',''Dec'') 
    THEN NVL(COUNT(*),0)
  END AS "QTR 4",
  CASE 
    WHEN TO_CHAR(DATE(TAB.PROCESS_DATE),''YYYY'') = TO_CHAR(:gv_ReportStartDate,''YYYY'') 
    THEN NVL(COUNT(*),0)
  END AS "YTD"	
FROM (SELECT A.HOUSEHOLD_ID, A.PROCESS_DATE					
                  FROM IDENTIFIER(:V_FULFILLMENT_REQUEST) A,										
                       IDENTIFIER(:V_HOUSEHOLD_PROFILE) HP										
                 WHERE A.HOUSEHOLD_ID = HP.HOUSEHOLD_ID										
                   AND :gv_ReportStartDate BETWEEN DATE(HP.HHOLD_PROFILE_START_DATE) AND DATE(HP.HHOLD_PROFILE_STOP_DATE)									
                   AND HP.DELETE_IND = ''N''										
                   AND A.FULFILLMENT_TYPE_ID = 5--EFT Brochure										
                   AND A.REQUEST_STATUS_ID = 2										
                   AND DATE(A.PROCESS_DATE) BETWEEN ADD_MONTHS(:gv_ReportStartDate,-12) AND :gv_ReportStopDate										
                UNION ALL										
                SELECT A.HOUSEHOLD_ID, A.PROCESS_DATE										
                  FROM IDENTIFIER(:V_FULFILLMENT_REQUEST_HIST) A,										
                       IDENTIFIER(:V_HOUSEHOLD_PROFILE) HP										
                 WHERE A.HOUSEHOLD_ID = HP.HOUSEHOLD_ID										
                   AND :gv_ReportStartDate BETWEEN DATE(HP.HHOLD_PROFILE_START_DATE) AND DATE(HP.HHOLD_PROFILE_STOP_DATE)										
                   AND HP.DELETE_IND = ''N''										
                   AND A.FULFILLMENT_TYPE_ID = 5--EFT Brochure										
                   AND A.REQUEST_STATUS_ID = 2										
                   AND DATE(A.PROCESS_DATE) BETWEEN :gv_ReportStartDate AND :gv_ReportStopDate										
                   ) TAB
WHERE
to_char(add_months(TAB.PROCESS_DATE,-0),''yyyy'') = TO_CHAR(:gv_ReportStartDate,''YYYY'')
GROUP BY
TAB.PROCESS_DATE

UNION ALL

SELECT
''EFT paper forms fulfilled by COMPAS (brochures sent)'' AS "EFT Paper Forms",
 ''Current Year:'' ||TO_CHAR(:gv_ReportStartDate,''YYYY'') AS YEAR,
 TO_NUMBER(''0'') AS "Current Month",
 TO_NUMBER(''0'') AS "QTR 1",
 TO_NUMBER(''0'') AS "QTR 2",
 TO_NUMBER(''0'') AS "QTR 3",
 TO_NUMBER(''0'') AS "QTR 4",
 TO_NUMBER(''0'') AS "YTD"	


UNION ALL

SELECT
 ''EFT paper forms fulfilled by COMPAS (brochures sent)'' AS "EFT Paper Forms",
 ''Previous Year:'' ||TO_CHAR(ADD_MONTHS(:gv_ReportStartDate,-12),''yyyy'') AS YEAR,
 CASE 
    WHEN TO_CHAR(DATE(TAB.PROCESS_DATE),''Mon'') IN (SELECT TO_CHAR( :gv_ReportStartDate ,''MON'') )
    THEN NVL(COUNT(*),0)
  END AS "Current Month",
  CASE 
    WHEN TO_CHAR(DATE(TAB.PROCESS_DATE),''Mon'')IN (''Jan'',''Feb'',''Mar'') 
    THEN NVL(COUNT(*),0)
  END AS "QTR 1",
  CASE 
    WHEN TO_CHAR(DATE(TAB.PROCESS_DATE),''Mon'')IN (''Apr'',''May'',''Jun'') 
    THEN NVL(COUNT(*),0)
  END AS "QTR 2",
  CASE 
    WHEN TO_CHAR(DATE(TAB.PROCESS_DATE),''Mon'')IN (''Jul'',''Aug'',''Sep'') 
    THEN NVL(COUNT(*),0)
  END AS "QTR 3",
  CASE 
    WHEN TO_CHAR(DATE(TAB.PROCESS_DATE),''Mon'')IN (''Oct'',''Nov'',''Dec'') 
    THEN NVL(COUNT(*),0)
  END AS "QTR 4",
  CASE 
    WHEN TO_CHAR(DATE(TAB.PROCESS_DATE),''YYYY'') = TO_CHAR(ADD_MONTHS(:gv_ReportStartDate,-12),''yyyy'')
    THEN NVL(COUNT(*),0)
  END AS "YTD"	
FROM (SELECT A.HOUSEHOLD_ID, A.PROCESS_DATE					
                  FROM IDENTIFIER(:V_FULFILLMENT_REQUEST) A,										
                       IDENTIFIER(:V_HOUSEHOLD_PROFILE) HP										
                 WHERE A.HOUSEHOLD_ID = HP.HOUSEHOLD_ID										
                   AND :gv_ReportStartDate BETWEEN DATE(HP.HHOLD_PROFILE_START_DATE) AND DATE(HP.HHOLD_PROFILE_STOP_DATE)									
                   AND HP.DELETE_IND = ''N''										
                   AND A.FULFILLMENT_TYPE_ID = 5--EFT Brochure										
                   AND A.REQUEST_STATUS_ID = 2										
                   AND DATE(A.PROCESS_DATE) BETWEEN ADD_MONTHS(:gv_ReportStartDate,-12) AND :gv_ReportStopDate										
                UNION ALL										
                SELECT A.HOUSEHOLD_ID, A.PROCESS_DATE										
                  FROM IDENTIFIER(:V_FULFILLMENT_REQUEST_HIST) A,										
                       IDENTIFIER(:V_HOUSEHOLD_PROFILE) HP										
                 WHERE A.HOUSEHOLD_ID = HP.HOUSEHOLD_ID										
                   AND DATE(:gv_ReportStartDate+1) BETWEEN DATE(HP.HHOLD_PROFILE_START_DATE) AND DATE(HP.HHOLD_PROFILE_STOP_DATE)										
                   AND HP.DELETE_IND = ''N''										
                   AND A.FULFILLMENT_TYPE_ID = 5--EFT Brochure										
                   AND A.REQUEST_STATUS_ID = 2										
                   AND DATE(A.PROCESS_DATE) BETWEEN :gv_ReportStartDate AND :gv_ReportStopDate										
                   ) TAB
WHERE
to_char(add_months(TAB.PROCESS_DATE,-0),''yyyy'') = TO_CHAR(ADD_MONTHS(:gv_ReportStartDate,-12),''yyyy'')
GROUP BY
TAB.PROCESS_DATE

UNION ALL

SELECT
''EFT paper forms fulfilled by COMPAS (brochures sent)'' AS "EFT Paper Forms",
''Previous Year:'' ||TO_CHAR(ADD_MONTHS(:gv_ReportStartDate,-12),''yyyy'') AS YEAR,
 TO_NUMBER(''0'') AS "Current Month",
 TO_NUMBER(''0'') AS "QTR 1",
 TO_NUMBER(''0'') AS "QTR 2",
 TO_NUMBER(''0'') AS "QTR 3",
 TO_NUMBER(''0'') AS "QTR 4",
 TO_NUMBER(''0'') AS "YTD"	

)
GROUP BY
"EFT Paper Forms",
YEAR
);

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_MAIN_PAPER)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP6'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE pv_ReportResult'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_pv_ReportResult) as
SELECT
    "EFT Paper Forms", 
    YEAR,
    CASE
        WHEN EFT_MONTH = ''Current Month''
        THEN ''Current Month: ''|| TO_CHAR(:gv_ReportStartDate,''Mon'')
        ELSE EFT_MONTH
    END AS EFT_MONTH, 
    TOTAL_CNT, 
    CURRENT_TIMESTAMP() AS RUN_DATE,
    :gv_ReportStartDate AS START_DATE,
    :gv_ReportStopDate as END_DATE
    FROM
    (   SELECT 
            "EFT Paper Forms", YEAR,"Current Month", "QTR 1", "QTR 2", "QTR 3", "QTR 4", YTD 
        FROM 
            IDENTIFIER(:V_MAIN_PAPER))
    UNPIVOT 
        ( TOTAL_CNT FOR EFT_MONTH 
            IN ("Current Month","QTR 1", "QTR 2", "QTR 3", "QTR 4", YTD)) TAB2;

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_pv_ReportResult)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP7'';
V_STEP_NAME :=  ''CALL BDR_BI.SP_ISB_SF_LOG_INSERT_COMPLETE(:gv_Log_id)'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CALL BDR_BI.SP_ISB_SF_LOG_INSERT_COMPLETE(:gv_Log_id);

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0 ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);





let res_set RESULTSET;
let select_statement1 := ''SELECT * FROM pv_ReportResult'';
res_set := (EXECUTE IMMEDIATE :select_statement1);
RETURN TABLE(res_set);

EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);

gv_error_code := SQLERRM;
CALL BDR_BI.SP_ISB_SF_LOG_INSERT_ERROR(:gv_Log_id, :gv_error_code);

RAISE;

END;

';