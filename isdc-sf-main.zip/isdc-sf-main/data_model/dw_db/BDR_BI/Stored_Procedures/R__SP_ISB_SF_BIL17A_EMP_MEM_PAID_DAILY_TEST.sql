USE SCHEMA BDR_BI; CREATE OR REPLACE PROCEDURE "SP_ISB_SF_BIL17A_EMP_MEM_PAID_DAILY_TEST"("PV_REPORTDATE" DATE, "DB_NAME" VARCHAR(16777216) DEFAULT '', "TGT_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "TGT2_SC" VARCHAR(16777216) DEFAULT '', "SRC_SC" VARCHAR(16777216) DEFAULT 'SRC_DWADM', "SRC2_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "UTIL_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "PIPELINE_ID" VARCHAR(16777216) DEFAULT '', "PIPELINE_NAME" VARCHAR(16777216) DEFAULT 'SP_ISB_SF_BIL17A_EMP_MEM_PAID_DAILY')
RETURNS TABLE ()
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

    gv_ReportStartDate                DATE := DATE(pv_ReportDate);
    gv_ReportStopDate                 DATE := DATE(pv_ReportDate);
	 gv_ReportDate                 DATE := DATE(pv_ReportDate);
    gv_Log_id                          NUMBER;
    gv_error_code                     varchar(200);
    gv_day                             VARCHAR(10);


V_START_TIME TIMESTAMP;
V_STEP VARCHAR;
V_LAST_QUERY_ID    VARCHAR;
V_ROWS_LOADED   VARCHAR;
V_PROCESS_NAME   VARCHAR DEFAULT ''SP_ISB_SF_BIL17A_EMP_MEM_PAID_DAILY'';
V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''SP_ISB_SF_BIL17A_EMP_MEM_PAID_DAILY'';
V_STEP_NAME        VARCHAR;
V_ROWS_PARSED      INTEGER;
V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := COALESCE(:UTIL_SC, ''BDR_BI'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';


BEGIN
----DWADM.CUSTOMER_DIM
----SRC_DWADM.CUSTOMER_DIM
LET V_CUSTOMER_DIM VARCHAR:=  :SRC_SC || ''.CUSTOMER_DIM'';

----DWADM.FT_FACT
----SRC_DWADM.FT_FACT
LET V_FT_FACT VARCHAR:=  :SRC_SC || ''.FT_FACT'';

LET V_pv_ReportResult VARCHAR:=  :TGT_SC || ''.pv_ReportResult'';


SELECT UPPER(DAYNAME(:gv_reportstartdate)) INTO :gv_day;


gv_reportstopdate := :gv_reportstopdate -1; 

IF (gv_day = ''MON'')  
THEN gv_reportstartdate := :gv_reportstartdate -3; 
ELSE gv_reportstartdate := :gv_reportstartdate -1; 
END IF;

--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP7'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE pv_ReportResult'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE pv_ReportResult AS
    SELECT 
        CE.ID_VAL AS EMPLOYER_ID,
        CE.NAME AS EMPLOYER_NAME,
        SUM(NVL(FT.CUR_AMT,0)) AS ADJ_AMT,
        :gv_reportstartdate AS START_DATE,
        :gv_ReportStopDate AS END_DATE,
        :gv_ReportDate AS REPORT_RUN_DATE
    FROM
    IDENTIFIER(:V_FT_FACT) FT
    INNER JOIN IDENTIFIER(:V_CUSTOMER_DIM) CE ON
            CE.CUST_CURR_KEY = ft.CUST_CURR_KEY 
            AND CE.CURR_REC_FLAG=''Y'' -- Current Record
            AND CE.ID_TYPE_CD = ''EMPID'' -- Individual Indemtifier
            AND FT.SRC_PARENT_ID = ''CMAARPAD'' -- Membership Fee Paid by Employer
            AND FT.MEVT_STATUS_FLG = ''B'' -- Balnced Flag means full Payment has been done 
            AND FT.CDC_STATUS_FLAG <> ''D''

	INNER JOIN IDENTIFIER(:V_FT_FACT) PFT ON
			PFT.SRC_MATCH_EVT_ID=FT.SRC_MATCH_EVT_ID
			AND PFT.SRC_PARENT_ID <> ''CMAARPAD''
			AND PFT.CDC_STATUS_FLAG <> ''D''
    WHERE
        DATE(PFT.FREEZE_DT) BETWEEN :gv_reportstartdate AND :gv_ReportStopDate              
    GROUP BY
            CE.ID_VAL,
            CE.NAME
    ORDER BY
        CE.ID_VAL ASC;
        
let res_set RESULTSET;
let select_statement1 := ''SELECT * FROM pv_ReportResult'';
res_set := (EXECUTE IMMEDIATE :select_statement1);
RETURN TABLE(res_set);

END;

';