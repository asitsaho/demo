USE SCHEMA BDR_BI; CREATE OR REPLACE PROCEDURE "SP_CREDIT_CARD_RECON_TEST"("PV_REPORTSTARTDATE" DATE, "PV_REPORTSTOPDATE" DATE)
RETURNS TABLE ()
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

																		  
							   
	 
										   
										  
														
	 
  
  gv_ReportStartDate                DATE := TRUNC(pv_ReportStartDate);
  gv_ReportStopDate                DATE := TRUNC(pv_ReportStopDate);
  gv_Log_id                          NUMBER;
  gv_error_code                     varchar(200);


BEGIN
											  
				  
			  
	 
																																			
	
							

LET DB_NAME VARCHAR:=''DWADM'';
LET SCHEMA_NAME VARCHAR := '''';
----DWADM.C1_REQUEST
----SRC_DWADM.C1_REQUEST
LET V_C1_REQUEST := :DB_NAME || ''.'' || :SCHEMA_NAME || ''.C1_REQUEST'';

----DWADM.PAYMENT_TENDERS_FACT
----SRC_DWADM.PAYMENT_TENDERS_FACT
LET V_PAYMENT_TENDERS_FACT := :DB_NAME || ''.'' || :SCHEMA_NAME || ''.PAYMENT_TENDERS_FACT'';

----DWADM.CUSTOMER_DIM
----SRC_DWADM.CUSTOMER_DIM
LET V_CUSTOMER_DIM := :DB_NAME || ''.'' || :SCHEMA_NAME || ''.CUSTOMER_DIM'';

----PAYMENT_DTLS
----PAYMENT_DTLS
LET V_PAYMENT_DTLS := :DB_NAME || ''.'' || :SCHEMA_NAME || ''.PAYMENT_DTLS'';

----DWADM.PAYMENT_FACT
----SRC_DWADM.PAYMENT_FACT
LET V_PAYMENT_FACT := :DB_NAME || ''.'' || :SCHEMA_NAME || ''.PAYMENT_FACT'';

----DWADM.C1_REQUEST_LOG
----SRC_SRC_DWADM.C1_REQUEST_LOG
LET V_C1_REQUEST_LOG := :DB_NAME || ''.'' || :SCHEMA_NAME || ''.C1_REQUEST_LOG'';

----DWADM.ACCOUNT_DIM
----SRC_DWADM.ACCOUNT_DIM
LET V_ACCOUNT_DIM := :DB_NAME || ''.'' || :SCHEMA_NAME || ''.ACCOUNT_DIM'';

----DWADM.TNDR_TYPE_DIM
----SRC_DWADM.TNDR_TYPE_DIM
LET V_TNDR_TYPE_DIM := :DB_NAME || ''.'' || :SCHEMA_NAME || ''.TNDR_TYPE_DIM'';

----DWADM.CI_PER_NAME_VW
----BDR_BI.CI_PER_NAME_VW
LET V_CI_PER_NAME_VW := :DB_NAME || ''.'' || :SCHEMA_NAME || ''.CI_PER_NAME_VW'';

----PV_REPORTRESULT
----PV_REPORTRESULT
LET V_PV_REPORTRESULT := :DB_NAME || ''.'' || :SCHEMA_NAME || ''.PV_REPORTRESULT'';

----NM_DTL
----NM_DTL
LET V_NM_DTL := :DB_NAME || ''.'' || :SCHEMA_NAME || ''.NM_DTL'';


 SELECT 
                CASE
                     WHEN PAYMENT_FACT.UDDGEN19 IN (''IVR'',''TEL'',''PHONE'') AND PAYMENT_FACT.TNDR_TYPE_CD IN (''CCAP'') AND PAYMENT_FACT.UDDGEN18 IN (''ONETIMECCSYS'')
                     THEN ''OptumCSS''
                     WHEN PAYMENT_FACT.UDDGEN19 IN (''WEB'',''WEB-QUICKPAY'') AND PAYMENT_FACT.TNDR_TYPE_CD IN (''CCAP'') AND PAYMENT_FACT.UDDGEN18 IN (''ONETIMECCSYS'')
                     THEN ''MemberWeb''
                  END AS TRANSACTION_TYPE,
                TO_CHAR(PAYMENT_FACT.FREEZE_DT,''MM/DD/YYYY HH:MI:SS AM'') AS PAYMENT_APPLIED_DATE_AND_TIME,
                TO_CHAR(REQ.CRE_DTTM,''MM/DD/YYYY HH:MI:SS AM'') AS CREATE_DATE,
                (NVL(CUSTOMER_DIM.CDF3_VAL,''000000000'') || ''-'' || NVL(CUSTOMER_DIM.CDF12_VAL,''0'') || NVL(CUSTOMER_DIM.CDF5_VAL,''0'')) AS MEMBER_NUMBER,
                NM_DTL.FIRST_NAME,
                NM_DTL.MIDDLE_NAME,
                NM_DTL.LAST_NAME,
                SUM(PTF.TNDR_AMT) AS TOTAL_PAYMENT,
                PAYMENT_FACT.SRC_PAY_TNDR_ID
            FROM 
                 SRC_DWADM.PAYMENT_FACT PAYMENT_FACT
                INNER JOIN SRC_DWADM.PAYMENT_TENDERS_FACT PTF ON PTF.SRC_PAY_TNDR_ID=PAYMENT_FACT.SRC_PAY_TNDR_ID AND PTF.CDC_STATUS_FLAG <> ''D'' 
                INNER JOIN SRC_DWADM.ACCOUNT_DIM AD ON AD.ACCT_CURR_KEY = PAYMENT_FACT.ACCT_CURR_KEY
                            AND AD.CURR_REC_FLAG =''Y'' AND AD.CUST_ID = ''1266812210'' 
                INNER JOIN SRC_DWADM.CUSTOMER_DIM CUSTOMER_DIM ON 
                           (CUSTOMER_DIM.CDF3_VAL || ''-'' || CUSTOMER_DIM.CDF12_VAL || CUSTOMER_DIM.CDF5_VAL)=PAYMENT_FACT.CDDGEN4_VAL                      
                           AND PAYMENT_FACT.CDDGEN4_VAL IS NOT NULL
                            AND CUSTOMER_DIM.CURR_REC_FLAG =''Y'' -- ''Y'' Fetch Always Latest Records
                            AND CUSTOMER_DIM.ID_TYPE_CD = ''INDID'' -- Individual Identifier
                INNER JOIN SRC_DWADM.TNDR_TYPE_DIM TNDR_TYPE_DIM ON 
                            PAYMENT_FACT.TNDR_TYPE_CD = TNDR_TYPE_DIM.SRC_TNDR_TYPE_CD 
                            AND TNDR_TYPE_DIM.TNDR_TYPE_CURR_KEY NOT IN (''-1'',''0'')  -- To Exclude Unknown and Missing Records
                            AND TNDR_TYPE_DIM.CURR_REC_FLAG=''Y'' -- ''Y'' Fetch Always Latest Records
                INNER JOIN PAYMENT_DTLS ON PAYMENT_DTLS.SRC_FT_ID=PAYMENT_FACT.SRC_FT_ID 
                                AND PAYMENT_DTLS.SRC_PAY_EVENT_ID=PAYMENT_FACT.SRC_PAY_EVENT_ID  
                                AND PAYMENT_DTLS.SRC_PAY_TNDR_ID=PAYMENT_FACT.SRC_PAY_TNDR_ID             
                INNER JOIN NM_DTL NM_DTL ON NM_DTL.SRC_CUST_ID = CUSTOMER_DIM.SRC_CUST_ID 
               LEFT JOIN (
                SELECT
                    CRL.CHAR_VAL_FK1 AS PAYMENT_EVENT_ID,
                    CR.CRE_DTTM
                    FROM
                    SRC_DWADM.C1_REQUEST CR
                    INNER JOIN SRC_DWADM.C1_REQUEST_LOG CRL ON CR.C1_REQ_ID = CRL.C1_REQ_ID
                                AND CR.CDC_FLAG <> ''D''
                                AND CRL.CDC_FLAG <> ''D''
                                AND CRL.CHAR_TYPE_CD = ''CMPAYEVT'' -- Payment Event           
                ) REQ ON REQ.PAYMENT_EVENT_ID = PAYMENT_FACT.SRC_PAY_EVENT_ID
            WHERE
                TNDR_TYPE_DIM.SRC_TNDR_TYPE_CD = ''CCAP'' /*Payment Recevied by payment type of credit card*/
                AND PAYMENT_FACT.UDDGEN19 IN (''IVR'',''TEL'',''WEB'',''WEB-QUICKPAY'',''PHONE'')
                AND PAYMENT_FACT.CDC_STATUS_FLAG <> ''D''
                AND TRUNC(PAYMENT_FACT.FREEZE_DT) BETWEEN gv_ReportStartDate AND gv_ReportStopDate
            GROUP BY
               REQ.CRE_DTTM,
               PAYMENT_FACT.FREEZE_DT,
               PAYMENT_FACT.SRC_PAY_TNDR_ID,
               CUSTOMER_DIM.CDF3_VAL, 
               CUSTOMER_DIM.CDF12_VAL,
               CUSTOMER_DIM.CDF5_VAL, 
               FIRST_NAME, 
               MIDDLE_NAME, 
               LAST_NAME, 
               PAYMENT_FACT.UDDGEN19,
               PAYMENT_FACT.TNDR_TYPE_CD, 
               PAYMENT_FACT.UDDGEN18;


END;

';