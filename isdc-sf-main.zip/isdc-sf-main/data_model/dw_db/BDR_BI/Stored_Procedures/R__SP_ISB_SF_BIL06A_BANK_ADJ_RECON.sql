USE SCHEMA BDR_BI; CREATE OR REPLACE PROCEDURE "SP_ISB_SF_BIL06A_BANK_ADJ_RECON"("PV_REPORTSTARTDATE" DATE, "PV_REPORTSTOPDATE" DATE, "PV_FREQUENCY" VARCHAR(1), "DB_NAME" VARCHAR(16777216) DEFAULT '', "TGT_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "TGT2_SC" VARCHAR(16777216) DEFAULT '', "SRC_SC" VARCHAR(16777216) DEFAULT 'SRC_DWADM', "SRC2_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "UTIL_SC" VARCHAR(16777216) DEFAULT 'BDR_BI', "PIPELINE_ID" VARCHAR(16777216) DEFAULT '', "PIPELINE_NAME" VARCHAR(16777216) DEFAULT 'SP_ISB_SF_BIL06A_BANK_ADJ_RECON')
RETURNS TABLE ()
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

  gv_ReportStartDate                DATE := DATE(pv_ReportStartDate);
  gv_ReportStopDate                 DATE := DATE(pv_ReportStopDate);
  gv_frequency                      CHAR := pv_frequency;
  gv_Log_id                         NUMBER;
  gv_error_code                     varchar(200);




V_START_TIME TIMESTAMP;

V_STEP VARCHAR;
V_LAST_QUERY_ID    VARCHAR;
V_ROWS_LOADED   VARCHAR;
V_PROCESS_NAME   VARCHAR DEFAULT ''SP_ISB_SF_BIL06A_BANK_ADJ_RECON'';
V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''SP_ISB_SF_BIL06A_BANK_ADJ_RECON'';
V_STEP_NAME        VARCHAR;
V_ROWS_PARSED      INTEGER;
V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := COALESCE(:UTIL_SC, ''BDR_BI'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';
BEGIN
LET V_TNDR_SRC_DIM VARCHAR :=  :SRC_SC || ''.TNDR_SRC_DIM'';

----EMPLOYER_PRE
----EMPLOYER_PRE
LET V_EMPLOYER_PRE VARCHAR :=  :TGT_SC || ''.EMPLOYER_PRE'';

----DWADM.PAYMENT_TENDERS_FACT
----SRC_DWADM.PAYMENT_TENDERS_FACT
LET V_PAYMENT_TENDERS_FACT VARCHAR :=  :SRC_SC || ''.PAYMENT_TENDERS_FACT'';

----PV_REPORTRESULT
----PV_REPORTRESULT
LET V_PV_REPORTRESULT VARCHAR :=  :TGT_SC || ''.PV_REPORTRESULT'';

----DWADM.DESCR_LKP
----SRC_DWADM.DESCR_LKP
LET V_DESCR_LKP VARCHAR :=  :SRC_SC || ''.DESCR_LKP'';

----BANKADJ
----BANKADJ
LET V_BANKADJ VARCHAR :=  :TGT_SC || ''.BANKADJ'';

----DWADM.PAYMENT_FACT
----SRC_DWADM.PAYMENT_FACT
LET V_PAYMENT_FACT VARCHAR :=  :SRC_SC || ''.PAYMENT_FACT'';

----DWADM.CUSTOMER_DIM
----SRC_DWADM.CUSTOMER_DIM
LET V_CUSTOMER_DIM VARCHAR :=  :SRC_SC || ''.CUSTOMER_DIM'';

----MEMB_ANDRS
----MEMB_ANDRS
LET V_MEMB_ANDRS VARCHAR :=  :TGT_SC || ''.MEMB_ANDRS'';

----PREMIUM
----PREMIUM
LET V_PREMIUM VARCHAR :=  :TGT_SC || ''.PREMIUM'';

----DWADM.TNDR_TYPE_DIM
----SRC_DWADM.TNDR_TYPE_DIM
LET V_TNDR_TYPE_DIM VARCHAR :=  :SRC_SC || ''.TNDR_TYPE_DIM'';

----DWADM.REASON_DIM
----SRC_DWADM.REASON_DIM
LET V_REASON_DIM VARCHAR :=  :SRC_SC || ''.REASON_DIM'';



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP1'';
V_STEP_NAME :=  ''call BDR_BI.FN_ISB_SF_GET_LOG_ID()'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

call BDR_BI.FN_ISB_SF_GET_LOG_ID()
    into :gv_Log_id;

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP2'';
V_STEP_NAME :=  ''CASE gv_frequency'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

if (gv_frequency = ''D'') THEN
    CALL BDR_BI.SP_ISB_SF_INSERT_JOB_LOG(:gv_Log_id,''BI.PKG_ISB_BILL_REPORTS.SP_ISB_Bank_Adj_Recon'',''BIL0006A_ISB_Bank_Adj_Recon_Daily'');
ELSE
CALL BDR_BI.SP_ISB_SF_INSERT_JOB_LOG(:gv_Log_id,''BI.PKG_ISB_BILL_REPORTS.SP_ISB_Bank_Adj_Recon'',''BIL0006A_ISB_Bank_Adj_Recon_Monthly'');
END IF;

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0 ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


LET TEST_VAR VARCHAR;

TEST_VAR := (
                                            SELECT 
                                                PF1.SRC_FT_ID
                                                -- SRC_MATCH_TYPE_CD 
                                            FROM 
                                                IDENTIFIER(:V_PAYMENT_FACT) PF1 ,
                                                IDENTIFIER(:V_PAYMENT_FACT) PF	
                                            WHERE 
                                                PF1.SRC_PAY_EVENT_ID=PF.SRC_PAY_EVENT_ID 
                                                AND PF.SRC_PAY_TNDR_ID=PF1.SRC_PAY_TNDR_ID 
                                            ORDER BY PF1.FREEZE_DT limit 1
                                            ); 
                                       
                                    


--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP3'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE BANKADJ'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_BANKADJ) AS 
    (
        SELECT
            CUST_CURR_KEY,
            SRC_PAY_SEG_ID,
            SRC_MATCH_TYPE_CD, 
            SRC_FT_ID,
            TNDR_SOURCE_TYPE_FLG,
            TNDR_SOURCE_DESCR,
            FREEZE_DT,
            PAY_DT,
            SRC_MICR_ID,
            SUM(PAY) AS PAY_AMT
        FROM
        (
               SELECT  
                    CD.CUST_CURR_KEY,SRC_PAY_SEG_ID,SRC_MATCH_TYPE_CD,PF.FT_TYPE,SRC_FT_ID,
                    TSD.TNDR_SOURCE_TYPE_FLG,
                    TSD.TNDR_SOURCE_DESCR,
                    DATE(PF.FREEZE_DT) AS FREEZE_DT,
                    PF.PAY_DT,
                    PTF.SRC_MICR_ID,
                    CASE
                        WHEN PF.PAY_STATUS_FLG IN (''Frozen'') -- FROZEN PAYMENTS
                        THEN SUM(PF.PAY_AMT) ELSE 0
                    END AS PAY
            FROM
                IDENTIFIER(:V_PAYMENT_FACT) PF		   
                INNER JOIN IDENTIFIER(:V_PAYMENT_TENDERS_FACT) PTF ON PTF.SRC_PAY_TNDR_ID = PF.SRC_PAY_TNDR_ID 
                            AND PTF.CDC_STATUS_FLAG <> ''D'' -- ''D'' Fetch Always Latest Records
                            AND PF.CDC_STATUS_FLAG <> ''D'' -- ''D'' Fetch Always Latest Records
                            AND PTF.CDDGEN1_VAL IS NULL
                INNER JOIN  IDENTIFIER(:V_CUSTOMER_DIM) CD ON PF.CUST_CURR_KEY = CD.CUST_CURR_KEY 
                            AND CD.CURR_REC_FLAG = ''Y'' -- ''Y'' Fetch Always Latest Records
                            AND CD.ID_TYPE_CD = ''INDID''  -- INDIVIDUAL IDENTIFIER
                            AND PF.CDC_STATUS_FLAG <> ''D'' 
                INNER JOIN IDENTIFIER(:V_TNDR_SRC_DIM) TSD ON TSD.SRC_TNDR_SOURCE_CD = PF.TNDR_SRC_CD 
                            AND TSD.CURR_REC_FLAG = ''Y'' -- ''Y'' Fetch Always Latest Records	
                            AND TSD.EXT_SOURCE_ID IN (''EXSIDAARP'',              
                                                        ''EXSIDAARPF'' ,             
                                                        ''EXSIDALLSAVERS'',
                                                        ''EXSIDCOBRA'',            
                                                        ''EXSIDEABP'',
                                                        ''EXSIDGENWORTH'',  
                                                        ''EXSIDMETLIFE'',          
                                                        ''EXSIDOXFORD'',          
                                                        ''EXSIDTRACR'',            
                                                        ''EXSIDUHC'',                  
                                                        ''EXSIDUHGCYPRESS'', 
                                                        ''EXSIDUHGDULUTH'',  
                                                        ''EXSIDUMR''
                                                    )
     
            WHERE    
                PF.CDC_STATUS_FLAG=''Y'' -- ''Y'' Fetch Always Latest Records
                AND  DATE(PF.FREEZE_DT) BETWEEN :gv_ReportStartDate AND :gv_ReportStopDate 
                AND PF.SRC_FT_ID = :TEST_VAR 
                -- IN  (SELECT SRC_FT_ID 
                --                      FROM (
                --                             SELECT 
                --                                 SRC_FT_ID,
                --                                 SRC_MATCH_TYPE_CD 
                --                             FROM 
                --                                 IDENTIFIER(:V_PAYMENT_FACT) PF1 
                --                             WHERE 
                --                                 PF1.SRC_PAY_EVENT_ID=PF.SRC_PAY_EVENT_ID 
                --                                 AND PF.SRC_PAY_TNDR_ID=PF1.SRC_PAY_TNDR_ID 
                --                             ORDER BY PF1.FREEZE_DT
                --                             ) 
                --                         -- WHERE ROWNUM=1
                --                         limit 1
                --                     )
            GROUP BY    
                    CD.CUST_CURR_KEY,
                    SRC_PAY_SEG_ID,
                    SRC_MATCH_TYPE_CD,
                    PF.FT_TYPE,
                    SRC_FT_ID,
                    PAY_STATUS_FLG,
                    TSD.TNDR_SOURCE_TYPE_FLG,
                    TSD.TNDR_SOURCE_DESCR,
                    PTF.SRC_MICR_ID,
                    PF.FREEZE_DT,
                    PF.PAY_DT
        )
        GROUP BY
            CUST_CURR_KEY,
            SRC_PAY_SEG_ID,
            SRC_MATCH_TYPE_CD, 
            SRC_FT_ID,
            TNDR_SOURCE_TYPE_FLG,
            TNDR_SOURCE_DESCR,
            FREEZE_DT,
            PAY_DT,
            SRC_MICR_ID
    );

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_BANKADJ)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP4'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE PREMIUM'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_PREMIUM) AS 
        (
            SELECT
                    CUST_CURR_KEY,
                    PAY_DT,
                    FREEZE_DT,
                    RSN_CURR_KEY,
                    SRC_PAY_TNDR_ID,
                    TNDR_TYPE_CD,
                    TNDR_SRC_CD,
                    PAY_STATUS_FLG,
                    SUM( CAL_PAY + PAY ) AS PAY_AMT                
            FROM
                (
                    SELECT  
                        CD.CUST_CURR_KEY,
                        PF.PAY_DT,
                        DATE(PF.FREEZE_DT) AS FREEZE_DT,
                        PF.RSN_CURR_KEY,
                        PF.SRC_PAY_TNDR_ID,
                        PF.TNDR_TYPE_CD,
                        PF.TNDR_SRC_CD,
                        PF.PAY_STATUS_FLG,
                        SUM(PF.PAY_AMT) AS CAL_PAY,
                        PTF.TNDR_AMT AS PAY
                    FROM
                        IDENTIFIER(:V_PAYMENT_FACT) PF
    --                    INNER JOIN (SELECT 
    --                                    PF1.SRC_PAY_TNDR_ID,
    --                                    SUM(PF1.PAY_AMT) AS PAY_AMT
    --                                FROM 
    --                                    IDENTIFIER(:V_PAYMENT_FACT) PF1 
    --                                GROUP BY 
    --                                    PF1.SRC_PAY_TNDR_ID
    --                                ) PF1 ON PF.SRC_PAY_TNDR_ID = PF1.SRC_PAY_TNDR_ID
                        INNER JOIN  IDENTIFIER(:V_PAYMENT_TENDERS_FACT) PTF ON
                        PF.SRC_PAY_TNDR_ID=PTF.SRC_PAY_TNDR_ID
                        AND PTF.CDC_STATUS_FLAG <> ''D''            
                        INNER JOIN  IDENTIFIER(:V_CUSTOMER_DIM) CD ON PF.CUST_CURR_KEY = CD.CUST_CURR_KEY 
                                    AND CD.CURR_REC_FLAG = ''Y'' -- ''Y'' Fetch Always Latest Records
                                    AND CD.ID_TYPE_CD = ''INDID''  -- INDIVIDUAL IDENTIFIER
                                    AND PF.CDC_STATUS_FLAG <> ''D''
                --                    AND PF.src_pay_tndr_id = ''849186993707''
                                    AND PF.SRC_MATCH_TYPE_CD NOT IN (''XFERMEMF'',''XFERADRS'')
                        INNER JOIN IDENTIFIER(:V_REASON_DIM) RD ON RD.RSN_CURR_KEY = PF.RSN_CURR_KEY  
                                    AND RD.SRC_RSN_CD IN (''EEBK'',''EEUH'') -- REASON CODE ADJUSTMENT CANCELLATION
                    WHERE                 
                            PF.CDC_STATUS_FLAG=''Y'' -- ''Y'' Fetch Always Latest Records
                            AND  DATE(PF.FREEZE_DT) BETWEEN :gv_ReportStartDate AND :gv_ReportStopDate 
                    GROUP BY    
                            CD.CUST_CURR_KEY,
                            PF.PAY_DT,
                            DATE(PF.FREEZE_DT),
                            PF.RSN_CURR_KEY,
                            PTF.TNDR_AMT,
                            PF.SRC_PAY_TNDR_ID,
                            PF.TNDR_TYPE_CD,
                            PF.TNDR_SRC_CD,
                            PF.PAY_STATUS_FLG
                )
                GROUP BY
                    CUST_CURR_KEY,
                    PAY_DT,
                    FREEZE_DT,
                    RSN_CURR_KEY,
                    SRC_PAY_TNDR_ID,
                    TNDR_TYPE_CD,
                    TNDR_SRC_CD,
                    PAY_STATUS_FLG
    );

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_PREMIUM)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP5'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE MEMB_ANDRS'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_MEMB_ANDRS) AS 
        ( 
        SELECT
                CUST_CURR_KEY,
                PAY_DT,
                FREEZE_DT,
                RSN_CURR_KEY,
                SRC_PAY_TNDR_ID,
                TNDR_TYPE_CD,
                TNDR_SRC_CD,
                PAY_STATUS_FLG,
                SUM( CAL_PAY + PAY ) AS PAY_AMT
                
            FROM
            (
                SELECT  
                    CD.CUST_CURR_KEY,
                    PF.PAY_DT,
                    DATE(PF.FREEZE_DT) AS FREEZE_DT,
                    PF.RSN_CURR_KEY,
                    PF.SRC_PAY_TNDR_ID,
                    PF.TNDR_TYPE_CD,
                    PF.TNDR_SRC_CD,
                    PF.PAY_STATUS_FLG,
                    SUM(PF.PAY_AMT) AS CAL_PAY,
                    PTF.TNDR_AMT AS PAY
                FROM
                    IDENTIFIER(:V_PAYMENT_FACT) PF
    --                INNER JOIN (SELECT 
    --                                PF1.SRC_PAY_TNDR_ID,
    --                                SUM(PF1.PAY_AMT) AS PAY_AMT
    --                            FROM 
    --                                IDENTIFIER(:V_PAYMENT_FACT) PF1 
    --                            GROUP BY 
    --                                PF1.SRC_PAY_TNDR_ID
    --                            ) PF1 ON PF.SRC_PAY_TNDR_ID = PF1.SRC_PAY_TNDR_ID
                    INNER JOIN  IDENTIFIER(:V_CUSTOMER_DIM) CD ON PF.CUST_CURR_KEY = CD.CUST_CURR_KEY 
                                AND CD.CURR_REC_FLAG = ''Y'' -- ''Y'' Fetch Always Latest Records
                                AND CD.ID_TYPE_CD = ''INDID''  -- INDIVIDUAL IDENTIFIER
                                AND PF.CDC_STATUS_FLAG <> ''D''
            --                    AND PF.src_pay_tndr_id = ''849186993707''
                                AND PF.SRC_MATCH_TYPE_CD IN (''XFERMEMF'',''XFERADRS'')
                    INNER JOIN  IDENTIFIER(:V_PAYMENT_TENDERS_FACT) PTF ON
                        PF.SRC_PAY_TNDR_ID=PTF.SRC_PAY_TNDR_ID
                        AND PTF.CDC_STATUS_FLAG <> ''D''             
                    INNER JOIN IDENTIFIER(:V_REASON_DIM) RD ON RD.RSN_CURR_KEY = PF.RSN_CURR_KEY  
                                AND RD.SRC_RSN_CD IN (''EEBK'',''EEUH'') -- REASON CODE ADJUSTMENT CANCELLATION
                WHERE      
                        PF.CDC_STATUS_FLAG=''Y'' -- ''Y'' Fetch Always Latest Records
                        AND  DATE(PF.FREEZE_DT) BETWEEN :gv_ReportStartDate AND :gv_ReportStopDate 
                GROUP BY    
                        CD.CUST_CURR_KEY,
                        PF.PAY_DT,
                        DATE(PF.FREEZE_DT),
                        PF.RSN_CURR_KEY,
                        PTF.TNDR_AMT,
                        PF.SRC_PAY_TNDR_ID,
                        PF.TNDR_TYPE_CD,
                        PF.TNDR_SRC_CD,
                        PF.PAY_STATUS_FLG
            )
            GROUP BY
            CUST_CURR_KEY,
            PAY_DT,
            FREEZE_DT,
            RSN_CURR_KEY,
            SRC_PAY_TNDR_ID,
            TNDR_TYPE_CD,
            TNDR_SRC_CD,
            PAY_STATUS_FLG
    );

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_MEMB_ANDRS)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP6'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE EMPLOYER_PRE'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_EMPLOYER_PRE) AS
        (    
              SELECT
                CUST_CURR_KEY,
                PAY_DT,
                FREEZE_DT,
                RSN_CURR_KEY,
                SRC_PAY_TNDR_ID,
                TNDR_TYPE_CD,
                TNDR_SRC_CD,
                PAY_STATUS_FLG,
                SUM( CAL_PAY + PAY ) AS PAY_AMT
                
            FROM
            (
                SELECT  
                    CD.CUST_CURR_KEY,
                    PF.PAY_DT,
                    DATE(PF.FREEZE_DT) AS FREEZE_DT,
                    PF.RSN_CURR_KEY,
                    PF.SRC_PAY_TNDR_ID,
                    PF.TNDR_TYPE_CD,
                    PF.TNDR_SRC_CD,
                    PF.PAY_STATUS_FLG,
                    SUM(PF.PAY_AMT) AS CAL_PAY,
                    PTF.TNDR_AMT AS PAY
                FROM
                IDENTIFIER(:V_PAYMENT_FACT) PF
    --            INNER JOIN (SELECT 
    --                                PF1.SRC_PAY_TNDR_ID,
    --                                SUM(PF1.PAY_AMT) AS PAY_AMT
    --                        FROM
    --                                IDENTIFIER(:V_PAYMENT_FACT) PF1
    --                        GROUP BY 
    --                                PF1.SRC_PAY_TNDR_ID
    --                        ) PF1 ON PF.SRC_PAY_TNDR_ID = PF1.SRC_PAY_TNDR_ID
                INNER JOIN  IDENTIFIER(:V_CUSTOMER_DIM) CD ON PF.CUST_CURR_KEY = CD.CUST_CURR_KEY 
                            AND CD.CURR_REC_FLAG = ''Y'' -- ''Y'' Fetch Always Latest Records
                            AND CD.ID_TYPE_CD = ''EMPID''  -- INDIVIDUAL IDENTIFIER
                            AND PF.CDC_STATUS_FLAG <> ''D''
    --                        AND PF.src_pay_tndr_id = ''464876110130''
                            AND PF.SRC_MATCH_TYPE_CD NOT IN (''XFERMEMF'',''XFERADRS'')
                INNER JOIN  IDENTIFIER(:V_PAYMENT_TENDERS_FACT) PTF ON
                        PF.SRC_PAY_TNDR_ID=PTF.SRC_PAY_TNDR_ID
                        AND PTF.CDC_STATUS_FLAG <> ''D''            
                INNER JOIN IDENTIFIER(:V_REASON_DIM) RD ON RD.RSN_CURR_KEY = PF.RSN_CURR_KEY  
                            AND RD.SRC_RSN_CD IN (''EEBK'',''EEUH'') -- REASON CODE ADJUSTMENT CANCELLATION
                WHERE                 
                       PF.CDC_STATUS_FLAG=''Y'' -- ''Y'' Fetch Always Latest Records
                        AND  DATE(PF.FREEZE_DT) BETWEEN :gv_ReportStartDate AND :gv_ReportStopDate 
                GROUP BY    
                        CD.CUST_CURR_KEY,
                        PF.PAY_DT,
                        DATE(PF.FREEZE_DT),
                        PF.RSN_CURR_KEY,
                        PTF.TNDR_AMT,
                        PF.SRC_PAY_TNDR_ID,
                        PF.TNDR_TYPE_CD,
                        PF.TNDR_SRC_CD,
                        PF.PAY_STATUS_FLG
            )
            GROUP BY
            CUST_CURR_KEY,
            PAY_DT,
            FREEZE_DT,
            RSN_CURR_KEY,
            SRC_PAY_TNDR_ID,
            TNDR_TYPE_CD,
            TNDR_SRC_CD,
            PAY_STATUS_FLG 
        );

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_EMPLOYER_PRE)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP7'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE pv_ReportResult'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_pv_ReportResult) AS
    SELECT
    PROCESSING_SITE,
    MAINTENANCE_PROCESS_DATE,
    MEMBER_NUMBER,
    MEMBER_NAME,
    "ROUTING#",
    "ACCOUNT#",
    REASON,
    MAX(BANK_PROCESS_DATE) AS BANK_PROCESS_DATE,
    SUM(TOTAL_PAYMENT) AS TOTAL_PAYMENT,
    SUM(NVL(PREMIUM,0)) AS PREMIUM,
    SUM(NVL(MEMBERSHIP,0)) AS MEMBERSHIP,
    SUM(NVL(ANDRUS,0)) AS ANDRUS,
    CURRENT_TIMESTAMP() AS RUN_DATE,
    :gv_ReportStartDate AS START_DATE,
    :gv_ReportStopDate AS END_DATE,
    CUST_CURR_KEY
    FROM
    (
    SELECT
        PROCESSING_SITE,
        MAINTENANCE_PROCESS_DATE,
        MEMBER_NUMBER,
        MEMBER_NAME,
        "ROUTING#",
        "ACCOUNT#",
        REASON,
        BANK_PROCESS_DATE,
        TOTAL_PAYMENT,
        PREMIUM,
        MEMBERSHIP,
        ANDRUS,
        CUST_CURR_KEY,
        SRC_PAY_TNDR_ID
        FROM
        (    
        SELECT 
        CASE
            WHEN TNDR_SOURCE_TYPE_FLG = ''LOCK'' AND SRC_TNDR_SOURCE_CD IN (''BNYLBXDL'',''BNYLBXPB'')
            THEN TNDR_SOURCE_DESCR
            WHEN SRC_TNDR_SOURCE_CD = ''ENROLL''
            THEN TNDR_SOURCE_DESCR
            ELSE ''Online Payment''
            END AS PROCESSING_SITE,    
        DATE(PF1.FREEZE_DT) AS MAINTENANCE_PROCESS_DATE, 
        (CU.CDF3_VAL || ''-'' || CU.CDF12_VAL || CU.CDF5_VAL) AS MEMBER_NUMBER,
        CU.NAME AS MEMBER_NAME,
        SUBSTR(PTF.SRC_MICR_ID,0,9)AS "ROUTING#",
        SUBSTR(PTF.SRC_MICR_ID,11,17) AS "ACCOUNT#",
        DL.DESCR AS REASON,
        DATE(PF1.PAY_DT) AS BANK_PROCESS_DATE,     
        (NVL(PF1.PAY_AMT,0)) AS TOTAL_PAYMENT,
        NVL(PF1.PAY_AMT,0)  AS PREMIUM,
        NVL(PF3.PAY_AMT,0)  AS MEMBERSHIP,
        NVL(PF3.PAY_AMT,0)  AS ANDRUS, 
        PF1.CUST_CURR_KEY,
        PF1.SRC_PAY_TNDR_ID,
        RANK() OVER (PARTITION BY (CU.CDF3_VAL || ''-'' || CU.CDF12_VAL || CU.CDF5_VAL) ORDER BY PF1.RSN_CURR_KEY) AS RNK
        FROM
        IDENTIFIER(:V_PREMIUM) PF1  
        LEFT JOIN IDENTIFIER(:V_MEMB_ANDRS) PF3  ON PF3.CUST_CURR_KEY=PF1.CUST_CURR_KEY 
        INNER JOIN IDENTIFIER(:V_TNDR_SRC_DIM) TSD ON TSD.SRC_TNDR_SOURCE_CD = PF1.TNDR_SRC_CD AND TSD.CURR_REC_FLAG = ''Y'' -- ''Y'' Fetch Always Latest Records
        INNER JOIN IDENTIFIER(:V_PAYMENT_TENDERS_FACT) PTF ON PTF.SRC_PAY_TNDR_ID = PF1.SRC_PAY_TNDR_ID 
                        AND PTF.CDC_STATUS_FLAG <> ''D'' -- ''D'' Fetch Always Latest Records
    --                    AND PF1.CDC_STATUS_FLAG <> ''D'' -- ''D'' Fetch Always Latest Records
                        AND PTF.CDDGEN1_VAL IS NOT NULL
        INNER JOIN IDENTIFIER(:V_DESCR_LKP) DL ON DL.PK_ATTR = PTF.CDDGEN1_VAL AND DL.ENTITY_NAME = ''CHAR_VAL'' AND DL.CODE = ''CMBADJRS'' -- Adjsutment Reason               
        LEFT OUTER JOIN IDENTIFIER(:V_CUSTOMER_DIM) CU ON CU.CUST_CURR_KEY = PF1.CUST_CURR_KEY AND CU.CURR_REC_FLAG = ''Y'' -- ''Y'' Fetch Always Latest Records
        WHERE 
        PF1.PAY_STATUS_FLG = ''Canceled'' -- Payment Cancellation
         AND        
            DATE(PF1.FREEZE_DT) BETWEEN  :gv_ReportStartDate AND :gv_ReportStopDate
        )
        WHERE
        RNK = ''1''
        
    UNION ALL
    
        SELECT
        CASE
            WHEN TNDR_SOURCE_TYPE_FLG = ''LOCK'' AND SRC_TNDR_SOURCE_CD IN (''BNYLBXDL'',''BNYLBXPB'')
            THEN TNDR_SOURCE_DESCR
            WHEN SRC_TNDR_SOURCE_CD = ''ENROLL''
            THEN TNDR_SOURCE_DESCR
            ELSE ''Online Payment''
        END AS PROCESSING_SITE,    
        DATE(PF1.FREEZE_DT) AS MAINTENANCE_PROCESS_DATE, 
        (CU.CDF3_VAL || ''-'' || CU.CDF12_VAL || CU.CDF5_VAL) AS MEMBER_NUMBER,
        CU.NAME AS MEMBER_NAME,
        SUBSTR(PTF.SRC_MICR_ID,0,9)AS "ROUTING#",
        SUBSTR(PTF.SRC_MICR_ID,11,17) AS "ACCOUNT#",
        DL.DESCR AS REASON,
        DATE(PF1.PAY_DT) AS BANK_PROCESS_DATE,     
        (NVL(PF1.PAY_AMT,0)) AS TOTAL_PAYMENT,
        NVL(PF1.PAY_AMT,0) AS PREMIUM,
        NVL(PF2.PAY_AMT,0) AS MEMBERSHIP,
        NVL(PF2.PAY_AMT,0) AS ANDRUS, 
        CU.CUST_CURR_KEY,
        PF1.SRC_PAY_TNDR_ID
        FROM
        IDENTIFIER(:V_PREMIUM) PF1
        INNER JOIN IDENTIFIER(:V_MEMB_ANDRS) PF2  ON PF2.CUST_CURR_KEY=PF1.CUST_CURR_KEY 
        INNER JOIN IDENTIFIER(:V_TNDR_SRC_DIM) TSD ON TSD.SRC_TNDR_SOURCE_CD = PF1.TNDR_SRC_CD AND TSD.CURR_REC_FLAG = ''Y'' -- ''Y'' Fetch Always Latest Records
        INNER JOIN IDENTIFIER(:V_PAYMENT_TENDERS_FACT) PTF ON PTF.SRC_PAY_TNDR_ID = PF1.SRC_PAY_TNDR_ID 
                        AND PTF.CDC_STATUS_FLAG <> ''D''
                        AND PTF.CDDGEN1_VAL IS NOT NULL
                        AND PF1.PAY_STATUS_FLG = ''Frozen'' -- Payment Frozen
        INNER JOIN IDENTIFIER(:V_DESCR_LKP) DL ON DL.PK_ATTR = PTF.CDDGEN1_VAL AND DL.ENTITY_NAME = ''CHAR_VAL'' AND DL.CODE = ''CMBADJRS'' -- Adjustment Reason               
        LEFT OUTER JOIN IDENTIFIER(:V_CUSTOMER_DIM) CU ON CU.CUST_CURR_KEY = PF1.CUST_CURR_KEY AND CU.CURR_REC_FLAG = ''Y'' -- ''Y'' Fetch Always Latest Records
        WHERE        
            DATE(PF1.FREEZE_DT) BETWEEN :gv_ReportStartDate AND :gv_ReportStopDate
    
    UNION ALL
        
        select distinct
        CASE
            WHEN TNDR_SOURCE_TYPE_FLG = ''LOCK'' AND SRC_TNDR_SOURCE_CD IN (''BNYLBXDL'',''BNYLBXPB'')
            THEN TNDR_SOURCE_DESCR
            WHEN SRC_TNDR_SOURCE_CD = ''ENROLL''
            THEN TNDR_SOURCE_DESCR
            ELSE ''Online Payment''
            END AS PROCESSING_SITE,    
        DATE(PF1.FREEZE_DT) AS MAINTENANCE_PROCESS_DATE, 
        ''000000000-00'' AS MEMBER_NUMBER,
        NULL AS MEMBER_NAME,
        SUBSTR(PTF.SRC_MICR_ID,-7)AS "ROUTING#",
        SUBSTR(PTF.SRC_MICR_ID,-19,12) AS "ACCOUNT#",
        DL.DESCR AS REASON,
        DATE(PF1.PAY_DT) AS BANK_PROCESS_DATE,     
        (NVL(PF1.PAY_AMT,0)) AS TOTAL_PAYMENT,
         NULL AS PREMIUM,
        NULL AS MEMBERSHIP,
        NULL AS ANDRUS,
        PF1.CUST_CURR_KEY,
        PF1.SRC_PAY_TNDR_ID
        from IDENTIFIER(:V_EMPLOYER_PRE) PF1
        INNER JOIN IDENTIFIER(:V_PAYMENT_TENDERS_FACT) PTF ON PTF.SRC_PAY_TNDR_ID = PF1.SRC_PAY_TNDR_ID 
                        AND PTF.CDC_STATUS_FLAG <> ''D'' -- ''D'' Fetch Always Latest Records
                        AND PTF.CDDGEN1_VAL IS NOT NULL
        INNER JOIN IDENTIFIER(:V_DESCR_LKP) DL ON DL.PK_ATTR = PTF.CDDGEN1_VAL AND DL.ENTITY_NAME = ''CHAR_VAL'' AND DL.CODE = ''CMBADJRS'' -- Adjustment Reason 
        INNER JOIN IDENTIFIER(:V_TNDR_SRC_DIM) TSD ON TSD.SRC_TNDR_SOURCE_CD = PF1.TNDR_SRC_CD AND TSD.CURR_REC_FLAG = ''Y'' -- ''Y'' Fetch Always Latest Records
        INNER JOIN IDENTIFIER(:V_TNDR_TYPE_DIM) TTD ON TTD.SRC_TNDR_TYPE_CD = PF1.TNDR_TYPE_CD AND TTD.CURR_REC_FLAG = ''Y'' -- ''Y'' Fetch Always Latest Records
        LEFT OUTER JOIN IDENTIFIER(:V_CUSTOMER_DIM) CU ON CU.CUST_CURR_KEY = PF1.CUST_CURR_KEY AND CU.CURR_REC_FLAG = ''Y'' -- ''Y'' Fetch Always Latest Records
      WHERE        
            DATE(PF1.FREEZE_DT) BETWEEN :gv_ReportStartDate AND :gv_ReportStopDate
            
        
        
    UNION ALL
    
        SELECT
         ''Online Payment'' AS PROCESSING_SITE,    
        DATE(BDJ.FREEZE_DT) AS MAINTENANCE_PROCESS_DATE, 
        (CU.CDF3_VAL || ''-'' || CU.CDF12_VAL || CU.CDF5_VAL) AS MEMBER_NUMBER,
        CU.NAME AS MEMBER_NAME,
        SUBSTR(BDJ.SRC_MICR_ID,0,9)AS "ROUTING#",
        SUBSTR(BDJ.SRC_MICR_ID,11,17) AS "ACCOUNT#",
        ''Bank Adjustment'' AS REASON,
        DATE(BDJ.PAY_DT) AS BANK_PROCESS_DATE,     
        (NVL(BDJ.PAY_AMT,0)) AS TOTAL_PAYMENT,
        case when BDJ.SRC_MATCH_TYPE_CD NOT IN (''XFERMEMF'',''XFERADRS'') then NVL(BDJ.PAY_AMT,0) END AS PREMIUM,
        case when BDJ.SRC_MATCH_TYPE_CD = ''XFERMEMF'' then NVL(BDJ.PAY_AMT,0) END AS MEMBERSHIP,
        case when BDJ.SRC_MATCH_TYPE_CD = ''XFERADRS'' then NVL(BDJ.PAY_AMT,0) END AS ANDRUS,
        CU.CUST_CURR_KEY,
        '''' AS SRC_PAY_TNDR_ID
        FROM
        IDENTIFIER(:V_BANKADJ) BDJ 
       -- INNER JOIN IDENTIFIER(:V_TNDR_SRC_DIM) TSD ON TSD.SRC_TNDR_SOURCE_CD = BDJ.TNDR_SRC_CD AND TSD.CURR_REC_FLAG = ''Y''	-- ''Y'' Fetch Always Latest Records	
        LEFT OUTER JOIN IDENTIFIER(:V_CUSTOMER_DIM) CU ON CU.CUST_CURR_KEY = BDJ.CUST_CURR_KEY AND CU.CURR_REC_FLAG = ''Y'' -- ''Y'' Fetch Always Latest Records	
    
    )	
     GROUP BY
    PROCESSING_SITE,
    MAINTENANCE_PROCESS_DATE,
    MEMBER_NUMBER,
    MEMBER_NAME,
    "ROUTING#",
    "ACCOUNT#",
    REASON,
    CUST_CURR_KEY,SRC_PAY_TNDR_ID
    HAVING
       SUM(NVL(TOTAL_PAYMENT,0)) <> ''0'';

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_pv_ReportResult)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP8'';
V_STEP_NAME :=  ''CALL BDR_BI.SP_ISB_SF_LOG_INSERT_COMPLETE(:gv_Log_id)'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CALL BDR_BI.SP_ISB_SF_LOG_INSERT_COMPLETE(:gv_Log_id);

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := 0 ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);






let res_set RESULTSET;
let select_statement1 := ''SELECT * FROM pv_ReportResult'';
res_set := (EXECUTE IMMEDIATE :select_statement1);
RETURN TABLE(res_set);

EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''ISB-REPORTS'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);

gv_error_code := SQLERRM;
CALL BDR_BI.SP_ISB_SF_LOG_INSERT_ERROR(:gv_Log_id, :gv_error_code);

RAISE;

END;

';