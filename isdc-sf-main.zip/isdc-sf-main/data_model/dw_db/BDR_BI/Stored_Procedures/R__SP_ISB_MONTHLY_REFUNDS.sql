USE SCHEMA BDR_BI; CREATE OR REPLACE PROCEDURE "SP_ISB_MONTHLY_REFUNDS"("PV_REPORTSTARTDATE" DATE, "PV_REPORTSTOPDATE" DATE, "PIPELINE_ID" VARCHAR(16777216), "PIPELINE_NAME" VARCHAR(16777216), "DB_NAME" VARCHAR(16777216), "UTIL_SC" VARCHAR(16777216), "TGT_SC" VARCHAR(16777216), "TGT2_SC" VARCHAR(16777216), "SRC_SC" VARCHAR(16777216), "SRC2_SC" VARCHAR(16777216), "WH" VARCHAR(16777216))
RETURNS TABLE ()
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

  gv_ReportStartDate                DATE := TRUNC(pv_ReportStartDate);
  gv_ReportStopDate                DATE := TRUNC(pv_ReportStopDate);
  gv_Log_id                          NUMBER;
  gv_error_code                     varchar(200);


V_STEP VARCHAR;
V_LAST_QUERY_ID    VARCHAR;
V_ROWS_LOADED   VARCHAR;
V_PROCESS_NAME   VARCHAR DEFAULT ''SP_ISB_Monthly_Refunds'';
V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''SP_ISB_Monthly_Refunds'';
V_STEP_NAME        VARCHAR;
V_ROWS_PARSED      INTEGER;
V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := :DB_NAME||''.''||COALESCE(:UTIL_SC, ''UTIL'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';
BEGIN
----DWADM.C1_REF_WO_REQ_LOG
----SRC_SRC_DWADM.C1_REF_WO_REQ_LOG
LET V_C1_REF_WO_REQ_LOG := :DB_NAME || ''.'' || :SCHEMA_NAME || ''.C1_REF_WO_REQ_LOG'';

----DWADM.CI_ACCT_APAY
----SRC_DWADM.CI_ACCT_APAY
LET V_CI_ACCT_APAY := :DB_NAME || ''.'' || :SCHEMA_NAME || ''.CI_ACCT_APAY'';

----DWADM.C1_REF_WO_REQ_DTLS
----SRC_SRC_DWADM.C1_REF_WO_REQ_DTLS
LET V_C1_REF_WO_REQ_DTLS := :DB_NAME || ''.'' || :SCHEMA_NAME || ''.C1_REF_WO_REQ_DTLS'';

----DWADM.C1_REF_WO_REQ
----SRC_DWADM.C1_REF_WO_REQ
LET V_C1_REF_WO_REQ := :DB_NAME || ''.'' || :SCHEMA_NAME || ''.C1_REF_WO_REQ'';

----REQUEST_DETL
----REQUEST_DETL
LET V_REQUEST_DETL := :DB_NAME || ''.'' || :SCHEMA_NAME || ''.REQUEST_DETL'';

----DWADM.ADJUSTMENT_FACT
----SRC_DWADM.ADJUSTMENT_FACT
LET V_ADJUSTMENT_FACT := :DB_NAME || ''.'' || :SCHEMA_NAME || ''.ADJUSTMENT_FACT'';

----PV_REPORTRESULT
----PV_REPORTRESULT
LET V_PV_REPORTRESULT := :DB_NAME || ''.'' || :SCHEMA_NAME || ''.PV_REPORTRESULT'';

----DWADM.C1_REF_WO_REQ_CHAR
----SRC_SRC_DWADM.C1_REF_WO_REQ_CHAR
LET V_C1_REF_WO_REQ_CHAR := :DB_NAME || ''.'' || :SCHEMA_NAME || ''.C1_REF_WO_REQ_CHAR'';

----RQ_DETL
----RQ_DETL
LET V_RQ_DETL := :DB_NAME || ''.'' || :SCHEMA_NAME || ''.RQ_DETL'';




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP1'';
V_STEP_NAME :=  ''call UBLIA_TST_ISDC_DEV_DB.BDR_BI.FN_GET_LOG_ID()'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

call UBLIA_TST_ISDC_DEV_DB.BDR_BI.FN_GET_LOG_ID()
    into :gv_Log_id;

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_QUEUE_NAMES1)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP2'';
V_STEP_NAME :=  ''CALL UBLIA_TST_ISDC_DEV_DB.BDR_BI.P_Insert_Job_Log()'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CALL UBLIA_TST_ISDC_DEV_DB.BDR_BI.P_Insert_Job_Log(:gv_Log_id,''BI.PKG_ISB_BILL_REPORTS.SP_ISB_Monthly_Refunds'',''BIL0033A_ISB_Monthly_Refunds'');

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_QUEUE_NAMES1)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP3'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE  RQ_DETL AS
    (
        SELECT
            REF_WO_REQ_ID,
            ADJ_ID,
            ADJ_AMT,
            STATUS,
            CRE_DTTM,
            ACCT_ID,
            BUS_OBJ_CD,
            MAX(SENT_DT) AS SENT_DT,
            FREEZE_DT
        FROM
            (
                SELECT DISTINCT 
                        REQ.REF_WO_REQ_ID,
                        DTL.ADJ_ID, 
                        AD.ADJ_AMT,
                        REQ.BUS_OBJ_CD,
                        REQ.ACCT_ID,
                        CASE 
                            WHEN 
                                AD.FT_TYPE=''Adjustment'' 
                            THEN 
                                ''PROCESSED'' 
                            ELSE 
                                ''VOID'' 
                        END AS STATUS,
                        CASE 
                            WHEN
                                RWC.CHAR_TYPE_CD = ''CM-SNTDT''
                            THEN 
                                TO_CHAR(TO_DATE(RWC.SRCH_CHAR_VAL,''YYYY/MM/DD''),''MM/DD/YYYY'') 
                        END AS SENT_DT,
                        REQ.CRE_DTTM,
                        DATE(AD.FREEZE_DT) AS FREEZE_DT
                FROM 
                    IDENTIFIER(:V_C1_REF_WO_REQ) REQ
                    INNER JOIN IDENTIFIER(:V_C1_REF_WO_REQ_DTLS) DTL ON REQ.REF_WO_REQ_ID = DTL.REF_WO_REQ_ID
                            AND REQ.CDC_FLAG <> ''D''
                            AND DTL.CDC_FLAG <> ''D''
                    INNER JOIN IDENTIFIER(:V_ADJUSTMENT_FACT) AD ON AD.SRC_ADJ_ID = DTL.ADJ_ID
                    LEFT JOIN IDENTIFIER(:V_C1_REF_WO_REQ_CHAR) RWC ON REQ.REF_WO_REQ_ID = RWC.REF_WO_REQ_ID AND RWC.CDC_FLAG <> ''D''
                            AND RWC.CHAR_TYPE_CD in (''CM-SNTDT'')
                WHERE 
                             NOT EXISTS (SELECT 1 
                                            FROM 
                                                IDENTIFIER(:V_C1_REF_WO_REQ_LOG) REF1 
                                            WHERE 
                                                REF1.CHAR_TYPE_CD = ''CMREFREQ''
                                                AND trim(REF1.CHAR_VAL_FK1) =REQ.REF_WO_REQ_ID 
                                                AND REQ.BO_STATUS_CD=''PROCESSED''
                                            )
            
            UNION ALL                                                
                                                            
                SELECT DISTINCT 
                        REQ.REF_WO_REQ_ID,
                        DTL.ADJ_ID, 
                        AD.ADJ_AMT, 
                        REQ.BUS_OBJ_CD,
                        REQ.ACCT_ID,
                        ''REISSUE'' AS STATUS,
                        CASE 
                            WHEN
                                RWC.CHAR_TYPE_CD = ''CM-SNTDT''
                            THEN 
                                TO_CHAR(TO_DATE(RWC.SRCH_CHAR_VAL,''YYYY/MM/DD''),''MM/DD/YYYY'') 
                        END AS SENT_DT,
                        REQ.CRE_DTTM,
                        DATE(AD.FREEZE_DT) AS FREEZE_DT
                FROM 
                    IDENTIFIER(:V_C1_REF_WO_REQ) REQ
                    INNER JOIN IDENTIFIER(:V_C1_REF_WO_REQ_DTLS) DTL ON REQ.REF_WO_REQ_ID = DTL.REF_WO_REQ_ID
                            AND REQ.CDC_FLAG <> ''D''
                            AND DTL.CDC_FLAG <> ''D''
                    INNER JOIN IDENTIFIER(:V_ADJUSTMENT_FACT) AD ON AD.SRC_ADJ_ID = DTL.ADJ_ID
                    LEFT JOIN IDENTIFIER(:V_C1_REF_WO_REQ_CHAR) RWC ON REQ.REF_WO_REQ_ID = RWC.REF_WO_REQ_ID 
                            AND RWC.CDC_FLAG <> ''D''
                            AND RWC.CHAR_TYPE_CD in (''CM-SNTDT'')
                WHERE 
                     EXISTS (SELECT 1 
                                FROM 
                                    IDENTIFIER(:V_C1_REF_WO_REQ_LOG) REF1 
                                WHERE REF1.CHAR_TYPE_CD = ''CMREFREQ''
                                AND trim(REF1.CHAR_VAL_FK1) =REQ.REF_WO_REQ_ID 
                                AND REQ.BO_STATUS_CD=''PROCESSED''
                                )
            )
        GROUP BY
            REF_WO_REQ_ID,
            ADJ_ID,
            ADJ_AMT,
            STATUS,
            CRE_DTTM,
            ACCT_ID,
            BUS_OBJ_CD,
            FREEZE_DT
    );

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_QUEUE_NAMES1)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP4'';
V_STEP_NAME :=  ''CREATE OR REPLACE TEMPORARY TABLE'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TEMPORARY TABLE REQUEST_DETL AS 
    (
        SELECT * FROM
            (
                SELECT DISTINCT
                            RW.REF_WO_REQ_ID,
                            RW.STATUS,
                            RW.ADJ_AMT,
                            RW.ADJ_ID,
                            CASE WHEN
                                    RW.STATUS <> ''VOID''
                                THEN 
                                    RW.SENT_DT        
                                END AS SENT_DATE,
                            RW.FREEZE_DT         
                        FROM
                            RQ_DETL RW
                            LEFT JOIN IDENTIFIER(:V_CI_ACCT_APAY) AA ON AA.ACCT_ID = RW.ACCT_ID
                                AND DATE(RW.CRE_DTTM) >= AA.START_DT AND (DATE(RW.CRE_DTTM) <= AA.END_DT OR AA.END_DT IS NULL)
                                AND AA.APAY_RTE_TYPE_CD <> ''PEN-FRS''
                                AND AA.CDC_FLAG <> ''D'' 
                        WHERE            
                                (RW.STATUS IN (''REISSUE'',''PROCESSED'',''VOID'') AND
                                RW.BUS_OBJ_CD IN (''CM-RefundReq'')
                                OR
                                RW.STATUS IN (''PROCESSED'',''VOID'') AND
                                RW.BUS_OBJ_CD IN (''CM-ACHRefundRequest''))-- CM-ACH(EFT) AND CM-REF (CHECK)
            )
            WHERE
                ((TO_DATE(TO_CHAR(TO_DATE(SENT_DATE ,''MM/DD/YYYY''),''DD/MON/YYYY''),''DD/MON/YYYY'') BETWEEN gv_ReportStartDate AND gv_ReportStopDate AND STATUS <> ''VOID'')
                                OR
                (FREEZE_DT BETWEEN gv_ReportStartDate AND gv_ReportStopDate AND STATUS = ''VOID''))
    );

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_QUEUE_NAMES1)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP5'';
V_STEP_NAME :=  ''CREATE OR REPLACE TABLE pv_ReportResult'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE pv_ReportResult AS

SELECT
    FREEZE_DT AS APPLIED_DATE,
    CASE 
    WHEN REFUND_STATUS IN (''PROCESSED'',''REISSUE'')
    THEN SENT_DATE
    END AS SENT_DATE,
    SUM(REFUND_AMOUNT) AS REFUND_AMOUNT,
    gv_ReportStartDate AS START_DATE,
    gv_ReportStopDate AS END_DATE,
    SYSDATE AS REPORT_RUN_DATE
FROM
    (
    SELECT  
        RQ_DETL.STATUS AS REFUND_STATUS,
        RQ_DETL.SENT_DATE,
        RQ_DETL.FREEZE_DT,
        RQ_DETL.ADJ_AMT AS REFUND_AMOUNT,
        RQ_DETL.ADJ_ID
    FROM 
        REQUEST_DETL RQ_DETL
    WHERE 
        RQ_DETL.STATUS IN (''REISSUE'',''PROCESSED'',''VOID'')
        AND
        ((RQ_DETL.STATUS IN (''REISSUE'',''PROCESSED'') AND RQ_DETL.SENT_DATE IS NOT NULL) OR RQ_DETL.STATUS IN (''VOID''))
    )
GROUP BY
    FREEZE_DT,
    REFUND_STATUS,
    SENT_DATE
HAVING 
    SUM(REFUND_AMOUNT) <> 0;

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_QUEUE_NAMES1)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;
ALTER SESSION SET TIMEZONE = ''America/Chicago'';
V_STEP := ''STEP6'';
V_STEP_NAME :=  ''CALL UBLIA_TST_ISDC_DEV_DB.BDR_BI.P_Insert_Complete(:gv_Log_id)'';
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CALL UBLIA_TST_ISDC_DEV_DB.BDR_BI.P_Insert_Complete(:gv_Log_id);

 V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

 V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_QUEUE_NAMES1)) ;

 CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME,:V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(),''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);





EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);

gv_error_code := SQLCODE;
CALL UBLIA_TST_ISDC_DEV_DB.BDR_BI.P_Insert_Error(:gv_Log_id, :gv_error_code);

RAISE;

END;

';