USE SCHEMA BDR_FFP_DA;

CREATE OR REPLACE PROCEDURE BDR_FFP_DA.SP_CAMPAIGN_DASHBOARD("PIPELINE_ID" VARCHAR(16777216), "PIPELINE_NAME" VARCHAR(16777216), "DB_NAME" VARCHAR(16777216), "UTIL_SC" VARCHAR(16777216), "SRC_SC_1" VARCHAR(16777216), "SRC_SC_2" VARCHAR(16777216), "SRC_SC_3" VARCHAR(16777216), "SRC_SC_4" VARCHAR(16777216), "SRC_SC_5" VARCHAR(16777216), "SRC_SC_6" VARCHAR(16777216), "WRK_SC" VARCHAR(16777216), "TGT_SC" VARCHAR(16777216), "WH" VARCHAR(16777216), "CURR_DATE" DATE)
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

V_CURRENT_DATE DATE := :CURR_DATE;

V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := :DB_NAME||''.''||COALESCE(:UTIL_SC, ''UTIL'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';

V_PROCESS_NAME   VARCHAR DEFAULT ''CAMPAIGN_DASHBOARD'';

V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''CAMPAIGN_DASHBOARD'';

V_STEP             VARCHAR;

V_STEP_NAME        VARCHAR;

V_START_TIME       VARCHAR;

V_END_TIME         VARCHAR;

V_ROWS_PARSED       INTEGER;

V_ROWS_LOADED       INTEGER;

V_MESSAGE          VARCHAR;

V_LAST_QUERY_ID    VARCHAR;

V_TRANS_DAY VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.TRANS_DAY''; 

V_F_PREM_TRANS_DAY VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_2, ''BDR_DM'') || ''.F_PREM_TRANS_DAY'';

V_VOLN_LAPSE_DAILY VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.VOLN_LAPSE_DAILY'';

V_EMAIL_CAMPAIGN_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.EMAIL_CAMPAIGN_1'';

V_DEATH_LAPSE_DM VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.DEATH_LAPSE_DM'';

V_D_PLN_BEN_MOD VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_3, ''BDR_CONF'') || ''.D_PLN_BEN_MOD'';

V_D_GEO_XREF VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_3, ''BDR_CONF'') || ''.D_GEO_XREF'';

V_D_ST VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_3, ''BDR_CONF'') || ''.D_ST'';

V_D_MBR_INFO VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_3, ''BDR_CONF'') || ''.D_MBR_INFO'';

V_D_CERT_ACTV VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_3, ''BDR_CONF'') || ''.D_CERT_ACTV'';

V_LAPSE_DAILY VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.LAPSE_DAILY'';

V_STR_LAPSE_DAILY VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.STR_LAPSE_DAILY'';

V_MEMBERSHIP_DAILY VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.MEMBERSHIP_DAILY'';

V_D_ACQN_CHNL VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_3, ''BDR_CONF'') || ''.D_ACQN_CHNL'';

V_MEMBER_DATA_CAM_DAILY VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.MEMBER_DATA_CAM_DAILY'';

V_DM_BASE VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.DM_BASE'';

V_MARKETING_CONTACT VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_1, ''BDR_SMART'') || ''.MARKETING_CONTACT'';

V_PERSON VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_1, ''BDR_SMART'') || ''.PERSON'';

V_CAMPAIGN_EXTRACT VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_1, ''BDR_SMART'') || ''.CAMPAIGN_EXTRACT'';

V_SM_CAMPAIGN VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_1, ''BDR_SMART'') || ''.SM_CAMPAIGN'';

V_VALPROP_CHAR VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_1, ''BDR_SMART'') || ''.VALPROP_CHAR'';

V_DM_BASE_V2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.DM_BASE_V2'';

V_EMAIL_DETAILS VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.EMAIL_DETAILS'';

V_EM_CONTACT_RESPONSE VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_1, ''BDR_SMART'') || ''.EM_CONTACT_RESPONSE'';

V_EMAIL_CAMPAIGN VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.EMAIL_CAMPAIGN'';

V_EM_EVENT_TYPE VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_1, ''BDR_SMART'') || ''.EM_EVENT_TYPE'';

V_PULL_PERSON VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.PULL_PERSON'';

V_PULL_AMERILINK VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.PULL_AMERILINK'';

V_AMERILINK_DATA VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_1, ''BDR_SMART'') || ''.AMERILINK_DATA'';

V_PULL_PERSON_8 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.PULL_PERSON_8'';

V_PERSON_ADDRESS_CURR_PERM VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_1, ''BDR_SMART'') || ''.PERSON_ADDRESS_CURR_PERM'';

V_DISPOSITION VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.DISPOSITION'';

V_TM_CONTACT_RESPONSE VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_1, ''BDR_SMART'') || ''.TM_CONTACT_RESPONSE'';

V_DISPOSITION_REASON VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_1, ''BDR_SMART'') || ''.DISPOSITION_REASON''; 

V_WEB_REG VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.WEB_REG'';

V_AC_WEB_REGISTRATION VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_1, ''BDR_SMART'') || ''.V_AC_WEB_REGISTRATION'';

V_DM_CAMP_EB VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.DM_CAMP_EB'';

V_EFT VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.EFT'';

V_PERSON_PAYMENT_METHOD VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_1, ''BDR_SMART'') || ''.PERSON_PAYMENT_METHOD'';

V_TEMP VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.TEMP'';

V_DM_CAMP_EFT_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.DM_CAMP_EFT_1'';

V_TEMP1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.TEMP1'';

V_SHIP_PERSON_XREF VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_1, ''BDR_SMART'') || ''.SHIP_PERSON_XREF'';

V_AUXILIARY_PERSON VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_4, ''SRC_COMPAS'') || ''.AUXILIARY_PERSON'';

V_TEMP2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.TEMP2'';

V_SHIP VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.SHIP'';

V_NHL_201567_DB_ICUE VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_5, ''SRC_FIN360'') || ''.NHL_201567_DB_ICUE''; 

V_NHL_3 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.NHL_3'';

V_VAS_HNW_MASTER VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.VAS_HNW_MASTER'';

V_DM_DIME_2021 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.DM_DIME_2021'';

V_CALLS_BASE VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.CALLS_BASE'';

V_PERSON_HCO_CONTACT_REQUEST VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_1, ''BDR_SMART'') || ''.PERSON_HCO_CONTACT_REQUEST'';

V_DM_CALL VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.DM_CALL'';

V_HCO_CONTACT_REASON_TYPE VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_1, ''BDR_SMART'') || ''.HCO_CONTACT_REASON_TYPE'';

V_HCO_CONTACT_REASON_SUB_TYPE VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_1, ''BDR_SMART'') || ''.HCO_CONTACT_REASON_SUB_TYPE'';

V_CALL_SUMM VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.CALL_SUMM'';

V_DM_BASE_CALLS VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.DM_BASE_CALLS'';

V_APPS_RPTG_DAILY VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_6, ''SRC_MPO'') || ''.APPS_RPTG_DAILY'';

V_PAID_SALE VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.PAID_SALE'';

V_STATE_DM VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.STATE_DM'';

V_STATE VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_1, ''BDR_SMART'') || ''.STATE'';

V_VOL_LAPSE_DM VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.VOL_LAPSE_DM'';

V_SWITCH_DM VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.SWITCH_DM'';

V_TENURE_DM VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.TENURE_DM'';

V_OBCALL_BASE_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.OBCALL_BASE_1'';

V_MYDIRECTIVES_ADVANCE_CARE VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_1, ''BDR_SMART'') || ''.MYDIRECTIVES_ADVANCE_CARE'';

V_ACP_2023_24 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.ACP_2023_24'';

V_ACP_2024_25 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.ACP_2024_25'';

V_SUMM_DATA_CAMPAIGN_2025 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.SUMM_DATA_CAMPAIGN_2025'';

V_MEMBER_COUNTV1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.MEMBER_COUNTV1'';

V_PDP_INDV_MBR_CONT VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_5, ''SRC_FIN360'') || ''.PDP_INDV_MBR_CONT'';

V_MEMBER_INFO_V1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.MEMBER_INFO_V1'';

V_MEMBER_INFO_PERSUPV2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.MEMBER_INFO_PERSUPV2'';

V_SUMM_DATA_CAMPAIGN_2025_TESTV1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.SUMM_DATA_CAMPAIGN_2025_TESTV1'';

V_SUMM_DATA_CAMPAIGN_2025_TESTV3 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.SUMM_DATA_CAMPAIGN_2025_TESTV3'';

V_SUMM_CAMPAIGN_2025_TESTV4 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.SUMM_CAMPAIGN_2025_TESTV4'';

BEGIN

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP1'';

V_STEP_NAME :=  ''Create table trans_day'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_TRANS_DAY) COPY GRANTS as select d_mbr_info_sk, prdct_eff_dt_id, CERT_EFF_DT_ID, TERM_CERT_QTY,
D_PLN_BEN_MOD_SK, PREM_DUE_DT_ID, PD_CERT_QTY, DELQ_CERT_QTY,prdct_D_ACQN_CHNL_SK, d_cert_actv_sk,RES_D_GEO_XREF_SK
from IDENTIFIER(:V_F_PREM_TRANS_DAY) where PREM_DUE_DT_ID >= 20240101; 


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_TRANS_DAY)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP2'';

V_STEP_NAME :=  ''Create voln_lapse_daily'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table  IDENTIFIER(:V_VOLN_LAPSE_DAILY) COPY GRANTS as  
select  PREM_DUE_dt_ID,prdct_eff_dt_id,CERT_EFF_dt_ID,pers_id,a16.CERT_ACTV_LVL_2_TXT,a16.CERT_ACTV_LVL_1_TXT
,a11.d_cert_actv_sk,
sum(a11.TERM_CERT_QTY) as term
from IDENTIFIER(:V_TRANS_DAY) a11
left outer join  IDENTIFIER(:V_D_PLN_BEN_MOD) a12
on (a11.D_PLN_BEN_MOD_SK = a12.D_PLN_BEN_MOD_SK)
left outer join  IDENTIFIER(:V_D_GEO_XREF)     a13
on        (a11.RES_D_GEO_XREF_SK = a13.D_GEO_XREF_SK)
left outer join     IDENTIFIER(:V_D_ST)     a14
on        (a13.D_ST_CD = a14.D_ST_CD)
left join IDENTIFIER(:V_D_MBR_INFO) a15
on a11.d_mbr_info_sk = a15.d_mbr_info_sk
left join  IDENTIFIER(:V_D_CERT_ACTV)   a16
on (a11.D_CERT_ACTV_SK = a16.D_CERT_ACTV_SK)
where (trim(a12.LF_CATGY_NM) in (''Med Supp-Pre-Standardized'', ''Med Supp-Select'', ''Med Supp-Standardized/Modernized'')
and (a11.d_cert_actv_sk between 19 and 49 or a11.d_cert_actv_sk between 3 and 11)) 
group by PREM_DUE_dt_ID,prdct_eff_dt_id,CERT_EFF_dt_ID,pers_id,a16.CERT_ACTV_LVL_2_TXT,a16.CERT_ACTV_LVL_1_TXT,
a11.d_cert_actv_sk
having term > 0;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_VOLN_LAPSE_DAILY)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP3'';

V_STEP_NAME :=  ''Create LAPSE_DAILY'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_LAPSE_DAILY) COPY GRANTS as 
select a.* from (
select b.*,
row_number() over (partition by pers_id order by pers_id, PREM_DUE_dt_ID desc) rn
from IDENTIFIER(:V_VOLN_LAPSE_DAILY) b) a
where rn =1;



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_LAPSE_DAILY)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP4'';

V_STEP_NAME :=  ''Create STR_LAPSE_DAILY'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_STR_LAPSE_DAILY) AS 
select a.*, 
cast(concat(substr(str_date,1,4),''-'', substr(str_date,5,2),''-'',substr(str_date,7,2)) as date) as prem_due_date from
(select pers_id, d_cert_actv_sk,CERT_ACTV_LVL_2_TXT,CERT_ACTV_LVL_1_TXT,
cast(PREM_DUE_dt_ID as string) as str_date, term from IDENTIFIER(:V_LAPSE_DAILY))a;

drop table if exists  IDENTIFIER(:V_VOLN_LAPSE_DAILY);
drop table if exists  IDENTIFIER(:V_LAPSE_DAILY);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_STR_LAPSE_DAILY)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP5'';

V_STEP_NAME :=  ''Create MEMBERSHIP_DAILY'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_MEMBERSHIP_DAILY) COPY GRANTS AS 
select distinct * from (select PREM_DUE_dt_ID,prdct_eff_dt_id,CERT_EFF_dt_ID, a15.pers_id
,a23.ACQN_CHNL_LVL_1 as prod_ACQN_CHNL_LVL_1,
a12.pln_lvl,
sum(a11.PD_CERT_QTY + a11.DELQ_CERT_QTY)  as cert_cnt
from IDENTIFIER(:V_TRANS_DAY) a11
left outer join     IDENTIFIER(:V_D_PLN_BEN_MOD)          a12
on        (a11.D_PLN_BEN_MOD_SK = a12.D_PLN_BEN_MOD_SK)
left join  IDENTIFIER(:V_D_MBR_INFO) a15
on a11.d_mbr_info_sk = a15.d_mbr_info_sk
left join IDENTIFIER(:V_D_ACQN_CHNL) a23
on (a11.prdct_D_ACQN_CHNL_SK = a23.D_ACQN_CHNL_SK)
where (trim(a12.LF_CATGY_NM) in (''Med Supp-Pre-Standardized'', ''Med Supp-Select'', ''Med Supp-Standardized/Modernized''))  
group by PREM_DUE_dt_ID,prdct_eff_dt_id,CERT_EFF_dt_ID, pers_id
,a23.ACQN_CHNL_LVL_1
,a12.pln_lvl having cert_cnt > 0)b;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_MEMBERSHIP_DAILY)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP6'';

V_STEP_NAME :=  ''Create MEMBER_DATA_CAM_DAILY'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_MEMBER_DATA_CAM_DAILY) COPY GRANTS AS 
select a.pers_id,a.prdct_eff_dt_id,a.pln_lvl,a.prod_ACQN_CHNL_LVL_1,a.rn,a.str_date2,
cast(concat(substr(str_date2,1,4),''-'', substr(str_date2,5,2),''-'',substr(str_date2,7,2)) as date) as prdct_eff_date
from (select b.*, 
cast(prdct_eff_dt_id as string) as str_date2 from 
(select *
from (select pers_id, prdct_eff_dt_id, pln_lvl,prod_ACQN_CHNL_LVL_1,PREM_DUE_dt_ID,
row_number() over (partition by pers_id order by
prdct_eff_dt_id desc,PREM_DUE_dt_ID) as rn from IDENTIFIER(:V_MEMBERSHIP_DAILY) as a)temp where rn = 1) b)a;

drop table if exists  IDENTIFIER(:V_MEMBERSHIP_DAILY);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_MEMBER_DATA_CAM_DAILY)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP7'';

V_STEP_NAME :=  ''Create dm_base'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_DM_BASE) COPY GRANTS as
SELECT mc.MKT_CONTACT_ID,
mc.PERSON_ID,
mc.CAMPAIGN_EXTRACT_ID,
ce.source_code,
p.first_name,
p.last_name,
mc.PERSON_BIRTH_DATE as BIRTH_DATE,
mc.mail_to_zip_code as ZIP_CODE,
ce.extract_date,
mc.AARP_MEMBER_IND as Member_Status,
MC.MAIL_TO_STATE_CODE AS STATE,
smc.INITIATIVE,
smc.NAME,
valp.channel_code,
ce.cellcode,
ce.CELLNAME
,smc.CAMPAIGNCODE
,valp.VALPROP_NAME
,valp.VALPROP_TYPE_CODE
,ce.ACTUAL_DROP_DATE
FROM  IDENTIFIER(:V_MARKETING_CONTACT) as mc

left join IDENTIFIER(:V_PERSON) as p
on mc.PERSON_ID=p.PERSON_ID

Inner join IDENTIFIER(:V_CAMPAIGN_EXTRACT) as ce
on mc.CAMPAIGN_EXTRACT_ID=ce.CAMPAIGN_EXTRACT_ID

Inner join IDENTIFIER(:V_SM_CAMPAIGN) as smc
on ce.CAMPAIGNID=smc.CAMPAIGNID

left join IDENTIFIER(:V_VALPROP_CHAR) as valp
on ce.valprop_trkg_code=valp.valprop_trkg_code
where smc.CAMPAIGNCODE in (
''C000004094'',
''C000004004'',
''C000002230'',
''C000004090'',
''C000002487'',
''C000002600'',
''C000004162'',
''C000004115'',
''C000003992'',
''C000003594'',
''C000004273'',
''C000003802'',
''C000003804'',
''C000003737'',
''C000004126'',
''C000003547'',
''C000003548'',
''C000003862'',
''C000004092'',
''C000003601'',
''C000003454'',
''C000003695'',
''C000003460'',
''C000003471'',
''C000003490'',
''C000003491'',
''C000003492'',
''C000003501'',
''C000004151'',
''C000004140'',
''C000004138'',
''C000004136'',
''C000004286'',
''C000004288'',
''C000004297'',
''C000003998'',
''C000004044'',
''C000001275'',
''C000003510'',
''C000001383'',
''C000001255'',
''C000002584'',
''C000004275'',
''C000004198'',
''C000003933'',
''C000004118'',
''C000004271'',
''C000002602'',
''C000003444'',
''C000003864'',
''C000003446'',
''C000001948'',
''C000004291'',
''C000004243'',
''C000004295'',
''C000004299'',
''C000001670'',
''C000004317'',
''C000004279'',
''C000004319'',
''C000004321'',
''C000003978'',
''C000004376'',
''C000004374'',
''C000004389'',
''C000004428'',
''C000004178'',
''C000004181'',
''C000004241'',
''C000004261'',
''C000004284'',
''C000004329'',
''C000004384'',
''C000004386'',
''C000004402'',
''C000003530'',
''C000004202'',
''C000004265'',
''C000004315'',
''C000004424'',
''C000004426'',
''C000004170'',
''C000004224'',
''C000004239'',
''C000004323'',
''C000004325'',
''C000004327'',
''C000004343'',
''C000004382'',
''C000004385'',
''C000004418'',
''C000004160'',
''C000004249'',
''C000004281'',
''C000004388'',
''C000004404'',
''C000004420'',
''C000004492'',
''C000004494'',
''C000004496'',
''C000004498'',
''C000004500'',
''C000004483'',
''C000004503'',   
''C000004505'',   
''C000004507'',   
''C000004509'',   
''C000004526'',
''C000004444'',   
''C000004462'',   
''C000004554'',   
''C000004546'',   
''C000004548'',   
''C000004550'',   
''C000004552'',   
''C000004558'',   
''C000004561'',   
''C000004184'',   
''C000003425'',    
''C000004632''
)
and
valp.channel_code in (''DM'',''EM'',''TM'')   
and ce.actual_drop_date >= ''2024-01-01''    
and ce.actual_drop_date < ''2026-01-01'';   

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DM_BASE)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP8'';

V_STEP_NAME :=  ''Create DM_BASE_V2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DM_BASE_V2) COPY GRANTS as select * from IDENTIFIER(:V_DM_BASE) where
campaigncode in (select distinct campaigncode from IDENTIFIER(:V_DM_BASE) where year(actual_drop_date)= 2025);    



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DM_BASE_V2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP9'';

V_STEP_NAME :=  ''Create EMAIL_DETAILS'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_EMAIL_DETAILS) COPY GRANTS as
select a.CAMPAIGNCODE, a.CAMPAIGN_EXTRACT_ID,a.MKT_CONTACT_ID, a.person_id,a.first_name, a.last_name,  a.BIRTH_DATE, 
a.extract_date, a.initiative, a.name, a.actual_drop_date, a.channel_code,
case when em_event_type_id is not NULL then em_event_type_id else 0 end as em_event_type_id, c.EM_EVENT_TIMESTAMP
from IDENTIFIER(:V_DM_BASE_V2) a 
left join (select mkt_contact_id, em_event_type_id, EM_EVENT_TIMESTAMP 
from IDENTIFIER(:V_EM_CONTACT_RESPONSE) where to_date(EM_EVENT_TIMESTAMP) between ''2024-01-01'' and ''2026-01-31'') c 
on a.MKT_CONTACT_ID=c.MKT_CONTACT_ID;
    

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EMAIL_DETAILS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP10'';

V_STEP_NAME :=  ''Create Email_campaign'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_EMAIL_CAMPAIGN) COPY GRANTS as 
select  MKT_CONTACT_ID,
max(case when (trim(em_event_type)  = ''BOUNCE'' and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP)) <=7 
and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP)) >=0 
and to_date(EM_EVENT_TIMESTAMP) is not null) then 1 else 0 end) as BOUNCE_1week,
max(case when (trim(em_event_type)  = ''BOUNCE''  and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP))<=14 and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP)) >=0 and to_date(EM_EVENT_TIMESTAMP) is not null) then 1 else 0 end) as BOUNCE_2week,
max(case when (trim(em_event_type)  = ''BOUNCE''  and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP))<=21 and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP)) >=0 and to_date(EM_EVENT_TIMESTAMP) is not null) then 1 else 0 end) as BOUNCE_3week,
max(case when (trim(em_event_type)  = ''BOUNCE''  and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP))<=28 and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP)) >=0 and to_date(EM_EVENT_TIMESTAMP) is not null) then 1 else 0 end) as BOUNCE_4week,

max(case when (trim(em_event_type)  = ''CLICK'' and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP)) <=7 and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP)) >=0 and to_date(EM_EVENT_TIMESTAMP) is not null) then 1 else 0 end) as CLICK_1week,
max(case when (trim(em_event_type)  = ''CLICK'' and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP))<=14 and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP)) >=0 and to_date(EM_EVENT_TIMESTAMP) is not null) then 1 else 0 end) as CLICK_2week,
max(case when (trim(em_event_type)  = ''CLICK'' and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP))<=21 and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP)) >=0 and to_date(EM_EVENT_TIMESTAMP) is not null) then 1 else 0 end) as CLICK_3week,
max(case when (trim(em_event_type)  = ''CLICK'' and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP))<=28 and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP)) >=0 and to_date(EM_EVENT_TIMESTAMP) is not null) then 1 else 0 end) as CLICK_4week,

max(case when (trim(em_event_type)  = ''NOT SENT'' and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP)) <=7 and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP)) >=0 and to_date(EM_EVENT_TIMESTAMP) is not null) then 1 else 0 end) as NOT_SENT_1week,
max(case when (trim(em_event_type)  = ''NOT SENT'' and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP))<=14 and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP)) >=0 and to_date(EM_EVENT_TIMESTAMP) is not null) then 1 else 0 end) as NOT_SENT_2week,
max(case when (trim(em_event_type)  = ''NOT SENT'' and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP))<=21 and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP)) >=0 and to_date(EM_EVENT_TIMESTAMP) is not null) then 1 else 0 end) as NOT_SENT_3week,
max(case when (trim(em_event_type)  = ''NOT SENT'' and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP))<=28 and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP)) >=0 and to_date(EM_EVENT_TIMESTAMP) is not null) then 1 else 0 end) as NOT_SENT_4week,

max(case when (trim(em_event_type)  = ''OPEN'' and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP)) <=7 and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP)) >=0 and to_date(EM_EVENT_TIMESTAMP) is not null) then 1 else 0 end) as OPEN_1week,
max(case when (trim(em_event_type)  = ''OPEN'' and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP))<=14 and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP)) >=0 and to_date(EM_EVENT_TIMESTAMP) is not null) then 1 else 0 end) as OPEN_2week,
max(case when (trim(em_event_type)  = ''OPEN'' and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP))<=21 and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP)) >=0 and to_date(EM_EVENT_TIMESTAMP) is not null) then 1 else 0 end)as OPEN_3week,
max(case when (trim(em_event_type)  = ''OPEN'' and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP))<=28 and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP)) >=0 and to_date(EM_EVENT_TIMESTAMP) is not null) then 1 else 0 end) as OPEN_4week,

max(case when (trim(em_event_type)  = ''SENT'' and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP)) <=7 and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP)) >=0 and to_date(EM_EVENT_TIMESTAMP) is not null) then 1 else 0 end) as SENT_1week,
max(case when (trim(em_event_type)  = ''SENT'' and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP))<=14 and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP)) >=0 and to_date(EM_EVENT_TIMESTAMP) is not null) then 1 else 0 end) as SENT_2week,
max(case when (trim(em_event_type)  = ''SENT'' and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP))<=21 and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP)) >=0 and to_date(EM_EVENT_TIMESTAMP) is not null) then 1 else 0 end) as SENT_3week,
max(case when (trim(em_event_type)  = ''SENT'' and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP))<=28 and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP)) >=0 and to_date(EM_EVENT_TIMESTAMP) is not null) then 1 else 0 end) as SENT_4week,

max(case when (trim(em_event_type)  = ''SUBSCRIBE'' and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP)) <=7 and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP)) >=0 and to_date(EM_EVENT_TIMESTAMP) is not null) then 1 else 0 end) as SUBSCRIBE_1week,
max(case when (trim(em_event_type)  = ''SUBSCRIBE'' and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP))<=14 and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP)) >=0 and to_date(EM_EVENT_TIMESTAMP) is not null) then 1 else 0 end) as SUBSCRIBE_2week,
max(case when (trim(em_event_type)  = ''SUBSCRIBE'' and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP))<=21 and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP)) >=0 and to_date(EM_EVENT_TIMESTAMP) is not null) then 1 else 0 end) as SUBSCRIBE_3week,
max(case when (trim(em_event_type)  = ''SUBSCRIBE'' and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP))<=28 and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP)) >=0 and to_date(EM_EVENT_TIMESTAMP) is not null) then 1 else 0 end) as SUBSCRIBE_4week,

max(case when (trim(em_event_type)  = ''UNSUBSCRIBE'' and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP)) <=7 and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP)) >=0 and to_date(EM_EVENT_TIMESTAMP) is not null) then 1 else 0 end) as UNSUBSCRIBE_1week,
max(case when (trim(em_event_type)  = ''UNSUBSCRIBE'' and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP))<=14 and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP)) >=0 and to_date(EM_EVENT_TIMESTAMP) is not null) then 1 else 0 end) as UNSUBSCRIBE_2week,
max(case when (trim(em_event_type)  = ''UNSUBSCRIBE'' and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP))<=21 and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP)) >=0 and to_date(EM_EVENT_TIMESTAMP) is not null) then 1 else 0 end) as UNSUBSCRIBE_3week,
max(case when (trim(em_event_type)  = ''UNSUBSCRIBE'' and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP))<=28 and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP)) >=0 and to_date(EM_EVENT_TIMESTAMP) is not null) then 1 else 0 end) as UNSUBSCRIBE_4week

from  IDENTIFIER(:V_EMAIL_DETAILS) a left join IDENTIFIER(:V_EM_EVENT_TYPE) b
on a.EM_EVENT_TYPE_ID = b.EM_EVENT_TYPE_ID
group by  MKT_CONTACT_ID;



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EMAIL_CAMPAIGN)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP11'';

V_STEP_NAME :=  ''Create email_campaign_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EMAIL_CAMPAIGN_1) COPY GRANTS as
select a.*,bounce_1week,
bounce_2week
,bounce_3week
,bounce_4week
,click_1week
,click_2week
,click_3week
,click_4week
,not_sent_1week
,not_sent_2week
,not_sent_3week
,not_sent_4week
,open_1week
,open_2week
,open_3week
,open_4week
,sent_1week
,sent_2week
,sent_3week
,sent_4week
,subscribe_1week
,subscribe_2week
,subscribe_3week
,subscribe_4week
,unsubscribe_1week
,unsubscribe_2week
,unsubscribe_3week
,unsubscribe_4week
from IDENTIFIER(:V_DM_BASE_V2) as a left join IDENTIFIER(:V_EMAIL_CAMPAIGN) as b
on a.mkt_contact_id = b.mkt_contact_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EMAIL_CAMPAIGN_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP12'';

V_STEP_NAME :=  ''Create pull_person'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_PULL_PERSON) COPY GRANTS as
select a.*,b.GENDER_CODE,b.birth_date as person_birth_date
from  IDENTIFIER(:V_EMAIL_CAMPAIGN_1) as a left join (select person_id, gender_code, birth_date from IDENTIFIER(:V_PERSON)) b 
on b.person_id=a.person_id;
 


drop table if exists  IDENTIFIER(:V_EMAIL_CAMPAIGN_1);
drop table if exists  IDENTIFIER(:V_EMAIL_DETAILS);
drop table if exists  IDENTIFIER(:V_EMAIL_CAMPAIGN);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_PULL_PERSON)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP13'';

V_STEP_NAME :=  ''Create pull_amerilink'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_PULL_AMERILINK) COPY GRANTS as
select a.*, b.ESTINC19
from IDENTIFIER(:V_PULL_PERSON) as a left join (select person_id, ESTINC19 from IDENTIFIER(:V_AMERILINK_DATA)) b
on a.person_id=b.person_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_PULL_AMERILINK)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP14'';

V_STEP_NAME :=  ''Create pull_person_8'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_PULL_PERSON_8) COPY GRANTS as
select a.*,state_code,b.zip_code as zp_cd,
county_code,zip_code_plus_4,
cast(concat(cast(year(actual_drop_date) as string),''-'', cast(month(actual_drop_date) as string),''-'',''01'') as date) as actual_drop_date2
from IDENTIFIER(:V_PULL_AMERILINK) as a left join 
IDENTIFIER(:V_PERSON_ADDRESS_CURR_PERM) b 
on b.person_id=a.person_id;
             

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_PULL_PERSON_8)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP15'';

V_STEP_NAME :=  ''Create disposition'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table  IDENTIFIER(:V_DISPOSITION) COPY GRANTS as select a.*,
b.disposition_code, b.disposition_reason_code, c.disposition_reason_desc from IDENTIFIER(:V_PULL_PERSON_8) a left join 
IDENTIFIER(:V_TM_CONTACT_RESPONSE) b
on a.mkt_contact_id = b.mkt_contact_id
left join IDENTIFIER(:V_DISPOSITION_REASON) c on b.DISPOSITION_REASON_CODE=c.DISPOSITION_REASON_CODE;

drop table if exists  IDENTIFIER(:V_PULL_PERSON);
drop table if exists  IDENTIFIER(:V_PULL_AMERILINK);
drop table if exists  IDENTIFIER(:V_PULL_PERSON_8);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DISPOSITION)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP16'';

V_STEP_NAME :=  ''Create WEB_REG'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_WEB_REG) COPY GRANTS as 
select a.*,wr.calculated_web_registration_date from IDENTIFIER(:V_DISPOSITION) as a 
left join (select person_id, calculated_web_registration_date from IDENTIFIER(:V_AC_WEB_REGISTRATION)) wr
on  wr.person_id = a.person_id;
           


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_WEB_REG)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP17'';

V_STEP_NAME :=  ''Create DM_CAMP_EB'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_DM_CAMP_EB) COPY GRANTS as
select distinct * from(select a.*,
case when datediff(day,actual_drop_date,calculated_web_registration_date)>=0 
and datediff(day,actual_drop_date,calculated_web_registration_date)<=30 then 1 else 0 end as web_rg_1mnth, 
case when datediff(day,actual_drop_date,calculated_web_registration_date)>=0 
and datediff(day,actual_drop_date,calculated_web_registration_date)<=60 then 1 else 0 end as web_rg_2mnth, 
case when datediff(day,actual_drop_date,calculated_web_registration_date)>=0 
and datediff(day,actual_drop_date,calculated_web_registration_date)<=90 then 1 else 0 end as web_rg_3mnth, 
case when datediff(day,actual_drop_date,calculated_web_registration_date)>=0 
and datediff(day,actual_drop_date,calculated_web_registration_date)<=180 then 1 else 0 end as web_rg_6mnth
from IDENTIFIER(:V_WEB_REG) as a)c;
               

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DM_CAMP_EB)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP18'';

V_STEP_NAME :=  ''Create eft'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_EFT) COPY GRANTS as 
select a.*, 
case when (ppm.PAYMENT_METHOD_CODE=3 
and ppm.BEGIN_DATE >= a.ACTUAL_DROP_DATE
and (ppm.end_date >= a.ACTUAL_DROP_DATE or ppm.end_date is NULL)) then ppm.eft_frequency_type_id else NULL END AS eft_frequency_type_id, 
case when (ppm.PAYMENT_METHOD_CODE=3 
and ppm.BEGIN_DATE >= a.ACTUAL_DROP_DATE
and (ppm.end_date >= a.ACTUAL_DROP_DATE or ppm.end_date is NULL)) then ppm.person_id else NULL end as eft_pers_id, 
case when (ppm.PAYMENT_METHOD_CODE=3 
and ppm.BEGIN_DATE >= a.ACTUAL_DROP_DATE
and (ppm.end_date >= a.ACTUAL_DROP_DATE or ppm.end_date is NULL)) then ppm.begin_date else NULL end as begin_date,
case when (ppm.PAYMENT_METHOD_CODE=3 
and ppm.BEGIN_DATE >= a.ACTUAL_DROP_DATE
and (ppm.end_date >= a.ACTUAL_DROP_DATE or ppm.end_date is NULL)) then ppm.end_date else NULL end as end_date
from IDENTIFIER(:V_DM_CAMP_EB) as a left join IDENTIFIER(:V_PERSON_PAYMENT_METHOD) ppm
on  ppm.person_id = a.person_id;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EFT)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP19'';

V_STEP_NAME :=  ''Create temp'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_TEMP) COPY GRANTS as select  mkt_contact_id,
max(case when (BEGIN_DATE >= ACTUAL_DROP_DATE and eft_pers_id is not NULL )then 1
else 0 end) as eft_flg,
max(CASE when datediff(day,ACTUAL_DROP_DATE,BEGIN_DATE)>=0 
AND datediff(day,ACTUAL_DROP_DATE,BEGIN_DATE)<=30 
AND eft_frequency_type_id = 2
and eft_pers_id is not NULL THEN 1 ELSE 0 END) AS OT_1MNTH,

max(case when datediff(day,ACTUAL_DROP_DATE,BEGIN_DATE)>=0 
AND datediff(day,ACTUAL_DROP_DATE,BEGIN_DATE)<=60 
AND eft_frequency_type_id = 2 
and eft_pers_id is not NULL THEN 1 ELSE 0 END) AS OT_2MNTH,

max(case when datediff(day,ACTUAL_DROP_DATE,BEGIN_DATE)>=0 
AND datediff(day,ACTUAL_DROP_DATE,BEGIN_DATE)<=90 
AND eft_frequency_type_id = 2
and eft_pers_id is not NULL THEN 1 ELSE 0 END) AS OT_3MNTH,

max(case when datediff(day,ACTUAL_DROP_DATE,BEGIN_DATE)>=0 
AND datediff(day,ACTUAL_DROP_DATE,BEGIN_DATE)<=180 
AND eft_frequency_type_id = 2
and eft_pers_id is not NULL THEN 1 ELSE 0 END) AS OT_6MNTH,

max(CASE when datediff(day,ACTUAL_DROP_DATE,BEGIN_DATE)>=0 
AND datediff(day,ACTUAL_DROP_DATE,BEGIN_DATE)<=30 
AND eft_frequency_type_id = 1
and eft_pers_id is not NULL THEN 1 ELSE 0 END) AS REC_1MNTH,

max(case when datediff(day,ACTUAL_DROP_DATE,BEGIN_DATE)>=0 
AND datediff(day,ACTUAL_DROP_DATE,BEGIN_DATE)<=60 
AND eft_frequency_type_id = 1 
and eft_pers_id is not NULL THEN 1 ELSE 0 END) AS REC_2MNTH,

max(case when datediff(day,ACTUAL_DROP_DATE,BEGIN_DATE)>=0 
AND datediff(day,ACTUAL_DROP_DATE,BEGIN_DATE)<=90 
AND eft_frequency_type_id = 1 
and eft_pers_id is not NULL THEN 1 ELSE 0 END) AS REC_3MNTH,

max(case when datediff(day,ACTUAL_DROP_DATE,BEGIN_DATE)>=0 
AND datediff(day,ACTUAL_DROP_DATE,BEGIN_DATE)<=180 
AND eft_frequency_type_id = 1 
and eft_pers_id is not NULL THEN 1 ELSE 0 END) AS REC_6MNTH
from IDENTIFIER(:V_EFT) as b group by mkt_contact_id;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_TEMP)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP20'';

V_STEP_NAME :=  ''Create dm_camp_eft_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DM_CAMP_EFT_1) COPY GRANTS as select a.*,eft_flg,
OT_1MNTH as ot_1mo,OT_2MNTH as ot_2mo,OT_3MNTH as ot_3mo,OT_6MNTH as ot_6mo,
REC_1MNTH as rec_1mo,REC_2MNTH as rec_2mo,REC_3MNTH as rec_3mo,REC_6MNTH as rec_6mo from
IDENTIFIER(:V_DM_CAMP_EB) as a left join IDENTIFIER(:V_TEMP) as b
on a.mkt_contact_id = b.mkt_contact_id;

drop table if exists  IDENTIFIER(:V_TEMP);
drop table if exists  IDENTIFIER(:V_DISPOSITION);
drop table if exists  IDENTIFIER(:V_WEB_REG);
drop table if exists  IDENTIFIER(:V_DM_CAMP_EB);

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DM_CAMP_EFT_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP21'';

V_STEP_NAME :=  ''Create temp1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_TEMP1) COPY GRANTS as 
select a.*, 
vap.creation_date as creation_date,AUXILIARY_PERSON_TYPE_ID,
xr.Ship_person_id as Ship_person_id, xr.UCPS_PERSON_ID
from  IDENTIFIER(:V_DM_CAMP_EFT_1) as a left join IDENTIFIER(:V_SHIP_PERSON_XREF) xr 
on  a.person_id = xr.person_id 
left join IDENTIFIER(:V_AUXILIARY_PERSON) vap 
on xr.Ship_person_id = vap.Individual_id;  

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_TEMP1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP22'';

V_STEP_NAME :=  ''Create TEMP2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_TEMP2) COPY GRANTS as
select mkt_contact_id,
max(case when datediff(day,actual_drop_date,to_date(creation_date)) is  not null and
datediff(day,actual_drop_date,to_date(creation_date)) >=0 
and AUXILIARY_PERSON_TYPE_ID=6 then 1 else 0 end) as priv_auth_flg,
max(case when datediff(day,actual_drop_date,to_date(creation_date)) >=0 
and datediff(day,actual_drop_date,to_date(creation_date))<=30 
and  AUXILIARY_PERSON_TYPE_ID=6 then 1 else 0 end) as priv_1mnth, 
max(case when datediff(day,actual_drop_date,to_date(creation_date)) >=0 
and datediff(day,actual_drop_date,to_date(creation_date))<=60 
and AUXILIARY_PERSON_TYPE_ID=6 then 1 else 0 end) as priv_2mnth,
max(case when datediff(day,actual_drop_date,to_date(creation_date)) >=0 
and datediff(day,actual_drop_date,to_date(creation_date))<=90 
and AUXILIARY_PERSON_TYPE_ID=6 then 1 else 0 end) as priv_3mnth,
max(case when datediff(day,actual_drop_date,to_date(creation_date)) >=0 
and datediff(day,actual_drop_date,to_date(creation_date))<=180 
and AUXILIARY_PERSON_TYPE_ID=6 then 1 else 0 end) as priv_6mnth
from IDENTIFIER(:V_TEMP1) 
group by
mkt_contact_id;



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_TEMP2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP23'';

V_STEP_NAME :=  ''Create SHIP'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_SHIP) COPY GRANTS as select b.*, a.priv_auth_flg,
a.priv_1mnth,a.priv_2mnth,a.priv_3mnth,a.priv_6mnth,cast(b.zip_code AS INT) as zip_code_num
,xr.Ship_person_id as Ship_person_id, xr.UCPS_PERSON_ID 
from IDENTIFIER(:V_TEMP2) as a left join IDENTIFIER(:V_DM_CAMP_EFT_1) as b on 
a.mkt_contact_id = b.mkt_contact_id
left join IDENTIFIER(:V_SHIP_PERSON_XREF) xr
on b.person_id = xr.person_id ;

drop table if exists  IDENTIFIER(:V_TEMP1);
drop table if exists  IDENTIFIER(:V_TEMP2);
drop table if exists  IDENTIFIER(:V_EFT);
drop table if exists  IDENTIFIER(:V_DM_CAMP_EFT_1);

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_SHIP)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP24'';

V_STEP_NAME :=  ''Create TEMP'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_TEMP) COPY GRANTS  as select mkt_contact_id, 
max(case when nhl.CONTACT_DATE is not null 
and nhl.CONTACT_DATE > ACTUAL_DROP_DATE then 1 else 0 end)
as nurse_health_line,
max(case when datediff(day,actual_drop_date,CONTACT_DATE) is not null and
datediff(day,actual_drop_date,CONTACT_DATE) >=0 and 
datediff(day,actual_drop_date,CONTACT_DATE) <=30 then 1 else 0 end) as nhl_1mnth, 
max(case when datediff(day,actual_drop_date,CONTACT_DATE) is not null and
datediff(day,actual_drop_date,CONTACT_DATE) >=0 and 
datediff(day,actual_drop_date,CONTACT_DATE) <=60 then 1 else 0 end) as nhl_2mnth, 
max(case when datediff(day,actual_drop_date,CONTACT_DATE) is not null and
datediff(day,actual_drop_date,CONTACT_DATE) >=0 and 
datediff(day,actual_drop_date,CONTACT_DATE) <=90 then 1 else 0 end) as nhl_3mnth,
max(case when datediff(day,actual_drop_date,CONTACT_DATE) is not null and
datediff(day,actual_drop_date,CONTACT_DATE) >=0 and 
datediff(day,actual_drop_date,CONTACT_DATE) <=180 then 1 else 0 end) as nhl_6mnth
from IDENTIFIER(:V_SHIP) a left join IDENTIFIER(:V_NHL_201567_DB_ICUE) nhl 
on a.zip_code_num = nhl.zip_code
and trim(a.first_name) = trim(nhl.first_name)
and trim(a.LAST_NAME) = trim(nhl.last_name)
and a.BIRTH_DATE = nhl.dob group by mkt_contact_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_TEMP)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP25'';

V_STEP_NAME :=  ''Create NHL_3'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_NHL_3) COPY GRANTS as select distinct * from( select a.*,
b.nurse_health_line,nhl_1mnth,nhl_2mnth,nhl_3mnth,
nhl_6mnth from IDENTIFIER(:V_SHIP) as a left join IDENTIFIER(:V_TEMP) as b on 
a.mkt_contact_id = b.mkt_contact_id)c;

drop table if exists  IDENTIFIER(:V_TEMP);
drop table if exists  IDENTIFIER(:V_SHIP);

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_NHL_3)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP26'';

V_STEP_NAME :=  ''Create temp1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_TEMP1) COPY GRANTS as 
select MKT_CONTACT_ID,

max(case 
	when opt.cognitive_fg = ''Yes''
	and datediff(day,tr.actual_drop_date2,opt.visit_month)>=0 
	and datediff(day,tr.actual_drop_date2,opt.visit_month)<=30 then 1 else 0 end) as VAS_staying_sharp_1mnth,
max(case 
	when opt.cognitive_fg = ''Yes''
	and datediff(day,tr.actual_drop_date2,opt.visit_month)>=0 
	and datediff(day,tr.actual_drop_date2,opt.visit_month)<=60 then 1 else 0 end) as VAS_staying_sharp_2mnth,
max(case 
	when opt.cognitive_fg = ''Yes''
	and datediff(day,tr.actual_drop_date2,opt.visit_month)>=0 
	and datediff(day,tr.actual_drop_date2,opt.visit_month)<=90 then 1 else 0 end) as VAS_staying_sharp_3mnth,
max(case 
	when opt.cognitive_fg = ''Yes''
	and datediff(day,tr.actual_drop_date2,opt.visit_month)>=0 
	and datediff(day,tr.actual_drop_date2,opt.visit_month)<=180 then 1 else 0 end) as VAS_staying_sharp_6mnth,	
	
max(case 
	when opt.gym_fg = ''Yes''
	and datediff(day,tr.actual_drop_date2,opt.visit_month)>=0 
	and datediff(day,tr.actual_drop_date2,opt.visit_month)<=30 then 1 else 0 end) as VAS_renew_active_gym_1mnth,
max(case 
	when opt.gym_fg = ''Yes''
	and datediff(day,tr.actual_drop_date2,opt.visit_month)>=0 
	and datediff(day,tr.actual_drop_date2,opt.visit_month)<=60 then 1 else 0 end) as VAS_renew_active_gym_2mnth,
max(case 
	when opt.gym_fg = ''Yes''
	and datediff(day,tr.actual_drop_date2,opt.visit_month)>=0 
	and datediff(day,tr.actual_drop_date2,opt.visit_month)<=90 then 1 else 0 end) as VAS_renew_active_gym_3mnth,
max(case 
	when opt.gym_fg = ''Yes''
	and datediff(day,tr.actual_drop_date2,opt.visit_month)>=0 
	and datediff(day,tr.actual_drop_date2,opt.visit_month)<=180 then 1 else 0 end) as VAS_renew_active_gym_6mnth,	

max(case 
	when opt.digital_fg = ''Yes''
	and datediff(day,tr.actual_drop_date2,opt.visit_month)>=0 
	and datediff(day,tr.actual_drop_date2,opt.visit_month)<=30 then 1 else 0 end) as VAS_gym_1mnth,
max(case 
	when opt.digital_fg = ''Yes''
	and datediff(day,tr.actual_drop_date2,opt.visit_month)>=0 
	and datediff(day,tr.actual_drop_date2,opt.visit_month)<=60 then 1 else 0 end) as VAS_gym_2mnth,
max(case 
	when opt.digital_fg = ''Yes'' 
	and datediff(day,tr.actual_drop_date2,opt.visit_month)>=0 
	and datediff(day,tr.actual_drop_date2,opt.visit_month)<=90 then 1 else 0 end) as VAS_gym_3mnth,
max(case 
	when opt.digital_fg = ''Yes''
	and datediff(day,tr.actual_drop_date2,opt.visit_month)>=0 
	and datediff(day,tr.actual_drop_date2,opt.visit_month)<=180 then 1 else 0 end) as VAS_gym_6mnth ,

max(case 
	when opt.social_fg = ''Yes''
	and datediff(day,tr.actual_drop_date,opt.visit_month)>=0 
	and datediff(day,tr.actual_drop_date,opt.visit_month)<=30 then 1 else 0 end) as VAS_event_1mnth,
max(case 
	when opt.social_fg = ''Yes''
	and datediff(day,tr.actual_drop_date,opt.visit_month)>=0 
	and datediff(day,tr.actual_drop_date,opt.visit_month)<=60 then 1 else 0 end) as VAS_event_2mnth,
max(case 
	when opt.social_fg = ''Yes''
	and datediff(day,tr.actual_drop_date,opt.visit_month)>=0 
	and datediff(day,tr.actual_drop_date,opt.visit_month)<=90 then 1 else 0 end) as VAS_event_3mnth,
max(case 
	when opt.social_fg = ''Yes''
	and datediff(day,tr.actual_drop_date,opt.visit_month)>=0 
	and datediff(day,tr.actual_drop_date,opt.visit_month)<=180 then 1 else 0 end) as VAS_event_6mnth,
	
max(case 
	when opt.ons_fg = ''Yes''
	and datediff(day,tr.actual_drop_date,opt.visit_month)>=0 
	and datediff(day,tr.actual_drop_date,opt.visit_month)<=30 then 1 else 0 end) as ONS_1mnth,
max(case 
	when opt.ons_fg = ''Yes''
	and datediff(day,tr.actual_drop_date,opt.visit_month)>=0 
	and datediff(day,tr.actual_drop_date,opt.visit_month)<=60 then 1 else 0 end) as ONS_2mnth,
max(case 
	when opt.ons_fg = ''Yes''
	and datediff(day,tr.actual_drop_date,opt.visit_month)>=0 
	and datediff(day,tr.actual_drop_date,opt.visit_month)<=90 then 1 else 0 end) as ONS_3mnth,
max(case 
	when opt.ons_fg = ''Yes''
	and datediff(day,tr.actual_drop_date,opt.visit_month)>=0 
	and datediff(day,tr.actual_drop_date,opt.visit_month)<=180 then 1 else 0 end) as ONS_6mnth,	

max(case 
	when opt.nurseline_inbound_fg = ''Yes''
	and datediff(day,tr.actual_drop_date,opt.visit_month)>=0 
	and datediff(day,tr.actual_drop_date,opt.visit_month)<=30 then 1 else 0 end) as VAS_telephonic_1mnth,
max(case 
	when opt.nurseline_inbound_fg = ''Yes''
	and datediff(day,tr.actual_drop_date,opt.visit_month)>=0 
	and datediff(day,tr.actual_drop_date,opt.visit_month)<=60 then 1 else 0 end) as VAS_telephonic_2mnth,
max(case 
	when opt.nurseline_inbound_fg = ''Yes'' 
	and datediff(day,tr.actual_drop_date,opt.visit_month)>=0 
	and datediff(day,tr.actual_drop_date,opt.visit_month)<=90 then 1 else 0 end) as VAS_telephonic_3mnth,
max(case 
	when opt.nurseline_inbound_fg = ''Yes''
	and datediff(day,tr.actual_drop_date,opt.visit_month)>=0 
	and datediff(day,tr.actual_drop_date,opt.visit_month)<=180 then 1 else 0 end) as VAS_telephonic_6mnth 
from IDENTIFIER(:V_NHL_3) as tr left join IDENTIFIER(:V_VAS_HNW_MASTER) opt
on tr.PERSON_ID=opt.pers_id group by MKT_CONTACT_ID;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_TEMP1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP27'';

V_STEP_NAME :=  ''Create dm_dime_2021'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DM_DIME_2021) COPY GRANTS as select temp2.*,
case when VAS_cnt_6mo >=1 then ''Yes'' else ''No'' end as VAS_regst,
case when VAS_cnt_1mo >=1 then ''Yes'' else ''No'' end as VAS_reg_1mo,
case when VAS_cnt_2mo >=1 then ''Yes'' else ''No'' end as VAS_reg_2mo,
case when VAS_cnt_3mo >=1 then ''Yes'' else ''No'' end as VAS_reg_3mo,
case when VAS_cnt_6mo >=1 then ''Yes'' else ''No'' end as VAS_reg_6mo
from (select a.*,(ONS_1mnth+ VAS_gym_1mnth + VAS_renew_active_gym_1mnth + VAS_event_1mnth + VAS_staying_sharp_1mnth +
VAS_telephonic_1mnth) as VAS_cnt_1mo,
(ONS_2mnth+ VAS_gym_2mnth + VAS_renew_active_gym_2mnth + VAS_event_2mnth + VAS_staying_sharp_2mnth +
VAS_telephonic_2mnth) as VAS_cnt_2mo,
(ONS_3mnth+ VAS_gym_3mnth + VAS_renew_active_gym_3mnth + VAS_event_3mnth + VAS_staying_sharp_3mnth +
VAS_telephonic_3mnth) as VAS_cnt_3mo,
(ONS_6mnth+ VAS_gym_6mnth + VAS_renew_active_gym_6mnth + VAS_event_6mnth + VAS_staying_sharp_6mnth +
VAS_telephonic_6mnth) as VAS_cnt_6mo,
ONS_1mnth,ONS_2mnth,ONS_3mnth,ONS_6mnth,
VAS_gym_1mnth,VAS_gym_2mnth,VAS_gym_3mnth,VAS_gym_6mnth,
VAS_renew_active_gym_1mnth, VAS_renew_active_gym_2mnth, VAS_renew_active_gym_3mnth, VAS_renew_active_gym_6mnth,
VAS_event_1mnth,VAS_event_2mnth,VAS_event_3mnth,VAS_event_6mnth,
VAS_staying_sharp_1mnth,VAS_staying_sharp_2mnth,VAS_staying_sharp_3mnth,VAS_staying_sharp_6mnth,
VAS_telephonic_1mnth,VAS_telephonic_2mnth,VAS_telephonic_3mnth,VAS_telephonic_6mnth
from IDENTIFIER(:V_TEMP1) as b left join  IDENTIFIER(:V_NHL_3) as a on a.mkt_contact_id = b.mkt_contact_id)temp2;

drop table if exists  IDENTIFIER(:V_TEMP1);
drop table if exists  IDENTIFIER(:V_NHL_3);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DM_DIME_2021)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP28'';

V_STEP_NAME :=  ''Create calls_base'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_CALLS_BASE) COPY GRANTS as select person_id, HCO_CONTACT_REQUEST_ID, HCO_CONTACT_RSN_TYPE_CODE, HCO_CONTACT_RSN_SUB_TYPE_CODE,
inquiry_type, contact_date from IDENTIFIER(:V_PERSON_HCO_CONTACT_REQUEST)
where contact_date between ''2024-01-01'' and ''2026-06-30'';


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_CALLS_BASE)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP29'';

V_STEP_NAME :=  ''Create DM_CALL'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DM_CALL) COPY GRANTS as
select temp2.*,
case when trim(HCO_CONTACT_RSN_TYPE_NAME) = ''PLAN INQUIRY'' then 1 ELSE 0 end as PLAN_INQ,
case when trim(HCO_CONTACT_RSN_TYPE_NAME) = ''BILLING/PAYMENT INQUIRY'' then 1 ELSE 0 end as BILL_PAY_INQ,
case when trim(HCO_CONTACT_RSN_TYPE_NAME) = ''CLAIM INQUIRY'' then 1 ELSE 0 end as CLAIM_INQ,
case when trim(HCO_CONTACT_RSN_TYPE_NAME) = ''TELEMARKETING'' then 1 ELSE 0 end as TELEMARKETING_INQ,
case when trim(HCO_CONTACT_RSN_TYPE_NAME) = ''OPPORTUNITY'' then 1 ELSE 0 end as OPPRTNTY_INQ,
case when trim(HCO_CONTACT_RSN_TYPE_NAME) = ''AUTHORIZATION MAINTENANCE'' then 1 ELSE 0 end as AUTH_MAIN_INQ,
case when trim(HCO_CONTACT_RSN_TYPE_NAME) = ''AUTHORIZATION INQUIRY'' then 1 ELSE 0 end as AUTH_INQ,
case when trim(HCO_CONTACT_RSN_TYPE_NAME) = ''PROGRAM INQUIRY'' then 1 ELSE 0 end as PROGRAM_INQ,
case when trim(HCO_CONTACT_RSN_TYPE_NAME) = ''ENROLLMENT INQUIRY'' then 1 ELSE  0 end as ENRL_INQ,
case when trim(HCO_CONTACT_RSN_TYPE_NAME) = ''FULFILLMENT INQUIRY'' then 1 ELSE 0 end as FULFILL_INQ,
case when trim(HCO_CONTACT_RSN_TYPE_NAME) = ''REBILL/RERATE INQUIRY'' then  1 ELSE  0 end as REBILL_INQ,
case when trim(HCO_CONTACT_RSN_TYPE_NAME) = ''SILVER SNEAKERS'' then  1 ELSE 0 end as SILVER_INQ,
case when trim(HCO_CONTACT_RSN_TYPE_NAME) = ''WEB INQUIRY'' then 1 ELSE  0 end as WEB_INQ,
case when trim(HCO_CONTACT_RSN_TYPE_NAME) = ''DEMOGRAPHIC INQUIRY'' then 1 ELSE 0 end as DEMOG_INQ,
case when datediff(day,actual_drop_date,contact_date) is not null and 
datediff(day,actual_drop_date,contact_date)>=0 then 
1 else 0 end as dm_call_fg,
case when datediff(day,actual_drop_date,contact_date) is not null and 
datediff(day,actual_drop_date,contact_date)>=0 and 
datediff(day,actual_drop_date,contact_date)<=30 then
1 else 0 end as dm_call_1mnth, 
case when datediff(day,actual_drop_date,contact_date) is not null and 
datediff(day,actual_drop_date,contact_date)>=0 and 
datediff(day,actual_drop_date,contact_date)<=60 then
1 else 0 end as dm_call_2mnth,
case when datediff(day,actual_drop_date,contact_date) is not null and 
datediff(day,actual_drop_date,contact_date)>=0 and 
datediff(day,actual_drop_date,contact_date)<=90 then
1 else 0 end as dm_call_3mnth,
case when datediff(day,actual_drop_date,contact_date) is not null and 
datediff(day,actual_drop_date,contact_date)>=0 and 
datediff(day,actual_drop_date,contact_date)<=180 then
1 else 0 end as dm_call_6mnth
from (select d.*, a.contact_date
,a.HCO_CONTACT_REQUEST_ID
,b.HCO_CONTACT_RSN_TYPE_NAME,c.hco_contact_rsn_sub_type_name
from IDENTIFIER(:V_DM_DIME_2021) d inner join IDENTIFIER(:V_CALLS_BASE) a
on d.person_id=a.person_id
left join IDENTIFIER(:V_HCO_CONTACT_REASON_TYPE) b
on a.HCO_CONTACT_RSN_TYPE_CODE=b.HCO_CONTACT_RSN_TYPE_CODE
left join IDENTIFIER(:V_HCO_CONTACT_REASON_SUB_TYPE) c
on a.HCO_CONTACT_RSN_SUB_TYPE_CODE=c.HCO_CONTACT_RSN_SUB_TYPE_CODE
where d.actual_drop_date <= a.contact_date
and d.actual_drop_date > dateadd(day ,-180,a.contact_date)
and a.inquiry_type=''T'')temp2;
             

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DM_CALL)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP30'';

V_STEP_NAME :=  ''Create CALL_SUMM'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_CALL_SUMM) COPY GRANTS as select mkt_contact_id,
max(dm_call_fg) as dm_call_fg,
max(dm_call_1mnth) as dm_call_1mnth,
max(dm_call_2mnth) as dm_call_2mnth,
max(dm_call_3mnth) as dm_call_3mnth,
max(dm_call_6mnth) as dm_call_6mnth,

count(distinct case when datediff(day,actual_drop_date,contact_date) < 30 THEN HCO_CONTACT_REQUEST_ID  end ) as no_calls_1_mnths,
count(distinct case when datediff(day,actual_drop_date,contact_date) < 60 THEN HCO_CONTACT_REQUEST_ID  end ) as no_calls_2_mnths,
count(distinct case when datediff(day,actual_drop_date,contact_date) < 90 THEN HCO_CONTACT_REQUEST_ID  end ) as no_calls_3_mnths,
count(distinct case when datediff(day,actual_drop_date,contact_date) < 180 THEN HCO_CONTACT_REQUEST_ID  end ) as no_calls_6_mnths,


sum(case when datediff(day,actual_drop_date,contact_date) < 30 THEN BILL_PAY_INQ  end ) as BILL_PAY_INQ_call_1_mnths, --1.6M
sum(case when datediff(day,actual_drop_date,contact_date) < 60 THEN BILL_PAY_INQ  end ) as BILL_PAY_INQ_call_2_mnths, --1.6M
sum(case when datediff(day,actual_drop_date,contact_date) < 90 THEN BILL_PAY_INQ  end ) as BILL_PAY_INQ_call_3_mnths, --1.6M
sum(case when datediff(day,actual_drop_date,contact_date) < 180 THEN BILL_PAY_INQ  end ) as BILL_PAY_INQ_call_6_mnths,
 

sum(case when datediff(day,actual_drop_date,contact_date) < 30 THEN CLAIM_INQ  end ) as CLAIM_INQ_call_1_mnths,
sum(case when datediff(day,actual_drop_date,contact_date) < 60 THEN CLAIM_INQ  end ) as CLAIM_INQ_call_2_mnths,
sum(case when datediff(day,actual_drop_date,contact_date) < 90 THEN CLAIM_INQ  end ) as CLAIM_INQ_call_3_mnths,
sum(case when datediff(day,actual_drop_date,contact_date) < 180 THEN CLAIM_INQ  end ) as CLAIM_INQ_call_6_mnths,
 

sum(case when datediff(day,actual_drop_date,contact_date) < 30 THEN TELEMARKETING_INQ  end ) as TELEMARKETING_INQ_call_1_mnths,
sum(case when datediff(day,actual_drop_date,contact_date) < 60 THEN TELEMARKETING_INQ  end ) as TELEMARKETING_INQ_call_2_mnths,
sum(case when datediff(day,actual_drop_date,contact_date) < 90 THEN TELEMARKETING_INQ  end ) as TELEMARKETING_INQ_call_3_mnths,
sum(case when datediff(day,actual_drop_date,contact_date) < 180 THEN TELEMARKETING_INQ  end ) as TELEMARKETING_INQ_call_6_mnths,
 

sum(case when datediff(day,actual_drop_date,contact_date) < 30 THEN OPPRTNTY_INQ  end ) as OPPRTNTY_INQ_call_1_mnths,
sum(case when datediff(day,actual_drop_date,contact_date) < 60 THEN OPPRTNTY_INQ  end ) as OPPRTNTY_INQ_call_2_mnths,
sum(case when datediff(day,actual_drop_date,contact_date) < 90 THEN OPPRTNTY_INQ  end ) as OPPRTNTY_INQ_call_3_mnths,
sum(case when datediff(day,actual_drop_date,contact_date) < 180 THEN OPPRTNTY_INQ  end ) as OPPRTNTY_INQ_call_6_mnths,
 

sum(case when datediff(day,actual_drop_date,contact_date) < 30 THEN PLAN_INQ  end ) as PLAN_INQ_call_1_mnths,
sum(case when datediff(day,actual_drop_date,contact_date) < 60 THEN PLAN_INQ  end ) as PLAN_INQ_call_2_mnths,
sum(case when datediff(day,actual_drop_date,contact_date) < 90 THEN PLAN_INQ  end ) as PLAN_INQ_call_3_mnths,
sum(case when datediff(day,actual_drop_date,contact_date) < 180 THEN PLAN_INQ  end ) as PLAN_INQ_call_6_mnths,


sum(case when datediff(day,actual_drop_date,contact_date) < 30 THEN AUTH_MAIN_INQ  end ) as AUTH_MAIN_INQ_call_1_mnths,
sum(case when datediff(day,actual_drop_date,contact_date) < 60 THEN AUTH_MAIN_INQ  end ) as AUTH_MAIN_INQ_call_2_mnths,
sum(case when datediff(day,actual_drop_date,contact_date) < 90 THEN AUTH_MAIN_INQ  end ) as AUTH_MAIN_INQ_call_3_mnths,
sum(case when datediff(day,actual_drop_date,contact_date) < 180 THEN AUTH_MAIN_INQ  end ) as AUTH_MAIN_INQ_call_6_mnths,


sum(case when datediff(day,actual_drop_date,contact_date) < 30 THEN AUTH_INQ  end ) as AUTH_INQ_call_1_mnths,
sum(case when datediff(day,actual_drop_date,contact_date) < 60 THEN AUTH_INQ  end ) as AUTH_INQ_call_2_mnths,
sum(case when datediff(day,actual_drop_date,contact_date) < 90 THEN AUTH_INQ  end ) as AUTH_INQ_call_3_mnths,
sum(case when datediff(day,actual_drop_date,contact_date) < 180 THEN AUTH_INQ  end ) as AUTH_INQ_call_6_mnths,


sum(case when datediff(day,actual_drop_date,contact_date) < 30 THEN PROGRAM_INQ  end ) as PROGRAM_INQ_call_1_mnths,
sum(case when datediff(day,actual_drop_date,contact_date) < 60 THEN PROGRAM_INQ  end ) as PROGRAM_INQ_call_2_mnths,
sum(case when datediff(day,actual_drop_date,contact_date) < 90 THEN PROGRAM_INQ  end ) as PROGRAM_INQ_call_3_mnths,
sum(case when datediff(day,actual_drop_date,contact_date) < 180 THEN PROGRAM_INQ  end ) as PROGRAM_INQ_call_6_mnths,
 

sum(case when datediff(day,actual_drop_date,contact_date) < 30 THEN ENRL_INQ  end ) as ENRL_INQ_call_1_mnths,
sum(case when datediff(day,actual_drop_date,contact_date) < 60 THEN ENRL_INQ  end ) as ENRL_INQ_call_2_mnths,
sum(case when datediff(day,actual_drop_date,contact_date) < 90 THEN ENRL_INQ  end ) as ENRL_INQ_call_3_mnths,
sum(case when datediff(day,actual_drop_date,contact_date) < 180 THEN ENRL_INQ  end ) as ENRL_INQ_call_6_mnths,


sum(case when datediff(day,actual_drop_date,contact_date) < 30 THEN FULFILL_INQ  end ) as FULFILL_INQ_call_1_mnths,
sum(case when datediff(day,actual_drop_date,contact_date) < 60 THEN FULFILL_INQ  end ) as FULFILL_INQ_call_2_mnths,
sum(case when datediff(day,actual_drop_date,contact_date) < 90 THEN FULFILL_INQ  end ) as FULFILL_INQ_call_3_mnths,
sum(case when datediff(day,actual_drop_date,contact_date) < 180 THEN FULFILL_INQ  end ) as FULFILL_INQ_call_6_mnths,
 

sum(case when datediff(day,actual_drop_date,contact_date) < 30 THEN REBILL_INQ  end ) as REBILL_INQ_call_1_mnths,--18613
sum(case when datediff(day,actual_drop_date,contact_date) < 60 THEN REBILL_INQ  end ) as REBILL_INQ_call_2_mnths,--18613
sum(case when datediff(day,actual_drop_date,contact_date) < 90 THEN REBILL_INQ  end ) as REBILL_INQ_call_3_mnths,--18613
sum(case when datediff(day,actual_drop_date,contact_date) < 180 THEN REBILL_INQ  end ) as REBILL_INQ_call_6_mnths,


sum(case when datediff(day,actual_drop_date,contact_date) < 30 THEN SILVER_INQ  end ) as SILVER_INQ_call_1_mnths, --0
sum(case when datediff(day,actual_drop_date,contact_date) < 60 THEN SILVER_INQ  end ) as SILVER_INQ_call_2_mnths, --0
sum(case when datediff(day,actual_drop_date,contact_date) < 90 THEN SILVER_INQ  end ) as SILVER_INQ_call_3_mnths, --0
sum(case when datediff(day,actual_drop_date,contact_date) < 180 THEN SILVER_INQ  end ) as SILVER_INQ_call_6_mnths,
 

sum(case when datediff(day,actual_drop_date,contact_date) < 30 THEN WEB_INQ  end ) as WEB_INQ_call_1_mnths,
sum(case when datediff(day,actual_drop_date,contact_date) < 60 THEN WEB_INQ  end ) as WEB_INQ_call_2_mnths,
sum(case when datediff(day,actual_drop_date,contact_date) < 90 THEN WEB_INQ  end ) as WEB_INQ_call_3_mnths,
sum(case when datediff(day,actual_drop_date,contact_date) < 180 THEN WEB_INQ  end ) as WEB_INQ_call_6_mnths,


sum(case when datediff(day,actual_drop_date,contact_date) < 30 THEN DEMOG_INQ  end ) as DEMOG_INQ_call_1_mnths,
sum(case when datediff(day,actual_drop_date,contact_date) < 60 THEN DEMOG_INQ  end ) as DEMOG_INQ_call_2_mnths,
sum(case when datediff(day,actual_drop_date,contact_date) < 90 THEN DEMOG_INQ  end ) as DEMOG_INQ_call_3_mnths,
sum(case when datediff(day,actual_drop_date,contact_date) < 180 THEN DEMOG_INQ  end ) as DEMOG_INQ_call_6_mnths


from IDENTIFIER(:V_DM_CALL)
group by mkt_contact_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_CALL_SUMM)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP31'';

V_STEP_NAME :=  ''Create DM_BASE_CALLS,'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DM_BASE_CALLS) COPY GRANTS as select a.*,
coalesce(b.dm_call_fg,0) as dm_call_fg,
coalesce(b.dm_call_1mnth,0) as dm_call_1mnth,
coalesce(b.dm_call_2mnth,0) as dm_call_2mnth,
coalesce(b.dm_call_3mnth,0) as dm_call_3mnth,
coalesce(b.dm_call_6mnth,0) as dm_call_6mnth,
coalesce(b.no_calls_1_mnths,0) as no_calls_1_mnths,
coalesce(b.no_calls_2_mnths,0) as  no_calls_2_mnths,
coalesce(b.no_calls_3_mnths,0) as  no_calls_3_mnths,
coalesce(b.no_calls_6_mnths,0) as no_calls_6_mnths,
coalesce(b.AUTH_INQ_call_1_mnths,0) as  AUTH_INQ_call_1_mnths,
coalesce(b.AUTH_INQ_call_2_mnths,0) as  AUTH_INQ_call_2_mnths,
coalesce(b.AUTH_INQ_call_3_mnths,0) as  AUTH_INQ_call_3_mnths,
coalesce(b.AUTH_INQ_call_6_mnths,0) as  AUTH_INQ_call_6_mnths,
coalesce(b.AUTH_MAIN_INQ_call_1_mnths,0) as  AUTH_MAIN_INQ_call_1_mnths,
coalesce(b.AUTH_MAIN_INQ_call_2_mnths,0) as  AUTH_MAIN_INQ_call_2_mnths,
coalesce(b.AUTH_MAIN_INQ_call_3_mnths,0) as  AUTH_MAIN_INQ_call_3_mnths,
coalesce(b.AUTH_MAIN_INQ_call_6_mnths,0) as AUTH_MAIN_INQ_call_6_mnths,
coalesce(b.BILL_PAY_INQ_call_1_mnths,0) as  BILL_PAY_INQ_call_1_mnths,
coalesce(b.BILL_PAY_INQ_call_2_mnths,0) as  BILL_PAY_INQ_call_2_mnths,
coalesce(b.BILL_PAY_INQ_call_3_mnths,0) as  BILL_PAY_INQ_call_3_mnths,
coalesce(b.BILL_PAY_INQ_call_6_mnths,0) as  BILL_PAY_INQ_call_6_mnths,
coalesce(b.CLAIM_INQ_call_1_mnths,0) as CLAIM_INQ_call_1_mnths,
coalesce(b.CLAIM_INQ_call_2_mnths,0) as CLAIM_INQ_call_2_mnths,
coalesce(b.CLAIM_INQ_call_3_mnths,0) as CLAIM_INQ_call_3_mnths,
coalesce(b.CLAIM_INQ_call_6_mnths,0) as CLAIM_INQ_call_6_mnths,
coalesce(b.DEMOG_INQ_call_1_mnths,0) as DEMOG_INQ_call_1_mnths,
coalesce(b.DEMOG_INQ_call_2_mnths,0) as DEMOG_INQ_call_2_mnths,
coalesce(b.DEMOG_INQ_call_3_mnths,0) as DEMOG_INQ_call_3_mnths,
coalesce(b.DEMOG_INQ_call_6_mnths,0) as DEMOG_INQ_call_6_mnths,
coalesce(b.ENRL_INQ_call_1_mnths,0) as ENRL_INQ_call_1_mnths,
coalesce(b.ENRL_INQ_call_2_mnths,0) as ENRL_INQ_call_2_mnths,
coalesce(b.ENRL_INQ_call_3_mnths,0) as ENRL_INQ_call_3_mnths,
coalesce(b.ENRL_INQ_call_6_mnths,0) as ENRL_INQ_call_6_mnths,
coalesce(b.FULFILL_INQ_call_1_mnths,0) as FULFILL_INQ_call_1_mnths,
coalesce(b.FULFILL_INQ_call_2_mnths,0) as FULFILL_INQ_call_2_mnths,
coalesce(b.FULFILL_INQ_call_3_mnths,0) as FULFILL_INQ_call_3_mnths,
coalesce(b.FULFILL_INQ_call_6_mnths,0) as FULFILL_INQ_call_6_mnths,
coalesce(b.OPPRTNTY_INQ_call_1_mnths,0) as OPPRTNTY_INQ_call_1_mnths,
coalesce(b.OPPRTNTY_INQ_call_2_mnths,0) as OPPRTNTY_INQ_call_2_mnths,
coalesce(b.OPPRTNTY_INQ_call_3_mnths,0) as OPPRTNTY_INQ_call_3_mnths,
coalesce(b.OPPRTNTY_INQ_call_6_mnths,0) as OPPRTNTY_INQ_call_6_mnths,
coalesce(b.PLAN_INQ_call_1_mnths,0) as PLAN_INQ_call_1_mnths,
coalesce(b.PLAN_INQ_call_2_mnths,0) as PLAN_INQ_call_2_mnths,
coalesce(b.PLAN_INQ_call_3_mnths,0) as PLAN_INQ_call_3_mnths,
coalesce(b.PLAN_INQ_call_6_mnths,0) as PLAN_INQ_call_6_mnths,
coalesce(b.PROGRAM_INQ_call_1_mnths,0) as PROGRAM_INQ_call_1_mnths,
coalesce(b.PROGRAM_INQ_call_2_mnths,0) as PROGRAM_INQ_call_2_mnths,
coalesce(b.PROGRAM_INQ_call_3_mnths,0) as PROGRAM_INQ_call_3_mnths,
coalesce(b.PROGRAM_INQ_call_6_mnths,0) as PROGRAM_INQ_call_6_mnths,
coalesce(b.REBILL_INQ_call_1_mnths,0) as REBILL_INQ_call_1_mnths,
coalesce(b.REBILL_INQ_call_2_mnths,0) as REBILL_INQ_call_2_mnths,
coalesce(b.REBILL_INQ_call_3_mnths,0) as REBILL_INQ_call_3_mnths,
coalesce(b.REBILL_INQ_call_6_mnths,0) as REBILL_INQ_call_6_mnths,
coalesce(b.SILVER_INQ_call_1_mnths,0) as SILVER_INQ_call_1_mnths,
coalesce(b.SILVER_INQ_call_2_mnths,0) as SILVER_INQ_call_2_mnths,
coalesce(b.SILVER_INQ_call_3_mnths,0) as SILVER_INQ_call_3_mnths,
coalesce(b.SILVER_INQ_call_6_mnths,0) as SILVER_INQ_call_6_mnths,
coalesce(b.TELEMARKETING_INQ_call_1_mnths,0) as TELEMARKETING_INQ_call_1_mnths,
coalesce(b.TELEMARKETING_INQ_call_2_mnths,0) as TELEMARKETING_INQ_call_2_mnths,
coalesce(b.TELEMARKETING_INQ_call_3_mnths,0) as TELEMARKETING_INQ_call_3_mnths,
coalesce(b.TELEMARKETING_INQ_call_6_mnths,0) as TELEMARKETING_INQ_call_6_mnths,
coalesce(b.WEB_INQ_call_1_mnths,0) as WEB_INQ_call_1_mnths,
coalesce(b.WEB_INQ_call_2_mnths,0) as WEB_INQ_call_2_mnths,
coalesce(b.WEB_INQ_call_3_mnths,0) as WEB_INQ_call_3_mnths,
coalesce(b.WEB_INQ_call_6_mnths,0) as WEB_INQ_call_6_mnths,
case when no_calls_1_mnths >= 1 then 1 else 0 end as Call_1_flag,
case when no_calls_2_mnths >= 1 then 1 else 0 end as Call_2_flag,
case when no_calls_3_mnths >= 1 then 1 else 0 end as Call_3_flag,
case when no_calls_6_mnths >= 1 then 1 else 0 end as Call_6_flag
from IDENTIFIER(:V_DM_DIME_2021) a left join IDENTIFIER(:V_CALL_SUMM) b  
on a.mkt_contact_id = b.mkt_contact_id;


drop table if exists  IDENTIFIER(:V_DM_CALL);
drop table if exists  IDENTIFIER(:V_CALL_SUMM);



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DM_BASE_CALLS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP32'';

V_STEP_NAME :=  ''Create TEMP1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_TEMP1) COPY GRANTS as select tr.mkt_contact_id,
max( case when datediff(day,tr.actual_drop_date,ms.appl_receipt_date) >= 0 then ms.sale else 0 end) as sale_fg,
sum( case when datediff(day,tr.actual_drop_date,ms.appl_receipt_date) >= 0
and datediff(day,tr.actual_drop_date,ms.appl_receipt_date) <=30 then ms.sale else 0 end) as sale_1mo,
sum(case when datediff(day,tr.actual_drop_date,ms.appl_receipt_date) >= 0
and datediff(day,tr.actual_drop_date,ms.appl_receipt_date) <= 60 then ms.sale else 0 end) as sale_2mo,
sum(case when datediff(day,tr.actual_drop_date,ms.appl_receipt_date) >= 0
and datediff(day,tr.actual_drop_date,ms.appl_receipt_date) <=90 then ms.sale else 0 end )as sale_3mo,
sum(case when datediff(day,tr.actual_drop_date,ms.appl_receipt_date) >= 0
and datediff(day,tr.actual_drop_date,ms.appl_receipt_date) <=180 then ms.sale else 0 end) as sale_6mo,
max(case when datediff(day,tr.actual_drop_date,ms.appl_receipt_date) >= 0 then ms.paidsale else 0 end) as paidsale_fg,
sum(case when datediff(day,tr.actual_drop_date,ms.appl_receipt_date) >= 0
and datediff(day,tr.actual_drop_date,ms.appl_receipt_date) <=30  then ms.paidsale else 0 end) as paidsale_1mo,
sum(case when datediff(day,tr.actual_drop_date,ms.appl_receipt_date) >= 0
and datediff(day,tr.actual_drop_date,ms.appl_receipt_date) <= 60 then ms.paidsale else 0 end) as paidsale_2mo,
sum(case when datediff(day,tr.actual_drop_date,ms.appl_receipt_date) >= 0
and datediff(day,tr.actual_drop_date,ms.appl_receipt_date) <=90  then ms.paidsale else 0 end) as paidsale_3mo,
sum(case when datediff(day,tr.actual_drop_date,ms.appl_receipt_date) >= 0
and datediff(day,tr.actual_drop_date,ms.appl_receipt_date) <=180  then ms.paidsale else 0 end) as paidsale_6mo
from IDENTIFIER(:V_DM_BASE_CALLS) as tr
left join IDENTIFIER(:V_APPS_RPTG_DAILY) ms
on tr.person_id=ms.person_id
group by tr.mkt_contact_id;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_TEMP1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP33'';

V_STEP_NAME :=  ''Create PAID_SALE'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_PAID_SALE) COPY GRANTS as select a.*,sale_fg,sale_1mo,sale_2mo,sale_3mo,sale_6mo,
paidsale_fg,paidsale_1mo,paidsale_2mo,paidsale_3mo,paidsale_6mo
from IDENTIFIER(:V_DM_BASE_CALLS) as a left join IDENTIFIER(:V_TEMP1) as b
on a.mkt_contact_id = b.mkt_contact_id;

drop table if exists  IDENTIFIER(:V_DM_BASE_CALLS);
drop table if exists  IDENTIFIER(:V_TEMP1);

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_PAID_SALE)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP34'';

V_STEP_NAME :=  ''Create V_STATE_DM'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_STATE_DM) COPY GRANTS as select a.*,state_name
from IDENTIFIER(:V_PAID_SALE) as a left join IDENTIFIER(:V_STATE) as b
on a.state = b.state_code;

drop table if exists  IDENTIFIER(:V_PAID_SALE);

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_STATE_DM)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP35'';

V_STEP_NAME :=  ''Create V_VOL_LAPSE_DM'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_VOL_LAPSE_DM) COPY GRANTS as select a.*,
case when term >=1 and datediff(day,actual_drop_date,prem_due_date)>=0 and 
datediff(day,actual_drop_date,prem_due_date)<=30 then ''Yes'' else ''No'' end as vol_lapse_1mo,
case when term >=1 and datediff(day,actual_drop_date,prem_due_date)>=0 and 
datediff(day,actual_drop_date,prem_due_date)<=60 then ''Yes'' else ''No'' end as vol_lapse_2mo,
case when term >=1 and datediff(day,actual_drop_date,prem_due_date)>=0 and 
datediff(day,actual_drop_date,prem_due_date)<=90 then ''Yes'' else ''No'' end as vol_lapse_3mo,
case when term >=1 and datediff(day,actual_drop_date,prem_due_date)>=0 and 
datediff(day,actual_drop_date,prem_due_date)<=180 then ''Yes'' else ''No'' end as vol_lapse_6mo
from IDENTIFIER(:V_STATE_DM) as a left join (select * from IDENTIFIER(:V_STR_LAPSE_DAILY) where 
d_cert_actv_sk between 19 and 49 and d_cert_actv_sk != 47) as b
on a.person_id = b.pers_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_VOL_LAPSE_DM)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP36'';

V_STEP_NAME :=  ''Create V_SWITCH_DM'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_SWITCH_DM) COPY GRANTS as select a.*,
case when term >=1 and datediff(day,actual_drop_date,prem_due_date)>=0 and 
datediff(day,actual_drop_date,prem_due_date)<=30 then ''Yes'' else ''No'' end as switch_1mo,
case when term >=1 and datediff(day,actual_drop_date,prem_due_date)>=0 and 
datediff(day,actual_drop_date,prem_due_date)<=60 then ''Yes'' else ''No'' end as switch_2mo,
case when term >=1 and datediff(day,actual_drop_date,prem_due_date)>=0 and 
datediff(day,actual_drop_date,prem_due_date)<=90 then ''Yes'' else ''No'' end as switch_3mo,
case when term >=1 and datediff(day,actual_drop_date,prem_due_date)>=0 and 
datediff(day,actual_drop_date,prem_due_date)<=180 then ''Yes'' else ''No'' end as switch_6mo
from IDENTIFIER(:V_VOL_LAPSE_DM) as a left join (select * from IDENTIFIER(:V_STR_LAPSE_DAILY) where 
d_cert_actv_sk between 3 and 11) as b
on a.person_id = b.pers_id;

drop table if exists  IDENTIFIER(:V_VOL_LAPSE_DM);
drop table if exists  IDENTIFIER(:V_DEATH_LAPSE_DM);

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_SWITCH_DM)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP37'';

V_STEP_NAME :=  ''Create V_TENURE_DM'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_TENURE_DM) COPY GRANTS as select a.*,
case when datediff(day,prdct_eff_date,actual_drop_date)/365.25 <= 1 THEN ''Less than 1yr''
when datediff(day,prdct_eff_date,actual_drop_date)/365.25 >1 and datediff(day,prdct_eff_date,actual_drop_date)/365.25 <=2 then ''1-2yrs''
when datediff(day,prdct_eff_date,actual_drop_date)/365.25 >2 and datediff(day,prdct_eff_date,actual_drop_date)/365.25 <=3 then ''2-3yrs''
when datediff(day,prdct_eff_date,actual_drop_date)/365.25 >3 and datediff(day,prdct_eff_date,actual_drop_date)/365.25 <=5 then ''3-5yrs''
when datediff(day,prdct_eff_date,actual_drop_date)/365.25 >5 and datediff(day,prdct_eff_date,actual_drop_date)/365.25 <=10 then ''5-10yrs''
when datediff(day,prdct_eff_date,actual_drop_date)/365.25 >10 then ''10+yrs''
else ''Unknown'' end as tenure,
case when prod_ACQN_CHNL_LVL_1 is not NULL then prod_ACQN_CHNL_LVL_1 ELSE ''Unknown'' end as acq_channel,
case when pln_lvl is NULL then ''Unknown''
when PLN_LVL in (''GH1'',''GH2'') THEN ''GH''  
when trim(pln_lvl) in (''G01'',''G'',''G0'',''GS1'',''G02'', ''GS2'') then ''G''
when trim(pln_lvl) in (''F01'',''F0'',''F'',''FS1'',''F02'', ''FS2'') then ''F'' 
when trim(pln_lvl) in (''K01'',''K'') then ''K''
when trim(pln_lvl) in (''N01'',''NS1'',''N02'', ''NS2'') then ''N''
else ''Other'' end as plan
from IDENTIFIER(:V_SWITCH_DM) as a left join IDENTIFIER(:V_MEMBER_DATA_CAM_DAILY) as b on
a.person_id = b.pers_id;

drop table if exists  IDENTIFIER(:V_SWITCH_DM);

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_TENURE_DM)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP38'';

V_STEP_NAME :=  ''Create V_OBCALL_BASE_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_OBCALL_BASE_1) COPY GRANTS as 
select a.*, b.csr_contact_ind
from IDENTIFIER(:V_TENURE_DM) a left join IDENTIFIER(:V_TM_CONTACT_RESPONSE) b  
on a.mkt_contact_id=b.mkt_contact_id;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_OBCALL_BASE_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP39'';

V_STEP_NAME :=  ''Create V_TEMP'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_TEMP) COPY GRANTS as select mkt_contact_id,
max(case when datediff(day,actual_drop_date,registered_on_date)<=30 
and datediff(day,actual_drop_date,registered_on_date) >= 0 then 1 else 0 end) as ACP_1mo,
max(case when datediff(day,actual_drop_date,registered_on_date)<=60 
and datediff(day,actual_drop_date,registered_on_date) >= 0 then 1 else 0 end) as ACP_2mo,
max(case when datediff(day,actual_drop_date,registered_on_date)<=90 
and datediff(day,actual_drop_date,registered_on_date) >= 0 then 1 else 0 end) as ACP_3mo,
max(case when datediff(day,actual_drop_date,registered_on_date)<=180 
and datediff(day,actual_drop_date,registered_on_date) >= 0 then 1 else 0 end) as ACP_6mo
from IDENTIFIER(:V_OBCALL_BASE_1) as a left join IDENTIFIER(:V_MYDIRECTIVES_ADVANCE_CARE) as b
on a.person_id = b.person_id
group by mkt_contact_id;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_TEMP)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP40'';

V_STEP_NAME :=  ''Create V_ACP_2024_25'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_ACP_2024_25) COPY GRANTS as select a.*,ACP_1mo,ACP_2mo,ACP_3mo,ACP_6mo
from IDENTIFIER(:V_OBCALL_BASE_1) a left join IDENTIFIER(:V_TEMP) b
on a.mkt_contact_id = b.mkt_contact_id;

drop table if exists  IDENTIFIER(:V_TEMP);
drop table if exists  IDENTIFIER(:V_TENURE_DM);
drop table if exists  IDENTIFIER(:V_OBCALL_BASE_1);

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_ACP_2024_25)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP41'';

V_STEP_NAME :=  ''Create V_SUMM_DATA_CAMPAIGN_2025,'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_SUMM_DATA_CAMPAIGN_2025) COPY GRANTS as
select mkt_contact_id,person_id,initiative,campaigncode,channel_code
,actual_drop_date,name as campaign_name,cellcode,cellname,
case when state_name is not NULL then state_name else ''Unknown'' end as state_name,
case when state is not NULL then state else ''Unknown'' end as state_code,
VAS_regst,VAS_reg_1mo,
VAS_reg_2mo,VAS_reg_3mo,VAS_reg_6mo,
vol_lapse_1mo,vol_lapse_2mo,vol_lapse_3mo,vol_lapse_6mo,tenure,plan,
switch_1mo,switch_2mo,switch_3mo,switch_6mo,
case when trim(state) in (''AL'', ''NJ'', ''KY'', ''MD'', ''OR'', ''MO'', ''WA'', ''MI'', ''LA'', ''NV'', ''WV'', ''WY'', ''TX'', ''OH'', ''OK'', ''TN'', ''DE'', ''IA'', ''ID'', 
''KS'', ''MN'', ''MS'', ''MT'', ''ND'', ''NY'', ''SD'', ''AZ'', ''CA'', ''CT'', ''IL'', ''IN'', ''NC'', ''UT'', ''WI'') then ''AYB States''
when trim(state) in (''AR'', ''CO'', ''DC'', ''GA'', ''NE'', ''PA'', ''SC'', ''VA'') then ''SS States''
else ''Neither'' end as Service_States,
case when acq_channel = ''UNKNOWN'' then ''Unknown'' else acq_channel end as acq_channel,
case when trim(csr_contact_ind) = ''Y'' then ''Presented'' 
when trim(csr_contact_ind) = ''N'' then ''Not Presented''
else ''Unknown'' end as csr_contact_ind,
case when trim(disposition_code) = ''Y''  then ''Contact Successful''
when trim(disposition_code) = ''N'' then ''Contact Unsuccessful''
when (trim(disposition_code) = ''S'' or trim(disposition_code) = ''A'') then ''Not Contacted''
else ''Unknown'' end as disposition_code
,disposition_reason_code
,disposition_reason_desc,
case when web_rg_1mnth = 1 then ''Yes'' else ''No'' end as web_rg_1mnth,
case when web_rg_2mnth = 1 then ''Yes'' else ''No'' end as web_rg_2mnth,
case when web_rg_3mnth = 1 then ''Yes'' else ''No'' end as web_rg_3mnth,
case when web_rg_6mnth = 1 then ''Yes'' else ''No'' end as web_rg_6mnth,
case when eft_flg = 1 then ''Yes'' else ''No'' end as eft_flg,
case when ot_1mo = 1 then ''Yes'' else ''No'' end as ot_1mo,
case when ot_2mo = 1 then ''Yes'' else ''No'' end as ot_2mo,
case when ot_3mo = 1 then ''Yes'' else ''No'' end as ot_3mo,
case when ot_6mo = 1 then ''Yes'' else ''No'' end as ot_6mo,
case when rec_1mo = 1 then ''Yes'' else ''No'' end as rec_1mo,
case when rec_2mo = 1 then ''Yes'' else ''No'' end as rec_2mo,
case when rec_3mo = 1 then ''Yes'' else ''No'' end as rec_3mo,
case when rec_6mo = 1 then ''Yes'' else ''No'' end as rec_6mo,
case when ACP_1mo = 1 then ''Yes'' else ''No'' end as ACP_1mo,
case when ACP_2mo = 1 then ''Yes'' else ''No'' end as ACP_2mo,
case when ACP_3mo = 1 then ''Yes'' else ''No'' end as ACP_3mo,
case when ACP_6mo = 1 then ''Yes'' else ''No'' end as ACP_6mo,
case when priv_1mnth = 1 then ''Yes'' else ''No'' end as priv_1mnth,
case when priv_2mnth = 1 then ''Yes'' else ''No'' end as priv_2mnth,
case when priv_3mnth = 1 then ''Yes'' else ''No'' end as priv_3mnth,
case when priv_6mnth = 1 then ''Yes'' else ''No'' end as priv_6mnth,
case when nhl_1mnth = 1 then ''Yes'' else ''No'' end as nhl_1mnth,
case when nhl_2mnth = 1 then ''Yes'' else ''No'' end as nhl_2mnth,
case when nhl_3mnth = 1 then ''Yes'' else ''No'' end as nhl_3mnth,
case when nhl_6mnth = 1 then ''Yes'' else ''No'' end as nhl_6mnth,
case when ONS_1mnth = 1 then ''Yes'' else ''No'' end as ONS_1mnth,
case when ONS_2mnth = 1 then ''Yes'' else ''No'' end as ONS_2mnth,
case when ONS_3mnth = 1 then ''Yes'' else ''No'' end as ONS_3mnth,
case when ONS_6mnth = 1 then ''Yes'' else ''No'' end as ONS_6mnth,
case when VAS_gym_1mnth= 1 then ''Yes'' else ''No'' end as VAS_gym_1mnth,
case when VAS_gym_2mnth= 1 then ''Yes'' else ''No'' end as VAS_gym_2mnth,
case when VAS_gym_3mnth= 1 then ''Yes'' else ''No'' end as VAS_gym_3mnth,
case when VAS_gym_6mnth= 1 then ''Yes'' else ''No'' end as VAS_gym_6mnth,
case when VAS_event_1mnth= 1 then ''Yes'' else ''No'' end as VAS_event_1mnth,
case when VAS_event_2mnth= 1 then ''Yes'' else ''No'' end as VAS_event_2mnth,
case when VAS_event_3mnth= 1 then ''Yes'' else ''No'' end as VAS_event_3mnth,
case when VAS_event_6mnth= 1 then ''Yes'' else ''No'' end as VAS_event_6mnth,
case when VAS_renew_active_gym_1mnth = 1 then ''Yes'' else ''No'' end as VAS_renew_active_gym_1mnth,
case when VAS_renew_active_gym_2mnth = 1 then ''Yes'' else ''No'' end as VAS_renew_active_gym_2mnth,
case when VAS_renew_active_gym_3mnth = 1 then ''Yes'' else ''No'' end as VAS_renew_active_gym_3mnth,
case when VAS_renew_active_gym_6mnth = 1 then ''Yes'' else ''No'' end as VAS_renew_active_gym_6mnth,
case when VAS_staying_sharp_1mnth = 1 then ''Yes'' else ''No'' end as VAS_staying_sharp_1mnth,
case when VAS_staying_sharp_2mnth = 1 then ''Yes'' else ''No'' end as VAS_staying_sharp_2mnth,
case when VAS_staying_sharp_3mnth = 1 then ''Yes'' else ''No'' end as VAS_staying_sharp_3mnth,
case when VAS_staying_sharp_6mnth = 1 then ''Yes'' else ''No'' end as VAS_staying_sharp_6mnth,
case when VAS_telephonic_1mnth= 1 then ''Yes'' else ''No'' end as VAS_telephonic_1mnth,
case when VAS_telephonic_2mnth= 1 then ''Yes'' else ''No'' end as VAS_telephonic_2mnth,
case when VAS_telephonic_3mnth= 1 then ''Yes'' else ''No'' end as VAS_telephonic_3mnth,
case when VAS_telephonic_6mnth= 1 then ''Yes'' else ''No'' end as VAS_telephonic_6mnth,
case when dm_call_fg= 1 then ''Yes'' else ''No'' end as call_fg,
case when call_1_flag = 1 then ''Yes'' else ''No'' end as call_1_flag,
case when call_2_flag = 1 then ''Yes'' else ''No'' end as call_2_flag,
case when call_3_flag = 1 then ''Yes'' else ''No'' end as call_3_flag,
case when call_6_flag = 1 then ''Yes'' else ''No'' end as call_6_flag,
no_calls_6_mnths as total_calls_6_mnths, no_calls_3_mnths as total_calls_3_mnths, 
no_calls_2_mnths as total_calls_2_mnths, no_calls_1_mnths as total_calls_1_mnths,
case when sale_fg = 1 then ''Yes'' else ''No'' end as sale_fg,
case when sale_1mo = 1 then ''Yes'' else ''No'' end as sale_1mo,
case when sale_2mo = 1 then ''Yes'' else ''No'' end as sale_2mo,
case when sale_3mo = 1 then ''Yes'' else ''No'' end as sale_3mo,
case when sale_6mo = 1 then ''Yes'' else ''No'' end as sale_6mo,
case when paidsale_fg = 1 then ''Yes'' else ''No'' end as paidsale_fg,
case when paidsale_1mo = 1 then ''Yes'' else ''No'' end as paidsale_1mo,
case when paidsale_2mo = 1 then ''Yes'' else ''No'' end as paidsale_2mo,
case when paidsale_3mo = 1 then ''Yes'' else ''No'' end as paidsale_3mo,
case when paidsale_6mo = 1 then ''Yes'' else ''No'' end as paidsale_6mo,
case when priv_auth_flg = 1 then ''Yes'' else ''No'' end as priv_auth_flg
,bounce_1week 
,bounce_2week 
,bounce_3week 
,bounce_4week 
-- ,bounce_grt_4week 
,click_1week 
,click_2week 
,click_3week 
,click_4week 
,not_sent_1week 
,not_sent_2week 
,not_sent_3week 
,not_sent_4week 

,open_1week 
,open_2week 
,open_3week 
,open_4week 
,sent_1week 
,sent_2week 
,sent_3week 
,sent_4week 
,subscribe_1week 
,subscribe_2week 
,subscribe_3week 
,subscribe_4week 
,unsubscribe_1week 
,unsubscribe_2week 
,unsubscribe_3week 
,unsubscribe_4week
,case when trim(estinc19) in (''A'',''B'') then  ''Less than $19,999''
when trim(estinc19) in (''C'') then ''$20,000 - $29,999''
when trim(estinc19) in (''D'') then ''$30,000 - $39,999''
when trim(estinc19) in (''E'') then ''$40,000 - $49,999''
when trim(estinc19) in (''F'',''G'',''H'',''I'',''J'',''K'',''L'',''M'',''N'',''O'')
then ''$50,000+''
else ''Unknown'' end as income,
case when trim(gender_code) = ''M'' then ''Male''
when trim(gender_code) = ''F'' then ''Female''
else ''Unknown'' end as gender,
case when round(datediff(day,birth_date,:V_CURRENT_DATE)/365.25) >=0 and round(datediff(day,birth_date,:V_CURRENT_DATE)/365.25)  <=64 THEN ''Less than 64''
when round(datediff(day,birth_date,:V_CURRENT_DATE)/365.25) >64 and round(datediff(day,birth_date,:V_CURRENT_DATE)/365.25) <=65 then ''64-65''
when round(datediff(day,birth_date,:V_CURRENT_DATE)/365.25) >65 and round(datediff(day,birth_date,:V_CURRENT_DATE)/365.25) <=70 then ''65-70''
when round(datediff(day,birth_date,:V_CURRENT_DATE)/365.25) >70 and round(datediff(day,birth_date,:V_CURRENT_DATE)/365.25) <=75 then ''70-75''
when round(datediff(day,birth_date,:V_CURRENT_DATE)/365.25) >75 and round(datediff(day,birth_date,:V_CURRENT_DATE)/365.25) <=80 then ''75-80''
when round(datediff(day,birth_date,:V_CURRENT_DATE)/365.25) >80 and round(datediff(day,birth_date,:V_CURRENT_DATE)/365.25) <=85 then ''80-85''
when round(datediff(day,birth_date,:V_CURRENT_DATE)/365.25) >85  then ''85+'' 
else ''Unknown'' end as age_group,
case when no_calls_1_mnths = 0 then ''No Calls''
when no_calls_1_mnths = 1 then ''1''
when no_calls_1_mnths = 2 then ''2''
when no_calls_1_mnths in (3,4) then ''3-4''
when no_calls_1_mnths >=5 then ''5+'' end as no_calls_1_mnths,
case when no_calls_2_mnths = 0 then ''No Calls''
when no_calls_2_mnths = 1 then ''1''
when no_calls_2_mnths = 2 then ''2''
when no_calls_2_mnths in (3,4) then ''3-4''
when no_calls_2_mnths >=5 then ''5+'' end as no_calls_2_mnths,
case when no_calls_3_mnths = 0 then ''No Calls''
when no_calls_3_mnths = 1 then ''1''
when no_calls_3_mnths = 2 then ''2''
when no_calls_3_mnths in (3,4) then ''3-4''
when no_calls_3_mnths >=5 then ''5+'' end as no_calls_3_mnths,
case when no_calls_6_mnths = 0 then ''No Calls''
when no_calls_6_mnths = 1 then ''1''
when no_calls_6_mnths = 2 then ''2''
when no_calls_6_mnths in (3,4) then ''3-4''
when no_calls_6_mnths >=5 then ''5+'' end as no_calls_6_mnths,
case when bill_pay_inq_call_1_mnths = 0 then ''No Calls''
when bill_pay_inq_call_1_mnths = 1 then ''1''
when bill_pay_inq_call_1_mnths = 2 then ''2''
when bill_pay_inq_call_1_mnths in (3,4) then ''3-4''
when bill_pay_inq_call_1_mnths >=5 then ''5+'' end as bill_pay_inq_call_1_mnths,
case when bill_pay_inq_call_2_mnths = 0 then ''No Calls''
when bill_pay_inq_call_2_mnths = 1 then ''1''
when bill_pay_inq_call_2_mnths = 2 then ''2''
when bill_pay_inq_call_2_mnths in (3,4) then ''3-4''
when bill_pay_inq_call_2_mnths >=5 then ''5+'' end as bill_pay_inq_call_2_mnths,
case when bill_pay_inq_call_3_mnths = 0 then ''No Calls''
when bill_pay_inq_call_3_mnths = 1 then ''1''
when bill_pay_inq_call_3_mnths = 2 then ''2''
when bill_pay_inq_call_3_mnths in (3,4) then ''3-4''
when bill_pay_inq_call_3_mnths >=5 then ''5+'' end as bill_pay_inq_call_3_mnths,
case when bill_pay_inq_call_6_mnths = 0 then ''No Calls''
when bill_pay_inq_call_6_mnths = 1 then ''1''
when bill_pay_inq_call_6_mnths = 2 then ''2''
when bill_pay_inq_call_6_mnths in (3,4) then ''3-4''
when bill_pay_inq_call_6_mnths >=5 then ''5+'' end as bill_pay_inq_call_6_mnths,
case when claim_inq_call_1_mnths = 0 then ''No Calls''
when claim_inq_call_1_mnths = 1 then ''1''
when claim_inq_call_1_mnths = 2 then ''2''
when claim_inq_call_1_mnths in (3,4) then ''3-4''
when claim_inq_call_1_mnths >=5 then ''5+'' end as claim_inq_call_1_mnths,
case when claim_inq_call_2_mnths = 0 then ''No Calls''
when claim_inq_call_2_mnths = 1 then ''1''
when claim_inq_call_2_mnths = 2 then ''2''
when claim_inq_call_2_mnths in (3,4) then ''3-4''
when claim_inq_call_2_mnths >=5 then ''5+'' end as claim_inq_call_2_mnths,
case when claim_inq_call_3_mnths = 0 then ''No Calls''
when claim_inq_call_3_mnths = 1 then ''1''
when claim_inq_call_3_mnths = 2 then ''2''
when claim_inq_call_3_mnths in (3,4) then ''3-4''
when claim_inq_call_3_mnths >=5 then ''5+'' end as claim_inq_call_3_mnths,
case when claim_inq_call_6_mnths = 0 then ''No Calls''
when claim_inq_call_6_mnths = 1 then ''1''
when claim_inq_call_6_mnths = 2 then ''2''
when claim_inq_call_6_mnths in (3,4) then ''3-4''
when claim_inq_call_6_mnths >=5 then ''5+'' end as claim_inq_call_6_mnths,
case when telemarketing_inq_call_1_mnths = 0 then ''No Calls''
when telemarketing_inq_call_1_mnths = 1 then ''1''
when telemarketing_inq_call_1_mnths = 2 then ''2''
when telemarketing_inq_call_1_mnths in (3,4) then ''3-4''
when telemarketing_inq_call_1_mnths >=5 then ''5+'' end as telemarketing_inq_call_1_mnths,
case when telemarketing_inq_call_2_mnths = 0 then ''No Calls''
when telemarketing_inq_call_2_mnths = 1 then ''1''
when telemarketing_inq_call_2_mnths = 2 then ''2''
when telemarketing_inq_call_2_mnths in (3,4) then ''3-4''
when telemarketing_inq_call_2_mnths >=5 then ''5+'' end as telemarketing_inq_call_2_mnths,
case when telemarketing_inq_call_3_mnths = 0 then ''No Calls''
when telemarketing_inq_call_3_mnths = 1 then ''1''
when telemarketing_inq_call_3_mnths = 2 then ''2''
when telemarketing_inq_call_3_mnths in (3,4) then ''3-4''
when telemarketing_inq_call_3_mnths >=5 then ''5+'' end as telemarketing_inq_call_3_mnths,
case when telemarketing_inq_call_6_mnths = 0 then ''No Calls''
when telemarketing_inq_call_6_mnths = 1 then ''1''
when telemarketing_inq_call_6_mnths = 2 then ''2''
when telemarketing_inq_call_6_mnths in (3,4) then ''3-4''
when telemarketing_inq_call_6_mnths >=5 then ''5+'' end as telemarketing_inq_call_6_mnths,
case when opprtnty_inq_call_1_mnths = 0 then ''No Calls''
when opprtnty_inq_call_1_mnths = 1 then ''1''
when opprtnty_inq_call_1_mnths = 2 then ''2''
when opprtnty_inq_call_1_mnths in (3,4) then ''3-4''
when opprtnty_inq_call_1_mnths >=5 then ''5+'' end as opprtnty_inq_call_1_mnths,
case when opprtnty_inq_call_2_mnths = 0 then ''No Calls''
when opprtnty_inq_call_2_mnths = 1 then ''1''
when opprtnty_inq_call_2_mnths = 2 then ''2''
when opprtnty_inq_call_2_mnths in (3,4) then ''3-4''
when opprtnty_inq_call_2_mnths >=5 then ''5+'' end as opprtnty_inq_call_2_mnths,
case when opprtnty_inq_call_3_mnths = 0 then ''No Calls''
when opprtnty_inq_call_3_mnths = 1 then ''1''
when opprtnty_inq_call_3_mnths = 2 then ''2''
when opprtnty_inq_call_3_mnths in (3,4) then ''3-4''
when opprtnty_inq_call_3_mnths >=5 then ''5+'' end as opprtnty_inq_call_3_mnths,
case when opprtnty_inq_call_6_mnths = 0 then ''No Calls''
when opprtnty_inq_call_6_mnths = 1 then ''1''
when opprtnty_inq_call_6_mnths = 2 then ''2''
when opprtnty_inq_call_6_mnths in (3,4) then ''3-4''
when opprtnty_inq_call_6_mnths >=5 then ''5+'' end as opprtnty_inq_call_6_mnths,
case when plan_inq_call_1_mnths = 0 then ''No Calls''
when plan_inq_call_1_mnths = 1 then ''1''
when plan_inq_call_1_mnths = 2 then ''2''
when plan_inq_call_1_mnths in (3,4) then ''3-4''
when plan_inq_call_1_mnths >=5 then ''5+'' end as plan_inq_call_1_mnths,
case when plan_inq_call_2_mnths = 0 then ''No Calls''
when plan_inq_call_2_mnths = 1 then ''1''
when plan_inq_call_2_mnths = 2 then ''2''
when plan_inq_call_2_mnths in (3,4) then ''3-4''
when plan_inq_call_2_mnths >=5 then ''5+'' end as plan_inq_call_2_mnths,
case when plan_inq_call_3_mnths = 0 then ''No Calls''
when plan_inq_call_3_mnths = 1 then ''1''
when plan_inq_call_3_mnths = 2 then ''2''
when plan_inq_call_3_mnths in (3,4) then ''3-4''
when plan_inq_call_3_mnths >=5 then ''5+'' end as plan_inq_call_3_mnths,
case when plan_inq_call_6_mnths = 0 then ''No Calls''
when plan_inq_call_6_mnths = 1 then ''1''
when plan_inq_call_6_mnths = 2 then ''2''
when plan_inq_call_6_mnths in (3,4) then ''3-4''
when plan_inq_call_6_mnths >=5 then ''5+'' end as plan_inq_call_6_mnths,
case when auth_main_inq_call_1_mnths = 0 then ''No Calls''
when auth_main_inq_call_1_mnths = 1 then ''1''
when auth_main_inq_call_1_mnths = 2 then ''2''
when auth_main_inq_call_1_mnths in (3,4) then ''3-4''
when auth_main_inq_call_1_mnths >=5 then ''5+'' end as auth_main_inq_call_1_mnths,
case when auth_main_inq_call_2_mnths = 0 then ''No Calls''
when auth_main_inq_call_2_mnths = 1 then ''1''
when auth_main_inq_call_2_mnths = 2 then ''2''
when auth_main_inq_call_2_mnths in (3,4) then ''3-4''
when auth_main_inq_call_2_mnths >=5 then ''5+'' end as auth_main_inq_call_2_mnths,
case when auth_main_inq_call_3_mnths = 0 then ''No Calls''
when auth_main_inq_call_3_mnths = 1 then ''1''
when auth_main_inq_call_3_mnths = 2 then ''2''
when auth_main_inq_call_3_mnths in (3,4) then ''3-4''
when auth_main_inq_call_3_mnths >=5 then ''5+'' end as auth_main_inq_call_3_mnths,
case when auth_main_inq_call_6_mnths = 0 then ''No Calls''
when auth_main_inq_call_6_mnths = 1 then ''1''
when auth_main_inq_call_6_mnths = 2 then ''2''
when auth_main_inq_call_6_mnths in (3,4) then ''3-4''
when auth_main_inq_call_6_mnths >=5 then ''5+'' end as auth_main_inq_call_6_mnths,
case when auth_inq_call_1_mnths = 0 then ''No Calls''
when auth_inq_call_1_mnths = 1 then ''1''
when auth_inq_call_1_mnths = 2 then ''2''
when auth_inq_call_1_mnths in (3,4) then ''3-4''
when auth_inq_call_1_mnths >=5 then ''5+'' end as auth_inq_call_1_mnths,
case when auth_inq_call_2_mnths = 0 then ''No Calls''
when auth_inq_call_2_mnths = 1 then ''1''
when auth_inq_call_2_mnths = 2 then ''2''
when auth_inq_call_2_mnths in (3,4) then ''3-4''
when auth_inq_call_2_mnths >=5 then ''5+'' end as auth_inq_call_2_mnths,
case when auth_inq_call_3_mnths = 0 then ''No Calls''
when auth_inq_call_3_mnths = 1 then ''1''
when auth_inq_call_3_mnths = 2 then ''2''
when auth_inq_call_3_mnths in (3,4) then ''3-4''
when auth_inq_call_3_mnths >=5 then ''5+'' end as auth_inq_call_3_mnths,
case when auth_inq_call_6_mnths = 0 then ''No Calls''
when auth_inq_call_6_mnths = 1 then ''1''
when auth_inq_call_6_mnths = 2 then ''2''
when auth_inq_call_6_mnths in (3,4) then ''3-4''
when auth_inq_call_6_mnths >=5 then ''5+'' end as auth_inq_call_6_mnths,
case when program_inq_call_1_mnths = 0 then ''No Calls''
when program_inq_call_1_mnths = 1 then ''1''
when program_inq_call_1_mnths = 2 then ''2''
when program_inq_call_1_mnths in (3,4) then ''3-4''
when program_inq_call_1_mnths >=5 then ''5+'' end as program_inq_call_1_mnths,
case when program_inq_call_2_mnths = 0 then ''No Calls''
when program_inq_call_2_mnths = 1 then ''1''
when program_inq_call_2_mnths = 2 then ''2''
when program_inq_call_2_mnths in (3,4) then ''3-4''
when program_inq_call_2_mnths >=5 then ''5+'' end as program_inq_call_2_mnths,
case when program_inq_call_3_mnths = 0 then ''No Calls''
when program_inq_call_3_mnths = 1 then ''1''
when program_inq_call_3_mnths = 2 then ''2''
when program_inq_call_3_mnths in (3,4) then ''3-4''
when program_inq_call_3_mnths >=5 then ''5+'' end as program_inq_call_3_mnths,
case when program_inq_call_6_mnths = 0 then ''No Calls''
when program_inq_call_6_mnths = 1 then ''1''
when program_inq_call_6_mnths = 2 then ''2''
when program_inq_call_6_mnths in (3,4) then ''3-4''
when program_inq_call_6_mnths >=5 then ''5+'' end as program_inq_call_6_mnths,
case when enrl_inq_call_1_mnths = 0 then ''No Calls''
when enrl_inq_call_1_mnths = 1 then ''1''
when enrl_inq_call_1_mnths = 2 then ''2''
when enrl_inq_call_1_mnths in (3,4) then ''3-4''
when enrl_inq_call_1_mnths >=5 then ''5+'' end as enrl_inq_call_1_mnths,
case when enrl_inq_call_2_mnths = 0 then ''No Calls''
when enrl_inq_call_2_mnths = 1 then ''1''
when enrl_inq_call_2_mnths = 2 then ''2''
when enrl_inq_call_2_mnths in (3,4) then ''3-4''
when enrl_inq_call_2_mnths >=5 then ''5+'' end as enrl_inq_call_2_mnths,
case when enrl_inq_call_3_mnths = 0 then ''No Calls''
when enrl_inq_call_3_mnths = 1 then ''1''
when enrl_inq_call_3_mnths = 2 then ''2''
when enrl_inq_call_3_mnths in (3,4) then ''3-4''
when enrl_inq_call_3_mnths >=5 then ''5+'' end as enrl_inq_call_3_mnths,
case when enrl_inq_call_6_mnths = 0 then ''No Calls''
when enrl_inq_call_6_mnths = 1 then ''1''
when enrl_inq_call_6_mnths = 2 then ''2''
when enrl_inq_call_6_mnths in (3,4) then ''3-4''
when enrl_inq_call_6_mnths >=5 then ''5+'' end as enrl_inq_call_6_mnths,
case when fulfill_inq_call_1_mnths = 0 then ''No Calls''
when fulfill_inq_call_1_mnths = 1 then ''1''
when fulfill_inq_call_1_mnths = 2 then ''2''
when fulfill_inq_call_1_mnths in (3,4) then ''3-4''
when fulfill_inq_call_1_mnths >=5 then ''5+'' end as fulfill_inq_call_1_mnths,
case when fulfill_inq_call_2_mnths = 0 then ''No Calls''
when fulfill_inq_call_2_mnths = 1 then ''1''
when fulfill_inq_call_2_mnths = 2 then ''2''
when fulfill_inq_call_2_mnths in (3,4) then ''3-4''
when fulfill_inq_call_2_mnths >=5 then ''5+'' end as fulfill_inq_call_2_mnths,
case when fulfill_inq_call_3_mnths = 0 then ''No Calls''
when fulfill_inq_call_3_mnths = 1 then ''1''
when fulfill_inq_call_3_mnths = 2 then ''2''
when fulfill_inq_call_3_mnths in (3,4) then ''3-4''
when fulfill_inq_call_3_mnths >=5 then ''5+'' end as fulfill_inq_call_3_mnths,
case when fulfill_inq_call_6_mnths = 0 then ''No Calls''
when fulfill_inq_call_6_mnths = 1 then ''1''
when fulfill_inq_call_6_mnths = 2 then ''2''
when fulfill_inq_call_6_mnths in (3,4) then ''3-4''
when fulfill_inq_call_6_mnths >=5 then ''5+'' end as fulfill_inq_call_6_mnths,
case when rebill_inq_call_1_mnths = 0 then ''No Calls''
when rebill_inq_call_1_mnths = 1 then ''1''
when rebill_inq_call_1_mnths = 2 then ''2''
when rebill_inq_call_1_mnths in (3,4) then ''3-4''
when rebill_inq_call_1_mnths >=5 then ''5+'' end as rebill_inq_call_1_mnths,
case when rebill_inq_call_2_mnths = 0 then ''No Calls''
when rebill_inq_call_2_mnths = 1 then ''1''
when rebill_inq_call_2_mnths = 2 then ''2''
when rebill_inq_call_2_mnths in (3,4) then ''3-4''
when rebill_inq_call_2_mnths >=5 then ''5+'' end as rebill_inq_call_2_mnths,
case when rebill_inq_call_3_mnths = 0 then ''No Calls''
when rebill_inq_call_3_mnths = 1 then ''1''
when rebill_inq_call_3_mnths = 2 then ''2''
when rebill_inq_call_3_mnths in (3,4) then ''3-4''
when rebill_inq_call_3_mnths >=5 then ''5+'' end as rebill_inq_call_3_mnths,
case when rebill_inq_call_6_mnths = 0 then ''No Calls''
when rebill_inq_call_6_mnths = 1 then ''1''
when rebill_inq_call_6_mnths = 2 then ''2''
when rebill_inq_call_6_mnths in (3,4) then ''3-4''
when rebill_inq_call_6_mnths >=5 then ''5+'' end as rebill_inq_call_6_mnths,
case when silver_inq_call_1_mnths = 0 then ''No Calls''
when silver_inq_call_1_mnths = 1 then ''1''
when silver_inq_call_1_mnths = 2 then ''2''
when silver_inq_call_1_mnths in (3,4) then ''3-4''
when silver_inq_call_1_mnths >=5 then ''5+'' end as silver_inq_call_1_mnths,
case when silver_inq_call_2_mnths = 0 then ''No Calls''
when silver_inq_call_2_mnths = 1 then ''1''
when silver_inq_call_2_mnths = 2 then ''2''
when silver_inq_call_2_mnths in (3,4) then ''3-4''
when silver_inq_call_2_mnths >=5 then ''5+'' end as silver_inq_call_2_mnths,
case when silver_inq_call_3_mnths = 0 then ''No Calls''
when silver_inq_call_3_mnths = 1 then ''1''
when silver_inq_call_3_mnths = 2 then ''2''
when silver_inq_call_3_mnths in (3,4) then ''3-4''
when silver_inq_call_3_mnths >=5 then ''5+'' end as silver_inq_call_3_mnths,
case when silver_inq_call_6_mnths = 0 then ''No Calls''
when silver_inq_call_6_mnths = 1 then ''1''
when silver_inq_call_6_mnths = 2 then ''2''
when silver_inq_call_6_mnths in (3,4) then ''3-4''
when silver_inq_call_6_mnths >=5 then ''5+'' end as silver_inq_call_6_mnths,
case when web_inq_call_1_mnths = 0 then ''No Calls''
when web_inq_call_1_mnths = 1 then ''1''
when web_inq_call_1_mnths = 2 then ''2''
when web_inq_call_1_mnths in (3,4) then ''3-4''
when web_inq_call_1_mnths >=5 then ''5+'' end as web_inq_call_1_mnths,
case when web_inq_call_2_mnths = 0 then ''No Calls''
when web_inq_call_2_mnths = 1 then ''1''
when web_inq_call_2_mnths = 2 then ''2''
when web_inq_call_2_mnths in (3,4) then ''3-4''
when web_inq_call_2_mnths >=5 then ''5+'' end as web_inq_call_2_mnths,
case when web_inq_call_3_mnths = 0 then ''No Calls''
when web_inq_call_3_mnths = 1 then ''1''
when web_inq_call_3_mnths = 2 then ''2''
when web_inq_call_3_mnths in (3,4) then ''3-4''
when web_inq_call_3_mnths >=5 then ''5+'' end as web_inq_call_3_mnths,
case when web_inq_call_6_mnths = 0 then ''No Calls''
when web_inq_call_6_mnths = 1 then ''1''
when web_inq_call_6_mnths = 2 then ''2''
when web_inq_call_6_mnths in (3,4) then ''3-4''
when web_inq_call_6_mnths >=5 then ''5+'' end as web_inq_call_6_mnths,
case when demog_inq_call_1_mnths = 0 then ''No Calls''
when demog_inq_call_1_mnths = 1 then ''1''
when demog_inq_call_1_mnths = 2 then ''2''
when demog_inq_call_1_mnths in (3,4) then ''3-4''
when demog_inq_call_1_mnths >=5 then ''5+'' end as demog_inq_call_1_mnths,
case when demog_inq_call_2_mnths = 0 then ''No Calls''
when demog_inq_call_2_mnths = 1 then ''1''
when demog_inq_call_2_mnths = 2 then ''2''
when demog_inq_call_2_mnths in (3,4) then ''3-4''
when demog_inq_call_2_mnths >=5 then ''5+'' end as demog_inq_call_2_mnths,
case when demog_inq_call_3_mnths = 0 then ''No Calls''
when demog_inq_call_3_mnths = 1 then ''1''
when demog_inq_call_3_mnths = 2 then ''2''
when demog_inq_call_3_mnths in (3,4) then ''3-4''
when demog_inq_call_3_mnths >=5 then ''5+'' end as demog_inq_call_3_mnths,
case when demog_inq_call_6_mnths = 0 then ''No Calls''
when demog_inq_call_6_mnths = 1 then ''1''
when demog_inq_call_6_mnths = 2 then ''2''
when demog_inq_call_6_mnths in (3,4) then ''3-4''
when demog_inq_call_6_mnths >=5 then ''5+'' end as demog_inq_call_6_mnths
from IDENTIFIER(:V_ACP_2024_25) where state_name != ''UNKNOWN'';      


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_SUMM_DATA_CAMPAIGN_2025)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP42'';

V_STEP_NAME :=  ''Create V_MEMBER_INFO_PERSUPV2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_MEMBER_COUNTV1) COPY GRANTS as 
select * from 
		(select a.*, ROW_NUMBER () over (PARTITION by medicare_hicn_cd order by mbr_plan_eff_dt asc) as Rn1 
		from 
	IDENTIFIER(:V_PDP_INDV_MBR_CONT) a)b where Rn1 = 1;

create or replace table  IDENTIFIER(:V_MEMBER_INFO_V1) COPY GRANTS as 
select * from 
		(select a.*, ROW_NUMBER () over (PARTITION by pers_id order by hsehld_id asc) as Rn1 
		from 
	IDENTIFIER(:V_D_MBR_INFO) a)b where Rn1 = 1;

create or replace table IDENTIFIER(:V_MEMBER_INFO_PERSUPV2) COPY GRANTS as
select b.pers_id,a.* 
from  IDENTIFIER(:V_MEMBER_COUNTV1) as a
left join 
IDENTIFIER(:V_MEMBER_INFO_V1)  as b 
on a.medicare_hicn_cd  = b.MEDCR_CLM_NBR
and a.medicare_hicn_cd is not null
and a.mbr_plan_eff_dt != a.dsenrl_dt;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_MEMBER_INFO_PERSUPV2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP43'';

V_STEP_NAME :=  ''Create V_SUMM_DATA_CAMPAIGN_2025_TESTV1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_SUMM_DATA_CAMPAIGN_2025_TESTV1) COPY GRANTS as 
select a.*
	,b.pdp_mbr_fg
	,b.dsenrl_dt
	,b.mbr_plan_eff_dt
	,CASE WHEN b.pers_id IS NOT NULL and b.pdp_mbr_fg = ''Y'' 
	and a.actual_drop_date > b.mbr_plan_eff_dt 
	and a.actual_drop_date < b.dsenrl_dt THEN ''Y'' ELSE ''N'' END AS PDP_1yr_FLG
from 
	IDENTIFIER(:V_SUMM_DATA_CAMPAIGN_2025) as a 
left join 
	IDENTIFIER(:V_MEMBER_INFO_PERSUPV2) as b 
on 
	a.person_id = b.pers_id
	and b.mbr_plan_eff_dt != b.dsenrl_dt;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_SUMM_DATA_CAMPAIGN_2025_TESTV1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP44'';

V_STEP_NAME :=  ''Create V_SUMM_DATA_CAMPAIGN_2025_TESTV3'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_SUMM_DATA_CAMPAIGN_2025_TESTV3) COPY GRANTS as 
select *
	,CASE WHEN PDP_1yr_FLG = ''Y''
	and dsenrl_dt > mbr_plan_eff_dt and datediff(day,actual_drop_date,dsenrl_dt) between 0 and 30 then 1 ELSE 0 end as PDP_Lapse_1month,
	CASE WHEN PDP_1yr_FLG = ''Y''
	and dsenrl_dt > mbr_plan_eff_dt and datediff(day,actual_drop_date,dsenrl_dt) between 0 and 60 then 1 ELSE 0 end as PDP_Lapse_2month,
	CASE WHEN PDP_1yr_FLG = ''Y''
	and dsenrl_dt > mbr_plan_eff_dt and datediff(day,actual_drop_date,dsenrl_dt) between 0 and 90 then 1 ELSE 0 end as PDP_Lapse_3month,
	CASE WHEN PDP_1yr_FLG = ''Y''
	and dsenrl_dt > mbr_plan_eff_dt and datediff(day,actual_drop_date,dsenrl_dt) between 0 and 180 then 1 ELSE 0 end as PDP_Lapse_6month
from 
	IDENTIFIER(:V_SUMM_DATA_CAMPAIGN_2025_TESTV1); 

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_SUMM_DATA_CAMPAIGN_2025_TESTV3)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP45'';

V_STEP_NAME :=  ''Create V_SUMM_CAMPAIGN_2025_TESTV4'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_SUMM_CAMPAIGN_2025_TESTV4) COPY GRANTS as            
select 
initiative
,campaigncode
,campaign_name
,cellcode
,cellname
,channel_code
,actual_drop_date
,age_group
,gender
,income
,state_code
,state_name
,disposition_code
,disposition_reason_code
,disposition_reason_desc
,csr_contact_ind
,web_rg_1mnth --0/1
,web_rg_2mnth --0/1 
,web_rg_3mnth --0/1
,web_rg_6mnth --0/1
,ot_1mo --0/1
,ot_2mo
,ot_3mo
,ot_6mo
,rec_1mo --0/1
,rec_2mo
,rec_3mo
,rec_6mo
,switch_1mo,switch_2mo,switch_3mo,switch_6mo
,ACP_1mo,ACP_2mo,ACP_3mo,ACP_6mo
,vol_lapse_1mo,vol_lapse_2mo,vol_lapse_3mo,vol_lapse_6mo,tenure,plan,acq_channel
,pdp_1yr_flg as Pdp_Flag
,pdp_lapse_1month
,pdp_lapse_2month
,pdp_lapse_3month
,pdp_lapse_6month
,Service_States
,priv_1mnth --0/1
,priv_2mnth
,priv_3mnth
,priv_6mnth
,nhl_1mnth --0/1
,nhl_2mnth
,nhl_3mnth
,nhl_6mnth
,VAS_regst
,VAS_reg_1mo
,VAS_reg_2mo
,VAS_reg_3mo
,VAS_reg_6mo
,ons_1mnth
,ons_2mnth
,ons_3mnth
,ons_6mnth
,VAS_gym_1mnth --0/1
,VAS_gym_2mnth
,VAS_gym_3mnth
,VAS_gym_6mnth
,VAS_event_1mnth --0/1
,VAS_event_2mnth
,VAS_event_3mnth
,VAS_event_6mnth
,VAS_telephonic_1mnth --0/1
,VAS_telephonic_2mnth
,VAS_telephonic_3mnth
,VAS_telephonic_6mnth,
VAS_renew_active_gym_1mnth,
VAS_renew_active_gym_2mnth,
VAS_renew_active_gym_3mnth,
VAS_renew_active_gym_6mnth,
VAS_staying_sharp_1mnth,
VAS_staying_sharp_2mnth,
VAS_staying_sharp_3mnth,
VAS_staying_sharp_6mnth,
call_fg --0/1
,call_1_flag --0/1
,call_2_flag
,call_3_flag
,call_6_flag
,no_calls_1_mnths
,no_calls_2_mnths
,no_calls_3_mnths
,no_calls_6_mnths
,bill_pay_inq_call_1_mnths
,bill_pay_inq_call_2_mnths
,bill_pay_inq_call_3_mnths
,bill_pay_inq_call_6_mnths
,claim_inq_call_1_mnths
,claim_inq_call_2_mnths
,claim_inq_call_3_mnths
,claim_inq_call_6_mnths
,telemarketing_inq_call_1_mnths
,telemarketing_inq_call_2_mnths
,telemarketing_inq_call_3_mnths
,telemarketing_inq_call_6_mnths
,opprtnty_inq_call_1_mnths
,opprtnty_inq_call_2_mnths
,opprtnty_inq_call_3_mnths
,opprtnty_inq_call_6_mnths
,plan_inq_call_1_mnths
,plan_inq_call_2_mnths
,plan_inq_call_3_mnths
,plan_inq_call_6_mnths
,auth_main_inq_call_1_mnths
,auth_main_inq_call_2_mnths
,auth_main_inq_call_3_mnths
,auth_main_inq_call_6_mnths
,auth_inq_call_1_mnths
,auth_inq_call_2_mnths
,auth_inq_call_3_mnths
,auth_inq_call_6_mnths
,program_inq_call_1_mnths
,program_inq_call_2_mnths
,program_inq_call_3_mnths
,program_inq_call_6_mnths
,enrl_inq_call_1_mnths
,enrl_inq_call_2_mnths
,enrl_inq_call_3_mnths
,enrl_inq_call_6_mnths
,fulfill_inq_call_1_mnths
,fulfill_inq_call_2_mnths
,fulfill_inq_call_3_mnths
,fulfill_inq_call_6_mnths
,rebill_inq_call_1_mnths
,rebill_inq_call_2_mnths
,rebill_inq_call_3_mnths
,rebill_inq_call_6_mnths
,silver_inq_call_1_mnths
,silver_inq_call_2_mnths
,silver_inq_call_3_mnths
,silver_inq_call_6_mnths
,web_inq_call_1_mnths
,web_inq_call_2_mnths
,web_inq_call_3_mnths
,web_inq_call_6_mnths
,demog_inq_call_1_mnths
,demog_inq_call_2_mnths
,demog_inq_call_3_mnths
,demog_inq_call_6_mnths
,sale_fg --0/1
,sale_1mo
,sale_2mo
,sale_3mo
,sale_6mo
,paidsale_fg --0/1
,paidsale_1mo
,paidsale_2mo
,paidsale_3mo
,paidsale_6mo,
''0'' as c_mkt_id,
''0'' as c_dis_mkt_id,
count(person_id) as c_pid, count(distinct person_id) as c_dis_pid,
sum(bounce_1week) as tot_bounce_1week
,sum(bounce_2week) as tot_bounce_2week
,sum(bounce_3week) as tot_bounce_3week
,sum(bounce_4week) as tot_bounce_4week
,sum(click_1week) as tot_click_1week
,sum(click_2week) as tot_click_2week
,sum(click_3week) as tot_click_3week
,sum(click_4week) as tot_click_4week
,sum(not_sent_1week) as tot_not_sent_1week
,sum(not_sent_2week) as tot_not_sent_2week
,sum(not_sent_3week) as tot_not_sent_3week
,sum(not_sent_4week) as tot_not_sent_4week
,sum(open_1week) as tot_open_1week
,sum(open_2week) as tot_open_2week
,sum(open_3week) as tot_open_3week
,sum(open_4week) as tot_open_4week
,sum(sent_1week) as tot_sent_1week
,sum(sent_2week) as tot_sent_2week
,sum(sent_3week) as tot_sent_3week
,sum(sent_4week) as tot_sent_4week
,sum(subscribe_1week) as tot_subscribe_1week
,sum(subscribe_2week) as tot_subscribe_2week
,sum(subscribe_3week) as tot_subscribe_3week
,sum(subscribe_4week) as tot_subscribe_4week
,sum(unsubscribe_1week) as tot_unsubscribe_1week
,sum(unsubscribe_2week) as tot_unsubscribe_2week
,sum(unsubscribe_3week) as tot_unsubscribe_3week
,sum(unsubscribe_4week) as tot_unsubscribe_4week
,sum(total_calls_1_mnths) as tot_calls_1_mnths
,sum(total_calls_2_mnths) as tot_calls_2_mnths
,sum(total_calls_3_mnths) as tot_calls_3_mnths
,sum(total_calls_6_mnths) as tot_calls_6_mnths
from IDENTIFIER(:V_SUMM_DATA_CAMPAIGN_2025_TESTV3)
group by
initiative
,campaigncode
,campaign_name
,cellcode
,cellname
,channel_code
,actual_drop_date
,age_group
,gender
,income
,state_code
,state_name
,disposition_code
,disposition_reason_code
,disposition_reason_desc
,csr_contact_ind
,web_rg_1mnth --0/1
,web_rg_2mnth --0/1 
,web_rg_3mnth --0/1
,web_rg_6mnth --0/1
,ot_1mo --0/1
,ot_2mo
,ot_3mo
,ot_6mo
,rec_1mo --0/1
,rec_2mo
,rec_3mo
,rec_6mo
,switch_1mo,switch_2mo,switch_3mo,switch_6mo
,ACP_1mo,ACP_2mo,ACP_3mo,ACP_6mo
,vol_lapse_1mo,vol_lapse_2mo,vol_lapse_3mo,vol_lapse_6mo,tenure,plan,acq_channel
,pdp_1yr_flg
,pdp_lapse_1month
,pdp_lapse_2month
,pdp_lapse_3month
,pdp_lapse_6month
,Service_States
,priv_1mnth --0/1
,priv_2mnth
,priv_3mnth
,priv_6mnth
,nhl_1mnth --0/1
,nhl_2mnth
,nhl_3mnth
,nhl_6mnth
,VAS_regst
,VAS_reg_1mo
,VAS_reg_2mo
,VAS_reg_3mo
,VAS_reg_6mo
,ons_1mnth
,ons_2mnth
,ons_3mnth
,ons_6mnth
,VAS_gym_1mnth --0/1
,VAS_gym_2mnth
,VAS_gym_3mnth
,VAS_gym_6mnth
,VAS_event_1mnth --0/1
,VAS_event_2mnth
,VAS_event_3mnth
,VAS_event_6mnth
,VAS_telephonic_1mnth --0/1
,VAS_telephonic_2mnth
,VAS_telephonic_3mnth
,VAS_telephonic_6mnth,
VAS_renew_active_gym_1mnth,
VAS_renew_active_gym_2mnth,
VAS_renew_active_gym_3mnth,
VAS_renew_active_gym_6mnth,
VAS_staying_sharp_1mnth,
VAS_staying_sharp_2mnth,
VAS_staying_sharp_3mnth,
VAS_staying_sharp_6mnth
,call_fg --0/1
,call_1_flag --0/1
,call_2_flag
,call_3_flag
,call_6_flag
,no_calls_1_mnths
,no_calls_2_mnths
,no_calls_3_mnths
,no_calls_6_mnths
,bill_pay_inq_call_1_mnths
,bill_pay_inq_call_2_mnths
,bill_pay_inq_call_3_mnths
,bill_pay_inq_call_6_mnths
,claim_inq_call_1_mnths
,claim_inq_call_2_mnths
,claim_inq_call_3_mnths
,claim_inq_call_6_mnths
,telemarketing_inq_call_1_mnths
,telemarketing_inq_call_2_mnths
,telemarketing_inq_call_3_mnths
,telemarketing_inq_call_6_mnths
,opprtnty_inq_call_1_mnths
,opprtnty_inq_call_2_mnths
,opprtnty_inq_call_3_mnths
,opprtnty_inq_call_6_mnths
,plan_inq_call_1_mnths
,plan_inq_call_2_mnths
,plan_inq_call_3_mnths
,plan_inq_call_6_mnths
,auth_main_inq_call_1_mnths
,auth_main_inq_call_2_mnths
,auth_main_inq_call_3_mnths
,auth_main_inq_call_6_mnths
,auth_inq_call_1_mnths
,auth_inq_call_2_mnths
,auth_inq_call_3_mnths
,auth_inq_call_6_mnths
,program_inq_call_1_mnths
,program_inq_call_2_mnths
,program_inq_call_3_mnths
,program_inq_call_6_mnths
,enrl_inq_call_1_mnths
,enrl_inq_call_2_mnths
,enrl_inq_call_3_mnths
,enrl_inq_call_6_mnths
,fulfill_inq_call_1_mnths
,fulfill_inq_call_2_mnths
,fulfill_inq_call_3_mnths
,fulfill_inq_call_6_mnths
,rebill_inq_call_1_mnths
,rebill_inq_call_2_mnths
,rebill_inq_call_3_mnths
,rebill_inq_call_6_mnths
,silver_inq_call_1_mnths
,silver_inq_call_2_mnths
,silver_inq_call_3_mnths
,silver_inq_call_6_mnths
,web_inq_call_1_mnths
,web_inq_call_2_mnths
,web_inq_call_3_mnths
,web_inq_call_6_mnths
,demog_inq_call_1_mnths
,demog_inq_call_2_mnths
,demog_inq_call_3_mnths
,demog_inq_call_6_mnths
,sale_fg --0/1
,sale_1mo
,sale_2mo
,sale_3mo
,sale_6mo
,paidsale_fg --0/1
,paidsale_1mo
,paidsale_2mo
,paidsale_3mo
,paidsale_6mo
;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_SUMM_CAMPAIGN_2025_TESTV4)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);								
								
EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);


RAISE;

END;

';
