--call SP_BASE_POPULATION('1234','RTO_MODELS','UBLIA_TST_ISDC_DEV_DB','UTIL','BDR_FFP_DA','BDR_FFP_DA_WRK','BDR_SMART','BDR_CONF','UBLIA_TST_WORK_XS_WH',CURRENT_DATE())
--call SP_RTO_MODELS_1('1234','RTO_MODELS','UBLIA_TST_ISDC_DEV_DB','UTIL','BDR_FFP_DA','BDR_FFP_DA_WRK','BDR_SMART','BDR_DM','UBLIA_TST_WORK_XS_WH',CURRENT_DATE())
--call SP_RTO_MODELS_2('1234','RTO_MODELS','UBLIA_TST_ISDC_DEV_DB','UTIL','BDR_FFP_DA','BDR_FFP_DA_WRK','BDR_SMART','BDR_DM','UBLIA_TST_WORK_XS_WH',CURRENT_DATE())

--call SP_RTO_MODELS_3('1234','RTO_MODELS','UBLIA_TST_ISDC_DEV_DB','UTIL','BDR_FFP_DA','BDR_FFP_DA_WRK','BDR_SMART','UBLIA_TST_WORK_XS_WH',CURRENT_DATE())
USE SCHEMA BDR_FFP_DA;

CREATE OR REPLACE PROCEDURE BDR_FFP_DA.SP_RTO_MODELS_3("PIPELINE_ID" VARCHAR(16777216), "PIPELINE_NAME" VARCHAR(16777216), "DB_NAME" VARCHAR(16777216), "UTIL_SC" VARCHAR(16777216), "TGT_SC" VARCHAR(16777216), "FFP_WRK_SC" VARCHAR(16777216), "SRC_SC" VARCHAR(16777216), "WH" VARCHAR(16777216), "CURR_DATE" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

V_CURRENT_DATE   DATE := COALESCE(TO_DATE(:CURR_DATE), CURRENT_DATE());

V_TYPE VARCHAR := COALESCE(''SYS'', ''FILL DEFAULT VALUE'');

V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := :DB_NAME||''.''||COALESCE(:UTIL_SC, ''UTIL'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';

V_PROCESS_NAME   VARCHAR DEFAULT ''RTO MODELS'';

V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''CODE17'';

V_STEP             VARCHAR;

V_STEP_NAME        VARCHAR;

V_START_TIME       VARCHAR;

V_END_TIME         VARCHAR;

V_ROWS_PARSED       INTEGER;

V_ROWS_LOADED       INTEGER;

V_MESSAGE          VARCHAR;

V_LAST_QUERY_ID    VARCHAR;



--Source Tables
V_DB_REFINED_POLICY_PERSON_PAYMENT_METHOD VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.PERSON_PAYMENT_METHOD'';
V_DB_REFINED_POLICY_PERSON_LATE_PAYMENT VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.PERSON_LATE_PAYMENT'';
V_DB_REFINED_CAMPAIGN_CAMPAIGN_EXTRACT_DETAIL VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.CAMPAIGN_EXTRACT_DETAIL'';
V_DB_REFINED_CAMPAIGN_CAMPAIGN_EXTRACT VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.CAMPAIGN_EXTRACT'';
V_DB_REFINED_PARTY_SHIP_PERSON_XREF VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.SHIP_PERSON_XREF'';
V_DB_REFINED_CAMPAIGN_SM_CAMPAIGN VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.SM_CAMPAIGN'';
V_DB_REFINED_PARTY_OPTUM_SHIP_VAS_ENGAGEMENT VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.OPTUM_SHIP_VAS_ENGAGEMENT'';
V_DB_REFINED_CAMPAIGN_MARKETING_CONTACT VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.MARKETING_CONTACT'';

--Intermediate Tables
V_WORK_DIR_EFT_TABLE1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_TABLE1'';
V_WORK_DIR_EFT_PULL_AMERILINK_TYPE VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PULL_AMERILINK_PRIV_SS'';
V_WORK_DIR_EFT_TYPE_FINAL_DATASET VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PRIV_SS_FINAL_DATASET'';
V_WORK_DIR_EFT_NBA_EFT1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_NBA_EFT1'';
V_WORK_DIR_EFT_TYPE_FINAL_DATASET9 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PRIV_SS_FINAL_DATASET9'';
V_WORK_DIR_EFT_P_AUTH VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_P_AUTH'';
V_WORK_DIR_EFT_1TIME_POP VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_1TIME_POP'';
V_WORK_DIR_EFT_T2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_T2'';
V_WORK_DIR_EFT_CAMPS_COUNTS VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_CAMPS_COUNTS'';
V_WORK_DIR_EFT_TYPE_FINAL_DATASET2_01 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PRIV_SS_FINAL_DATASET2_01'';
V_WORK_DIR_EFT_CLAIM_BASE_POP_2_TYPE VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_CLAIM_BASE_POP_2_PRIV_SS'';
V_WORK_DIR_EFT_PULL_INSPLAN_SPEC_2_TYPE VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PULL_INSPLAN_SPEC_2_PRIV_SS'';
V_WORK_DIR_EFT_CDWCLMS_BASE_POP_1_TYPE VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_CDWCLMS_BASE_POP_1_PRIV_SS'';
V_WORK_DIR_EFT_TYPE_FINAL_DATASET6 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_SYS_FINAL_DATASET6'';
V_WORK_DIR_EFT_FINAL_NBA_DATA_V2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_FINAL_NBA_DATA_V2'';
V_WORK_DIR_EFT_TYPE_FINAL_DATASET3 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PRIV_SS_FINAL_DATASET3'';
V_WORK_DIR_EFT_PULL_ECC_CLAIMS_POP_1_TYPE VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PULL_ECC_CLAIMS_POP_1_PRIV_SS'';
V_WORK_DIR_EFT_PULL_FINAL_TENURE_TYPE VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PULL_FINAL_TENURE_PRIV_SS'';
V_WORK_DIR_EFT_TYPE_FINAL_DATASET7 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PRIV_SS_FINAL_DATASET7'';
V_WORK_DIR_EFT_TABLE_RECC_EFT_ACTIVE VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_TABLE_RECC_EFT_ACTIVE'';
V_WORK_DIR_EFT_TYPE_FINAL_DATASET2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PRIV_SS_FINAL_DATASET2'';
V_WORK_DIR_EFT_FINAL_TYPE_DATA_V2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_FINAL_PRIV_SS_DATA_V2'';
V_WORK_DIR_EFT_WEB_REG_CAMPS VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_WEB_REG_CAMPS'';
V_WORK_DIR_EFT_APP_REPORTING_BASEPOP_TYPE VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_APP_REPORTING_BASEPOP_PRIV_SS'';
V_WORK_DIR_EFT_LATEPAYERS VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_LATEPAYERS'';
V_WORK_DIR_EFT_PULL_INSPLAN_PROFILE_2_TYPE VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PULL_INSPLAN_PROFILE_2_PRIV_SS'';
V_WORK_DIR_EFT_BASE_POP_TYPE VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_BASE_POP_PRIV_SS'';
V_WORK_DIR_EFT_REC_POP VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_REC_POP'';
V_WORK_DIR_EFT_ZIP_CODE_BASE1_TYPE VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_ZIP_CODE_BASE1_PRIV_SS'';
V_WORK_DIR_EFT_NBA_DATA VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_NBA_DATA'';
V_WORK_DIR_EFT_REC_POP1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_REC_POP1'';
V_WORK_DIR_EFT_PREMIUM_BASE_POP_1_TYPE VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PREMIUM_BASE_POP_1_PRIV_SS'';
V_WORK_DIR_EFT_NBA_DATA_01 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_NBA_DATA_01'';
V_WORK_DIR_EFT_TYPE_FINAL_DATASET1_01 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PRIV_SS_FINAL_DATASET1_01'';
V_WORK_DIR_EFT_WEB_REG_CAMPS1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_WEB_REG_CAMPS1'';
V_WORK_DIR_EFT_NBA_EFT2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_NBA_EFT2'';
V_WORK_DIR_EFT_PULL_CALL_DATA_BASE_POP_TYPE VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PULL_CALL_DATA_BASE_POP_PRIV_SS'';
V_WORK_DIR_EFT_TYPE_FINAL_DATASET4 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PRIV_SS_FINAL_DATASET4'';
V_WORK_DIR_EFT_TABLE_RECC_EFT_ACTIVE1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_TABLE_RECC_EFT_ACTIVE1'';
V_WORK_DIR_EFT_TYPE_FINAL_DATASET5 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PRIV_SS_FINAL_DATASET5'';
V_WORK_DIR_EFT_T3 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_T3'';
V_WORK_DIR_EFT_TYPE_DATA_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PRIV_SS_DATA_1'';
V_WORK_DIR_EFT_TREATMENT_BASE_POP_1_TYPE VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_TREATMENT_BASE_POP_1_PRIV_SS'';
V_WORK_DIR_EFT_PULL_PERSON_PROF_TYPE VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PULL_PERSON_PROF_PRIV_SS'';
V_WORK_DIR_EFT_ECC_CLMS_BASE_POP_1_TYPE VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_ECC_CLMS_BASE_POP_1_PRIV_SS'';
V_WORK_DIR_EFT_CAMP_COUNTS VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_CAMP_COUNTS'';
V_WORK_DIR_EFT_TYPE_FINAL_DATASET1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PRIV_SS_FINAL_DATASET1'';
V_WORK_DIR_EFT_PULL_PERSON_TYPE VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PULL_PERSON_PRIV_SS'';
V_WORK_DIR_EFT_TYPE_FINAL_DATASET8 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PRIV_SS_FINAL_DATASET8'';
V_WORK_DIR_EFT_TEMP VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_TEMP'';
V_WORK_DIR_PREV_EFT_TYPE_FINAL_DATASET9 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_PREV_EFT_PRIV_SS_FINAL_DATASET9'';

V_WORK_DIR_EFT_PDP_FG_BASEPOP_1_SYS VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PDP_FG_BASEPOP_1_PRIV_SS'';





BEGIN


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP1'';

V_STEP_NAME :=  ''create a table EFT_FINAL_TYPE_DATA_V2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());



create or replace table IDENTIFIER(:V_WORK_DIR_EFT_FINAL_TYPE_DATA_V2) as
select distinct base.person_id,base.individual_id,base.actual_drop_date,
b.tot_proc_days_3_mnths,
b.tot_proc_days_6_mnths,
b.tot_proc_days,
b.avg_proc_days_3_mnths,
b.avg_proc_days_6_mnths,
b.avg_proc_days,
b.max_proc_days_3_mnths,
b.max_proc_days_6_mnths,
b.max_proc_days,
b.min_proc_days_3_mnths,
b.min_proc_days_6_mnths,
b.min_proc_days,
b.tot_benefit_amt_3_mnths,
b.tot_benefit_amt_6_mnths,
b.tot_benefit_amt, 
d.ecc_bl_payment_amount_3_mnths,
d.ecc_bl_payment_amount_6_mnths,
d.ecc_bl_payment_amount,
d.a_ecc_bl_payment_amount_3_mnths,
d.a_ecc_bl_payment_amount_6_mnths,
d.a_ecc_bl_payment_amount,
d.ecc_coins_amount_3_mnths,
d.ecc_coins_amount_6_mnths,
d.ecc_coins_amount,
d.a_ecc_coins_amount_3_mnths,
d.a_ecc_coins_amount_6_mnths,
d.a_ecc_coins_amount,
d.service_days_3_mnths,
d.service_days_6_mnths,
d.service_days,
d.a_service_days_3_mnths,
d.a_service_days_6_mnths,
d.a_service_days,
e.ecc_claim_total_amt_pd_3_mnths,
e.ecc_claim_total_amt_pd_6_mnths,
e.ecc_claim_total_amt_paid,
e.a_ecc_claim_total_amt_pd_3_mnths,
e.a_ecc_claim_total_amt_pd_6_mnths,
e.a_ecc_claim_total_amt_paid,
e.ecc_claim_total_app_3_mnths,
e.ecc_claim_total_app_6_mnths,
e.ecc_claim_total_app_amt,
e.a_ecc_claim_total_app_3_mnths,
e.a_ecc_claim_total_app_6_mnths,
e.a_ecc_claim_total_app_amt,
e.ecc_claim_total_charge_3_mnths,
e.ecc_claim_total_charge_6_mnths,
e.ecc_claim_total_charge,
e.a_ecc_claim_total_charge_3_mnths,
e.a_ecc_claim_total_charge_6_mnths,
e.a_ecc_claim_total_charge,
e.ecc_claim_total_deuct_3_mnths,
e.ecc_claim_total_deuct_6_mnths,
e.ecc_claim_total_deuct,
e.a_ecc_claim_total_deuct_3_mnths,
e.a_ecc_claim_total_deuct_6_mnths,
e.a_ecc_claim_total_deuct,
e.ecc_clm_tot_inelig_amt_3_mnths,
e.ecc_clm_tot_inelig_amt_6_mnths,
e.ecc_clm_tot_inelig_amt,
e.a_ecc_clm_tot_inelig_amt_3_mnths,
e.a_ecc_clm_tot_inelig_amt_6_mnths,
e.a_ecc_clm_tot_inelig_amt, 
g.no_calls_3_mnths,
g.no_calls_6_mnths,
g.no_calls,
g.bill_pay_inq_call_3_mnths,
g.bill_pay_inq_call_6_mnths,
g.bill_pay_inq_call,
g.claim_inq_call_3_mnths,
g.claim_inq_call_6_mnths,
g.claim_inq_call,
g.telemarketing_inq_call_3_mnths,
g.telemarketing_inq_call_6_mnths,
g.telemarketing_inq_call,
g.opprtnty_inq_call_3_mnths,
g.opprtnty_inq_call_6_mnths,
g.opprtnty_inq_call,
g.plan_inq_call_3_mnths,
g.plan_inq_call_6_mnths,
g.plan_inq_call,
h.no_treatment_3_mnths,
h.no_treatment_6_mnths,
h.no_treatment,
h.no_pres_mcare_edu_3_mnths,
h.no_pres_mcare_edu_6_mnths,
h.no_pres_mcare_edu,
h.no_pres_priv_auth_3_mnths,
h.no_pres_priv_auth_6_mnths,
h.no_pres_priv_auth,
h.no_pres_priv_crgiver_3_mnths,
h.no_pres_priv_crgiver_6_mnths,
h.no_pres_priv_crgiver,
h.no_pres_web_reg_3_mnths,
h.no_pres_web_reg_6_mnths,
h.no_pres_web_reg,
h.at_your_best_pos_3_months,
h.at_your_best_pos_6_months,
h.at_your_best_positive,
h.at_your_best_neg_3_months,
h.at_your_best_neg_6_months,
h.at_your_best_negative,
h.eft_web_promo_neg_3_months,
h.eft_web_promo_neg_6_months,
h.eft_web_promo_negative,
h.eft_web_promo_pos_3_months,
h.eft_web_promo_pos_6_months,
h.eft_web_promo_positive,
h.heal_well_res_neg_3_months,
h.heal_well_res_neg_6_months,
h.heal_well_res_negative,
h.heal_well_res_pos_3_months,
h.heal_well_res_pos_6_months,
h.heal_well_res_positive,
h.med_ed_neg_3_months,
h.med_ed_neg_6_months,
h.med_ed_negative,
h.med_ed_pos_3_months,
h.med_ed_pos_6_months,
h.med_ed_positive,
h.med_ed_neut_3_months,
h.med_ed_neut_6_months,
h.med_ed_neutral,
i.application_id,
i.appl_receipt_date,
i.adjudication_date,
i.application_processing_time,
j.msup_num_lapses,
j.msup_num_plan_changes,
j.msup_active_prod_duration,
j.msup_rate_determination_code,
q.tenure,
s.zip_code,
s.network_hosp_dist,
t.no_claims_3_mnths,
t.no_claims_6_mnths,
t.no_claims,
t.part_b_deduct_3_mnths,
t.part_b_deduct_6_mnths,
t.part_b_deduct,
t.avg_part_b_deduct_3_mnths,
t.avg_part_b_deduct_6_mnths,
t.avg_part_b_deduct,
t.oop_amount_3_mnths,
t.oop_amount_6_mnths,
t.oop_amount,
t.avg_oop_amount_3_mnths,
t.avg_oop_amount_6_mnths,
t.avg_oop_amount,
t.adjust_benefit_amount_3_mnths,
t.adjust_benefit_amount_6_mnths,
t.adjust_benefit_amount,
t.avg_adjust_benefit_amt_3_mnths,
t.avg_adjust_benefit_amt_6_mnths,
t.avg_adjust_benefit_amount,
t.benefit_amount_3_mnths,
t.benefit_amount_6_mnths,
t.benefit_amount_12_mnths,
t.avg_benefit_amount_3_mnths,
t.avg_benefit_amount_6_mnths,
t.avg_benefit_amount,
t.covered_expense_3_mnths,
t.covered_expense_6_mnths,
t.tot_covered_expense,
t.avg_covered_expense_3_mnths,
t.avg_covered_expense_6_mnths,
t.avg_tot_covered_expense,
t.charge_amount_3_mnths,
t.charge_amount_6_mnths,
t.charge_amount,
t.avg_charge_amount_3_mnths,
t.avg_charge_amount_6_mnths,
t.avg_charge_amount,
t.deductible_amount_3_mnths,
t.deductible_amount_6_mnths,
t.deductible_amount,
t.avg_deductible_amount_3_mnths,
t.avg_deductible_amount_6_mnths,
t.avg_deductible_amount,
t.medicare_app_amount_3_mnths,
t.medicare_app_amount_6_mnths,
t.medicare_app_amount,
t.avg_medicare_app_amount_3_mnths,
t.avg_medicare_app_amount_6_mnths,
t.avg_medicare_app_amount,
t.medicare_pay_amount_3_mnths,
t.medicare_pay_amount_6_mnths,
t.medicare_pay_amount_12_mnths,
t.avg_medicare_pay_amount_3_mnths,
t.avg_medicare_pay_amount_6_mnths,
t.avg_medicare_pay_amount,
t.benefit_period_days_3_mnths,
t.benefit_period_days_6_mnths,
t.benefit_period_days_12_mnths,
u.disabled_ind,
u.smoker_ind,
u.adjusted_base_type_code,
u.begin_date,
u.end_date,
u.group_plan_id,
u.group_plan_type_id,
u.insured_plan_id,
u.insured_plan_profile_id,
u.loyalty_program_code,
u.rate_determination_code,
v.no_premium_3_mnths,
v.no_premium_6_mnths,
v.no_premium,
v.annual_payor_disc_amt_3_mnths,
v.annual_payor_disc_amt_6_mnths,
v.tot_annual_payor_disc_amt,
v.tot_eft_disc_amount_3_mnths,
v.tot_eft_disc_amount_6_mnths,
v.tot_eft_disc_amount,
v.tot_loyalty_disc_amount_3_mnths,
v.tot_loyalty_disc_amount_6_mnths,
v.tot_loyalty_disc_amount,
v.tot_premium_amt_3_mnths,
v.tot_premium_amt_6_mnths,
v.tot_premium_amt,
v.paid_net_memb_cont_amt_3_mnths,
v.paid_net_memb_cont_amt_6_mnths,
v.paid_net_memb_cont_amt,
v.tot_spouse_disc_amt_3_mnths,
v.tot_spouse_disc_amt_6_mnths,
v.tot_spouse_disc_amt,
v.tot_eb_subsidy_paid_amt_3_mnths,
v.tot_eb_subsidy_paid_amt_6_mnths,
v.tot_eb_subsidy_paid_amt,
v.paid_cert_qnty_3_mnths,
v.paid_cert_qnty_6_mnths,
v.paid_cert_qnty,
v.termed_cert_qnty_3_mnths,
v.termed_cert_qnty_6_mnths,
v.termed_cert_qnty,
w.individual_premium_amount,
w.employer_premium_amount,
w.plan_effective_date,
w.plan_termination_date,
w.specification_id,
w.ins_plan_switcher_ind,
w.language_preference_id,
w.specification_name,
w.product_type_var,
w.plan_code,
w.product_secondary_var_code,
w.product_type_code,
x.famp,
x.iola,
x.onla,
x.ret,
x.orac,
x.aalz,
x.aasm,
x.abce,
x.adbt,
x.agresp,
x.ahbp,
x.ahrt,
x.alng,
x.ares,
x.bc,
x.hhcomp,
x.homval,
x.homstat,
x.nah19,
x.nph19,
x.noc19,
x.poc19,
x.netw19,
x.pwheelch,
x.estinc19,
x.mr,
x.veri,
x.famp_bcgm,
x.famp_f,
x.famp_h,
x.famp_psw,
x.bank_card_multiple,
x.bank_card_single,
x.homeowner_fg,
x.children_present,
x.networth,
x.income,
x.mr_m,
x.mr_y,
x.married_with_children,
x.married_no_children,
x.male_with_no_children,
x.female_with_no_children,
y.gender_code,
y.birth_date,
case  when z.person_id is not null then 1  else 0 end as pdp_fg_final
from 
IDENTIFIER(:V_WORK_DIR_EFT_BASE_POP_TYPE) base 
left join IDENTIFIER(:V_WORK_DIR_EFT_CDWCLMS_BASE_POP_1_TYPE) b 
on base.person_id = b.person_id and base.actual_drop_date=b.actual_drop_date
left join IDENTIFIER(:V_WORK_DIR_EFT_PULL_ECC_CLAIMS_POP_1_TYPE) d 
on base.person_id = d.person_id and base.actual_drop_date=d.actual_drop_date
left join IDENTIFIER(:V_WORK_DIR_EFT_ECC_CLMS_BASE_POP_1_TYPE) e 
on base.person_id = e.person_id and base.actual_drop_date=e.actual_drop_date
left join IDENTIFIER(:V_WORK_DIR_EFT_PULL_CALL_DATA_BASE_POP_TYPE) g 
on base.person_id = g.person_id and base.actual_drop_date=g.actual_drop_date
left join IDENTIFIER(:V_WORK_DIR_EFT_TREATMENT_BASE_POP_1_TYPE) h 
on base.person_id = h.person_id and base.actual_drop_date=h.actual_drop_date
left join IDENTIFIER(:V_WORK_DIR_EFT_APP_REPORTING_BASEPOP_TYPE) i 
on base.person_id = i.person_id and base.actual_drop_date=i.actual_drop_date
left join IDENTIFIER(:V_WORK_DIR_EFT_PULL_PERSON_PROF_TYPE) j 
on base.person_id = j.person_id
left join IDENTIFIER(:V_WORK_DIR_EFT_PULL_FINAL_TENURE_TYPE) q 
on base.person_id = q.person_id and base.actual_drop_date=q.actual_drop_date
left join IDENTIFIER(:V_WORK_DIR_EFT_ZIP_CODE_BASE1_TYPE) s
on base.person_id = s.person_id and base.actual_drop_date=s.actual_drop_date
left join IDENTIFIER(:V_WORK_DIR_EFT_CLAIM_BASE_POP_2_TYPE) t
on base.person_id = t.person_id and base.actual_drop_date=t.actual_drop_date
left join IDENTIFIER(:V_WORK_DIR_EFT_PULL_INSPLAN_PROFILE_2_TYPE) u
on base.person_id = u.person_id and base.actual_drop_date=u.actual_drop_date
left join IDENTIFIER(:V_WORK_DIR_EFT_PREMIUM_BASE_POP_1_TYPE) v
on base.person_id = v.person_id and base.actual_drop_date=v.actual_drop_date
left join IDENTIFIER(:V_WORK_DIR_EFT_PULL_INSPLAN_SPEC_2_TYPE) w
on  base.person_id = w.person_id and base.actual_drop_date=w.actual_drop_date
left join IDENTIFIER(:V_WORK_DIR_EFT_PULL_AMERILINK_TYPE) x
on  base.person_id = x.person_id and base.actual_drop_date=x.actual_drop_date
left join IDENTIFIER(:V_WORK_DIR_EFT_PULL_PERSON_TYPE) y
on  base.person_id = y.person_id and base.actual_drop_date=y.actual_drop_date
left join (select DISTINCT person_id from IDENTIFIER(:V_WORK_DIR_EFT_PDP_FG_BASEPOP_1_SYS)) z
on base.person_id=z.person_id;




V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_WORK_DIR_EFT_FINAL_TYPE_DATA_V2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




V_STEP := ''STEP2'';

V_STEP_NAME :=  ''create a table WORK_DIR_EFT_FINAL_NBA_DATA_V2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());



create or replace table IDENTIFIER(:V_WORK_DIR_EFT_FINAL_NBA_DATA_V2) as
select * ,
case when RATE_DETERMINATION_CODE=1 then 1 else 0 end as RDC_1,
case when RATE_DETERMINATION_CODE=2 then 1 else 0 end as RDC_2,
case when RATE_DETERMINATION_CODE=3 then 1 else 0 end as RDC_3,
case when RATE_DETERMINATION_CODE=4 then 1 else 0 end as RDC_4,
case when (tenure < 180 and tenure > 0) then 1  when tenure is null then null  else 0 end as new_member_fg,
cast(null as int) as no_app_acc_disc_3_mnths,
cast(null as int) as no_app_claims_3_mnths,
cast(null as int) as no_app_claimscorr_3_mnths,
cast(null as int) as no_app_Enroll_3_mnths,
cast(null as int) as no_app_CSS_complain_3_mnths,
cast(null as int) as total_appeals_3_months,
cast(null as int) as no_app_acc_disc_6_mnths,
cast(null as int) as no_app_claims_6_mnths,
cast(null as int) as no_app_claimscorr_6_mnths,
cast(null as int) as no_app_Enroll_6_mnths,
cast(null as int) as no_app_CSS_complain_6_mnths,
cast(null as int) as total_appeals_6_months,
cast(null as int) as no_app_acc_disc,
cast(null as int) as no_app_claims,
cast(null as int) as no_app_claimscorr,
cast(null as int) as no_app_Enroll,
cast(null as int) as no_app_CSS_complain,
cast(null as int) as total_appeals,
-- /*no_app_acc_disc_3_mnths+no_app_claims_3_mnths+no_app_claimscorr_3_mnths,no_app_Enroll_3_mnths+no_app_CSS_complain_3_mnths as total_appeals_3_months, */
-- /* no_app_acc_disc_6_mnths+no_app_claims_6_mnths+no_app_claimscorr_6_mnths+no_app_Enroll_6_mnths+no_app_CSS_complain_6_mnths as total_appeals_6_months,*/
-- /*no_app_acc_disc+no_app_claims+no_app_claimscorr+no_app_Enroll+no_app_CSS_complain as total_appeals,*/
floor(UTIL.DATE_DIFF_UDF(actual_drop_date,BIRTH_DATE)/365) as age,
case when disabled_ind=''N'' then 0  when disabled_ind = ''Y'' then 1 end as disabled_ind_var,
case when gender_code = ''M'' then 0  when gender_code = ''F'' then 1 end as Gender_F,
cast(null as int) as INS_code,
-- /*case when INS_code = 1 then 1  else 0 end as INS_code_1,*/
0 as INS_code_1,
-- /*case when (INS_code = 2 or INS_code = 3) then 1 else 0 end as INS_code_23,*/
0 as INS_code_23,
cast(null as int) as TERMINATION_ID,
-- /*case when TERMINATION_ID = 11 then 1  else 0 end as termination_id_11_var,*/
0 as termination_id_11_var,
-- /*case when underwrite_code in (''B'', ''N'', ''Y'') then 1  else 0 end as underwrite_code_BNY,*/
-- /*case when underwrite_code in (''W'') then 1 else 0 end as underwrite_code_W,*/
cast(null as string) as underwrite_code,
0 as underwrite_code_BNY,
0 as underwrite_code_W,
case when INS_PLAN_SWITCHER_IND=''N'' then 0  when INS_PLAN_SWITCHER_IND = ''Y'' then 1  end as INS_PLAN_SWITCHER_IND_var,
case when product_type_code in (''H'', ''R'') then 1 else 0 end as product_type_code_HR,
case when product_type_code in (''M'') then 1 else 0 end as product_type_code_M,
case when SMOKER_IND = ''N'' then 0  when SMOKER_IND = ''Y'' then 1  end as SMOKER_IND_VAR,
cast(null as string) as deliverable_mail_IND,
-- /*case when deliverable_mail_IND = ''N'' then 0  when deliverable_mail_IND = ''Y'' then 1  end as deliverable_mail_IND_VAR,*/
cast(null as int) as deliverable_mail_IND_VAR,
cast(null as string) as empl_spons_cov_IND,
-- /*case when empl_spons_cov_IND = ''N'' then 0  when empl_spons_cov_IND = ''Y'' then 1 end as empl_spons_cov_IND_VAR,*/
cast(null as int) as empl_spons_cov_IND_VAR,
cast(null as string) as Employer_account_IND,
-- /*case when Employer_account_IND = ''N'' then 0  when Employer_account_IND = ''Y'' then 1 end as Employer_account_IND_VAR,*/
cast(null as int) as Employer_account_IND_VAR,
cast(null as string) as ESRD_Denial_IND,
-- /*case when ESRD_Denial_IND = ''N'' then 0  when ESRD_Denial_IND = ''Y''  then 1 end as ESRD_Denial_IND_VAR,*/
cast(null as int) as ESRD_Denial_IND_VAR,
cast(null as string) as GLOBAL_SUPPRESS_IND,
-- /*case when GLOBAL_SUPPRESS_IND = ''N'' then 0  when GLOBAL_SUPPRESS_IND = ''Y'' then 1 end as GLOBAL_SUPPRESS_IND_VAR,*/
cast(null as int) as GLOBAL_SUPPRESS_IND_VAR,
cast(null as string) as Medicare_dis_IND,
-- /*case when Medicare_dis_IND = ''N'' then 0  when Medicare_dis_IND = ''Y'' then 1 end as Medicare_dis_IND_VAR,*/
cast(null as int) as Medicare_dis_IND_VAR,
cast(null as string) as Msup_benefit_mod_IND,
-- /*case when Msup_benefit_mod_IND = ''N'' then 0  when Msup_benefit_mod_IND = ''Y'' then 1  end as Msup_benefit_mod_IND_VAR,*/
cast(null as int) as Msup_benefit_mod_IND_VAR,
cast(null as string) as adjudication_status_code,
-- /*case when adjudication_status_code = ''A'' then 1  else 0 end as  adjudication_status_code_A,*/
0 adjudication_status_code_A,
-- /*case when adjudication_status_code in (''D'',''P'', ''W'') then 1 else 0 end as adjudication_status_code_DPW*/
0 adjudication_status_code_DPW
from IDENTIFIER(:V_WORK_DIR_EFT_FINAL_TYPE_DATA_V2);




V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_WORK_DIR_EFT_FINAL_NBA_DATA_V2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



-- /*Treatment extra variables*/

V_STEP := ''STEP3'';

V_STEP_NAME :=  ''create a table DIR_EFT_TEMP'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_WORK_DIR_EFT_TEMP) as
select distinct a.person_id,a.actual_drop_date,
b.optum_ship_vas_engagement_id,
b.ucps_person_id,
b.begin_date,
b.end_date,
b.value_added_service_code,
b.ayb_engaged_activity,
b.row_ins_timestamp
from IDENTIFIER(:V_WORK_DIR_EFT_FINAL_NBA_DATA_V2) a
left join IDENTIFIER(:V_DB_REFINED_PARTY_SHIP_PERSON_XREF) xr on a.person_id = xr.person_id
inner join IDENTIFIER(:V_DB_REFINED_PARTY_OPTUM_SHIP_VAS_ENGAGEMENT) b on xr.ucps_person_id = b.ucps_person_id;


V_STEP := ''STEP4'';

V_STEP_NAME :=  ''create a table WORK_DIR_EFT_T2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());



create or replace table IDENTIFIER(:V_WORK_DIR_EFT_T2) as
select * , 
case  when (UTIL.DATE_DIFF_UDF(actual_drop_date,end_date)<365 and UTIL.DATE_DIFF_UDF(actual_drop_date,end_date) >= 0) then 1 else 0 end as VAS_term_one_year_fg,
case  when (UTIL.DATE_DIFF_UDF(end_date,actual_drop_date)>0 or end_date is null) then 1  else 0 end as VAS_Active_fg
from IDENTIFIER(:V_WORK_DIR_EFT_TEMP)
where begin_date < actual_drop_date and (end_date is null or end_date  > dateadd(''day'',-365,actual_drop_date));


V_STEP := ''STEP5'';

V_STEP_NAME :=  ''create a table WORK_DIR_EFT_T3'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_WORK_DIR_EFT_T3) as
select *, 1 as vas_fg,
case when VALUE_ADDED_SERVICE_CODE=''MCP'' then 1 end as MCP_fg,
case when VALUE_ADDED_SERVICE_CODE=''AYB'' then 1 end as AYB_fg,
case when (VALUE_ADDED_SERVICE_CODE=''AYB'' and AYB_ENGAGED_ACTIVITY=''G'')
then 1 end as AYB_GYM_fg,
case when (VALUE_ADDED_SERVICE_CODE=''AYB'' and AYB_ENGAGED_ACTIVITY=''E'')
then 1 end as AYB_event_fg,
case when (VALUE_ADDED_SERVICE_CODE=''AYB'' and AYB_ENGAGED_ACTIVITY=''P'')
then 1 end as AYB_portal_fg,
case when (VALUE_ADDED_SERVICE_CODE=''AYB'' and AYB_ENGAGED_ACTIVITY=''T'')
then 1 end as AYB_telephonic_fg
from IDENTIFIER(:V_WORK_DIR_EFT_T2);


V_STEP := ''STEP6'';

V_STEP_NAME :=  ''create a table EFT_NBA_DATA_01'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());



create or replace table IDENTIFIER(:V_WORK_DIR_EFT_NBA_DATA_01) as
select b.person_id,b.actual_drop_date,
sum(b.vas_fg) as vas_count,
sum(b.MCP_fg) as MCP_count,
sum(b.AYB_fg) as AYB_count,
sum(b. VAS_term_one_year_fg) as VAS_term_one_year_count,
sum(b. VAS_Active_fg) as VAS_Active_count,
sum(b.AYB_GYM_fg) as AYB_GYM_count,
sum(b. AYB_event_fg) as AYB_event_count,
sum(b. AYB_portal_fg) as AYB_portal_count,
sum(b. AYB_telephonic_fg) as AYB_telephonic_count
from IDENTIFIER(:V_WORK_DIR_EFT_T3) b
group by b.person_id,b.actual_drop_date;


-- /*vas_count*/

V_STEP := ''STEP7'';

V_STEP_NAME :=  ''create a table EFT_NBA_DATA'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());




create or replace table IDENTIFIER(:V_WORK_DIR_EFT_NBA_DATA) as
select 
person_id,
actual_drop_date,
case when vas_count > 0 then 1 else 0 end as vas_fg,
case when MCP_count > 0 then 1 else 0 end as MCP_fg,
case when AYB_count > 0 then 1 else 0 end as AYB_fg,
case when  VAS_term_one_year_count > 0 THEN 1 else 0 end as VAS_term_one_year_fg,
case when VAS_Active_count > 0 THEN 1 else 0 end as VAS_Active_fg ,
case when AYB_GYM_count > 0 THEN 1 else 0 end as AYB_GYM_fg,
case when AYB_event_count > 0 THEN 1 else 0 end as  AYB_event_fg,
case when AYB_portal_count > 0 THEN 1 else 0 end as AYB_portal_fg ,
case when AYB_telephonic_count > 0 THEN 1 else 0 end as AYB_telephonic_fg
 from 
IDENTIFIER(:V_WORK_DIR_EFT_NBA_DATA_01);


V_STEP := ''STEP8'';

V_STEP_NAME :=  ''create a table EFT_TYPE_DATA_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());




create or replace table IDENTIFIER(:V_WORK_DIR_EFT_TYPE_DATA_1) as
select a.*,
b.vas_fg,
b.MCP_fg,
b.AYB_fg,
b.VAS_term_one_year_fg,
b.VAS_Active_fg,
b.AYB_GYM_fg,
b.AYB_event_fg,
b.AYB_portal_fg,
b.AYB_telephonic_fg
from IDENTIFIER(:V_WORK_DIR_EFT_FINAL_NBA_DATA_V2) a left join IDENTIFIER(:V_WORK_DIR_EFT_NBA_DATA) b
on a.person_id=b.person_id
and a.actual_drop_date=b.actual_drop_date;


V_STEP := ''STEP9'';

V_STEP_NAME :=  ''create a table EFT_TYPE_FINAL_DATASET'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());




create or replace table IDENTIFIER(:V_WORK_DIR_EFT_TYPE_FINAL_DATASET) as
select * from IDENTIFIER(:V_WORK_DIR_EFT_TYPE_DATA_1);




V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_WORK_DIR_EFT_TYPE_FINAL_DATASET)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



-- /*################################################### Common Code ends #############################################################################*/
-- /*################################################### Variables for specific models #############################################################################*/
-- /* Variables for privacy authorization*/

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP10'';

V_STEP_NAME :=  ''create a table EFT_P_AUTH'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_WORK_DIR_EFT_P_AUTH) as 
select mc.person_id,ce.actual_drop_date,mc.mkt_contact_id,mc.campaign_extract_id,ced.targeted_message,ce.campaignid,ce.cellname,
ce.cellcode,ce.extract_date,smc.name,smc.campaigncode,smc.initiative,smc.business_Segment
FROM  IDENTIFIER(:V_DB_REFINED_CAMPAIGN_MARKETING_CONTACT)  mc
Inner join IDENTIFIER(:V_DB_REFINED_CAMPAIGN_CAMPAIGN_EXTRACT)  ce
on mc.CAMPAIGN_EXTRACT_ID=ce.CAMPAIGN_EXTRACT_ID
Inner join IDENTIFIER(:V_DB_REFINED_CAMPAIGN_SM_CAMPAIGN)  smc
on ce.CAMPAIGNID=smc.CAMPAIGNID 
left join IDENTIFIER(:V_DB_REFINED_CAMPAIGN_CAMPAIGN_EXTRACT_DETAIL)  ced 
on ce.campaign_extract_id= ced.campaign_extract_id
where campaigncode in (''C000004004'')
and trim(targeted_message) = ''PRIVACY AUTHORIZATION''
order by person_id , actual_drop_date;




V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_WORK_DIR_EFT_P_AUTH)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



-- /*getting person_id and campaign send date in a table*/



V_STEP := ''STEP11'';

V_STEP_NAME :=  ''create a table EFT_TABLE1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_WORK_DIR_EFT_TABLE1) as 
select distinct person_id, actual_drop_date
from IDENTIFIER(:V_WORK_DIR_EFT_P_AUTH);


V_STEP := ''STEP12'';

V_STEP_NAME :=  ''create a table EFT_TYPE_FINAL_DATASET1_01'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());



create or replace table IDENTIFIER(:V_WORK_DIR_EFT_TYPE_FINAL_DATASET1_01) as
select a.person_id,a.actual_drop_date, 
count(distinct b.actual_drop_date) as no_nba_camp_sent_before,
count(distinct case when UTIL.DATE_DIFF_UDF(a.actual_drop_date,b.actual_drop_date)>0 and UTIL.DATE_DIFF_UDF(a.actual_drop_date,b.actual_drop_date) < 30 THEN b.actual_drop_date  end ) as no_nba_sent_1mnths,
count(distinct case when UTIL.DATE_DIFF_UDF(a.actual_drop_date,b.actual_drop_date)>0 and UTIL.DATE_DIFF_UDF(a.actual_drop_date,b.actual_drop_date) < 90 THEN b.actual_drop_date  end ) as no_nba_sent_3mnths,
count(distinct case when UTIL.DATE_DIFF_UDF(a.actual_drop_date,b.actual_drop_date)>0 and UTIL.DATE_DIFF_UDF(a.actual_drop_date,b.actual_drop_date) < 180 THEN b.actual_drop_date  end ) as no_nba_sent_6mnths,
count(distinct case when UTIL.DATE_DIFF_UDF(a.actual_drop_date,b.actual_drop_date)>0 and UTIL.DATE_DIFF_UDF(a.actual_drop_date,b.actual_drop_date) < 360 THEN b.actual_drop_date  end ) as no_nba_sent_12mnths
from IDENTIFIER(:V_WORK_DIR_EFT_TYPE_FINAL_DATASET) a left join IDENTIFIER(:V_WORK_DIR_EFT_TABLE1) b
on a.person_id=b.person_id
group by a.person_id,a.actual_drop_date;


V_STEP := ''STEP13'';

V_STEP_NAME :=  ''create a table EFT_TYPE_FINAL_DATASET1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_WORK_DIR_EFT_TYPE_FINAL_DATASET1) as
select a.* , 
b.no_nba_camp_sent_before,
b.no_nba_sent_1mnths,
b.no_nba_sent_3mnths,
b.no_nba_sent_6mnths,
b.no_nba_sent_12mnths
from IDENTIFIER(:V_WORK_DIR_EFT_TYPE_FINAL_DATASET) a left join IDENTIFIER(:V_WORK_DIR_EFT_TYPE_FINAL_DATASET1_01) b 
on a.person_id=b.person_id;



V_STEP := ''STEP14'';

V_STEP_NAME :=  ''create a table EFT_LATEPAYERS'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_WORK_DIR_EFT_LATEPAYERS) as 
select b.person_id, a.actual_drop_date,
count(distinct case when UTIL.DATE_DIFF_UDF(a.actual_drop_date,b.delinquency_date)>=0 and UTIL.DATE_DIFF_UDF(a.actual_drop_date,b.delinquency_date) <= 180 THEN b.delinquency_date  end ) as no_late_6_mnths,
count(distinct case when UTIL.DATE_DIFF_UDF(a.actual_drop_date,b.delinquency_date)>=0 and UTIL.DATE_DIFF_UDF(a.actual_drop_date,b.delinquency_date) <= 360 THEN b.delinquency_date  end ) as no_late_12_mnths
from IDENTIFIER(:V_DB_REFINED_POLICY_PERSON_LATE_PAYMENT) b inner join IDENTIFIER(:V_WORK_DIR_EFT_TYPE_FINAL_DATASET1) a 
on a.person_id=b.person_id
group by b.person_id,a.actual_drop_date;


V_STEP := ''STEP15'';

V_STEP_NAME :=  ''create a table EFT_TYPE_FINAL_DATASET2_01'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_WORK_DIR_EFT_TYPE_FINAL_DATASET2_01) as 
select a.person_id,a.actual_drop_date,sum(b.no_late_6_mnths) as no_late_6_mnths,
sum(b.no_late_12_mnths) as no_late_12_mnths
from IDENTIFIER(:V_WORK_DIR_EFT_TYPE_FINAL_DATASET1) a left join IDENTIFIER(:V_WORK_DIR_EFT_LATEPAYERS) b
on a.person_id=b.person_id
and a.actual_drop_date=b.actual_drop_date
group by a.person_id,a.actual_drop_date;


V_STEP := ''STEP16'';

V_STEP_NAME :=  ''create a table EFT_TYPE_FINAL_DATASET2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());



create or replace table IDENTIFIER(:V_WORK_DIR_EFT_TYPE_FINAL_DATASET2) as 
select a.* ,
b.no_late_6_mnths,b.no_late_12_mnths
from IDENTIFIER(:V_WORK_DIR_EFT_TYPE_FINAL_DATASET1) a left join 
IDENTIFIER(:V_WORK_DIR_EFT_TYPE_FINAL_DATASET2_01) b
on a.person_id=b.person_id;


V_STEP := ''STEP17'';

V_STEP_NAME :=  ''create a table EFT_1TIME_POP'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_WORK_DIR_EFT_1TIME_POP) as
select cast(b.person_id as int) as person_id, a.actual_drop_date,
count(distinct case when UTIL.DATE_DIFF_UDF(a.actual_drop_date,b.begin_date)>0 and UTIL.DATE_DIFF_UDF(a.actual_drop_date,b.begin_date) <= 180 and b.EFT_FREQUENCY_TYPE_ID=2 THEN b.begin_date  end ) as no_1timeEFT_6mths,
count(distinct case when UTIL.DATE_DIFF_UDF(a.actual_drop_date,b.begin_date)>0 and UTIL.DATE_DIFF_UDF(a.actual_drop_date,b.begin_date) <= 360 and b.EFT_FREQUENCY_TYPE_ID=2 THEN b.begin_date  end ) as no_1timeEFT_12mths
from IDENTIFIER(:V_DB_REFINED_POLICY_PERSON_PAYMENT_METHOD)  b inner join IDENTIFIER(:V_WORK_DIR_EFT_TYPE_FINAL_DATASET2) a 
on a.person_id=b.person_id
group by cast(b.person_id as int),a.actual_drop_date;


V_STEP := ''STEP18'';

V_STEP_NAME :=  ''create a table EFT_REC_POP'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_WORK_DIR_EFT_REC_POP) as
select distinct cast(a.person_id as int) as person_id, a.actual_drop_date,
case  when (b.begin_date is not null and b.begin_date<a.actual_drop_date 
and b.EFT_FREQUENCY_TYPE_ID=1 and UTIL.DATE_DIFF_UDF(a.actual_drop_date,b.end_date)>=0 and UTIL.DATE_DIFF_UDF(a.actual_drop_date,b.end_date) <= 360) THEN 1 else 0  end as previous_recc_EFT_360days
from IDENTIFIER(:V_DB_REFINED_POLICY_PERSON_PAYMENT_METHOD)  b inner join IDENTIFIER(:V_WORK_DIR_EFT_TYPE_FINAL_DATASET2) a 
on a.person_id=b.person_id;

-- /*Flag for recc in previous 360 days*/


V_STEP := ''STEP19'';

V_STEP_NAME :=  ''create a table EFT_REC_POP1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_WORK_DIR_EFT_REC_POP1) as
select person_id, actual_drop_date,previous_recc_EFT_360days
from IDENTIFIER(:V_WORK_DIR_EFT_REC_POP)
where previous_recc_EFT_360days=1;


V_STEP := ''STEP20'';

V_STEP_NAME :=  ''create a table EFT_TYPE_FINAL_DATASET3'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_WORK_DIR_EFT_TYPE_FINAL_DATASET3) as
select distinct 
a.person_id,
a.individual_id,
a.actual_drop_date,
a.tot_proc_days_3_mnths,
a.tot_proc_days_6_mnths,
a.tot_proc_days,
a.avg_proc_days_3_mnths,
a.avg_proc_days_6_mnths,
a.avg_proc_days,
a.max_proc_days_3_mnths,
a.max_proc_days_6_mnths,
a.max_proc_days,
a.min_proc_days_3_mnths,
a.min_proc_days_6_mnths,
a.min_proc_days,
a.tot_benefit_amt_3_mnths,
a.tot_benefit_amt_6_mnths,
a.tot_benefit_amt,
a.ecc_bl_payment_amount_3_mnths,
a.ecc_bl_payment_amount_6_mnths,
a.ecc_bl_payment_amount,
a.a_ecc_bl_payment_amount_3_mnths,
a.a_ecc_bl_payment_amount_6_mnths,
a.a_ecc_bl_payment_amount,
a.ecc_coins_amount_3_mnths,
a.ecc_coins_amount_6_mnths,
a.ecc_coins_amount,
a.a_ecc_coins_amount_3_mnths,
a.a_ecc_coins_amount_6_mnths,
a.a_ecc_coins_amount,
a.service_days_3_mnths,
a.service_days_6_mnths,
a.service_days,
a.a_service_days_3_mnths,
a.a_service_days_6_mnths,
a.a_service_days,
a.ecc_claim_total_amt_pd_3_mnths,
a.ecc_claim_total_amt_pd_6_mnths,
a.ecc_claim_total_amt_paid,
a.a_ecc_claim_total_amt_pd_3_mnths,
a.a_ecc_claim_total_amt_pd_6_mnths,
a.a_ecc_claim_total_amt_paid,
a.ecc_claim_total_app_3_mnths,
a.ecc_claim_total_app_6_mnths,
a.ecc_claim_total_app_amt,
a.a_ecc_claim_total_app_3_mnths,
a.a_ecc_claim_total_app_6_mnths,
a.a_ecc_claim_total_app_amt,
a.ecc_claim_total_charge_3_mnths,
a.ecc_claim_total_charge_6_mnths,
a.ecc_claim_total_charge,
a.a_ecc_claim_total_charge_3_mnths,
a.a_ecc_claim_total_charge_6_mnths,
a.a_ecc_claim_total_charge,
a.ecc_claim_total_deuct_3_mnths,
a.ecc_claim_total_deuct_6_mnths,
a.ecc_claim_total_deuct,
a.a_ecc_claim_total_deuct_3_mnths,
a.a_ecc_claim_total_deuct_6_mnths,
a.a_ecc_claim_total_deuct,
a.ecc_clm_tot_inelig_amt_3_mnths,
a.ecc_clm_tot_inelig_amt_6_mnths,
a.ecc_clm_tot_inelig_amt,
a.a_ecc_clm_tot_inelig_amt_3_mnths,
a.a_ecc_clm_tot_inelig_amt_6_mnths,
a.a_ecc_clm_tot_inelig_amt,
a.no_calls_3_mnths,
a.no_calls_6_mnths,
a.no_calls,
a.bill_pay_inq_call_3_mnths,
a.bill_pay_inq_call_6_mnths,
a.bill_pay_inq_call,
a.claim_inq_call_3_mnths,
a.claim_inq_call_6_mnths,
a.claim_inq_call,
a.telemarketing_inq_call_3_mnths,
a.telemarketing_inq_call_6_mnths,
a.telemarketing_inq_call,
a.opprtnty_inq_call_3_mnths,
a.opprtnty_inq_call_6_mnths,
a.opprtnty_inq_call,
a.plan_inq_call_3_mnths,
a.plan_inq_call_6_mnths,
a.plan_inq_call,
a.no_treatment_3_mnths,
a.no_treatment_6_mnths,
a.no_treatment,
a.no_pres_mcare_edu_3_mnths,
a.no_pres_mcare_edu_6_mnths,
a.no_pres_mcare_edu,
a.no_pres_priv_auth_3_mnths,
a.no_pres_priv_auth_6_mnths,
a.no_pres_priv_auth,
a.no_pres_priv_crgiver_3_mnths,
a.no_pres_priv_crgiver_6_mnths,
a.no_pres_priv_crgiver,
a.no_pres_web_reg_3_mnths,
a.no_pres_web_reg_6_mnths,
a.no_pres_web_reg,
a.at_your_best_pos_3_months,
a.at_your_best_pos_6_months,
a.at_your_best_positive,
a.at_your_best_neg_3_months,
a.at_your_best_neg_6_months,
a.at_your_best_negative,
a.eft_web_promo_neg_3_months,
a.eft_web_promo_neg_6_months,
a.eft_web_promo_negative,
a.eft_web_promo_pos_3_months,
a.eft_web_promo_pos_6_months,
a.eft_web_promo_positive,
a.heal_well_res_neg_3_months,
a.heal_well_res_neg_6_months,
a.heal_well_res_negative,
a.heal_well_res_pos_3_months,
a.heal_well_res_pos_6_months,
a.heal_well_res_positive,
a.med_ed_neg_3_months,
a.med_ed_neg_6_months,
a.med_ed_negative,
a.med_ed_pos_3_months,
a.med_ed_pos_6_months,
a.med_ed_positive,
a.med_ed_neut_3_months,
a.med_ed_neut_6_months,
a.med_ed_neutral,
a.application_id,
a.appl_receipt_date,
a.adjudication_date,
a.application_processing_time,
a.msup_num_lapses,
a.msup_num_plan_changes,
a.msup_active_prod_duration,
a.msup_rate_determination_code,
a.tenure,
a.zip_code,
a.network_hosp_dist,
a.no_claims_3_mnths,
a.no_claims_6_mnths,
a.no_claims,
a.part_b_deduct_3_mnths,
a.part_b_deduct_6_mnths,
a.part_b_deduct,
a.avg_part_b_deduct_3_mnths,
a.avg_part_b_deduct_6_mnths,
a.avg_part_b_deduct,
a.oop_amount_3_mnths,
a.oop_amount_6_mnths,
a.oop_amount,
a.avg_oop_amount_3_mnths,
a.avg_oop_amount_6_mnths,
a.avg_oop_amount,
a.adjust_benefit_amount_3_mnths,
a.adjust_benefit_amount_6_mnths,
a.adjust_benefit_amount,
a.avg_adjust_benefit_amt_3_mnths,
a.avg_adjust_benefit_amt_6_mnths,
a.avg_adjust_benefit_amount,
a.benefit_amount_3_mnths,
a.benefit_amount_6_mnths,
a.benefit_amount_12_mnths,
a.avg_benefit_amount_3_mnths,
a.avg_benefit_amount_6_mnths,
a.avg_benefit_amount,
a.covered_expense_3_mnths,
a.covered_expense_6_mnths,
a.tot_covered_expense,
a.avg_covered_expense_3_mnths,
a.avg_covered_expense_6_mnths,
a.avg_tot_covered_expense,
a.charge_amount_3_mnths,
a.charge_amount_6_mnths,
a.charge_amount,
a.avg_charge_amount_3_mnths,
a.avg_charge_amount_6_mnths,
a.avg_charge_amount,
a.deductible_amount_3_mnths,
a.deductible_amount_6_mnths,
a.deductible_amount,
a.avg_deductible_amount_3_mnths,
a.avg_deductible_amount_6_mnths,
a.avg_deductible_amount,
a.medicare_app_amount_3_mnths,
a.medicare_app_amount_6_mnths,
a.medicare_app_amount,
a.avg_medicare_app_amount_3_mnths,
a.avg_medicare_app_amount_6_mnths,
a.avg_medicare_app_amount,
a.medicare_pay_amount_3_mnths,
a.medicare_pay_amount_6_mnths,
a.medicare_pay_amount_12_mnths,
a.avg_medicare_pay_amount_3_mnths,
a.avg_medicare_pay_amount_6_mnths,
a.avg_medicare_pay_amount,
a.benefit_period_days_3_mnths,
a.benefit_period_days_6_mnths,
a.benefit_period_days_12_mnths,
a.disabled_ind,
a.smoker_ind,
a.adjusted_base_type_code,
a.begin_date,
a.end_date,
a.group_plan_id,
a.group_plan_type_id,
a.insured_plan_id,
a.insured_plan_profile_id,
a.loyalty_program_code,
a.rate_determination_code,
a.no_premium_3_mnths,
a.no_premium_6_mnths,
a.no_premium,
a.annual_payor_disc_amt_3_mnths,
a.annual_payor_disc_amt_6_mnths,
a.tot_annual_payor_disc_amt,
a.tot_eft_disc_amount_3_mnths,
a.tot_eft_disc_amount_6_mnths,
a.tot_eft_disc_amount,
a.tot_loyalty_disc_amount_3_mnths,
a.tot_loyalty_disc_amount_6_mnths,
a.tot_loyalty_disc_amount,
a.tot_premium_amt_3_mnths,
a.tot_premium_amt_6_mnths,
a.tot_premium_amt,
a.paid_net_memb_cont_amt_3_mnths,
a.paid_net_memb_cont_amt_6_mnths,
a.paid_net_memb_cont_amt,
a.tot_spouse_disc_amt_3_mnths,
a.tot_spouse_disc_amt_6_mnths,
a.tot_spouse_disc_amt,
a.tot_eb_subsidy_paid_amt_3_mnths,
a.tot_eb_subsidy_paid_amt_6_mnths,
a.tot_eb_subsidy_paid_amt,
a.paid_cert_qnty_3_mnths,
a.paid_cert_qnty_6_mnths,
a.paid_cert_qnty,
a.termed_cert_qnty_3_mnths,
a.termed_cert_qnty_6_mnths,
a.termed_cert_qnty,
a.individual_premium_amount,
a.employer_premium_amount,
a.plan_effective_date,
a.plan_termination_date,
a.specification_id,
a.ins_plan_switcher_ind,
a.language_preference_id,
a.specification_name,
a.product_type_var,
a.plan_code,
a.product_secondary_var_code,
a.product_type_code,
a.famp,
a.iola,
a.onla,
a.ret,
a.orac,
a.aalz,
a.aasm,
a.abce,
a.adbt,
a.agresp,
a.ahbp,
a.ahrt,
a.alng,
a.ares,
a.bc,
a.hhcomp,
a.homval,
a.homstat,
a.nah19,
a.nph19,
a.noc19,
a.poc19,
a.netw19,
a.pwheelch,
a.estinc19,
a.mr,
a.veri,
a.famp_bcgm,
a.famp_f,
a.famp_h,
a.famp_psw,
a.bank_card_multiple,
a.bank_card_single,
a.homeowner_fg,
a.children_present,
a.networth,
a.income,
a.mr_m,
a.mr_y,
a.married_with_children,
a.married_no_children,
a.male_with_no_children,
a.female_with_no_children,
a.gender_code,
a.birth_date,
a.pdp_fg_final,
a.rdc_1,
a.rdc_2,
a.rdc_3,
a.rdc_4,
a.new_member_fg,
a.no_app_acc_disc_3_mnths,
a.no_app_claims_3_mnths,
a.no_app_claimscorr_3_mnths,
a.no_app_enroll_3_mnths,
a.no_app_css_complain_3_mnths,
a.total_appeals_3_months,
a.no_app_acc_disc_6_mnths,
a.no_app_claims_6_mnths,
a.no_app_claimscorr_6_mnths,
a.no_app_enroll_6_mnths,
a.no_app_css_complain_6_mnths,
a.total_appeals_6_months,
a.no_app_acc_disc,
a.no_app_claims,
a.no_app_claimscorr,
a.no_app_enroll,
a.no_app_css_complain,
a.total_appeals,
a.age,
a.disabled_ind_var,
a.gender_f,
a.ins_code,
a.ins_code_1,
a.ins_code_23,
a.termination_id,
a.termination_id_11_var,
a.underwrite_code,
a.underwrite_code_bny,
a.underwrite_code_w,
a.ins_plan_switcher_ind_var,
a.product_type_code_hr,
a.product_type_code_m,
a.smoker_ind_var,
a.deliverable_mail_ind,
a.deliverable_mail_ind_var,
a.empl_spons_cov_ind,
a.empl_spons_cov_ind_var,
a.employer_account_ind,
a.employer_account_ind_var,
a.esrd_denial_ind,
a.esrd_denial_ind_var,
a.global_suppress_ind,
a.global_suppress_ind_var,
a.medicare_dis_ind,
a.medicare_dis_ind_var,
a.msup_benefit_mod_ind,
a.msup_benefit_mod_ind_var,
a.adjudication_status_code,
a.adjudication_status_code_a,
a.adjudication_status_code_dpw,
a.vas_fg,
a.mcp_fg,
a.ayb_fg,
a.vas_term_one_year_fg,
a.vas_active_fg,
a.ayb_gym_fg,
a.ayb_event_fg,
a.ayb_portal_fg,
a.ayb_telephonic_fg,
a.no_nba_camp_sent_before,
a.no_nba_sent_1mnths,
a.no_nba_sent_3mnths,
a.no_nba_sent_6mnths,
a.no_nba_sent_12mnths,
a.no_late_6_mnths,
a.no_late_12_mnths,
b.no_1timeEFT_6mths,b.no_1timeEFT_12mths,c.previous_recc_EFT_360days
from IDENTIFIER(:V_WORK_DIR_EFT_TYPE_FINAL_DATASET2) a left join IDENTIFIER(:V_WORK_DIR_EFT_1TIME_POP) b
on a.person_id=b.person_id
and a.actual_drop_date=b.actual_drop_date
left join IDENTIFIER(:V_WORK_DIR_EFT_REC_POP1) c
on a.person_id=c.person_id
and a.actual_drop_date=c.actual_drop_date;




V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_WORK_DIR_EFT_TYPE_FINAL_DATASET3)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



-- /*-------------------EFT campaigns count- NBA and other campaigns EFT---------------*/

V_STEP := ''STEP21'';

V_STEP_NAME :=  ''create a table EFT_NBA_EFT1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_WORK_DIR_EFT_NBA_EFT1) as
select distinct mc.person_id,ce.actual_drop_date,mc.mkt_contact_id,mc.campaign_extract_id,ced.targeted_message,ce.campaignid,ce.cellname,
ce.cellcode,ce.extract_date,smc.name,smc.campaigncode,smc.initiative,smc.business_Segment
FROM  IDENTIFIER(:V_DB_REFINED_CAMPAIGN_MARKETING_CONTACT)  mc
Inner join IDENTIFIER(:V_DB_REFINED_CAMPAIGN_CAMPAIGN_EXTRACT)  ce
on mc.CAMPAIGN_EXTRACT_ID=ce.CAMPAIGN_EXTRACT_ID
Inner join IDENTIFIER(:V_DB_REFINED_CAMPAIGN_SM_CAMPAIGN)  smc
on ce.CAMPAIGNID=smc.CAMPAIGNID 
left join IDENTIFIER(:V_DB_REFINED_CAMPAIGN_CAMPAIGN_EXTRACT_DETAIL)  ced 
on ce.campaign_extract_id= ced.campaign_extract_id
where (smc.campaigncode in (''C000004004'') and trim(targeted_message) = ''LATE PAYER EFT'' and  ce.ACTUAL_DROP_DATE >= CAST(''2017-07-01'' AS DATE))
or 
(smc.CAMPAIGNCODE IN (''C000002832'',
''C000002884'',
''C000002924'',
''C000001927'',
''C000002230'',
''C000002600'',
''C000002487'',
''C000003461'',
''C000003497'',
''C000003716'',
''C000000445'',
''C000002710'',
''C000003574'',
''C000003594'')
and ce.ACTUAL_DROP_DATE >= CAST(''2017-07-01'' AS DATE));


V_STEP := ''STEP22'';

V_STEP_NAME :=  ''create a table EFT_NBA_EFT2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_WORK_DIR_EFT_NBA_EFT2) as
select person_id, campaigncode, actual_drop_date from IDENTIFIER(:V_WORK_DIR_EFT_NBA_EFT1) order by person_id, campaigncode, actual_drop_date;



V_STEP := ''STEP23'';

V_STEP_NAME :=  ''create a table EFT_CAMP_COUNTS'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_WORK_DIR_EFT_CAMP_COUNTS) as
select a.person_id, a.actual_drop_date,
count(case when UTIL.DATE_DIFF_UDF(a.actual_drop_date,b.actual_drop_date)>0 and UTIL.DATE_DIFF_UDF(a.actual_drop_date,b.actual_drop_date)<=180 and b.campaigncode=''C000002230'' then b.actual_drop_date end) as no_camp_C000002230_180days
,count(case when UTIL.DATE_DIFF_UDF(a.actual_drop_date,b.actual_drop_date)>0 and UTIL.DATE_DIFF_UDF(a.actual_drop_date,b.actual_drop_date)<=180 and b.campaigncode=''C000002487'' then b.actual_drop_date end) as no_camp_C000002487_180days
,count(case when UTIL.DATE_DIFF_UDF(a.actual_drop_date,b.actual_drop_date)>0 and UTIL.DATE_DIFF_UDF(a.actual_drop_date,b.actual_drop_date)<=180 and b.campaigncode=''C000002600'' then b.actual_drop_date end) as no_camp_C000002600_180days
,count(case when UTIL.DATE_DIFF_UDF(a.actual_drop_date,b.actual_drop_date)>0 and UTIL.DATE_DIFF_UDF(a.actual_drop_date,b.actual_drop_date)<=180 and b.campaigncode=''C000003461'' then b.actual_drop_date end) as no_camp_C000003461_180days
,count(case when UTIL.DATE_DIFF_UDF(a.actual_drop_date,b.actual_drop_date)>0 and UTIL.DATE_DIFF_UDF(a.actual_drop_date,b.actual_drop_date)<=180 and b.campaigncode=''C000003594'' then b.actual_drop_date end) as no_camp_C000003594_180days
,count(case when UTIL.DATE_DIFF_UDF(a.actual_drop_date,b.actual_drop_date)>0 and UTIL.DATE_DIFF_UDF(a.actual_drop_date,b.actual_drop_date)<=180 and b.campaigncode=''C000003716'' then b.actual_drop_date end) as no_camp_C000003716_180days
,count(case when UTIL.DATE_DIFF_UDF(a.actual_drop_date,b.actual_drop_date)>0 and UTIL.DATE_DIFF_UDF(a.actual_drop_date,b.actual_drop_date)<=180 and b.campaigncode=''C000004004'' then b.actual_drop_date end) as no_camp_C000004004_180days
from IDENTIFIER(:V_WORK_DIR_EFT_TYPE_FINAL_DATASET3) a inner join IDENTIFIER(:V_WORK_DIR_EFT_NBA_EFT2) b
on a.person_id=b.person_id
group by a.person_id, a.actual_drop_date;



V_STEP := ''STEP24'';

V_STEP_NAME :=  ''create a table EFT_TYPE_FINAL_DATASET4'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_WORK_DIR_EFT_TYPE_FINAL_DATASET4) as
select distinct 
a.person_id,
a.individual_id,
a.actual_drop_date,
a.tot_proc_days_3_mnths,
a.tot_proc_days_6_mnths,
a.tot_proc_days,
a.avg_proc_days_3_mnths,
a.avg_proc_days_6_mnths,
a.avg_proc_days,
a.max_proc_days_3_mnths,
a.max_proc_days_6_mnths,
a.max_proc_days,
a.min_proc_days_3_mnths,
a.min_proc_days_6_mnths,
a.min_proc_days,
a.tot_benefit_amt_3_mnths,
a.tot_benefit_amt_6_mnths,
a.tot_benefit_amt,
a.ecc_bl_payment_amount_3_mnths,
a.ecc_bl_payment_amount_6_mnths,
a.ecc_bl_payment_amount,
a.a_ecc_bl_payment_amount_3_mnths,
a.a_ecc_bl_payment_amount_6_mnths,
a.a_ecc_bl_payment_amount,
a.ecc_coins_amount_3_mnths,
a.ecc_coins_amount_6_mnths,
a.ecc_coins_amount,
a.a_ecc_coins_amount_3_mnths,
a.a_ecc_coins_amount_6_mnths,
a.a_ecc_coins_amount,
a.service_days_3_mnths,
a.service_days_6_mnths,
a.service_days,
a.a_service_days_3_mnths,
a.a_service_days_6_mnths,
a.a_service_days,
a.ecc_claim_total_amt_pd_3_mnths,
a.ecc_claim_total_amt_pd_6_mnths,
a.ecc_claim_total_amt_paid,
a.a_ecc_claim_total_amt_pd_3_mnths,
a.a_ecc_claim_total_amt_pd_6_mnths,
a.a_ecc_claim_total_amt_paid,
a.ecc_claim_total_app_3_mnths,
a.ecc_claim_total_app_6_mnths,
a.ecc_claim_total_app_amt,
a.a_ecc_claim_total_app_3_mnths,
a.a_ecc_claim_total_app_6_mnths,
a.a_ecc_claim_total_app_amt,
a.ecc_claim_total_charge_3_mnths,
a.ecc_claim_total_charge_6_mnths,
a.ecc_claim_total_charge,
a.a_ecc_claim_total_charge_3_mnths,
a.a_ecc_claim_total_charge_6_mnths,
a.a_ecc_claim_total_charge,
a.ecc_claim_total_deuct_3_mnths,
a.ecc_claim_total_deuct_6_mnths,
a.ecc_claim_total_deuct,
a.a_ecc_claim_total_deuct_3_mnths,
a.a_ecc_claim_total_deuct_6_mnths,
a.a_ecc_claim_total_deuct,
a.ecc_clm_tot_inelig_amt_3_mnths,
a.ecc_clm_tot_inelig_amt_6_mnths,
a.ecc_clm_tot_inelig_amt,
a.a_ecc_clm_tot_inelig_amt_3_mnths,
a.a_ecc_clm_tot_inelig_amt_6_mnths,
a.a_ecc_clm_tot_inelig_amt,
a.no_calls_3_mnths,
a.no_calls_6_mnths,
a.no_calls,
a.bill_pay_inq_call_3_mnths,
a.bill_pay_inq_call_6_mnths,
a.bill_pay_inq_call,
a.claim_inq_call_3_mnths,
a.claim_inq_call_6_mnths,
a.claim_inq_call,
a.telemarketing_inq_call_3_mnths,
a.telemarketing_inq_call_6_mnths,
a.telemarketing_inq_call,
a.opprtnty_inq_call_3_mnths,
a.opprtnty_inq_call_6_mnths,
a.opprtnty_inq_call,
a.plan_inq_call_3_mnths,
a.plan_inq_call_6_mnths,
a.plan_inq_call,
a.no_treatment_3_mnths,
a.no_treatment_6_mnths,
a.no_treatment,
a.no_pres_mcare_edu_3_mnths,
a.no_pres_mcare_edu_6_mnths,
a.no_pres_mcare_edu,
a.no_pres_priv_auth_3_mnths,
a.no_pres_priv_auth_6_mnths,
a.no_pres_priv_auth,
a.no_pres_priv_crgiver_3_mnths,
a.no_pres_priv_crgiver_6_mnths,
a.no_pres_priv_crgiver,
a.no_pres_web_reg_3_mnths,
a.no_pres_web_reg_6_mnths,
a.no_pres_web_reg,
a.at_your_best_pos_3_months,
a.at_your_best_pos_6_months,
a.at_your_best_positive,
a.at_your_best_neg_3_months,
a.at_your_best_neg_6_months,
a.at_your_best_negative,
a.eft_web_promo_neg_3_months,
a.eft_web_promo_neg_6_months,
a.eft_web_promo_negative,
a.eft_web_promo_pos_3_months,
a.eft_web_promo_pos_6_months,
a.eft_web_promo_positive,
a.heal_well_res_neg_3_months,
a.heal_well_res_neg_6_months,
a.heal_well_res_negative,
a.heal_well_res_pos_3_months,
a.heal_well_res_pos_6_months,
a.heal_well_res_positive,
a.med_ed_neg_3_months,
a.med_ed_neg_6_months,
a.med_ed_negative,
a.med_ed_pos_3_months,
a.med_ed_pos_6_months,
a.med_ed_positive,
a.med_ed_neut_3_months,
a.med_ed_neut_6_months,
a.med_ed_neutral,
a.application_id,
a.appl_receipt_date,
a.adjudication_date,
a.application_processing_time,
a.msup_num_lapses,
a.msup_num_plan_changes,
a.msup_active_prod_duration,
a.msup_rate_determination_code,
a.tenure,
a.zip_code,
a.network_hosp_dist,
a.no_claims_3_mnths,
a.no_claims_6_mnths,
a.no_claims,
a.part_b_deduct_3_mnths,
a.part_b_deduct_6_mnths,
a.part_b_deduct,
a.avg_part_b_deduct_3_mnths,
a.avg_part_b_deduct_6_mnths,
a.avg_part_b_deduct,
a.oop_amount_3_mnths,
a.oop_amount_6_mnths,
a.oop_amount,
a.avg_oop_amount_3_mnths,
a.avg_oop_amount_6_mnths,
a.avg_oop_amount,
a.adjust_benefit_amount_3_mnths,
a.adjust_benefit_amount_6_mnths,
a.adjust_benefit_amount,
a.avg_adjust_benefit_amt_3_mnths,
a.avg_adjust_benefit_amt_6_mnths,
a.avg_adjust_benefit_amount,
a.benefit_amount_3_mnths,
a.benefit_amount_6_mnths,
a.benefit_amount_12_mnths,
a.avg_benefit_amount_3_mnths,
a.avg_benefit_amount_6_mnths,
a.avg_benefit_amount,
a.covered_expense_3_mnths,
a.covered_expense_6_mnths,
a.tot_covered_expense,
a.avg_covered_expense_3_mnths,
a.avg_covered_expense_6_mnths,
a.avg_tot_covered_expense,
a.charge_amount_3_mnths,
a.charge_amount_6_mnths,
a.charge_amount,
a.avg_charge_amount_3_mnths,
a.avg_charge_amount_6_mnths,
a.avg_charge_amount,
a.deductible_amount_3_mnths,
a.deductible_amount_6_mnths,
a.deductible_amount,
a.avg_deductible_amount_3_mnths,
a.avg_deductible_amount_6_mnths,
a.avg_deductible_amount,
a.medicare_app_amount_3_mnths,
a.medicare_app_amount_6_mnths,
a.medicare_app_amount,
a.avg_medicare_app_amount_3_mnths,
a.avg_medicare_app_amount_6_mnths,
a.avg_medicare_app_amount,
a.medicare_pay_amount_3_mnths,
a.medicare_pay_amount_6_mnths,
a.medicare_pay_amount_12_mnths,
a.avg_medicare_pay_amount_3_mnths,
a.avg_medicare_pay_amount_6_mnths,
a.avg_medicare_pay_amount,
a.benefit_period_days_3_mnths,
a.benefit_period_days_6_mnths,
a.benefit_period_days_12_mnths,
a.disabled_ind,
a.smoker_ind,
a.adjusted_base_type_code,
a.begin_date,
a.end_date,
a.group_plan_id,
a.group_plan_type_id,
a.insured_plan_id,
a.insured_plan_profile_id,
a.loyalty_program_code,
a.rate_determination_code,
a.no_premium_3_mnths,
a.no_premium_6_mnths,
a.no_premium,
a.annual_payor_disc_amt_3_mnths,
a.annual_payor_disc_amt_6_mnths,
a.tot_annual_payor_disc_amt,
a.tot_eft_disc_amount_3_mnths,
a.tot_eft_disc_amount_6_mnths,
a.tot_eft_disc_amount,
a.tot_loyalty_disc_amount_3_mnths,
a.tot_loyalty_disc_amount_6_mnths,
a.tot_loyalty_disc_amount,
a.tot_premium_amt_3_mnths,
a.tot_premium_amt_6_mnths,
a.tot_premium_amt,
a.paid_net_memb_cont_amt_3_mnths,
a.paid_net_memb_cont_amt_6_mnths,
a.paid_net_memb_cont_amt,
a.tot_spouse_disc_amt_3_mnths,
a.tot_spouse_disc_amt_6_mnths,
a.tot_spouse_disc_amt,
a.tot_eb_subsidy_paid_amt_3_mnths,
a.tot_eb_subsidy_paid_amt_6_mnths,
a.tot_eb_subsidy_paid_amt,
a.paid_cert_qnty_3_mnths,
a.paid_cert_qnty_6_mnths,
a.paid_cert_qnty,
a.termed_cert_qnty_3_mnths,
a.termed_cert_qnty_6_mnths,
a.termed_cert_qnty,
a.individual_premium_amount,
a.employer_premium_amount,
a.plan_effective_date,
a.plan_termination_date,
a.specification_id,
a.ins_plan_switcher_ind,
a.language_preference_id,
a.specification_name,
a.product_type_var,
a.plan_code,
a.product_secondary_var_code,
a.product_type_code,
a.famp,
a.iola,
a.onla,
a.ret,
a.orac,
a.aalz,
a.aasm,
a.abce,
a.adbt,
a.agresp,
a.ahbp,
a.ahrt,
a.alng,
a.ares,
a.bc,
a.hhcomp,
a.homval,
a.homstat,
a.nah19,
a.nph19,
a.noc19,
a.poc19,
a.netw19,
a.pwheelch,
a.estinc19,
a.mr,
a.veri,
a.famp_bcgm,
a.famp_f,
a.famp_h,
a.famp_psw,
a.bank_card_multiple,
a.bank_card_single,
a.homeowner_fg,
a.children_present,
a.networth,
a.income,
a.mr_m,
a.mr_y,
a.married_with_children,
a.married_no_children,
a.male_with_no_children,
a.female_with_no_children,
a.gender_code,
a.birth_date,
a.pdp_fg_final,
a.rdc_1,
a.rdc_2,
a.rdc_3,
a.rdc_4,
a.new_member_fg,
a.no_app_acc_disc_3_mnths,
a.no_app_claims_3_mnths,
a.no_app_claimscorr_3_mnths,
a.no_app_enroll_3_mnths,
a.no_app_css_complain_3_mnths,
a.total_appeals_3_months,
a.no_app_acc_disc_6_mnths,
a.no_app_claims_6_mnths,
a.no_app_claimscorr_6_mnths,
a.no_app_enroll_6_mnths,
a.no_app_css_complain_6_mnths,
a.total_appeals_6_months,
a.no_app_acc_disc,
a.no_app_claims,
a.no_app_claimscorr,
a.no_app_enroll,
a.no_app_css_complain,
a.total_appeals,
a.age,
a.disabled_ind_var,
a.gender_f,
a.ins_code,
a.ins_code_1,
a.ins_code_23,
a.termination_id,
a.termination_id_11_var,
a.underwrite_code,
a.underwrite_code_bny,
a.underwrite_code_w,
a.ins_plan_switcher_ind_var,
a.product_type_code_hr,
a.product_type_code_m,
a.smoker_ind_var,
a.deliverable_mail_ind,
a.deliverable_mail_ind_var,
a.empl_spons_cov_ind,
a.empl_spons_cov_ind_var,
a.employer_account_ind,
a.employer_account_ind_var,
a.esrd_denial_ind,
a.esrd_denial_ind_var,
a.global_suppress_ind,
a.global_suppress_ind_var,
a.medicare_dis_ind,
a.medicare_dis_ind_var,
a.msup_benefit_mod_ind,
a.msup_benefit_mod_ind_var,
a.adjudication_status_code,
a.adjudication_status_code_a,
a.adjudication_status_code_dpw,
a.vas_fg,
a.mcp_fg,
a.ayb_fg,
a.vas_term_one_year_fg,
a.vas_active_fg,
a.ayb_gym_fg,
a.ayb_event_fg,
a.ayb_portal_fg,
a.ayb_telephonic_fg,
a.no_nba_camp_sent_before,
a.no_nba_sent_1mnths,
a.no_nba_sent_3mnths,
a.no_nba_sent_6mnths,
a.no_nba_sent_12mnths,
a.no_late_6_mnths,
a.no_late_12_mnths,
a.no_1timeEFT_6mths,
a.no_1timeEFT_12mths,
a.previous_recc_EFT_360days,
b.no_camp_C000002230_180days,
b.no_camp_C000002487_180days,
b.no_camp_C000002600_180days,
b.no_camp_C000003461_180days,
b.no_camp_C000003594_180days,
b.no_camp_C000003716_180days,
b.no_camp_C000004004_180days
from IDENTIFIER(:V_WORK_DIR_EFT_TYPE_FINAL_DATASET3) a left join IDENTIFIER(:V_WORK_DIR_EFT_CAMP_COUNTS) b
on a.person_id=b.person_id 
and a.actual_drop_date=b.actual_drop_date;



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_WORK_DIR_EFT_TYPE_FINAL_DATASET4)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



-- /*IMP----REmember to make recc_EFT_active variable next time here*/

V_STEP := ''STEP25'';

V_STEP_NAME :=  ''create a table EFT_TABLE_RECC_EFT_ACTIVE'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_WORK_DIR_EFT_TABLE_RECC_EFT_ACTIVE) as
select distinct a.person_id, a.actual_drop_date,
case when (b.begin_date is not null and b.begin_date<a.actual_drop_date 
and b.EFT_FREQUENCY_TYPE_ID=1 and ( (UTIL.DATE_DIFF_UDF(b.end_date,a.actual_drop_date)>0) or b.end_date is null ) ) THEN 1 else 0  end  as recc_EFT_active
from IDENTIFIER(:V_WORK_DIR_EFT_TYPE_FINAL_DATASET4) a inner join IDENTIFIER(:V_DB_REFINED_POLICY_PERSON_PAYMENT_METHOD)  b 
on a.person_id=b.person_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_WORK_DIR_EFT_TABLE_RECC_EFT_ACTIVE)) ;


V_STEP := ''STEP26'';

V_STEP_NAME :=  ''create a table EFT_TABLE_RECC_EFT_ACTIVE1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_WORK_DIR_EFT_TABLE_RECC_EFT_ACTIVE1) as
select distinct person_id, actual_drop_date,recc_EFT_active from IDENTIFIER(:V_WORK_DIR_EFT_TABLE_RECC_EFT_ACTIVE)
where recc_EFT_active =1;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_WORK_DIR_EFT_TABLE_RECC_EFT_ACTIVE1)) ;



V_STEP := ''STEP27'';

V_STEP_NAME :=  ''create a table EFT_TYPE_FINAL_DATASET5'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());




create or replace table IDENTIFIER(:V_WORK_DIR_EFT_TYPE_FINAL_DATASET5) as
select distinct 
a.person_id,
a.individual_id,
a.actual_drop_date,
a.tot_proc_days_3_mnths,
a.tot_proc_days_6_mnths,
a.tot_proc_days,
a.avg_proc_days_3_mnths,
a.avg_proc_days_6_mnths,
a.avg_proc_days,
a.max_proc_days_3_mnths,
a.max_proc_days_6_mnths,
a.max_proc_days,
a.min_proc_days_3_mnths,
a.min_proc_days_6_mnths,
a.min_proc_days,
a.tot_benefit_amt_3_mnths,
a.tot_benefit_amt_6_mnths,
a.tot_benefit_amt,
a.ecc_bl_payment_amount_3_mnths,
a.ecc_bl_payment_amount_6_mnths,
a.ecc_bl_payment_amount,
a.a_ecc_bl_payment_amount_3_mnths,
a.a_ecc_bl_payment_amount_6_mnths,
a.a_ecc_bl_payment_amount,
a.ecc_coins_amount_3_mnths,
a.ecc_coins_amount_6_mnths,
a.ecc_coins_amount,
a.a_ecc_coins_amount_3_mnths,
a.a_ecc_coins_amount_6_mnths,
a.a_ecc_coins_amount,
a.service_days_3_mnths,
a.service_days_6_mnths,
a.service_days,
a.a_service_days_3_mnths,
a.a_service_days_6_mnths,
a.a_service_days,
a.ecc_claim_total_amt_pd_3_mnths,
a.ecc_claim_total_amt_pd_6_mnths,
a.ecc_claim_total_amt_paid,
a.a_ecc_claim_total_amt_pd_3_mnths,
a.a_ecc_claim_total_amt_pd_6_mnths,
a.a_ecc_claim_total_amt_paid,
a.ecc_claim_total_app_3_mnths,
a.ecc_claim_total_app_6_mnths,
a.ecc_claim_total_app_amt,
a.a_ecc_claim_total_app_3_mnths,
a.a_ecc_claim_total_app_6_mnths,
a.a_ecc_claim_total_app_amt,
a.ecc_claim_total_charge_3_mnths,
a.ecc_claim_total_charge_6_mnths,
a.ecc_claim_total_charge,
a.a_ecc_claim_total_charge_3_mnths,
a.a_ecc_claim_total_charge_6_mnths,
a.a_ecc_claim_total_charge,
a.ecc_claim_total_deuct_3_mnths,
a.ecc_claim_total_deuct_6_mnths,
a.ecc_claim_total_deuct,
a.a_ecc_claim_total_deuct_3_mnths,
a.a_ecc_claim_total_deuct_6_mnths,
a.a_ecc_claim_total_deuct,
a.ecc_clm_tot_inelig_amt_3_mnths,
a.ecc_clm_tot_inelig_amt_6_mnths,
a.ecc_clm_tot_inelig_amt,
a.a_ecc_clm_tot_inelig_amt_3_mnths,
a.a_ecc_clm_tot_inelig_amt_6_mnths,
a.a_ecc_clm_tot_inelig_amt,
a.no_calls_3_mnths,
a.no_calls_6_mnths,
a.no_calls,
a.bill_pay_inq_call_3_mnths,
a.bill_pay_inq_call_6_mnths,
a.bill_pay_inq_call,
a.claim_inq_call_3_mnths,
a.claim_inq_call_6_mnths,
a.claim_inq_call,
a.telemarketing_inq_call_3_mnths,
a.telemarketing_inq_call_6_mnths,
a.telemarketing_inq_call,
a.opprtnty_inq_call_3_mnths,
a.opprtnty_inq_call_6_mnths,
a.opprtnty_inq_call,
a.plan_inq_call_3_mnths,
a.plan_inq_call_6_mnths,
a.plan_inq_call,
a.no_treatment_3_mnths,
a.no_treatment_6_mnths,
a.no_treatment,
a.no_pres_mcare_edu_3_mnths,
a.no_pres_mcare_edu_6_mnths,
a.no_pres_mcare_edu,
a.no_pres_priv_auth_3_mnths,
a.no_pres_priv_auth_6_mnths,
a.no_pres_priv_auth,
a.no_pres_priv_crgiver_3_mnths,
a.no_pres_priv_crgiver_6_mnths,
a.no_pres_priv_crgiver,
a.no_pres_web_reg_3_mnths,
a.no_pres_web_reg_6_mnths,
a.no_pres_web_reg,
a.at_your_best_pos_3_months,
a.at_your_best_pos_6_months,
a.at_your_best_positive,
a.at_your_best_neg_3_months,
a.at_your_best_neg_6_months,
a.at_your_best_negative,
a.eft_web_promo_neg_3_months,
a.eft_web_promo_neg_6_months,
a.eft_web_promo_negative,
a.eft_web_promo_pos_3_months,
a.eft_web_promo_pos_6_months,
a.eft_web_promo_positive,
a.heal_well_res_neg_3_months,
a.heal_well_res_neg_6_months,
a.heal_well_res_negative,
a.heal_well_res_pos_3_months,
a.heal_well_res_pos_6_months,
a.heal_well_res_positive,
a.med_ed_neg_3_months,
a.med_ed_neg_6_months,
a.med_ed_negative,
a.med_ed_pos_3_months,
a.med_ed_pos_6_months,
a.med_ed_positive,
a.med_ed_neut_3_months,
a.med_ed_neut_6_months,
a.med_ed_neutral,
a.application_id,
a.appl_receipt_date,
a.adjudication_date,
a.application_processing_time,
a.msup_num_lapses,
a.msup_num_plan_changes,
a.msup_active_prod_duration,
a.msup_rate_determination_code,
a.tenure,
a.zip_code,
a.network_hosp_dist,
a.no_claims_3_mnths,
a.no_claims_6_mnths,
a.no_claims,
a.part_b_deduct_3_mnths,
a.part_b_deduct_6_mnths,
a.part_b_deduct,
a.avg_part_b_deduct_3_mnths,
a.avg_part_b_deduct_6_mnths,
a.avg_part_b_deduct,
a.oop_amount_3_mnths,
a.oop_amount_6_mnths,
a.oop_amount,
a.avg_oop_amount_3_mnths,
a.avg_oop_amount_6_mnths,
a.avg_oop_amount,
a.adjust_benefit_amount_3_mnths,
a.adjust_benefit_amount_6_mnths,
a.adjust_benefit_amount,
a.avg_adjust_benefit_amt_3_mnths,
a.avg_adjust_benefit_amt_6_mnths,
a.avg_adjust_benefit_amount,
a.benefit_amount_3_mnths,
a.benefit_amount_6_mnths,
a.benefit_amount_12_mnths,
a.avg_benefit_amount_3_mnths,
a.avg_benefit_amount_6_mnths,
a.avg_benefit_amount,
a.covered_expense_3_mnths,
a.covered_expense_6_mnths,
a.tot_covered_expense,
a.avg_covered_expense_3_mnths,
a.avg_covered_expense_6_mnths,
a.avg_tot_covered_expense,
a.charge_amount_3_mnths,
a.charge_amount_6_mnths,
a.charge_amount,
a.avg_charge_amount_3_mnths,
a.avg_charge_amount_6_mnths,
a.avg_charge_amount,
a.deductible_amount_3_mnths,
a.deductible_amount_6_mnths,
a.deductible_amount,
a.avg_deductible_amount_3_mnths,
a.avg_deductible_amount_6_mnths,
a.avg_deductible_amount,
a.medicare_app_amount_3_mnths,
a.medicare_app_amount_6_mnths,
a.medicare_app_amount,
a.avg_medicare_app_amount_3_mnths,
a.avg_medicare_app_amount_6_mnths,
a.avg_medicare_app_amount,
a.medicare_pay_amount_3_mnths,
a.medicare_pay_amount_6_mnths,
a.medicare_pay_amount_12_mnths,
a.avg_medicare_pay_amount_3_mnths,
a.avg_medicare_pay_amount_6_mnths,
a.avg_medicare_pay_amount,
a.benefit_period_days_3_mnths,
a.benefit_period_days_6_mnths,
a.benefit_period_days_12_mnths,
a.disabled_ind,
a.smoker_ind,
a.adjusted_base_type_code,
a.begin_date,
a.end_date,
a.group_plan_id,
a.group_plan_type_id,
a.insured_plan_id,
a.insured_plan_profile_id,
a.loyalty_program_code,
a.rate_determination_code,
a.no_premium_3_mnths,
a.no_premium_6_mnths,
a.no_premium,
a.annual_payor_disc_amt_3_mnths,
a.annual_payor_disc_amt_6_mnths,
a.tot_annual_payor_disc_amt,
a.tot_eft_disc_amount_3_mnths,
a.tot_eft_disc_amount_6_mnths,
a.tot_eft_disc_amount,
a.tot_loyalty_disc_amount_3_mnths,
a.tot_loyalty_disc_amount_6_mnths,
a.tot_loyalty_disc_amount,
a.tot_premium_amt_3_mnths,
a.tot_premium_amt_6_mnths,
a.tot_premium_amt,
a.paid_net_memb_cont_amt_3_mnths,
a.paid_net_memb_cont_amt_6_mnths,
a.paid_net_memb_cont_amt,
a.tot_spouse_disc_amt_3_mnths,
a.tot_spouse_disc_amt_6_mnths,
a.tot_spouse_disc_amt,
a.tot_eb_subsidy_paid_amt_3_mnths,
a.tot_eb_subsidy_paid_amt_6_mnths,
a.tot_eb_subsidy_paid_amt,
a.paid_cert_qnty_3_mnths,
a.paid_cert_qnty_6_mnths,
a.paid_cert_qnty,
a.termed_cert_qnty_3_mnths,
a.termed_cert_qnty_6_mnths,
a.termed_cert_qnty,
a.individual_premium_amount,
a.employer_premium_amount,
a.plan_effective_date,
a.plan_termination_date,
a.specification_id,
a.ins_plan_switcher_ind,
a.language_preference_id,
a.specification_name,
a.product_type_var,
a.plan_code,
a.product_secondary_var_code,
a.product_type_code,
a.famp,
a.iola,
a.onla,
a.ret,
a.orac,
a.aalz,
a.aasm,
a.abce,
a.adbt,
a.agresp,
a.ahbp,
a.ahrt,
a.alng,
a.ares,
a.bc,
a.hhcomp,
a.homval,
a.homstat,
a.nah19,
a.nph19,
a.noc19,
a.poc19,
a.netw19,
a.pwheelch,
a.estinc19,
a.mr,
a.veri,
a.famp_bcgm,
a.famp_f,
a.famp_h,
a.famp_psw,
a.bank_card_multiple,
a.bank_card_single,
a.homeowner_fg,
a.children_present,
a.networth,
a.income,
a.mr_m,
a.mr_y,
a.married_with_children,
a.married_no_children,
a.male_with_no_children,
a.female_with_no_children,
a.gender_code,
a.birth_date,
a.pdp_fg_final,
a.rdc_1,
a.rdc_2,
a.rdc_3,
a.rdc_4,
a.new_member_fg,
a.no_app_acc_disc_3_mnths,
a.no_app_claims_3_mnths,
a.no_app_claimscorr_3_mnths,
a.no_app_enroll_3_mnths,
a.no_app_css_complain_3_mnths,
a.total_appeals_3_months,
a.no_app_acc_disc_6_mnths,
a.no_app_claims_6_mnths,
a.no_app_claimscorr_6_mnths,
a.no_app_enroll_6_mnths,
a.no_app_css_complain_6_mnths,
a.total_appeals_6_months,
a.no_app_acc_disc,
a.no_app_claims,
a.no_app_claimscorr,
a.no_app_enroll,
a.no_app_css_complain,
a.total_appeals,
a.age,
a.disabled_ind_var,
a.gender_f,
a.ins_code,
a.ins_code_1,
a.ins_code_23,
a.termination_id,
a.termination_id_11_var,
a.underwrite_code,
a.underwrite_code_bny,
a.underwrite_code_w,
a.ins_plan_switcher_ind_var,
a.product_type_code_hr,
a.product_type_code_m,
a.smoker_ind_var,
a.deliverable_mail_ind,
a.deliverable_mail_ind_var,
a.empl_spons_cov_ind,
a.empl_spons_cov_ind_var,
a.employer_account_ind,
a.employer_account_ind_var,
a.esrd_denial_ind,
a.esrd_denial_ind_var,
a.global_suppress_ind,
a.global_suppress_ind_var,
a.medicare_dis_ind,
a.medicare_dis_ind_var,
a.msup_benefit_mod_ind,
a.msup_benefit_mod_ind_var,
a.adjudication_status_code,
a.adjudication_status_code_a,
a.adjudication_status_code_dpw,
a.vas_fg,
a.mcp_fg,
a.ayb_fg,
a.vas_term_one_year_fg,
a.vas_active_fg,
a.ayb_gym_fg,
a.ayb_event_fg,
a.ayb_portal_fg,
a.ayb_telephonic_fg,
a.no_nba_camp_sent_before,
a.no_nba_sent_1mnths,
a.no_nba_sent_3mnths,
a.no_nba_sent_6mnths,
a.no_nba_sent_12mnths,
a.no_late_6_mnths,
a.no_late_12_mnths,
a.no_1timeEFT_6mths,
a.no_1timeEFT_12mths,
a.previous_recc_EFT_360days,
a.no_camp_C000002230_180days,
a.no_camp_C000002487_180days,
a.no_camp_C000002600_180days,
a.no_camp_C000003461_180days,
a.no_camp_C000003594_180days,
a.no_camp_C000003716_180days,
a.no_camp_C000004004_180days,
b.recc_EFT_active
from IDENTIFIER(:V_WORK_DIR_EFT_TYPE_FINAL_DATASET4) a left join IDENTIFIER(:V_WORK_DIR_EFT_TABLE_RECC_EFT_ACTIVE1) b
on a.person_id=b.person_id 
and a.actual_drop_date=b.actual_drop_date;




V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_WORK_DIR_EFT_TYPE_FINAL_DATASET5)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



-- /*WEB variables*/

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP28'';

V_STEP_NAME :=  ''create a table EFT_WEB_REG_CAMPS'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_WORK_DIR_EFT_WEB_REG_CAMPS) as
select distinct mc.person_id,ce.actual_drop_date,mc.mkt_contact_id,mc.campaign_extract_id,ced.targeted_message,ce.campaignid,ce.cellname,
ce.cellcode,ce.extract_date,smc.name,smc.campaigncode,smc.initiative,smc.business_Segment
FROM  IDENTIFIER(:V_DB_REFINED_CAMPAIGN_MARKETING_CONTACT)  mc
Inner join IDENTIFIER(:V_DB_REFINED_CAMPAIGN_CAMPAIGN_EXTRACT)  ce
on mc.CAMPAIGN_EXTRACT_ID=ce.CAMPAIGN_EXTRACT_ID
Inner join IDENTIFIER(:V_DB_REFINED_CAMPAIGN_SM_CAMPAIGN)  smc
on ce.CAMPAIGNID=smc.CAMPAIGNID 
left join IDENTIFIER(:V_DB_REFINED_CAMPAIGN_CAMPAIGN_EXTRACT_DETAIL)  ced 
on ce.campaign_extract_id= ced.campaign_extract_id
where
(smc.CAMPAIGNCODE IN 
(''C000003460'',
''C000003601''
)
and ce.ACTUAL_DROP_DATE >= CAST(''2017-01-01'' AS DATE) )
and nvl(ced.targeted_message,'''')='''';




V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_WORK_DIR_EFT_WEB_REG_CAMPS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



V_STEP := ''STEP29'';

V_STEP_NAME :=  ''create a table EFT_WEB_REG_CAMPS1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_WORK_DIR_EFT_WEB_REG_CAMPS1) as
select person_id, campaigncode, actual_drop_date from IDENTIFIER(:V_WORK_DIR_EFT_WEB_REG_CAMPS) order by person_id, campaigncode, actual_drop_date;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_WORK_DIR_EFT_WEB_REG_CAMPS1)) ;


V_STEP := ''STEP30'';

V_STEP_NAME :=  ''create a table EFT_CAMPS_COUNTS'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());



create or replace table IDENTIFIER(:V_WORK_DIR_EFT_CAMPS_COUNTS) as
select a.person_id, a.actual_drop_date
,count(case when UTIL.DATE_DIFF_UDF(a.actual_drop_date,b.actual_drop_date)>0 and UTIL.DATE_DIFF_UDF(a.actual_drop_date,b.actual_drop_date)<=180 and b.campaigncode= ''C000003460'' then b.actual_drop_date end) as no_camp_C000003460_180days
,count(case when UTIL.DATE_DIFF_UDF(a.actual_drop_date,b.actual_drop_date)>0 and UTIL.DATE_DIFF_UDF(a.actual_drop_date,b.actual_drop_date)<=180 and b.campaigncode= ''C000003601'' then b.actual_drop_date end) as no_camp_C000003601_180days
,count(case when UTIL.DATE_DIFF_UDF(a.actual_drop_date,b.actual_drop_date)>0 and UTIL.DATE_DIFF_UDF(a.actual_drop_date,b.actual_drop_date)<=360 and b.campaigncode= ''C000003460'' then b.actual_drop_date end) as no_camp_C000003460_360days
,count(case when UTIL.DATE_DIFF_UDF(a.actual_drop_date,b.actual_drop_date)>0 and UTIL.DATE_DIFF_UDF(a.actual_drop_date,b.actual_drop_date)<=360 and b.campaigncode= ''C000003601'' then b.actual_drop_date end) as no_camp_C000003601_360days
from IDENTIFIER(:V_WORK_DIR_EFT_TYPE_FINAL_DATASET5) a inner join IDENTIFIER(:V_WORK_DIR_EFT_WEB_REG_CAMPS1) b
on a.person_id=b.person_id
group by a.person_id,a.actual_drop_date;




V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_WORK_DIR_EFT_CAMPS_COUNTS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);






V_STEP := ''STEP31'';

V_STEP_NAME :=  ''create a table EFT_TYPE_FINAL_DATASET6'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());



create or replace table IDENTIFIER(:V_WORK_DIR_EFT_TYPE_FINAL_DATASET6) as
select distinct 
a.person_id,
a.individual_id,
a.actual_drop_date,
a.tot_proc_days_3_mnths,
a.tot_proc_days_6_mnths,
a.tot_proc_days,
a.avg_proc_days_3_mnths,
a.avg_proc_days_6_mnths,
a.avg_proc_days,
a.max_proc_days_3_mnths,
a.max_proc_days_6_mnths,
a.max_proc_days,
a.min_proc_days_3_mnths,
a.min_proc_days_6_mnths,
a.min_proc_days,
a.tot_benefit_amt_3_mnths,
a.tot_benefit_amt_6_mnths,
a.tot_benefit_amt,
a.ecc_bl_payment_amount_3_mnths,
a.ecc_bl_payment_amount_6_mnths,
a.ecc_bl_payment_amount,
a.a_ecc_bl_payment_amount_3_mnths,
a.a_ecc_bl_payment_amount_6_mnths,
a.a_ecc_bl_payment_amount,
a.ecc_coins_amount_3_mnths,
a.ecc_coins_amount_6_mnths,
a.ecc_coins_amount,
a.a_ecc_coins_amount_3_mnths,
a.a_ecc_coins_amount_6_mnths,
a.a_ecc_coins_amount,
a.service_days_3_mnths,
a.service_days_6_mnths,
a.service_days,
a.a_service_days_3_mnths,
a.a_service_days_6_mnths,
a.a_service_days,
a.ecc_claim_total_amt_pd_3_mnths,
a.ecc_claim_total_amt_pd_6_mnths,
a.ecc_claim_total_amt_paid,
a.a_ecc_claim_total_amt_pd_3_mnths,
a.a_ecc_claim_total_amt_pd_6_mnths,
a.a_ecc_claim_total_amt_paid,
a.ecc_claim_total_app_3_mnths,
a.ecc_claim_total_app_6_mnths,
a.ecc_claim_total_app_amt,
a.a_ecc_claim_total_app_3_mnths,
a.a_ecc_claim_total_app_6_mnths,
a.a_ecc_claim_total_app_amt,
a.ecc_claim_total_charge_3_mnths,
a.ecc_claim_total_charge_6_mnths,
a.ecc_claim_total_charge,
a.a_ecc_claim_total_charge_3_mnths,
a.a_ecc_claim_total_charge_6_mnths,
a.a_ecc_claim_total_charge,
a.ecc_claim_total_deuct_3_mnths,
a.ecc_claim_total_deuct_6_mnths,
a.ecc_claim_total_deuct,
a.a_ecc_claim_total_deuct_3_mnths,
a.a_ecc_claim_total_deuct_6_mnths,
a.a_ecc_claim_total_deuct,
a.ecc_clm_tot_inelig_amt_3_mnths,
a.ecc_clm_tot_inelig_amt_6_mnths,
a.ecc_clm_tot_inelig_amt,
a.a_ecc_clm_tot_inelig_amt_3_mnths,
a.a_ecc_clm_tot_inelig_amt_6_mnths,
a.a_ecc_clm_tot_inelig_amt,
a.no_calls_3_mnths,
a.no_calls_6_mnths,
a.no_calls,
a.bill_pay_inq_call_3_mnths,
a.bill_pay_inq_call_6_mnths,
a.bill_pay_inq_call,
a.claim_inq_call_3_mnths,
a.claim_inq_call_6_mnths,
a.claim_inq_call,
a.telemarketing_inq_call_3_mnths,
a.telemarketing_inq_call_6_mnths,
a.telemarketing_inq_call,
a.opprtnty_inq_call_3_mnths,
a.opprtnty_inq_call_6_mnths,
a.opprtnty_inq_call,
a.plan_inq_call_3_mnths,
a.plan_inq_call_6_mnths,
a.plan_inq_call,
a.no_treatment_3_mnths,
a.no_treatment_6_mnths,
a.no_treatment,
a.no_pres_mcare_edu_3_mnths,
a.no_pres_mcare_edu_6_mnths,
a.no_pres_mcare_edu,
a.no_pres_priv_auth_3_mnths,
a.no_pres_priv_auth_6_mnths,
a.no_pres_priv_auth,
a.no_pres_priv_crgiver_3_mnths,
a.no_pres_priv_crgiver_6_mnths,
a.no_pres_priv_crgiver,
a.no_pres_web_reg_3_mnths,
a.no_pres_web_reg_6_mnths,
a.no_pres_web_reg,
a.at_your_best_pos_3_months,
a.at_your_best_pos_6_months,
a.at_your_best_positive,
a.at_your_best_neg_3_months,
a.at_your_best_neg_6_months,
a.at_your_best_negative,
a.eft_web_promo_neg_3_months,
a.eft_web_promo_neg_6_months,
a.eft_web_promo_negative,
a.eft_web_promo_pos_3_months,
a.eft_web_promo_pos_6_months,
a.eft_web_promo_positive,
a.heal_well_res_neg_3_months,
a.heal_well_res_neg_6_months,
a.heal_well_res_negative,
a.heal_well_res_pos_3_months,
a.heal_well_res_pos_6_months,
a.heal_well_res_positive,
a.med_ed_neg_3_months,
a.med_ed_neg_6_months,
a.med_ed_negative,
a.med_ed_pos_3_months,
a.med_ed_pos_6_months,
a.med_ed_positive,
a.med_ed_neut_3_months,
a.med_ed_neut_6_months,
a.med_ed_neutral,
a.application_id,
a.appl_receipt_date,
a.adjudication_date,
a.application_processing_time,
a.msup_num_lapses,
a.msup_num_plan_changes,
a.msup_active_prod_duration,
a.msup_rate_determination_code,
a.tenure,
a.zip_code,
a.network_hosp_dist,
a.no_claims_3_mnths,
a.no_claims_6_mnths,
a.no_claims,
a.part_b_deduct_3_mnths,
a.part_b_deduct_6_mnths,
a.part_b_deduct,
a.avg_part_b_deduct_3_mnths,
a.avg_part_b_deduct_6_mnths,
a.avg_part_b_deduct,
a.oop_amount_3_mnths,
a.oop_amount_6_mnths,
a.oop_amount,
a.avg_oop_amount_3_mnths,
a.avg_oop_amount_6_mnths,
a.avg_oop_amount,
a.adjust_benefit_amount_3_mnths,
a.adjust_benefit_amount_6_mnths,
a.adjust_benefit_amount,
a.avg_adjust_benefit_amt_3_mnths,
a.avg_adjust_benefit_amt_6_mnths,
a.avg_adjust_benefit_amount,
a.benefit_amount_3_mnths,
a.benefit_amount_6_mnths,
a.benefit_amount_12_mnths,
a.avg_benefit_amount_3_mnths,
a.avg_benefit_amount_6_mnths,
a.avg_benefit_amount,
a.covered_expense_3_mnths,
a.covered_expense_6_mnths,
a.tot_covered_expense,
a.avg_covered_expense_3_mnths,
a.avg_covered_expense_6_mnths,
a.avg_tot_covered_expense,
a.charge_amount_3_mnths,
a.charge_amount_6_mnths,
a.charge_amount,
a.avg_charge_amount_3_mnths,
a.avg_charge_amount_6_mnths,
a.avg_charge_amount,
a.deductible_amount_3_mnths,
a.deductible_amount_6_mnths,
a.deductible_amount,
a.avg_deductible_amount_3_mnths,
a.avg_deductible_amount_6_mnths,
a.avg_deductible_amount,
a.medicare_app_amount_3_mnths,
a.medicare_app_amount_6_mnths,
a.medicare_app_amount,
a.avg_medicare_app_amount_3_mnths,
a.avg_medicare_app_amount_6_mnths,
a.avg_medicare_app_amount,
a.medicare_pay_amount_3_mnths,
a.medicare_pay_amount_6_mnths,
a.medicare_pay_amount_12_mnths,
a.avg_medicare_pay_amount_3_mnths,
a.avg_medicare_pay_amount_6_mnths,
a.avg_medicare_pay_amount,
a.benefit_period_days_3_mnths,
a.benefit_period_days_6_mnths,
a.benefit_period_days_12_mnths,
a.disabled_ind,
a.smoker_ind,
a.adjusted_base_type_code,
a.begin_date,
a.end_date,
a.group_plan_id,
a.group_plan_type_id,
a.insured_plan_id,
a.insured_plan_profile_id,
a.loyalty_program_code,
a.rate_determination_code,
a.no_premium_3_mnths,
a.no_premium_6_mnths,
a.no_premium,
a.annual_payor_disc_amt_3_mnths,
a.annual_payor_disc_amt_6_mnths,
a.tot_annual_payor_disc_amt,
a.tot_eft_disc_amount_3_mnths,
a.tot_eft_disc_amount_6_mnths,
a.tot_eft_disc_amount,
a.tot_loyalty_disc_amount_3_mnths,
a.tot_loyalty_disc_amount_6_mnths,
a.tot_loyalty_disc_amount,
a.tot_premium_amt_3_mnths,
a.tot_premium_amt_6_mnths,
a.tot_premium_amt,
a.paid_net_memb_cont_amt_3_mnths,
a.paid_net_memb_cont_amt_6_mnths,
a.paid_net_memb_cont_amt,
a.tot_spouse_disc_amt_3_mnths,
a.tot_spouse_disc_amt_6_mnths,
a.tot_spouse_disc_amt,
a.tot_eb_subsidy_paid_amt_3_mnths,
a.tot_eb_subsidy_paid_amt_6_mnths,
a.tot_eb_subsidy_paid_amt,
a.paid_cert_qnty_3_mnths,
a.paid_cert_qnty_6_mnths,
a.paid_cert_qnty,
a.termed_cert_qnty_3_mnths,
a.termed_cert_qnty_6_mnths,
a.termed_cert_qnty,
a.individual_premium_amount,
a.employer_premium_amount,
a.plan_effective_date,
a.plan_termination_date,
a.specification_id,
a.ins_plan_switcher_ind,
a.language_preference_id,
a.specification_name,
a.product_type_var,
a.plan_code,
a.product_secondary_var_code,
a.product_type_code,
a.famp,
a.iola,
a.onla,
a.ret,
a.orac,
a.aalz,
a.aasm,
a.abce,
a.adbt,
a.agresp,
a.ahbp,
a.ahrt,
a.alng,
a.ares,
a.bc,
a.hhcomp,
a.homval,
a.homstat,
a.nah19,
a.nph19,
a.noc19,
a.poc19,
a.netw19,
a.pwheelch,
a.estinc19,
a.mr,
a.veri,
a.famp_bcgm,
a.famp_f,
a.famp_h,
a.famp_psw,
a.bank_card_multiple,
a.bank_card_single,
a.homeowner_fg,
a.children_present,
a.networth,
a.income,
a.mr_m,
a.mr_y,
a.married_with_children,
a.married_no_children,
a.male_with_no_children,
a.female_with_no_children,
a.gender_code,
a.birth_date,
a.pdp_fg_final,
a.rdc_1,
a.rdc_2,
a.rdc_3,
a.rdc_4,
a.new_member_fg,
a.no_app_acc_disc_3_mnths,
a.no_app_claims_3_mnths,
a.no_app_claimscorr_3_mnths,
a.no_app_enroll_3_mnths,
a.no_app_css_complain_3_mnths,
a.total_appeals_3_months,
a.no_app_acc_disc_6_mnths,
a.no_app_claims_6_mnths,
a.no_app_claimscorr_6_mnths,
a.no_app_enroll_6_mnths,
a.no_app_css_complain_6_mnths,
a.total_appeals_6_months,
a.no_app_acc_disc,
a.no_app_claims,
a.no_app_claimscorr,
a.no_app_enroll,
a.no_app_css_complain,
a.total_appeals,
a.age,
a.disabled_ind_var,
a.gender_f,
a.ins_code,
a.ins_code_1,
a.ins_code_23,
a.termination_id,
a.termination_id_11_var,
a.underwrite_code,
a.underwrite_code_bny,
a.underwrite_code_w,
a.ins_plan_switcher_ind_var,
a.product_type_code_hr,
a.product_type_code_m,
a.smoker_ind_var,
a.deliverable_mail_ind,
a.deliverable_mail_ind_var,
a.empl_spons_cov_ind,
a.empl_spons_cov_ind_var,
a.employer_account_ind,
a.employer_account_ind_var,
a.esrd_denial_ind,
a.esrd_denial_ind_var,
a.global_suppress_ind,
a.global_suppress_ind_var,
a.medicare_dis_ind,
a.medicare_dis_ind_var,
a.msup_benefit_mod_ind,
a.msup_benefit_mod_ind_var,
a.adjudication_status_code,
a.adjudication_status_code_a,
a.adjudication_status_code_dpw,
a.vas_fg,
a.mcp_fg,
a.ayb_fg,
a.vas_term_one_year_fg,
a.vas_active_fg,
a.ayb_gym_fg,
a.ayb_event_fg,
a.ayb_portal_fg,
a.ayb_telephonic_fg,
a.no_nba_camp_sent_before,
a.no_nba_sent_1mnths,
a.no_nba_sent_3mnths,
a.no_nba_sent_6mnths,
a.no_nba_sent_12mnths,
a.no_late_6_mnths,
a.no_late_12_mnths,
a.no_1timeEFT_6mths,
a.no_1timeEFT_12mths,
a.previous_recc_EFT_360days,
a.no_camp_C000002230_180days,
a.no_camp_C000002487_180days,
a.no_camp_C000002600_180days,
a.no_camp_C000003461_180days,
a.no_camp_C000003594_180days,
a.no_camp_C000003716_180days,
a.no_camp_C000004004_180days,
a.recc_EFT_active,
b.no_camp_C000003460_180days,
b.no_camp_C000003601_180days,
b.no_camp_C000003460_360days,
b.no_camp_C000003601_360days
from IDENTIFIER(:V_WORK_DIR_EFT_TYPE_FINAL_DATASET5) a left join IDENTIFIER(:V_WORK_DIR_EFT_CAMPS_COUNTS) b
on a.person_id=b.person_id 
and a.actual_drop_date=b.actual_drop_date;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_WORK_DIR_EFT_TYPE_FINAL_DATASET6)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP32'';

V_STEP_NAME :=  ''create a table EFT_TYPE_FINAL_DATASET7'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());



create or replace table IDENTIFIER(:V_WORK_DIR_EFT_TYPE_FINAL_DATASET7) as
select 
PERSON_ID
,individual_id
,MSUP_NUM_LAPSES
,tenure
,age
,PLAN_CODE
,Bank_Card_Single
,INDIVIDUAL_PREMIUM_AMOUNT
,OPPRTNTY_INQ_call
,CHARGE_amount
,MEDICARE_APP_amount
,tot_COVERED_EXPENSE
,avg_CHARGE_amount_6_mnths
,tot_benefit_amt_6_mnths
,MEDICARE_PAY_amount_12_mnths
,ECC_claim_total_deuct
,Gender_F
,new_member_fg
,tot_proc_days
,PART_B_DEDUCT
,paid_net_memb_cont_amt
,RDC_1
,no_claims
,application_processing_time
,avg_Benefit_amount
,avg_CHARGE_amount
,avg_DEDUCTIBLE_amount
,avg_MEDICARE_APP_amount
,avg_MEDICARE_PAY_amount
,avg_PART_B_DEDUCT
,avg_proc_days
,a_ECC_claim_total_amt_paid
,a_ECC_claim_total_app_amt
,a_ECC_claim_total_charge
,a_ECC_claim_total_deuct
,a_ECC_clm_tot_inelig_amt
,a_ECC_coins_amount
-- /*,no_held_days*/
,HOMVAL
,income
,NETWORK_HOSP_DIST
,networth
,no_calls
,tot_EFT_disc_amount
,tot_loyalty_disc_amount
,paid_net_memb_cont_amt_6_mnths
,ECC_BL_payment_amount_3_mnths
,ECC_coins_amount_3_mnths
,a_ECC_claim_total_app_6_mnths
,ECC_claim_total_amt_paid
,tot_benefit_amt
-- /*,held_days_6_mnths*/
,max_proc_days
,no_premium_6_mnths
,no_nba_camp_sent_before
,no_pres_PRIV_AUTH_3_mnths
,tot_Spouse_disc_amt_3_mnths
,tot_Spouse_disc_amt_6_mnths
,no_calls_3_mnths
,no_treatment_3_mnths
-- /*,time_service_days_6_mnths*/
,avg_CHARGE_amount_3_mnths
,a_ECC_claim_total_amt_pd_6_mnths
,ECC_BL_payment_amount_6_mnths
,BILL_PAY_INQ_call
,no_pres_PRIV_AUTH
,RET
,FAMP_F
,PLAN_INQ_call_3_mnths
,tot_EFT_disc_amount_3_mnths
,tot_EFT_disc_amount_6_mnths
,pdp_fg_final
,CLAIM_INQ_call_3_mnths
,no_nba_sent_12mnths
,OPPRTNTY_INQ_call_6_mnths
,DEDUCTIBLE_amount_3_mnths
,DEDUCTIBLE_amount_6_mnths
,TELEMARKETING_INQ_call
,no_pres_WEB_REG
,no_treatment_6_mnths
,no_camp_C000002230_180days
,previous_recc_EFT_360days
,no_1timeEFT_6mths
,no_late_12_mnths
,ECC_claim_total_app_amt
,no_treatment
,no_camp_C000003601_360days
,no_calls_6_mnths
,MEDICARE_APP_amount_6_mnths
,tot_premium_amt_3_mnths
-- /*,held_days_3_mnths*/
,a_ECC_claim_total_app_3_mnths
,PAID_CERT_QNTY
,no_premium_3_mnths
,tot_premium_amt_6_mnths
,ECC_claim_total_app_3_mnths
,ECC_claim_total_deuct_6_mnths
,MEDICARE_PAY_amount_6_mnths
,avg_COVERED_EXPENSE_6_mnths
,a_ECC_coins_amount_3_mnths
,no_camp_C000003460_180days
,paid_net_memb_cont_amt_3_mnths
-- /*,no_time_service_days*/
,a_ECC_claim_total_deuct_6_mnths
,SPECIFICATION_NAME
,MSUP_ACTIVE_PROD_DURATION
,no_premium
,tot_premium_amt
from IDENTIFIER(:V_WORK_DIR_EFT_TYPE_FINAL_DATASET6);



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_WORK_DIR_EFT_TYPE_FINAL_DATASET7)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



V_STEP := ''STEP33'';

V_STEP_NAME :=  ''create a table EFT_TYPE_FINAL_DATASET8'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_WORK_DIR_EFT_TYPE_FINAL_DATASET8) as
select  PERSON_ID,individual_id,
case when (tot_proc_days is null) then 0 else tot_proc_days end as tot_proc_days ,
case when (avg_proc_days is null) then 0 else avg_proc_days end as avg_proc_days ,
case when (max_proc_days is null) then 0 else max_proc_days end as max_proc_days ,
case when (tot_benefit_amt_6_mnths is null) then 0 else tot_benefit_amt_6_mnths end as tot_benefit_amt_6_mnths ,
case when (tot_benefit_amt is null) then 0 else tot_benefit_amt end as tot_benefit_amt ,
case when (ECC_BL_payment_amount_3_mnths is null) then 0 else ECC_BL_payment_amount_3_mnths end as ECC_BL_payment_amount_3_mnths ,
case when  (ECC_BL_payment_amount_6_mnths is null) then 0 else ECC_BL_payment_amount_6_mnths end as  ECC_BL_payment_amount_6_mnths ,
case when  (ECC_coins_amount_3_mnths is null) then 0 else ECC_coins_amount_3_mnths end as ECC_coins_amount_3_mnths ,
case when (a_ECC_coins_amount_3_mnths is null) then 0 else a_ECC_coins_amount_3_mnths end as a_ECC_coins_amount_3_mnths ,
case when (a_ECC_coins_amount is null) then 0 else a_ECC_coins_amount end as a_ECC_coins_amount ,
case when (ECC_claim_total_amt_paid is null) then 0 else ECC_claim_total_amt_paid end as ECC_claim_total_amt_paid ,
case when (a_ECC_claim_total_amt_pd_6_mnths is null) then 0 else a_ECC_claim_total_amt_pd_6_mnths end as a_ECC_claim_total_amt_pd_6_mnths ,
case when (a_ECC_claim_total_amt_paid is null) then 0 else a_ECC_claim_total_amt_paid end as a_ECC_claim_total_amt_paid ,
case when (ECC_claim_total_app_3_mnths is null) then 0 else ECC_claim_total_app_3_mnths end as ECC_claim_total_app_3_mnths ,
case when (ECC_claim_total_app_amt is null) then 0  else ECC_claim_total_app_amt end as ECC_claim_total_app_amt ,
case when (a_ECC_claim_total_app_3_mnths is null) then 0 else a_ECC_claim_total_app_3_mnths end as a_ECC_claim_total_app_3_mnths ,
case when  (a_ECC_claim_total_app_6_mnths is null) then 0 else a_ECC_claim_total_app_6_mnths end as  a_ECC_claim_total_app_6_mnths ,
case when  (a_ECC_claim_total_app_amt is null) then 0 else a_ECC_claim_total_app_amt end as a_ECC_claim_total_app_amt ,
case when  (a_ECC_claim_total_charge is null) then 0 else a_ECC_claim_total_charge end as a_ECC_claim_total_charge ,
case when  (ECC_claim_total_deuct_6_mnths is null) then 0 else ECC_claim_total_deuct_6_mnths end as ECC_claim_total_deuct_6_mnths ,
case when  (ECC_claim_total_deuct is null) then 0 else ECC_claim_total_deuct end as ECC_claim_total_deuct ,
case when  (a_ECC_claim_total_deuct_6_mnths is null) then 0 else a_ECC_claim_total_deuct_6_mnths end as a_ECC_claim_total_deuct_6_mnths ,
case when  (a_ECC_claim_total_deuct is null) then 0 else a_ECC_claim_total_deuct end as a_ECC_claim_total_deuct ,
case when (a_ECC_clm_tot_inelig_amt is null) then 0 else a_ECC_clm_tot_inelig_amt end as a_ECC_clm_tot_inelig_amt ,
case when (no_calls_3_mnths is null) then 0 else no_calls_3_mnths end as no_calls_3_mnths ,
case when (no_calls_6_mnths is null) then 0 else no_calls_6_mnths end as no_calls_6_mnths ,
case when (no_calls is null) then 0 else no_calls end as no_calls ,
case when (BILL_PAY_INQ_call is null) then 0  else BILL_PAY_INQ_call end as BILL_PAY_INQ_call ,
case when (CLAIM_INQ_call_3_mnths is null) then 0 else CLAIM_INQ_call_3_mnths end as CLAIM_INQ_call_3_mnths ,
case when (TELEMARKETING_INQ_call is null) then 0 else TELEMARKETING_INQ_call end as TELEMARKETING_INQ_call ,
case when (OPPRTNTY_INQ_call_6_mnths is null) then 0 else OPPRTNTY_INQ_call_6_mnths end as OPPRTNTY_INQ_call_6_mnths ,
case when (OPPRTNTY_INQ_call is null) then 0 else OPPRTNTY_INQ_call end as OPPRTNTY_INQ_call ,
case when (PLAN_INQ_call_3_mnths is null) then 0 else PLAN_INQ_call_3_mnths end as PLAN_INQ_call_3_mnths ,
case when (no_treatment_3_mnths is null) then 0 else no_treatment_3_mnths end as no_treatment_3_mnths ,
case when (no_treatment_6_mnths is null) then 0 else no_treatment_6_mnths end as no_treatment_6_mnths ,
case when (no_treatment is null) then  0 else no_treatment end as no_treatment ,
case when (no_pres_PRIV_AUTH_3_mnths is null) then 0 else no_pres_PRIV_AUTH_3_mnths end as no_pres_PRIV_AUTH_3_mnths ,
case when (no_pres_PRIV_AUTH is null) then 0 else no_pres_PRIV_AUTH end as no_pres_PRIV_AUTH ,
case when (no_pres_WEB_REG is null) then 0 else no_pres_WEB_REG end as no_pres_WEB_REG ,
case when (application_processing_time is null) then 1 else application_processing_time end as application_processing_time ,
case when (MSUP_NUM_LAPSES is null) then 0 else MSUP_NUM_LAPSES end as MSUP_NUM_LAPSES ,
case when (MSUP_ACTIVE_PROD_DURATION is null) then 66 else MSUP_ACTIVE_PROD_DURATION end as MSUP_ACTIVE_PROD_DURATION,
tenure,
case when (NETWORK_HOSP_DIST is null) then 0 else NETWORK_HOSP_DIST end as NETWORK_HOSP_DIST ,
case when (no_claims is null) then 0 else no_claims end as no_claims ,
case when (PART_B_DEDUCT is null) then 0 else PART_B_DEDUCT end as PART_B_DEDUCT ,
case when (avg_PART_B_DEDUCT is null) then 0 else avg_PART_B_DEDUCT end as avg_PART_B_DEDUCT ,
case when (avg_Benefit_amount is null) then 0 else avg_Benefit_amount end as avg_Benefit_amount ,
case when (tot_COVERED_EXPENSE is null) then 0 else tot_COVERED_EXPENSE end as tot_COVERED_EXPENSE ,
case when (avg_COVERED_EXPENSE_6_mnths is null) then 0 else avg_COVERED_EXPENSE_6_mnths end as avg_COVERED_EXPENSE_6_mnths ,
case when (CHARGE_amount is null) then 0 else CHARGE_amount end as CHARGE_amount ,
case when (avg_CHARGE_amount_3_mnths is null) then 0 else avg_CHARGE_amount_3_mnths end as avg_CHARGE_amount_3_mnths ,
case when (avg_CHARGE_amount_6_mnths is null) then 0 else avg_CHARGE_amount_6_mnths end as avg_CHARGE_amount_6_mnths ,
case when (avg_CHARGE_amount is null) then 0 else avg_CHARGE_amount end as avg_CHARGE_amount ,
case when (DEDUCTIBLE_amount_3_mnths is null) then 0 else DEDUCTIBLE_amount_3_mnths end as DEDUCTIBLE_amount_3_mnths ,
case when (DEDUCTIBLE_amount_6_mnths is null) then 0 else DEDUCTIBLE_amount_6_mnths end as DEDUCTIBLE_amount_6_mnths ,
case when (avg_DEDUCTIBLE_amount is null) then 0 else avg_DEDUCTIBLE_amount end as avg_DEDUCTIBLE_amount ,
case when (MEDICARE_APP_amount_6_mnths is null) then 0 else MEDICARE_APP_amount_6_mnths end as MEDICARE_APP_amount_6_mnths ,
case when (MEDICARE_APP_amount is null) then 0 else MEDICARE_APP_amount end as MEDICARE_APP_amount ,
case when (avg_MEDICARE_APP_amount is null or avg_MEDICARE_APP_amount = 99999) then 0 else avg_MEDICARE_APP_amount end as avg_MEDICARE_APP_amount ,
case when (MEDICARE_PAY_amount_6_mnths is null) then 0 else MEDICARE_PAY_amount_6_mnths end as MEDICARE_PAY_amount_6_mnths ,
case when (MEDICARE_PAY_amount_12_mnths is null) then 0 else MEDICARE_PAY_amount_12_mnths end as MEDICARE_PAY_amount_12_mnths ,
case when (avg_MEDICARE_PAY_amount is null or avg_MEDICARE_PAY_amount = 99999) then 0 else avg_MEDICARE_PAY_amount end as avg_MEDICARE_PAY_amount ,
case when (no_premium_3_mnths is null) then 0 else no_premium_3_mnths end as no_premium_3_mnths ,
case when (no_premium_6_mnths is null) then 0 else no_premium_6_mnths end as no_premium_6_mnths ,
case when (no_premium is null) then 0 else no_premium end as no_premium ,
case when (tot_EFT_disc_amount_3_mnths is null) then 0 else tot_EFT_disc_amount_3_mnths end as tot_EFT_disc_amount_3_mnths ,
case when (tot_EFT_disc_amount_6_mnths is null) then 0 else tot_EFT_disc_amount_6_mnths end as tot_EFT_disc_amount_6_mnths ,
case when (tot_EFT_disc_amount is null) then 0 else tot_EFT_disc_amount end as tot_EFT_disc_amount ,
case when (tot_loyalty_disc_amount is null) then 0 else tot_loyalty_disc_amount end as tot_loyalty_disc_amount ,
case when (tot_premium_amt_3_mnths is null) then 0 else tot_premium_amt_3_mnths end as tot_premium_amt_3_mnths ,
case when (tot_premium_amt_6_mnths is null ) then 0 else tot_premium_amt_6_mnths end as tot_premium_amt_6_mnths ,
case when (tot_premium_amt is null ) then 0 else tot_premium_amt end as tot_premium_amt ,
case when (paid_net_memb_cont_amt_3_mnths is null) then 0 else paid_net_memb_cont_amt_3_mnths end as paid_net_memb_cont_amt_3_mnths ,
case when (paid_net_memb_cont_amt_6_mnths is null) then 0 else paid_net_memb_cont_amt_6_mnths end as paid_net_memb_cont_amt_6_mnths ,
case when (paid_net_memb_cont_amt is null) then 0 else paid_net_memb_cont_amt end as paid_net_memb_cont_amt ,
case when (tot_Spouse_disc_amt_3_mnths is null) then 0 else tot_Spouse_disc_amt_3_mnths end as tot_Spouse_disc_amt_3_mnths ,
case when (tot_Spouse_disc_amt_6_mnths is null) then 0 else tot_Spouse_disc_amt_6_mnths end as tot_Spouse_disc_amt_6_mnths ,
case when (PAID_CERT_QNTY is null) then 0 else PAID_CERT_QNTY end as PAID_CERT_QNTY ,
case when (INDIVIDUAL_PREMIUM_AMOUNT is null) then 0 else INDIVIDUAL_PREMIUM_AMOUNT end as INDIVIDUAL_PREMIUM_AMOUNT ,
SPECIFICATION_NAME,
PLAN_CODE,
RET,
case when (HOMVAL is null) then 225 else HOMVAL end as HOMVAL ,
case when (FAMP_F is null) then 0 else FAMP_F end as FAMP_F ,
case when (Bank_Card_Single is null) then 0 else Bank_Card_Single end as Bank_Card_Single ,
case when (networth is null) then 625000 else networth end as networth ,
case when (income is null) then 67500 else income end as income ,
pdp_fg_final,
RDC_1,
new_member_fg,
age,
case when (Gender_F is null) then 0 else Gender_F end as Gender_F ,
no_nba_camp_sent_before,
no_nba_sent_12mnths,
case when (no_late_12_mnths is null) then 0 else no_late_12_mnths end as no_late_12_mnths ,
case when (no_1timeEFT_6mths is null) then 0 else no_1timeEFT_6mths end as no_1timeEFT_6mths ,
case when (previous_recc_EFT_360days is null) then 0 else previous_recc_EFT_360days end as previous_recc_EFT_360days ,
case when (no_camp_C000002230_180days is null) then 0 else no_camp_C000002230_180days end as no_camp_C000002230_180days ,
case when (no_camp_C000003460_180days is null) then 0 else no_camp_C000003460_180days end as no_camp_C000003460_180days ,
case when (no_camp_C000003601_360days is null) then 0 else no_camp_C000003601_360days end as no_camp_C000003601_360days 
from IDENTIFIER(:V_WORK_DIR_EFT_TYPE_FINAL_DATASET7);




V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_WORK_DIR_EFT_TYPE_FINAL_DATASET8)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



V_STEP := ''STEP34'';

V_STEP_NAME :=  ''create a table EFT_TYPE_FINAL_DATASET9'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_WORK_DIR_PREV_EFT_TYPE_FINAL_DATASET9) as
select * from IDENTIFIER(:V_WORK_DIR_EFT_TYPE_FINAL_DATASET9);



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_WORK_DIR_PREV_EFT_TYPE_FINAL_DATASET9)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




V_STEP := ''STEP35'';

V_STEP_NAME :=  ''create a table EFT_TYPE_FINAL_DATASET9'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_WORK_DIR_EFT_TYPE_FINAL_DATASET9) as
select * from IDENTIFIER(:V_WORK_DIR_EFT_TYPE_FINAL_DATASET8) where 
plan_code is not null;




V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_WORK_DIR_EFT_TYPE_FINAL_DATASET9)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);


RAISE;

END;

';