USE SCHEMA BDR_FFP_DA;


CREATE OR REPLACE PROCEDURE BDR_FFP_DA.SP_ASSET_DASHBOARD("PIPELINE_ID" VARCHAR(16777216), "PIPELINE_NAME" VARCHAR(16777216), "DB_NAME" VARCHAR(16777216), "UTIL_SC" VARCHAR(16777216), "TGT_SC" VARCHAR(16777216), "SRC_SC" VARCHAR(16777216), "WH" VARCHAR(16777216), "STAGE_NAME" VARCHAR(16777216), "FILE_FORMAT_CSV" VARCHAR(16777216), "FOLDER_PATH" VARCHAR(16777216), "CURR_DATE" DATE)
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

V_CURRENT_DATE DATE := COALESCE(:CURR_DATE, CURRENT_DATE());

V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := :DB_NAME||''.''||COALESCE(:UTIL_SC, ''UTIL'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';

V_STAGE_NAME VARCHAR := ''@''||:UTIL_SC||''.''||:STAGE_NAME;

V_FOLDER_PATH VARCHAR :=''analytics/outbox/''||:FOLDER_PATH;

V_INPUT_FILE VARCHAR := ''ListofDashboards_''||:V_CURRENT_DATE||''.csv'';

V_FILE_FORMAT_CSV VARCHAR := :UTIL_SC||''.''||:FILE_FORMAT_CSV;

V_PROCESS_NAME   VARCHAR DEFAULT ''ASSET_DASHBOARD'';

V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''ASSET_DASHBOARD'';

V_STEP             VARCHAR;

V_STEP_NAME        VARCHAR;

V_START_TIME       VARCHAR;

V_END_TIME         VARCHAR;

V_ROWS_PARSED       INTEGER;

V_ROWS_LOADED       INTEGER;

V_MESSAGE          VARCHAR;

V_LAST_QUERY_ID    VARCHAR;

V_ASSET_DASHBOARD_FULL  VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_FFP_DA_WRK'') || ''.ASSET_DASHBOARD_FULL'';
V_ASSET_DASHBOARD_WRK  VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_FFP_DA_WRK'') || ''.ASSET_DASHBOARD'';
V_ASSET_DASHBOARD_BKP VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_FFP_DA_WRK'') || ''.ASSET_DASHBOARD_BKP'';
V_ASSET_DASHBOARD  VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.ASSET_DASHBOARD'';

V_COPY_FULL VARCHAR := ''COPY INTO ''||:V_ASSET_DASHBOARD_FULL||'' FROM ''||:V_STAGE_NAME||''/''||:V_FOLDER_PATH||''/''||:V_INPUT_FILE||'' FILE_FORMAT''||''=''||''(''||''TYPE=CSV FIELD_OPTIONALLY_ENCLOSED_BY = ''||''''''''||''"''||''''''''||'' SKIP_HEADER=1 ''||'')'';

V_COPY_FILE VARCHAR := ''COPY INTO ''||:V_ASSET_DASHBOARD_WRK||'' FROM ''||:V_STAGE_NAME||''/''||:V_FOLDER_PATH||''/''||:V_INPUT_FILE||'' FILE_FORMAT''||''=''||''(''||''TYPE=CSV FIELD_OPTIONALLY_ENCLOSED_BY = ''||''''''''||''"''||''''''''||'' SKIP_HEADER=1 ''||'')'';


BEGIN

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP1'';

V_STEP_NAME :=  ''create table from input file'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


CREATE TABLE IF NOT EXISTS IDENTIFIER(:V_ASSET_DASHBOARD_FULL)
(
BUSINESS_UNIT STRING,
ASSET_TYPE STRING,
ASSET_NAME STRING,
ASSET_DESCRIPTION STRING,
ANALYSIS_TEAM STRING,
BUSINESS_OWNER STRING,
BUSINESS_TEAM STRING,
ASSET_OWNER STRING,
ASSET_STATUS STRING,
ASSET_CATEGORY STRING,
KPI STRING,
REFRESH_FREQUENCY STRING,
URL STRING,
UNIQUE_USERS_MAR22 STRING,
VIEWS_MAR22 STRING,
UNIQUE_USERS_Q122 STRING,
VIEWS_Q122 STRING,
MPO_MARY_FILE STRING,
DA STRING
);

EXECUTE IMMEDIATE :V_COPY_FULL;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_ASSET_DASHBOARD_FULL)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, NULL, NULL, NULL, NULL);


V_STEP := ''STEP2'';

V_STEP_NAME :=  ''create a ASSET_DASHBOARD Backup Table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_ASSET_DASHBOARD_BKP) COPY GRANTS AS SELECT * FROM IDENTIFIER(:V_ASSET_DASHBOARD_FULL);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_ASSET_DASHBOARD_BKP)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP3'';

V_STEP_NAME :=  ''create a ASSET_DASHBOARD STAGE Table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create OR REPLACE table  IDENTIFIER(:V_ASSET_DASHBOARD_WRK)
(
business_unit string,
asset_type string,
asset_name string,
asset_description string,
analysis_team string,
business_owner string,
business_team string,
asset_owner string,
asset_status string,
asset_category string,
kpi string,
refresh_frequency string,
url string,
unique_users_mar22 int,
views_mar22 int,
unique_users_q122 int,
views_q122 int,
mpo_mary_file string,
da string
) COPY GRANTS;

EXECUTE IMMEDIATE :V_COPY_FILE;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_ASSET_DASHBOARD_WRK)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

V_STEP := ''STEP4'';

V_STEP_NAME :=  ''create a ASSET_DASHBOARD FINAL Table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_ASSET_DASHBOARD) COPY GRANTS as 
select
case when TRIM(business_unit) = '''' then null else TRIM(business_unit) end as business_unit,
case when TRIM(asset_type) = '''' then null else TRIM(asset_type) end as asset_type,
case when TRIM(asset_name) = '''' then null else TRIM(asset_name) end as asset_name,
case when TRIM(asset_description) = '''' then null else TRIM(asset_description) end as asset_description,
case when TRIM(analysis_team) = '''' then null else TRIM(analysis_team) end as analysis_team,
case when TRIM(business_owner) = '''' then null else TRIM(business_owner) end as business_owner,
case when TRIM(business_team) = '''' then null else TRIM(business_team) end as business_team,
case when TRIM(asset_owner) = '''' then null else TRIM(asset_owner) end as asset_owner,
case when TRIM(asset_status) = '''' then null else TRIM(asset_status) end as asset_status,
case when TRIM(asset_category) = '''' then null else TRIM(asset_category) end as asset_category,
case when TRIM(kpi) = '''' then null else TRIM(kpi) end as kpi,
case when TRIM(refresh_frequency) = '''' then null else TRIM(refresh_frequency) end as refresh_frequency,
case when TRIM(url) = '''' then null else TRIM(url) end as url,
cast(unique_users_mar22 as bigint) as unique_users_mar22,
cast(views_mar22 as bigint) as views_mar22,
cast(unique_users_q122 as bigint) as unique_users_q122,
cast(views_q122 as bigint) as views_q122,
case when TRIM(mpo_mary_file) = '''' then null else TRIM(mpo_mary_file) end as mpo_mary_file,
case when TRIM(da) = '''' then null else TRIM(da) end as da from IDENTIFIER(:V_ASSET_DASHBOARD_WRK);

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_ASSET_DASHBOARD)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);


RAISE;

END;

';