USE SCHEMA BDR_FFP_DA;


CREATE OR REPLACE PROCEDURE BDR_FFP_DA.SP_AGENT_QUALITY_03_FEDERAL_HIERARCHY("PIPELINE_ID" VARCHAR(16777216), "PIPELINE_NAME" VARCHAR(16777216), "DB_NAME" VARCHAR(16777216), "UTIL_SC" VARCHAR(16777216), "TGT_SC" VARCHAR(16777216), "INTRM_SC" VARCHAR(16777216), "ONE_SC" VARCHAR(16777216), "TWO_SC" VARCHAR(16777216), "WH" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := :DB_NAME||''.''||COALESCE(:UTIL_SC, ''UTIL'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';

V_PROCESS_NAME   VARCHAR DEFAULT ''PROCESS_NAME'';

V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''03_TNA_RDC'';

V_STEP             VARCHAR;

V_STEP_NAME        VARCHAR;

V_START_TIME       VARCHAR;

V_END_TIME         VARCHAR;

V_ROWS_PARSED       INTEGER;

V_ROWS_LOADED       INTEGER;

V_MESSAGE          VARCHAR;

V_LAST_QUERY_ID    VARCHAR;



V_AGENT_QUALITY_ICM_CURRENT VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_ICM_CURRENT'';
V_AGENT_QUALITY_MBI_HIERARACHY_4_1_FED VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_MBI_HIERARACHY_4_1_FED'';
V_AGENT_QUALITY_FED_HIERARCHY_FINAL_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_FED_HIERARCHY_FINAL_1'';
V_AGENT_QUALITY_MBI_MA_PDP_SALES VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_MBI_MA_PDP_SALES'';
V_AGENT_QUALITY_FED_HIERARCHY_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_FED_HIERARCHY_1'';
V_AGENT_QUALITY_PROXIMITY_0 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_PROXIMITY_0'';
V_AGENT_QUALITY_PROXIMITY VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_PROXIMITY'';
V_AGENT_QUALITY_PROXIMITY_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_PROXIMITY_1'';
V_AGENT_QUALITY_PROXIMITY_2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_PROXIMITY_2'';
V_AGENT_QUALITY_MA_PDP_SALES VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_MA_PDP_SALES'';
V_CMS_HICN_TO_MBI_CROSSWALK  VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''SRC_UCEE'') || ''.CMS_HICN_TO_MBI_CROSSWALK'';


V_ALL_APPS_FEDERAL  VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''SRC_UCEE'') || ''.ALL_APPS_FEDERAL'';

V_SRC_ICM_COMMISSIONS_TRANSACTIONS_PAID_VW VARCHAR := :DB_NAME || ''.'' || COALESCE(:TWO_SC, ''SRC_ICM'') || ''.SRC_ICM_COMMISSIONS_TRANSACTIONS_PAID_VW'';

V_SCR_COMMISSION_PAID_DCM VARCHAR := :DB_NAME || ''.'' || COALESCE(:TWO_SC, ''SRC_ICM'') || ''.SCR_COMMISSION_PAID_DCM'';

V_SRC_ICM_COMMISSIONS_TRANSACTIONS_PAID_ARCHIVE_VW VARCHAR := :DB_NAME || ''.'' || COALESCE(:TWO_SC, ''SRC_ICM'') || ''.SRC_ICM_COMMISSIONS_TRANSACTIONS_PAID_ARCHIVE_VW'';

V_AGENT_QUALITY_ICM_ARCHIVE VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_ICM_ARCHIVE'';

V_AGENT_QUALITY_HIERARACHY_2_1_FED_FINAL VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_HIERARACHY_2_1_FED_FINAL'';

V_AGENT_QUALITY_HIERARACHY_0_FED         VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_HIERARACHY_0_FED'';

V_AGENT_QUALITY_HIERARACHY_1_FED VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_HIERARACHY_1_FED'';

V_AGENT_QUALITY_HIERARACHY_2_1_FED VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_HIERARACHY_2_1_FED'';

V_AGENT_QUALITY_HIERARACHY_2_2_FED VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_HIERARACHY_2_2_FED'';
V_AGENT_QUALITY_HIERARACHY_2_2_FED_FINAL VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_HIERARACHY_2_2_FED_FINAL'';
V_AGENT_QUALITY_HIERARACHY_4_1_FED VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_HIERARACHY_4_1_FED'';
V_AGENT_QUALITY_HIERARACHY_5_1_FED VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_HIERARACHY_5_1_FED'';
V_AGENT_QUALITY_HIERARACHY_5_2_FED VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_HIERARACHY_5_2_FED'';
V_AGENT_QUALITY_HIERARACHY_6_1_FED VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_HIERARACHY_6_1_FED'';
V_AGENT_QUALITY_HIERARACHY_6_1_FED_FINAL VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_HIERARACHY_6_1_FED_FINAL'';
V_AGENT_QUALITY_HIERARACHY_6_2_FED VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_HIERARACHY_6_2_FED'';
V_AGENT_QUALITY_HIERARACHY_6_3_FED VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_HIERARACHY_6_3_FED'';
V_AGENT_QUALITY_HIERARACHY_6_FED VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_HIERARACHY_6_FED'';
V_AGENT_QUALITY_HIERARACHY_9_1_FED VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_HIERARACHY_9_1_FED'';
V_AGENT_QUALITY_MBI_HIERARACHY_9_1_FED VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_MBI_HIERARACHY_9_1_FED'';
V_AGENT_QUALITY_HIERARACHY_10_FED VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_HIERARACHY_10'';
V_AGENT_QUALITY_HIERARACHY_11_FED VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_HIERARACHY_11_FED'';
V_AGENT_QUALITY_HIERARACHY_12_FED VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_HIERARACHY_12_FED'';
V_ISDW_EFF_SALES_DASHBOARD VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.LOSS_RATIO_ISDW_EFF_SALES_DASHBOARD'';
V_AGENT_QUALITY_FED_HIERARCHY_FINAL VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.AGENT_QUALITY_FED_HIERARCHY_FINAL'';


BEGIN


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP1'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_ICM_CURRENT'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_AGENT_QUALITY_ICM_CURRENT) COPY GRANTS AS 
select medicare_id,
allocation_agent_id, 
concat(contract_number,''-'',case when Length(Trim(pbp_number)) in (1,2) then lpad(Trim(pbp_number),3,0)
else pbp_number end) as contract_id,
effective_date,
app_sign_date,
ledger_item_date,
ledger_item_agent_level,
(case when ledger_item_agent_level in (70,80) then ledger_item_agent_id end) as NMA_agent_id,
(case when ledger_item_agent_level in (70,80) then payment_party_id end) as NMA_party_id,
(case when ledger_item_agent_level = 60 then ledger_item_agent_id end) as SMO_agent_id,
(case when ledger_item_agent_level = 60 then payment_party_id end) as SMO_party_id,
(case when ledger_item_agent_level = 50 then ledger_item_agent_id end) as FMO_agent_id,
(case when ledger_item_agent_level = 50 then payment_party_id end) as FMO_party_id,
(case when ledger_item_agent_level = 40 then ledger_item_agent_id end) as MGA_agent_id,
(case when ledger_item_agent_level = 40 then payment_party_id end) as MGA_party_id,
(case when ledger_item_agent_level = 30 then ledger_item_agent_id end) as GA_agent_id,
(case when ledger_item_agent_level = 30 then payment_party_id end) as GA_party_id,
(case when ledger_item_agent_level = 20 then ledger_item_agent_id end) as agent_ica_agent_id,
(case when ledger_item_agent_level = 20 then payment_party_id end) as agent_ica_party_id,
(case when ledger_item_agent_level = 1 then ledger_item_agent_id end) as solicitor_agent_id,
(case when ledger_item_agent_level = 1 then payment_party_id end) as solicitor_party_id,
writing_agent_id,
(case when agent_level = 1 then ''solicitor''
when agent_level = 20 then ''agent/ICA''
when agent_level = 30 then ''GA''
when agent_level = 40 then ''MGA''
when agent_level = 50 then ''FMO/SGA''
when agent_level = 60 then ''SMO''
when agent_level in (70,80) then ''NMA'' else ''check'' end) as agent_level_name,
(case when writing_agent_id = ledger_item_agent_id then 1 else 0 end) as hierarachy_flag,  
''icm2'' as tbl,
sum(credit) as s
from IDENTIFIER(:V_SRC_ICM_COMMISSIONS_TRANSACTIONS_PAID_VW)
where product_category not in (''MS'') 
group by 
medicare_id,
allocation_agent_id,
concat(contract_number,''-'',case when Length(Trim(pbp_number)) in (1,2) then lpad(Trim(pbp_number),3,0) else pbp_number end),
effective_date,
ledger_item_date,
ledger_item_agent_level,
app_sign_date,
(case when ledger_item_agent_level in (70,80) then ledger_item_agent_id end),
(case when ledger_item_agent_level in (70,80) then payment_party_id end),
(case when ledger_item_agent_level = 60 then ledger_item_agent_id end),
(case when ledger_item_agent_level = 60 then payment_party_id end),
(case when ledger_item_agent_level = 50 then ledger_item_agent_id end),
(case when ledger_item_agent_level = 50 then payment_party_id end),
(case when ledger_item_agent_level = 40 then ledger_item_agent_id end),
(case when ledger_item_agent_level = 40 then payment_party_id end),
(case when ledger_item_agent_level = 30 then ledger_item_agent_id end),
(case when ledger_item_agent_level = 30 then payment_party_id end),
(case when ledger_item_agent_level = 20 then ledger_item_agent_id end),
(case when ledger_item_agent_level = 20 then payment_party_id end),
(case when ledger_item_agent_level = 1 then ledger_item_agent_id end),
(case when ledger_item_agent_level = 1 then payment_party_id end),
writing_agent_id,
(case when agent_level = 1 then ''solicitor''
when agent_level = 20 then ''agent/ICA''
when agent_level = 30 then ''GA''
when agent_level = 40 then ''MGA''
when agent_level = 50 then ''FMO/SGA''
when agent_level = 60 then ''SMO''
when agent_level in (70,80) then ''NMA'' else ''check'' end),
(case when writing_agent_id = ledger_item_agent_id then 1 else 0 end),''icm2''; 

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_ICM_CURRENT)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP2'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_ICM_ARCHIVE'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

										   


create or replace table IDENTIFIER(:V_AGENT_QUALITY_ICM_ARCHIVE) COPY GRANTS AS 
select medicare_id,
allocation_agent_id, 
concat(contract_number,''-'',case when Length(Trim(pbp_number)) in (1,2) then lpad(Trim(pbp_number),3,0)
else pbp_number end) as contract_id,
effective_date,
app_sign_date,
ledger_item_date,
ledger_item_agent_level,
(case when ledger_item_agent_level in (70,80) then ledger_item_agent_id end) as NMA_agent_id,
(case when ledger_item_agent_level in (70,80) then payment_party_id end) as NMA_party_id,
(case when ledger_item_agent_level = 60 then ledger_item_agent_id end) as SMO_agent_id,
(case when ledger_item_agent_level = 60 then payment_party_id end) as SMO_party_id,
(case when ledger_item_agent_level = 50 then ledger_item_agent_id end) as FMO_agent_id,
(case when ledger_item_agent_level = 50 then payment_party_id end) as FMO_party_id,
(case when ledger_item_agent_level = 40 then ledger_item_agent_id end) as MGA_agent_id,
(case when ledger_item_agent_level = 40 then payment_party_id end) as MGA_party_id,
(case when ledger_item_agent_level = 30 then ledger_item_agent_id end) as GA_agent_id,
(case when ledger_item_agent_level = 30 then payment_party_id end) as GA_party_id,
(case when ledger_item_agent_level = 20 then ledger_item_agent_id end) as agent_ica_agent_id,
(case when ledger_item_agent_level = 20 then payment_party_id end) as agent_ica_party_id,
(case when ledger_item_agent_level = 1 then ledger_item_agent_id end) as solicitor_agent_id,
(case when ledger_item_agent_level = 1 then payment_party_id end) as solicitor_party_id,
writing_agent_id,
(case when agent_level = 1 then ''solicitor''
when agent_level = 20 then ''agent/ICA''
when agent_level = 30 then ''GA''
when agent_level = 40 then ''MGA''
when agent_level = 50 then ''FMO/SGA''
when agent_level = 60 then ''SMO''
when agent_level in (70,80) then ''NMA'' else ''check'' end) as agent_level_name,
(case when writing_agent_id = ledger_item_agent_id then 1 else 0 end) as hierarachy_flag,  
''icm1'' as tbl,
sum(credit) as s
from IDENTIFIER(:V_SRC_ICM_COMMISSIONS_TRANSACTIONS_PAID_ARCHIVE_VW)
where product_category not in (''MS'') 
group by 
medicare_id,
allocation_agent_id,
concat(contract_number,''-'',case when Length(Trim(pbp_number)) in (1,2) then lpad(Trim(pbp_number),3,0) else pbp_number end),
effective_date,
ledger_item_date,
ledger_item_agent_level,
app_sign_date,
(case when ledger_item_agent_level in (70,80) then ledger_item_agent_id end),
(case when ledger_item_agent_level in (70,80) then payment_party_id end),
(case when ledger_item_agent_level = 60 then ledger_item_agent_id end),
(case when ledger_item_agent_level = 60 then payment_party_id end),
(case when ledger_item_agent_level = 50 then ledger_item_agent_id end),
(case when ledger_item_agent_level = 50 then payment_party_id end),
(case when ledger_item_agent_level = 40 then ledger_item_agent_id end),
(case when ledger_item_agent_level = 40 then payment_party_id end),
(case when ledger_item_agent_level = 30 then ledger_item_agent_id end),
(case when ledger_item_agent_level = 30 then payment_party_id end),
(case when ledger_item_agent_level = 20 then ledger_item_agent_id end),
(case when ledger_item_agent_level = 20 then payment_party_id end),
(case when ledger_item_agent_level = 1 then ledger_item_agent_id end),
(case when ledger_item_agent_level = 1 then payment_party_id end),
writing_agent_id,
(case when agent_level = 1 then ''solicitor''
when agent_level = 20 then ''agent/ICA''
when agent_level = 30 then ''GA''
when agent_level = 40 then ''MGA''
when agent_level = 50 then ''FMO/SGA''
when agent_level = 60 then ''SMO''
when agent_level in (70,80) then ''NMA'' else ''check'' end),
(case when writing_agent_id = ledger_item_agent_id then 1 else 0 end),''icm1''; 

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_ICM_ARCHIVE)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP3'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_HIERARACHY_0_FED'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

										   


create or replace table IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_0_FED) COPY GRANTS AS 
select medicare_id,
allocation_agent_id, 
contract_id,
effective_date,
app_sign_date,
ledger_item_date,
ledger_item_agent_level,
NMA_agent_id,NMA_party_id,
SMO_agent_id,SMO_party_id,
FMO_agent_id,FMO_party_id,
MGA_agent_id,MGA_party_id,GA_agent_id,GA_party_id,
agent_ica_agent_id,agent_ica_party_id,solicitor_agent_id,solicitor_party_id,
writing_agent_id,tbl,agent_level_name,hierarachy_flag,s
from IDENTIFIER(:V_AGENT_QUALITY_ICM_CURRENT)
UNION
select medicare_id,
allocation_agent_id, 
contract_id,
effective_date,
app_sign_date,
ledger_item_date,
ledger_item_agent_level,
NMA_agent_id,NMA_party_id,
SMO_agent_id,SMO_party_id,
FMO_agent_id,FMO_party_id,
MGA_agent_id,MGA_party_id,GA_agent_id,GA_party_id,
agent_ica_agent_id,agent_ica_party_id,solicitor_agent_id,solicitor_party_id,
writing_agent_id,tbl,agent_level_name,hierarachy_flag,s
from IDENTIFIER(:V_AGENT_QUALITY_ICM_ARCHIVE);

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_0_FED)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP4'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_HIERARACHY_1_FED'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

										   

create or replace table IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_1_FED) COPY GRANTS AS  
select * 
from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_0_FED) 
where writing_agent_id <> '''' and ledger_item_date <> '''' ;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_1_FED)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP5'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_HIERARACHY_2_1_FED'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

										   

create or replace table IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_2_1_FED) COPY GRANTS AS 
Select 
medicare_id,
contract_id,
cast(effective_date as DATE) as effective_date,
cast(app_sign_date as DATE) as app_sign_date,
cast(ledger_item_date as DATE) as ledger_item_date,
coalesce(writing_agent_id,'''') as writing_agent_id,
coalesce(tbl,'''') as tbl,
max(coalesce(NMA_agent_id,'''')) as NMA_agent_id,
max(coalesce(NMA_party_id,'''')) as NMA_party_id,
max(coalesce(SMO_agent_id,'''')) as SMO_agent_id,
max(coalesce(SMO_party_id,'''')) as SMO_party_id,
max(coalesce(FMO_agent_id,'''')) as FMO_agent_id,
max(coalesce(FMO_party_id,'''')) as FMO_party_id,
max(coalesce(MGA_agent_id,'''')) as MGA_agent_id,
max(coalesce(MGA_party_id,'''')) as MGA_party_id,
max(coalesce(GA_agent_id,'''')) as GA_agent_id,
max(coalesce(GA_party_id,'''')) as GA_party_id,
max(coalesce(agent_ica_agent_id,'''')) as agent_ica_agent_id,
max(coalesce(agent_ica_party_id,'''')) as agent_ica_party_id,
max(coalesce(solicitor_agent_id,'''')) as solicitor_agent_id,
max(coalesce(solicitor_party_id,'''')) as solicitor_party_id,
sum(s) as credit
from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_1_FED)
group by medicare_id,
contract_id, cast(effective_date as DATE), cast(app_sign_date as DATE), cast(ledger_item_date as DATE), writing_agent_id,tbl; 

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_2_1_FED)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP6'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_HIERARACHY_2_1_FED_FINAL'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

										   

create or replace table IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_2_1_FED_FINAL) COPY GRANTS AS  
Select * from (
Select a.*, row_number() over (partition by a.medicare_id,
a.contract_id,a.writing_agent_id, a.effective_date
order by  a.app_sign_date desc, a.ledger_item_date desc) as rownum 
from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_2_1_FED) a) b
where b.rownum = 1;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_2_1_FED_FINAL)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP7'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_HIERARACHY_2_2_FED'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

										   

create or replace table IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_2_2_FED) COPY GRANTS AS  
Select medicare_id,
contract_id, cast(effective_date as DATE) as effective_date,
cast(app_sign_date as DATE) as app_sign_date,
cast(ledger_item_date as DATE) as ledger_item_date, writing_agent_id,tbl,
allocation_agent_id, hierarachy_flag, agent_level_name,ledger_item_agent_level
from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_1_FED);

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_2_2_FED)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP8'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_HIERARACHY_2_2_FED_FINAL'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

										   

create or replace table IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_2_2_FED_FINAL) COPY GRANTS AS 
select * from (
Select a.*, row_number() over (partition by a.medicare_id,
a.contract_id,a.writing_agent_id, a.effective_date
order by a.app_sign_date desc, a.ledger_item_date desc,a.hierarachy_flag desc,a.ledger_item_agent_level) as rowNum
from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_2_2_FED) a) b
where b.rownum = 1;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_2_2_FED_FINAL)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP9'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_HIERARACHY_4_1_FED'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

										   

create or replace table  IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_4_1_FED) COPY GRANTS AS  
Select a.*, b.allocation_agent_id, b.hierarachy_flag, 
b.agent_level_name , b.ledger_item_agent_level
from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_2_1_FED_FINAL) a 
left join IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_2_2_FED_FINAL) b
on coalesce(a.medicare_id,'''') = coalesce(b.medicare_id,'''')
and coalesce(a.contract_id,'''') = coalesce(b.contract_id,'''')
and a.effective_date = b. effective_date
and a.writing_agent_id = b.writing_agent_id;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_4_1_FED)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP10'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_MBI_HIERARACHY_4_1_FED'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

										   
use secondary roles all ;
create or replace table IDENTIFIER(:V_AGENT_QUALITY_MBI_HIERARACHY_4_1_FED) COPY GRANTS AS  
select a.contract_id,
allocation_agent_id,tbl,
a.writing_agent_id,a.effective_date,a.app_sign_date,a.ledger_item_date,a.agent_level_name,
a.nma_agent_id,a.nma_party_id,a.smo_agent_id,a.smo_party_id,
a.fmo_agent_id,a.fmo_party_id,a.mga_agent_id,a.mga_party_id,a.ga_agent_id,a.ga_party_id,
a.agent_ica_agent_id,a.agent_ica_party_id,a.solicitor_agent_id,a.solicitor_party_id,a.credit,a.rownum,
case when b.medicare_hicn_cd is not null then b.mbi else a.medicare_id end as mbi
from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_4_1_FED) a
left join IDENTIFIER(:V_CMS_HICN_TO_MBI_CROSSWALK) b
on a.medicare_id=b.medicare_hicn_cd;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_MBI_HIERARACHY_4_1_FED)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP11'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_HIERARACHY_5_1_FED'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

										   

create or replace table IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_5_1_FED) COPY GRANTS AS 
SELECT * from IDENTIFIER(:V_SCR_COMMISSION_PAID_DCM)
where product_category not in (''AARP MS'') ;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_5_1_FED)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP12'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_HIERARACHY_5_2_FED'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

										   

create or replace table IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_5_2_FED) COPY GRANTS AS 
select 
hic as medicare_id,
allocation_agent_id,
concat(contract_number,''-'',case when Length(Trim(pbp_number)) in (1,2) then lpad(Trim(pbp_number),3,0) else pbp_number end) as contract_id,
effective_date,
application_sign_date as app_sign_date,
ledger_item_date,
agent_level, 
(case when agent_level in (70,80) then ledger_item_agent_id end) as NMA_agent_id,
cast((case when agent_level in (70,80) then payment_party_id end) as string) as NMA_party_id,
(case when agent_level = 60 then ledger_item_agent_id end) as SMO_agent_id,
cast((case when agent_level = 60 then payment_party_id end) as string) as SMO_party_id,
(case when agent_level = 50 then ledger_item_agent_id end) as FMO_agent_id,
cast((case when agent_level = 50 then payment_party_id end) as string) as FMO_party_id,
(case when agent_level = 40 then ledger_item_agent_id end) as MGA_agent_id,
cast((case when agent_level = 40 then payment_party_id end) as string) as MGA_party_id,
(case when agent_level = 30 then ledger_item_agent_id end) as GA_agent_id,
cast((case when agent_level = 30 then payment_party_id end) as string) as GA_party_id,
(case when agent_level in (-1,20) then ledger_item_agent_id end) as agent_ica_agent_id,
cast((case when agent_level in (-1,20) then payment_party_id end) as string) as agent_ica_party_id,
(case when agent_level = 1 then ledger_item_agent_id end) as solicitor_agent_id,
cast((case when agent_level = 1 then payment_party_id end) as string) as solicitor_party_id,
writing_agent_id as writing_agent_id,
(case when agent_level = 1 then ''solicitor''
when agent_level in (-1,20) then ''agent/ICA''
when agent_level = 30 then ''GA''
when agent_level = 40 then ''MGA''
when agent_level = 50 then ''FMO/SGA''
when agent_level = 60 then ''SMO''
when agent_level in (70,80) then ''NMA'' else ''check'' end) as agent_level_name,
(case when writing_agent_id = ledger_item_agent_id then 1 else 0 end) as hierarachy_flag, 
sum(credit) as s
from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_5_1_FED)
group by 
hic,
allocation_agent_id,
concat(contract_number,''-'',case when Length(Trim(pbp_number)) in (1,2) then lpad(Trim(pbp_number),3,0) else pbp_number end),
effective_date,
application_sign_date,
ledger_item_date,
agent_level, 
(case when agent_level in (70,80) then ledger_item_agent_id end),
(case when agent_level in (70,80) then payment_party_id end),
(case when agent_level = 60 then ledger_item_agent_id end),
(case when agent_level = 60 then payment_party_id end),
(case when agent_level = 50 then ledger_item_agent_id end),
(case when agent_level = 50 then payment_party_id end),
(case when agent_level = 40 then ledger_item_agent_id end),
(case when agent_level = 40 then payment_party_id end),
(case when agent_level = 30 then ledger_item_agent_id end),
(case when agent_level = 30 then payment_party_id end),
(case when agent_level in (-1,20) then ledger_item_agent_id end),
(case when agent_level in (-1,20) then payment_party_id end),
(case when agent_level = 1 then ledger_item_agent_id end),
(case when agent_level = 1 then payment_party_id end),
writing_agent_id,
(case when agent_level = 1 then ''solicitor''
when agent_level in (-1,20) then ''agent/ICA''
when agent_level = 30 then ''GA''
when agent_level = 40 then ''MGA''
when agent_level = 50 then ''FMO/SGA''
when agent_level = 60 then ''SMO''
when agent_level in (70,80) then ''NMA'' else ''check'' end)
,(case when writing_agent_id = ledger_item_agent_id then 1 else 0 end);

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_5_2_FED)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP13'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_HIERARACHY_6_FED'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

										   

create or replace table IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_6_FED) COPY GRANTS AS  
select * 
from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_5_2_FED) 
where writing_agent_id <> '''' and ledger_item_date <> '''';

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_6_FED)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP14'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_HIERARACHY_6_1_FED'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

										   

create or replace table IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_6_1_FED) COPY GRANTS AS 
Select 
medicare_id,
contract_id,
cast(effective_date as DATE) as effective_date,
cast(app_sign_date as DATE) as app_sign_date,
cast(ledger_item_date as DATE) as ledger_item_date,
coalesce(writing_agent_id,'''') as writing_agent_id,
max(coalesce(NMA_agent_id,'''')) as NMA_agent_id,
max(coalesce(NMA_party_id,'''')) as NMA_party_id,
max(coalesce(SMO_agent_id,'''')) as SMO_agent_id,
max(coalesce(SMO_party_id,'''')) as SMO_party_id,
max(coalesce(FMO_agent_id,'''')) as FMO_agent_id,
max(coalesce(FMO_party_id,'''')) as FMO_party_id,
max(coalesce(MGA_agent_id,'''')) as MGA_agent_id,
max(coalesce(MGA_party_id,'''')) as MGA_party_id,
max(coalesce(GA_agent_id,'''')) as GA_agent_id,
max(coalesce(GA_party_id,'''')) as GA_party_id,
max(coalesce(agent_ica_agent_id,'''')) as agent_ica_agent_id,
max(coalesce(agent_ica_party_id,'''')) as agent_ica_party_id,
max(coalesce(solicitor_agent_id,'''')) as solicitor_agent_id,
max(coalesce(solicitor_party_id,'''')) as solicitor_party_id,
sum(s) as credit
from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_6_FED)
group by medicare_id,
contract_id, cast(effective_date as DATE), cast(app_sign_date as DATE), cast(ledger_item_date as DATE) , writing_agent_id; 

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_6_1_FED)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP15'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_HIERARACHY_6_1_FED_FINAL'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

										   

create or replace table IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_6_1_FED_FINAL) COPY GRANTS AS 
Select * from(
Select a.*,
row_number() over (partition by a.medicare_id,
a.contract_id,a.writing_agent_id,a.effective_date 
order by a.app_sign_date desc, ledger_item_date desc) as rownum
from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_6_1_FED) a) b
where b.rownum = 1;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_6_1_FED_FINAL)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP16'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_HIERARACHY_6_2_FED_FINAL'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

										   
											  
create or replace table IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_6_2_FED) COPY GRANTS AS  
Select medicare_id,
contract_id, cast(effective_date as DATE) as effective_date,
cast(app_sign_date as DATE) as app_sign_date,
cast(ledger_item_date as DATE) as ledger_item_date, writing_agent_id ,
allocation_agent_id, hierarachy_flag, agent_level_name,
row_number() over (partition by  a.medicare_id,a.contract_id,a.writing_agent_id,a.effective_date
order by a.app_sign_date desc, ledger_item_date desc, hierarachy_flag desc ,agent_level) as rownumber
from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_6_FED) a; 

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_6_2_FED)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP17'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_HIERARACHY_6_3_FED'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

										   

create or replace table IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_6_3_FED) COPY GRANTS AS 
select medicare_id,
contract_id, effective_date, app_sign_date, ledger_item_date, writing_agent_id ,
allocation_agent_id, hierarachy_flag, agent_level_name from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_6_2_FED) where rownumber = 1; 

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_6_3_FED)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP18'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_HIERARACHY_9_1_FED'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

										   

create or replace table  IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_9_1_FED) COPY GRANTS AS  
Select a.*, b.allocation_agent_id, b.hierarachy_flag, b.agent_level_name
from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_6_1_FED_FINAL) a left join IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_6_3_FED) b
on coalesce(a.medicare_id,'''') = coalesce(b.medicare_id,'''')
and coalesce(a.contract_id,'''') = coalesce(b.contract_id,'''')
and a.effective_date = b. effective_date
and a.writing_agent_id = b.writing_agent_id;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_9_1_FED)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP19'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_MBI_HIERARACHY_9_1_FED'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

										   
use secondary roles all ;
create or replace table IDENTIFIER(:V_AGENT_QUALITY_MBI_HIERARACHY_9_1_FED) COPY GRANTS AS  
select a.contract_id,
allocation_agent_id,
a.writing_agent_id,a.effective_date,a.app_sign_date,a.ledger_item_date,a.agent_level_name,
a.nma_agent_id,a.nma_party_id,a.smo_agent_id,a.smo_party_id,
a.fmo_agent_id,a.fmo_party_id,a.mga_agent_id,a.mga_party_id,a.ga_agent_id,a.ga_party_id,
a.agent_ica_agent_id,a.agent_ica_party_id,a.solicitor_agent_id,a.solicitor_party_id,a.credit,
case when b.medicare_hicn_cd is not null then b.mbi else a.medicare_id end as mbi
from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_9_1_FED) a
left join IDENTIFIER(:V_CMS_HICN_TO_MBI_CROSSWALK) b
on a.medicare_id=b.medicare_hicn_cd;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_MBI_HIERARACHY_9_1_FED)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP20'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_HIERARACHY_10_FED'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

										   

create or replace table IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_10_FED) COPY GRANTS AS  
select distinct 
coalesce(b.mbi,'''') as mbi, coalesce(b.contract_id,'''') as contract_id,
coalesce(allocation_agent_id,'''') as allocation_agent_id,
coalesce(b.writing_agent_id,'''') as writing_agent_id,
coalesce(b.effective_date,'''') as effective_date,
coalesce(b.app_sign_date,'''') as app_sign_date,
coalesce(b.agent_level_name,'''') as agent_level_name,
coalesce(b.nma_agent_id,'''') as nma_agent_id, coalesce(b.nma_party_id,'''') as nma_party_id,
coalesce(b.smo_agent_id,'''') as smo_agent_id, coalesce(b.smo_party_id,'''') as smo_party_id,
coalesce(b.fmo_agent_id,'''') as fmo_agent_id, coalesce(b.fmo_party_id,'''') as fmo_party_id,
coalesce(b.mga_agent_id,'''') as mga_agent_id, coalesce(b.mga_party_id,'''') as mga_party_id,
coalesce(b.ga_agent_id,'''') as ga_agent_id, coalesce(b.ga_party_id,'''') as ga_party_id,
coalesce(b.agent_ica_agent_id,'''') as agent_ica_agent_id, coalesce(b.agent_ica_party_id,'''') as agent_ica_party_id,
coalesce(b.solicitor_agent_id,'''') as solicitor_agent_id, coalesce(b.solicitor_party_id,'''') as solicitor_party_id,
coalesce(tbl,'''') as tbl 
from IDENTIFIER(:V_AGENT_QUALITY_MBI_HIERARACHY_4_1_FED) b
union
select distinct 
coalesce(b.mbi,'''') as mbi, coalesce(b.contract_id,'''') as contract_id,
coalesce(allocation_agent_id,'''') as allocation_agent_id,
coalesce(b.writing_agent_id,'''') as writing_agent_id,
coalesce(b.effective_date,'''') as effective_date,
coalesce(b.app_sign_date,'''') as app_sign_date,
coalesce(b.agent_level_name,'''') as agent_level_name,
coalesce(b.nma_agent_id,'''') as nma_agent_id, coalesce(b.nma_party_id,'''') as nma_party_id,
coalesce(b.smo_agent_id,'''') as smo_agent_id, coalesce(b.smo_party_id,'''') as smo_party_id,
coalesce(b.fmo_agent_id,'''') as fmo_agent_id, coalesce(b.fmo_party_id,'''') as fmo_party_id,
coalesce(b.mga_agent_id,'''') as mga_agent_id, coalesce(b.mga_party_id,'''') as mga_party_id,
coalesce(b.ga_agent_id,'''') as ga_agent_id, coalesce(b.ga_party_id,'''') as ga_party_id,
coalesce(b.agent_ica_agent_id,'''') as agent_ica_agent_id, coalesce(b.agent_ica_party_id,'''') as agent_ica_party_id,
coalesce(b.solicitor_agent_id,'''') as solicitor_agent_id, coalesce(b.solicitor_party_id,'''') as solicitor_party_id,
''dcm'' as tbl from IDENTIFIER(:V_AGENT_QUALITY_MBI_HIERARACHY_9_1_FED) b;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_10_FED)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP21'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_HIERARACHY_11_FED'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

										   
											 
create or replace table IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_11_FED) COPY GRANTS AS  
select a.*,row_number() over (partition by a.mbi,a.contract_id,a.writing_agent_id, a.effective_date 
order by a.mbi,a.contract_id,a.writing_agent_id,a.effective_date ,a.tbl desc) as rowNum
from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_10_FED) a;
V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_11_FED)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP22'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_HIERARACHY_12_FED'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

										   


create or replace table IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_12_FED) COPY GRANTS AS  
select b.mbi,b.contract_id,
allocation_agent_id,
b.writing_agent_id, b.effective_date,b.app_sign_date,
b.agent_level_name,
(case when b.effective_date<''2023-10-01'' then coalesce(b.nma_agent_id, b.smo_agent_id) else b.nma_agent_id end) as nma_agent_id,
(case when b.effective_date<''2023-10-01'' then coalesce(b.nma_party_id, b.smo_party_id) else b.nma_party_id end) as nma_party_id,
(case when b.effective_date<''2023-10-01'' then '''' else b.smo_agent_id end) as smo_agent_id,
(case when b.effective_date<''2023-10-01'' then '''' else b.smo_party_id end) as smo_party_id,
b.nma_agent_id as nma_agent_id_orig, b.nma_party_id as nma_party_id_orig, 
b.smo_agent_id as smo_agent_id_orig, b.smo_party_id as smo_party_id_orig, --changes
b.fmo_agent_id,b.fmo_party_id,
b.mga_agent_id,b.mga_party_id,b.ga_agent_id,b.ga_party_id,b.agent_ica_agent_id,b.agent_ica_party_id,
b.solicitor_agent_id,b.solicitor_party_id,
tbl,rowNum
from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_11_FED) b
where rowNum = 1;
V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_12_FED)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP23'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_MA_PDP_SALES'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

										   

use secondary roles all ;
create or replace table IDENTIFIER(:V_AGENT_QUALITY_MA_PDP_SALES) COPY GRANTS AS  
select b.pty_id, 
a.indvdl_id,
a.zip_cd,
a.hh_id,
a.chnl_desc,
case when a.app_channel=''TEL'' or a.app_channel=''TELESALES'' then ''TELESALES''
when a.app_channel=''EDC'' or a.app_channel=''EDCAGG'' or a.app_channel=''FMO'' then ''FMO''
else a.app_channel end as app_channel,
substr(a.CONTRACT_ID_CD,0,9) as CONTRACT_ID_CD,
a.MEDICARE_HICN_CD,
a.PLAN_EFF_DT,
a.broker_id_cd,
substr(a.stfips,1,2) as st_cd,
a.PRODUCT_SEGMENTS,
a.appl_id_cd
from (select * from  IDENTIFIER(:V_ALL_APPS_FEDERAL)
where PRODUCT_SEGMENTS in (''MA INDIVIDUAL'',''M&R SNP'',''PDP'') 
and broker_id_cd is not null
and (PLAN_EFF_DT between ''2015-01-01'' and  concat((year(current_date)),''-'',lpad(month((current_date)),2,''0''),''-01''))
and STATUS in (''NEW'',''WINBACK'') 
and ADJUDICATION_STAT_CD = 1) a 
inner join (select distinct pty_id_final as PTY_ID, agt_id_final as broker_id_cd
from IDENTIFIER(:V_ISDW_EFF_SALES_DASHBOARD)
where marketing_channel_final in (''Agent'')) b
on a.broker_id_cd = b.broker_id_cd
group by b.pty_id,
a.indvdl_id,
a.zip_cd,
a.hh_id,
a.chnl_desc,
(case when a.app_channel=''TEL'' or a.app_channel=''TELESALES'' then ''TELESALES''
when a.app_channel=''EDC'' or a.app_channel=''EDCAGG'' or a.app_channel=''FMO'' then ''FMO''
else a.app_channel end),
substr(a.CONTRACT_ID_CD,0,9),
a.MEDICARE_HICN_CD,
a.PLAN_EFF_DT,
a.broker_id_cd,
substr(a.stfips,1,2),
a.PRODUCT_SEGMENTS,
a.appl_id_cd;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_MA_PDP_SALES)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP24'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_MBI_MA_PDP_SALES'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

										   
use secondary roles all ;
create or replace table IDENTIFIER(:V_AGENT_QUALITY_MBI_MA_PDP_SALES) COPY GRANTS AS  
select distinct a.pty_id,a.indvdl_id,a.zip_cd,a.hh_id,a.chnl_desc,a.app_channel,a.contract_id_cd,a.plan_eff_dt,a.broker_id_cd,a.st_cd,a.product_segments,a.appl_id_cd,a.medicare_hicn_cd,
case when b.medicare_hicn_cd is not null then b.mbi else a.medicare_hicn_cd end as mbi 
from IDENTIFIER(:V_AGENT_QUALITY_MA_PDP_SALES) a
left join IDENTIFIER(:V_CMS_HICN_TO_MBI_CROSSWALK) b
on a.medicare_hicn_cd=b.medicare_hicn_cd;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_MBI_MA_PDP_SALES)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP25'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_FED_HIERARCHY_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

										   


create or replace table IDENTIFIER(:V_AGENT_QUALITY_FED_HIERARCHY_1) COPY GRANTS AS 
select distinct a.indvdl_id,a.zip_cd,a.hh_id,a.chnl_desc,a.app_channel,
a.contract_id_cd,a.plan_eff_dt,a.broker_id_cd,st_cd,a.product_segments,a.appl_id_cd,a.mbi,
case when b.mbi is null then 0 else 1 end as psu_fg,
case when ((case when b.mbi is null then 0 else 1 end)=0 and a.app_channel in (''TELESALES'',''ISR'')) then a.app_channel else b.agent_level_name end as agent_level_name,
case when ((case when b.mbi is null then 0 else 1 end)=0 and a.app_channel in (''TELESALES'',''ISR'')) then a.app_channel else b.nma_agent_id end as nma_agent_id,
case when ((case when b.mbi is null then 0 else 1 end)=0 and a.app_channel in (''TELESALES'',''ISR'')) then a.app_channel else b.nma_party_id end as nma_party_id,
case when ((case when b.mbi is null then 0 else 1 end)=0 and a.app_channel in (''TELESALES'',''ISR'')) then a.app_channel else b.smo_agent_id end as smo_agent_id,
case when ((case when b.mbi is null then 0 else 1 end)=0 and a.app_channel in (''TELESALES'',''ISR'')) then a.app_channel else b.smo_party_id end as smo_party_id,--changes
case when ((case when b.mbi is null then 0 else 1 end)=0 and a.app_channel in (''TELESALES'',''ISR'')) then a.app_channel else b.fmo_agent_id end as fmo_agent_id,
case when ((case when b.mbi is null then 0 else 1 end)=0 and a.app_channel in (''TELESALES'',''ISR'')) then a.app_channel else b.fmo_party_id end as fmo_party_id,
case when ((case when b.mbi is null then 0 else 1 end)=0 and a.app_channel in (''TELESALES'',''ISR'')) then a.app_channel else b.mga_agent_id end as mga_agent_id,
case when ((case when b.mbi is null then 0 else 1 end)=0 and a.app_channel in (''TELESALES'',''ISR'')) then a.app_channel else b.mga_party_id end as mga_party_id,
case when ((case when b.mbi is null then 0 else 1 end)=0 and a.app_channel in (''TELESALES'',''ISR'')) then a.app_channel else b.ga_agent_id end as ga_agent_id,
case when ((case when b.mbi is null then 0 else 1 end)=0 and a.app_channel in (''TELESALES'',''ISR'')) then a.app_channel else b.ga_party_id end as ga_party_id,
case when ((case when b.mbi is null then 0 else 1 end)=0 and a.app_channel in (''TELESALES'',''ISR'')) then a.app_channel else b.agent_ica_agent_id end as agent_ica_agent_id,
case when ((case when b.mbi is null then 0 else 1 end)=0 and a.app_channel in (''TELESALES'',''ISR'')) then a.app_channel else b.agent_ica_party_id end as agent_ica_party_id,
case when ((case when b.mbi is null then 0 else 1 end)=0 and a.app_channel in (''TELESALES'',''ISR'')) then a.app_channel else b.solicitor_agent_id end as solicitor_agent_id,
case when ((case when b.mbi is null then 0 else 1 end)=0 and a.app_channel in (''TELESALES'',''ISR'')) then a.app_channel else b.solicitor_party_id end as solicitor_party_id
from IDENTIFIER(:V_AGENT_QUALITY_MBI_MA_PDP_SALES) a
left join IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_12_FED)  b 
on a.mbi= b.mbi and a.broker_id_cd=b.writing_agent_id and
a.contract_id_cd=b.contract_id and a.plan_eff_dt=b.effective_date;

--Proximity Method
V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_FED_HIERARCHY_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP26'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_PROXIMITY'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

										   

create or replace table IDENTIFIER(:V_AGENT_QUALITY_PROXIMITY) COPY GRANTS as 
select * from IDENTIFIER(:V_AGENT_QUALITY_FED_HIERARCHY_1) where psu_fg=0 and app_channel not in (''TELESALES'',''ISR'');

	V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_PROXIMITY)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP27'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_PROXIMITY_0'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

										   
								   
create or replace table IDENTIFIER(:V_AGENT_QUALITY_PROXIMITY_0) COPY GRANTS AS  
select distinct a.indvdl_id,a.zip_cd,a.hh_id,a.chnl_desc,a.app_channel,
a.contract_id_cd,a.plan_eff_dt,a.broker_id_cd,st_cd,a.product_segments,a.appl_id_cd,a.mbi,
b.effective_date,abs(cast(months_between(a.plan_eff_dt, b.effective_date)as int)) as month_diff,b.agent_level_name,
b.nma_agent_id,b.nma_party_id,b.smo_agent_id,b.smo_party_id,
b.fmo_agent_id,b.fmo_party_id,b.mga_agent_id,b.mga_party_id,b.ga_agent_id,
b.ga_party_id,b.agent_ica_agent_id,b.agent_ica_party_id,b.solicitor_agent_id,b.solicitor_party_id,
case when b.writing_agent_id is null then 0 else 1 end as proximity_fg
from IDENTIFIER(:V_AGENT_QUALITY_PROXIMITY) a
left join IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_12_FED) b
on a.broker_id_cd=b.writing_agent_id and abs(cast(months_between(a.plan_eff_dt, b.effective_date)as int)) <= 6;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_PROXIMITY_0)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP28'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_PROXIMITY_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

										   

									   
create or replace table IDENTIFIER(:V_AGENT_QUALITY_PROXIMITY_1) COPY GRANTS AS  
select a.*, row_number() over(partition by mbi,contract_id_cd,broker_id_cd,plan_eff_dt order by month_diff,effective_date,agent_level_name,nma_agent_id,
nma_party_id,
smo_agent_id,
smo_party_id,
fmo_agent_id,
fmo_party_id,
mga_agent_id,
mga_party_id,
ga_agent_id,
ga_party_id,
agent_ica_agent_id,
agent_ica_party_id,
solicitor_agent_id,
solicitor_party_id) as rowNum2
from IDENTIFIER(:V_AGENT_QUALITY_PROXIMITY_0) a;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_PROXIMITY_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP29'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_PROXIMITY_2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

										   
									   
create or replace table IDENTIFIER(:V_AGENT_QUALITY_PROXIMITY_2) COPY GRANTS AS  
select a.*
from IDENTIFIER(:V_AGENT_QUALITY_PROXIMITY_1) a
where rowNum2 = 1;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_PROXIMITY_2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP30'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_FED_HIERARCHY_FINAL_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

										   

												 
create or replace table IDENTIFIER(:V_AGENT_QUALITY_FED_HIERARCHY_FINAL_1) COPY GRANTS AS  
select a.indvdl_id,a.zip_cd,a.hh_id,a.chnl_desc,a.app_channel,a.contract_id_cd,a.plan_eff_dt,a.broker_id_cd,st_cd,a.product_segments,a.appl_id_cd,a.mbi,
a.agent_level_name,a.nma_agent_id,a.nma_party_id,a.smo_agent_id,a.smo_party_id,
a.fmo_agent_id,a.fmo_party_id,a.mga_agent_id,a.mga_party_id,a.ga_agent_id,a.ga_party_id,a.agent_ica_agent_id,
a.agent_ica_party_id,a.solicitor_agent_id,a.solicitor_party_id,psu_fg,2 as proximity_fg,-1 as month_diff from IDENTIFIER(:V_AGENT_QUALITY_FED_HIERARCHY_1) a where (a.psu_fg=1 or a.app_channel in (''TELESALES'',''ISR''))
union all
select b.indvdl_id,b.zip_cd,b.hh_id,b.chnl_desc,b.app_channel,b.contract_id_cd,b.plan_eff_dt,b.broker_id_cd,st_cd,b.product_segments,b.appl_id_cd,b.mbi,
b.agent_level_name,b.nma_agent_id,b.nma_party_id,b.smo_agent_id,b.smo_party_id,
b.fmo_agent_id,b.fmo_party_id,b.mga_agent_id,b.mga_party_id,b.ga_agent_id,b.ga_party_id,b.agent_ica_agent_id,
b.agent_ica_party_id,b.solicitor_agent_id,b.solicitor_party_id,2 as psu_fg,proximity_fg,month_diff from IDENTIFIER(:V_AGENT_QUALITY_PROXIMITY_2) b;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_FED_HIERARCHY_FINAL_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP31'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_FED_HIERARCHY_FINAL'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

										   

											   
create or replace table IDENTIFIER(:V_AGENT_QUALITY_FED_HIERARCHY_FINAL) COPY GRANTS AS  
select b.indvdl_id,b.zip_cd,b.hh_id,b.chnl_desc,b.app_channel,b.contract_id_cd,b.plan_eff_dt,b.broker_id_cd,st_cd,b.product_segments,b.appl_id_cd,b.mbi,b.agent_level_name,
b.nma_agent_id,b.nma_party_id,b.smo_agent_id,b.smo_party_id,
b.fmo_agent_id,b.fmo_party_id,b.mga_agent_id,b.mga_party_id,b.ga_agent_id,b.ga_party_id,b.agent_ica_agent_id,
b.agent_ica_party_id,b.solicitor_agent_id,b.solicitor_party_id, 
case 
when b.psu_fg=1 then ''Direct'' 
when b.psu_fg=0 and b.app_channel in (''TELESALES'',''ISR'') then ''ISR/TELESALES''
when proximity_fg=1 then ''Proximity'' end as match_category
from IDENTIFIER(:V_AGENT_QUALITY_FED_HIERARCHY_FINAL_1) b;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_FED_HIERARCHY_FINAL)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);


RAISE;

END;

';