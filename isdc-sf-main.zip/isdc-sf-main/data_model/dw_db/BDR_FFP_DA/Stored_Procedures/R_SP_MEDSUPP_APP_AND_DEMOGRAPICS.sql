USE SCHEMA BDR_FFP_DA;






CREATE OR REPLACE PROCEDURE BDR_FFP_DA.SP_MEDSUPP_APP_AND_DEMOGRAPICS("PIPELINE_ID" VARCHAR(16777216), "PIPELINE_NAME" VARCHAR(16777216), "DB_NAME" VARCHAR(16777216), "UTIL_SC" VARCHAR(16777216), "ONE_SC" VARCHAR(16777216), "TWO_SC" VARCHAR(16777216), "THREE_SC" VARCHAR(16777216), "TGT_SC" VARCHAR(16777216), "WH" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE



V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := :DB_NAME||''.''||COALESCE(:UTIL_SC, ''UTIL'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';
        
V_PROCESS_NAME VARCHAR DEFAULT ''DAILY_APPS_DEMOGRAPICS_AMLK'';

V_SUB_PROCESS_NAME VARCHAR DEFAULT ''MEDSUPP_APP_AND_DEMOGRAPICS'';

V_STEP             VARCHAR;

V_STEP_NAME        VARCHAR;

V_START_TIME       VARCHAR;

V_END_TIME         VARCHAR;

V_ROWS_PARSED       INTEGER;

V_ROWS_LOADED       INTEGER;

V_MESSAGE          VARCHAR;

V_LAST_QUERY_ID    VARCHAR;

V_medsupp_apps_demographics_24_and_23 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.apps_demog_medsupp_apps_demographics_24_and_23'';

V_apps_rptg_daily VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''SRC_MPO'') || ''.apps_rptg_daily'';

V_bottomsup_campaignref_depotprj VARCHAR := :DB_NAME || ''.'' || COALESCE(:TWO_SC, ''SRC_FIN360'') || ''.bottomsup_campaignref_depotprj'';

V_person_address_hhold_profile VARCHAR := :DB_NAME || ''.'' || COALESCE(:THREE_SC, ''BDR_SMART'') || ''.person_address_hhold_profile'';

V_amerilink_data VARCHAR := :DB_NAME || ''.'' || COALESCE(:THREE_SC, ''BDR_SMART'') || ''.amerilink_data'';
/*
V_apps_rptg_daily_subset VARCHAR:= :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.apps_demog_apps_rptg_daily_subset'';

V_Medsupp_Apps_Demographics_subset VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.apps_demog_Medsupp_Apps_Demographics_subset'';

V_Medsupp_Apps_Demographics_21_and_20 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.apps_demog_Medsupp_Apps_Demographics_21_and_20'';
*/


BEGIN

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP1'';
  
V_STEP_NAME := ''Loading table apps_demog_medsupp_apps_demographics_24_and_23'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH; 

create or replace table IDENTIFIER(:V_medsupp_apps_demographics_24_and_23) as  
select a.* exclude(CREAT_DT,CREAT_BY,LST_MOD_DT,LST_MOD_BY,ETL_LST_BTCH_ID,FILE_NAME,FILE_MONTH_ID), 
b.* exclude(CREAT_DT,CREAT_BY,LST_MOD_DT,LST_MOD_BY,ETL_LST_BTCH_ID,FILE_NAME,FILE_MONTH_ID),
am.person_id as amerlink_person_id,
am.amlk_id,
am.gend,
am.hhcomp,
am.geners,
am.nph19,
am.cmys,
am.estinc30,
h.person_id as hhold_person_id,
h.hh_address_id,
h.qty_in_address
from IDENTIFIER(:V_apps_rptg_daily) a
left join IDENTIFIER(:V_bottomsup_campaignref_depotprj) b on  a.projectcode_depot = b.`2023_projectcode`
left join IDENTIFIER(:V_person_address_hhold_profile) h on a.person_id = h.person_id 
left join IDENTIFIER(:V_amerilink_data) am on a.person_id = am.person_id 
where product = ''MS''
and year(appl_receipt_date) = 2023

union all

select a.* exclude(CREAT_DT,CREAT_BY,LST_MOD_DT,LST_MOD_BY,ETL_LST_BTCH_ID,FILE_NAME,FILE_MONTH_ID), 
b.* exclude(CREAT_DT,CREAT_BY,LST_MOD_DT,LST_MOD_BY,ETL_LST_BTCH_ID,FILE_NAME,FILE_MONTH_ID),
am.person_id as amerlink_person_id,
am.amlk_id,
am.gend,
am.hhcomp,
am.geners,
am.nph19,
am.cmys,
am.estinc30,
h.person_id as hhold_person_id,
h.hh_address_id,
h.qty_in_address
from IDENTIFIER(:V_apps_rptg_daily) a
left join IDENTIFIER(:V_bottomsup_campaignref_depotprj) b on  a.projectcode_depot = b.`2024_projectcode`
left join IDENTIFIER(:V_person_address_hhold_profile) h on a.person_id = h.person_id 
left join IDENTIFIER(:V_amerilink_data) am on a.person_id = am.person_id 
where product = ''MS''
and year(appl_receipt_date) = 2024;

V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_medsupp_apps_demographics_24_and_23) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

/*
V_STEP := ''STEP2'';
   
V_STEP_NAME := ''Loading table apps_demog_apps_rptg_daily_subset'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
*/
-- create or replace table IDENTIFIER(:V_apps_rptg_daily_subset)  as
-- select * from IDENTIFIER(:V_apps_rptg_daily) 
-- where product = ''MS''
-- and year(appl_receipt_date) in (2020,2021);
/*
V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_apps_rptg_daily_subset) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP3'';
   
V_STEP_NAME := ''Loading table apps_demog_Medsupp_Apps_Demographics_subset'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
*/  
-- create table IDENTIFIER(:V_Medsupp_Apps_Demographics_subset) as
-- select 
--  a.*,
-- am.person_id as amerlink_person_id,
-- am.amlk_id,
-- am.gend,
-- am.hhcomp,
-- am.geners,
-- am.race,
-- am.nph19,
-- am.cmys,
-- am.estinc30,
-- h.person_id as hhold_person_id,
-- h.hh_address_id,
-- h.qty_in_address
-- from IDENTIFIER(:V_apps_rptg_daily_subset) a
-- left join IDENTIFIER(:V_person_address_hhold_profile) h on a.person_id = h.person_id 
-- left join IDENTIFIER(:V_amerilink_data) am on a.person_id = am.person_id;
/*
V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_Medsupp_Apps_Demographics_subset) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
*/

/*
V_STEP := ''STEP4'';
   
V_STEP_NAME := ''Loading table apps_demog_Medsupp_Apps_Demographics_21_and_20'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
 */  
-- create table IDENTIFIER(:V_Medsupp_Apps_Demographics_21_and_20)
-- as 
-- select 
-- a.*,
-- b.*
-- from 
-- IDENTIFIER(:V_Medsupp_Apps_Demographics_subset) a 
-- left join IDENTIFIER(:V_bottomsup_campaignref_depotprj) b on  a.projectcode_depot = b.`2020_projectcode`
-- where year(a.appl_receipt_date) = 2020
-- UNION ALL
-- select 
-- a.*,
-- b.*
-- from 
-- IDENTIFIER(:V_Medsupp_Apps_Demographics_subset) a 
-- left join IDENTIFIER(:V_bottomsup_campaignref_depotprj) b on  a.projectcode_depot = b.`2021_projectcode`
-- where year(a.appl_receipt_date) = 2021;	

/*
V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V__Medsupp_Apps_Demographics_21_and_20) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
*/





EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);


RAISE;

END;

';