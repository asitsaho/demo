--call SP_RTO_MODELS_1('1234','RTO_MODELS','UBLIA_TST_ISDC_DEV_DB','UTIL','BDR_FFP_DA','BDR_FFP_DA_WRK','BDR_SMART','BDR_DM','UBLIA_TST_WORK_XS_WH',CURRENT_DATE())

--call SP_BASE_POPULATION('1234','RTO_MODELS','UBLIA_TST_ISDC_DEV_DB','UTIL','BDR_FFP_DA','BDR_FFP_DA_WRK','BDR_SMART','BDR_CONF','UBLIA_TST_WORK_XS_WH',CURRENT_DATE())

--call SP_RTO_MODELS_2('1234','RTO_MODELS','UBLIA_TST_ISDC_DEV_DB','UTIL','BDR_FFP_DA','BDR_FFP_DA_WRK','BDR_SMART','BDR_DM','UBLIA_TST_WORK_XS_WH',CURRENT_DATE())

USE SCHEMA BDR_FFP_DA;

CREATE OR REPLACE PROCEDURE BDR_FFP_DA.SP_RTO_MODELS_2("PIPELINE_ID" VARCHAR(16777216), "PIPELINE_NAME" VARCHAR(16777216), "DB_NAME" VARCHAR(16777216), "UTIL_SC" VARCHAR(16777216), "TGT_SC" VARCHAR(16777216), "FFP_WRK_SC" VARCHAR(16777216), "SRC_SC" VARCHAR(16777216), "ONE_SC" VARCHAR(16777216), "WH" VARCHAR(16777216), "CURR_DATE" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

V_CURRENT_DATE   DATE := COALESCE(TO_DATE(:CURR_DATE), CURRENT_DATE());

V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := :DB_NAME||''.''||COALESCE(:UTIL_SC, ''UTIL'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';

V_PROCESS_NAME   VARCHAR DEFAULT ''RTO MODELS'';

V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''CODE11-CODE16'';

V_STEP             VARCHAR;

V_STEP_NAME        VARCHAR;

V_START_TIME       VARCHAR;

V_END_TIME         VARCHAR;

V_ROWS_PARSED       INTEGER;

V_ROWS_LOADED       INTEGER;

V_MESSAGE          VARCHAR;

V_LAST_QUERY_ID    VARCHAR;





-- Third Part Start

V_FFP_EFT_BASE_POP_SYS VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_BASE_POP_PRIV_SS'';

V_D_EC_PART_B_BL  VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''BDR_DM'') || ''.D_EC_PART_B_BL'';

V_D_EC_PART_B  VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''BDR_DM'') || ''.D_EC_PART_B'';

V_F_CLM_HIST  VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''BDR_DM'') || ''.F_CLM_HIST'';

V_INSURED_PLAN VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.INSURED_PLAN'';

V_CMDB_SMART_PERSON_PROFILE  VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.CMDB_SMART_PERSON_PROFILE'';

V_PERSON_ADDRESS_PROFILE  VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.PERSON_ADDRESS_PROFILE'';

V_ZIP_CODE  VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.ZIP_CODE'';


--Intermediate Tables
V_EFT_PULL_ECC_BILL_LINE VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PULL_ECC_BILL_LINE'';

V_EFT_PULL_ECC_BILL_LINE_V3 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PULL_ECC_BILL_LINE_V3'';

V_EFT_PULL_ECC_CLAIMS_POP_1_SYS VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PULL_ECC_CLAIMS_POP_1_PRIV_SS'';

V_EFT_EFT_ECC_CLMS_BASE_POP VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_ECC_CLMS_BASE_POP'';

V_EFT_EFT_ECC_CLMS_BASE_POP_1_SYS VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_ECC_CLMS_BASE_POP_1_PRIV_SS'';

V_EFT_PULL_CDWCLMS VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PULL_CDWCLMS'';

V_EFT_CDWCLMS_BASE_POP_1_SYS VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_CDWCLMS_BASE_POP_1_PRIV_SS'';

V_EFT_ZIP_CODE_BASE  VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_ZIP_CODE_BASE '';
V_EFT_ZIP_CODE_BASE1_SYS VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_ZIP_CODE_BASE1_PRIV_SS'';



--CODE 14
V_EFT_MR2961_DATA2  VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_MR2961_DATA2 '';
V_EFT_MR2961_DATA_2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_MR2961_DATA_2'';
V_EFT_MR2961_DATA_3 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_MR2961_DATA_3'';
V_EFT_MR2961_DATA_4 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_MR2961_DATA_4'';
V_EFT_MR2961_DATA_5 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_MR2961_DATA_5'';
V_EFT_MR2961_DATA_6_01 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_MR2961_DATA_6_01'';
V_EFT_MR2961_DATA_6_02 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_MR2961_DATA_6_02'';
V_EFT_MR2961_DATA_6_03 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_MR2961_DATA_6_03'';
V_EFT_MR2961_DATA_6_04 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_MR2961_DATA_6_04'';
V_EFT_MR2961_DATA_6_05 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_MR2961_DATA_6_05'';
V_EFT_MR2961_DATA_6 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_MR2961_DATA_6'';
V_EFT_MR2961_DATA_7_01 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_MR2961_DATA_7_01'';
V_EFT_MR2961_DATA_7_02 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_MR2961_DATA_7_02'';
V_EFT_MR2961_DATA_7_03 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_MR2961_DATA_7_03'';
V_EFT_MR2961_DATA_7 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_MR2961_DATA_7'';
V_EFT_MR2961_DATA_8 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_MR2961_DATA_8'';
V_EFT_MR2961_DATA_10 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_MR2961_DATA_10'';
V_EFT_MR2961_DATA_1_ALL VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_MR2961_DATA_1_ALL'';
V_EFT_MR2961_FINAL_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_MR2961_FINAL_1'';
V_EFT_MR2961_FINAL_2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_MR2961_FINAL_2'';
V_EFT_FINAL_MA_DATA VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_FINAL_MA_DATA'';
V_EFT_DURATION_DATA VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_DURATION_DATA'';
V_EFT_DURATION_DATA_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_DURATION_DATA_1'';
V_EFT_FINAL_TENURE VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_FINAL_TENURE'';
V_EFT_PULL_FINAL_TENURE_SYS VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PULL_FINAL_TENURE_PRIV_SS'';

--CODE 15

V_EFT_PDP_FG_BASEPOP VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PDP_FG_BASEPOP'';
V_EFT_PDP_FG_BASEPOP_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PDP_FG_BASEPOP_1'';
V_EFT_PDP_FG_BASEPOP_1_SYS VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PDP_FG_BASEPOP_1_PRIV_SS'';




BEGIN

--/*----------------------F_ECC_BILL_LINE/D_ECC_MED_TOS-------------------------*/

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP1'';

V_STEP_NAME :=  ''create a table EFT_PULL_ECC_BILL_LINE'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EFT_PULL_ECC_BILL_LINE) as
select distinct 
b.PERSON_ID,
B.ACTUAL_DROP_DATE,
SRC_XTRCT_DT_ID,
SRC_XTRCT_DT_ID as Extract_key,
cast(SRC_XTRCT_DT_ID as string) as Extract_key_1, 
substr(cast(SRC_XTRCT_DT_ID as string),7,2) as Extract_key_1_day,
substr(cast(SRC_XTRCT_DT_ID as string),5,2) as Extract_key_1_month,
substr(cast(SRC_XTRCT_DT_ID as string),1,4) as Extract_key_1_year, 
concat(trim(substr(cast(SRC_XTRCT_DT_ID as string),5,2)), trim(substr(cast(SRC_XTRCT_DT_ID as string),7,2)),trim(substr(cast(SRC_XTRCT_DT_ID as string),1,4))) as Extract_key_2,
TRY_TO_DATE(concat(trim(substr(cast(SRC_XTRCT_DT_ID as string),1,4)),''-'',trim(substr(cast(SRC_XTRCT_DT_ID as string),5,2)),''-'',trim(substr(cast(SRC_XTRCT_DT_ID as string),7,2)))) as Extract_key_3,
EC_CLM_NBR,
EC_BL_NBR,
EC_BL_APRV_AMT,
EC_BL_CHRG_AMT,
EC_BL_DED_AMT,
EC_BL_INELG_AMT,
EC_BL_INELG_CD,
EC_BL_PAY_AMT,
EC_BL_PCT_PD,
EC_BL_DT_SRVC_FROM_ID,
EC_BL_DT_SRVC_TO_ID,
(EC_BL_DT_SRVC_TO_ID-EC_BL_DT_SRVC_FROM_ID) AS SERVICE_DAYS,
EC_BL_COINS_AMT,
EC_BL_MEDCR_TOS_CD
from IDENTIFIER(:V_FFP_EFT_BASE_POP_SYS) b 
INNER join IDENTIFIER(:V_D_EC_PART_B_BL) a
--INNER join rrani13.v_d_ec_part_b_BL a
on nvl(trim(a.EC_ACCT_NBR),''999999'')=nvl(trim(b.account_number),''999999'')
where b.actual_drop_date > TRY_TO_DATE(concat(trim(substr(cast(SRC_XTRCT_DT_ID as string),1,4)),''-'',trim(substr(cast(SRC_XTRCT_DT_ID as string),5,2)),''-'',trim(substr(cast(SRC_XTRCT_DT_ID as string),7,2))) ) and b.actual_drop_date < dateadd(''day'',365,TRY_TO_DATE(concat(trim(substr(cast(SRC_XTRCT_DT_ID as string),1,4)),''-'',trim(substr(cast(SRC_XTRCT_DT_ID as string),5,2)),''-'',trim(substr(cast(SRC_XTRCT_DT_ID as string),7,2))) ));



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EFT_PULL_ECC_BILL_LINE)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP2'';

V_STEP_NAME :=  ''create a table EFT_PULL_ECC_BILL_LINE_V3'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EFT_PULL_ECC_BILL_LINE_V3) as
select PERSON_ID,actual_drop_date,EC_CLM_NBR, Extract_key_3, 
sum(EC_BL_PAY_AMT) as ECC_BL_payment_amount,
sum(EC_BL_COINS_AMT) as ECC_coins_amount,
sum(SERVICE_DAYS) as Service_days
from IDENTIFIER(:V_EFT_PULL_ECC_BILL_LINE)
group by PERSON_ID,actual_drop_date,EC_CLM_NBR,Extract_key_3 ;



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EFT_PULL_ECC_BILL_LINE_V3)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP3'';

V_STEP_NAME :=  ''create a table EFT_PULL_ECC_CLAIMS_POP_1_SYS'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EFT_PULL_ECC_CLAIMS_POP_1_SYS) as
select
PERSON_ID, actual_drop_date,
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 90 THEN ECC_BL_payment_amount::number(38,14)  end ) as ECC_BL_payment_amount_3_mnths,
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 180 THEN ECC_BL_payment_amount::number(38,14)  end ) as ECC_BL_payment_amount_6_mnths,
sum(ECC_BL_payment_amount::number(38,14)) as ECC_BL_payment_amount,

avg(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 90 THEN ECC_BL_payment_amount::number(38,14)  end ) as a_ECC_BL_payment_amount_3_mnths,
avg(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 180 THEN ECC_BL_payment_amount::number(38,14)  end ) as a_ECC_BL_payment_amount_6_mnths,
avg(ECC_BL_payment_amount::number(38,14)) as a_ECC_BL_payment_amount,

sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 90 THEN ECC_coins_amount::number(38,14)  end ) as ECC_coins_amount_3_mnths,
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 180 THEN ECC_coins_amount::number(38,14)  end ) as ECC_coins_amount_6_mnths,
sum(ECC_coins_amount::number(38,14)) as ECC_coins_amount,

avg(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 90 THEN ECC_coins_amount::number(38,14)  end ) as a_ECC_coins_amount_3_mnths,
avg(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 180 THEN ECC_coins_amount::number(38,14)  end ) as a_ECC_coins_amount_6_mnths,
avg(ECC_coins_amount::number(38,14)) as a_ECC_coins_amount,


sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 90 THEN Service_days::number(38,14)  end ) as Service_days_3_mnths,
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 180 THEN Service_days::number(38,14)  end ) as Service_days_6_mnths,
sum(Service_days::number(38,14)) as Service_days,

avg(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 90 THEN Service_days::number(38,14)  end ) as a_Service_days_3_mnths,
avg(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 180 THEN Service_days::number(38,14)  end ) as a_Service_days_6_mnths,
avg(Service_days::number(38,14)) as a_Service_days

from IDENTIFIER(:V_EFT_PULL_ECC_BILL_LINE_V3) group by  PERSON_ID, actual_drop_date;



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EFT_PULL_ECC_CLAIMS_POP_1_SYS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--/*----------------------F_ECC_CLAIMS-------------------------*/

V_STEP := ''STEP4'';

V_STEP_NAME :=  ''create a table EFT_EFT_ECC_CLMS_BASE_POP'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EFT_EFT_ECC_CLMS_BASE_POP) as
select distinct b.person_id,
b.actual_drop_date,
b.individual_id,
b.account_number,
SRC_XTRCT_DT_ID, 
SRC_XTRCT_DT_ID as Extract_key,
cast(SRC_XTRCT_DT_ID as string) as Extract_key_1,
substr(cast(SRC_XTRCT_DT_ID as string),7,2) as Extract_key_1_day,
substr(cast(SRC_XTRCT_DT_ID as string),5,2) as Extract_key_1_month,
substr(cast(SRC_XTRCT_DT_ID as string),1,4) as Extract_key_1_year, 
concat(trim(substr(cast(SRC_XTRCT_DT_ID as string),5,2)), trim(substr(cast(SRC_XTRCT_DT_ID as string),7,2)),trim(substr(cast(SRC_XTRCT_DT_ID as string),1,4))) as Extract_key_2,
TRY_TO_DATE(concat(trim(substr(cast(SRC_XTRCT_DT_ID as string),1,4)),''-'',trim(substr(cast(SRC_XTRCT_DT_ID as string),5,2)),''-'',trim(substr(cast(SRC_XTRCT_DT_ID as string),7,2)))) as Extract_key_3 ,

EC_CLM_NBR,
EC_TOT_PAY_AMT,
EC_TOT_APRV_AMT,
EC_TOT_CHRG_AMT,
EC_TOT_DED_AMT,
EC_TOT_INELG_AMT,
EC_SUSP_CD,
EC_DT_PROC_ID

from IDENTIFIER(:V_FFP_EFT_BASE_POP_SYS) b 
inner join IDENTIFIER(:V_D_EC_PART_B)  a 
--inner join rrani13.v_d_ec_part_b a
on nvl(trim(a.EC_ACCT_NBR),''999999'')=nvl(trim(b.account_number),''999999'')
where b.actual_drop_date > TRY_TO_DATE(concat(trim(substr(cast(SRC_XTRCT_DT_ID as string),1,4)),''-'',trim(substr(cast(SRC_XTRCT_DT_ID as string),5,2)),''-'',trim(substr(cast(SRC_XTRCT_DT_ID as string),7,2)))) and b.actual_drop_date < dateadd(''day'',365,TRY_TO_DATE(concat(trim(substr(cast(SRC_XTRCT_DT_ID as string),1,4)),''-'',trim(substr(cast(SRC_XTRCT_DT_ID as string),5,2)),''-'',trim(substr(cast(SRC_XTRCT_DT_ID as string),7,2))) ));




V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EFT_EFT_ECC_CLMS_BASE_POP)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



V_STEP := ''STEP5'';

V_STEP_NAME :=  ''create a table EFT_EFT_ECC_CLMS_BASE_POP_1_SYS'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EFT_EFT_ECC_CLMS_BASE_POP_1_SYS) as
select
INDIVIDUAL_ID, PERSON_ID, actual_drop_date,
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 90 THEN EC_TOT_PAY_AMT::number(38,14)  end ) as ECC_claim_total_amt_pd_3_mnths,
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 180 THEN EC_TOT_PAY_AMT::number(38,14)  end ) as ECC_claim_total_amt_pd_6_mnths,
sum(EC_TOT_PAY_AMT::number(38,14)) as ECC_claim_total_amt_paid,

avg(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 90 THEN EC_TOT_PAY_AMT::number(38,14)  end ) as a_ECC_claim_total_amt_pd_3_mnths,
avg(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 180 THEN EC_TOT_PAY_AMT::number(38,14)  end ) as a_ECC_claim_total_amt_pd_6_mnths,
avg(EC_TOT_PAY_AMT::number(38,14)) as a_ECC_claim_total_amt_paid,

sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 90 THEN EC_TOT_APRV_AMT::number(38,14)  end ) as ECC_claim_total_app_3_mnths,
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 180 THEN EC_TOT_APRV_AMT::number(38,14)  end ) as ECC_claim_total_app_6_mnths,
sum(EC_TOT_APRV_AMT::number(38,14)) as ECC_claim_total_app_amt,

avg(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 90 THEN EC_TOT_APRV_AMT::number(38,14)  end ) as a_ECC_claim_total_app_3_mnths,
AVG(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 180 THEN EC_TOT_APRV_AMT::number(38,14)  end ) as a_ECC_claim_total_app_6_mnths,
avg(EC_TOT_APRV_AMT::number(38,14)) as a_ECC_claim_total_app_amt,

sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 90 THEN EC_TOT_CHRG_AMT::number(38,14)  end ) as ECC_claim_total_charge_3_mnths,
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 180 THEN EC_TOT_CHRG_AMT::number(38,14)  end ) as ECC_claim_total_charge_6_mnths,
sum(EC_TOT_CHRG_AMT::number(38,14)) as ECC_claim_total_charge,

avg(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 90 THEN EC_TOT_CHRG_AMT::number(38,14)  end ) as a_ECC_claim_total_charge_3_mnths,
avg(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 180 THEN EC_TOT_CHRG_AMT::number(38,14)  end ) as a_ECC_claim_total_charge_6_mnths,
avg(EC_TOT_CHRG_AMT::number(38,14)) as a_ECC_claim_total_charge,


sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 90 THEN EC_TOT_DED_AMT::number(38,14)  end ) as ECC_claim_total_deuct_3_mnths,
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 180 THEN EC_TOT_DED_AMT::number(38,14)  end ) as ECC_claim_total_deuct_6_mnths,
sum(EC_TOT_DED_AMT::number(38,14)) as ECC_claim_total_deuct,

avg(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 90 THEN EC_TOT_DED_AMT::number(38,14)  end ) as a_ECC_claim_total_deuct_3_mnths,
avg(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 180 THEN EC_TOT_DED_AMT::number(38,14)  end ) as a_ECC_claim_total_deuct_6_mnths,
avg(EC_TOT_DED_AMT::number(38,14)) as a_ECC_claim_total_deuct,

sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 90 THEN EC_TOT_INELG_AMT::number(38,14)  end ) as ECC_clm_tot_inelig_amt_3_mnths,
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 180 THEN EC_TOT_INELG_AMT::number(38,14)  end ) as ECC_clm_tot_inelig_amt_6_mnths,
sum(EC_TOT_INELG_AMT::number(38,14)) as ECC_clm_tot_inelig_amt,

avg(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 90 THEN EC_TOT_INELG_AMT::number(38,14)  end ) as a_ECC_clm_tot_inelig_amt_3_mnths,
avg(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 180 THEN EC_TOT_INELG_AMT::number(38,14)  end ) as a_ECC_clm_tot_inelig_amt_6_mnths,
avg(EC_TOT_INELG_AMT::number(38,14)) as a_ECC_clm_tot_inelig_amt

from IDENTIFIER(:V_EFT_EFT_ECC_CLMS_BASE_POP) group by INDIVIDUAL_ID, PERSON_ID, actual_drop_date;




V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EFT_EFT_ECC_CLMS_BASE_POP_1_SYS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


--/*----------------------F_OPREC_CLAIMS+d_deceased-------------------------*/

V_STEP := ''STEP6'';

V_STEP_NAME :=  ''create a table EFT_PULL_CDWCLMS'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EFT_PULL_CDWCLMS) as
select distinct c.person_id,
c.actual_drop_date,
c.individual_id,
c.account_number,
a01.CLM_PD_DT_ID,
a01.CLM_PD_DT_ID as Extract_key, 
cast(a01.CLM_PD_DT_ID as string) as Extract_key_1, 
substr(cast(CLM_PD_DT_ID as string),7,2) as Extract_key_1_day,
substr(cast(CLM_PD_DT_ID as string),5,2) as Extract_key_1_month, 
substr(cast(CLM_PD_DT_ID as string),1,4) as Extract_key_1_year, 
concat(trim(substr(cast(CLM_PD_DT_ID as string),5,2)), trim(substr(cast(CLM_PD_DT_ID as string),7,2)),trim(substr(cast(CLM_PD_DT_ID as string),1,4))) as Extract_key_2,
TRY_TO_DATE(concat(trim(substr(cast(CLM_PD_DT_ID as string),1,4)),''-'',trim(substr(cast(CLM_PD_DT_ID as string),5,2)),''-'',trim(substr(cast(CLM_PD_DT_ID as string),7,2))))  as Extract_key_3 ,

a01.SRVC_FROM_DT_ID,
a01.SRVC_FROM_DT_ID as service_from_date,
cast(a01.SRVC_FROM_DT_ID as string) as service_from_date_1,
substr(cast(SRVC_FROM_DT_ID as string),7,2) as service_from_date_1_day,
case
when SRVC_FROM_DT_ID=-1 then null 
else substr(cast(SRVC_FROM_DT_ID as string),5,2) end as service_from_date_1_month, 
case when SRVC_FROM_DT_ID=-1 then null 
else substr(cast(SRVC_FROM_DT_ID as string),1,4) end as service_from_date_1_year, 
concat(trim(substr(cast(SRVC_FROM_DT_ID as string),5,2)), trim(substr(cast(SRVC_FROM_DT_ID as string),7,2)),trim(substr(cast(SRVC_FROM_DT_ID as string),1,4))) as service_from_date_2,
case when SRVC_FROM_DT_ID=-1 then null else 
TRY_TO_DATE(concat(trim(substr(cast(SRVC_FROM_DT_ID as string),1,4)),''-'',trim(substr(cast(SRVC_FROM_DT_ID as string),5,2)),''-'',trim(substr(cast(SRVC_FROM_DT_ID as string),7,2))) ) end as service_from_date_3,
a01.CLM_NBR,
a01.TOT_BEN_AMT
from IDENTIFIER(:V_FFP_EFT_BASE_POP_SYS) c 
inner join IDENTIFIER(:V_F_CLM_HIST) a01
--inner join rrani13.v_f_clm_hist a01
on nvl(trim(a01.ACCT_NBR),''999999'')=nvl(trim(c.account_number),''999999'')
where c.actual_drop_date > TRY_TO_DATE(concat(trim(substr(cast(CLM_PD_DT_ID as string),1,4)),''-'',trim(substr(cast(CLM_PD_DT_ID as string),5,2)),''-'',trim(substr(cast(CLM_PD_DT_ID as string),7,2))) ) and c.actual_drop_date < dateadd(''day'',365,TRY_TO_DATE(concat(trim(substr(cast(CLM_PD_DT_ID as string),1,4)),''-'',trim(substr(cast(CLM_PD_DT_ID as string),5,2)),''-'',trim(substr(cast(CLM_PD_DT_ID as string),7,2)))));



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EFT_PULL_CDWCLMS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP7'';

V_STEP_NAME :=  ''create a table EFT_CDWCLMS_BASE_POP_1_SYS'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EFT_CDWCLMS_BASE_POP_1_SYS) as
select
INDIVIDUAL_ID, PERSON_ID, actual_drop_date,
sum(case 
when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 90 and service_from_date_3=to_date(''9999-12-31'') THEN abs(UTIL.DATE_DIFF_UDF(service_from_date_3,Extract_key_3)::number(38,14))-2  
when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 90 THEN abs(UTIL.DATE_DIFF_UDF(service_from_date_3,Extract_key_3)::number(38,14))  
end ) as tot_proc_days_3_mnths,
sum(case 
when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 180 and service_from_date_3=to_date(''9999-12-31'') THEN abs(UTIL.DATE_DIFF_UDF(service_from_date_3,Extract_key_3)::number(38,14))-2
when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 180 THEN abs(UTIL.DATE_DIFF_UDF(service_from_date_3,Extract_key_3)::number(38,14))  end ) as tot_proc_days_6_mnths,
sum(case 
when service_from_date_3=to_date(''9999-12-31'') then abs(UTIL.DATE_DIFF_UDF(service_from_date_3,Extract_key_3)::number(38,14))-2
else abs(UTIL.DATE_DIFF_UDF(service_from_date_3,Extract_key_3)::number(38,14)) end
) as tot_proc_days,
avg(case 
when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 90 and service_from_date_3=to_date(''9999-12-31'') THEN abs(UTIL.DATE_DIFF_UDF(service_from_date_3,Extract_key_3)::number(38,14))-2 
when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 90 THEN abs(UTIL.DATE_DIFF_UDF(service_from_date_3,Extract_key_3)::number(38,14)) 
end ) as avg_proc_days_3_mnths,
avg(case 
when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 180 and service_from_date_3=to_date(''9999-12-31'') THEN abs(UTIL.DATE_DIFF_UDF(service_from_date_3,Extract_key_3)::number(38,14))-2
when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 180 THEN abs(UTIL.DATE_DIFF_UDF(service_from_date_3,Extract_key_3)::number(38,14))  end ) as avg_proc_days_6_mnths,
avg(
case when service_from_date_3=to_date(''9999-12-31'') then abs(UTIL.DATE_DIFF_UDF(service_from_date_3,Extract_key_3)::number(38,14))-2
else abs(UTIL.DATE_DIFF_UDF(service_from_date_3,Extract_key_3)::number(38,14)) end) as avg_proc_days,
max(case 
when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 90 and service_from_date_3=to_date(''9999-12-31'') THEN abs(UTIL.DATE_DIFF_UDF(service_from_date_3,Extract_key_3)::number(38,14))-2
when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 90 THEN abs(UTIL.DATE_DIFF_UDF(service_from_date_3,Extract_key_3)::number(38,14))  end ) as max_proc_days_3_mnths,
max(case 
when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 180 and service_from_date_3=to_date(''9999-12-31'') THEN abs(UTIL.DATE_DIFF_UDF(service_from_date_3,Extract_key_3)::number(38,14))-2
when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 180 THEN abs(UTIL.DATE_DIFF_UDF(service_from_date_3,Extract_key_3)::number(38,14))  end ) as max_proc_days_6_mnths,
max(
case 
when service_from_date_3=to_date(''9999-12-31'') then abs(UTIL.DATE_DIFF_UDF(service_from_date_3,Extract_key_3)::number(38,14))-2
else abs(UTIL.DATE_DIFF_UDF(service_from_date_3,Extract_key_3)::number(38,14)) end) as max_proc_days,
min(case 
when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 90 and service_from_date_3=to_date(''9999-12-31'') THEN abs(UTIL.DATE_DIFF_UDF(service_from_date_3,Extract_key_3))-2 
when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 90 THEN abs(UTIL.DATE_DIFF_UDF(service_from_date_3,Extract_key_3))  end ) as min_proc_days_3_mnths,
min(case 
when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 180 and service_from_date_3=to_date(''9999-12-31'') THEN abs(UTIL.DATE_DIFF_UDF(service_from_date_3,Extract_key_3))-2
when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 180 THEN abs(UTIL.DATE_DIFF_UDF(service_from_date_3,Extract_key_3))  end ) as min_proc_days_6_mnths,
min(
case when service_from_date_3=to_date(''9999-12-31'') then abs(UTIL.DATE_DIFF_UDF(service_from_date_3,Extract_key_3)::number(38,14))-2
else abs(UTIL.DATE_DIFF_UDF(service_from_date_3,Extract_key_3)::number(38,14)) end) as min_proc_days,
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 90 THEN TOT_BEN_AMT  end ) as tot_benefit_amt_3_mnths,
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 180 THEN TOT_BEN_AMT  end ) as tot_benefit_amt_6_mnths,
sum(TOT_BEN_AMT::number(38,14)) as tot_benefit_amt
from IDENTIFIER(:V_EFT_PULL_CDWCLMS) group by INDIVIDUAL_ID, PERSON_ID, actual_drop_date;



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EFT_CDWCLMS_BASE_POP_1_SYS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


--/*--------------------------CODE-14--------------------*/
V_STEP := ''STEP8'';

V_STEP_NAME :=  ''create a table EFT_MR2961_DATA2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EFT_MR2961_DATA2) as
select distinct a.person_id,
a.insured_plan_id,
a.application_id,                
a.specification_id,             
a.effective_date,                
a.termination_date,              
a.plan_termination_reason_code,  
a.conservation_reason_code,     
a.last_termination_date,        
a.individual_premium_amount,   
a.employer_premium_amount, 
a.payment_received_date, 
a.termination_processed_date, 
a.source_insured_plan_id , 
a.language_preference_id , 
a.agent_id ,
a.zip_code,
a.zip_code_plus_4 , 
a.ins_plan_switcher_ind  ,
a.row_ins_timestamp ,  
a.row_updt_timestamp,a.effective_date as plan_effective_date, a.termination_date as plan_termination_date,b.actual_drop_date
from IDENTIFIER(:V_INSURED_PLAN) a
INNER join IDENTIFIER(:V_FFP_EFT_BASE_POP_SYS) b
on a.person_id=b.person_id
order by person_id ,actual_drop_date, plan_effective_date, plan_Termination_date;



--/*In case of multiple disenrollment date per Membership effective date - keep last disenrollment date*/
create or replace table IDENTIFIER(:V_EFT_MR2961_DATA_2) as
SELECT * EXCLUDE ROW_NUM FROM (
select * 
from
(select *,ROW_NUMBER() OVER (PARTITION BY person_id,plan_effective_date order by actual_drop_date desc , plan_effective_date desc ,plan_Termination_date desc NULLS LAST, insured_plan_id desc , application_id desc , specification_id desc ) AS ROW_NUM from IDENTIFIER(:V_EFT_MR2961_DATA2)) as a where a.row_num=1
);


--/*In case of multiple null disenrollment date per medicare - keep record with last Membership effective date*/

create or replace table IDENTIFIER(:V_EFT_MR2961_DATA_3) as
select * from IDENTIFIER(:V_EFT_MR2961_DATA_2) where plan_Termination_date is null
order by person_id, actual_drop_date, plan_effective_date;

create or replace table IDENTIFIER(:V_EFT_MR2961_DATA_4) as  
select * from IDENTIFIER(:V_EFT_MR2961_DATA_2) where plan_Termination_date is not null ;

create or replace table IDENTIFIER(:V_EFT_MR2961_DATA_5) as 
SELECT * EXCLUDE ROW_NUM FROM (
select *
from
(select *,ROW_NUMBER() OVER (PARTITION BY PERSON_ID order by PERSON_ID, actual_drop_date desc , plan_effective_date desc ) AS ROW_NUM from IDENTIFIER(:V_EFT_MR2961_DATA_3)) as a where a.row_num=1
);


create or replace table IDENTIFIER(:V_EFT_MR2961_DATA_6_01)  as
select a.* from (
select * from IDENTIFIER(:V_EFT_MR2961_DATA_4)
union 
select * from IDENTIFIER(:V_EFT_MR2961_DATA_5)) a
order by person_id, actual_drop_date, plan_effective_date,
plan_Termination_date;


--/*In case of multiple Membership effective date per disenrollment date per medicare - keep record with first Membership effective date*/

create or replace table IDENTIFIER(:V_EFT_MR2961_DATA_6_02) as 
SELECT * EXCLUDE ROW_NUM FROM (
select *
from
(select *,ROW_NUMBER() OVER (PARTITION BY PERSON_ID,actual_drop_date, plan_effective_date, plan_Termination_date 
order by person_id ,actual_drop_date, plan_effective_date ,plan_Termination_date) AS ROW_NUM from IDENTIFIER(:V_EFT_MR2961_DATA_6_01)) as a where a.row_num=1
order by person_id ,actual_drop_date, plan_effective_date ,plan_Termination_date
);


create or replace table IDENTIFIER(:V_EFT_MR2961_DATA_6_03) as 
SELECT * EXCLUDE ROW_NUM FROM (
select *
from
(select *,ROW_NUMBER() OVER (PARTITION BY PERSON_ID , plan_effective_date order by person_id, actual_drop_date, plan_effective_date ,plan_Termination_date ) AS ROW_NUM from IDENTIFIER(:V_EFT_MR2961_DATA_6_02) ) as a where a.row_num=1
);

create or replace table IDENTIFIER(:V_EFT_MR2961_DATA_6_04) as 
SELECT * EXCLUDE ROW_NUM FROM (
select *
from
(select *,ROW_NUMBER() OVER (PARTITION BY person_id, actual_drop_date, plan_effective_date, plan_Termination_date 
order by person_id, actual_drop_date, plan_effective_date, plan_Termination_date) AS ROW_NUM from IDENTIFIER(:V_EFT_MR2961_DATA_6_03)) as a where a.row_num=1
order by person_id, actual_drop_date, plan_effective_date, plan_Termination_date
);

--/*to be updated*/

create or replace table IDENTIFIER(:V_EFT_MR2961_DATA_6_05) as 
select 
person_id, 
insured_plan_id,  
application_id,  
specification_id,  
effective_date, 
termination_date ,
plan_termination_reason_code,  
conservation_reason_code, 
last_termination_date,   
individual_premium_amount ,  
employer_premium_amount,      
payment_received_date ,       
termination_processed_date ,  
source_insured_plan_id,       
language_preference_id  ,     
agent_id,                  
zip_code,                     
zip_code_plus_4,          
ins_plan_switcher_ind,    
row_ins_timestamp,   
row_updt_timestamp,  
plan_effective_date, 
case when (plan_termination_date is null or plan_termination_date > actual_drop_date) then actual_drop_date
else plan_termination_date
end as  plan_termination_date,  
actual_drop_date 
from IDENTIFIER(:V_EFT_MR2961_DATA_6_04);

create or replace table IDENTIFIER(:V_EFT_MR2961_DATA_6) as 
select * , dateadd(''day'',30,plan_Termination_date) as plan_Termination_date_2 from IDENTIFIER(:V_EFT_MR2961_DATA_6_05);

create or replace table IDENTIFIER(:V_EFT_MR2961_DATA_7_01) as 
select distinct a.person_id,
a.insured_plan_id, 
a.application_id,
a.specification_id  ,
a.effective_date ,
a.termination_date,
a.plan_termination_reason_code,
a.conservation_reason_code ,
a.last_termination_date,
a.individual_premium_amount,
a.employer_premium_amount ,
a.payment_received_date  ,
a.termination_processed_date,
a.source_insured_plan_id ,
a.language_preference_id ,
a.agent_id ,
a.zip_code ,
a.zip_code_plus_4,
a.ins_plan_switcher_ind ,
a.row_ins_timestamp ,
a.row_updt_timestamp ,
a.plan_effective_date ,
a.plan_termination_date ,
a.actual_drop_date,
a.plan_termination_date_2, 
b.plan_Termination_date_2 as check_dt
from IDENTIFIER(:V_EFT_MR2961_DATA_6) a left join IDENTIFIER(:V_EFT_MR2961_DATA_6) b
on a.person_id = b.person_id AND a.actual_drop_date = b.actual_drop_date
and a.plan_effective_date between b.plan_Termination_date and b.plan_Termination_date_2
order by person_id ,actual_drop_date , plan_effective_date;


create or replace table IDENTIFIER(:V_EFT_MR2961_DATA_7_02) as 
SELECT * EXCLUDE ROW_NUM FROM (
select *, case when ROW_NUM=1 then 1 else 0 end as flag1
from
(select *,ROW_NUMBER() OVER (PARTITION BY PERSON_ID order by person_id, actual_drop_date, plan_effective_date ) AS ROW_NUM from IDENTIFIER(:V_EFT_MR2961_DATA_7_01)) as a 
order by person_id, actual_drop_date, plan_effective_date, plan_Termination_date);


create or replace table IDENTIFIER(:V_EFT_MR2961_DATA_7_03) as 
select * , 
case when (check_dt is not null) then 1 else 0 end as flag2
from IDENTIFIER(:V_EFT_MR2961_DATA_7_02);


create or replace  table IDENTIFIER(:V_EFT_MR2961_DATA_7)  as
select * , 
case when (flag1=1 or flag2=1) then 1 else 0 end as flag
from IDENTIFIER(:V_EFT_MR2961_DATA_7_03) order by  person_id, actual_drop_date, plan_effective_date;


create or replace table IDENTIFIER(:V_EFT_MR2961_DATA_8)  as 
select * , ROW_NUMBER() over(order by person_id, actual_drop_date, plan_effective_date) as sn from IDENTIFIER(:V_EFT_MR2961_DATA_7);


create or replace table IDENTIFIER(:V_EFT_MR2961_DATA_10) as
select  person_id , actual_drop_date, sum(flag) as flag , max(sn) as sn 
from IDENTIFIER(:V_EFT_MR2961_DATA_8)
where flag = 0   --*EITHER IT IS NOT THE FIRST RECORD OR THE PLAN HAS BEEN TERMINATED*/
group by person_id ,actual_drop_date  ;

create or replace table IDENTIFIER(:V_EFT_MR2961_DATA_1_ALL) as
select person_id , actual_drop_date, sum(flag) as flg_sum , count(*) as nrec 
from IDENTIFIER(:V_EFT_MR2961_DATA_8)
group by person_id, actual_drop_date ;

create or replace table IDENTIFIER(:V_EFT_MR2961_FINAL_1) as
select distinct a.* 
from IDENTIFIER(:V_EFT_MR2961_DATA_8) a inner join IDENTIFIER(:V_EFT_MR2961_DATA_1_ALL) b
on a.person_id = b.person_id and a.actual_drop_date = b.actual_drop_date
where b.flg_sum = b.nrec ;


create or replace table IDENTIFIER(:V_EFT_MR2961_FINAL_2) as
select distinct a.* 
from IDENTIFIER(:V_EFT_MR2961_DATA_8) a inner join IDENTIFIER(:V_EFT_MR2961_DATA_10) b
on a.person_id = b.person_id and a.actual_drop_date = b.actual_drop_date
and a.sn >= b.sn;


create or replace table IDENTIFIER(:V_EFT_FINAL_MA_DATA) as 
select * from IDENTIFIER(:V_EFT_MR2961_FINAL_1)
union 
select * from IDENTIFIER(:V_EFT_MR2961_FINAL_2);


create or replace table IDENTIFIER(:V_EFT_DURATION_DATA) as 
select *, 
UTIL.DATE_DIFF_UDF(plan_Termination_date,plan_effective_date) as dur
from IDENTIFIER(:V_EFT_FINAL_MA_DATA)
order by person_id, actual_drop_date;

create or replace table IDENTIFIER(:V_EFT_DURATION_DATA_1) as
select * ,
case when dur <= 0 then 0 
else dur end as dur1
from  IDENTIFIER(:V_EFT_DURATION_DATA); 


create or replace table IDENTIFIER(:V_EFT_FINAL_TENURE) as
select person_id,actual_drop_date, sum(dur1) as tenure
from IDENTIFIER(:V_EFT_DURATION_DATA_1)
group by person_id,actual_drop_date;

--/*main table to be merged later*/


create or replace table IDENTIFIER(:V_EFT_PULL_FINAL_TENURE_SYS) as
select * from IDENTIFIER(:V_EFT_FINAL_TENURE);



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EFT_PULL_FINAL_TENURE_SYS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--CODE 15

V_STEP := ''STEP9'';

V_STEP_NAME :=  ''create a table EFT_PDP_FG_BASEPOP'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EFT_PDP_FG_BASEPOP) as
select distinct a.person_id, a.individual_id,a.actual_drop_date, 
b. cmdb_person_id                ,
b. smart_person_id               ,
b. cmdb_age_yyymm                ,
b. smart_age_yyymm               ,
b. cmdb_date_of_birth            ,
b. smart_date_of_birth           ,
b. smart_deceased_ind            ,
b. cmdb_deceased_ind             ,
b. hco_account_number            ,
b. aarp_account_number           ,
b. aarp_member_code              ,
b. aarp_original_effective_date  ,
b. aarp_member_dns_ind           ,
b. aarp_non_member_dns_ind       ,
b. smart_internal_dns_ind        ,
b. cmdb_ok_to_mail               ,
b. cmdb_ok_to_call               ,
b. cmdb_ok_to_email              ,
b. cmdb_member_ok_to_mail        ,
b. cmdb_member_ok_to_call        ,
b. cmdb_on_fed_dont_call         ,
b. sh_insured_status_code        ,
b. sh_effective_date             ,
b. sh_termination_date           ,
b. sh_termination_reason         ,
b. pdp_insured_status_code       ,
b. pdp_effective_date            ,
b. pdp_termination_date          ,
b. pdp_termination_reason        ,
b. evc_insured_status_code       ,
b. evc_effective_date            ,
b. evc_termination_date          ,
b. evc_termination_reason        ,
b. amc_insured_status_code       ,
b. amc_effective_date            ,
b. amc_termination_date          ,
b. amc_termination_reason        ,
b. ehi_active_plan_code          ,
b. ehi_active_plan_duration      ,
b. ehi_active_plan_eff_date      ,
b. ehi_active_prod_duration      ,
b. ehi_last_eff_date             ,
b. ehi_last_plan_code            ,
b. ehi_last_term_cons_reason     ,
b. ehi_last_term_date            ,
b. ehi_last_term_plan_reason     ,
b. ehi_last_term_proc_date       ,
b. ehi_num_lapses                ,
b. ehi_num_plan_changes          ,
b. hap_active_plan_code          ,
b. hap_active_plan_duration      ,
b. hap_active_plan_eff_date      ,
b. hap_active_prod_duration      ,
b. hap_last_eff_date             ,
b. hap_last_plan_code            ,
b. hap_last_term_cons_reason     ,
b. hap_last_term_date            ,
b. hap_last_term_plan_reason     ,
b. hap_last_term_proc_date       ,
b. hap_num_lapses                ,
b. hap_num_plan_changes          ,
b. hip_active_plan_code          ,
b. hip_active_plan_duration      ,
b. hip_active_plan_eff_date      ,
b. hip_active_prod_duration      ,
b. hip_last_eff_date             ,
b. hip_last_plan_code            ,
b. hip_last_term_cons_reason     ,
b. hip_last_term_date            ,
b. hip_last_term_plan_reason     ,
b. hip_last_term_proc_date       ,
b. hip_num_lapses                ,
b. hip_num_plan_changes          ,
b. hip_inquiry_date              ,
b. hip_age_as_of_inquiry_date    ,
b. map_active_plan_code          ,
b. map_active_plan_duration      ,
b. map_active_plan_eff_date      ,
b. map_active_prod_duration      ,
b. map_last_eff_date             ,
b. map_last_plan_code            ,
b. map_last_term_cons_reason     ,
b. map_last_term_date            ,
b. map_last_term_plan_reason     ,
b. map_last_term_proc_date       ,
b. map_num_lapses                ,
b. map_num_plan_changes          ,
b. map_rate_determination_code   ,
b. msup_active_plan_code         ,
b. msup_active_plan_duration     ,
b. msup_active_plan_eff_date     ,
b. msup_active_prod_duration     ,
b. msup_last_eff_date            ,
b. msup_last_plan_code           ,
b. msup_last_term_cons_reason    ,
b. msup_last_term_date           ,
b. msup_last_term_plan_reason    ,
b. msup_last_term_proc_date      ,
b. msup_num_lapses               ,
b. msup_num_plan_changes         ,
b. msup_agent_purchased          ,
b. msup_rate_determination_code  ,
b. msup_inquiry_date             ,
b. msup_age_as_of_inquiry_date   ,
b. phip_active_plan_code         ,
b. phip_active_plan_duration     ,
b. phip_active_plan_eff_date     ,
b. phip_active_prod_duration     ,
b. phip_last_eff_date            ,
b. phip_last_plan_code           ,
b. phip_last_term_cons_reason    ,
b. phip_last_term_date           ,
b. phip_last_term_plan_reason    ,
b. phip_last_term_proc_date      ,
b. phip_num_lapses               ,
b. phip_num_plan_changes         ,
b. smp_active_plan_code          ,
b. smp_active_plan_duration      ,
b. smp_active_plan_eff_date      ,
b. smp_active_prod_duration      ,
b. smp_last_eff_date             ,
b. smp_last_plan_code            ,
b. smp_last_term_cons_reason     ,
b. smp_last_term_date            ,
b. smp_last_term_plan_reason     ,
b. smp_last_term_proc_date       ,
b. smp_num_lapses                ,
b. smp_num_plan_changes          ,
b. row_ins_date      
 from 
IDENTIFIER(:V_FFP_EFT_BASE_POP_SYS) a inner join IDENTIFIER(:V_CMDB_SMART_PERSON_PROFILE) b on 
a.person_id = b.smart_person_id 
where (a.actual_drop_date > b.pdp_effective_date) and (a.actual_drop_date < b.pdp_termination_date OR b.pdp_termination_date is null or pdp_termination_date is null) and  b.pdp_effective_date is not null ;


create or replace table IDENTIFIER(:V_EFT_PDP_FG_BASEPOP_1) as 
select * from IDENTIFIER(:V_EFT_PDP_FG_BASEPOP) order by 
person_id , actual_drop_date, pdp_effective_date;

create or replace table IDENTIFIER(:V_EFT_PDP_FG_BASEPOP_1_SYS) as 
select * EXCLUDE ROW_NUM FROM (
select *
from
(select *,ROW_NUMBER() OVER (PARTITION BY PERSON_ID order by actual_drop_date desc , pdp_effective_date desc ,pdp_termination_date desc, cmdb_person_id desc) AS ROW_NUM from IDENTIFIER(:V_EFT_PDP_FG_BASEPOP_1)) as a where a.ROW_NUM=1);



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EFT_PDP_FG_BASEPOP_1_SYS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


--Code 16
--/*Network Hospital Distance*/
create or replace table IDENTIFIER(:V_EFT_ZIP_CODE_BASE) as  
select distinct a.person_id,a.individual_id,a.actual_drop_date,b.zip_code
from
IDENTIFIER(:V_FFP_EFT_BASE_POP_SYS) a inner join
IDENTIFIER(:V_PERSON_ADDRESS_PROFILE) b
on a.person_id=b.person_id
where (case when b.end_date is not null THEN (a.actual_drop_date > b.begin_date and 
a.actual_drop_date < b.end_date) else (a.actual_drop_date > b.begin_date) end);


create or replace table IDENTIFIER(:V_EFT_ZIP_CODE_BASE1_SYS) as
select distinct a.person_id, a.individual_id,a.actual_drop_date,a.zip_code,b.network_hosp_dist
from IDENTIFIER(:V_EFT_ZIP_CODE_BASE) a
left join IDENTIFIER(:V_ZIP_CODE) b
on a.zip_code=b.zip_code;



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EFT_ZIP_CODE_BASE1_SYS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);


RAISE;

END;

';