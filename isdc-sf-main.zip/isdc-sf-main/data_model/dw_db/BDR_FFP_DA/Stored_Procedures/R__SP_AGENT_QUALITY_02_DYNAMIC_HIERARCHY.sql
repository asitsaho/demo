USE SCHEMA BDR_FFP_DA;


CREATE OR REPLACE PROCEDURE BDR_FFP_DA.SP_AGENT_QUALITY_02_DYNAMIC_HIERARCHY("PIPELINE_ID" VARCHAR(16777216), "PIPELINE_NAME" VARCHAR(16777216), "DB_NAME" VARCHAR(16777216), "UTIL_SC" VARCHAR(16777216), "TGT_SC" VARCHAR(16777216), "INTRM_SC" VARCHAR(16777216), "ONE_SC" VARCHAR(16777216), "WH" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := :DB_NAME||''.''||COALESCE(:UTIL_SC, ''UTIL'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';

V_PROCESS_NAME   VARCHAR DEFAULT ''PROCESS_NAME'';

V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''01_TNA_RDC'';

V_STEP             VARCHAR;

V_STEP_NAME        VARCHAR;

V_START_TIME       VARCHAR;

V_END_TIME         VARCHAR;

V_ROWS_PARSED       INTEGER;

V_ROWS_LOADED       INTEGER;

V_MESSAGE          VARCHAR;

V_LAST_QUERY_ID    VARCHAR;



V_AGENT_QUALITY_ICM_CURRENT VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_ICM_CURRENT'';

V_SRC_ICM_COMMISSIONS_TRANSACTIONS_PAID_VW VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''SRC_ICM'') || ''.SRC_ICM_COMMISSIONS_TRANSACTIONS_PAID_VW'';

V_SRC_ICM_COMMISSIONS_TRANSACTIONS_PAID_ARCHIVE_VW VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''SRC_ICM'') || ''.SRC_ICM_COMMISSIONS_TRANSACTIONS_PAID_ARCHIVE_VW'';

V_SCR_COMMISSION_PAID_DCM VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''SRC_ICM'') || ''.SCR_COMMISSION_PAID_DCM'';

V_AGENT_QUALITY_ICM_ARCHIVE VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_ICM_ARCHIVE'';

V_AGENT_QUALITY_HIERARACHY_0  VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_HIERARACHY_0'';

V_AGENT_QUALITY_HIERARACHY_1  VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_HIERARACHY_1'';

V_AGENT_QUALITY_HIERARACHY_2_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_HIERARACHY_2_1'';

V_AGENT_QUALITY_HIERARACHY_2_1_FINAL VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_HIERARACHY_2_1_FINAL'';

V_AGENT_QUALITY_HIERARACHY_2_2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_HIERARACHY_2_2'';

V_AGENT_QUALITY_HIERARACHY_2_4 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_HIERARACHY_2_4'';

V_AGENT_QUALITY_HIERARACHY_2_2_FINAL VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_HIERARACHY_2_2_FINAL'';

V_AGENT_QUALITY_HIERARACHY_4_0 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_HIERARACHY_4_0'';

V_AGENT_QUALITY_HIERARACHY_4_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_HIERARACHY_4_1'';

V_AGENT_QUALITY_HIERARACHY_5_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_HIERARACHY_5_1'';

V_AGENT_QUALITY_HIERARACHY_5_2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_HIERARACHY_5_2'';

V_AGENT_QUALITY_HIERARACHY_6 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_HIERARACHY_6'';

V_AGENT_QUALITY_HIERARACHY_6_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_HIERARACHY_6_1'';

V_AGENT_QUALITY_HIERARACHY_6_1_FINAL VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_HIERARACHY_6_1_FINAL'';

V_AGENT_QUALITY_HIERARACHY_6_2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_HIERARACHY_6_2'';

V_AGENT_QUALITY_HIERARACHY_6_3 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_HIERARACHY_6_3'';

V_AGENT_QUALITY_HIERARACHY_6_4 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_HIERARACHY_6_4'';

V_AGENT_QUALITY_HIERARACHY_9_0 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_HIERARACHY_9_0'';

V_AGENT_QUALITY_HIERARACHY_9_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_HIERARACHY_9_1'';

V_AGENT_QUALITY_HIERARACHY_10 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_HIERARACHY_10'';

V_AGENT_QUALITY_HIERARACHY_11 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_HIERARACHY_11'';

V_AGENT_QUALITY_HIERARACHY_12 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_HIERARACHY_12'';

V_AGENT_QUALITY_HIERARACHY_13 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_HIERARACHY_13'';




BEGIN


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP1'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_ICM_CURRENT'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_AGENT_QUALITY_ICM_CURRENT) COPY GRANTS AS 
select policy_number,
effective_date,
ledger_item_date,
app_sign_date,
allocation_agent_id,
ledger_item_agent_level, 
(case when ledger_item_agent_level in (70,80) then ledger_item_agent_id end) as NMA_agent_id,
(case when ledger_item_agent_level in (70,80) then payment_party_id end) as NMA_party_id,
(case when ledger_item_agent_level = 60 then ledger_item_agent_id end) as SMO_agent_id,
(case when ledger_item_agent_level = 60 then payment_party_id end) as SMO_party_id,
(case when ledger_item_agent_level = 50 then ledger_item_agent_id end) as FMO_agent_id,
(case when ledger_item_agent_level = 50 then payment_party_id end) as FMO_party_id,
(case when ledger_item_agent_level = 40 then ledger_item_agent_id end) as MGA_agent_id,
(case when ledger_item_agent_level = 40 then payment_party_id end) as MGA_party_id,
(case when ledger_item_agent_level = 30 then ledger_item_agent_id end) as GA_agent_id,
(case when ledger_item_agent_level = 30 then payment_party_id end) as GA_party_id,
(case when ledger_item_agent_level = 20 then ledger_item_agent_id end) as agent_ica_agent_id,
(case when ledger_item_agent_level = 20 then payment_party_id end) as agent_ica_party_id,
(case when ledger_item_agent_level = 1 then ledger_item_agent_id end) as solicitor_agent_id,
(case when ledger_item_agent_level = 1 then payment_party_id end) as solicitor_party_id,
writing_agent_id as writing_agent_id,
(case when agent_level = 1 then ''solicitor''
when agent_level = 20 then ''agent/ICA''
when agent_level = 30 then ''GA''
when agent_level = 40 then ''MGA''
when agent_level = 50 then ''FMO/SGA''
when agent_level = 60 then ''SMO''
when agent_level in (70,80) then ''NMA'' else ''check'' end) as agent_level_name,
(case when writing_agent_id = ledger_item_agent_id then 1 else 0 end) as hierarachy_flag, 
''icm2'' as tbl,
sum(credit) as s
from IDENTIFIER(:V_SRC_ICM_COMMISSIONS_TRANSACTIONS_PAID_VW)
where product_category = ''MS'' 
group by policy_number,
effective_date,
ledger_item_date,
app_sign_date,
allocation_agent_id,
ledger_item_agent_level,
(case when ledger_item_agent_level in (70,80) then ledger_item_agent_id end),
(case when ledger_item_agent_level in (70,80) then payment_party_id end),
(case when ledger_item_agent_level = 60 then ledger_item_agent_id end),
(case when ledger_item_agent_level = 60 then payment_party_id end),
(case when ledger_item_agent_level = 50 then ledger_item_agent_id end),
(case when ledger_item_agent_level = 50 then payment_party_id end),
(case when ledger_item_agent_level = 40 then ledger_item_agent_id end),
(case when ledger_item_agent_level = 40 then payment_party_id end),
(case when ledger_item_agent_level = 30 then ledger_item_agent_id end),
(case when ledger_item_agent_level = 30 then payment_party_id end),
(case when ledger_item_agent_level = 20 then ledger_item_agent_id end),
(case when ledger_item_agent_level = 20 then payment_party_id end),
(case when ledger_item_agent_level = 1 then ledger_item_agent_id end),
(case when ledger_item_agent_level = 1 then payment_party_id end),
writing_agent_id,
(case when agent_level = 1 then ''solicitor''
when agent_level = 20 then ''agent/ICA''
when agent_level = 30 then ''GA''
when agent_level = 40 then ''MGA''
when agent_level = 50 then ''FMO/SGA''
when agent_level = 60 then ''SMO''
when agent_level in (70,80) then ''NMA'' else ''check'' end),
(case when writing_agent_id = ledger_item_agent_id then 1 else 0 end),''icm2'';


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_ICM_CURRENT)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP2'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_ICM_ARCHIVE'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_AGENT_QUALITY_ICM_ARCHIVE) COPY GRANTS AS 
select policy_number,
effective_date,
ledger_item_date,
app_sign_date,
allocation_agent_id,
ledger_item_agent_level, 
(case when ledger_item_agent_level in (70,80) then ledger_item_agent_id end) as NMA_agent_id,
(case when ledger_item_agent_level in (70,80) then payment_party_id end) as NMA_party_id,
(case when ledger_item_agent_level = 60 then ledger_item_agent_id end) as SMO_agent_id,
(case when ledger_item_agent_level = 60 then payment_party_id end) as SMO_party_id,
(case when ledger_item_agent_level = 50 then ledger_item_agent_id end) as FMO_agent_id,
(case when ledger_item_agent_level = 50 then payment_party_id end) as FMO_party_id,
(case when ledger_item_agent_level = 40 then ledger_item_agent_id end) as MGA_agent_id,
(case when ledger_item_agent_level = 40 then payment_party_id end) as MGA_party_id,
(case when ledger_item_agent_level = 30 then ledger_item_agent_id end) as GA_agent_id,
(case when ledger_item_agent_level = 30 then payment_party_id end) as GA_party_id,
(case when ledger_item_agent_level = 20 then ledger_item_agent_id end) as agent_ica_agent_id,
(case when ledger_item_agent_level = 20 then payment_party_id end) as agent_ica_party_id,
(case when ledger_item_agent_level = 1 then ledger_item_agent_id end) as solicitor_agent_id,
(case when ledger_item_agent_level = 1 then payment_party_id end) as solicitor_party_id,
writing_agent_id as writing_agent_id,
(case when agent_level = 1 then ''solicitor''
when agent_level = 20 then ''agent/ICA''
when agent_level = 30 then ''GA''
when agent_level = 40 then ''MGA''
when agent_level = 50 then ''FMO/SGA''
when agent_level = 60 then ''SMO''
when agent_level in (70,80) then ''NMA'' else ''check'' end) as agent_level_name,
(case when writing_agent_id = ledger_item_agent_id then 1 else 0 end) as hierarachy_flag, 
''icm1'' as tbl,
sum(credit) as s
from IDENTIFIER(:V_SRC_ICM_COMMISSIONS_TRANSACTIONS_PAID_ARCHIVE_VW)
where product_category = ''MS'' 
group by policy_number,
effective_date,
ledger_item_date,
app_sign_date,
allocation_agent_id,
ledger_item_agent_level,
(case when ledger_item_agent_level in (70,80) then ledger_item_agent_id end),
(case when ledger_item_agent_level in (70,80) then payment_party_id end),
(case when ledger_item_agent_level = 60 then ledger_item_agent_id end),
(case when ledger_item_agent_level = 60 then payment_party_id end),
(case when ledger_item_agent_level = 50 then ledger_item_agent_id end),
(case when ledger_item_agent_level = 50 then payment_party_id end),
(case when ledger_item_agent_level = 40 then ledger_item_agent_id end),
(case when ledger_item_agent_level = 40 then payment_party_id end),
(case when ledger_item_agent_level = 30 then ledger_item_agent_id end),
(case when ledger_item_agent_level = 30 then payment_party_id end),
(case when ledger_item_agent_level = 20 then ledger_item_agent_id end),
(case when ledger_item_agent_level = 20 then payment_party_id end),
(case when ledger_item_agent_level = 1 then ledger_item_agent_id end),
(case when ledger_item_agent_level = 1 then payment_party_id end),
writing_agent_id,
(case when agent_level = 1 then ''solicitor''
when agent_level = 20 then ''agent/ICA''
when agent_level = 30 then ''GA''
when agent_level = 40 then ''MGA''
when agent_level = 50 then ''FMO/SGA''
when agent_level = 60 then ''SMO''
when agent_level in (70,80) then ''NMA'' else ''check'' end),
(case when writing_agent_id = ledger_item_agent_id then 1 else 0 end),''icm1'';


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_ICM_ARCHIVE)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP3'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_HIERARACHY_0'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_0) COPY GRANTS AS 
select policy_number,
effective_date,
ledger_item_date,
app_sign_date,
allocation_agent_id,
ledger_item_agent_level, 
NMA_agent_id,NMA_party_id,
SMO_agent_id,SMO_party_id,
FMO_agent_id,FMO_party_id,
MGA_agent_id,MGA_party_id,GA_agent_id,GA_party_id,
agent_ica_agent_id,agent_ica_party_id,
solicitor_agent_id,solicitor_party_id,
writing_agent_id,agent_level_name,
hierarachy_flag, tbl,s
from IDENTIFIER(:V_AGENT_QUALITY_ICM_CURRENT)
UNION 
select policy_number,
effective_date,
ledger_item_date,
app_sign_date,
allocation_agent_id,
ledger_item_agent_level, 
NMA_agent_id,NMA_party_id,
SMO_agent_id,SMO_party_id,
FMO_agent_id,FMO_party_id,
MGA_agent_id,MGA_party_id,GA_agent_id,GA_party_id,
agent_ica_agent_id,agent_ica_party_id,
solicitor_agent_id,solicitor_party_id,
writing_agent_id,agent_level_name,
hierarachy_flag, tbl,s
from IDENTIFIER(:V_AGENT_QUALITY_ICM_ARCHIVE);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_0)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP4'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_HIERARACHY_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_1) COPY GRANTS AS  
select * 
from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_0)
where writing_agent_id <> '''' and ledger_item_date <> '''' ;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP5'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_HIERARACHY_2_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_2_1) COPY GRANTS AS 
Select 
policy_number,	
cast(effective_date as DATE) as effective_date,
cast(app_sign_date as DATE) as app_sign_date,
cast(ledger_item_date as DATE) as ledger_item_date,
coalesce(writing_agent_id,'''') as  writing_agent_id,
COALESCE(tbl,'''') as tbl,
max(COALESCE(NMA_agent_id,'''')) as NMA_agent_id,
max(COALESCE(NMA_party_id,'''')) as NMA_party_id,
max(COALESCE(SMO_agent_id,'''')) as SMO_agent_id,
max(COALESCE(SMO_party_id,'''')) as SMO_party_id,
max(COALESCE(FMO_agent_id,'''')) as FMO_agent_id,
max(COALESCE(FMO_party_id,'''')) as FMO_party_id,
max(COALESCE(MGA_agent_id,'''')) as MGA_agent_id,
max(COALESCE(MGA_party_id,'''')) as MGA_party_id,
max(COALESCE(GA_agent_id,'''')) as GA_agent_id,
max(COALESCE(GA_party_id,'''')) as GA_party_id,
max(COALESCE(agent_ica_agent_id,'''')) as agent_ica_agent_id,
max(COALESCE(agent_ica_party_id,'''')) as agent_ica_party_id,
max(COALESCE(solicitor_agent_id,'''')) as solicitor_agent_id,
max(COALESCE(solicitor_party_id,'''')) as solicitor_party_id,
sum(s) as credit
from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_1) 
group by policy_number,	cast(effective_date as DATE),cast(app_sign_date as DATE), cast(ledger_item_date as DATE),writing_agent_id,tbl; 
--select count(*) from hierarachy_2_1;--71,436,079/78,661,732


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_2_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP6'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_HIERARACHY_2_1_FINAL'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_2_1_FINAL) COPY GRANTS AS  
Select * from(
Select a.*, row_number() over (partition by a.policy_number, a.effective_date, a.app_sign_date order by  a.ledger_item_date desc,writing_agent_id desc,tbl desc) as rownum
from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_2_1) a) b
where b.rownum = 1;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_2_1_FINAL)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP7'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_HIERARACHY_2_2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_2_2) COPY GRANTS AS  
Select policy_number,	cast(effective_date as DATE) as effective_date,
cast(app_sign_date as DATE) as app_sign_date,
cast(ledger_item_date as DATE) as ledger_item_date, writing_agent_id,tbl,
allocation_agent_id, hierarachy_flag,	agent_level_name, ledger_item_agent_level
from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_1);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_2_2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP8'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_HIERARACHY_2_2_FINAL'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_2_2_FINAL) COPY GRANTS AS 
select * from (
Select a.*, 
row_number() over (partition by a.policy_number, a.effective_date, a.app_sign_date order by  a.ledger_item_date desc,a.writing_agent_id desc,a.tbl desc,a.allocation_agent_id desc,a.hierarachy_flag desc,a.ledger_item_agent_level nulls first) as rowNum
from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_2_2) a) b
where b.rownum = 1;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_2_2_FINAL)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP9'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_HIERARACHY_2_4'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table  IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_2_4) COPY GRANTS AS  
Select a.*, b.allocation_agent_id, b.hierarachy_flag,	b.agent_level_name
from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_2_1_FINAL) a left join IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_2_2_FINAL) b
on a.policy_number = b.policy_number
and a.effective_date = b. effective_date
and a.app_sign_date = b.app_sign_date
and a.ledger_item_date = b.ledger_item_date;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_2_4)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP10'';

V_STEP_NAME :=  ''create a table agent_quality_hierarachy_4_0'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_4_0) COPY GRANTS AS  
select a.*,row_number() over (partition by a.policy_number, a.effective_date order by a.app_sign_date desc) as rowNum1
from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_2_4) a ;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_4_0)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP11'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_HIERARACHY_4_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_4_1) COPY GRANTS AS  
select a.*
from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_4_0) a
where rowNum1 = 1;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_4_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP12'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_HIERARACHY_5_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_5_1) COPY GRANTS AS  
Select * from IDENTIFIER(:V_SCR_COMMISSION_PAID_DCM)
where product_category in (''MS'' ,''AARP MS'') ;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_5_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP13'';

V_STEP_NAME :=  ''create a table V_AGENT_QUALITY_HIERARACHY_5_2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_5_2) COPY GRANTS AS 
select policy_id as policy_number,
effective_date,
application_sign_date as app_sign_date,
ledger_item_date,
allocation_agent_id,
agent_level,
(case when agent_level in (70,80) then ledger_item_agent_id end) as NMA_agent_id,
cast((case when agent_level in (70,80) then payment_party_id end) as string) as NMA_party_id,
(case when agent_level = 60 then ledger_item_agent_id end) as SMO_agent_id,
cast((case when agent_level = 60 then payment_party_id end) as string) as SMO_party_id,
(case when agent_level = 50 then ledger_item_agent_id end) as FMO_agent_id,
cast((case when agent_level = 50 then payment_party_id end) as string) as FMO_party_id,
(case when agent_level = 40 then ledger_item_agent_id end) as MGA_agent_id,
cast((case when agent_level = 40 then payment_party_id end) as string) as MGA_party_id,
(case when agent_level = 30 then ledger_item_agent_id end) as GA_agent_id,
cast((case when agent_level = 30 then payment_party_id end) as string) as GA_party_id,

(case when agent_level in (-1,20) then ledger_item_agent_id end) as agent_ica_agent_id,
cast((case when agent_level in (-1,20) then payment_party_id end) as string) as agent_ica_party_id,

(case when agent_level = 1 then ledger_item_agent_id end) as solicitor_agent_id,
cast((case when agent_level = 1 then payment_party_id end) as string) as solicitor_party_id,

writing_agent_id as writing_agent_id,
(case when agent_level = 1 then ''solicitor''
when agent_level in (-1,20) then ''agent/ICA''
when agent_level = 30 then ''GA''
when agent_level = 40 then ''MGA''
when agent_level = 50 then ''FMO/SGA''
when agent_level = 60 then ''SMO''
when agent_level in (70,80) then ''NMA'' else ''check'' end) as agent_level_name,
(case when writing_agent_id = ledger_item_agent_id then 1 else 0 end) as hierarachy_flag, 
sum(credit) as s
from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_5_1)
group by policy_id,
effective_date,
application_sign_date,
ledger_item_date,
allocation_agent_id,
agent_level, 
(case when agent_level in (70,80) then ledger_item_agent_id end),
(case when agent_level in (70,80) then payment_party_id end),
(case when agent_level = 60 then ledger_item_agent_id end),
(case when agent_level = 60 then payment_party_id end),
(case when agent_level = 50 then ledger_item_agent_id end),
(case when agent_level = 50 then payment_party_id end),
(case when agent_level = 40 then ledger_item_agent_id end),
(case when agent_level = 40 then payment_party_id end),
(case when agent_level = 30 then ledger_item_agent_id end),
(case when agent_level = 30 then payment_party_id end),
(case when agent_level in (-1,20) then ledger_item_agent_id end),
(case when agent_level in (-1,20) then payment_party_id end),
(case when agent_level = 1 then ledger_item_agent_id end),
(case when agent_level = 1 then payment_party_id end),
writing_agent_id,
(case when agent_level = 1 then ''solicitor''
when agent_level in (-1,20) then ''agent/ICA''
when agent_level = 30 then ''GA''
when agent_level = 40 then ''MGA''
when agent_level = 50 then ''FMO/SGA''
when agent_level = 60 then ''SMO''
when agent_level in (70,80) then ''NMA'' else ''check'' end),
(case when writing_agent_id = ledger_item_agent_id then 1 else 0 end) ; 


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_5_2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP14'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_HIERARACHY_6'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_6) COPY GRANTS AS  
select * 
from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_5_2)
where writing_agent_id <> '''' and ledger_item_date <> '''';


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_6)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP15'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_HIERARACHY_6_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_6_1) COPY GRANTS AS 
Select 
policy_number,	
cast(effective_date as DATE) as effective_date,
cast(app_sign_date as DATE) as app_sign_date,
cast(ledger_item_date as DATE) as ledger_item_date,
COALESCE(writing_agent_id,'''') as writing_agent_id,
max(COALESCE(NMA_agent_id,'''')) as NMA_agent_id,
max(COALESCE(NMA_party_id,'''')) as NMA_party_id,
max(COALESCE(SMO_agent_id,'''')) as SMO_agent_id,
max(COALESCE(SMO_party_id,'''')) as SMO_party_id,
max(COALESCE(FMO_agent_id,'''')) as FMO_agent_id,
max(COALESCE(FMO_party_id,'''')) as FMO_party_id,
max(COALESCE(MGA_agent_id,'''')) as MGA_agent_id,
max(COALESCE(MGA_party_id,'''')) as MGA_party_id,
max(COALESCE(GA_agent_id,'''')) as GA_agent_id,
max(COALESCE(GA_party_id,'''')) as GA_party_id,
max(COALESCE(agent_ica_agent_id,'''')) as agent_ica_agent_id,
max(COALESCE(agent_ica_party_id,'''')) as agent_ica_party_id,
max(COALESCE(solicitor_agent_id,'''')) as solicitor_agent_id,
max(COALESCE(solicitor_party_id,'''')) as solicitor_party_id,
sum(s) as credit
from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_6)
group by policy_number,	cast(effective_date as DATE),	cast(app_sign_date as DATE), cast(ledger_item_date as DATE) , writing_agent_id; 


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_6_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP16'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_HIERARACHY_6_1_final'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_6_1_final) COPY GRANTS AS 
Select * from(
Select a.*,
row_number() over (partition by policy_number,	effective_date,	app_sign_date order by ledger_item_date desc) as rownum
from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_6_1) a) b
where b.rownum = 1;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_6_1_final)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP17'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_HIERARACHY_6_2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_6_2) COPY GRANTS AS  
Select policy_number,	cast(effective_date as DATE) as effective_date,
cast(app_sign_date as DATE) as app_sign_date,
cast(ledger_item_date as DATE) as ledger_item_date, writing_agent_id ,
allocation_agent_id, hierarachy_flag,	agent_level_name,
row_number() over (partition by policy_number,	effective_date,	app_sign_date order by policy_number desc,ledger_item_date desc, hierarachy_flag desc ,ALLOCATION_AGENT_ID ,agent_level_name ) as rownumber
from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_6);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_6_2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP18'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_HIERARACHY_6_3'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_6_3) COPY GRANTS AS 
select policy_number,	effective_date,	app_sign_date,	ledger_item_date, writing_agent_id ,
allocation_agent_id, hierarachy_flag,	agent_level_name from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_6_2) where rownumber = 1;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_6_3)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP19'';

V_STEP_NAME :=  ''create a table V_AGENT_QUALITY_HIERARACHY_6_4'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table  IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_6_4) COPY GRANTS AS  
Select a.*, b.allocation_agent_id, b.hierarachy_flag,	b.agent_level_name
from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_6_1_final) a left join IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_6_3) b
on a.policy_number = b.policy_number
and a.effective_date = b. effective_date
and a.app_sign_date = b.app_sign_date
and a.ledger_item_date = b.ledger_item_date;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_6_4)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP20'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_HIERARACHY_9_0'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_9_0) COPY GRANTS AS  
select a.*,row_number() over (partition by a.policy_number, a.effective_date order by a.app_sign_date desc, hierarachy_flag desc ) as rowNum1
from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_6_4) a ;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_9_0)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP21'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_HIERARACHY_9_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_9_1) COPY GRANTS AS  
select a.*
from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_9_0) a
where rowNum1 = 1;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_9_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP22'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_HIERARACHY_10'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_10) COPY GRANTS AS  
select distinct 
coalesce(b.policy_number,'''') as policy_number,
COALESCE(allocation_agent_id,'''') as allocation_agent_id,
COALESCE(b.effective_date,'''') as effective_date,
COALESCE(b.app_sign_date,'''') as app_sign_date,
COALESCE(b.agent_level_name,'''') as agent_level_name,
COALESCE(b.writing_agent_id,'''')as writing_agent_id,
COALESCE(b.nma_agent_id,'''') as nma_agent_id, COALESCE(b.nma_party_id,'''') as nma_party_id,
COALESCE(b.smo_agent_id,'''') as smo_agent_id, COALESCE(b.smo_party_id,'''') as smo_party_id,
COALESCE(b.fmo_agent_id,'''') as fmo_agent_id, COALESCE(b.fmo_party_id,'''') as fmo_party_id,
COALESCE(b.mga_agent_id,'''') as mga_agent_id, COALESCE(b.mga_party_id,'''') as mga_party_id,
COALESCE(b.ga_agent_id,'''') as ga_agent_id, COALESCE(b.ga_party_id,'''') as ga_party_id, 
COALESCE(b.agent_ica_agent_id,'''') as agent_ica_agent_id, COALESCE(b.agent_ica_party_id,'''') as agent_ica_party_id,
COALESCE(b.solicitor_agent_id,'''') as solicitor_agent_id, COALESCE(b.solicitor_party_id,'''') as solicitor_party_id,
COALESCE(tbl, '''') as tbl
from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_4_1) b
union
select distinct 
coalesce(b.policy_number,'''') as policy_number,
COALESCE(allocation_agent_id,'''') as allocation_agent_id,
COALESCE(b.effective_date,'''') as effective_date,
COALESCE(b.app_sign_date,'''') as app_sign_date,
COALESCE(b.agent_level_name,'''') as agent_level_name, 
COALESCE(b.writing_agent_id,'''') as writing_agent_id,
COALESCE(b.nma_agent_id,'''') as nma_agent_id, COALESCE(b.nma_party_id,'''') as nma_party_id,
COALESCE(b.smo_agent_id,'''') as smo_agent_id, COALESCE(b.smo_party_id,'''') as smo_party_id,
COALESCE(b.fmo_agent_id,'''') as fmo_agent_id, COALESCE(b.fmo_party_id,'''') as fmo_party_id,
COALESCE(b.mga_agent_id,'''') as mga_agent_id, COALESCE(b.mga_party_id,'''') as mga_party_id,
COALESCE(b.ga_agent_id,'''') as ga_agent_id, COALESCE(b.ga_party_id,'''') as ga_party_id,
COALESCE(b.agent_ica_agent_id,'''') as agent_ica_agent_id, COALESCE(b.agent_ica_party_id,'''') as agent_ica_party_id,
COALESCE(b.solicitor_agent_id,'''') as solicitor_agent_id, COALESCE(b.solicitor_party_id,'''') as solicitor_party_id,
''dcm'' as tbl 
from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_9_1) b;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_10)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP23'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_HIERARACHY_11'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_11) COPY GRANTS AS  
select a.*,row_number() over (partition by a.policy_number, a.effective_date order by a.tbl desc) as rowNum
from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_10) a
order by a.policy_number, a.effective_date ,a.tbl desc;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_11)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP24'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_HIERARACHY_12'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_12) COPY GRANTS AS  
select a.*
from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_11) a
where rowNum = 1;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_12)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP25'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_HIERARACHY_13'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_13) COPY GRANTS AS  
select a.*, b.individual_id
from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_12) a 
left join src_compas.individual b 
on a.policy_number = b.policy_number ;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_HIERARACHY_13)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);


RAISE;

END;

';