
USE SCHEMA BDR_FFP_DA;




CREATE OR REPLACE PROCEDURE BDR_FFP_DA.SP_DTC_SALES("PIPELINE_ID" VARCHAR(16777216), "PIPELINE_NAME" VARCHAR(16777216), "DB_NAME" VARCHAR(16777216), "UTIL_SC" VARCHAR(16777216), "INTRM_SC" VARCHAR(16777216), "TGT_SC" VARCHAR(16777216), "SRC_COMPAS_SC" VARCHAR(16777216), "BDR_CONF_SC" VARCHAR(16777216), "BDR_SMART_SC" VARCHAR(16777216), "SRC_MPO_SC" VARCHAR(16777216), "SRC_FIN360_SC" VARCHAR(16777216), "WH" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := :DB_NAME||''.''||COALESCE(:UTIL_SC, ''UTIL'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';

V_PROCESS_NAME   VARCHAR DEFAULT ''DTC SALES'';

V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''DTC SALES LOADING PROCESS'';

V_STEP             VARCHAR;
V_STEP_NAME        VARCHAR;
V_START_TIME       VARCHAR;
V_END_TIME         VARCHAR;
V_ROWS_PARSED       INTEGER;
V_ROWS_LOADED       INTEGER;
V_MESSAGE          VARCHAR;
V_LAST_QUERY_ID    VARCHAR;

V_DTC_SALES_MEDSUPP_SALES                      VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.DTC_SALES_MEDSUPP_SALES'';

V_DTC_SALES_MEDSUPP_SALES2                     VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.DTC_SALES_MEDSUPP_SALES2'';

V_DTC_SALES_MEDSUPP_SALES3                     VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.DTC_SALES_MEDSUPP_SALES3'';

V_DTC_SALES_INQUIRIES_DATA_BASE                VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.DTC_SALES_INQUIRIES_DATA_BASE'';

V_DTC_SALES_MEDSUPP_SALES4                     VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.DTC_SALES_MEDSUPP_SALES4'';

V_DTC_SALES_MEDSUPP_SALES4A                    VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.DTC_SALES_MEDSUPP_SALES4A'';

V_DTC_SALES_MEDSUPP_SALES5                     VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.DTC_SALES_MEDSUPP_SALES5'';

V_DTC_SALES_MEDSUPP_SALES6                     VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.DTC_SALES_MEDSUPP_SALES6'';

V_DTC_SALES_MEDSUPP_SALES7                     VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.DTC_SALES_MEDSUPP_SALES7'';

V_DTC_SALES_MEDSUPP_SALES8                     VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.DTC_SALES_MEDSUPP_SALES8'';

V_DTC_SALES_MEDSUPP_SALES8A                    VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.DTC_SALES_MEDSUPP_SALES8A'';

V_DTC_SALES_MS_INS_PLAN                        VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.DTC_SALES_MS_INS_PLAN'';

V_DTC_SALES_MEDSUPP_SALES9                     VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.DTC_SALES_MEDSUPP_SALES9'';

V_DTC_SALES_MEDSUPP_SALES10                    VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.DTC_SALES_MEDSUPP_SALES10'';

V_DTC_SALES_MEDSUPP_SALES11                    VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.DTC_SALES_MEDSUPP_SALES11'';

V_DTC_SALES_MEDSUPP_SALES12                    VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.DTC_SALES_MEDSUPP_SALES12'';

V_DTC_SALES_MEDSUPP_SALES13                    VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.DTC_SALES_MEDSUPP_SALES13'';

V_DTC_SALES_DTC_FUNNEL_FIRST_EFFECTIVE         VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.DTC_SALES_DTC_FUNNEL_FIRST_EFFECTIVE'';

V_DTC_SALES_DTC_FUNNEL_FIRST_EFFECTIVE_CNT     VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.DTC_SALES_DTC_FUNNEL_FIRST_EFFECTIVE_CNT'';

V_DTC_SALES_DTC_FUNNEL_SAME_DAY_APP            VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.DTC_SALES_DTC_FUNNEL_SAME_DAY_APP'';

V_DTC_SALES_DTC_FUNNEL_FIRST_EFFECTIVE2        VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.DTC_SALES_DTC_FUNNEL_FIRST_EFFECTIVE2'';

V_DTC_SALES_MEDSUPP_SALES_FINAL_1              VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.DTC_SALES_MEDSUPP_SALES_FINAL_1'';

V_DTC_SALES_APP_COUNT_QC                       VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.DTC_SALES_APP_COUNT_QC'';

V_DTC_SALES_PLAN_CHANGER_QC                    VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.DTC_SALES_PLAN_CHANGER_QC'';

V_DTC_SALES_DUPE_APP_QC                        VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.DTC_SALES_DUPE_APP_QC'';

V_DTC_SALES_FUNNEL                             VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.DTC_SALES_FUNNEL'';

V_P_LVL_CLAIM_INFO                             VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.INFORCELR_P_LVL_CLAIM_INFO'';



V_APPS_RPTG_DAILY                              VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_MPO_SC, ''SRC_MPO'') || ''.APPS_RPTG_DAILY'';

V_OPTUMCSS_CONTACT_RESPONSE                    VARCHAR := :DB_NAME || ''.'' || COALESCE(:BDR_SMART_SC, ''BDR_SMART'') || ''.OPTUMCSS_CONTACT_RESPONSE'';

V_OLE_APPLICATION                              VARCHAR := :DB_NAME || ''.'' || COALESCE(:BDR_SMART_SC, ''BDR_SMART'') || ''.OLE_APPLICATION'';

V_PERSON_CONSOLIDATION                         VARCHAR := :DB_NAME || ''.'' || COALESCE(:BDR_SMART_SC, ''BDR_SMART'') || ''.PERSON_CONSOLIDATION'';

V_SPECIFICATION                                VARCHAR := :DB_NAME || ''.'' || COALESCE(:BDR_SMART_SC, ''BDR_SMART'') || ''.SPECIFICATION'';

V_INSURED_PLAN                                 VARCHAR := :DB_NAME || ''.'' || COALESCE(:BDR_SMART_SC, ''BDR_SMART'') || ''.INSURED_PLAN'';

V_D_MBR_INFO                                   VARCHAR := :DB_NAME || ''.'' || COALESCE(:BDR_CONF_SC, ''BDR_CONF'') || ''.D_MBR_INFO'';

V_INQUIRY_DATA                                 VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_FIN360_SC, ''SRC_FIN360'') || ''.INQUIRY_DATA'';

V_INQUIRY_DAILY                                VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_MPO_SC, ''SRC_MPO'') || ''.INQUIRY_DAILY'';

V_UNDERWRITING_DASHBOARD_DATA                  VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.POS_UW_UNDERWRITING_DASHBOARD_DATA'';




BEGIN


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP1'';

V_STEP_NAME :=  ''create table DTC_SALES_MEDSUPP_SALES'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());



create or replace table IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES)  as
SELECT person_id, appl_receipt_date , rptg_effective_date as effective_date , requested_effective_date ,
CASE 
	WHEN rptg_effective_date <= (current_date) AND termination_date IS NULL then ''Y''
	WHEN rptg_effective_date > (current_date) THEN ''Not yet effective''
	ELSE ''N''
END effective_at_refresh,
payment_received_date , termination_date ,  
source_application_id ,application_id, source_code as source_code_final , enrollment, paidsale ,
CASE 
	WHEN paidsale = 1 THEN ''Yes''
	WHEN paidsale = 0 AND rptg_effective_date > (current_date) THEN ''Not yet effective''
	WHEN paidsale = 0 AND dateadd(day,90,rptg_effective_date) < (current_date) THEN ''NPOP''
	ELSE ''No''
END AS paid_sale_conversion,
age_at_eff ,
CASE 
	WHEN age_at_eff < 65 THEN ''<65''
	WHEN age_at_eff >= 65 AND age_at_eff < 66 THEN ''65''
	WHEN age_at_eff >= 66 AND age_at_eff < 70 THEN ''66-69''
	WHEN age_at_eff >= 70 AND age_at_eff < 75 THEN ''70-74''
	WHEN age_at_eff >= 75 AND age_at_eff < 80 THEN ''75-79''
	ELSE ''80+''
END AS age_group,
state_code , plan_code , plan_grp  
FROM IDENTIFIER(:V_APPS_RPTG_DAILY) 
WHERE 1=1
AND app = 1
AND sale = 1
AND spec_type_code = ''B''
AND product = ''MS''
AND adjudication_status = ''ACCEPTED''
AND enrollment_call_center_source <> ''UCC''
AND appl_receipt_date >= ''2023-01-01''
AND rptg_effective_date >= ''2023-01-01''
;




V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID,:V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP2'';
   
   V_STEP_NAME := ''CREATING TABLE DTC_SALES_MEDSUPP_SALES2'';
   
   V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
create or replace table IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES2)  AS
SELECT a.*, 
MIN(b.contact_date) OVER (PARTITION BY a.person_id, a.appl_receipt_date) AS first_OCSS_contact_6months
FROM IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES) a
LEFT JOIN IDENTIFIER(:V_OPTUMCSS_CONTACT_RESPONSE) b 
ON a.person_id = b.person_id 
AND b.opportunity_record_type = ''OPPORTUNITY''
AND b.hco_contact_source_in_out = ''INBOUND''
AND b.contact_date <= a.appl_receipt_date
AND b.contact_date >= cast(dateadd(day,-179,a.appl_receipt_date) as date) 
;





V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES2) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP3'';
   
   V_STEP_NAME := ''CREATING TABLE DTC_SALES_MEDSUPP_SALES3'';
   
   V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES3)  AS
SELECT a.*, 
min(b.ole_app_creation_date) over (partition by a.person_id, a.appl_receipt_date) as first_OLE_app_6months
FROM IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES2) a
LEFT JOIN IDENTIFIER(:V_OLE_APPLICATION) b 
ON a.person_id = b.person_id 
AND b.ole_app_creation_date <= a.appl_receipt_date
AND b.ole_app_creation_date >= cast(dateadd(day,-179,appl_receipt_date) as date)
AND b.role_id = 3 
;




V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES3) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP4'';
   
   V_STEP_NAME := ''CREATING TABLE DTC_SALES_INQUIRIES_DATA_BASE'';
   
   V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
   
create or replace table IDENTIFIER(:V_DTC_SALES_INQUIRIES_DATA_BASE)  as         
select id.person_id,id.inq_time , i.* 
from IDENTIFIER(:V_INQUIRY_DATA) as i
left join IDENTIFIER(:V_INQUIRY_DAILY) id
on i.reporting_id=id.reporting_id
and i.inquiry_date=id.inquiry_date
where i.vendor=''Optum''
and i.inbound_channel=''Phone''
and i.fulfillment in (''eInquiry'',''Standard'')
and i.metric=''Leads''
and i.inquiry_date >= ''2022-06-01'';




V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_DTC_SALES_INQUIRIES_DATA_BASE) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP5'';
   
   V_STEP_NAME := ''CREATING TABLE DTC_SALES_MEDSUPP_SALES4'';
   
   V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
   
create or replace table IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES4)  AS
select a.*, 
min(b.inquiry_date) over (partition by a.person_id, a.appl_receipt_date) as first_inquiry_6months
FROM IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES3) a
LEFT JOIN IDENTIFIER(:V_DTC_SALES_INQUIRIES_DATA_BASE) b 
ON a.person_id = b.person_id 
AND b.inquiry_date <= a.appl_receipt_date
AND b.inquiry_date >= cast(DATEADD(day,-179,a.appl_receipt_date) as date)
;




V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES4) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP6'';
   
   V_STEP_NAME := ''CREATING TABLE DTC_SALES_MEDSUPP_SALES4A'';
   
   V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
   
create or replace table IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES4A)  AS
SELECT DISTINCT *
FROM IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES4)
;




V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES4A) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP7'';
   
   V_STEP_NAME := ''CREATING TABLE DTC_SALES_MEDSUPP_SALES5'';
   
   V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
   
create or replace table IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES5)  AS
Select *,
CASE 
	WHEN first_inquiry_6months IS NULL AND first_ole_app_6months IS NULL AND first_ocss_contact_6months IS NULL THEN appl_receipt_date
	WHEN first_inquiry_6months IS NOT NULL AND (first_inquiry_6months <= first_ole_app_6months OR first_ole_app_6months IS NULL) And (first_inquiry_6months <= first_ocss_contact_6months OR first_ocss_contact_6months IS NULL) Then first_inquiry_6months
    WHEN first_ole_app_6months IS NOT NULL AND (first_ole_app_6months < first_inquiry_6months OR first_inquiry_6months IS NULL) And (first_ole_app_6months <= first_ocss_contact_6months OR first_ocss_contact_6months IS NULL) Then first_ole_app_6months 
    WHEN first_ocss_contact_6months IS NOT NULL AND (first_ocss_contact_6months < first_inquiry_6months OR first_inquiry_6months IS NULL) And (first_ocss_contact_6months < first_ole_app_6months OR first_ole_app_6months IS NULL) Then first_ocss_contact_6months
    Else NULL
END AS Initial_Contact_Date,
CASE 
	WHEN first_inquiry_6months IS NULL AND first_ole_app_6months IS NULL AND first_ocss_contact_6months IS NULL THEN ''No prior contact within 6 months''
	WHEN first_inquiry_6months IS NOT NULL AND (first_inquiry_6months <= first_ole_app_6months OR first_ole_app_6months IS NULL) And (first_inquiry_6months <= first_ocss_contact_6months OR first_ocss_contact_6months IS NULL) Then ''Inquiry''
	WHEN first_ole_app_6months IS NOT NULL AND (first_ole_app_6months < first_inquiry_6months OR first_inquiry_6months IS NULL) And (first_ole_app_6months <= first_ocss_contact_6months OR first_ocss_contact_6months IS NULL) Then ''OLE'' 
	When first_ocss_contact_6months IS NOT NULL AND (first_ocss_contact_6months < first_inquiry_6months OR first_inquiry_6months IS NULL) And (first_ocss_contact_6months < first_ole_app_6months OR first_ole_app_6months IS NULL) Then ''OCSS''
	ELSE ''FLAG''
End As Initial_Contact_Channel
From  IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES4A)
;




V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES5) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP8'';
   
   V_STEP_NAME := ''CREATING TABLE DTC_SALES_MEDSUPP_SALES6'';
   
   V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
   
create or replace table IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES6)  AS
SELECT *, DATEDIFF(day,initial_contact_date,appl_receipt_date)+1 as conversion_time
FROM IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES5)
WHERE initial_contact_date >= ''2023-01-01''
;



V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES6) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP9'';
   
   V_STEP_NAME := ''CREATING TABLE DTC_SALES_MEDSUPP_SALES7'';
   
   V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
   
create or replace table IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES7)  AS
SELECT t1.*, t2.optum_unique_call_id,
CASE 
	WHEN t1.initial_contact_channel = ''OCSS'' THEN t2.desired_effective_date_1
	WHEN t1.initial_contact_channel = ''OLE'' THEN t3.requested_effective_date
	WHEN t1.initial_contact_channel = ''Inquiry'' THEN t4.desired_effective_date
	WHEN t1.initial_contact_channel = ''No prior contact within 6 months'' THEN t1.requested_effective_date 
END requested_effective_date_inital,
CASE 
	WHEN t1.initial_contact_channel = ''OCSS'' THEN t2.source_code 
	WHEN t1.initial_contact_channel = ''OLE'' THEN t3.source_code
	WHEN t1.initial_contact_channel = ''Inquiry'' THEN t4.source_code
	WHEN t1.initial_contact_channel = ''No prior contact within 6 months'' THEN t1.source_code_final 
END source_code_initial,
CASE 
	WHEN conversion_time <= 30 THEN 30
	WHEN conversion_time <= 60 THEN 60
	WHEN conversion_time <= 90 THEN 90
	WHEN conversion_time <= 120 THEN 120
	WHEN conversion_time <= 150 THEN 150
	WHEN conversion_time <= 180 THEN 180 
END AS conversion_time_bucket
FROM IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES6) AS t1
LEFT JOIN (
	SELECT b.person_id, b.contact_date, b.contact_time, b.optum_unique_call_id, b.opportunity_record_type, b.hco_contact_source_in_out, b.desired_effective_date_1, b.source_code, ROW_NUMBER () OVER(PARTITION BY b.person_id ,b.contact_date ORDER BY b.optumcss_contact_response_id, b.contact_date , b.contact_time asc) AS RowNo 
	FROM IDENTIFIER(:V_OPTUMCSS_CONTACT_RESPONSE) b
	WHERE b.opportunity_record_type = ''OPPORTUNITY'' and b.hco_contact_source_in_out = ''INBOUND''
) AS t2 ON t1.person_id = t2.person_id AND t1.initial_contact_date = t2.contact_date AND t2.RowNo = 1 AND t1.initial_contact_channel = ''OCSS'' 
LEFT JOIN (
	SELECT c.person_id, c.ole_app_creation_date, c.ole_app_creation_time, c.requested_effective_date, c.source_code, ROW_NUMBER () OVER(PARTITION BY c.person_id ,c.ole_app_creation_date ORDER BY c.ole_application_id,c.ole_app_creation_date , c.ole_app_creation_time asc) AS RowNo 
	FROM IDENTIFIER(:V_OLE_APPLICATION) c
) AS t3 ON t1.person_id = t3.person_id AND t1.initial_contact_date = t3.ole_app_creation_date AND t3.RowNo = 1 AND t1.initial_contact_channel = ''OLE'' 
LEFT JOIN (
	SELECT d.person_id, d.desired_effective_date, d.inquiry_date, d.inq_time, d.source_code, ROW_NUMBER () OVER(PARTITION BY d.person_id ,d.inquiry_date ORDER BY d.key,d.inquiry_date, d.inq_time asc) AS RowNo 
	FROM IDENTIFIER(:V_DTC_SALES_INQUIRIES_DATA_BASE) d
) AS t4 ON t1.person_id = t4.person_id AND t1.initial_contact_date = t4.inquiry_date AND t4.RowNo = 1 AND t1.initial_contact_channel = ''Inquiry'' 
;



V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES7) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP10'';
   
   V_STEP_NAME := ''CREATING TABLE DTC_SALES_MEDSUPP_SALES8'';
   
   V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
   
create or replace table IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES8)  AS 
SELECT a.*, 
b.prdct_eff_dt  
FROM IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES7) a
LEFT JOIN IDENTIFIER(:V_P_LVL_CLAIM_INFO) b 
ON a.person_id = b.pers_id 
AND a.effective_date = b.prem_due_dt 
;



V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES8) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP11'';
   
   V_STEP_NAME := ''CREATING TABLE DTC_SALES_MEDSUPP_SALES8A'';
   
   V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
   

create or replace table IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES8A)  AS
SELECT t1.*,
t2.acct_nbr
from IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES8) t1
LEFT JOIN (
	SELECT mi.acct_nbr, mi.pers_id, ROW_NUMBER () OVER(PARTITION BY mi.pers_id ORDER BY mi.d_mbr_info_sk,mi.mbr_info_sk_end_dt desc) AS RowNo 
	FROM IDENTIFIER(:V_D_MBR_INFO) mi
) AS t2 
ON t1.person_id = t2.pers_id
AND t2.RowNo = 1
;



V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES8A) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP12'';
   
   V_STEP_NAME := ''CREATING TABLE DTC_SALES_MS_INS_PLAN'';
   
   V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
   
 

create or replace table IDENTIFIER(:V_DTC_SALES_MS_INS_PLAN)  as 
SELECT DISTINCT a.person_id , a.appl_receipt_date, a.source_application_id,
CASE 
	WHEN a.initial_contact_date >= ip.EFFECTIVE_DATE AND ip.TERMINATION_DATE IS NULL AND a.initial_contact_date < a.appl_receipt_date THEN ''Y''
    WHEN ip.TERMINATION_DATE IS NOT NULL AND a.initial_contact_date < a.appl_receipt_date AND a.initial_contact_date BETWEEN ip.EFFECTIVE_DATE AND ip.TERMINATION_DATE THEN ''Y''       
    ELSE ''N'' 
END AS MS_Insured_Mbr   
FROM IDENTIFIER(:V_INSURED_PLAN) ip --bdr_smart
LEFT JOIN IDENTIFIER(:V_PERSON_CONSOLIDATION) pc
        ON pc.merged_person_id=ip.person_id
INNER JOIN IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES8A) a
        ON a.person_id = pc.retained_person_id
INNER JOIN IDENTIFIER(:V_SPECIFICATION) sp
        ON ip.specification_id = sp.specification_id
WHERE 1=1
		AND sp.product_type_code IN (''M'')
        AND sp.spec_type_code IN (''B'')
        AND ((ip.TERMINATION_DATE IS NOT NULL AND a.initial_contact_date BETWEEN ip.EFFECTIVE_DATE AND ip.TERMINATION_DATE) OR (a.initial_contact_date >= ip.EFFECTIVE_DATE AND ip.TERMINATION_DATE IS NULL))
;



V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_DTC_SALES_MS_INS_PLAN) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP13'';
   
   V_STEP_NAME := ''CREATING TABLE DTC_SALES_MEDSUPP_SALES9'';
   
   V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
   
create or replace table IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES9)  AS 
SELECT a.*,
CASE
	WHEN MS_Insured_Mbr = ''Y'' THEN ''Y''
	ELSE ''N''
END AS MS_Insured_Mbr
FROM IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES8A) a
LEFT JOIN IDENTIFIER(:V_DTC_SALES_MS_INS_PLAN) b
ON a.person_id = b.person_id 
AND a.appl_receipt_date = b.appl_receipt_date 
AND a.source_application_id = b.source_application_id 
;



V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES9) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP14'';
   
   V_STEP_NAME := ''CREATING TABLE DTC_SALES_MEDSUPP_SALES10'';
   
   V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
   

create or replace table IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES10)  as 
SELECT distinct a.*,
max(ip.termination_date) OVER (PARTITION BY a.person_id, a.appl_receipt_date) AS prior_termination_date
FROM IDENTIFIER(:V_INSURED_PLAN) ip
LEFT JOIN IDENTIFIER(:V_PERSON_CONSOLIDATION) pc
        ON pc.merged_person_id=ip.person_id
INNER JOIN IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES9) a
        ON a.person_id = pc.retained_person_id
INNER JOIN IDENTIFIER(:V_SPECIFICATION) sp
        ON ip.specification_id = sp.specification_id
WHERE 1=1
		AND sp.product_type_code IN (''M'')
        AND sp.spec_type_code IN (''B'')
        AND ip.TERMINATION_DATE < a.effective_date 
;



V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES10) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP15'';
   
   V_STEP_NAME := ''CREATING TABLE DTC_SALES_MEDSUPP_SALES11'';
   
   V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
   
create or replace table IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES11)  as 
SELECT a.*,
CASE 
	WHEN b.prior_termination_date IS NOT NULL THEN b.prior_termination_date
	ELSE NULL
END AS prior_termination_date,
CASE 
	WHEN b.prior_termination_date IS NOT NULL THEN DATEDIFF(day,b.prior_termination_date,a.effective_date)::varchar
	ELSE ''No prior coverage''
END AS days_between_coverage
FROM IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES9) a
LEFT JOIN IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES10) b 
ON a.person_id = b.person_id 
AND a.appl_receipt_date = b.appl_receipt_date 
AND a.source_application_id = b.source_application_id 
; 



V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES11) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP16'';
   
   V_STEP_NAME := ''CREATING TABLE DTC_SALES_MEDSUPP_SALES12'';
   
   V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
   
create or replace table IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES12)  as 
SELECT *, 
CASE 
	WHEN days_between_coverage = ''1'' THEN ''Y''
	ELSE ''N''
END AS plan_changer_flag,
CASE 
	WHEN effective_date = termination_date THEN 1
	ELSE 0
END same_day_term_flg

FROM IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES11)
;



V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES12) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP17'';
   
   V_STEP_NAME := ''CREATING TABLE DTC_SALES_MEDSUPP_SALES13'';
   
   V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
   
create or replace table IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES13)  as 
select a.*
,b.rate_determination_code_desc
,b.uw_pln_rqr
,b.uw_prdct_rqr
,case 
	when a.SOURCE_APPLICATION_ID=b.SOURCE_APPLICATION_ID then ''Match'' 
	else ''No match'' 
end as match_flg
from IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES12) as a
left join (
	select distinct rate_determination_code_desc,SOURCE_APPLICATION_ID,uw_pln_rqr,uw_prdct_rqr 
	from IDENTIFIER(:V_UNDERWRITING_DASHBOARD_DATA)--SRC_COMPAS
) b on a.SOURCE_APPLICATION_ID=b.SOURCE_APPLICATION_ID
;



V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES13) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP18'';
   
   V_STEP_NAME := ''CREATING TABLE DTC_SALES_DTC_FUNNEL_FIRST_EFFECTIVE'';
   
   V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
   

create or replace table IDENTIFIER(:V_DTC_SALES_DTC_FUNNEL_FIRST_EFFECTIVE)  as
Select base.person_id,
base.source_application_id,
Min(fe.effective_date) as first_effective
From IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES13) base
join IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES13) fe on 
	base.person_id =fe.person_id 
	and base.appl_receipt_date < fe.effective_date 
Where base.plan_changer_flag =''N''
and fe.plan_changer_flag =''N''
	group by base.person_id, base.source_application_id;




V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_DTC_SALES_DTC_FUNNEL_FIRST_EFFECTIVE) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP19'';
   
   V_STEP_NAME := ''CREATING TABLE DTC_SALES_DTC_FUNNEL_FIRST_EFFECTIVE_CNT'';
   
   V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
   
create or replace table IDENTIFIER(:V_DTC_SALES_DTC_FUNNEL_FIRST_EFFECTIVE_CNT)  as
Select person_id,
first_effective,
Count(first_effective) as count_multi_apps
From IDENTIFIER(:V_DTC_SALES_DTC_FUNNEL_FIRST_EFFECTIVE)
group by person_id, first_effective;




V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_DTC_SALES_DTC_FUNNEL_FIRST_EFFECTIVE_CNT) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP20'';
   
   V_STEP_NAME := ''CREATING TABLE V_DTC_SALES_DTC_FUNNEL_SAME_DAY_APP'';
   
   V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
   
create or replace table IDENTIFIER(:V_DTC_SALES_DTC_FUNNEL_SAME_DAY_APP)  as
Select base.person_id,
base.source_application_id, 
case when rd.appl_receipt_date is null then 0 else 1 End as same_day_chnl_flg
From IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES13) base
LEFT join IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES13) rd on 
	base.person_id =rd.person_id 
	and base.appl_receipt_date = rd.appl_receipt_date 
	and base.enrollment = rd.enrollment
	and base.source_application_id <> rd.source_application_id
Where base.plan_changer_flag =''N'' and rd.plan_changer_flag =''N''
group by 
base.person_id,
base.source_application_id, 
Base.appl_receipt_date,
base.enrollment,
rd.appl_receipt_date,
rd.enrollment
;



V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_DTC_SALES_DTC_FUNNEL_SAME_DAY_APP) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP21'';
   
   V_STEP_NAME := ''CREATING TABLE DTC_SALES_DTC_FUNNEL_FIRST_EFFECTIVE2'';
   
   V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
   
create or replace table IDENTIFIER(:V_DTC_SALES_DTC_FUNNEL_FIRST_EFFECTIVE2)  as
Select base.*,
fe.first_effective,
fec.count_multi_apps,
sda.same_day_chnl_flg
From IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES13) base
left join IDENTIFIER(:V_DTC_SALES_DTC_FUNNEL_FIRST_EFFECTIVE) fe on 
	base.person_id =fe.person_id 
	and base.source_application_id =fe.source_application_id 
left join IDENTIFIER(:V_DTC_SALES_DTC_FUNNEL_FIRST_EFFECTIVE_CNT) fec on 
	base.person_id =fec.person_id 
	and fe.first_effective =fec.first_effective
left join IDENTIFIER(:V_DTC_SALES_DTC_FUNNEL_SAME_DAY_APP) sda on 
	base.person_id =sda.person_id 
	and base.source_application_id =sda.source_application_id ;



V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_DTC_SALES_DTC_FUNNEL_FIRST_EFFECTIVE2) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP22'';
   
   V_STEP_NAME := ''CREATING TABLE DTC_SALES_MEDSUPP_SALES_FINAL_1'';
   
   V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
   
create or replace table IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES_FINAL_1)  as
Select  base.*, 
CASE 
	WHEN (substring(base.plan_code, 2,3) = ''02'' OR substring(base.plan_code, 2,3) = ''S2'' OR base.plan_code = ''GH2'') THEN ''NLE''
	ELSE ''ELE''
END AS lgl_enty, 
CASE When RD.source_application_id IS NOT NULL then 1 Else 0 END as Enrolment_Plan_Change
from IDENTIFIER(:V_DTC_SALES_DTC_FUNNEL_FIRST_EFFECTIVE2) base
LEFT join IDENTIFIER(:V_DTC_SALES_DTC_FUNNEL_FIRST_EFFECTIVE2) rd on
	base.person_id =rd.person_id
		and base.first_effective  = rd.first_effective
		and rd.enrollment= ''Plan Change''
		and base.count_multi_apps >1
;



V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES_FINAL_1) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP23'';
   
   V_STEP_NAME := ''CREATING TABLE DTC_SALES_FUNNEL'';
   
   V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
   
create or replace table IDENTIFIER(:V_DTC_SALES_FUNNEL)  as
select distinct *
from IDENTIFIER(:V_DTC_SALES_MEDSUPP_SALES_FINAL_1);





V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_DTC_SALES_FUNNEL) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP24'';
   
   V_STEP_NAME := ''CREATING TABLE DTC_SALES_APP_COUNT_QC'';
   
   V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
   
create or replace table IDENTIFIER(:V_DTC_SALES_APP_COUNT_QC)  as
select SUBSTR(appl_receipt_date , 1, 7) app_receipt_month, Count (Distinct application_id) distinct_apps, Count (Distinct person_id) distinct_ids
from IDENTIFIER(:V_DTC_SALES_FUNNEL) 
Group by SUBSTR(appl_receipt_date , 1, 7)
ORDER BY SUBSTR(appl_receipt_date , 1, 7)
;



V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_DTC_SALES_APP_COUNT_QC) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP25'';
   
   V_STEP_NAME := ''CREATING TABLE DTC_SALES_PLAN_CHANGER_QC'';
   
   V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
   

create or replace table IDENTIFIER(:V_DTC_SALES_PLAN_CHANGER_QC) as
select SUBSTR(appl_receipt_date , 1, 7) app_receipt_month, plan_changer_flag, Count (Distinct application_id) distinct_apps, Count (Distinct person_id) distinct_ids
from IDENTIFIER(:V_DTC_SALES_FUNNEL)
Group by SUBSTR(appl_receipt_date , 1, 7), plan_changer_flag
ORDER BY SUBSTR(appl_receipt_date , 1, 7), plan_changer_flag
;




V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_DTC_SALES_PLAN_CHANGER_QC) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP26'';
   
   V_STEP_NAME := ''CREATING TABLE DTC_SALES_DUPE_APP_QC'';
   
   V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
   
create or replace table IDENTIFIER(:V_DTC_SALES_DUPE_APP_QC)  as
select SUBSTR(appl_receipt_date , 1, 7) app_receipt_month, count_multi_apps, Count (Distinct application_id) distinct_apps, Count (Distinct person_id) distinct_ids
from IDENTIFIER(:V_DTC_SALES_FUNNEL) 
Group by SUBSTR(appl_receipt_date , 1, 7), count_multi_apps
ORDER BY SUBSTR(appl_receipt_date , 1, 7), count_multi_apps
;

V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_DTC_SALES_DUPE_APP_QC) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'',  :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);


RAISE;

END;

';