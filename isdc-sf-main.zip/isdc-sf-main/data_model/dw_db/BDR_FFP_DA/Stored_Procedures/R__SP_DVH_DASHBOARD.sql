USE SCHEMA BDR_FFP_DA;

CREATE OR REPLACE PROCEDURE BDR_FFP_DA.SP_DVH_DASHBOARD("PIPELINE_ID" VARCHAR(16777216), "PIPELINE_NAME" VARCHAR(16777216), "DB_NAME" VARCHAR(16777216), "UTIL_SC" VARCHAR(16777216), "TGT_SC_1" VARCHAR(16777216), "TGT_SC_2" VARCHAR(16777216), "SRC_SC_DM" VARCHAR(16777216), "SRC_SC_CONF" VARCHAR(16777216), "SRC_SC_MPBU" VARCHAR(16777216), "SRC_SC_SMART" VARCHAR(16777216), "SRC_SC_SRA" VARCHAR(16777216), "SRC_SC_MPO" VARCHAR(16777216), "WH" VARCHAR(16777216), "STAGE_NAME" VARCHAR(16777216), "CURR_DATE" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

V_CURRENT_DATE   DATE := COALESCE(TO_DATE(:CURR_DATE), CURRENT_DATE());


V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := :DB_NAME||''.''||COALESCE(:UTIL_SC, ''UTIL'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';

V_PROCESS_NAME   VARCHAR DEFAULT ''DVH_DASHBOARD'';

V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''DVH_DASHBOARD'';

V_STEP             VARCHAR;

V_STEP_NAME        VARCHAR;

V_START_TIME       VARCHAR;

V_END_TIME         VARCHAR;

V_ROWS_PARSED       INTEGER;

V_ROWS_LOADED       INTEGER;

V_MESSAGE          VARCHAR;

V_LAST_QUERY_ID    VARCHAR;


V_REFINED_ISDW_PREM_V_F_PREM_TRANS_DAY VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_DM, ''BDR_DM'') || ''.F_PREM_TRANS_DAY'';

V_REFINED_ISDW_REF_V_D_SURCHRG_TIER VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_DM, ''BDR_DM'') || ''.D_SURCHRG_TIER'';

V_REFINED_ISDW_REF_V_D_MBR_INFO VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_CONF, ''BDR_CONF'') || ''.V_D_MBR_INFO'';

V_REFINED_ISDW_REF_V_D_ACQN_CHNL VARCHAR := :DB_NAME || ''.'' || COALESCE(SRC_SC_CONF, ''BDR_CONF'') || ''.D_ACQN_CHNL'';

V_REFINED_ISDW_REF_V_D_CERT_ACTV VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_CONF, ''BDR_CONF'') || ''.D_CERT_ACTV'';

V_REFINED_ISDW_REF_V_D_AGT VARCHAR := :DB_NAME || ''.'' || COALESCE(SRC_SC_CONF, ''BDR_CONF'') || ''.D_AGT'';

V_REFINED_ISDW_REF_V_D_UNDWR_TAG VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_CONF, ''BDR_CONF'') || ''.D_UNDWR_TAG'';

V_REFINED_ISDW_REF_V_D_PLN_BEN_MOD VARCHAR := :DB_NAME || ''.'' || COALESCE(SRC_SC_CONF, ''BDR_CONF'') || ''.D_PLN_BEN_MOD'';

V_REFINED_ISDW_PREM_V_FF_MPBU_SRC_INDV VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_MPBU, ''BDR_MPBU'') || ''.FF_MPBU_SRC_INDV'';

V_REFINED_SRA_EVERYTHING_BASE VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_SRA, ''SRC_SRA'') || ''.EVERYTHING_BASE'';

V_REFINED_PARTY_SHIP_PERSON_XREF VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_SMART, ''BDR_SMART'') || ''.SHIP_PERSON_XREF'';

V_REFINED_LOCATION_ZIP_CODE VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_SMART, ''BDR_SMART'') || ''.ZIP_CODE'';

V_REFINED_POLICY_INSURED_PLAN VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_SMART, ''BDR_SMART'') || ''.INSURED_PLAN'';

V_REFINED_POLICY_APPLICATION_AGENT VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_SMART, ''BDR_SMART'') || ''.APPLICATION_AGENT'';

V_REFINED_POLICY_APPLICATION VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_SMART, ''BDR_SMART'') || ''.APPLICATION'';

V_REFINED_POLICY_SPECIFICATION VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_SMART, ''BDR_SMART'') || ''.SPECIFICATION'';

V_FFP_AGENT_QUALITY_WRK_AGENT_PROFILE VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_AGENT_PROFILE'';

V_REFINED_ISDW_PREM_FACETS_DENTAL_CROSSWALK VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2, ''BDR_FFP_DA_WRK'') || ''.DVH_FACETS_DENTAL_CROSSWALK_DEEP'';

V_FFP_INFORCE_LR_P_LVL_CLAIM_INFO VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_1, ''BDR_FFP_DA'') || ''.INFORCELR_P_LVL_CLAIM_INFO'';

V_COMMON_OGS_EALLIANCE VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_MPO, ''SRC_MPO'') || ''.EALLIANCE'';

V_REFINED_MPO_APPS_RPTG_DAILY VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_MPO, ''SRC_MPO'') || ''.APPS_RPTG_DAILY'';

V_DB_FFP_WRK_TST1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_TST1'';

V_DB_FFP_WRK_APPS_DT_6_3 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_APPS_DT_6_3'';

V_DB_FFP_WRK_DVH_APPS_3 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_APPS_3'';

V_DB_FFP_WRK_APPS_DT_4_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_APPS_DT_4_1'';

V_DB_FFP_WRK_APPS_DT_3_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_APPS_DT_3_1'';

V_DB_FFP_WRK_MS_MBR_FOR_DVH_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_MS_MBR_FOR_DVH_1'';

V_DB_FFP_WRK_DVH_APPS_4 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_APPS_4'';

V_DB_FFP_WRK_MS_MBR_FOR_DVH VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_MS_MBR_FOR_DVH'';

V_DB_FFP_WRK_APPS_DT_1_0 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_APPS_DT_1_0'';

V_DB_FFP_WRK_APPS_DT_3 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_APPS_DT_3'';

V_DB_FFP_WRK_MS_DVH_COMBO_UNIONED VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_MS_DVH_COMBO_UNIONED'';

V_DB_FFP_WRK_APPS_SMZD_DAILY_NODUP_0 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_APPS_SMZD_DAILY_NODUP_0'';

V_DB_FFP_WRK_DVH_APPS_SUMMARY VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_APPS_SUMMARY'';

V_DB_FFP_WRK_CROSS_SALES_IDS VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_CROSS_SALES_IDS'';

V_DB_FFP_WRK_APPS_SMZD_DAILY_NODUP_FINAL VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_APPS_SMZD_DAILY_NODUP_FINAL'';

V_DB_FFP_WRK_APPS_DT_4_2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_APPS_DT_4_2'';

V_DB_FFP_WRK_EALLIANCE_MAP VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_EALLIANCE_MAP'';

V_DB_FFP_WRK_APPS_DT_0 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_APPS_DT_0'';

V_DB_FFP_WRK_DVH_CROSS_PRODUCT_APPS_2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_CROSS_PRODUCT_APPS_2'';

V_DB_FFP_WRK_MS_MBR_FOR_DVH_3 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_MS_MBR_FOR_DVH_3'';

V_DB_FFP_WRK_MS_APPS_FOR_DVH_0 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_MS_APPS_FOR_DVH_0'';

V_DB_FFP_WRK_APPS_DT_6_2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_APPS_DT_6_2'';

V_DB_FFP_WRK_DVH_AGT_DTL_ISDW VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_AGT_DTL_ISDW'';

V_DB_FFP_WRK_DVH_AGENT_DTL_2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_AGENT_DTL_2'';

V_DB_FFP_WRK_AGT_PARTY_ID_MAP VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_AGT_PARTY_ID_MAP'';

V_DB_FFP_WRK_APPS_DT_5 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_APPS_DT_5'';

V_DB_FFP_WRK_DVH_AGENT_DTL VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_AGENT_DTL'';

V_DB_FFP_WRK_DVH_APPS_SUMMARY_FINAL VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_APPS_SUMMARY_FINAL'';

V_DB_FFP_WRK_APPS_DT_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_APPS_DT_1'';

V_DB_FFP_WRK_APPS_DT_2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_APPS_DT_2'';

V_DB_FFP_WRK_APPS_DT_6 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_APPS_DT_6'';

V_DB_FFP_WRK_APPS_DT_3_2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_APPS_DT_3_2'';

V_DB_FFP_WRK_APPS_DT_5_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_APPS_DT_5_1'';

V_DB_FFP_WRK_V_F_PREM_TRANS_DAY_SUBSET_B VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_V_F_PREM_TRANS_DAY_SUBSET_B'';

V_DB_FFP_WRK_DVH_APPS_5 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_APPS_5'';

V_DB_FFP_WRK_MS_PRDCT_EFF VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_MS_PRDCT_EFF'';

V_DB_FFP_WRK_MS_MBR_FOR_DVH_2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_MS_MBR_FOR_DVH_2'';

V_DB_FFP_WRK_MS_PRDCT_EFF_V1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_MS_PRDCT_EFF_V1'';

V_DB_FFP_WRK_DVH_AGT_HIERARCHY VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_AGT_HIERARCHY'';

V_DB_FFP_WRK_APPS_DT_6_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_APPS_DT_6_1'';

V_DB_FFP_WRK_SALE_PAID_KEY VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_SALE_PAID_KEY'';

V_DB_FFP_WRK_MS_MBR_FOR_DVH_0 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_MS_MBR_FOR_DVH_0'';

V_DB_FFP_WRK_COMPAS_PLAN_IDS VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_COMPAS_PLAN_IDS'';

V_DB_FFP_WRK_MS_APPS_FOR_DVH VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_MS_APPS_FOR_DVH'';

V_DB_FFP_WRK_CROSS_SALES_LR VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_CROSS_SALES_LR'';

V_DB_FFP_WRK_MS_PRDCT_EFF_V2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_MS_PRDCT_EFF_V2'';

V_DB_FFP_WRK_APPS_DT_4 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_APPS_DT_4'';

V_DB_FFP_WRK_MS_DVH_COMBO_APPS_2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_MS_DVH_COMBO_APPS_2'';

V_DB_FFP_WRK_ISDW_EFF_SALES VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_ISDW_EFF_SALES'';

V_DB_FFP_WRK_COMBO_APPS_FROM_MS VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_COMBO_APPS_FROM_MS'';

V_DB_FFP_WRK_DVH_AGT_DTL_ISDW_DEDUP VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_AGT_DTL_ISDW_DEDUP'';

V_DB_FFP_WRK_DVH_APPS_2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_APPS_2'';

V_DB_FFP_WRK_V_F_PREM_TRANS_DAY_SUBSET_A VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_V_F_PREM_TRANS_DAY_SUBSET_A'';

V_DB_FFP_WRK_DVH_CROSS_PRODUCT_APPS_3 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_CROSS_PRODUCT_APPS_3'';

V_DB_FFP_WRK_V_F_PREM_TRANS_DAY_SUBSET VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_V_F_PREM_TRANS_DAY_SUBSET'';

V_DB_FFP_WRK_APPS_DT_0_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_APPS_DT_0_1'';

V_DB_FFP_WRK_DVH_CROSS_PRODUCT_APPS VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_CROSS_PRODUCT_APPS'';

V_DB_FFP_MS_DVH_COMBO_DASHBOARD_SUMMARY VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_1, ''BDR_FFP_DA'') || ''.DVH_MS_DVH_COMBO_DASHBOARD_SUMMARY'';

V_DB_FFP_WRK_DVH_APPS VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_APPS'';

V_DB_FFP_WRK_MS_DVH_COMBO_APPS VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_MS_DVH_COMBO_APPS'';

V_DVH_MS_AND_COMBO_DVH_SALES VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_MS_AND_COMBO_DVH_SALES'';

V_DVH_P_LVL_CLAIM_INFO VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_P_LVL_CLAIM_INFO'';

V_DVH_MAX_UPDT_DT VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_MAX_UPDT_DT'';

V_DVH_P_LVL_CLAIM_INFO_V1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_P_LVL_CLAIM_INFO_V1'';

V_DVH_MS_AND_COMBO_DVH_SALES_LAPSE VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_MS_AND_COMBO_DVH_SALES_LAPSE'';

V_DVH_MS_AND_COMBO_DVH_SALES_LAPSE_V0 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_MS_AND_COMBO_DVH_SALES_LAPSE_V0'';

V_DVH_MS_AND_COMBO_DVH_SALES_LAPSE_V1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2,''BDR_FFP_DA_WRK'') || ''.DVH_MS_AND_COMBO_DVH_SALES_LAPSE_V1'';

V_DVH_MS_AND_COMBO_DVH_SALES_LAPSE_FINAL_DATA_NEW VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_1,''BDR_FFP_DA'') || ''.DVH_MS_AND_COMBO_DVH_SALES_LAPSE_FINAL_DATA_NEW'';


BEGIN

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP1'';

V_STEP_NAME :=  ''CREATE table DVH_APPS_DT_0'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_0) COPY GRANTS as 
select source_insured_plan_id, person_id,
application_id,
source_application_id, 
Rptg_EFFECTIVE_DATE,
APPL_RECEIPT_DATE,
((year(Rptg_EFFECTIVE_DATE)*100)+month(Rptg_EFFECTIVE_DATE)) as year_mon,
adjudication_status_code,
adjudication_status,
(case when Mktg_Chnl_grp in (''Unknown'', ''UNKNOWN'','''', ''DTC'') then ''DTC'' 
when Mktg_Chnl_grp = ''Agent Aggr'' then  ''Aggregator''
when Mktg_Chnl_grp = ''Agent FTF'' then ''Agent''
when Mktg_Chnl_grp = ''GRS'' then ''Employer'' else ''CHECK'' end) as Mktg_Chnl_grp,
response_id,
source_code,
RELATED_RESPONSE_ID,
rptg_adv_channel,
rptg_ad_type_name,
rptg_comm_medium_name,
rptg_component_desc,
rptg_portfolio_flag,
rptg_solicitation_category,
rptg_solicitation_channel,
enrollment_process,
max(b.paidsale) as paidsale,
max(b.sale) as sale,
max(b.app) as app,
MARKETING_CHANNEL,
STATE_CODE,
Mktg_Chnl_Dtl_grp,
Mktg_Chnl_Dtl,
Campaign_Grp,
RELATED_COMM_MEDIUM_NAME,
COMM_MEDIUM_NAME,
Mktg_Chnl_grp as Mktg_Chnl_grp_O,
ATTRIBUTION_TYPE,
campaign_name,
initiating_vendor_name,
ENROLLMENT_CALL_CENTER_SOURCE,
Enrollment,
(case when age_at_eff <64.11 then ''<64.11'' 
when age_at_eff >= 64.11 and  age_at_eff < 66 then ''64.11-65'' 
when (floor(age_at_eff) >65 and floor(age_at_eff) <=69) then ''66-69'' 
when (floor(age_at_eff) >69 and floor(age_at_eff) <=74) then ''70-74''
when (floor(age_at_eff) >74 and floor(age_at_eff) <=79) then ''75-79''
when floor(age_at_eff) >79  then ''80+''
end) as age,
(case when CAST(floor(MONTHS_BETWEEN(rptg_effective_date,birth_date)) AS INT) < 779 then ''Y'' else ''N'' end) as  disabled_sales_flag,
app_gender_code as gender,	
influence,
(case when CAST(floor(MONTHS_BETWEEN(medb_date,birth_date)) AS INT) < 779 then ''Y'' else ''N'' end) as PartB_eff_Age_Lessthan65,
plan_code,
rptg_adv_channel_grp,
rptg_response_id,
rptg_source_code,
(case when STATE_CODE in (''FL'',''GA'',''ID'',''MO'',''NH'') then ''Entry Age Rated''
when STATE_CODE in (''AS'',''AR'',''CT'',''GU'',''ME'',''MN'',''NY'',''VI'',''VT'',''WA'') then ''Community Rated''
else ''CREEED'' end) as st_group_rtng		
from IDENTIFIER(:V_refined_mpo_APPS_RPTG_DAILY) as b 
where b.appl_receipt_date>=''2023-09-29''
and Plan_Grp not in (''Rider'')
and MS_Insured_at_app = ''N''
group by source_insured_plan_id, person_id,
application_id,
source_application_id,
Rptg_EFFECTIVE_DATE,
APPL_RECEIPT_DATE,
adjudication_status_code,
adjudication_status,
((year(b.Rptg_EFFECTIVE_DATE)*100)+month(b.Rptg_EFFECTIVE_DATE)),
(case when b.Mktg_Chnl_grp in (''Unknown'', ''UNKNOWN'','''', ''DTC'') then ''DTC'' 
when b.Mktg_Chnl_grp = ''Agent Aggr'' then  ''Aggregator''
when b.Mktg_Chnl_grp = ''Agent FTF'' then ''Agent''
when b.Mktg_Chnl_grp = ''GRS'' then ''Employer'' else ''CHECK'' end),
response_id,
source_code,
RELATED_RESPONSE_ID,
rptg_adv_channel,
rptg_ad_type_name,
rptg_comm_medium_name,
rptg_component_desc,
rptg_portfolio_flag,
rptg_solicitation_category,
rptg_solicitation_channel,
enrollment_process,
MARKETING_CHANNEL,
STATE_CODE,
Mktg_Chnl_Dtl_grp,
Mktg_Chnl_Dtl,
Campaign_Grp,
RELATED_COMM_MEDIUM_NAME,
COMM_MEDIUM_NAME,
Mktg_Chnl_grp,
ATTRIBUTION_TYPE,
campaign_name,
initiating_vendor_name,
ENROLLMENT_CALL_CENTER_SOURCE,
Enrollment,
(case when age_at_eff <64.11 then ''<64.11'' 
when age_at_eff >= 64.11 and  age_at_eff < 66 then ''64.11-65'' 
when (floor(age_at_eff) >65 and floor(age_at_eff) <=69) then ''66-69'' 
when (floor(age_at_eff) >69 and floor(age_at_eff) <=74) then ''70-74''
when (floor(age_at_eff) >74 and floor(age_at_eff) <=79) then ''75-79''
when floor(age_at_eff) >79  then ''80+''
end),
(case when CAST(floor(MONTHS_BETWEEN(rptg_effective_date,birth_date)) AS INT) < 779 then ''Y'' else ''N'' end),
app_gender_code,	
influence,
(case when CAST(floor(MONTHS_BETWEEN(medb_date,birth_date)) AS INT) < 779 then ''Y'' else ''N'' end),
plan_code,
rptg_adv_channel_grp,
rptg_response_id,
rptg_source_code,
(case when STATE_CODE in (''FL'',''GA'',''ID'',''MO'',''NH'') then ''Entry Age Rated''
when STATE_CODE in (''AS'',''AR'',''CT'',''GU'',''ME'',''MN'',''NY'',''VI'',''VT'',''WA'') then ''Community Rated''
else ''CREEED'' end);

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_0)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

V_STEP := ''STEP2'';

V_STEP_NAME :=  ''create table dvh_sale_paid_key'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());				

create or replace table IDENTIFIER(:V_DB_FFP_WRK_SALE_PAID_KEY) COPY GRANTS as
select application_id, max(sale) as sale_fg, max(paidsale) as paidsale_fg
from IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_0) group by application_id;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_SALE_PAID_KEY)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP3'';

V_STEP_NAME :=  ''create table dvh_apps_dt_0_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_0_1) COPY GRANTS as
select a.*, b.sale_fg, b.paidsale_fg
from IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_0) a left join IDENTIFIER(:V_DB_FFP_WRK_SALE_PAID_KEY) b on a.application_id=b.application_id;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_0_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP4'';

V_STEP_NAME :=  ''create table dvh_apps_dt_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_1) COPY GRANTS as
select a.*,row_number() over (partition by a.person_id, a.rptg_effective_date order by a.appl_receipt_date desc) as rowNum
from IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_0) a
order by a.application_id, a.APPL_RECEIPT_DATE desc;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP5'';

V_STEP_NAME :=  ''create table dvh_apps_dt_1_0'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_1_0) COPY GRANTS as 
select a.*
from IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_1) a
where rowNum = 1;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_1_0)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP6'';

V_STEP_NAME :=  ''create table dvh_apps_dt_2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_2) COPY GRANTS as 
select a.*,
b.PROMOTION_CODE as app_PROMOTION_CODE
from IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_1_0) as a
left join IDENTIFIER(:V_REFINED_POLICY_APPLICATION) as b 
on a.APPLICATION_ID = b.APPLICATION_ID 
and a.person_id = b.person_id;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP7'';

V_STEP_NAME :=  ''create table dvh_apps_dt_3'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_3) COPY GRANTS as 
select a.*, 
b.agent_id as agt_id
from IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_2) a 
left join IDENTIFIER(:V_refined_policy_APPLICATION_AGENT) b 
on a.application_id = b.application_id;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP8'';

V_STEP_NAME :=  ''create table dvh_apps_dt_3_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_3_1) COPY GRANTS as
select a.*,row_number() over (partition by a.person_id, a.rptg_effective_date order by a.appl_receipt_date desc) as rowNum1
from IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_3) a
order by a.application_id, a.APPL_RECEIPT_DATE desc;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP9'';

V_STEP_NAME :=  ''create table dvh_apps_dt_3_2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_3_2) COPY GRANTS as 
select a.*
from IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_3_1) a
where rowNum1 = 1;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP10'';

V_STEP_NAME :=  ''create table dvh_apps_dt_4'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_4) COPY GRANTS as 
select a.*,b.pty_id ,b.ealliance_pref_nm 
from IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_3_2) as a 
left join (select distinct pty_id, agt_id,ealliance_pref_nm,ROW_EFF_STRT_DT from IDENTIFIER(:V_refined_isdw_ref_V_D_AGT)) as b 
on a.agt_id = b.agt_id;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP11'';

V_STEP_NAME :=  ''create table dvh_apps_dt_4_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_4_1) COPY GRANTS as
select a.*,row_number() over (partition by a.person_id, a.rptg_effective_date order by a.appl_receipt_date desc) as rowNum2
from IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_4) a
ORDER by a.application_id, a.APPL_RECEIPT_DATE desc;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP12'';

V_STEP_NAME :=  ''create table dvh_apps_dt_4_2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_4_2) COPY GRANTS as 
select a.*
from IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_4_1) a
where rowNum2 = 1;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP13'';

V_STEP_NAME :=  ''create table dvh_apps_dt_5'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_5)  COPY GRANTS as 
select *,
(case when trim(enrollment_process) in (''CUSTOMER MAILED APPLICATION'',''CUSTOMER BEGAN WEB ENROLL - MAILED APP'') then ''Cust Mailed''
when trim(enrollment_process) in (''TSR: APP ASSIST PHONE ENROLLMENT'', ''TSR:APP ASSIST DIGITAL ENROLLMENT'') then ''App Assist''
when trim(enrollment_process) in (''TSR: VOICE SIGNATURE PHONE ENROLLMENT'') then ''Voice Sign''
when trim(enrollment_process) in (''CUSTOMER WEB ENROLLMENT'') then ''Cust OLE''
when trim(enrollment_process) in (''TSR: PLAN CHANGE PHONE'',''OPERATIONS - PLAN CHANGE GENERATED VIA UI'',''AGENT FIELDS: PLAN CHANGE'') then ''Plan Change''
when trim(enrollment_process) in (''AGENT ELECTRONIC WEB ENROLLMENT'') then ''Aggr Web''
when trim(enrollment_process) in (''APP ASSIST - AGENT COVERAGE'') then ''Agent App Assist''
when trim(enrollment_process) in (''AGENT: MAILED APP'') then ''Agent Mailed''
when trim(enrollment_process) in (''AGENT: WEB ENROLLMENT'')  then ''Agent OLE''
when trim(enrollment_process) in (''OPERATIONS - UNKNOWN CHANNEL - GENERATED VIA UI'',''AGENT: CHANNEL UNK -  UI'') then ''Other''
when trim(enrollment_process) in (''INVALID'') then ''Other''
else ''CHECK'' end) as enrollment_type
from IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_4_2);

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP14'';

V_STEP_NAME :=  ''create table dvh_ealliance_map'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_EALLIANCE_MAP) COPY GRANTS as 
select pty_id,agt_id,e_alliance_partner_name,nickname,
(case when e_alliance_old_category in (''eAlliance - Retail'') then ''ealliance-Retail'' else e_alliance_old_category end) as e_alliance_old_category,
(case when e_alliance_new_category in (''eAlliance - Retail'') then ''ealliance-Retail'' else e_alliance_new_category end) as e_alliance_new_category
from IDENTIFIER(:V_common_ogs_EALLIANCE);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_EALLIANCE_MAP)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP15'';

V_STEP_NAME :=  ''create table dvh_apps_dt_5_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_5_1) COPY GRANTS as 
select a.*, b.e_alliance_old_category
from IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_5) a 
left join IDENTIFIER(:V_DB_FFP_WRK_EALLIANCE_MAP) b 
on a.pty_id = b.pty_id and a.agt_id = b.agt_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_5_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP16'';

V_STEP_NAME :=  ''create table dvh_apps_dt_6_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_6_1) COPY GRANTS as 
select *,
(case when agt_id in (''SQS3333'',''SQS4444'') then ''DTC''
when agt_id in (''SQS2222'',''GOH2222'',''INS2222'',''EHC2222'') then ''DTC''
when Mktg_Chnl_grp =''UNKNOWN'' then ''DTC''
when e_alliance_old_category <> '''' then e_alliance_old_category
when Mktg_Chnl_grp =''Aggregator'' and (e_alliance_old_category = '''' or e_alliance_old_category is null) then ''ealliance-Others'' 
else Mktg_Chnl_grp end) as mktng_channel
from IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_5_1);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_6_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP17'';

V_STEP_NAME :=  ''create table dvh_apps_dt_6_2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_6_2) COPY GRANTS as 
select *, 
(case when TRIM(SPLIT_PART(MARKETING_CHANNEL,''-'', 2)) = ''TELEQUOTE'' then ''E-TELEQUOTE'' else TRIM(SPLIT_PART(MARKETING_CHANNEL,''-'', 2)) end) as agt_nm
from IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_6_1);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_6_2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP18'';

V_STEP_NAME :=  ''create table dvh_tst1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_TST1) COPY GRANTS as 
select distinct LOWER(TRIM(e_alliance_partner_name)) as nm, e_alliance_old_category
from IDENTIFIER(:V_DB_FFP_WRK_EALLIANCE_MAP)
where e_alliance_old_category <> ''Lead Captive''
union 
select distinct LOWER(TRIM(nickname)) as nm, e_alliance_old_category
from IDENTIFIER(:V_DB_FFP_WRK_EALLIANCE_MAP)
where e_alliance_old_category <> ''Lead Captive'';


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_TST1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP19'';

V_STEP_NAME :=  ''create table dvh_apps_dt_6_3'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_6_3) COPY GRANTS as 
select a.*, b.nm, b.e_alliance_old_category as e_alliance_old_category_1
from IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_6_2) a 
left join (SELECT DISTINCT * from IDENTIFIER(:V_DB_FFP_WRK_TST1) where nm <> '''') b 
on LOWER(TRIM(a.agt_nm)) = b.nm;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_6_3)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP20'';

V_STEP_NAME :=  ''create table dvh_apps_dt_6'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_6) COPY GRANTS as 
select *,
(case when mktng_channel = ''ealliance-Others'' and nm <> ''''
then e_alliance_old_category_1 
else mktng_channel end) as mkt_chnl_2
from IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_6_3);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_6)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP21'';

V_STEP_NAME :=  ''create table dvh_apps_dt_0'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_0) COPY GRANTS as 
select *, 
(case when agt_id in (''SQS3333'',''SQS4444'') then ''SQS_VS'' 
when agt_id in (''SQS2222'',''GOH2222'',''INS2222'',''EHC2222'') then ''MA-Leads_Captives''
when TRIM(Enrollment) = ''Application Assistance'' and TRIM(ENROLLMENT_CALL_CENTER_SOURCE) = ''CSS'' then ''Optum AS''
when TRIM(Enrollment) = ''Application Assistance'' and TRIM(ENROLLMENT_CALL_CENTER_SOURCE) = ''UCC'' then ''UCC_AS''
when TRIM(Enrollment) = ''Voice Signature'' and TRIM(ENROLLMENT_CALL_CENTER_SOURCE) = ''CSS'' then ''Optum VS''
when TRIM(Enrollment) = ''Voice Signature'' and TRIM(ENROLLMENT_CALL_CENTER_SOURCE) = ''UCC'' then ''UCC_VS''
when mkt_chnl_2 = ''Agent'' and enrollment_type in (''Agent Mailed'', ''Agent OLE'') then enrollment_type
when mkt_chnl_2 = ''DTC'' and TRIM(Enrollment) = (''Customer Mailed App'') then ''Cust Mailed''
when mkt_chnl_2 = ''DTC'' and TRIM(Enrollment) = (''Customer OLE'') then ''Cust OLE''
when mkt_chnl_2 = ''ealliance-Classic'' and  TRIM(Enrollment) = (''Agent Aggr'') then ''Aggr Web''
when mkt_chnl_2 = ''ealliance-Retail'' and TRIM(Enrollment) = (''Agent Aggr'') then ''Aggr Web''
when mkt_chnl_2 = ''ealliance-Others'' then ''Others''
when mkt_chnl_2 = ''Employer'' and TRIM(Enrollment) = (''Customer Mailed App'') then ''Cust Mailed''
when mkt_chnl_2 = ''Employer'' and TRIM(Enrollment) = (''Customer OLE'') then ''Cust OLE''
else ''Others'' end) as sub_channel
from IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_6);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_0)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP22'';

V_STEP_NAME :=  ''create table dvh_apps_dt_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_1) COPY GRANTS as
select a.*,row_number() over (partition by a.person_id,a.rptg_effective_date order by a.appl_receipt_date desc) as rowNum0
from IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_0) a
ORDER by a.application_id, a.Rptg_EFFECTIVE_DATE desc;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP23'';

V_STEP_NAME :=  ''create table dvh_apps_dt_2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_2) as 
select a.*
from IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_1) a
where rowNum0 = 1;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP24'';

V_STEP_NAME :=  ''create table dvh_apps_smzd_daily_nodup_0'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_APPS_SMZD_DAILY_NODUP_0) COPY GRANTS as 
select *, 
(case when mkt_chnl_2 = ''Agent'' then ''Agent''
when mkt_chnl_2 = ''Employer'' then ''Employer''
when mkt_chnl_2 = ''ealliance-Retail'' then ''ealliance-Retail''
when mkt_chnl_2 = ''ealliance-Classic'' then ''ealliance-Classic''
when mkt_chnl_2 = ''ealliance-Others'' then ''ealliance-Others''
when mkt_chnl_2 = ''DTC'' and sub_channel in (''UCC_AS'',''UCC_VS'') then ''DTC-UCC''
when mkt_chnl_2 = ''DTC'' then concat(mkt_chnl_2,''-'',sub_channel) else ''chk'' end) as cat
from IDENTIFIER(:V_DB_FFP_WRK_APPS_DT_2);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_APPS_SMZD_DAILY_NODUP_0)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP25'';

V_STEP_NAME :=  ''create table dvh_apps_smzd_daily_nodup_final'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_APPS_SMZD_DAILY_NODUP_FINAL) COPY GRANTS as 
select a.*, 
(case when cat = ''Agent'' then ''Agent''
when cat = ''ealliance-Retail'' then ''ealliance-Retail''
when cat = ''ealliance-Classic'' then ''ealliance-Classic''
when cat = ''ealliance-Others'' then ''ealliance-Others''
when cat = ''Employer'' then ''Employer'' else ''DTC'' end) as marketing_channel_final,
(case when cat = ''DTC-Cust Mailed'' then  ''Cust Mailed''
when cat = ''DTC-Others'' then ''Others''
when cat = ''DTC-Cust OLE'' then ''Cust OLE''
when cat = ''DTC-MA-Leads_Captives'' then ''MA-Leads_Captives''
when cat = ''DTC-Optum AS'' then ''Optum AS''
when cat = ''DTC-Optum VS'' then ''Optum VS''
when cat = ''DTC-UCC'' then ''UCC'' 
when cat = ''DTC-SQS_VS'' then ''SQS VS''else '''' end) as sub_channel_final
from IDENTIFIER(:V_DB_FFP_WRK_APPS_SMZD_DAILY_NODUP_0) a;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_APPS_SMZD_DAILY_NODUP_FINAL)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP26'';

V_STEP_NAME :=  ''create table dvh_ms_apps_for_dvh_0'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_MS_APPS_FOR_DVH_0) COPY GRANTS as 
select b.ship_person_id as individual_id
	,a.source_insured_plan_id
	,a.person_id
	,a.application_id
	,a.source_application_id
	,a.rptg_effective_date
	,a.appl_receipt_date
	,a.year_mon
	,a.adjudication_status_code
	,a.adjudication_status
	,a.mktg_chnl_grp
	,a.response_id
	,a.source_code
	,a.related_response_id
	,a.rptg_adv_channel
	,a.rptg_ad_type_name
	,a.rptg_comm_medium_name
	,a.rptg_component_desc
	,a.rptg_portfolio_flag
	,a.rptg_solicitation_category
	,a.rptg_solicitation_channel
	,a.enrollment_process
	,a.paidsale
	,a.sale
	,a.app
	,a.marketing_channel
	,a.state_code
	,a.mktg_chnl_dtl_grp
	,a.mktg_chnl_dtl
	,a.campaign_grp
	,a.related_comm_medium_name
	,a.comm_medium_name
	,a.mktg_chnl_grp_o
	,a.attribution_type
	,a.campaign_name
	,a.initiating_vendor_name
	,a.enrollment_call_center_source
	,a.enrollment
	,a.age
	,a.disabled_sales_flag
	,a.gender
	,a.influence
	,a.partb_eff_age_lessthan65
	,a.plan_code
	,a.rptg_adv_channel_grp
	,a.rptg_response_id
	,a.rptg_source_code
	,a.st_group_rtng
	,a.app_promotion_code
	,a.agt_id
	,a.pty_id
	,a.ealliance_pref_nm
	,a.enrollment_type
	,a.e_alliance_old_category
	,a.mktng_channel
	,a.agt_nm
	,a.nm
	,a.e_alliance_old_category_1
	,a.mkt_chnl_2
	,a.sub_channel
	,a.cat
	,a.marketing_channel_final
	,a.sub_channel_final
from IDENTIFIER(:V_DB_FFP_WRK_APPS_SMZD_DAILY_NODUP_FINAL) a 
left join IDENTIFIER(:V_refined_party_SHIP_PERSON_XREF) b on a.person_id=b.person_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_MS_APPS_FOR_DVH_0)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP27'';

V_STEP_NAME :=  ''create table dvh_isdw_eff_sales'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_ISDW_EFF_SALES) COPY GRANTS as 
select floor(a11.prem_due_dt_id/100) as prem_due_mo_id,
	a13.LF_CATGY_NM,
	a13.PRDCT_SUB_GRP,
	a13.pln_lvl_desc,
	a13.PRDCT_TYP,
	a13.pln_typ,
	pln_grp,
	smart_prdct_typ_var,
	a14.ACQN_CHNL_LVL_1 as prdct_ACQN_CHNL_LVL_1,
	a17.ACQN_CHNL_LVL_1 as cert_ACQN_CHNL_LVL_1,
	a14.ACQN_CHNL_LVL_2 as prdct_ACQN_CHNL_LVL_2,
	a17.ACQN_CHNL_LVL_2 as cert_ACQN_CHNL_LVL_2,
	a12.CERT_ACTV_LVL_1_TXT,
	a13.PLN_LVL,
	a12.CERT_ACTV_LVL_2_TXT,
	undwr_pln_rqr_txt,
	undwr_prdct_rqr_txt,
	prem_due_age_id,
	a31.person_id as pers_id,
	a27.isid, 
	a27.INDV_ID,
	a30.rt_dtrm_cd_desc,
	a11.acct_nbr,
	floor(a11.cert_eff_dt_id) as cert_eff_mo_id,
	a11.d_mbr_info_sk,
	a11.COMPAS_INSD_PLN_ID,
	a11.D_LGL_ENTY_SK,
	floor(a11.prdct_eff_dt_id/100) as prdct_eff_mo_id,
	a27.MEDCR_ID as medicare_hicn_cd,
	a11.hsehld_id,
	sum(a11.PD_CERT_QTY + a11.DELQ_CERT_QTY) as mbr
from IDENTIFIER(:V_refined_isdw_prem_V_F_PREM_TRANS_DAY) a11         
left join IDENTIFIER(:V_refined_isdw_ref_V_D_CERT_ACTV) a12
	on (a11.D_CERT_ACTV_SK = a12.D_CERT_ACTV_SK)
left join IDENTIFIER(:V_refined_isdw_ref_V_D_PLN_BEN_MOD) a13
	on (a11.D_PLN_BEN_MOD_SK = a13.D_PLN_BEN_MOD_SK)
left join IDENTIFIER(:V_refined_isdw_ref_V_D_ACQN_CHNL) a14
	on (a11.PRDCT_D_ACQN_CHNL_SK = a14.D_ACQN_CHNL_SK)
left join IDENTIFIER(:V_refined_isdw_ref_V_D_ACQN_CHNL) a17
	on (a11.CERT_D_ACQN_CHNL_SK = a17.D_ACQN_CHNL_SK)   
left join IDENTIFIER(:V_refined_isdw_ref_V_D_UNDWR_TAG) a24
	on (a11.D_UNDWR_TAG_Sk = a24.D_UNDWR_TAG_Sk)
left join IDENTIFIER(:V_refined_isdw_ref_V_D_MBR_INFO) as a27
	on a11.d_mbr_info_sk = a27.d_mbr_info_sk
left join IDENTIFIER(:V_refined_isdw_ref_V_D_SURCHRG_TIER) as a30
	on a11.D_SURCHRG_TIER_sk = a30.D_SURCHRG_TIER_sk
left join IDENTIFIER(:V_refined_party_SHIP_PERSON_XREF) a31
	on a27.INDV_ID = a31.SHIP_PERSON_ID				  
where ((a11.prem_due_dt_id >= 20230901) 
and PRDCT_SUB_GRP in (''Med Supp Base'') 
and CERT_ACTV_LVL_1_TXT in (''NEW ENROLL ADD'')) 
group by floor(a11.prem_due_dt_id/100),
	a13.LF_CATGY_NM,
	a13.PRDCT_SUB_GRP,
	a13.pln_lvl_desc,
	a13.PRDCT_TYP,
	a13.pln_typ,
	pln_grp,
	smart_prdct_typ_var,
	a14.ACQN_CHNL_LVL_1,
	a17.ACQN_CHNL_LVL_1,
	a14.ACQN_CHNL_LVL_2,
	a17.ACQN_CHNL_LVL_2 ,
	a12.CERT_ACTV_LVL_1_TXT,
	a13.PLN_LVL,
	a12.CERT_ACTV_LVL_2_TXT,
	undwr_pln_rqr_txt,
	undwr_prdct_rqr_txt,
	prem_due_age_id,
	a31.person_id,
	a27.isid, 
	a27.INDV_ID,
	a30.rt_dtrm_cd_desc,
	a11.acct_nbr,
	floor(a11.cert_eff_dt_id),
	a11.d_mbr_info_sk,
	a11.hsehld_id,
	a11.COMPAS_INSD_PLN_ID,
	a11.D_LGL_ENTY_SK,
	floor(a11.prdct_eff_dt_id/100),
	a27.MEDCR_ID 
having (mbr >0);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_ISDW_EFF_SALES)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP28'';

V_STEP_NAME :=  ''create table dvh_ms_apps_for_dvh'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_MS_APPS_FOR_DVH) COPY GRANTS as 
select a.*, b.undwr_pln_rqr_txt, b.undwr_prdct_rqr_txt, b.rt_dtrm_cd_desc from IDENTIFIER(:V_DB_FFP_WRK_MS_APPS_FOR_DVH_0) a
left join IDENTIFIER(:V_DB_FFP_WRK_ISDW_EFF_SALES) b on a.source_insured_plan_id=b.compas_insd_pln_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_MS_APPS_FOR_DVH)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP29'';

V_STEP_NAME :=  ''create table dvh_dvh_apps'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_DVH_APPS) COPY GRANTS as 
select indv_id 
	,mdm_mbr_indv_id
	,mdm_mbr_match_ind
	,unique_id_policy_num 
	,mbr_fst_nm 
	,mbr_lst_nm 
	,appl_id
	,appl_st_cd
	,appl_st_desc
	,pln_cd
	,substr(pln_cd, 1,8) as pln_cd2
	,date(pln_effective_dt) as pln_effective_dt 
	,date(pln_term_dt) as pln_term_dt 
	,member_relationship
	,date(received_dt) as received_dt 
	,broker_id
	,agent_id
	,mbr_dob 
	,primary_addr_st_cd
	,issue_state
	,membership_active 
	,membership_productcode 
	,sum(premium_amount) as total_premium_amount
from IDENTIFIER(:V_refined_isdw_prem_V_FF_MPBU_SRC_INDV)
--FROM BDR_FFP_DA_WRK.DVH_FF_MPBU_SRC_INDV_DEEP
where date(received_dt) >= ''2023-09-29'' 
	and membership_active = ''Y''
	and upper(appl_id) like ''%MNR%'' 
group by indv_id 
	,mdm_mbr_indv_id
	,mdm_mbr_match_ind
	,unique_id_policy_num 
	,mbr_fst_nm 
	,mbr_lst_nm 
	,appl_id
	,appl_st_cd
	,appl_st_desc
	,pln_cd
	,substr(pln_cd, 1,8)
	,date(pln_effective_dt) 
	,date(pln_term_dt) 
	,member_relationship 
	,date(received_dt) 
	,broker_id
	,agent_id
	,mbr_dob 
	,primary_addr_st_cd
	,issue_state
	,membership_active 
	,membership_productcode;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_DVH_APPS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP30'';

V_STEP_NAME :=  ''create table dvh_dvh_apps_2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());	

create or replace table IDENTIFIER(:V_DB_FFP_WRK_DVH_APPS_2) COPY GRANTS as
SELECT * FROM 
(SELECT *, ROW_NUMBER() OVER (PARTITION BY indv_id, received_dt ORDER BY membership_active DESC,indv_id asc) AS rn 
FROM IDENTIFIER(:V_DB_FFP_WRK_DVH_APPS)) a WHERE rn=1;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_DVH_APPS_2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP31'';

V_STEP_NAME :=  ''create table dvh_dvh_apps_3'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_DVH_APPS_3) COPY GRANTS as
select a.*, b.marketing_plan_name from IDENTIFIER(:V_DB_FFP_WRK_DVH_APPS_2) a
left join IDENTIFIER(:V_refined_isdw_prem_FACETS_DENTAL_CROSSWALK) b on a.pln_cd2=b.facets_plan_code;



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_DVH_APPS_3)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP32'';

V_STEP_NAME :=  ''create table dvh_agt_party_id_map'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_DB_FFP_WRK_AGT_PARTY_ID_MAP) COPY GRANTS as
select distinct sra.agent_id, sra.party_id from IDENTIFIER(:V_refined_sra_EVERYTHING_BASE) sra
inner join (select distinct agent_id from IDENTIFIER(:V_DB_FFP_WRK_DVH_APPS_3)) dvh on sra.agent_id = dvh.agent_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_AGT_PARTY_ID_MAP)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP33'';

V_STEP_NAME :=  ''create table dvh_dvh_agent_dtl'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_DVH_AGENT_DTL) COPY GRANTS as
select wid_status, wid_end, sra.agent_id as sra_agent_id, party_id, agent_name, email, phone, state, suborg, agent_level_name, agency_name, 
	row_number() over (partition by party_id order by wid_status asc,party_id asc) as row_num
from IDENTIFIER(:V_refined_sra_EVERYTHING_BASE) sra
inner join (select distinct party_id as party_id_2 from IDENTIFIER(:V_DB_FFP_WRK_AGT_PARTY_ID_MAP)) dvh on sra.party_id = dvh.party_id_2
where date(wid_end) = ''2300-01-01'';


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_DVH_AGENT_DTL)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP34'';

V_STEP_NAME :=  ''create table dvh_dvh_agent_dtl_2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_DVH_AGENT_DTL_2) COPY GRANTS as
select * from IDENTIFIER(:V_DB_FFP_WRK_DVH_AGENT_DTL) where row_num=1;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_DVH_AGENT_DTL_2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP35'';

V_STEP_NAME :=  ''create table dvh_dvh_apps_4'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_DB_FFP_WRK_DVH_APPS_4) COPY GRANTS as
select dvh.*, agt.*  from IDENTIFIER(:V_DB_FFP_WRK_DVH_APPS_3) dvh 
left join IDENTIFIER(:V_DB_FFP_WRK_AGT_PARTY_ID_MAP) idmap on dvh.agent_id = idmap.agent_id
left join IDENTIFIER(:V_DB_FFP_WRK_DVH_AGENT_DTL_2) agt on idmap.party_id = agt.party_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_DVH_APPS_4)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP36'';

V_STEP_NAME :=  ''create table dvh_dvh_agt_dtl_isdw'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_DB_FFP_WRK_DVH_AGT_DTL_ISDW) COPY GRANTS as
select a.* from IDENTIFIER(:V_refined_isdw_ref_V_D_AGT) a
inner join (select distinct agent_id from IDENTIFIER(:V_DB_FFP_WRK_DVH_APPS_4)) b on a.agt_id = b.agent_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_DVH_AGT_DTL_ISDW)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP37'';

V_STEP_NAME :=  ''create table dvh_dvh_agt_dtl_isdw_dedup'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_DVH_AGT_DTL_ISDW_DEDUP) as
select * from 
(select a.*, ROW_NUMBER() over(partition by pty_id order by row_eff_end_dt desc,row_eff_strt_dt desc) as rownumber
from IDENTIFIER(:V_DB_FFP_WRK_DVH_AGT_DTL_ISDW) a) v
where rownumber =1;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_DVH_AGT_DTL_ISDW_DEDUP)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP38'';

V_STEP_NAME :=  ''create table dvh_dvh_agt_hierarchy'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_DVH_AGT_HIERARCHY) COPY GRANTS as
select a.agt_id, a.pty_id as party_id_isdw
	,coalesce(b.nma_type, b.fmo_type, b.mga_type, b.ga_type, null) as highest_upline_agent_role
	,coalesce(b.nma_name, b.fmo_name, b.mga_name, b.ga_name, null) as highest_upline_agent_name
	,coalesce(b.nma_id, b.fmo_id, b.mga_id, b.ga_id, null) as highest_upline_agent_id
	,coalesce(b.nma_party_id, b.fmo_party_id, b.mga_party_id, b.ga_party_id, null) as highest_upline_party_id
	,b.hierarchystatus
from IDENTIFIER(:V_DB_FFP_WRK_DVH_AGT_DTL_ISDW_DEDUP) a
left join IDENTIFIER(:V_ffp_agent_quality_wrk_AGENT_PROFILE) b on a.pty_id = b.pty_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_DVH_AGT_HIERARCHY)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP39'';

V_STEP_NAME :=  ''create table dvh_dvh_apps_5'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_DVH_APPS_5) COPY GRANTS as
select a.*
	,b.party_id_isdw
	,b.highest_upline_agent_role
	,b.highest_upline_agent_name
	,b.highest_upline_agent_id
	,b.highest_upline_party_id
	,b.hierarchystatus
from IDENTIFIER(:V_DB_FFP_WRK_DVH_APPS_4) a
left join IDENTIFIER(:V_DB_FFP_WRK_DVH_AGT_HIERARCHY) b 
on a.agent_id = b.agt_id ;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_DVH_APPS_5)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP40'';

V_STEP_NAME :=  ''create table dvh_ms_dvh_combo_apps'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_MS_DVH_COMBO_APPS) COPY GRANTS as
select ms.*
	,dvh.indv_id as dvh_indv_id
	,dvh.mdm_mbr_indv_id as dvh_mdm_mbr_indv_id
	,dvh.mdm_mbr_match_ind as dvh_mdm_mbr_match_ind
	,dvh.unique_id_policy_num as dvh_unique_id_policy_num
	,dvh.mbr_fst_nm as dvh_mbr_fst_nm
	,dvh.mbr_lst_nm as dvh_mbr_lst_nm
	,dvh.appl_id as dvh_appl_id
	,dvh.appl_st_cd as dvh_appl_st_cd
	,dvh.appl_st_desc as dvh_appl_st_desc
	,dvh.pln_cd as dvh_pln_cd
	,dvh.pln_cd2 as dvh_pln_cd2
	,dvh.pln_effective_dt as dvh_pln_effective_dt
	,dvh.pln_term_dt as dvh_pln_term_dt
	,dvh.member_relationship as dvh_member_relationship
	,dvh.received_dt as dvh_received_dt
	,dvh.broker_id as dvh_broker_id
	,dvh.agent_id as dvh_agent_id
	,dvh.mbr_dob as dvh_mbr_dob
	,dvh.primary_addr_st_cd as dvh_primary_addr_st_cd
	,dvh.issue_state as dvh_issue_state
	,dvh.membership_active as dvh_membership_active
	,dvh.membership_productcode as dvh_membership_productcode
	,dvh.marketing_plan_name as dvh_marketing_plan_name
	,total_premium_amount as dvh_premium_amount
	,wid_status 
	,wid_end
	,sra_agent_id
	,party_id
	,agent_name
	,email
	,phone
	,state
	,suborg
	,agent_level_name
	,agency_name
	,party_id_isdw
	,highest_upline_agent_role
	,highest_upline_agent_name
	,highest_upline_agent_id
	,highest_upline_party_id
	,hierarchystatus
	,case when dvh.mdm_mbr_indv_id is null then ''MS Only''
		when date(substr(ms.appl_receipt_date,0,10))=(dvh.received_dt) and date(ms.rptg_effective_date) = (dvh.pln_effective_dt) then ''same app same eff''
		when date(substr(ms.appl_receipt_date,0,10))=(dvh.received_dt) and date(ms.rptg_effective_date) != (dvh.pln_effective_dt) then ''same app diff eff''
		when date(substr(ms.appl_receipt_date,0,10))!=(dvh.received_dt) then ''diff app same eff''
	else ''check'' end combo_app_dt_fg
from IDENTIFIER(:V_DB_FFP_WRK_MS_APPS_FOR_DVH) ms
inner join IDENTIFIER(:V_DB_FFP_WRK_DVH_APPS_5) dvh on ms.individual_id = dvh.mdm_mbr_indv_id
and 
(
	(date(ms.rptg_effective_date) = (dvh.pln_effective_dt) and datediff(''day'',(dvh.received_dt),date(substr(ms.appl_receipt_date,0,10))) between -62 and 62)
	or 
	date(substr(ms.appl_receipt_date,0,10))=dvh.received_dt 
)
and ms.individual_id is not null;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_MS_DVH_COMBO_APPS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP41'';

V_STEP_NAME :=  ''create table dvh_ms_dvh_combo_apps_2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_MS_DVH_COMBO_APPS_2) COPY GRANTS as
SELECT * FROM 
(SELECT *, ROW_NUMBER() OVER (PARTITION BY individual_id,dvh_received_dt ORDER BY dvh_issue_state, individual_id asc ) AS rn2
FROM IDENTIFIER(:V_DB_FFP_WRK_MS_DVH_COMBO_APPS)) a WHERE rn2=1;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_MS_DVH_COMBO_APPS_2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP42'';

V_STEP_NAME :=  ''create table dvh_combo_apps_from_ms'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_COMBO_APPS_FROM_MS) COPY GRANTS as 
select a.*
	,b.dvh_indv_id
	,b.dvh_mdm_mbr_indv_id
	,b.dvh_mdm_mbr_match_ind
	,b.dvh_unique_id_policy_num
	,b.dvh_mbr_fst_nm
	,b.dvh_mbr_lst_nm
	,b.dvh_appl_id
	,b.dvh_appl_st_cd
	,b.dvh_appl_st_desc
	,b.dvh_pln_cd
	,b.dvh_pln_cd2
	,b.dvh_pln_effective_dt
	,b.dvh_pln_term_dt
	,b.dvh_member_relationship
	,b.dvh_received_dt
	,b.dvh_broker_id
	,b.dvh_agent_id
	,b.dvh_mbr_dob
	,b.dvh_primary_addr_st_cd
	,b.dvh_issue_state
	,b.dvh_membership_active
	,b.dvh_membership_productcode
	,b.dvh_marketing_plan_name
	,b.dvh_premium_amount
	,b.wid_status
	,b.wid_end
	,b.sra_agent_id
	,b.party_id
	,b.agent_name
	,b.email
	,b.phone
	,b.state
	,b.suborg
	,b.agent_level_name
	,b.agency_name
	,b.party_id_isdw
	,b.highest_upline_agent_role
	,b.highest_upline_agent_name
	,b.highest_upline_agent_id
	,b.highest_upline_party_id
	,b.hierarchystatus
	,case when b.application_id is null then ''MS Only''
		when date(substr(a.appl_receipt_date,0,10))=(b.dvh_received_dt) and date(a.rptg_effective_date) = (b.dvh_pln_effective_dt) then ''same app same eff''
		when date(substr(a.appl_receipt_date,0,10))=(b.dvh_received_dt) and date(a.rptg_effective_date) != (b.dvh_pln_effective_dt) then ''same app diff eff''
		when date(substr(a.appl_receipt_date,0,10))!=(b.dvh_received_dt) then ''diff app same eff''
	else ''check'' end combo_app_dt_fg
from IDENTIFIER(:V_DB_FFP_WRK_MS_APPS_FOR_DVH) a
left join IDENTIFIER(:V_DB_FFP_WRK_MS_DVH_COMBO_APPS_2) b on a.application_id = b.application_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_COMBO_APPS_FROM_MS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP43'';

V_STEP_NAME :=  ''create table dvh_ms_mbr_for_dvh_0'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_MS_MBR_FOR_DVH_0) COPY GRANTS as 
select a.*
		,date(coalesce(termination_date,''9999-12-31'')) as term_dt
        ,b.product_type_code, b.spec_type_code, b.plan_code, b.display_plan_code from IDENTIFIER(:V_refined_policy_INSURED_PLAN) a
inner join (select distinct specification_id, product_type_code, spec_type_code, plan_code, display_plan_code from IDENTIFIER(:V_REFINED_POLICY_SPECIFICATION)) b on a.specification_id=b.specification_id
where date(coalesce(a.termination_date,''9999-12-31''))>=''2023-09-29''
and (a.effective_date<>date(coalesce(a.termination_date,''9999-12-31'')))
and b.product_type_code = ''M'' and b.spec_type_code=''B'';


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_MS_MBR_FOR_DVH_0)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP44'';

V_STEP_NAME :=  ''create table dvh_ms_mbr_for_dvh_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_DB_FFP_WRK_MS_MBR_FOR_DVH_1) COPY GRANTS as 
select b.ship_person_id as individual_id
	,a.* 
from IDENTIFIER(:V_DB_FFP_WRK_MS_MBR_FOR_DVH_0) a
left join IDENTIFIER(:V_refined_party_SHIP_PERSON_XREF) b on a.person_id=b.person_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_MS_MBR_FOR_DVH_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP45'';

V_STEP_NAME :=  ''create table dvh_v_F_PREM_TRANS_DAY_subset_a'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_V_F_PREM_TRANS_DAY_SUBSET_A) COPY GRANTS as 
select PREM_DUE_DT_ID,acct_nbr,d_mbr_info_sk,COMPAS_INSD_PLN_ID,PD_CERT_QTY,DELQ_CERT_QTY,D_CERT_ACTV_SK,D_PLN_BEN_MOD_SK,PRDCT_D_ACQN_CHNL_SK,RES_D_GEO_XREF_SK,CERT_D_ACQN_CHNL_SK,D_GDR_ID_SK,agt_sel_orig_d_agt_sk,agt_ref_orig_d_agt_sk,prdct_eff_dt_id,prem_due_age_id,floor(PREM_DUE_DT_ID/100) as PREM_DUE_DT_ID_floor,floor(prdct_eff_dt_id/100) as prdct_eff_dt_id_floor
from IDENTIFIER(:V_refined_isdw_prem_V_F_PREM_TRANS_DAY); 


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_V_F_PREM_TRANS_DAY_SUBSET_A)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP46'';

V_STEP_NAME :=  ''create table dvh_v_F_PREM_TRANS_DAY_subset_b'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_V_F_PREM_TRANS_DAY_SUBSET_B) COPY GRANTS as 
select * from IDENTIFIER(:V_DB_FFP_WRK_V_F_PREM_TRANS_DAY_SUBSET_A)
where PREM_DUE_DT_ID_floor >= 202306; -- taking 3 months lag from sep 23 ms membership 

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_V_F_PREM_TRANS_DAY_SUBSET_B)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP47'';

V_STEP_NAME :=  ''create table dvh_v_F_PREM_TRANS_DAY_subset'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_V_F_PREM_TRANS_DAY_SUBSET) COPY GRANTS as 
select a.*
	,b.ACQN_CHNL_LVL_1 as prdct_ACQN_CHNL_LVL_1 
	,b.ACQN_CHNL_LVL_2 as prdct_ACQN_CHNL_LVL_2
from IDENTIFIER(:V_DB_FFP_WRK_V_F_PREM_TRANS_DAY_SUBSET_B) a
left join IDENTIFIER(:V_refined_isdw_ref_V_D_ACQN_CHNL) b
	on (a.PRDCT_D_ACQN_CHNL_SK = b.D_ACQN_CHNL_SK);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_V_F_PREM_TRANS_DAY_SUBSET)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP48'';

V_STEP_NAME :=  ''create table dvh_compas_plan_ids'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_DB_FFP_WRK_COMPAS_PLAN_IDS) COPY GRANTS as 
select distinct source_insured_plan_id from IDENTIFIER(:V_DB_FFP_WRK_MS_MBR_FOR_DVH_1);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_COMPAS_PLAN_IDS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP49'';

V_STEP_NAME :=  ''create table dvh_ms_prdct_eff'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_DB_FFP_WRK_MS_PRDCT_EFF) COPY GRANTS as 
select compas_insd_pln_id, prdct_eff_dt_id, prdct_ACQN_CHNL_LVL_1, prdct_ACQN_CHNL_LVL_2
from IDENTIFIER(:V_DB_FFP_WRK_V_F_PREM_TRANS_DAY_SUBSET) prem
inner join IDENTIFIER(:V_DB_FFP_WRK_COMPAS_PLAN_IDS) on prem.compas_insd_pln_id = source_insured_plan_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_MS_PRDCT_EFF)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP50'';

V_STEP_NAME :=  ''create table dvh_ms_prdct_eff_v1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_DB_FFP_WRK_MS_PRDCT_EFF_V1) COPY GRANTS as 
select distinct compas_insd_pln_id, prdct_eff_dt_id, prdct_ACQN_CHNL_LVL_1 from IDENTIFIER(:V_DB_FFP_WRK_MS_PRDCT_EFF);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_MS_PRDCT_EFF_V1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP51'';

V_STEP_NAME :=  ''create table dvh_ms_prdct_eff_v2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_MS_PRDCT_EFF_V2) COPY GRANTS as 
select * from 
        (
        select *, 
        row_number() over (partition by compas_insd_pln_id order by prdct_eff_dt_id desc) as rn
        from IDENTIFIER(:V_DB_FFP_WRK_MS_PRDCT_EFF_V1) a
        ) a
where rn=1
and prdct_eff_dt_id<>-1;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_MS_PRDCT_EFF_V2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP52'';

V_STEP_NAME :=  ''create table dvh_ms_mbr_for_dvh_2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_DB_FFP_WRK_MS_MBR_FOR_DVH_2) COPY GRANTS as
select a.*, b.prdct_eff_dt_id, prdct_acqn_chnl_lvl_1 from IDENTIFIER(:V_DB_FFP_WRK_MS_MBR_FOR_DVH_1) a 
left join IDENTIFIER(:V_DB_FFP_WRK_MS_PRDCT_EFF_V2) b on source_insured_plan_id=compas_insd_pln_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_MS_MBR_FOR_DVH_2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP53'';

V_STEP_NAME :=  ''create table dvh_ms_mbr_for_dvh_3'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_MS_MBR_FOR_DVH_3) COPY GRANTS as
select *, 
        case when prdct_eff_dt_id is null then effective_date        
        else cast(concat(substr(prdct_eff_dt_id,1,4), ''-'', substr(prdct_eff_dt_id,5,2), ''-'',1 ) as date) end as prdct_eff_dt,
        case when prdct_eff_dt_id is null then 0 else 1 end as eff_dt_fg
from IDENTIFIER(:V_DB_FFP_WRK_MS_MBR_FOR_DVH_2);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_MS_MBR_FOR_DVH_3)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP54'';

V_STEP_NAME :=  ''create table dvh_ms_mbr_for_dvh'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_MS_MBR_FOR_DVH) COPY GRANTS as 
select * from 
        (
        select *, 
        row_number() over (partition by person_id, prdct_eff_dt order by term_dt desc) as rn
        from IDENTIFIER(:V_DB_FFP_WRK_MS_MBR_FOR_DVH_3) a
        ) a
where rn=1;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_MS_MBR_FOR_DVH)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP55'';

V_STEP_NAME :=  ''create table dvh_dvh_cross_product_apps'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_DVH_CROSS_PRODUCT_APPS) COPY GRANTS as
select 
	dvh.indv_id as dvh_indv_id
	,dvh.appl_id as dvh_appl_id
	,dvh.pln_cd as dvh_pln_cd
	,date(dvh.pln_effective_dt) as dvh_pln_effective_dt 
	,date(dvh.pln_term_dt) as dvh_pln_term_dt 
	,date(dvh.received_dt) as dvh_received_dt 
	,dvh.broker_id as dvh_broker_id
	,dvh.agent_id as dvh_agent_id
	,dvh.primary_addr_st_cd as dvh_primary_addr_st_cd
	,dvh.issue_state as dvh_issue_state
	,dvh.membership_productcode as dvh_membership_productcode 
	,ms.* 
from IDENTIFIER(:V_DB_FFP_WRK_MS_MBR_FOR_DVH) ms 
inner join IDENTIFIER(:V_DB_FFP_WRK_DVH_APPS_5) dvh on ms.individual_id = dvh.mdm_mbr_indv_id 
and date(dvh.received_dt) between ms.effective_date and ms.term_dt
and date(dvh.pln_effective_dt)!=ms.effective_date;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_DVH_CROSS_PRODUCT_APPS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP56'';

V_STEP_NAME :=  ''create table dvh_dvh_cross_product_apps_2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_DVH_CROSS_PRODUCT_APPS_2) COPY GRANTS as
SELECT * FROM 
(SELECT *, ROW_NUMBER() OVER (PARTITION BY individual_id, dvh_received_dt ORDER BY display_plan_code,individual_id) AS rn2 
FROM IDENTIFIER(:V_DB_FFP_WRK_DVH_CROSS_PRODUCT_APPS)) a WHERE rn2=1;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_DVH_CROSS_PRODUCT_APPS_2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP57'';

V_STEP_NAME :=  ''create table dvh_dvh_cross_product_apps_3'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_DB_FFP_WRK_DVH_CROSS_PRODUCT_APPS_3) COPY GRANTS as
SELECT a.*, b.state_code FROM IDENTIFIER(:V_DB_FFP_WRK_DVH_CROSS_PRODUCT_APPS_2) a 
left join IDENTIFIER(:V_refined_location_ZIP_CODE) b on a.zip_code = b.zip_code;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_DVH_CROSS_PRODUCT_APPS_3)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP58'';

V_STEP_NAME :=  ''create table dvh_dvh_apps_summary'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_DVH_APPS_SUMMARY) COPY GRANTS as
select 
	b.individual_id
	,b.person_id
	,b.application_id
	,b.source_application_id
	,b.rptg_effective_date
	,b.appl_receipt_date
	,b.year_mon
	,b.adjudication_status_code
	,b.adjudication_status
	,b.mktg_chnl_grp
	,b.response_id
	,b.source_code
	,b.related_response_id
	,b.rptg_adv_channel
	,b.rptg_ad_type_name
	,b.rptg_comm_medium_name
	,b.rptg_component_desc
	,b.rptg_portfolio_flag
	,b.rptg_solicitation_category
	,b.rptg_solicitation_channel
	,b.enrollment_process
	,b.paidsale
	,b.sale
	,b.app
	,b.marketing_channel
	,b.state_code
	,b.mktg_chnl_dtl_grp
	,b.mktg_chnl_dtl
	,b.campaign_grp
	,b.related_comm_medium_name
	,b.comm_medium_name
	,b.mktg_chnl_grp_o
	,b.attribution_type
	,b.campaign_name
	,b.initiating_vendor_name
	,b.enrollment_call_center_source
	,b.enrollment
	,b.age
	,b.disabled_sales_flag
	,b.gender
	,b.influence
	,b.partb_eff_age_lessthan65
	,b.plan_code
	,b.rptg_adv_channel_grp
	,b.rptg_response_id
	,b.rptg_source_code
	,b.st_group_rtng
	,b.app_promotion_code
	,b.agt_id
	,b.pty_id
	,b.ealliance_pref_nm
	,b.enrollment_type
	,b.e_alliance_old_category
	,b.mktng_channel
	,b.agt_nm
	,b.nm
	,b.e_alliance_old_category_1
	,b.mkt_chnl_2
	,b.sub_channel
	,b.cat
	,case when b.individual_id is not null then b.marketing_channel_final
		when c.individual_id is not null then c.prdct_acqn_chnl_lvl_1
	else null end as marketing_channel_final
	,b.sub_channel_final
	,b.undwr_pln_rqr_txt
	,b.undwr_prdct_rqr_txt
	,b.rt_dtrm_cd_desc
	,a.*
	,b.combo_app_dt_fg
	, 
	case when b.individual_id is not null then ''Combo''
		when c.individual_id is not null then ''Cross''
	else ''DVH only'' end as combo_cross_fg
	,
	case when b.individual_id is not null then b.plan_code
		when c.individual_id is not null then c.plan_code
	else ''DVH only'' end as combo_cross_pln
	,
	case when b.individual_id is not null then b.state_code
		when c.individual_id is not null then c.state_code
	else ''DVH only'' end as combo_cross_st	
	,c.prdct_eff_dt as ms_prdct_eff_dt
	,case when c.individual_id is null then ''NA''		
		when c.dvh_received_dt >= add_months(c.prdct_eff_dt,0) and c.dvh_received_dt < add_months(c.prdct_eff_dt,1) then ''0-1 month''
		when c.dvh_received_dt >= add_months(c.prdct_eff_dt,1) and c.dvh_received_dt < add_months(c.prdct_eff_dt,2) then ''1-2 months''
		when c.dvh_received_dt >= add_months(c.prdct_eff_dt,2) and c.dvh_received_dt < add_months(c.prdct_eff_dt,3) then ''2-3 months''
		when c.dvh_received_dt >= add_months(c.prdct_eff_dt,3) and c.dvh_received_dt < add_months(c.prdct_eff_dt,4) then ''3-4 months''
		when c.dvh_received_dt >= add_months(c.prdct_eff_dt,4) and c.dvh_received_dt < add_months(c.prdct_eff_dt,5) then ''4-5 months''
		when c.dvh_received_dt >= add_months(c.prdct_eff_dt,5) and c.dvh_received_dt < add_months(c.prdct_eff_dt,6) then ''5-6 months''
		when c.dvh_received_dt >= add_months(c.prdct_eff_dt,6) and c.dvh_received_dt < add_months(c.prdct_eff_dt,7) then ''6-7 months''
		when c.dvh_received_dt >= add_months(c.prdct_eff_dt,7) and c.dvh_received_dt < add_months(c.prdct_eff_dt,8) then ''7-8 months''
		when c.dvh_received_dt >= add_months(c.prdct_eff_dt,8) and c.dvh_received_dt < add_months(c.prdct_eff_dt,9) then ''8-9 months''
		when c.dvh_received_dt >= add_months(c.prdct_eff_dt,9) and c.dvh_received_dt < add_months(c.prdct_eff_dt,10) then ''9-10 months''
		when c.dvh_received_dt >= add_months(c.prdct_eff_dt,10) and c.dvh_received_dt < add_months(c.prdct_eff_dt,11) then ''10-11 months''
		when c.dvh_received_dt >= add_months(c.prdct_eff_dt,11) and c.dvh_received_dt < add_months(c.prdct_eff_dt,12) then ''11-12 months''
				
		when c.dvh_received_dt >= add_months(c.prdct_eff_dt,12) and c.dvh_received_dt < add_months(c.prdct_eff_dt,24) then ''1-2 Years''
		when c.dvh_received_dt >= add_months(c.prdct_eff_dt,24) and c.dvh_received_dt < add_months(c.prdct_eff_dt,36) then ''2-3 Years''
		when c.dvh_received_dt >= add_months(c.prdct_eff_dt,36) and c.dvh_received_dt < add_months(c.prdct_eff_dt,48) then ''3-4 Years''
		when c.dvh_received_dt >= add_months(c.prdct_eff_dt,48) and c.dvh_received_dt < add_months(c.prdct_eff_dt,60) then ''4-5 Years''
		when c.dvh_received_dt >= add_months(c.prdct_eff_dt,60) and c.dvh_received_dt < add_months(c.prdct_eff_dt,120) then ''5-10 Years''
		when c.dvh_received_dt >= add_months(c.prdct_eff_dt,120) then ''10+ Years''

	else ''Check'' end as tenure_in_MS
	
from IDENTIFIER(:V_DB_FFP_WRK_DVH_APPS_5) a
left join IDENTIFIER(:V_DB_FFP_WRK_MS_DVH_COMBO_APPS_2) b  
	on a.mdm_mbr_indv_id = b.individual_id and date(a.received_dt)=b.dvh_received_dt
left join (select distinct individual_id,plan_code,display_plan_code,dvh_received_dt,state_code,prdct_eff_dt, prdct_acqn_chnl_lvl_1 from IDENTIFIER(:V_DB_FFP_WRK_DVH_CROSS_PRODUCT_APPS_3)) c 
	on a.mdm_mbr_indv_id = c.individual_id and date(a.received_dt)=c.dvh_received_dt;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_DVH_APPS_SUMMARY)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP59'';

V_STEP_NAME :=  ''create table dvh_cross_sales_ids'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_CROSS_SALES_IDS) COPY GRANTS as
select distinct mdm_mbr_indv_id, received_dt, trunc(received_dt, ''month'') as received_month from IDENTIFIER(:V_DB_FFP_WRK_DVH_APPS_SUMMARY) where combo_cross_fg = ''Cross'';


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_CROSS_SALES_IDS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP60'';

V_STEP_NAME :=  ''create table dvh_cross_sales_lr'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DB_FFP_WRK_CROSS_SALES_LR) COPY GRANTS as 
select a.mdm_mbr_indv_id, a.received_dt, a.received_month
	,sum(b.paid_prem) as paid_prem
	,sum(b.claim) as claim
from IDENTIFIER(:V_DB_FFP_WRK_CROSS_SALES_IDS) a
left join IDENTIFIER(:V_ffp_inforce_lr_P_LVL_CLAIM_INFO) b
  on  a.mdm_mbr_indv_id = b.indv_id
  and add_months(received_month,-12) <= prem_due_dt 
  and prem_due_dt < received_month
group by a.mdm_mbr_indv_id, a.received_dt, a.received_month;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_CROSS_SALES_LR)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP61'';

V_STEP_NAME :=  ''create table DVH_APPS_SUMMARY_FINAL'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_DB_FFP_WRK_DVH_APPS_SUMMARY_FINAL) COPY GRANTS as
select a.*, b.paid_prem, b.claim from IDENTIFIER(:V_DB_FFP_WRK_DVH_APPS_SUMMARY) a
left join IDENTIFIER(:V_DB_FFP_WRK_CROSS_SALES_LR) b 
on a.mdm_mbr_indv_id = b.mdm_mbr_indv_id 
and a.received_dt = b.received_dt 
and a.combo_cross_fg = ''Cross'';


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_DVH_APPS_SUMMARY_FINAL)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP62'';

V_STEP_NAME :=  ''create table dvh_ms_dvh_combo_unioned'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_DB_FFP_WRK_MS_DVH_COMBO_UNIONED) COPY GRANTS as
select ''MS'' as ms_dvh_app_fg 
	,individual_id
	,person_id
	,application_id
	,source_application_id
	,rptg_effective_date
	,appl_receipt_date
	,year_mon
	,adjudication_status_code
	,adjudication_status
	,mktg_chnl_grp
	,response_id
	,source_code
	,related_response_id
	,rptg_adv_channel
	,rptg_ad_type_name
	,rptg_comm_medium_name
	,rptg_component_desc
	,rptg_portfolio_flag
	,rptg_solicitation_category
	,rptg_solicitation_channel
	,enrollment_process
	,paidsale
	,sale
	,app
	,marketing_channel
	,state_code
	,mktg_chnl_dtl_grp
	,mktg_chnl_dtl
	,campaign_grp
	,related_comm_medium_name
	,comm_medium_name
	,mktg_chnl_grp_o
	,attribution_type
	,campaign_name
	,initiating_vendor_name
	,enrollment_call_center_source
	,enrollment
	,age
	,disabled_sales_flag
	,gender
	,influence
	,partb_eff_age_lessthan65
	,plan_code
	,rptg_adv_channel_grp
	,rptg_response_id
	,rptg_source_code
	,st_group_rtng
	,app_promotion_code
	,agt_id
	,pty_id
	,ealliance_pref_nm
	,enrollment_type
	,e_alliance_old_category
	,mktng_channel
	,agt_nm
	,nm
	,e_alliance_old_category_1
	,mkt_chnl_2
	,sub_channel
	,cat
	,marketing_channel_final
	,sub_channel_final
	,undwr_pln_rqr_txt
	,undwr_prdct_rqr_txt
	,rt_dtrm_cd_desc
	
	,dvh_indv_id
	,dvh_mdm_mbr_indv_id
	,dvh_mdm_mbr_match_ind
	,dvh_unique_id_policy_num
	,dvh_mbr_fst_nm
	,dvh_mbr_lst_nm
	,dvh_appl_id
	,dvh_appl_st_cd
	,dvh_appl_st_desc
	,dvh_pln_cd
	,dvh_pln_cd2
	,dvh_pln_effective_dt
	,dvh_pln_term_dt
	,dvh_member_relationship
	,dvh_received_dt
	,dvh_broker_id
	,dvh_agent_id
	,dvh_mbr_dob
	,dvh_primary_addr_st_cd
	,dvh_issue_state
	,dvh_membership_active
	,dvh_membership_productcode
	,dvh_premium_amount
	,dvh_marketing_plan_name
	,wid_status
	,wid_end
	,sra_agent_id
	,party_id
	,agent_name
	,email
	,phone
	,state
	,suborg
	,agent_level_name
	,agency_name

	,party_id_isdw
	,highest_upline_agent_role
	,highest_upline_agent_name
	,highest_upline_agent_id
	,highest_upline_party_id
	,hierarchystatus
	
	,combo_app_dt_fg
	,case when combo_app_dt_fg in (''same app same eff'',''same app diff eff'',''diff app same eff'') then ''Combo''
		when combo_app_dt_fg in (''MS Only'') then ''MS Only''
	else ''Check'' end as combo_cross_fg
	,plan_code as combo_cross_pln
	,state_code as combo_cross_st
	,null as tenure_in_ms
	,null as paid_prem
	,null as claim
	,1 as app_cnt
from IDENTIFIER(:V_DB_FFP_WRK_COMBO_APPS_FROM_MS)

union all

select ''DVH'' as ms_dvh_app_fg 
	
	,individual_id
	,person_id
	,application_id
	,source_application_id
	,rptg_effective_date
	,appl_receipt_date
	,year_mon
	,adjudication_status_code
	,adjudication_status
	,mktg_chnl_grp
	,response_id
	,source_code
	,related_response_id
	,rptg_adv_channel
	,rptg_ad_type_name
	,rptg_comm_medium_name
	,rptg_component_desc
	,rptg_portfolio_flag
	,rptg_solicitation_category
	,rptg_solicitation_channel
	,enrollment_process
	,paidsale
	,sale
	,app
	,marketing_channel
	,state_code
	,mktg_chnl_dtl_grp
	,mktg_chnl_dtl
	,campaign_grp
	,related_comm_medium_name
	,comm_medium_name
	,mktg_chnl_grp_o
	,attribution_type
	,campaign_name
	,initiating_vendor_name
	,enrollment_call_center_source
	,enrollment
	,age
	,disabled_sales_flag
	,gender
	,influence
	,partb_eff_age_lessthan65
	,plan_code
	,rptg_adv_channel_grp
	,rptg_response_id
	,rptg_source_code
	,st_group_rtng
	,app_promotion_code
	,agt_id
	,pty_id
	,ealliance_pref_nm
	,enrollment_type
	,e_alliance_old_category
	,mktng_channel
	,agt_nm
	,nm
	,e_alliance_old_category_1
	,mkt_chnl_2
	,sub_channel
	,cat
	,marketing_channel_final
	,sub_channel_final
	,undwr_pln_rqr_txt
	,undwr_prdct_rqr_txt
	,rt_dtrm_cd_desc
	
	,indv_id
	,mdm_mbr_indv_id
	,mdm_mbr_match_ind
	,unique_id_policy_num
	,mbr_fst_nm
	,mbr_lst_nm
	,appl_id
	,appl_st_cd
	,appl_st_desc
	,pln_cd
	,pln_cd2
	,pln_effective_dt
	,pln_term_dt
	,member_relationship
	,received_dt
	,broker_id
	,agent_id
	,mbr_dob
	,primary_addr_st_cd
	,issue_state
	,membership_active
	,membership_productcode
	,total_premium_amount
	,marketing_plan_name
	,wid_status
	,wid_end
	,sra_agent_id
	,party_id
	,agent_name
	,email
	,phone
	,state
	,suborg
	,agent_level_name
	,agency_name

	,party_id_isdw
	,highest_upline_agent_role
	,highest_upline_agent_name
	,highest_upline_agent_id
	,highest_upline_party_id
	,hierarchystatus
		
	,combo_app_dt_fg
	,combo_cross_fg
	,combo_cross_pln
	,combo_cross_st
	,tenure_in_ms
	,paid_prem
	,claim
	,1 as app_cnt
from IDENTIFIER(:V_DB_FFP_WRK_DVH_APPS_SUMMARY_FINAL);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_WRK_MS_DVH_COMBO_UNIONED)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP63'';

V_STEP_NAME :=  ''create table dvh_ms_dvh_combo_dashboard_summary'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_DB_FFP_MS_DVH_COMBO_DASHBOARD_SUMMARY) COPY GRANTS as
select *,
	case when combo_cross_pln = ''DVH only'' then ''DVH only''
		when combo_cross_pln in (''F'',''F01'',''FS1'',''F02'',''FS2'') then ''F''
		when combo_cross_pln in (''G'',''G01'',''GS1'',''G02'',''GS2'')  then ''G''
		when combo_cross_pln in (''GH1'',''GH2'')  then ''GH''
		when combo_cross_pln in (''N'',''N01'',''NS1'',''N02'',''NS2'') then ''N''
	else ''Others'' end as ms_plan_name
	
	,case when combo_cross_pln = ''DVH only'' then ''DVH only''
		when combo_cross_pln like ''%02'' then ''NLE''
		when combo_cross_pln like ''%S2'' then ''NLE''
		when combo_cross_pln like ''%GH2'' then ''NLE''
	else ''ELE'' end as ms_legal_entity
	
	,case when ms_dvh_app_fg = ''MS'' and appl_receipt_date >= ''2024-03-26'' and state_code in (''AK'', ''AL'', ''HI'', ''KS'', ''MS'', ''NC'', ''NE'', ''SD'', ''TN'', ''WY'') then ''DVH State''
		when ms_dvh_app_fg = ''MS'' and state_code in (''AZ'', ''CA'', ''FL'', ''GA'', ''IL'', ''IN'', ''KY'', ''MI'', ''MO'', ''NV'', ''OH'', ''PA'', ''TX'', ''WI'') then ''DVH State''

		when ms_dvh_app_fg = ''DVH'' and dvh_received_dt  >= ''2024-03-26'' and dvh_issue_state in (''AK'', ''AL'', ''HI'', ''KS'', ''MS'', ''NC'', ''NE'', ''SD'', ''TN'', ''WY'') then ''DVH State''
		when ms_dvh_app_fg = ''DVH'' and dvh_issue_state in (''AZ'', ''CA'', ''FL'', ''GA'', ''IL'', ''IN'', ''KY'', ''MI'', ''MO'', ''NV'', ''OH'', ''PA'', ''TX'', ''WI'') then ''DVH State''
	
		else ''Non-DVH State'' end as state_category
	
	,(case when UNDWR_PLN_RQR_TXT is null then null
		when UNDWR_PLN_RQR_TXT = ''Default'' then ''Default''
        when UNDWR_PLN_RQR_TXT = ''Not U/W - Open Enrollment'' then ''OE''
        when UNDWR_PLN_RQR_TXT = ''Not U/W - Plan Change'' then ''Plan Change''
        when UNDWR_PLN_RQR_TXT = ''Not U/W Guaranteed Issue Reason not specified'' then ''GI''
        else ''UW'' end) as UW_PLN_RQR_TXT
        
	,(case when UNDWR_PRDCT_RQR_TXT is null then null
		when UNDWR_PRDCT_RQR_TXT = ''Default'' then ''Default''
		when UNDWR_PRDCT_RQR_TXT = ''Not U/W - Open Enrollment'' then ''OE''
		when UNDWR_PRDCT_RQR_TXT = ''Not U/W - Plan Change'' then ''Plan Change''
		when UNDWR_PRDCT_RQR_TXT = ''Not U/W Guaranteed Issue Reason not specified'' then ''GI''
		else ''UW'' end) as UW_PRDCT_RQR_TXT
	
from IDENTIFIER(:V_DB_FFP_WRK_MS_DVH_COMBO_UNIONED);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DB_FFP_MS_DVH_COMBO_DASHBOARD_SUMMARY)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP64'';

V_STEP_NAME :=  ''create table dvh_MS_and_Combo_DVH_sales'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_DVH_MS_AND_COMBO_DVH_SALES) COPY GRANTS as
select
	*
from
	IDENTIFIER(:V_DB_FFP_MS_DVH_COMBO_DASHBOARD_SUMMARY)
where
	combo_app_dt_fg is not null -- Combo apps and MS Only apps
and paidsale = 1 -- To get paid sale
and rptg_effective_date >= ''2023-10-01'' and rptg_effective_date <= ''2025-04-01'' -- Update each month
and ms_dvh_app_fg = ''MS''
and app > 0
;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DVH_MS_AND_COMBO_DVH_SALES)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP65'';

V_STEP_NAME :=  ''create table dvh_MS_and_Combo_DVH_sales'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_DVH_P_LVL_CLAIM_INFO) COPY GRANTS as
select
	pers_id
	,d_mbr_info_sk
	,prdct_eff_dt
	,max(prem_due_mo_id) as max_prem_due_mo
from
	IDENTIFIER(:V_FFP_INFORCE_LR_P_LVL_CLAIM_INFO)
where
	prdct_eff_dt >= ''2023-06-01''
group by
	pers_id
	,d_mbr_info_sk
	,prdct_eff_dt
;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DVH_P_LVL_CLAIM_INFO)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

V_STEP := ''STEP66'';

V_STEP_NAME :=  ''create table V_DVH_MAX_UPDT_DT'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_DVH_MAX_UPDT_DT) COPY GRANTS as
select
	max(prem_due_dt) as updt_dt
from IDENTIFIER(:V_FFP_INFORCE_LR_P_LVL_CLAIM_INFO)
;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DVH_MAX_UPDT_DT)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP67'';

V_STEP_NAME :=  ''create table V_DVH_P_LVL_CLAIM_INFO_V1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_DVH_P_LVL_CLAIM_INFO_V1) COPY GRANTS as
select
	a.*
	,b.updt_dt
from
	IDENTIFIER(:V_DVH_P_LVL_CLAIM_INFO) a
join
	IDENTIFIER(:V_DVH_MAX_UPDT_DT) b
;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DVH_P_LVL_CLAIM_INFO_V1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP68'';

V_STEP_NAME :=  ''create table V_DVH_MS_AND_COMBO_DVH_SALES_LAPSE'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_DVH_MS_AND_COMBO_DVH_SALES_LAPSE) COPY GRANTS as
select
	a.*
	,case
		when b.pers_id is not null and (month(b.updt_dt) != month(current_date) and b.max_prem_due_mo = concat(substr(trunc(add_months(current_date,-1),''MM''),1,4),substr(trunc(add_months(current_date,-1),''MM''),6,2))) then 219912
		when b.pers_id is not null and (month(b.updt_dt) = month(current_date) and b.max_prem_due_mo = concat(substr(trunc(current_date,''MM''),1,4),substr(trunc(current_date,''MM''),6,2))) then 219912
		when b.pers_id is not null and (month(b.updt_dt) != month(current_date) and b.max_prem_due_mo != concat(substr(trunc(add_months(current_date,-1),''MM''),1,4),substr(trunc(add_months(current_date,-1),''MM''),6,2))) then max_prem_due_mo
		when b.pers_id is not null and (month(b.updt_dt) = month(current_date) and b.max_prem_due_mo != concat(substr(trunc(current_date,''MM''),1,4),substr(trunc(current_date,''MM''),6,2))) then max_prem_due_mo
	 end as isdw_Term_Dt
	,case when a.rptg_effective_date = c.termination_date then ''Y'' else ''N'' end as Same_Eff_Term_Fg_SMART
--	,case when b.pers_id is not null then ''Y'' else ''N'' end as MS_Lapse_Fg
	,case when dvh_pln_term_dt is not null and combo_cross_fg = ''Combo'' then ''Y'' else ''N'' end as DVH_Lapse_Fg
from
	IDENTIFIER(:V_DVH_MS_AND_COMBO_DVH_SALES) a
left join
	IDENTIFIER(:V_DVH_P_LVL_CLAIM_INFO_V1) b
on	a.person_id = b.pers_id
and a.rptg_effective_date <= concat(substr(b.max_prem_due_mo,1,4),''-'',substr(b.max_prem_due_mo,5,2),''-'',''01'')
and a.rptg_effective_date = b.prdct_eff_dt
left join
	IDENTIFIER(:V_REFINED_MPO_APPS_RPTG_DAILY) c
on	a.person_id = c.person_id
and a.rptg_effective_date = c.rptg_effective_date
and c.adjudication_status_code = ''A''
;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DVH_MS_AND_COMBO_DVH_SALES_LAPSE)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

V_STEP := ''STEP69'';

V_STEP_NAME :=  ''create table V_DVH_MS_AND_COMBO_DVH_SALES_LAPSE_V0'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_DVH_MS_AND_COMBO_DVH_SALES_LAPSE_V0) COPY GRANTS as
select
	*
	,case when (isdw_term_dt != 219912 and same_eff_term_fg_smart = ''Y'') then ''N'' else same_eff_term_fg_smart end as same_eff_term_fg_smart_new
from
	IDENTIFIER(:V_DVH_MS_AND_COMBO_DVH_SALES_LAPSE)
;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DVH_MS_AND_COMBO_DVH_SALES_LAPSE_V0)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP70'';

V_STEP_NAME :=  ''create table V_DVH_MS_AND_COMBO_DVH_SALES_LAPSE_V1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_DVH_MS_AND_COMBO_DVH_SALES_LAPSE_V1) COPY GRANTS as
select a.* from (
select b.*,
row_number() over (partition by person_id,rptg_effective_date,same_eff_term_fg_smart_new order by person_id,same_eff_term_fg_smart_new) rn
from IDENTIFIER(:V_DVH_MS_AND_COMBO_DVH_SALES_LAPSE_V0) b 
) a
where
	rn =1
and (same_eff_term_fg_smart_new = ''N'' or same_eff_term_fg_smart_new is null)
;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DVH_MS_AND_COMBO_DVH_SALES_LAPSE_V1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

V_STEP := ''STEP71'';

V_STEP_NAME :=  ''create table V_DVH_MS_AND_COMBO_DVH_SALES_LAPSE_FINAL_DATA_NEW'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_DVH_MS_AND_COMBO_DVH_SALES_LAPSE_FINAL_DATA_NEW) COPY GRANTS as
select
	person_id
	,combo_cross_fg as DVH_Combo_Fg
	,combo_app_dt_fg as DVH_Combo_Detail_Fg
	,marketing_channel_final
	,rptg_effective_date
	,application_id
	,case
		when isdw_term_dt != 219912 and substr(isdw_term_dt,5,2) between 1 and 11 then dateadd(''DAY'',-1,to_date(concat(substr(isdw_term_dt+1,1,4),''-'',substr(isdw_term_dt+1,5,2),''-01'')))
		when isdw_term_dt != 219912 and substr(isdw_term_dt,5,2) = 12 then dateadd(''DAY'',-1,to_date(concat(substr(isdw_term_dt+100,1,4),''-01-01'')))
		when isdw_term_dt = 219912 then to_date(''2199-12-31'')
	 end as ms_term_dt
	,case when isdw_term_dt != 219912 then ''Y'' else ''N'' end as ms_lapse_fg
	-- ,Same_eff_term_fg_ISDW
	,Same_Eff_Term_Fg_SMART
	,dvh_pln_effective_dt
	,dvh_pln_term_dt
	,dvh_lapse_fg
	,state_category as DVH_State_category
from
	IDENTIFIER(:V_DVH_MS_AND_COMBO_DVH_SALES_LAPSE_V1)
;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DVH_MS_AND_COMBO_DVH_SALES_LAPSE_FINAL_DATA_NEW)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);


RAISE;

END;

';
