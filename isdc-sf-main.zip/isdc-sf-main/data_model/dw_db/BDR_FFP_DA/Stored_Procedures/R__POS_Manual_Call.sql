--call SP_POS_MANUAL_CALL('1234','POS_MANUAL_CALL','UBLIA_TST_ISDC_DEV_DB','UTIL','BDR_FFP_DA','BDR_FFP_DA_WRK','SRC_GENESYS','SRC_ACESX','SRC_COMPAS','SRC_APEX','SRC_MPO','UBLIA_TST_WORK_XS_WH',CURRENT_DATE())

USE SCHEMA BDR_FFP_DA;


CREATE OR REPLACE PROCEDURE "SP_POS_MANUAL_CALL"("PIPELINE_ID" VARCHAR(16777216), "PIPELINE_NAME" VARCHAR(16777216), "DB_NAME" VARCHAR(16777216), "UTIL_SC" VARCHAR(16777216), "TGT_SC" VARCHAR(16777216),"FFP_WRK_SC" VARCHAR(16777216),"SRC_SC" VARCHAR(16777216),"ONE_SC" VARCHAR(16777216),"TWO_SC" VARCHAR(16777216),"THREE_SC" VARCHAR(16777216),"FOUR_SC" VARCHAR(16777216), "WH" VARCHAR(16777216), "CURR_DATE" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE

V_CURRENT_DATE   DATE := COALESCE(TO_DATE(:CURR_DATE), CURRENT_DATE());

V_REPORT_DATE DATE := COALESCE(TO_DATE(:CURR_DATE), CURRENT_DATE());

V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := :DB_NAME||'.'||COALESCE(:UTIL_SC, 'UTIL')||'.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS';

V_PROCESS_NAME   VARCHAR DEFAULT 'POS_MANUAL_CALL';

V_SUB_PROCESS_NAME  VARCHAR DEFAULT 'POS_MANUAL_CALL';

V_STEP             VARCHAR;

V_STEP_NAME        VARCHAR;

V_START_TIME       VARCHAR;

V_END_TIME         VARCHAR;

V_ROWS_PARSED       INTEGER;

V_ROWS_LOADED       INTEGER;

V_MESSAGE          VARCHAR;

V_LAST_QUERY_ID    VARCHAR;

V_CUSTOMER_INTERACTION_FACT_VOICE  VARCHAR := :DB_NAME || '.' || COALESCE(:SRC_SC, 'SRC_GENESYS') || '.CUSTOMER_INTERACTION_FACT_VOICE';
V_POS_EVENT_LOG VARCHAR := :DB_NAME || '.' || COALESCE(:ONE_SC, 'SRC_ACESX') || '.POS_EVENT_LOG';
V_APP_ENROLL_STORE VARCHAR := :DB_NAME || '.' || COALESCE(:ONE_SC, 'SRC_ACESX') || '.APP_ENROLL_STORE';
V_APPLICATION VARCHAR := :DB_NAME || '.' || COALESCE(:TWO_SC, 'SRC_COMPAS') || '.APPLICATION';
V_UW_AUDIT_MAIN VARCHAR := :DB_NAME || '.' || COALESCE(:THREE_SC, 'SRC_APEX') || '.UW_AUDIT_MAIN';
V_UW_OUTCOMES VARCHAR := :DB_NAME || '.' || COALESCE(:THREE_SC, 'SRC_APEX') || '.UW_OUTCOMES';
V_UW_OUTCOME_SOURCE VARCHAR := :DB_NAME || '.' || COALESCE(:THREE_SC, 'SRC_APEX') || '.UW_OUTCOME_SOURCE';
V_UW_OUTCOME_REASON VARCHAR := :DB_NAME || '.' || COALESCE(:THREE_SC, 'SRC_APEX') || '.UW_OUTCOME_REASON';
V_APPLICATION_MECHANISM VARCHAR := :DB_NAME || '.' || COALESCE(:TWO_SC, 'SRC_COMPAS') || '.APPLICATION_MECHANISM';
V_APPLICATION_ACTOR VARCHAR := :DB_NAME || '.' || COALESCE(:TWO_SC, 'SRC_COMPAS') || '.APPLICATION_ACTOR';
V_EALLIANCE1 VARCHAR := :DB_NAME || '.' || COALESCE(:FOUR_SC, 'SRC_MPO') || '.EALLIANCE';
V_ARC_WORK_QUEUE_REC_ID VARCHAR := :DB_NAME || '.' || COALESCE(:TWO_SC, 'SRC_COMPAS') || '.ARC_WORK_QUEUE_REC_ID';
V_ARC_WQ_ITEM_REASON_HIST VARCHAR := :DB_NAME || '.' || COALESCE(:TWO_SC, 'SRC_COMPAS') || '.ARC_WQ_ITEM_REASON_HIST';
V_WORK_QUEUE_REC_ID VARCHAR := :DB_NAME || '.' || COALESCE(:TWO_SC, 'SRC_COMPAS') || '.WORK_QUEUE_REC_ID';
V_WORK_QUEUE_ITEM_REASON_HIST VARCHAR := :DB_NAME || '.' || COALESCE(:TWO_SC, 'SRC_COMPAS') || '.WORK_QUEUE_ITEM_REASON_HIST';





V_POS_GENESYS VARCHAR := :DB_NAME || '.' || COALESCE(:FFP_WRK_SC, 'BDR_FFP_DA_WRK') || '.POS_GENESYS';
V_POS_GENESYS1 VARCHAR := :DB_NAME || '.' || COALESCE(:FFP_WRK_SC, 'BDR_FFP_DA_WRK') || '.POS_GENESYS1';
V_POS_GENESYS2 VARCHAR := :DB_NAME || '.' || COALESCE(:FFP_WRK_SC, 'BDR_FFP_DA_WRK') || '.POS_GENESYS2';
V_POS_GENESYS3 VARCHAR := :DB_NAME || '.' || COALESCE(:FFP_WRK_SC, 'BDR_FFP_DA_WRK') || '.POS_GENESYS3';
V_CALLTABLE VARCHAR := :DB_NAME || '.' || COALESCE(:FFP_WRK_SC, 'BDR_FFP_DA_WRK') || '.POS_MANUAL_CALL_CALLTABLE';
V_CALLTABLE_NODUP VARCHAR := :DB_NAME || '.' || COALESCE(:FFP_WRK_SC, 'BDR_FFP_DA_WRK') || '.CALLTABLE_NODUP';
V_POS_COMPAS VARCHAR := :DB_NAME || '.' || COALESCE(:FFP_WRK_SC, 'BDR_FFP_DA_WRK') || '.POS_COMPAS';
V_POS_COMPAS1 VARCHAR := :DB_NAME || '.' || COALESCE(:FFP_WRK_SC, 'BDR_FFP_DA_WRK') || '.POS_COMPAS1';
V_POS_COMPAS2 VARCHAR := :DB_NAME || '.' || COALESCE(:FFP_WRK_SC, 'BDR_FFP_DA_WRK') || '.POS_COMPAS2';
V_POS_COMPAS3 VARCHAR := :DB_NAME || '.' || COALESCE(:FFP_WRK_SC, 'BDR_FFP_DA_WRK') || '.POS_COMPAS3';
V_POS_COMPAS4 VARCHAR := :DB_NAME || '.' || COALESCE(:FFP_WRK_SC, 'BDR_FFP_DA_WRK') || '.POS_COMPAS4';
V_POS_COMPAS5 VARCHAR := :DB_NAME || '.' || COALESCE(:FFP_WRK_SC, 'BDR_FFP_DA_WRK') || '.POS_COMPAS5';
V_POS_COMPAS6 VARCHAR := :DB_NAME || '.' || COALESCE(:FFP_WRK_SC, 'BDR_FFP_DA_WRK') || '.POS_COMPAS6';
V_POS_COMPAS7 VARCHAR := :DB_NAME || '.' || COALESCE(:FFP_WRK_SC, 'BDR_FFP_DA_WRK') || '.POS_COMPAS7';
V_POS_COMPAS8 VARCHAR := :DB_NAME || '.' || COALESCE(:FFP_WRK_SC, 'BDR_FFP_DA_WRK') || '.POS_COMPAS8';
V_POS_COMPAS8_1 VARCHAR := :DB_NAME || '.' || COALESCE(:FFP_WRK_SC, 'BDR_FFP_DA_WRK') || '.POS_COMPAS8_1';
V_POS_COMPAS9 VARCHAR := :DB_NAME || '.' || COALESCE(:FFP_WRK_SC, 'BDR_FFP_DA_WRK') || '.POS_COMPAS9';
V_POS_COMPAS10 VARCHAR := :DB_NAME || '.' || COALESCE(:FFP_WRK_SC, 'BDR_FFP_DA_WRK') || '.POS_COMPAS10';
V_POS_COMPAS11 VARCHAR := :DB_NAME || '.' || COALESCE(:TGT_SC, 'BDR_FFP_DA') || '.POS_MANUAL_CALL_POS_COMPAS11';
V_POS_FINALTABLE VARCHAR := :DB_NAME || '.' || COALESCE(:FFP_WRK_SC, 'BDR_FFP_DA_WRK') || '.POS_FINALTABLE';

BEGIN

EXECUTE IMMEDIATE 'USE WAREHOUSE '||:WH;

ALTER SESSION SET TIMEZONE = 'America/Chicago';

V_STEP := 'STEP1';

V_STEP_NAME :=  'create POS_GENESYS tables';
   
V_START_TIME := CONVERT_TIMEZONE('America/Chicago', CURRENT_TIMESTAMP());


create or replace temporary table  IDENTIFIER(:V_POS_GENESYS) as
(
select interaction_end ,initial_uuid,initial_gucid,CONCAT(initial_ani,'-',initial_vqueue) as ani_vqueue,
  row_number() over (partition by initial_ani order by initial_ani ,interaction_end) rn,

initial_ani,interaction_start ,initial_tfn ,initial_digits_dialed ,initial_vqueue
from IDENTIFIER(:V_CUSTOMER_INTERACTION_FACT_VOICE)
WHERE YEAR(INTERACTION_START)>2022
AND INITIAL_TFN ='8882000310'
);

create or replace temporary table  IDENTIFIER(:V_POS_GENESYS1) as
(select *,
 row_number() over (partition by initial_ani order by initial_ani desc,interaction_end desc) rn1
 from IDENTIFIER(:V_POS_GENESYS));


create or replace temporary table  IDENTIFIER(:V_POS_GENESYS2) as
(
select * ,(case when rn=1 then 'F'
when rn1=1 then 'L'
END ) as  First_Last
from IDENTIFIER(:V_POS_GENESYS1));


create or replace temporary table  IDENTIFIER(:V_POS_GENESYS3) as
(
select * ,CONCAT(initial_ani,'-',first_last) as  First_Last_ani
from IDENTIFIER(:V_POS_GENESYS2));


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_POS_GENESYS3)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, 'DEEP_PROCESS', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), 'SUCCESS', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := 'STEP2';

V_STEP_NAME :=  'create a CALLTABLE TABLES';
   
V_START_TIME := CONVERT_TIMEZONE('America/Chicago', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_CALLTABLE) as
select *,(rank() over ( partition by aces_app_id order by created_date)) as rank_alias,
             DAYNAME(created_date) as created_weekday
from IDENTIFIER(:V_POS_EVENT_LOG)
--where locate("1-888-200-0310",event_detail) >0;
  where POSITION('1-888-200-0310' in event_detail) >0;
  
create or replace temporary table IDENTIFIER(:V_CALLTABLE_NODUP) as
select *,case when (hour(created_date) >=8 and hour(created_date)<16 and created_weekday not in ('Sat','Sun')) then 'Y' else 'N' end
             as message_in_business_hour
from IDENTIFIER(:V_CALLTABLE)
where rank_alias=1;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_CALLTABLE_NODUP)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, 'DEEP_PROCESS', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), 'SUCCESS', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := 'STEP3';

V_STEP_NAME :=  'create a POS_COMPASS TABLES';
   
V_START_TIME := CONVERT_TIMEZONE('America/Chicago', CURRENT_TIMESTAMP());

create or replace temporary table IDENTIFIER(:V_POS_COMPAS) as
select aes.ole_reference_id , aes.adjudication_status , pel.*,cp.application_id,cp.day_phone_num,cp.appl_receipt_date, cp.appl_channel_id,
ot.uw_outcomes,so.uw_outcome_source,re.uw_outcome_reason,uw.completion_date, am.appl_mechanism_description,
case when am.APPL_MECHANISM_DESCRIPTION = 'WEB' and aa.APPLICATION_ACTOR_DESCRIPTION = 'CSR' then 'Telesale'
            when uw.agent_id in ('INS2222', 'EHC2222', 'SQS2222', 'SQS3333', 'SQS4444', 'GOH2222' ) OR uw.agent_id is null then 'DTC'
            when e.e_alliance_old_category <> '' then e.e_alliance_old_category
            else 'Agent' end as Channel
from IDENTIFIER(:V_APP_ENROLL_STORE) aes right join IDENTIFIER(:V_CALLTABLE_NODUP) pel
on aes.aces_app_id =pel.aces_app_id
left join IDENTIFIER(:V_APPLICATION) cp on aes.system_application_id  =cp.application_id
left join IDENTIFIER(:V_UW_AUDIT_MAIN) uw on aes.system_application_id =uw.application_id
left join IDENTIFIER(:V_UW_OUTCOMES) ot on uw.outcome =ot.id
left join IDENTIFIER(:V_UW_OUTCOME_SOURCE) so on uw.outcome_source =so.id
left join IDENTIFIER(:V_UW_OUTCOME_REASON) re on CAST(REPLACE(uw.outcome_reason,':','0') AS VARCHAR) =CAST(re.id AS VARCHAR)
left join IDENTIFIER(:V_APPLICATION_MECHANISM) am on cp.appl_mechanism_id=am.application_mechanism_id
left join IDENTIFIER(:V_APPLICATION_ACTOR) aa on aa.APPLICATION_ACTOR_ID = cp.APPL_ACTOR_ID
left join IDENTIFIER(:V_EALLIANCE1) e on uw.agent_id=e.agt_id;

create or replace temporary table IDENTIFIER(:V_POS_FINALTABLE) as
select distinct * from
(select a.*,nvl(b.item_reason_type_id, c.item_reason_type_id) as item_reason_type_id
from IDENTIFIER(:V_POS_COMPAS) a
left join
(select distinct wqri.identifier_value,wqri.tracking_number,wqirh.item_reason_type_id
       from IDENTIFIER(:V_WORK_QUEUE_REC_ID) wqri
       inner join IDENTIFIER(:V_WORK_QUEUE_ITEM_REASON_HIST) wqirh
       on wqri.tracking_number=wqirh.tracking_number and wqri.identifier_type_id = 2011 and wqirh.ITEM_REASON_TYPE_ID in (5037,5043)
) b on a.application_id = b.identifier_value
left join
(select distinct awqri.identifier_value,awqri.tracking_number, awqirh.item_reason_type_id
       from IDENTIFIER(:V_ARC_WORK_QUEUE_REC_ID) awqri
       inner join IDENTIFIER(:V_ARC_WQ_ITEM_REASON_HIST) awqirh
       on awqri.tracking_number=awqirh.tracking_number and awqri.identifier_type_id = 2011 and awqirh.ITEM_REASON_TYPE_ID in (5037,5043)
) c on a.application_id = c.identifier_value
) d;
  
create or replace temporary table IDENTIFIER(:V_POS_COMPAS1) as
select a.*,b.INTERACTION_START as First_call_time,b.First_Last_ani,
b.initial_vqueue as first_call_vqueue,
CONCAT(a.day_phone_num,'-F') as phone_num_F
from IDENTIFIER(:V_POS_FINALTABLE) a left join IDENTIFIER(:V_POS_GENESYS3) b
on CONCAT(a.day_phone_num,'-F')= b.First_Last_ani ;
  

create or replace temporary table IDENTIFIER(:V_POS_COMPAS2) as
select * ,
(case when First_call_time is null then 'Did not call'
when ((MOD(abs(datediff('day',first_call_time,'1900-01-07')),7)+7)%7) + 1=1 then 'Sun'
when ((MOD(abs(datediff('day',first_call_time,'1900-01-07')),7)+7)%7) + 1=2 then 'Mon'
when ((MOD(abs(datediff('day',first_call_time,'1900-01-07')),7)+7)%7) + 1=3 then 'Tue'
when ((MOD(abs(datediff('day',first_call_time,'1900-01-07')),7)+7)%7) + 1=4 then 'Wed'
when ((MOD(abs(datediff('day',first_call_time,'1900-01-07')),7)+7)%7) + 1=5 then 'Thu'
when ((MOD(abs(datediff('day',first_call_time,'1900-01-07')),7)+7)%7) + 1=6 then 'Fri'
when ((MOD(abs(datediff('day',first_call_time,'1900-01-07')),7)+7)%7) + 1=7 then 'Sat'
end) as First_Call_Day,
(case when first_call_vqueue is null then 'Did not call'
when first_call_vqueue='VQ_UHC_GovtPrograms_Underwriting_POS' then 'Yes'
when first_call_vqueue='VQ_UHC_GovtPrograms_Underwriting_Emergency' then 'No'
when first_call_vqueue='VQ_UHC_GovtPrograms_Underwriting_Closed' then 'No'
when first_call_vqueue='NONE' then 'No'
end) as First_Call_Successful,
(case when first_call_time is null then null

--else (datediff(to_date(first_call_time), to_date(created_date)))*60*24
else (TO_DATE(first_call_time)-TO_DATE(created_date))/60
end ) as Time_To_1call_min,
(case when first_call_time is null then null
else (TO_DATE(first_call_time)-TO_DATE(created_date))/3600
--else (datediff(to_date(first_call_time), to_date(created_date))*60*24)/60

end ) as Time_To_1call_hr

from IDENTIFIER(:V_POS_COMPAS1);
  
create or replace temporary table IDENTIFIER(:V_POS_COMPAS3) as
select * ,
(case when first_call_time is null then null
else (case when Time_To_1call_hr < (case when upper(created_weekday) ='SAT' then 48
when upper(created_weekday) ='FRI' then 72
else 24 end) then 'Y'
else 'N' end) end) as first_call_business_hour
from IDENTIFIER(:V_POS_COMPAS2);

create or replace temporary table IDENTIFIER(:V_POS_COMPAS4) as
select a.*,b.INTERACTION_START as First_successful_call_time
from IDENTIFIER(:V_POS_COMPAS3) a left join (select ani_vqueue,min(INTERACTION_START) as  INTERACTION_START
from IDENTIFIER(:V_POS_GENESYS3) where upper(initial_vqueue)='VQ_UHC_GOVTPROGRAMS_UNDERWRITING_POS'
group by ani_vqueue) b
on CONCAT(a.day_phone_num,'-VQ_UHC_GovtPrograms_Underwriting_POS')= b.ani_vqueue;
  
create or replace table IDENTIFIER(:V_POS_COMPAS5) as
(
select *,(case when First_successful_call_time is null then ' '
when ((MOD(abs(datediff('day',First_successful_call_time,'1900-01-07')),7)+7)%7) + 1=1 then 'Sun'
when ((MOD(abs(datediff('day',First_successful_call_time,'1900-01-07')),7)+7)%7) + 1=2 then 'Mon'
when ((MOD(abs(datediff('day',First_successful_call_time,'1900-01-07')),7)+7)%7) + 1=3 then 'Tue'
when ((MOD(abs(datediff('day',First_successful_call_time,'1900-01-07')),7)+7)%7) + 1=4 then 'Wed'
when ((MOD(abs(datediff('day',First_successful_call_time,'1900-01-07')),7)+7)%7) + 1=5 then 'Thu'
when ((MOD(abs(datediff('day',First_successful_call_time,'1900-01-07')),7)+7)%7) + 1=6 then 'Fri'
when ((MOD(abs(datediff('day',First_successful_call_time,'1900-01-07')),7)+7)%7) + 1=7 then 'Sat'
end) as First_successful_call_day
from IDENTIFIER(:V_POS_COMPAS4));
  
create or replace temporary table IDENTIFIER(:V_POS_COMPAS6) as
(
select *,(case when First_successful_call_day is null then null
when First_successful_call_day in ('Sat','Sun') then 'N'
when hour(First_successful_call_time) >=8 and hour(First_successful_call_time)<16 then 'Y'
else'N' end
) as Successful_Call_during_business_hours
from IDENTIFIER(:V_POS_COMPAS5));

create or replace temporary table IDENTIFIER(:V_POS_COMPAS7) as
(
select *,(case when First_successful_call_time is null then null

--else (datediff(to_date(First_successful_call_time), to_date(created_date)))*60*24
else (to_date(First_successful_call_time)-to_date(created_date))/60
end ) as Time_to_Successful_Call_min,
(case when First_successful_call_time is null then null
--else (datediff(to_date(First_successful_call_time), to_date(created_date))*60*24)/60
else (to_date(First_successful_call_time)-to_date(created_date))/3600
end ) as Time_to_Successful_Call_hr
from IDENTIFIER(:V_POS_COMPAS6) );

create or replace temporary table IDENTIFIER(:V_POS_COMPAS8) as
select a.*,b.call_cnt ,c.no_of_succ_calls from IDENTIFIER(:V_POS_COMPAS7) a
left join (select initial_ani,max(rn) as call_cnt from IDENTIFIER(:V_POS_GENESYS3) group by initial_ani) b
on a.day_phone_num=b.initial_ani
left join (select initial_ani,count(initial_ani) as no_of_succ_calls from IDENTIFIER(:V_POS_GENESYS3)
 where initial_vqueue='VQ_UHC_GovtPrograms_Underwriting_POS' group by initial_ani) c
on a.day_phone_num=c.initial_ani;
  
create or replace temporary table IDENTIFIER(:V_POS_COMPAS8_1) as
select *,(case when call_cnt is null then 0 else call_cnt end) as call_cnt1,
(case when no_of_succ_calls is null then 0 else no_of_succ_calls end) as no_of_succ_calls1
from  IDENTIFIER(:V_POS_COMPAS8);

create or replace temporary table IDENTIFIER(:V_POS_COMPAS9) as
select * ,

(case when First_successful_call_time is null or First_successful_call_time is null or
           First_successful_call_time=NULL or First_successful_call_time is null
then
  (case when call_cnt1>0
      then 'Called but unsuccessful'
        else 'Did not call' end)
else
   (case when Time_to_Successful_Call_hr <
          (case when upper(created_weekday) ='SAT' then 48
               when upper(created_weekday) ='FRI'
                     then 72 else 24 end)
     then 'Y'  else 'N' end)
end ) as successful_less_24hr
from IDENTIFIER(:V_POS_COMPAS8_1);
  
create or replace temporary table IDENTIFIER(:V_POS_COMPAS10) as
select * ,
(case when completion_date is null then null
when completion_date is null then 'Pending'
when First_successful_call_time is null then

(datediff(day,to_date(completion_date),to_date(created_date)))
else (datediff(day,to_date(completion_date),to_date(First_successful_call_time)))
end ) as UW_completion_timeframe
from IDENTIFIER(:V_POS_COMPAS9);
  
create or replace table IDENTIFIER(:V_POS_COMPAS11) COPY GRANTS as
select * ,
(case when UW_completion_timeframe is null then 'Not in Apex'
when cast(UW_completion_timeframe as varchar)='Pending' then 'Pending'
when UW_completion_timeframe<1 and UW_completion_timeframe>-1  then 'Y'
else 'N'
end ) as Completion_Same_Day

from IDENTIFIER(:V_POS_COMPAS10);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_POS_COMPAS11)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, 'DEEP_PROCESS', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), 'SUCCESS', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

  
EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, 'DEEP_PROCESSES', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), 'FAILED', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);


RAISE;

END;

$$;
  
  
  
  

  