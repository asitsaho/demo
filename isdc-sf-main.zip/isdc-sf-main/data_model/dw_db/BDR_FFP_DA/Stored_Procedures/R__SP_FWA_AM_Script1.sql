USE SCHEMA BDR_FFP_DA ; 

CREATE OR REPLACE PROCEDURE SP_FWA_AM_Script1
( 
"PIPELINE_ID" VARCHAR(16777216), 
"PIPELINE_NAME" VARCHAR(16777216), 
"DB_NAME" VARCHAR(16777216),
"UTIL_SC" VARCHAR(16777216),
"TGT_SC" VARCHAR(16777216),
"SRC_SC"    VARCHAR(16777216),
"WH" VARCHAR(16777216),
"STAGE_NAME" VARCHAR(16777216),
"START_DT" VARCHAR(16777216),
"END_DT" VARCHAR(16777216),
"CURR_DATE" VARCHAR(16777216)
)
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS 
'
DECLARE

V_CURRENT_DATE   DATE := COALESCE(TO_DATE(:CURR_DATE), CURRENT_DATE());


V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := :DB_NAME||''.''||COALESCE(:UTIL_SC, ''UTIL'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';

V_PROCESS_NAME   VARCHAR DEFAULT ''PROCESS_NAME'';

V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''FWA_AM_Script1'';

V_STEP             VARCHAR;

V_STEP_NAME        VARCHAR;

V_START_TIME       VARCHAR;

V_END_TIME         VARCHAR;

V_ROWS_PARSED       INTEGER;

V_ROWS_LOADED       INTEGER;

V_MESSAGE          VARCHAR;

V_LAST_QUERY_ID    VARCHAR;



V_NPI_FLAGGED_NEWMO_RAW VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_FFP_DA_WRK'') || ''.FWA_AM_NPI_FLAGGED_NEWMO_RAW_DEEP'';

V_FWA_AM_NPI_MATCHED_LASTMO_RAW_DEEP VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_FFP_DA_WRK'') || ''.FWA_AM_NPI_MATCHED_LASTMO_RAW_DEEP'';

V_FWA_AM_INPUT_DEEP VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_FFP_DA_WRK'') || ''.FWA_AM_INPUT_DEEP'';

V_NPI_FINAL VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.FWA_AM_NPI_FINAL_DEEP'';

V_NPI_DATA VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.NPI_DATA'';

V_NPI_NEW_LIST VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_FFP_DA_WRK'') || ''.NPI_NEW_LIST'';

V__FWA_0 VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_FFP_DA_WRK'') || ''.FWA_0'';

V_NPI_DATA_BACKUP VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.NPI_DATA_BACKUP'';

V__FWA_NA_0 VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_FFP_DA_WRK'') || ''.FWA_NA_0'';

V__FWA_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_FFP_DA_WRK'') || ''.FWA_AM_1'';



BEGIN


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;


V_STEP := ''STEP1'';

V_STEP_NAME :=  ''Load data into :V_NPI_FLAGGED_NEWMO_RAW'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

-- Drop the existing table
DROP TABLE IF EXISTS IDENTIFIER(:V_FWA_AM_NPI_MATCHED_LASTMO_RAW_DEEP);

-- Rename the table
ALTER TABLE IDENTIFIER(:V_NPI_FLAGGED_NEWMO_RAW) RENAME TO IDENTIFIER(:V_FWA_AM_NPI_MATCHED_LASTMO_RAW_DEEP);

-- Insert data from the source table into the target table
CREATE OR REPLACE TABLE IDENTIFIER(:V_NPI_FLAGGED_NEWMO_RAW) AS
SELECT 
    TIN,
    NPI,
    Business_Name,
    Provider_Last_Name,
    Provider_First_Name,
    Address,
    Address_2,
    City,
    Provider_State,
    ZIP
FROM IDENTIFIER(:V_FWA_AM_INPUT_DEEP)
WHERE Flag_Reason = ''FWA'';


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_NPI_FLAGGED_NEWMO_RAW)) ; 
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP2'';

V_STEP_NAME :=  ''create a table :V_NPI_NEW_LIST'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());



create or replace TEMPORARY table IDENTIFIER(:V_NPI_NEW_LIST) as
select distinct a.npi  from IDENTIFIER(:V_NPI_FLAGGED_NEWMO_RAW) a
left join IDENTIFIER(:V_NPI_FINAL) b on TRY_TO_NUMBER(a.npi) = TRY_TO_NUMBER(b.npi_fwa) where b.npi_fwa is null and a.npi is not null;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_NPI_NEW_LIST)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP3'';

V_STEP_NAME :=  ''create a table :V__FWA_0'' ;
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());





create or replace TEMPORARY table IDENTIFIER(:V__FWA_0) as
select distinct
a.npi,	
b.provider_first_line_business_practice_location_address as provider_practice_add_1ln,
b.provider_second_line_business_practice_location_address as provider_practice_add_2ln,
b.provider_business_practice_location_address_city_name as provider_practice_add_city_nm,
b.provider_business_practice_location_address_state_name as provider_practice_add_st_nm,
b.provider_business_practice_location_address_postal_code as provider_practice_add_postal_cd,
b.provider_last_name as provider_last_name,
b.provider_first_name as provider_first_name,
b.provider_organization_name as provider_business_name,
b.npi as npi_cms,
case when b.entity_type_code = 2 then b.authorized_official_last_name else b.provider_last_name end as provider_last_name_npi,
case when b.entity_type_code = 2 then b.authorized_official_first_name else b.provider_first_name end as provider_first_name_npi,
b.provider_enumeration_date, b.npi_deactivation_date,
b.npi_reactivation_date, b.provider_gender_code,
case when b.npi is not null then 1 else 0 end as npi_match_flag
from IDENTIFIER(:V_NPI_NEW_LIST) a
left join IDENTIFIER(:V_NPI_DATA) b
on a.npi = b.npi;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V__FWA_0)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP4'';

V_STEP_NAME :=  ''create a table :V__FWA_NA_0'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


 


create or replace TEMPORARY table IDENTIFIER(:V__FWA_NA_0) as 
select a.npi,
b.npi_deactivation_date
from (select * from IDENTIFIER(:V__FWA_0) where npi_cms is null) a
left join IDENTIFIER(:V_NPI_DATA_BACKUP) b 
on a.npi = b.npi 
UNION 
select a.npi,
a.npi_deactivation_date
from (select * from IDENTIFIER(:V__FWA_0) where npi_deactivation_date is not null) a;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V__FWA_NA_0)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP5'';

V_STEP_NAME :=  ''create a table :V__FWA_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


 

 
create or replace table IDENTIFIER(:V__FWA_1) as
select
a.npi,
lower(a.provider_organization_name) as l_provider_business_name_npi,
case when entity_type_code = 2 then LOWER(CONCAT(COALESCE(a.authorized_official_last_name,''''),'' '',COALESCE(a.authorized_official_first_name,'''')))
else lower(CONCAT(COALESCE(a.provider_last_name,''''),'' '',COALESCE(a.provider_first_name,''''))) end as provider_fullname_npi,
 
LOWER(CONCAT(COALESCE(a.provider_first_line_business_practice_location_address,''''),
'' '',COALESCE(a.provider_second_line_business_practice_location_address,''''),
'' '',COALESCE(a.provider_business_practice_location_address_city_name,''''),
'' '', COALESCE(a.provider_business_practice_location_address_state_name,''''),
'' '',COALESCE(SUBSTRING( a.provider_business_practice_location_address_postal_code,1,5),''''))) as key1_npi,
 
LOWER(CONCAT(COALESCE(b.provider_practice_add_1ln,''''),
'' '',COALESCE(b.provider_practice_add_2ln,''''),
'' '',COALESCE(b.provider_practice_add_city_nm,''''),
'' '', COALESCE(b.provider_practice_add_st_nm,''''),
'' '',COALESCE(SUBSTRING( b.provider_practice_add_postal_cd,1,5),''''))) as key2_fwa,
b.npi as npi_fwa,
lower(b.provider_business_name) as l_business_name_fwa,
b.provider_last_name_npi as provider_last_name_fwa,
b.provider_first_name_npi as provider_first_name_fwa,
lower(CONCAT(COALESCE(b.provider_last_name_npi,''''),'' '',COALESCE(b.provider_first_name_npi,''''))) as provider_full_name_fwa,
b.provider_practice_add_1ln as provider_practice_add_1ln_fwa,
b.provider_practice_add_2ln as provider_practice_add_2ln_fwa,
b.provider_practice_add_city_nm as provider_practice_add_city_nm_fwa,
b.provider_practice_add_st_nm as provider_practice_add_st_nm_fwa,
SUBSTRING( b.provider_practice_add_postal_cd,1,5) as provider_practice_add_postal_cd_fwa
from IDENTIFIER(:V__FWA_0) b
left join IDENTIFIER(:V_NPI_DATA) a
on b.provider_practice_add_st_nm = a.provider_business_practice_location_address_state_name
and substr(b.provider_practice_add_postal_cd,1,5) = substr(a.provider_business_practice_location_address_postal_code,1,5);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V__FWA_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);


RAISE;

END;

'
;