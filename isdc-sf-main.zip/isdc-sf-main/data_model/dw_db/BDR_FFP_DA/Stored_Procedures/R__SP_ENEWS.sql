USE SCHEMA BDR_FFP_DA;


CREATE OR REPLACE PROCEDURE SP_ENEWS("PIPELINE_ID" VARCHAR(16777216), "PIPELINE_NAME" VARCHAR(16777216), "DB_NAME" VARCHAR(16777216), "UTIL_SC" VARCHAR(16777216), "INTRM_SC" VARCHAR(16777216), "TGT_SC" VARCHAR(16777216), "ONE_SC" VARCHAR(16777216), "WH" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := :DB_NAME||''.''||COALESCE(:UTIL_SC, ''UTIL'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';

V_PROCESS_NAME   VARCHAR DEFAULT ''ENEWS'';

V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''ENEWS_PROCESS'';

V_STEP             VARCHAR;

V_STEP_NAME        VARCHAR;

V_START_TIME       VARCHAR;

V_END_TIME         VARCHAR;

V_ROWS_PARSED       INTEGER;

V_ROWS_LOADED       INTEGER;

V_MESSAGE          VARCHAR;

V_LAST_QUERY_ID    VARCHAR;

V_ENEWS_BASE_POPULATION VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.ENEWS_BASE_POPULATION'';

V_ENEWS_EMAIL_DETAILS VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.ENEWS_EMAIL_DETAILS'';

V_ENEWS_EMAIL_CAMPAIGN VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.ENEWS_EMAIL_CAMPAIGN'';

V_ENEWS_EMAIL_CAMPAIGN_V1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.ENEWS_EMAIL_CAMPAIGN_V1'';

V_MARKETING_CONTACT VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''BDR_SMART'') || ''.MARKETING_CONTACT'';

V_CAMPAIGN_EXTRACT VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''BDR_SMART'') || ''.CAMPAIGN_EXTRACT'';

V_SM_CAMPAIGN VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''BDR_SMART'') || ''.SM_CAMPAIGN'';

V_EM_CONTACT_RESPONSE VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''BDR_SMART'') || ''.EM_CONTACT_RESPONSE'';

V_EM_EVENT_TYPE VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''BDR_SMART'') || ''.EM_EVENT_TYPE'';



BEGIN

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP1'';

V_STEP_NAME :=  ''create a table ENEWS_BASE_POPULATION'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table   IDENTIFIER(:V_ENEWS_BASE_POPULATION) as
select
        mc.MKT_CONTACT_ID
        ,mc.PERSON_ID
        ,mc.CAMPAIGN_EXTRACT_ID
        ,ce.source_code
        ,smc.INITIATIVE
        ,smc.NAME
        ,ce.CELLNAME
        ,smc.CAMPAIGNCODE
        ,ce.ACTUAL_DROP_DATE

FROM
        IDENTIFIER(:V_MARKETING_CONTACT) as mc

Inner join
        IDENTIFIER(:V_CAMPAIGN_EXTRACT) as ce
on
        mc.CAMPAIGN_EXTRACT_ID = ce.CAMPAIGN_EXTRACT_ID

Inner join
        IDENTIFIER(:V_SM_CAMPAIGN) as smc
on
        ce.CAMPAIGNID=smc.CAMPAIGNID

where
        smc.campaigncode = ''C000003460''
and     year(actual_drop_date) in (2025);



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_ENEWS_BASE_POPULATION)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP2'';

V_STEP_NAME :=  ''create a table ENEWS_EMAIL_DETAILS'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table  IDENTIFIER(:V_ENEWS_EMAIL_DETAILS) as
select
        a.*
        ,click_alias
        ,coalesce(em_event_type_id,0) as em_event_type_id
        ,c.EM_EVENT_TIMESTAMP
        ,em_contact_response_id
from
        IDENTIFIER(:V_ENEWS_BASE_POPULATION) a
left join
        (select mkt_contact_id, em_event_type_id, EM_EVENT_TIMESTAMP, click_alias, em_contact_response_id
         from  IDENTIFIER(:V_EM_CONTACT_RESPONSE) where to_date(EM_EVENT_TIMESTAMP) >= ''2022-01-01'') c
on
        a.MKT_CONTACT_ID = c.MKT_CONTACT_ID;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_ENEWS_EMAIL_DETAILS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP3'';

V_STEP_NAME :=  ''create a table ENEWS_EMAIL_CAMPAIGN'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table  IDENTIFIER(:V_ENEWS_EMAIL_CAMPAIGN)  as
select
        MKT_CONTACT_ID
        ,max(case when trim(em_event_type)  = ''BOUNCE'' and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP)) >=0
         and to_date(EM_EVENT_TIMESTAMP) is not null then 1 else 0 end) as BOUNCE
        ,max(case when trim(em_event_type)  = ''CLICK'' and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP)) >=0
         and to_date(EM_EVENT_TIMESTAMP) is not null then 1 else 0 end) as CLICK
        ,max(case when trim(em_event_type)  = ''NOT SENT'' and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP) ) >=0
         and to_date(EM_EVENT_TIMESTAMP) is not null then 1 else 0 end) as NOT_SENT
        ,max(case when trim(em_event_type)  = ''OPEN'' and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP) ) >=0
         and to_date(EM_EVENT_TIMESTAMP) is not null then 1 else 0 end) as OPEN
        ,max(case when trim(em_event_type)  = ''SENT'' and datediff(day,actual_drop_date,to_date(EM_EVENT_TIMESTAMP) ) >=0
         and to_date(EM_EVENT_TIMESTAMP) is not null then 1 else 0 end) as SENT

from
        IDENTIFIER(:V_ENEWS_EMAIL_DETAILS) a
left join
        IDENTIFIER(:V_EM_EVENT_TYPE) b
on
        a.EM_EVENT_TYPE_ID = b.EM_EVENT_TYPE_ID
group by
        MKT_CONTACT_ID;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_ENEWS_EMAIL_CAMPAIGN)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP4'';

V_STEP_NAME :=  ''create a table ENEWS_EMAIL_CAMPAIGN_V1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table   IDENTIFIER(:V_ENEWS_EMAIL_CAMPAIGN_V1) as
select
        a.*
        ,bounce
        ,click
        ,not_sent
        ,open
        ,sent

from
        IDENTIFIER(:V_ENEWS_BASE_POPULATION) as a

left join
        IDENTIFIER(:V_ENEWS_EMAIL_CAMPAIGN) as b
on
        a.mkt_contact_id = b.mkt_contact_id
;



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_ENEWS_EMAIL_CAMPAIGN_V1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);


RAISE;

END;

';
