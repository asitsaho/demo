USE SCHEMA BDR_FFP_DA;



CREATE OR REPLACE PROCEDURE BDR_FFP_DA.SP_HCC_SCORING_PROCESS_5("PIPELINE_ID" VARCHAR(16777216), "PIPELINE_NAME" VARCHAR(16777216), "DB_NAME" VARCHAR(16777216), "UTIL_SC" VARCHAR(16777216), "TGT_SC" VARCHAR(16777216), "TGT_SC_FINAL" VARCHAR(16777216), "WH" VARCHAR(16777216), "CURR_DATE" DATE)
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

V_CURRENT_DATE   DATE := COALESCE(:CURR_DATE, CURRENT_DATE());
V_CURRENT_MONTH VARCHAR := COALESCE(MONTHNAME(:V_CURRENT_DATE), ''FILL DEFAULT VALUE'');
V_CURRENT_YEAR VARCHAR := COALESCE(TO_CHAR(YEAR(:V_CURRENT_DATE)),''FILL DEFAULT VALUE'');
V_EDIT_DATE_ASOF VARCHAR := TO_CHAR(:V_CURRENT_DATE,''YYYYMMDD'');


V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := :DB_NAME||''.''||COALESCE(:UTIL_SC, ''UTIL'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';

V_PROCESS_NAME   VARCHAR DEFAULT ''HCC_SCORING'';

V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''HCC_SCORING_PROCESS_5'';

V_STEP             VARCHAR;

V_STEP_NAME        VARCHAR;

V_START_TIME       VARCHAR;

V_END_TIME         VARCHAR;

V_ROWS_PARSED       INTEGER;

V_ROWS_LOADED       INTEGER;

V_MESSAGE          VARCHAR;

V_LAST_QUERY_ID    VARCHAR;



V_HCC_OUTPUT_TEMP VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA_WRK'') || ''.HCC_OUTPUT_TEMP'';

V_HCC_OUTPUT_EDIT_DATE_ASOF VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA_WRK'') || ''.HCC_OUTPUT_'' || :V_EDIT_DATE_ASOF;

V_HCC_HISTORICAL_PATTERN VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_FINAL, ''BDR_FFP_DA'') || ''.HCC_HISTORICAL_PATTERN'';

V_HCC_OUTPUT_PART VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA_WRK'') || ''.HCC_OUTPUT_PART'';

V_HCC_SCORING_YEARLY VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_FINAL, ''BDR_FFP_DA'') || ''.HCC_SCORING_YEARLY'';

V_HCC_OUTPUT_UNION_HISTORY_TEMP VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA_WRK'') || ''.HCC_OUTPUT_UNION_HISTORY_TEMP'';

V_HCC_OUTPUT_HISTORY VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA_WRK'') || ''.HCC_OUTPUT_HISTORY'';

V_HCC_OUTPUT_UNION_HISTORY_FINAL VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA_WRK'') || ''.HCC_OUTPUT_UNION_HISTORY_FINAL'';

BEGIN


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP1'';

V_STEP_NAME :=  ''create a table hcc_output_temp'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_HCC_OUTPUT_TEMP) COPY GRANTS as
select *,:V_CURRENT_MONTH as month,:V_CURRENT_YEAR as year,CURRENT_TIMESTAMP() as ins_tsmtp from IDENTIFIER(:V_HCC_OUTPUT_EDIT_DATE_ASOF);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCC_OUTPUT_TEMP)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP2'';

V_STEP_NAME :=  ''create a table hcc_historical_pattern'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create table if not exists IDENTIFIER(:V_HCC_HISTORICAL_PATTERN)( hcc1 int ,  hcc2 int ,  hcc6 int ,  hcc8 int ,  hcc9 int ,  hcc10 int ,  hcc11 int ,  hcc12 int ,  hcc17 int ,  hcc18 int ,  hcc19 int ,  hcc21 int ,  hcc22 int ,  hcc23 int ,  hcc27 int ,  hcc28 int ,  hcc29 int ,  hcc33 int ,  hcc34 int ,  hcc35 int ,  hcc39 int ,  hcc40 int ,  hcc46 int ,  hcc47 int ,  hcc48 int ,  hcc51 int ,  hcc52 int ,  hcc54 int ,  hcc55 int ,  hcc56 int ,  hcc57 int ,  hcc58 int ,  hcc59 int ,  hcc60 int ,  hcc70 int ,  hcc71 int ,  hcc72 int ,  hcc73 int ,  hcc74 int ,  hcc75 int ,  hcc76 int ,  hcc77 int ,  hcc78 int ,  hcc79 int ,  hcc80 int ,  hcc82 int ,  hcc83 int ,  hcc84 int ,  hcc85 int ,  hcc86 int ,  hcc87 int ,  hcc88 int ,  hcc96 int ,  hcc99 int ,  hcc100 int ,  hcc103 int ,  hcc104 int ,  hcc106 int ,  hcc107 int ,  hcc108 int ,  hcc110 int ,  hcc111 int ,  hcc112 int ,  hcc114 int ,  hcc115 int ,  hcc122 int ,  hcc124 int ,  hcc134 int ,  hcc135 int ,  hcc136 int ,  hcc137 int ,  hcc138 int ,  hcc157 int ,  hcc158 int ,  hcc159 int ,  hcc161 int ,  hcc162 int ,  hcc166 int ,  hcc167 int ,  hcc169 int ,  hcc170 int ,  hcc173 int ,  hcc176 int ,  hcc186 int ,  hcc188 int ,  hcc189 int ,  agef bigint ,  cc1 int ,  cc2 int ,  cc6 int ,  cc8 int ,  cc9 int ,  cc10 int ,  cc11 int ,  cc12 int ,  cc17 int ,  cc18 int ,  cc19 int ,  cc21 int ,  cc22 int ,  cc23 int ,  cc27 int ,  cc28 int ,  cc29 int ,  cc33 int ,  cc34 int ,  cc35 int ,  cc39 int ,  cc40 int ,  cc46 int ,  cc47 int ,  cc48 int ,  cc51 int ,  cc52 int ,  cc54 int ,  cc55 int ,  cc56 int ,  cc57 int ,  cc58 int ,  cc59 int ,  cc60 int ,  cc70 int ,  cc71 int ,  cc72 int ,  cc73 int ,  cc74 int ,  cc75 int ,  cc76 int ,  cc77 int ,  cc78 int ,  cc79 int ,  cc80 int ,  cc82 int ,  cc83 int ,  cc84 int ,  cc85 int ,  cc86 int ,  cc87 int ,  cc88 int ,  cc96 int ,  cc99 int ,  cc100 int ,  cc103 int ,  cc104 int ,  cc106 int ,  cc107 int ,  cc108 int ,  cc110 int ,  cc111 int ,  cc112 int ,  cc114 int ,  cc115 int ,  cc122 int ,  cc124 int ,  cc134 int ,  cc135 int ,  cc136 int ,  cc137 int ,  cc138 int ,  cc157 int ,  cc158 int ,  cc159 int ,  cc161 int ,  cc162 int ,  cc166 int ,  cc167 int ,  cc169 int ,  cc170 int ,  cc173 int ,  cc176 int ,  cc186 int ,  cc188 int ,  cc189 int ,  hicno bigint ,  dob date  ,  sex int ,  nemcaid int ,  orec int ,  f0_34 int ,  f35_44 int ,  f45_54 int ,  f55_59 int ,  f60_64 int ,  f65_69 int ,  f70_74 int ,  f75_79 int ,  f80_84 int ,  f85_89 int ,  f90_94 int ,  f95_gt int ,  m0_34 int ,  m35_44 int ,  m45_54 int ,  m55_59 int ,  m60_64 int ,  m65_69 int ,  m70_74 int ,  m75_79 int ,  m80_84 int ,  m85_89 int ,  m90_94 int ,  m95_gt int ,  disabl int ,  origds int ,  nef0_34 int ,  nef35_44 int ,  nef45_54 int ,  nef55_59 int ,  nef60_64 int ,  nef65 int ,  nef66 int ,  nef67 int ,  nef68 int ,  nef69 int ,  nef70_74 int ,  nef75_79 int ,  nef80_84 int ,  nef85_89 int ,  nef90_94 int ,  nef95_gt int ,  nem0_34 int ,  nem35_44 int ,  nem45_54 int ,  nem55_59 int ,  nem60_64 int ,  nem65 int ,  nem66 int ,  nem67 int ,  nem68 int ,  nem69 int ,  nem70_74 int ,  nem75_79 int ,  nem80_84 int ,  nem85_89 int ,  nem90_94 int ,  nem95_gt int ,  score_community_na decimal(38,3) ,  score_community_nd decimal(38,3) ,  score_community_fba decimal(38,3) ,  score_community_fbd decimal(38,3) ,  score_community_pba decimal(38,3) ,  score_community_pbd decimal(38,3) ,  score_institutional decimal(38,3) ,  score_new_enrollee decimal(38,3) ,  score_snp_new_enrollee decimal(38,3), ins_tsmtp timestamp,year varchar,month varchar);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCC_HISTORICAL_PATTERN)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP3'';

V_STEP_NAME :=  ''insert data into table hcc_historical_pattern'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


delete from IDENTIFIER(:V_HCC_HISTORICAL_PATTERN) where year=:V_CURRENT_YEAR and month=:V_CURRENT_MONTH;

insert into IDENTIFIER(:V_HCC_HISTORICAL_PATTERN)
select hcc1,  hcc2,hcc6,hcc8,hcc9,hcc10,hcc11,hcc12 ,  hcc17 ,  hcc18 ,  hcc19 ,  hcc21 ,  hcc22 ,  hcc23 ,  hcc27 ,  hcc28 ,  hcc29 ,  hcc33 ,  hcc34 ,  hcc35 ,  hcc39 ,  hcc40 ,  hcc46 ,  hcc47 ,  hcc48 ,  hcc51 ,  hcc52 ,  hcc54 ,  hcc55 ,  hcc56 ,  hcc57 ,  hcc58 ,  hcc59 ,  hcc60 ,  hcc70 ,  hcc71 ,  hcc72 ,  hcc73 ,  hcc74 ,  hcc75 ,  hcc76 ,  hcc77 ,  hcc78 ,  hcc79 ,  hcc80 ,  hcc82 ,  hcc83 ,  hcc84 ,  hcc85 ,  hcc86 ,  hcc87 ,  hcc88 ,  hcc96 ,  hcc99 ,  hcc100 ,  hcc103 ,  hcc104 ,  hcc106 ,  hcc107 ,  hcc108 ,  hcc110 ,  hcc111 ,  hcc112 ,  hcc114 ,  hcc115 ,  hcc122 ,  hcc124 ,  hcc134 ,  hcc135 ,  hcc136 ,  hcc137 ,  hcc138 ,  hcc157 ,  hcc158 ,  hcc159 ,  hcc161 ,  hcc162 ,  hcc166 ,  hcc167 ,  hcc169 ,  hcc170 ,  hcc173 ,  hcc176 ,  hcc186 ,  hcc188 ,  hcc189 ,  agef big  ,  cc1 ,  cc2 ,  cc6 ,  cc8 ,  cc9 ,  cc10 ,  cc11 ,  cc12 ,  cc17 ,  cc18 ,  cc19 ,  cc21 ,  cc22 ,  cc23 ,  cc27 ,  cc28 ,  cc29 ,  cc33 ,  cc34 ,  cc35 ,  cc39 ,  cc40 ,  cc46 ,  cc47 ,  cc48 ,  cc51 ,  cc52 ,  cc54 ,  cc55 ,  cc56 ,  cc57 ,  cc58 ,  cc59 ,  cc60 ,  cc70 ,  cc71 ,  cc72 ,  cc73 ,  cc74 ,  cc75 ,  cc76 ,  cc77 ,  cc78 ,  cc79 ,  cc80 ,  cc82 ,  cc83 ,  cc84 ,  cc85 ,  cc86 ,  cc87 ,  cc88 ,  cc96 ,  cc99 ,  cc100 ,  cc103 ,  cc104 ,  cc106 ,  cc107 ,  cc108 ,  cc110 ,  cc111 ,  cc112 ,  cc114 ,  cc115 ,  cc122 ,  cc124 ,  cc134 ,  cc135 ,  cc136 ,  cc137 ,  cc138 ,  cc157 ,  cc158 ,  cc159 ,  cc161 ,  cc162 ,  cc166 ,  cc167 ,  cc169 ,  cc170 ,  cc173 ,  cc176 ,  cc186 ,  cc188 ,  cc189 ,  hicno big  ,  dob  ,  sex ,  nemcaid ,  orec ,  f0_34 ,  f35_44 ,  f45_54 ,  f55_59 ,  f60_64 ,  f65_69 ,  f70_74 ,  f75_79 ,  f80_84 ,  f85_89 ,  f90_94 ,  f95_gt ,  m0_34 ,  m35_44 ,  m45_54 ,  m55_59 ,  m60_64 ,  m65_69 ,  m70_74 ,  m75_79 ,  m80_84 ,  m85_89 ,  m90_94 ,  m95_gt ,  disabl ,  origds ,  nef0_34 ,  nef35_44 ,  nef45_54 ,  nef55_59 ,  nef60_64 ,  nef65 ,  nef66 ,  nef67 ,  nef68 ,  nef69 ,  nef70_74 ,  nef75_79 ,  nef80_84 ,  nef85_89 ,  nef90_94 ,  nef95_gt ,  nem0_34 ,  nem35_44 ,  nem45_54 ,  nem55_59 ,  nem60_64 ,  nem65 ,  nem66 ,  nem67 ,  nem68 ,  nem69 ,  nem70_74 ,  nem75_79 ,  nem80_84 ,  nem85_89 ,  nem90_94 ,  nem95_gt ,  score_community_na ,  score_community_nd ,  score_community_fba ,  score_community_fbd ,  score_community_pba ,  score_community_pbd ,  score_institutional ,  score_new_enrollee ,  score_snp_new_enrollee  ,
ins_tsmtp ,year,month from IDENTIFIER(:V_HCC_OUTPUT_TEMP) order by hicno;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCC_HISTORICAL_PATTERN)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP4'';

V_STEP_NAME :=  ''create a table hcc_output_part'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create table if not exists IDENTIFIER(:V_HCC_OUTPUT_PART)( hcc1 int ,  hcc2 int ,  hcc6 int ,  hcc8 int ,  hcc9 int ,  hcc10 int ,  hcc11 int ,  hcc12 int ,  hcc17 int ,  hcc18 int ,  hcc19 int ,  hcc21 int ,  hcc22 int ,  hcc23 int ,  hcc27 int ,  hcc28 int ,  hcc29 int ,  hcc33 int ,  hcc34 int ,  hcc35 int ,  hcc39 int ,  hcc40 int ,  hcc46 int ,  hcc47 int ,  hcc48 int ,  hcc51 int ,  hcc52 int ,  hcc54 int ,  hcc55 int ,  hcc56 int ,  hcc57 int ,  hcc58 int ,  hcc59 int ,  hcc60 int ,  hcc70 int ,  hcc71 int ,  hcc72 int ,  hcc73 int ,  hcc74 int ,  hcc75 int ,  hcc76 int ,  hcc77 int ,  hcc78 int ,  hcc79 int ,  hcc80 int ,  hcc82 int ,  hcc83 int ,  hcc84 int ,  hcc85 int ,  hcc86 int ,  hcc87 int ,  hcc88 int ,  hcc96 int ,  hcc99 int ,  hcc100 int ,  hcc103 int ,  hcc104 int ,  hcc106 int ,  hcc107 int ,  hcc108 int ,  hcc110 int ,  hcc111 int ,  hcc112 int ,  hcc114 int ,  hcc115 int ,  hcc122 int ,  hcc124 int ,  hcc134 int ,  hcc135 int ,  hcc136 int ,  hcc137 int ,  hcc138 int ,  hcc157 int ,  hcc158 int ,  hcc159 int ,  hcc161 int ,  hcc162 int ,  hcc166 int ,  hcc167 int ,  hcc169 int ,  hcc170 int ,  hcc173 int ,  hcc176 int ,  hcc186 int ,  hcc188 int ,  hcc189 int ,  agef bigint ,  cc1 int ,  cc2 int ,  cc6 int ,  cc8 int ,  cc9 int ,  cc10 int ,  cc11 int ,  cc12 int ,  cc17 int ,  cc18 int ,  cc19 int ,  cc21 int ,  cc22 int ,  cc23 int ,  cc27 int ,  cc28 int ,  cc29 int ,  cc33 int ,  cc34 int ,  cc35 int ,  cc39 int ,  cc40 int ,  cc46 int ,  cc47 int ,  cc48 int ,  cc51 int ,  cc52 int ,  cc54 int ,  cc55 int ,  cc56 int ,  cc57 int ,  cc58 int ,  cc59 int ,  cc60 int ,  cc70 int ,  cc71 int ,  cc72 int ,  cc73 int ,  cc74 int ,  cc75 int ,  cc76 int ,  cc77 int ,  cc78 int ,  cc79 int ,  cc80 int ,  cc82 int ,  cc83 int ,  cc84 int ,  cc85 int ,  cc86 int ,  cc87 int ,  cc88 int ,  cc96 int ,  cc99 int ,  cc100 int ,  cc103 int ,  cc104 int ,  cc106 int ,  cc107 int ,  cc108 int ,  cc110 int ,  cc111 int ,  cc112 int ,  cc114 int ,  cc115 int ,  cc122 int ,  cc124 int ,  cc134 int ,  cc135 int ,  cc136 int ,  cc137 int ,  cc138 int ,  cc157 int ,  cc158 int ,  cc159 int ,  cc161 int ,  cc162 int ,  cc166 int ,  cc167 int ,  cc169 int ,  cc170 int ,  cc173 int ,  cc176 int ,  cc186 int ,  cc188 int ,  cc189 int ,  hicno bigint ,  dob date  ,  sex int ,  nemcaid int ,  orec int ,  f0_34 int ,  f35_44 int ,  f45_54 int ,  f55_59 int ,  f60_64 int ,  f65_69 int ,  f70_74 int ,  f75_79 int ,  f80_84 int ,  f85_89 int ,  f90_94 int ,  f95_gt int ,  m0_34 int ,  m35_44 int ,  m45_54 int ,  m55_59 int ,  m60_64 int ,  m65_69 int ,  m70_74 int ,  m75_79 int ,  m80_84 int ,  m85_89 int ,  m90_94 int ,  m95_gt int ,  disabl int ,  origds int ,  nef0_34 int ,  nef35_44 int ,  nef45_54 int ,  nef55_59 int ,  nef60_64 int ,  nef65 int ,  nef66 int ,  nef67 int ,  nef68 int ,  nef69 int ,  nef70_74 int ,  nef75_79 int ,  nef80_84 int ,  nef85_89 int ,  nef90_94 int ,  nef95_gt int ,  nem0_34 int ,  nem35_44 int ,  nem45_54 int ,  nem55_59 int ,  nem60_64 int ,  nem65 int ,  nem66 int ,  nem67 int ,  nem68 int ,  nem69 int ,  nem70_74 int ,  nem75_79 int ,  nem80_84 int ,  nem85_89 int ,  nem90_94 int ,  nem95_gt int ,  score_community_na decimal(38,3) ,  score_community_nd decimal(38,3) ,  score_community_fba decimal(38,3) ,  score_community_fbd decimal(38,3) ,  score_community_pba decimal(38,3) ,  score_community_pbd decimal(38,3) ,  score_institutional decimal(38,3) ,  score_new_enrollee decimal(38,3) ,  score_snp_new_enrollee decimal(38,3),
month varchar, ins_tsmtp timestamp,year varchar);




V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCC_OUTPUT_PART)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP5'';

V_STEP_NAME :=  ''insert the data into table hcc_output_part'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

delete from IDENTIFIER(:V_HCC_OUTPUT_PART) where year=:V_CURRENT_YEAR;

insert into IDENTIFIER(:V_HCC_OUTPUT_PART)
select hcc1,  hcc2,hcc6,hcc8,hcc9,hcc10,hcc11,hcc12 ,  hcc17 ,  hcc18 ,  hcc19 ,  hcc21 ,  hcc22 ,  hcc23 ,  hcc27 ,  hcc28 ,  hcc29 ,  hcc33 ,  hcc34 ,  hcc35 ,  hcc39 ,  hcc40 ,  hcc46 ,  hcc47 ,  hcc48 ,  hcc51 ,  hcc52 ,  hcc54 ,  hcc55 ,  hcc56 ,  hcc57 ,  hcc58 ,  hcc59 ,  hcc60 ,  hcc70 ,  hcc71 ,  hcc72 ,  hcc73 ,  hcc74 ,  hcc75 ,  hcc76 ,  hcc77 ,  hcc78 ,  hcc79 ,  hcc80 ,  hcc82 ,  hcc83 ,  hcc84 ,  hcc85 ,  hcc86 ,  hcc87 ,  hcc88 ,  hcc96 ,  hcc99 ,  hcc100 ,  hcc103 ,  hcc104 ,  hcc106 ,  hcc107 ,  hcc108 ,  hcc110 ,  hcc111 ,  hcc112 ,  hcc114 ,  hcc115 ,  hcc122 ,  hcc124 ,  hcc134 ,  hcc135 ,  hcc136 ,  hcc137 ,  hcc138 ,  hcc157 ,  hcc158 ,  hcc159 ,  hcc161 ,  hcc162 ,  hcc166 ,  hcc167 ,  hcc169 ,  hcc170 ,  hcc173 ,  hcc176 ,  hcc186 ,  hcc188 ,  hcc189 ,  agef big  ,  cc1 ,  cc2 ,  cc6 ,  cc8 ,  cc9 ,  cc10 ,  cc11 ,  cc12 ,  cc17 ,  cc18 ,  cc19 ,  cc21 ,  cc22 ,  cc23 ,  cc27 ,  cc28 ,  cc29 ,  cc33 ,  cc34 ,  cc35 ,  cc39 ,  cc40 ,  cc46 ,  cc47 ,  cc48 ,  cc51 ,  cc52 ,  cc54 ,  cc55 ,  cc56 ,  cc57 ,  cc58 ,  cc59 ,  cc60 ,  cc70 ,  cc71 ,  cc72 ,  cc73 ,  cc74 ,  cc75 ,  cc76 ,  cc77 ,  cc78 ,  cc79 ,  cc80 ,  cc82 ,  cc83 ,  cc84 ,  cc85 ,  cc86 ,  cc87 ,  cc88 ,  cc96 ,  cc99 ,  cc100 ,  cc103 ,  cc104 ,  cc106 ,  cc107 ,  cc108 ,  cc110 ,  cc111 ,  cc112 ,  cc114 ,  cc115 ,  cc122 ,  cc124 ,  cc134 ,  cc135 ,  cc136 ,  cc137 ,  cc138 ,  cc157 ,  cc158 ,  cc159 ,  cc161 ,  cc162 ,  cc166 ,  cc167 ,  cc169 ,  cc170 ,  cc173 ,  cc176 ,  cc186 ,  cc188 ,  cc189 ,  hicno big  ,  dob  ,  sex ,  nemcaid ,  orec ,  f0_34 ,  f35_44 ,  f45_54 ,  f55_59 ,  f60_64 ,  f65_69 ,  f70_74 ,  f75_79 ,  f80_84 ,  f85_89 ,  f90_94 ,  f95_gt ,  m0_34 ,  m35_44 ,  m45_54 ,  m55_59 ,  m60_64 ,  m65_69 ,  m70_74 ,  m75_79 ,  m80_84 ,  m85_89 ,  m90_94 ,  m95_gt ,  disabl ,  origds ,  nef0_34 ,  nef35_44 ,  nef45_54 ,  nef55_59 ,  nef60_64 ,  nef65 ,  nef66 ,  nef67 ,  nef68 ,  nef69 ,  nef70_74 ,  nef75_79 ,  nef80_84 ,  nef85_89 ,  nef90_94 ,  nef95_gt ,  nem0_34 ,  nem35_44 ,  nem45_54 ,  nem55_59 ,  nem60_64 ,  nem65 ,  nem66 ,  nem67 ,  nem68 ,  nem69 ,  nem70_74 ,  nem75_79 ,  nem80_84 ,  nem85_89 ,  nem90_94 ,  nem95_gt ,  score_community_na ,  score_community_nd ,  score_community_fba ,  score_community_fbd ,  score_community_pba ,  score_community_pbd ,  score_institutional ,  score_new_enrollee ,  score_snp_new_enrollee  ,
month ,ins_tsmtp,year from IDENTIFIER(:V_HCC_OUTPUT_TEMP);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCC_OUTPUT_PART)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP6'';

V_STEP_NAME :=  ''create a table hcc_scoring_yearly'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());




create table if not exists IDENTIFIER(:V_HCC_SCORING_YEARLY)( hcc1 int ,  hcc2 int ,  hcc6 int ,  hcc8 int ,  hcc9 int ,  hcc10 int ,  hcc11 int ,  hcc12 int ,  hcc17 int ,  hcc18 int ,  hcc19 int ,  hcc21 int ,  hcc22 int ,  hcc23 int ,  hcc27 int ,  hcc28 int ,  hcc29 int ,  hcc33 int ,  hcc34 int ,  hcc35 int ,  hcc39 int ,  hcc40 int ,  hcc46 int ,  hcc47 int ,  hcc48 int ,  hcc51 int ,  hcc52 int ,  hcc54 int ,  hcc55 int ,  hcc56 int ,  hcc57 int ,  hcc58 int ,  hcc59 int ,  hcc60 int ,  hcc70 int ,  hcc71 int ,  hcc72 int ,  hcc73 int ,  hcc74 int ,  hcc75 int ,  hcc76 int ,  hcc77 int ,  hcc78 int ,  hcc79 int ,  hcc80 int ,  hcc82 int ,  hcc83 int ,  hcc84 int ,  hcc85 int ,  hcc86 int ,  hcc87 int ,  hcc88 int ,  hcc96 int ,  hcc99 int ,  hcc100 int ,  hcc103 int ,  hcc104 int ,  hcc106 int ,  hcc107 int ,  hcc108 int ,  hcc110 int ,  hcc111 int ,  hcc112 int ,  hcc114 int ,  hcc115 int ,  hcc122 int ,  hcc124 int ,  hcc134 int ,  hcc135 int ,  hcc136 int ,  hcc137 int ,  hcc138 int ,  hcc157 int ,  hcc158 int ,  hcc159 int ,  hcc161 int ,  hcc162 int ,  hcc166 int ,  hcc167 int ,  hcc169 int ,  hcc170 int ,  hcc173 int ,  hcc176 int ,  hcc186 int ,  hcc188 int ,  hcc189 int ,  agef bigint ,  cc1 int ,  cc2 int ,  cc6 int ,  cc8 int ,  cc9 int ,  cc10 int ,  cc11 int ,  cc12 int ,  cc17 int ,  cc18 int ,  cc19 int ,  cc21 int ,  cc22 int ,  cc23 int ,  cc27 int ,  cc28 int ,  cc29 int ,  cc33 int ,  cc34 int ,  cc35 int ,  cc39 int ,  cc40 int ,  cc46 int ,  cc47 int ,  cc48 int ,  cc51 int ,  cc52 int ,  cc54 int ,  cc55 int ,  cc56 int ,  cc57 int ,  cc58 int ,  cc59 int ,  cc60 int ,  cc70 int ,  cc71 int ,  cc72 int ,  cc73 int ,  cc74 int ,  cc75 int ,  cc76 int ,  cc77 int ,  cc78 int ,  cc79 int ,  cc80 int ,  cc82 int ,  cc83 int ,  cc84 int ,  cc85 int ,  cc86 int ,  cc87 int ,  cc88 int ,  cc96 int ,  cc99 int ,  cc100 int ,  cc103 int ,  cc104 int ,  cc106 int ,  cc107 int ,  cc108 int ,  cc110 int ,  cc111 int ,  cc112 int ,  cc114 int ,  cc115 int ,  cc122 int ,  cc124 int ,  cc134 int ,  cc135 int ,  cc136 int ,  cc137 int ,  cc138 int ,  cc157 int ,  cc158 int ,  cc159 int ,  cc161 int ,  cc162 int ,  cc166 int ,  cc167 int ,  cc169 int ,  cc170 int ,  cc173 int ,  cc176 int ,  cc186 int ,  cc188 int ,  cc189 int ,  hicno bigint ,  dob date  ,  sex int ,  nemcaid int ,  orec int ,  f0_34 int ,  f35_44 int ,  f45_54 int ,  f55_59 int ,  f60_64 int ,  f65_69 int ,  f70_74 int ,  f75_79 int ,  f80_84 int ,  f85_89 int ,  f90_94 int ,  f95_gt int ,  m0_34 int ,  m35_44 int ,  m45_54 int ,  m55_59 int ,  m60_64 int ,  m65_69 int ,  m70_74 int ,  m75_79 int ,  m80_84 int ,  m85_89 int ,  m90_94 int ,  m95_gt int ,  disabl int ,  origds int ,  nef0_34 int ,  nef35_44 int ,  nef45_54 int ,  nef55_59 int ,  nef60_64 int ,  nef65 int ,  nef66 int ,  nef67 int ,  nef68 int ,  nef69 int ,  nef70_74 int ,  nef75_79 int ,  nef80_84 int ,  nef85_89 int ,  nef90_94 int ,  nef95_gt int ,  nem0_34 int ,  nem35_44 int ,  nem45_54 int ,  nem55_59 int ,  nem60_64 int ,  nem65 int ,  nem66 int ,  nem67 int ,  nem68 int ,  nem69 int ,  nem70_74 int ,  nem75_79 int ,  nem80_84 int ,  nem85_89 int ,  nem90_94 int ,  nem95_gt int ,  score_community_na decimal(38,3) ,  score_community_nd decimal(38,3) ,  score_community_fba decimal(38,3) ,  score_community_fbd decimal(38,3) ,  score_community_pba decimal(38,3) ,  score_community_pbd decimal(38,3) ,  score_institutional decimal(38,3) ,  score_new_enrollee decimal(38,3) ,  score_snp_new_enrollee decimal(38,3),
month varchar, ins_tsmtp timestamp,year varchar);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCC_SCORING_YEARLY)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP7'';

V_STEP_NAME :=  ''create a table hcc_output_history'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


CREATE table if not exists IDENTIFIER(:V_HCC_OUTPUT_HISTORY)(   hcc1 int,   hcc2 int,   hcc6 int,   hcc8 int,   hcc9 int,   hcc10 int,   hcc11 int,   hcc12 int,   hcc17 int,   hcc18 int,   hcc19 int,   hcc21 int,   hcc22 int,   hcc23 int,   hcc27 int,   hcc28 int,   hcc29 int,   hcc33 int,   hcc34 int,   hcc35 int,   hcc39 int,   hcc40 int,   hcc46 int,   hcc47 int,   hcc48 int,   hcc51 int,   hcc52 int,   hcc54 int,   hcc55 int,   hcc56 int,   hcc57 int,   hcc58 int,   hcc59 int,   hcc60 int,   hcc70 int,   hcc71 int,   hcc72 int,   hcc73 int,   hcc74 int,   hcc75 int,   hcc76 int,   hcc77 int,   hcc78 int,   hcc79 int,   hcc80 int,   hcc82 int,   hcc83 int,   hcc84 int,   hcc85 int,   hcc86 int,   hcc87 int,   hcc88 int,   hcc96 int,   hcc99 int,   hcc100 int,   hcc103 int,   hcc104 int,   hcc106 int,   hcc107 int,   hcc108 int,   hcc110 int,   hcc111 int,   hcc112 int,   hcc114 int,   hcc115 int,   hcc122 int,   hcc124 int,   hcc134 int,   hcc135 int,   hcc136 int,   hcc137 int,   hcc138 int,   hcc157 int,   hcc158 int,   hcc159 int,   hcc161 int,   hcc162 int,   hcc166 int,   hcc167 int,   hcc169 int,   hcc170 int,   hcc173 int,   hcc176 int,   hcc186 int,   hcc188 int,   hcc189 int,   agef bigint,   cc1 int,   cc2 int,   cc6 int,   cc8 int,   cc9 int,   cc10 int,   cc11 int,   cc12 int,   cc17 int,   cc18 int,   cc19 int,   cc21 int,   cc22 int,   cc23 int,   cc27 int,   cc28 int,   cc29 int,   cc33 int,   cc34 int,   cc35 int,   cc39 int,   cc40 int,   cc46 int,   cc47 int,   cc48 int,   cc51 int,   cc52 int,   cc54 int,   cc55 int,   cc56 int,   cc57 int,   cc58 int,   cc59 int,   cc60 int,   cc70 int,   cc71 int,   cc72 int,   cc73 int,   cc74 int,   cc75 int,   cc76 int,   cc77 int,   cc78 int,   cc79 int,   cc80 int,   cc82 int,   cc83 int,   cc84 int,   cc85 int,   cc86 int,   cc87 int,   cc88 int,   cc96 int,   cc99 int,   cc100 int,   cc103 int,   cc104 int,   cc106 int,   cc107 int,   cc108 int,   cc110 int,   cc111 int,   cc112 int,   cc114 int,   cc115 int,   cc122 int,   cc124 int,   cc134 int,   cc135 int,   cc136 int,   cc137 int,   cc138 int,   cc157 int,   cc158 int,   cc159 int,   cc161 int,   cc162 int,   cc166 int,   cc167 int,   cc169 int,   cc170 int,   cc173 int,   cc176 int,   cc186 int,   cc188 int,   cc189 int,   hicno bigint,   dob date,   sex int,   nemcaid int,   orec int,   f0_34 int,   f35_44 int,   f45_54 int,   f55_59 int,   f60_64 int,   f65_69 int,   f70_74 int,   f75_79 int,   f80_84 int,   f85_89 int,   f90_94 int,   f95_gt int,   m0_34 int,   m35_44 int,   m45_54 int,   m55_59 int,   m60_64 int,   m65_69 int,   m70_74 int,   m75_79 int,   m80_84 int,   m85_89 int,   m90_94 int,   m95_gt int,   disabl int,   origds int,   nef0_34 int,   nef35_44 int,   nef45_54 int,   nef55_59 int,   nef60_64 int,   nef65 int,   nef66 int,   nef67 int,   nef68 int,   nef69 int,   nef70_74 int,   nef75_79 int,   nef80_84 int,   nef85_89 int,   nef90_94 int,   nef95_gt int,   nem0_34 int,   nem35_44 int,   nem45_54 int,   nem55_59 int,   nem60_64 int,   nem65 int,   nem66 int,   nem67 int,   nem68 int,   nem69 int,   nem70_74 int,   nem75_79 int,   nem80_84 int,   nem85_89 int,   nem90_94 int,   nem95_gt int,   score_community_na decimal(38,3),   score_community_nd decimal(38,3),   score_community_fba decimal(38,3),   score_community_fbd decimal(38,3),   score_community_pba decimal(38,3),   score_community_pbd decimal(38,3),   score_institutional decimal(38,3),   score_new_enrollee decimal(38,3),   score_snp_new_enrollee decimal(38,3),   month varchar, ins_tsmtp timestamp,year varchar);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCC_OUTPUT_HISTORY)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP8'';

V_STEP_NAME :=  ''create a table hcc_output_union_history_temp'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());



create or replace table IDENTIFIER(:V_HCC_OUTPUT_UNION_HISTORY_TEMP) COPY GRANTS as
select * from IDENTIFIER(:V_HCC_OUTPUT_PART) where month=:V_CURRENT_MONTH and year=:V_CURRENT_YEAR
UNION ALL
SELECT * from IDENTIFIER(:V_HCC_OUTPUT_HISTORY) where year=:V_CURRENT_YEAR;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCC_OUTPUT_UNION_HISTORY_TEMP)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP9'';

V_STEP_NAME :=  ''create a table hcc_output_union_history_final'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_HCC_OUTPUT_UNION_HISTORY_FINAL) COPY GRANTS as
select a.hcc1,a.hcc2,a.hcc6,a.hcc8,a.hcc9,a.hcc10,a.hcc11,a.hcc12,a.hcc17,a.hcc18,a.hcc19,a.hcc21,a.hcc22,a.hcc23,a.hcc27,a.hcc28,a.hcc29,a.hcc33,a.hcc34,a.hcc35,a.hcc39,a.hcc40,a.hcc46,a.hcc47,a.hcc48,a.hcc51,a.hcc52,a.hcc54,a.hcc55,a.hcc56,a.hcc57,a.hcc58,a.hcc59,a.hcc60,a.hcc70,a.hcc71,a.hcc72,a.hcc73,a.hcc74,a.hcc75,a.hcc76,a.hcc77,a.hcc78,a.hcc79,a.hcc80,a.hcc82,a.hcc83,a.hcc84,a.hcc85,a.hcc86,a.hcc87,a.hcc88,a.hcc96,a.hcc99,a.hcc100,a.hcc103,a.hcc104,a.hcc106,a.hcc107,a.hcc108,a.hcc110,a.hcc111,a.hcc112,a.hcc114,a.hcc115,a.hcc122,a.hcc124,a.hcc134,a.hcc135,a.hcc136,a.hcc137,a.hcc138,a.hcc157,a.hcc158,a.hcc159,a.hcc161,a.hcc162,a.hcc166,a.hcc167,a.hcc169,a.hcc170,a.hcc173,a.hcc176,a.hcc186,a.hcc188,a.hcc189,a.agef,a.cc1,a.cc2,a.cc6,a.cc8,a.cc9,a.cc10,a.cc11,a.cc12,a.cc17,a.cc18,a.cc19,a.cc21,a.cc22,a.cc23,a.cc27,a.cc28,a.cc29,a.cc33,a.cc34,a.cc35,a.cc39,a.cc40,a.cc46,a.cc47,a.cc48,a.cc51,a.cc52,a.cc54,a.cc55,a.cc56,a.cc57,a.cc58,a.cc59,a.cc60,a.cc70,a.cc71,a.cc72,a.cc73,a.cc74,a.cc75,a.cc76,a.cc77,a.cc78,a.cc79,a.cc80,a.cc82,a.cc83,a.cc84,a.cc85,a.cc86,a.cc87,a.cc88,a.cc96,a.cc99,a.cc100,a.cc103,a.cc104,a.cc106,a.cc107,a.cc108,a.cc110,a.cc111,a.cc112,a.cc114,a.cc115,a.cc122,a.cc124,a.cc134,a.cc135,a.cc136,a.cc137,a.cc138,a.cc157,a.cc158,a.cc159,a.cc161,a.cc162,a.cc166,a.cc167,a.cc169,a.cc170,a.cc173,a.cc176,a.cc186,a.cc188,a.cc189,a.hicno,a.dob,a.sex,a.nemcaid,a.orec,a.f0_34,a.f35_44,a.f45_54,a.f55_59,a.f60_64,a.f65_69,a.f70_74,a.f75_79,a.f80_84,a.f85_89,a.f90_94,a.f95_gt,a.m0_34,a.m35_44,a.m45_54,a.m55_59,a.m60_64,a.m65_69,a.m70_74,a.m75_79,a.m80_84,a.m85_89,a.m90_94,a.m95_gt,a.disabl,a.origds,a.nef0_34,a.nef35_44,a.nef45_54,a.nef55_59,a.nef60_64,a.nef65,a.nef66,a.nef67,a.nef68,a.nef69,a.nef70_74,a.nef75_79,a.nef80_84,a.nef85_89,a.nef90_94,a.nef95_gt,a.nem0_34,a.nem35_44,a.nem45_54,a.nem55_59,a.nem60_64,a.nem65,a.nem66,a.nem67,a.nem68,a.nem69,a.nem70_74,a.nem75_79,a.nem80_84,a.nem85_89,a.nem90_94,a.nem95_gt,a.score_community_na,a.score_community_nd,a.score_community_fba,a.score_community_fbd,a.score_community_pba,a.score_community_pbd,a.score_institutional,a.score_new_enrollee,a.score_snp_new_enrollee,a.month,a.year,a.ins_tsmtp from (
Select * ,row_number() over (partition by hicno order by ins_tsmtp desc) rn from IDENTIFIER(:V_HCC_OUTPUT_UNION_HISTORY_TEMP)) a
where a.rn=1;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCC_OUTPUT_UNION_HISTORY_FINAL)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP10'';

V_STEP_NAME :=  ''insert the data into table hcc_scoring_yearly'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

delete from IDENTIFIER(:V_HCC_SCORING_YEARLY) where year=:V_CURRENT_YEAR;

insert into IDENTIFIER(:V_HCC_SCORING_YEARLY)
select hcc1,hcc2,hcc6,hcc8,hcc9,hcc10,hcc11,hcc12,hcc17,hcc18,hcc19,hcc21,hcc22,hcc23,hcc27,hcc28,hcc29,hcc33,hcc34,hcc35,hcc39,hcc40,hcc46,hcc47,hcc48,hcc51,hcc52,hcc54,hcc55,hcc56,hcc57,hcc58,hcc59,hcc60,hcc70,hcc71,hcc72,hcc73,hcc74,hcc75,hcc76,hcc77,hcc78,hcc79,hcc80,hcc82,hcc83,hcc84,hcc85,hcc86,hcc87,hcc88,hcc96,hcc99,hcc100,hcc103,hcc104,hcc106,hcc107,hcc108,hcc110,hcc111,hcc112,hcc114,hcc115,hcc122,hcc124,hcc134,hcc135,hcc136,hcc137,hcc138,hcc157,hcc158,hcc159,hcc161,hcc162,hcc166,hcc167,hcc169,hcc170,hcc173,hcc176,hcc186,hcc188,hcc189,agef,cc1,cc2,cc6,cc8,cc9,cc10,cc11,cc12,cc17,cc18,cc19,cc21,cc22,cc23,cc27,cc28,cc29,cc33,cc34,cc35,cc39,cc40,cc46,cc47,cc48,cc51,cc52,cc54,cc55,cc56,cc57,cc58,cc59,cc60,cc70,cc71,cc72,cc73,cc74,cc75,cc76,cc77,cc78,cc79,cc80,cc82,cc83,cc84,cc85,cc86,cc87,cc88,cc96,cc99,cc100,cc103,cc104,cc106,cc107,cc108,cc110,cc111,cc112,cc114,cc115,cc122,cc124,cc134,cc135,cc136,cc137,cc138,cc157,cc158,cc159,cc161,cc162,cc166,cc167,cc169,cc170,cc173,cc176,cc186,cc188,cc189,hicno,dob,sex,nemcaid,orec,f0_34,f35_44,f45_54,f55_59,f60_64,f65_69,f70_74,f75_79,f80_84,f85_89,f90_94,f95_gt,m0_34,m35_44,m45_54,m55_59,m60_64,m65_69,m70_74,m75_79,m80_84,m85_89,m90_94,m95_gt,disabl,origds,nef0_34,nef35_44,nef45_54,nef55_59,nef60_64,nef65,nef66,nef67,nef68,nef69,nef70_74,nef75_79,nef80_84,nef85_89,nef90_94,nef95_gt,nem0_34,nem35_44,nem45_54,nem55_59,nem60_64,nem65,nem66,nem67,nem68,nem69,nem70_74,nem75_79,nem80_84,nem85_89,nem90_94,nem95_gt,score_community_na,score_community_nd,score_community_fba,score_community_fbd,score_community_pba,score_community_pbd,score_institutional,score_new_enrollee,score_snp_new_enrollee,month,
ins_tsmtp,year from IDENTIFIER(:V_HCC_OUTPUT_UNION_HISTORY_FINAL) order by hicno;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCC_SCORING_YEARLY)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);


RAISE;

END;

';