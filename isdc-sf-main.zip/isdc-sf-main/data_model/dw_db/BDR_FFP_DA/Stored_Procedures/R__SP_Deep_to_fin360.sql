USE SCHEMA BDR_FFP_DA;
CREATE OR REPLACE PROCEDURE SP_DEEP_TO_FIN360_AUT("PIPELINE_ID" VARCHAR(16777216), "PIPELINE_NAME" VARCHAR(16777216), "DB_NAME" VARCHAR(16777216), "UTIL_SC" VARCHAR(16777216), "SRC_SC" VARCHAR(16777216), "TGT_SC" VARCHAR(16777216), "INTRM_SC" VARCHAR(16777216), "STAGE_NAME" VARCHAR(16777216), "WH" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '

DECLARE


V_CURRENT_DATE   DATE := COALESCE(CURRENT_DATE(), CURRENT_DATE());

V_SP_PROCESS_RUN_LOGS_DTL VARCHAR := :DB_NAME||''.''||COALESCE(:UTIL_SC, ''UTIL'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';

V_PROCESS_NAME   VARCHAR DEFAULT ''DEEP_TO_FIN360_AUT'';

V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''DEEP_TO_FIN360_AUT'';

V_STEP             VARCHAR;

V_STEP_NAME        VARCHAR;

V_START_TIME       VARCHAR;

V_END_TIME         VARCHAR;

V_ROWS_PARSED       INTEGER;

V_ROWS_LOADED       INTEGER;

V_MESSAGE          VARCHAR;

V_LAST_QUERY_ID    VARCHAR;

V_FILE_QUERY VARCHAR;

V_FILE_QUERY1 VARCHAR;

V_FILE_QUERY2 VARCHAR;
V_FILE_QUERY3 VARCHAR;
V_FILE_QUERY4 VARCHAR;
V_FILE_QUERY5 VARCHAR;
V_FILE_QUERY6 VARCHAR;
V_FILE_QUERY7 VARCHAR;

V_FED_MEMBERS VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''SRC_UCEE'') || ''.FED_MEMBERS'';

V_NEW_CATEGORIZATION_PSC_ALL VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''SRC_UCEE'') || ''.NEW_CATEGORIZATION_PSC_ALL'';

V_INFORCE_CI_MBR_FINAL4 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.INFORCE_CI_MBR_FINAL4'';

V_ALL_APPS_FEDERAL VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''SRC_UCEE'') || ''.ALL_APPS_FEDERAL'';

-----QC Tables

BEGIN

 EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP1'';

V_STEP_NAME :=  ''Blob fed_members File Creation'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

use secondary roles all;

V_FILE_QUERY := ''COPY INTO ''||''@UTIL.STAGE_AZURE_ISDC/analytics/outbox/deep_to_fin360/fed_members_''||(:V_CURRENT_DATE)||''.csv.gz
 FROM (
select prod_id AS "prod_id",
contract_id_cd AS "contract_id_cd",
lob_id AS "lob_id",
sh_mbr_fg AS "sh_mbr_fg",
evc_mbr_fg AS "evc_mbr_fg",
mbr_plan_eff_dt AS "mbr_plan_eff_dt",
dsenrl_dt AS "dsenrl_dt",
plan_cat_nm AS "plan_cat_nm",
indvdl_id as "indvdl_id",
pdp_mbr_fg as "pdp_mbr_fg",
plan_desc as "plan_desc",
fips_cnty_cd as "fips_cnty_cd",
medicare_hicn_cd as "medicare_hicn_cd",
amc_mbr_fg as "amc_mbr_fg",
appl_id_cd	as "appl_id_cd"
from SRC_UCEE.FED_MEMBERS)

FILE_FORMAT = (TYPE = ''''csv''''
               FIELD_OPTIONALLY_ENCLOSED_BY= NONE
               -------ESCAPE_UNCLOSED_FIELD = NONE
               EMPTY_FIELD_AS_NULL = FALSE
               FIELD_DELIMITER = ''''|''''
               record_delimiter = ''''\\n''''
			   compression = GZIP 
               NULL_IF = (''''''''))             
                             
            
HEADER = True
OVERWRITE = True
MAX_FILE_SIZE = 4900000000
SINGLE = True'';


execute immediate  :V_FILE_QUERY;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED,NULL, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP2'';

V_STEP_NAME :=  ''Blob inforce_ci_mbr_final4 File Creation'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


V_FILE_QUERY1 := ''COPY INTO ''||''@UTIL.STAGE_AZURE_ISDC/analytics/outbox/deep_to_fin360/inforce_ci_mbr_final4_''||(:V_CURRENT_DATE)||''.csv.gz FROM (
select 
pers_id as "pers_id",
prem_due_mo_id as "prem_due_mo_id",
d_st_cd as "d_st_cd",
prdct_typ as "prdct_typ",
prdct_acqn_chnl_lvl_1 as "prdct_acqn_chnl_lvl_1",
cert_acqn_chnl_lvl_1 as "cert_acqn_chnl_lvl_1",
pln_lvl as "pln_lvl",
pln_lvl_desc as "pln_lvl_desc",
pln_typ as "pln_typ",
dscnt_annl_payr_desc as "dscnt_annl_payr_desc",
dscnt_eft_desc as "dscnt_eft_desc",
dscnt_erly_enrl_flg as "dscnt_erly_enrl_flg",
dscnt_erly_enrl_desc as "dscnt_erly_enrl_desc",
dscnt_erly_enrl_nm as "dscnt_erly_enrl_nm",
rtng_area_cd as "rtng_area_cd",
gdr_desc as "gdr_desc",
dscnt_multi_insd_flg as "dscnt_multi_insd_flg",
e_alliance_new_category as "e_alliance_new_category",
e_alliance_old_category as "e_alliance_old_category",
e_alliance_partner_name as "e_alliance_partner_name",
ealliance_cat_new as "ealliance_cat_new",
ealliance_partner_name_new as "ealliance_partner_name_new",
ealliance_pref_nm as "ealliance_pref_nm",
surchrg_tbcc_user_flg as "surchrg_tbcc_user_flg",
dscnt_erly_enrl_yr as "dscnt_erly_enrl_yr",
dscnt_erly_enrl_adj_amt as "dscnt_erly_enrl_adj_amt",
undwr_pln_rqr_txt as "undwr_pln_rqr_txt",
undwr_prdct_rqr_txt as "undwr_prdct_rqr_txt",
prem_due_age_id as "prem_due_age_id",
prem_due_age as "prem_due_age",
zip_cd as "zip_cd",
cnty_cd as "cnty_cd",
cty as "cty",
cnty_nm as "cnty_nm",
rt_dtrm_cd_desc as "rt_dtrm_cd_desc",
lgl_enty_nm as "lgl_enty_nm",
lgl_enty_shrt_desc as "lgl_enty_shrt_desc",
prdct_eff_mo_id as "prdct_eff_mo_id",
surchrg_tier_desc as "surchrg_tier_desc",
cert_eff_mo_id as "cert_eff_mo_id",
d_dscnt_lngvty_sk as "d_dscnt_lngvty_sk",
prdct_eff_dt as "prdct_eff_dt",
uw_pln_rqr_txt as "uw_pln_rqr_txt",
uw_prdct_rqr_txt as "uw_prdct_rqr_txt",
age_at_enrollment as "age_at_enrollment",
rtng_area_nm as "rtng_area_nm",
prem_due_dt as "prem_due_dt",
ref_ealliance_pref_nm_final as "ref_ealliance_pref_nm_final",
marketing_channel_final as "marketing_channel_final",
partb_eff_age_lessthan65 as "partb_eff_age_lessthan65",
plan as "plan",
mbr as "mbr",
paid_prem as "paid_prem",
dscnt_pd_annl_payr_amt as "dscnt_pd_annl_payr_amt",
dscnt_pd_eft_amt as "dscnt_pd_eft_amt",
dscnt_pd_erly_enrl_amt as "dscnt_pd_erly_enrl_amt",
dscnt_pd_lngvty_amt as "dscnt_pd_lngvty_amt",
dscnt_pd_multi_insd_amt as "dscnt_pd_multi_insd_amt",
surchrg_pd_tbcc_user_amt as "surchrg_pd_tbcc_user_amt",
surchrg_pd_tier_amt as "surchrg_pd_tier_amt",
aarp_final_prem as "aarp_final_prem",
fips as "fips",
baserating as "baserating",
statename as "statename",
total_paid_prem as "total_paid_prem",
total_claims as "total_claims",
total_claim_cf_covid as "total_claim_cf_covid",
loss_ratio as "loss_ratio",
covid_adj_loss_ratio as "covid_adj_loss_ratio"
from BDR_FFP_DA.INFORCE_CI_MBR_FINAL4 )

               
file_format = (type = ''''CSV'''' 
			   FIELD_OPTIONALLY_ENCLOSED_BY= NONE
			   EMPTY_FIELD_AS_NULL = FALSE
               FIELD_DELIMITER = ''''|''''
               record_delimiter = ''''\\n''''
               compression = GZIP 
			   NULL_IF = (''''''''))
			   
			   
HEADER = True
OVERWRITE = True
MAX_FILE_SIZE = 4900000000
SINGLE = True'';


execute immediate  :V_FILE_QUERY1;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED,NULL, NULL, NULL, NULL);
 


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP3'';

V_STEP_NAME :=  ''Blob new_categorization_psc_all_txt File Creation'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

use secondary roles all;
 
V_FILE_QUERY2 := ''COPY INTO ''||''@UTIL.STAGE_AZURE_ISDC/analytics/outbox/deep_to_fin360/new_categorization_psc_all_''||(:V_CURRENT_DATE)||''.csv.gz FROM (
select
psc as "psc",
value_prop_name as "value_prop_name" ,
value_prop_desc as "value_prop_desc",
psc_mkt as "psc_mkt" ,
psc_lob  as "psc_lob" ,
psc_prod as "psc_prod" ,
medium as "medium" ,
sub_medium as "sub_medium" ,
classification as "classification" ,
initiative as "initiative" ,
creative as "creative" ,
audience as "audience" ,
sub_audience as "sub_audience" ,
requestor_nm as "requestor_nm" ,
intended_live_date as  "intended_live_date" ,
psc_month as "psc_month" ,
tfn as "tfn" ,
tfn_eff_dt as "tfn_eff_dt" ,
project_cd as "project_cd" ,
sales_campaign as "sales_campaign" ,
objective as "objective" ,
productoffer as "productoffer" ,
enrollmentoption as "enrollmentoption" ,
period as "period" ,
leadsource as "leadsource" ,
campaign as "campaign" ,
channel as "channel" ,
mktgmedium as "mktgmedium" ,
version as "version" ,
geography as "geography" ,
language as "language" ,
pricing as "pricing" ,
brand as "brand" ,
calltoaction as "calltoaction" ,
type as "type" ,
requester as "requester" ,
budgetmonth as "budgetmonth" ,
enddate as "enddate" ,
status as "status" ,
lob as "lob" ,
site as "site" ,
issourcecode as "issourcecode",
istfn as "istfn",
reporting as "reporting",
callexperience as "callexperience",
costperpiece as "costperpiece",
bilingual_flag as "bilingual_flag",
responseid as "responseid",
depot_project_cd as "depot_project_cd",
project_id as "project_id",
project_nm as "project_nm",
template_nm as "template_nm",
project_rqst_fg as "project_rqst_fg",
root_project_id as "root_project_id",
parent_project_cd as "parent_project_cd",
parent_project_id as "parent_project_id",
parent_project_nm as "parent_project_nm",
program_cd as "program_cd",
program_nm as "program_nm",
plan_cd as "plan_cd",
plan_nm as "plan_nm",
in_home_dt as "in_home_dt",
project_budget_amt as "project_budget_amt",
circulation_qty as "circulation_qty",
call_qty as "call_qty",
brc_qty as "brc_qty",
lead_qty as "lead_qty",
appl_ma_qty as "appl_ma_qty",
appl_pdp_qty as "appl_pdp_qty",
appl_mr_snp_qty as "appl_mr_snp_qty",
tgt_universe_qty as "tgt_universe_qty",
ins_pqid as "ins_pqid",
ins_rid as "ins_rid",
ins_srcid as "ins_srcid",
ins_tstmp as "ins_tstmp",
pscprojectcode as "pscprojectcode",
pscname as "pscname",
inhomedate as "inhomedate"
from SRC_UCEE.NEW_CATEGORIZATION_PSC_ALL)
               

file_format = (type = ''''CSV'''' 
			   FIELD_OPTIONALLY_ENCLOSED_BY= NONE
			   EMPTY_FIELD_AS_NULL = FALSE
               field_delimiter = ''''~''''
               record_delimiter = ''''\\n''''
			   NULL_IF = ('''''''')
			   compression = GZIP
---------------FIELD_OPTIONALLY_ENCLOSED_BY=''''"''''
              )
HEADER = True
OVERWRITE = True
MAX_FILE_SIZE = 4900000000
SINGLE = True'';


execute immediate  :V_FILE_QUERY2;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED,NULL, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP4'';

V_STEP_NAME :=  ''Blob qc_deep_to_fin360_auto File Creation'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

use secondary roles all;
 
V_FILE_QUERY3 := ''COPY INTO ''||''@UTIL.STAGE_AZURE_ISDC/analytics/outbox/deep_to_fin360/qc_deep_to_fin360_auto_''||(:V_CURRENT_DATE)||''.txt''||'' FROM (
select ''''new_categorization_psc_all'''' as "table_name", count(*)+1 as "total_file_count" ,count(*) as "table_count" 
from SRC_UCEE.NEW_CATEGORIZATION_PSC_ALL

UNION ALL

select ''''fed_members'''' as "table_name", count(*)+1 as "total_file_count" ,count(*) as "table_count" 
from SRC_UCEE.FED_MEMBERS

UNION ALL

select ''''inforce_ci_mbr_final4'''' as "table_name", count(*)+1 as "total_file_count" ,count(*) as "table_count" 
from BDR_FFP_DA.INFORCE_CI_MBR_FINAL4)
               

file_format = (field_delimiter = '''',''''
               record_delimiter = ''''\\n''''
			   compression = None 
			   -----NULL_IF = ('''''''')
----------FIELD_OPTIONALLY_ENCLOSED_BY = ''''"''''
			    )
HEADER = True
OVERWRITE = True
MAX_FILE_SIZE = 4900000000
SINGLE = True'';


execute immediate  :V_FILE_QUERY3;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED,NULL, NULL, NULL, NULL);
 


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP5'';

V_STEP_NAME :=  ''Blob mndeep_deep_to_fin360_auto File Creation'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


V_FILE_QUERY4 := ''COPY INTO ''||''@UTIL.STAGE_AZURE_ISDC/analytics/outbox/deep_to_fin360/mndeep_deep_to_fin360_auto''||''.trig''||'' FROM (
select ''''  '''' from dual )
               

FILE_FORMAT = (		   
			   COMPRESSION = NONE
              )            

HEADER = FALSE
OVERWRITE = True
MAX_FILE_SIZE = 4900000000
SINGLE = True'';
              

execute immediate  :V_FILE_QUERY4;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED,NULL, NULL, NULL, NULL);
 

V_FILE_QUERY5 := ''COPY INTO ''||''@UTIL.STAGE_AZURE_ISDC/analytics/outbox/deep_to_fin360/all_apps_federal_'' ||(:V_CURRENT_DATE)||''.csv.gz FROM (
select
bus as "bus",
appl_dt as "appl_dt",
plan_eff_dt as "plan_eff_dt",
adjudication_dt as "adjudication_dt",
indvdl_id as "indvdl_id",
plan_lob_id as "plan_lob_id",
gps_plan_cd as "gps_plan_cd",
appl_id_cd as "appl_id_cd",
attr_rule_set_cd as "attr_rule_set_cd",
chnl_id as "chnl_id",
broker_id_cd as "broker_id_cd",
prod_id as "prod_id",
contract_id_cd as "contract_id_cd",
credited_psc_trtmnt_cd as "credited_psc_trtmnt_cd",
zip_cd as "zip_cd",
hh_id as "hh_id",
medicare_hicn_cd as "medicare_hicn_cd",
adjudication_stat_cd as "adjudication_stat_cd",
adjudication_stat_desc as "adjudication_stat_desc",
src_sys_srcid as "src_sys_srcid",
appl_src_cd as "appl_src_cd",
gps_appl_src_cd as "gps_appl_src_cd",
appl_src_desc as "appl_src_desc",
application_source_desc as "application_source_desc",
lob as "lob",
prod_cd as "prod_cd",
chnl_desc as "chnl_desc",
stfips as "stfips",
sar_segment as "sar_segment",
sar_contract as "sar_contract",
sar as "sar",
sar_plan_name as "sar_plan_name",
sar_plan_type as "sar_plan_type",
product as "product",
app_channel as "app_channel",
week_end_dt as "week_end_dt",
attr_cd as "attr_cd",
online_app as "online_app",
plan_change as "plan_change",
dup as "dup",
product_segments as "product_segments",
status as "status",
gps_salesinitiative as "gps_salesinitiative",
plan_cd as "plan_cd",
year as "year"
from SRC_UCEE.ALL_APPS_FEDERAL where year >=2020)
               

file_format = (type = ''''CSV'''' 
			   FIELD_OPTIONALLY_ENCLOSED_BY= NONE
			   EMPTY_FIELD_AS_NULL = FALSE
               field_delimiter = ''''|''''
               record_delimiter = ''''\\n''''
			   NULL_IF = ('''''''')
			   compression = GZIP
---------------FIELD_OPTIONALLY_ENCLOSED_BY=''''"''''
              )
HEADER = True
OVERWRITE = True
MAX_FILE_SIZE = 4900000000
SINGLE = True'';


execute immediate  :V_FILE_QUERY5;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED,NULL, NULL, NULL, NULL);


V_FILE_QUERY6 := ''COPY INTO ''||''@UTIL.STAGE_AZURE_ISDC/analytics/outbox/deep_to_fin360/qc_all_apps_federal_''||(:V_CURRENT_DATE)||''.txt''||'' FROM (
select count(*)+1 as "total_file_count" ,count(*) as "table_count" 
from SRC_UCEE.ALL_APPS_FEDERAL where year >=2020)
               

file_format = (field_delimiter = '''',''''
               record_delimiter = ''''\\n''''
			   compression = None 
			   -----NULL_IF = ('''''''')
----------FIELD_OPTIONALLY_ENCLOSED_BY = ''''"''''
			    )
HEADER = False
OVERWRITE = True
MAX_FILE_SIZE = 4900000000
SINGLE = True'';

execute immediate  :V_FILE_QUERY6;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED,NULL, NULL, NULL, NULL);

V_FILE_QUERY7 := ''COPY INTO ''||''@UTIL.STAGE_AZURE_ISDC/analytics/outbox/deep_to_fin360/mndeep_ucee_apps_federal''||''.trig''||'' FROM (
select ''''  '''' from dual )
               

FILE_FORMAT = (		   
			   COMPRESSION = NONE
              )            

HEADER = FALSE
OVERWRITE = True
MAX_FILE_SIZE = 4900000000
SINGLE = True'';

execute immediate  :V_FILE_QUERY7;



EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);



RAISE;

END;

';