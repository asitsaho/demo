USE SCHEMA BDR_FFP_DA;




CREATE OR REPLACE PROCEDURE BDR_FFP_DA.SP_RTO_CALL_CENTER("PIPELINE_ID" VARCHAR(16777216), "PIPELINE_NAME" VARCHAR(16777216), "DB_NAME" VARCHAR(16777216), "UTIL_SC" VARCHAR(16777216), "TGT_SC" VARCHAR(16777216), "SRC_SC" VARCHAR(16777216), "SRC_SC_1" VARCHAR(16777216), "SRC_SC_2" VARCHAR(16777216), "SRC_SC_3" VARCHAR(16777216), "SRC_SC_4" VARCHAR(16777216), "SRC_SC_5" VARCHAR(16777216), "INTRM_SC" VARCHAR(16777216), "WH" VARCHAR(16777216), "CURR_DATE" DATE)
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

 
---V_REPORT_DATE DATE := to_varchar(:V_CURRENT_DATE(),''yyyymmdd'');          

V_REPORT_DATE VARCHAR := to_varchar(COALESCE(:CURR_DATE, CURRENT_DATE()),''mmddyyyy'');

V_REPORT_DATE_YMD VARCHAR := to_varchar(COALESCE(:CURR_DATE, CURRENT_DATE()),''yyyymmdd'');

V_CURRENT_DATE   VARCHAR := COALESCE((:CURR_DATE), CURRENT_DATE());

V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS  VARCHAR := :DB_NAME||''.''||COALESCE(:UTIL_SC, ''UTIL'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';

V_PROCESS_NAME   VARCHAR DEFAULT ''RTO_CALL_CENTER'';

V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''RTO_PROCESS'';

V_STEP             VARCHAR;

V_STEP_NAME        VARCHAR;

V_START_TIME       VARCHAR;

V_END_TIME         VARCHAR;

V_ROWS_PARSED       INTEGER;

V_ROWS_LOADED       INTEGER;

V_MESSAGE          VARCHAR;

V_LAST_QUERY_ID    VARCHAR;



V_MEMBERSHIP_RTO_DAILY VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_MEMBERSHIP_RTO_DAILY'';

V_F_PREM_TRANS_DAY VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_1, ''BDR_DM'') || ''.F_PREM_TRANS_DAY''; 

V_D_PLN_BEN_MOD VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_2, ''BDR_CONF'') || ''.D_PLN_BEN_MOD'';

V_D_MBR_INFO VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_2, ''BDR_CONF'') || ''.D_MBR_INFO'';

V_D_ACQN_CHNL VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_2, ''BDR_CONF'') || ''.D_ACQN_CHNL'';

V_MEMBER_DATA_CAM_RTO_DAILY VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_MEMBER_DATA_CAM_RTO_DAILY'';

V_VOLN_LAPSE_RTO_DAILY VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_VOLN_LAPSE_RTO_DAILY'';

V_LAPSE_RTO_DAILY VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_LAPSE_RTO_DAILY'';

V_STR_LAPSE_RTO_DAILY VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_STR_LAPSE_RTO_DAILY'';

V_D_GEO_XREF VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_2, ''BDR_CONF'') || ''.D_GEO_XREF'';

V_D_ST VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_2, ''BDR_CONF'') || ''.D_ST'';

V_D_CERT_ACTV  VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_2, ''BDR_CONF'') || ''.D_CERT_ACTV '';

V_AC_WEB_REGISTRATION VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.V_AC_WEB_REGISTRATION'';

V_COMBINED_VAS VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_COMBINED_VAS'';

V_EFT_OCSS VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_EFT_OCSS'';

V_HCO_CONTACT_REASON_SUB_TYPE VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.HCO_CONTACT_REASON_SUB_TYPE'';

V_COUNTY VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.COUNTY'';

V_OCSS_CAMP_EFT VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_OCSS_CAMP_EFT'';

---DOUBT
V_RTO_CALL_CENTER_NEW VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.COMMON_RTO_CALL_CENTER_NEW'';

V_PULL_PERSON_YTD_OCSS VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_PULL_PERSON_YTD_OCSS'';

V_PULL_COUNTY_YTD_OCSS VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_PULL_COUNTY_YTD_OCSS'';

V_MYDIRECTIVES_ADVANCE_CARE VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.MYDIRECTIVES_ADVANCE_CARE'';

V_STATE VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.STATE'';

V_PULL_PERSON_OCSS VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_PULL_PERSON_OCSS'';

V_AMERILINK_DATA VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.AMERILINK_DATA'';

V_PERSON VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.PERSON'';

V_PERSON_PAYMENT_METHOD VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.PERSON_PAYMENT_METHOD'';

----V_RTO_CC_OCSS_YTD_SUM VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.RTO_CC_OCSS_YTD_SUM'';

V_HCO_CONTACT_REASON_TYPE VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.HCO_CONTACT_REASON_TYPE'';

V_PULL_GEOG_OCSS VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_PULL_GEOG_OCSS'';

V_OCSS_AGENTS_STATIC VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_OCSS_AGENTS_STATIC'';

V_OCSS_BASE_CALLS VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_OCSS_BASE_CALLS'';

V_NHL_3_OCSS VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_NHL_3_OCSS'';

V_NHL_201567_DB_ICUE VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_5 , ''SRC_MPO'') || ''.NHL_201567_DB_ICUE'';

V_OCSS_REASON_DYNAMIC VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_OCSS_REASON_DYNAMIC'';

V_DEATH_LAPSE_OCSS VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_DEATH_LAPSE_OCSS'';

V_OCSS_METRIC_BASE VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_OCSS_METRIC_BASE'';

V_PERSON_ADDRESS_CURR_PERM VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.PERSON_ADDRESS_CURR_PERM'';

V_OCSS_TENURE VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_OCSS_TENURE'';

V_PULL_COUNTY_OCSS VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_PULL_COUNTY_OCSS'';

V_OCSS_CAMP_EB VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_OCSS_CAMP_EB'';

V_VOL_LAPSE_OCSS VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_VOL_LAPSE_OCSS'';

V_PERSON_HCO_CONTACT_REQUEST VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.PERSON_HCO_CONTACT_REQUEST'';

V_OCSS_ONLY VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_OCSS_ONLY'';

---V_STR_LAPSE_RTO_DAILY VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_STR_LAPSE_RTO_DAILY'';

V_PULL_GEOG_YTD_OCSS VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_PULL_GEOG_YTD_OCSS'';

V_PULL_STATE_OCSS VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_PULL_STATE_OCSS'';

V_OPTUM_SHIP_VAS_ENGAGE_ANALYSIS VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.OPTUM_SHIP_VAS_ENGAGE_ANALYSIS'';

V_PULL_STATE_YTD_OCSS VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_PULL_STATE_YTD_OCSS'';

V_YTD_OCSS_TENURE VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_YTD_OCSS_TENURE'';

V_PAID_SALE_OCSS VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_PAID_SALE_OCSS'';

V_OCSS_CALL VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_OCSS_CALL'';

V_SHIP_PERSON_XREF VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.SHIP_PERSON_XREF'';

V_PULL_AMERILINK_OCSS VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_PULL_AMERILINK_OCSS'';

V_OCSS_YTD_BASE VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_OCSS_YTD_BASE'';

V_RTO_CONTACT_HISTORY VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.RTO_CONTACT_HISTORY'';

V_CALL_SUMM_OCSS VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_CALL_SUMM_OCSS'';

V_SUMM_DATA_YTD_OCSS VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_SUMM_DATA_YTD_OCSS'';

V_OPTUM_SHIP_VAS_ENGAGEMENT VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.OPTUM_SHIP_VAS_ENGAGEMENT'';

V_OCSS_DIME VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_OCSS_DIME'';

V_RTO_RESPONSE_HISTORY VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.RTO_RESPONSE_HISTORY'';

V_TEMP2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_TEMP2'';

V_WEB_REG_OCSS VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_WEB_REG_OCSS'';

V_AUXILIARY_PERSON VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_4, ''SRC_COMPAS'') || ''.AUXILIARY_PERSON'';

V_APPS_RPTG_DAILY VARCHAR := :DB_NAME || ''.'' || COALESCE(: SRC_SC_3, ''SRC_MPO'') || ''.APPS_RPTG_DAILY'';

V_PULL_AMERILINK_YTD_OCSS VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_PULL_AMERILINK_YTD_OCSS'';

V_SHIP_OCSS VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_SHIP_OCSS'';

V_OCSS_OVERALL_BASE VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_OCSS_OVERALL_BASE'';

V_RTO_ENHANCEMENTS VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_RTO_ENHANCEMENTS'';

V_OCSS_CONTROL VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_OCSS_CONTROL'';

V_TEMP1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_TEMP1'';

V_SWITCH_OCSS VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_SWITCH_OCSS'';

V_TEMP VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_TEMP'';

---V_MEMBER_DATA_CAM_RTO_DAILY VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_MEMBER_DATA_CAM_RTO_DAILY'';

V_OCSS_YTD_SUM VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.RTO_CC_OCSS_YTD_SUM'';

V_V_OCSS_YTD_SUM VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.V_RTO_CC_OCSS_YTD_SUM'';

V_ACP_OCSS VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_ACP_OCSS'';

V_SUMM_DATA_OCSS VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_SUMM_DATA_OCSS'';

V_OCSS_METRIC_SUM VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.RTO_CC_OCSS_METRIC_SUM'';

V_V_OCSS_METRIC_SUM VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.V_RTO_CC_OCSS_METRIC_SUM'';

----V_RTO_CC_OCSS_METRIC_SUM VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA'') || ''.RTO_CC_OCSS_METRIC_SUM'';

V_OCSS_YTD_BASE_QC1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_OCSS_YTD_BASE_QC1'';

V_OCSS_YTD_BASE_QC2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_OCSS_YTD_BASE_QC2'';

V_OCSS_YTD_BASE_QC3 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_OCSS_YTD_BASE_QC3'';

V_OCSS_YTD_BASE_QC VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_OCSS_YTD_BASE_QC'';

V_SUMM_DATA_OCSS_QC1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_SUMM_DATA_OCSS_QC1'';

V_SUMM_DATA_OCSS_QC2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_CC_SUMM_DATA_OCSS_QC2'';


BEGIN

----rto_process1 


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP1'';

V_STEP_NAME :=  ''create MEMBERSHIP_RTO_DAILY table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_MEMBERSHIP_RTO_DAILY)  COPY GRANTS as
select distinct * from (select pers_id, prdct_eff_dt_id, pln_lvl,prod_ACQN_CHNL_LVL_1 
from (select PREM_DUE_DT_ID,prdct_eff_dt_id,CERT_EFF_DT_ID, a15.pers_id
,a23.ACQN_CHNL_LVL_1 as prod_ACQN_CHNL_LVL_1,
  a12.pln_lvl,
sum(a11.PD_CERT_QTY + a11.DELQ_CERT_QTY)  as cert_cnt
from IDENTIFIER(:V_F_PREM_TRANS_DAY) a11
               left outer join IDENTIFIER(:V_D_PLN_BEN_MOD) a12
                 on (a11.D_PLN_BEN_MOD_SK = a12.D_PLN_BEN_MOD_SK)
               left join  IDENTIFIER(:V_D_MBR_INFO) a15
                 on a11.d_mbr_info_sk = a15.d_mbr_info_sk
                 left join IDENTIFIER(:V_D_ACQN_CHNL) a23
                 on (a11.prdct_D_ACQN_CHNL_SK = a23.D_ACQN_CHNL_SK)
                
where (trim(a12.LF_CATGY_NM) in (''Med Supp-Pre-Standardized'', ''Med Supp-Select'', ''Med Supp-Standardized/Modernized'')
and a11.PREM_DUE_DT_ID >= (20190801)) 
group by PREM_DUE_DT_ID,prdct_eff_dt_id,CERT_EFF_DT_ID, pers_id
,a23.ACQN_CHNL_LVL_1
,a12.pln_lvl having cert_cnt > 0)temp )b;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_MEMBERSHIP_RTO_DAILY));

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1));
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP2'';

V_STEP_NAME :=  ''create MEMBER_DATA_CAM_RTO_DAILY table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


CREATE OR REPLACE TABLE IDENTIFIER(:V_MEMBER_DATA_CAM_RTO_DAILY) COPY GRANTS as
select a.*,
cast(concat(substr(str_date2,1,4),''-'', substr(str_date2,5,2),''-'', substr(str_date2,7,2)) as date) as prdct_eff_date
from (select b.*, 
cast(prdct_eff_dt_id as string) as str_date2 from 
(select *
from (select pers_id, prdct_eff_dt_id, pln_lvl,prod_ACQN_CHNL_LVL_1,
row_number() over (partition by pers_id order by pers_id,pln_lvl,prod_ACQN_CHNL_LVL_1, prdct_eff_dt_id desc) as rn from IDENTIFIER(:V_MEMBERSHIP_RTO_DAILY) as a)temp where rn = 1) b)a;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_MEMBER_DATA_CAM_RTO_DAILY)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP3'';

V_STEP_NAME :=  ''create RTO_CC_VOLN_LAPSE_RTO_DAILY table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


CREATE OR REPLACE TABLE IDENTIFIER(:V_VOLN_LAPSE_RTO_DAILY)  COPY GRANTS as
select  PREM_DUE_dt_ID,prdct_eff_dt_id,CERT_EFF_dt_ID,pers_id,a16.CERT_ACTV_LVL_2_TXT,a16.CERT_ACTV_LVL_1_TXT
,a11.d_cert_actv_sk,
sum(a11.TERM_CERT_QTY) as term
from IDENTIFIER(:V_F_PREM_TRANS_DAY) a11
left outer join  IDENTIFIER(:V_D_PLN_BEN_MOD) a12
 on (a11.D_PLN_BEN_MOD_SK = a12.D_PLN_BEN_MOD_SK)
left outer join  IDENTIFIER(:V_D_GEO_XREF)     a13
 on        (a11.RES_D_GEO_XREF_SK = a13.D_GEO_XREF_SK)
left outer join     IDENTIFIER(:V_D_ST) a14
 on        (a13.D_ST_CD = a14.D_ST_CD)
 left join IDENTIFIER(:V_D_MBR_INFO) a15
 on a11.d_mbr_info_sk = a15.d_mbr_info_sk
 left join   IDENTIFIER(:V_D_CERT_ACTV)  a16
 on        (a11.D_CERT_ACTV_SK = a16.D_CERT_ACTV_SK)
where (trim(a12.LF_CATGY_NM) in (''Med Supp-Pre-Standardized'', ''Med Supp-Select'', ''Med Supp-Standardized/Modernized'')
and (a11.d_cert_actv_sk between 19 and 49 or a11.d_cert_actv_sk between 3 and 11)
and a11.PREM_DUE_dt_ID >= (20190801)
--and a11.PREM_DUE_dt_ID <= (${hivevar:last_date_of_month})
) 
group by PREM_DUE_dt_ID,prdct_eff_dt_id,CERT_EFF_dt_ID,pers_id,a16.CERT_ACTV_LVL_2_TXT,a16.CERT_ACTV_LVL_1_TXT
,a11.d_cert_actv_sk
having term > 0;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_VOLN_LAPSE_RTO_DAILY)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP4'';

V_STEP_NAME :=  ''create LAPSE_RTO_DAILY table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_LAPSE_RTO_DAILY) COPY GRANTS  as
select a.* from (
select b.*,
row_number() over (partition by pers_id order by pers_id, PREM_DUE_dt_ID desc) rn
from IDENTIFIER(:V_VOLN_LAPSE_RTO_DAILY) b) a
where rn =1;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_LAPSE_RTO_DAILY)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP5'';

V_STEP_NAME :=  ''create STR_LAPSE_RTO_DAILY table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


CREATE OR REPLACE TABLE IDENTIFIER(:V_STR_LAPSE_RTO_DAILY) COPY GRANTS as
select a.*, 
cast(concat(substr(str_date,1,4),''-'', substr(str_date,5,2),''-'', substr(str_date,7,2)) as date) as prem_due_date from
(select pers_id, d_cert_actv_sk,CERT_ACTV_LVL_2_TXT,CERT_ACTV_LVL_1_TXT,
cast(PREM_DUE_dt_ID as string) as str_date, term from   IDENTIFIER(:V_LAPSE_RTO_DAILY))a;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_STR_LAPSE_RTO_DAILY)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




------rto_process2



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP6'';

V_STEP_NAME :=  ''create OCSS_ONLY table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());



create or replace table IDENTIFIER(:V_OCSS_ONLY) COPY GRANTS as 
select a.*,
case when trim(event_name) = ''NOTDELIVERED'' or event_name is NULL then ''No'' ELSE ''Yes'' end as presented_fg
from IDENTIFIER(:V_RTO_RESPONSE_HISTORY) a
where (response_datetime) >= ''2020-02-09 00:00:00.0'' and uaci_interactive_channel_name = ''OCSS_IC''
and reason not in (''NOT OFFERED - NO OWNER'');


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_OCSS_ONLY)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);





EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP7'';

V_STEP_NAME :=  ''create TEMP1 table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

---order by response_datetime
--adding order by person_id,SHIP_PERSON_ID,date_id,interact_offer_code,reason,TREATMENT_CODE,is_session_id,OFFER_SCRIPT_ID,
---uaci_interactive_channel_name,response_datetime
create or replace table IDENTIFIER(:V_TEMP1) COPY GRANTS as select * from(select a.*,
row_number() over (partition by person_id,interact_offer_code,date_id,presented_fg
order by person_id,ship_person_id,date_id,interact_offer_code,reason,treatment_code,is_session_id,offer_script_id,
uaci_interactive_channel_name,response_datetime desc) as z1 
from IDENTIFIER(:V_OCSS_ONLY) as a )b where z1 = 1;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_TEMP1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP8'';

V_STEP_NAME :=  ''create TEMP2 table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_TEMP2) COPY GRANTS as select * from(select a.*,
row_number() over (partition by person_id,interact_offer_code,date_id
order by person_id,ship_person_id,date_id,interact_offer_code, reason,treatment_code,is_session_id,offer_script_id,
uaci_interactive_channel_name, presented_fg,response_datetime desc) as z2
from IDENTIFIER(:V_TEMP1) as a )b where z2 = 1;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_TEMP2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP9'';

V_STEP_NAME :=  ''create OCSS_REASON_DYNAMIC table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_OCSS_REASON_DYNAMIC) COPY GRANTS as select b.*,
case when trim(b.event_name) = ''ACCEPT'' then ''Yes'' ELSE ''No'' end as accept_fg,
case when trim(b.event_name) = ''REJECT'' then ''Yes'' ELSE ''No'' end as reject_fg,
case when trim(b.event_name) = ''UN_REJECT'' then ''Yes'' ELSE ''No'' end as un_reject_fg
from IDENTIFIER(:V_TEMP2) b;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_OCSS_REASON_DYNAMIC)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP10'';

V_STEP_NAME :=  ''create OCSS_YTD_BASE table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());



create or replace table IDENTIFIER(:V_OCSS_YTD_BASE) COPY GRANTS  as select * from
(select  person_id , ship_person_id , offer_business_id, interact_offer_code, offer_name, treatment_inst_id, treatment_code, response_datetime, date_id, time_id, event_type, event_name, uaci_interactive_channel_name, reason, is_session_id, offer_script_id, offer_content_id, row_ins_timestamp, row_updt_timestamp, presented_fg,z1, z2, accept_fg, reject_fg, un_reject_fg   from IDENTIFIER(:V_OCSS_AGENTS_STATIC) a
union all
select  person_id , ship_person_id , offer_business_id, interact_offer_code, offer_name, treatment_inst_id, treatment_code, response_datetime, date_id, time_id, event_type, event_name, uaci_interactive_channel_name, reason, is_session_id, offer_script_id, offer_content_id, row_ins_timestamp, row_updt_timestamp, presented_fg,z1, z2, accept_fg, reject_fg, un_reject_fg  from IDENTIFIER(:V_OCSS_REASON_DYNAMIC) b) unioned;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_OCSS_YTD_BASE)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP11'';

V_STEP_NAME :=  ''create PULL_PERSON_YTD_OCSS table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_PULL_PERSON_YTD_OCSS)  COPY GRANTS as
select a.*,b.GENDER_CODE,b.birth_date as person_birth_date, b.first_name,b.last_name
from IDENTIFIER(:V_OCSS_YTD_BASE)  as a left join IDENTIFIER(:V_PERSON) b 
on b.person_id=a.person_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_PULL_PERSON_YTD_OCSS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP12'';

V_STEP_NAME :=  ''create PULL_AMERILINK_YTD_OCSS table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_PULL_AMERILINK_YTD_OCSS) COPY GRANTS as
select distinct * from(select a.*, b.ESTINC19
from IDENTIFIER(:V_PULL_PERSON_YTD_OCSS) as a left join IDENTIFIER(:V_AMERILINK_DATA) b
on a.person_id=b.person_id)c;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_PULL_AMERILINK_YTD_OCSS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

--STATE


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP13'';

V_STEP_NAME :=  ''create PULL_GEOG_YTD_OCSS table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_PULL_GEOG_YTD_OCSS) COPY GRANTS as select a.*,b.state_code,b.zip_code,
county_code,zip_code_plus_4
from IDENTIFIER(:V_PULL_AMERILINK_YTD_OCSS) as a left join IDENTIFIER(:V_PERSON_ADDRESS_CURR_PERM) as b
on a.person_id = b.person_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_PULL_GEOG_YTD_OCSS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP14'';

V_STEP_NAME :=  ''create PULL_COUNTY_YTD_OCSS table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());



create or replace table IDENTIFIER(:V_PULL_COUNTY_YTD_OCSS) COPY GRANTS as select a.*, b.county_name
from IDENTIFIER(:V_PULL_GEOG_YTD_OCSS) as a left join IDENTIFIER(:V_COUNTY) as b
on TRIM(a.state_code) = TRIM(b.state_code)
and TRIM(a.county_code) = TRIM(b.fips_county_code);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_PULL_COUNTY_YTD_OCSS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP15'';

V_STEP_NAME :=  ''create PULL_STATE_YTD_OCSS table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());



create or replace table IDENTIFIER(:V_PULL_STATE_YTD_OCSS) COPY GRANTS as select a.*,state_name,
cast(concat(substr(date_id,1,4),''-'', substr(date_id,5,2),''-'',substr(date_id,7,2)) as date) as date_id2
from IDENTIFIER(:V_PULL_COUNTY_YTD_OCSS) as a left join IDENTIFIER(:V_STATE) as b
on a.state_code = b.state_code;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_PULL_STATE_YTD_OCSS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP16'';

V_STEP_NAME :=  ''create YTD_OCSS_TENURE table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());



create or replace table IDENTIFIER(:V_YTD_OCSS_TENURE) COPY GRANTS as select a.*,
case when UTIL.DATE_DIFF_UDF(date_id2,prdct_eff_date)/365.25 <= 1 THEN ''Less than 1yr''
when UTIL.DATE_DIFF_UDF(date_id2,prdct_eff_date)/365.25 >1 and UTIL.DATE_DIFF_UDF(date_id2,prdct_eff_date)/365.25 <=2 then ''1-2yrs''
when UTIL.DATE_DIFF_UDF(date_id2,prdct_eff_date)/365.25 >2 and UTIL.DATE_DIFF_UDF(date_id2,prdct_eff_date)/365.25 <=3 then ''2-3yrs''
when UTIL.DATE_DIFF_UDF(date_id2,prdct_eff_date)/365.25 >3 and UTIL.DATE_DIFF_UDF(date_id2,prdct_eff_date)/365.25 <=5 then ''3-5yrs''
when UTIL.DATE_DIFF_UDF(date_id2,prdct_eff_date)/365.25 >5 and UTIL.DATE_DIFF_UDF(date_id2,prdct_eff_date)/365.25 <=10 then ''5-10yrs''
when UTIL.DATE_DIFF_UDF(date_id2,prdct_eff_date)/365.25 >10 then ''10+yrs''
else ''Unknown'' end as tenure,
case when prod_ACQN_CHNL_LVL_1 is not NULL then prod_ACQN_CHNL_LVL_1 ELSE ''Unknown'' end as acq_channel,
case when pln_lvl is NULL then ''Unknown''
when trim(pln_lvl) in (''G01'',''G'',''G0'',''GS1'',''G02'', ''GS2'') then ''G'' --new change updated
when trim(pln_lvl) in (''F01'',''F0'',''F'',''FS1'',''F02'', ''FS2'') then ''F'' --new change updated
when trim(pln_lvl) in (''K01'',''K'') then ''K''
when trim(pln_lvl) in (''N01'',''NS1'',''N02'', ''NS2'') then ''N''  --new change updated
when trim(pln_lvl) in (''GH1'',''GH2'') then ''GH''  --new change updated (30-4-24)
else ''Other'' end as plan
from IDENTIFIER(:V_PULL_STATE_YTD_OCSS) as a left join IDENTIFIER(:V_MEMBER_DATA_CAM_RTO_DAILY) as b on
a.person_id = b.pers_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_YTD_OCSS_TENURE)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

-----------------rto enhancements---------------
 --new change updated till v_ocss_ytd_sum


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP17'';

V_STEP_NAME :=  ''create RTO_ENHANCEMENTS table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_RTO_ENHANCEMENTS) COPY GRANTS  as 
Select a.*,
b.reason as new_reason,
b.ishardclose,
b.optimal_suboptimal_outcome,
b.isfalsepositive,
b.falsepositives,
b.includereasonflag from IDENTIFIER(:V_YTD_OCSS_TENURE) a 
left join IDENTIFIER(:V_RTO_CALL_CENTER_NEW) b on a.offer_name = b.offer_name
and a.reason = b.reason and a.event_name = b.event_name;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_RTO_ENHANCEMENTS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP18'';

V_STEP_NAME :=  ''create SUMM_DATA_YTD_OCSS table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_SUMM_DATA_YTD_OCSS) COPY GRANTS as
select offer_name,person_id,
case when uaci_interactive_channel_name = ''OCSS_IC'' then ''OCSS-Call Center''
 when uaci_interactive_channel_name =''RMPI_IC'' then ''RMPI-Member Portal''
 else ''Unknown'' end as uaci_interactive_channel_name,
cast(concat(substr(date_id,1,4),''-'', substr(date_id,5,2),''-'',substr(date_id,7,2)) as date) as date_id,
case when acq_channel is NULL then ''Unknown'' 
 when acq_channel = ''UNKNOWN'' then ''Unknown'' else acq_channel end as acq_channel,
case when plan is NULL then ''Unknown'' else plan end as plan,
case when tenure is NULL then ''Unknown'' else tenure end as tenure
,presented_fg,accept_fg,reject_fg,un_reject_fg,
case when county_name is not NULL then county_name else ''Unknown'' end as county_name,
case when trim(state_code) in (''AL'', ''NJ'', ''KY'', ''MD'', ''OR'', ''MO'', ''WA'', ''MI'', ''LA'', ''NV'', ''WV'', ''WY'', ''TX'', ''OH'', ''OK'', ''TN'', ''DE'', ''IA'', ''ID'', 
''KS'', ''MN'', ''MS'', ''MT'', ''ND'', ''NY'', ''SD'', ''AZ'', ''CA'', ''CT'', ''IL'', ''IN'', ''NC'', ''UT'', ''WI'') then ''AYB States''
when trim(state_code) in (''AR'', ''CO'', ''DC'', ''GA'', ''NE'', ''PA'', ''SC'', ''VA'') then ''SS States''
when trim(state_code) is NULL then ''Unknown''
else ''Neither'' end as Service_States,
case when state_name is not NULL then state_name else ''Unknown'' end as state_name,
case when trim(estinc19) in (''A'',''B'') then  ''Less than $19,999''
when trim(estinc19) in (''C'') then ''$20,000 - $29,999''
when trim(estinc19) in (''D'') then ''$30,000 - $39,999''
when trim(estinc19) in (''E'') then ''$40,000 - $49,999''
when trim(estinc19) in (''F'',''G'',''H'',''I'',''J'',''K'',''L'',''M'',''N'',''O'')
then ''$50,000+''
else ''Unknown'' end as income,
case when trim(gender_code) = ''M'' then ''Male''
when trim(gender_code) = ''F'' then ''Female''
else ''Unknown'' end as gender,
case when round(UTIL.DATE_DIFF_UDF(:V_CURRENT_DATE,person_birth_date)/365.25) >=0 and round(UTIL.DATE_DIFF_UDF(:V_CURRENT_DATE,person_birth_date)/365.25)  <=64 THEN ''Less than 64''
when round(UTIL.DATE_DIFF_UDF(:V_CURRENT_DATE,person_birth_date)/365.25) >64 and round(UTIL.DATE_DIFF_UDF(:V_CURRENT_DATE,person_birth_date)/365.25) <=65 then ''64-65''
when round(UTIL.DATE_DIFF_UDF(:V_CURRENT_DATE,person_birth_date)/365.25) >65 and round(UTIL.DATE_DIFF_UDF(:V_CURRENT_DATE,person_birth_date)/365.25) <=70 then ''65-70''
when round(UTIL.DATE_DIFF_UDF(:V_CURRENT_DATE,person_birth_date)/365.25) >70 and round(UTIL.DATE_DIFF_UDF(:V_CURRENT_DATE,person_birth_date)/365.25) <=75 then ''70-75''
when round(UTIL.DATE_DIFF_UDF(:V_CURRENT_DATE,person_birth_date)/365.25) >75 and round(UTIL.DATE_DIFF_UDF(:V_CURRENT_DATE,person_birth_date)/365.25) <=80 then ''75-80''
when round(UTIL.DATE_DIFF_UDF(:V_CURRENT_DATE,person_birth_date)/365.25) >80 and round(UTIL.DATE_DIFF_UDF(:V_CURRENT_DATE,person_birth_date)/365.25) <=85 then ''80-85''
when round(UTIL.DATE_DIFF_UDF(:V_CURRENT_DATE,person_birth_date)/365.25) >85  then ''85+'' 
else ''Unknown'' end as age_group,
reason,new_reason,
ishardclose,
optimal_suboptimal_outcome,
isfalsepositive,
falsepositives,
includereasonflag
from IDENTIFIER(:V_RTO_ENHANCEMENTS) where state_name is not NULL;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_SUMM_DATA_YTD_OCSS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP19'';

V_STEP_NAME :=  ''create OCSS_YTD_SUM table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());



create or replace table IDENTIFIER(:V_OCSS_YTD_SUM) COPY GRANTS  (
DT_ID DATE ,
OFR_NM STRING ,
UACI_INTAC_CHNL_NM STRING ,
PRS_FLG STRING ,
ACPT_FLG STRING ,
REJ_FLG STRING ,
UN_REJ_FLG STRING ,
GDR_IND STRING ,
ST_NM STRING ,
AGE_GRP_RNG_TXT STRING ,
INCM_RNG_TXT STRING ,
TNUR_DESC STRING ,
CNTY_NM STRING ,
ACQN_CHNL_NM STRING ,
PLN_CD STRING ,
SRVC_ST_TXT STRING ,
/* IDENTIFIER(:V__NEW) Columns */--new change updated
reason STRING ,
new_reason STRING  ,
ishardclose STRING ,
optimal_suboptimal_outcome STRING ,
isfalsepositive STRING ,
falsepositives STRING ,
includereasonflag STRING ,
/* IDENTIFIER(:V__TILL) here */
PERS_ID_CNT BIGINT ,
CREAT_BY_USER_ID STRING ,
CREAT_TMSTMP TIMESTAMP ,
UPD_BY_USER_ID STRING ,
UPD_TMSTMP TIMESTAMP 
);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_OCSS_YTD_SUM)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP20'';

V_STEP_NAME :=  ''insert the data into OCSS_YTD_SUM target table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

insert into IDENTIFIER(:V_OCSS_YTD_SUM) 
select 
date_id,
offer_name,
uaci_interactive_channel_name,
presented_fg,
accept_fg,
reject_fg,
un_reject_fg,
gender,
state_name,
age_group,
income,
tenure,
county_name,
acq_channel,
plan,
Service_States,
reason,new_reason,
ishardclose,
optimal_suboptimal_outcome,
isfalsepositive,
falsepositives,
includereasonflag, 
c_pid,
''isbsqadd'' as CREAT_BY_USER_ID,
:V_CURRENT_DATE as CREAT_TMSTMP,
''isbsqadd'' as UPD_BY_USER_ID,
:V_CURRENT_DATE as UPD_TMSTMP 
from (
select 
date_id, offer_name, uaci_interactive_channel_name, presented_fg,accept_fg,reject_fg,un_reject_fg,
gender,state_name,age_group,income,tenure,county_name,acq_channel,plan,Service_States,
reason,new_reason,
ishardclose,
optimal_suboptimal_outcome,
isfalsepositive,
falsepositives,
includereasonflag,
count(person_id) as c_pid
from IDENTIFIER(:V_SUMM_DATA_YTD_OCSS)
group by date_id, offer_name, uaci_interactive_channel_name, presented_fg,accept_fg,reject_fg,un_reject_fg,
gender,state_name,age_group,income,tenure,county_name,acq_channel,plan,Service_States,
reason,new_reason,
ishardclose,
optimal_suboptimal_outcome,
isfalsepositive,
falsepositives,
includereasonflag) fltr1;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_OCSS_YTD_SUM)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP21'';

V_STEP_NAME :=  ''create OCSS_YTD_SUM View'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace view IDENTIFIER(:V_V_OCSS_YTD_SUM) COPY GRANTS 
as 
select 
dt_id as date_id,
ofr_nm as offer_name,
uaci_intac_chnl_nm as uaci_interactive_channel_name,
prs_flg as presented_fg,
acpt_flg as accept_fg,
rej_flg as reject_fg,
un_rej_flg as un_reject_fg,
gdr_ind as gender,
st_nm as state_name,
age_grp_rng_txt as age_group,
incm_rng_txt as income,
tnur_desc as tenure,
cnty_nm as county_name,
acqn_chnl_nm as acq_channel,
pln_cd as plan,
srvc_st_txt as Service_States,
reason,new_reason,--new change updated
ishardclose,
optimal_suboptimal_outcome,
isfalsepositive,
falsepositives,
includereasonflag,
pers_id_cnt as c_pid 
from IDENTIFIER(:V_OCSS_YTD_SUM);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_V_OCSS_YTD_SUM)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


---------Metric

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP22'';

V_STEP_NAME :=  ''create TEMP1 table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_TEMP1) COPY GRANTS as select * from(select a.*,
row_number() over (partition by person_id,interact_offer_code,uaci_interactive_channel_name,year(response_datetime),presented_fg
order by person_id,ship_person_id,date_id,interact_offer_code,reason,treatment_code,is_session_id,offer_script_id,
uaci_interactive_channel_name,response_datetime,presented_fg desc) as rn2 
from IDENTIFIER(:V_OCSS_YTD_BASE) as a )b where rn2 = 1;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_TEMP1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP23'';

V_STEP_NAME :=  ''create TEMP2 table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());



create or replace table IDENTIFIER(:V_TEMP2) COPY GRANTS  as select * from(select a.*,
row_number() over (partition by person_id,interact_offer_code,uaci_interactive_channel_name,year(response_datetime) 
order by person_id,ship_person_id,date_id,interact_offer_code,reason,treatment_code,is_session_id,offer_script_id,
uaci_interactive_channel_name,presented_fg desc) as rn3
from IDENTIFIER(:V_TEMP1) as a )b where rn3 = 1;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_TEMP2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);





EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP24'';

V_STEP_NAME :=  ''create OCSS_METRIC_BASE table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());



create or replace table IDENTIFIER(:V_OCSS_METRIC_BASE) COPY GRANTS as select person_id, interact_offer_code,response_datetime,
date_id, offer_name, uaci_interactive_channel_name, presented_fg,accept_fg,reject_fg,un_reject_fg,event_name
from IDENTIFIER(:V_TEMP2);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_OCSS_METRIC_BASE)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

-- changed date_id limit 



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP25'';

V_STEP_NAME :=  ''create OCSS_CONTROL table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_OCSS_CONTROL) COPY GRANTS as select person_id, interact_offer_code, contact_datetime as response_datetime,
date_id, offer_name, uaci_interactive_channel_name, ''No'' accept_fg, ''No''
reject_fg, ''No'' un_reject_fg, ''No'' presented_fg,
event_name from 
(select a.*,
row_number() over (partition by person_id, interact_offer_code, uaci_interactive_channel_name,year(contact_datetime)
order by person_id,interact_offer_code,date_id,offer_name,uaci_interactive_channel_name,contact_datetime desc) rn from 
IDENTIFIER(:V_RTO_CONTACT_HISTORY) a
where uaci_interactive_channel_name = ''OCSS_IC''
and trim(event_name) = ''CONTROL'')B where rn = 1;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_OCSS_CONTROL)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP26'';

V_STEP_NAME :=  ''create OCSS_OVERALL_BASE table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());



create or replace table IDENTIFIER(:V_OCSS_OVERALL_BASE) COPY GRANTS as
SELECT *
FROM (
SELECT *  
FROM IDENTIFIER(:V_OCSS_METRIC_BASE) a  
UNION ALL  
SELECT *
from IDENTIFIER(:V_OCSS_CONTROL) b
)c;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_OCSS_OVERALL_BASE)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP27'';

V_STEP_NAME :=  ''create PULL_PERSON_OCSS table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_PULL_PERSON_OCSS)  COPY GRANTS as
select a.*,b.GENDER_CODE,b.birth_date as person_birth_date, b.first_name,b.last_name
from IDENTIFIER(:V_OCSS_OVERALL_BASE)  as a left join IDENTIFIER(:V_PERSON) b 
on b.person_id=a.person_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_PULL_PERSON_OCSS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP28'';

V_STEP_NAME :=  ''create PULL_AMERILINK_OCSS table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_PULL_AMERILINK_OCSS) COPY GRANTS as
select distinct * from(select a.*, b.ESTINC19
from IDENTIFIER(:V_PULL_PERSON_OCSS) as a left join IDENTIFIER(:V_AMERILINK_DATA) b
on a.person_id=b.person_id)c;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_PULL_AMERILINK_OCSS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

--STATE

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP29'';

V_STEP_NAME :=  ''create PULL_GEOG_OCSS table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_PULL_GEOG_OCSS) COPY GRANTS as select a.*,b.state_code,b.zip_code,
county_code,zip_code_plus_4
from IDENTIFIER(:V_PULL_AMERILINK_OCSS) as a left join IDENTIFIER(:V_PERSON_ADDRESS_CURR_PERM) as b
on a.person_id = b.person_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_PULL_GEOG_OCSS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP30'';

V_STEP_NAME :=  ''create PULL_COUNTY_OCSS table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_PULL_COUNTY_OCSS) COPY GRANTS as select a.*, b.county_name
from IDENTIFIER(:V_PULL_GEOG_OCSS) as a left join IDENTIFIER(:V_COUNTY) as b
on a.state_code = b.state_code
and a.county_code = b.fips_county_code;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_PULL_COUNTY_OCSS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP31'';

V_STEP_NAME :=  ''create PULL_STATE_OCSS table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_PULL_STATE_OCSS) COPY GRANTS as select a.*,state_name,
cast(concat(substr(date_id,1,4),''-'', substr(date_id,5,2),''-'',substr(date_id,7,2)) as date) as date_id2,
cast(concat(substr(a.date_id,1,4),''-'', substr(a.date_id,5,2),''-'',''01'') as date) as date_id3
from IDENTIFIER(:V_PULL_COUNTY_OCSS) as a left join IDENTIFIER(:V_STATE) as b
on a.state_code = b.state_code;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_PULL_STATE_OCSS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP32'';

V_STEP_NAME :=  ''create OCSS_TENURE table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
create or replace table IDENTIFIER(:V_OCSS_TENURE) COPY GRANTS  as select a.*,
case when UTIL.DATE_DIFF_UDF(date_id2,prdct_eff_date)/365.25 <= 1 THEN ''Less than 1yr''
when UTIL.DATE_DIFF_UDF(date_id2,prdct_eff_date)/365.25 >1 and UTIL.DATE_DIFF_UDF(date_id2,prdct_eff_date)/365.25 <=2 then ''1-2yrs''
when UTIL.DATE_DIFF_UDF(date_id2,prdct_eff_date)/365.25 >2 and UTIL.DATE_DIFF_UDF(date_id2,prdct_eff_date)/365.25 <=3 then ''2-3yrs''
when UTIL.DATE_DIFF_UDF(date_id2,prdct_eff_date)/365.25 >3 and UTIL.DATE_DIFF_UDF(date_id2,prdct_eff_date)/365.25 <=5 then ''3-5yrs''
when UTIL.DATE_DIFF_UDF(date_id2,prdct_eff_date)/365.25 >5 and UTIL.DATE_DIFF_UDF(date_id2,prdct_eff_date)/365.25 <=10 then ''5-10yrs''
when UTIL.DATE_DIFF_UDF(date_id2,prdct_eff_date)/365.25 >10 then ''10+yrs''
else ''Unknown'' end as tenure,
case when prod_ACQN_CHNL_LVL_1 is not NULL then prod_ACQN_CHNL_LVL_1 ELSE ''Unknown'' end as acq_channel,
case when pln_lvl is NULL then ''Unknown''
when trim(pln_lvl) in (''G01'',''G'',''G0'',''GS1'',''G02'', ''GS2'') then ''G'' --new change updated
when trim(pln_lvl) in (''F01'',''F0'',''F'',''FS1'',''F02'', ''FS2'') then ''F'' --new change updated
when trim(pln_lvl) in (''K01'',''K'') then ''K''
when trim(pln_lvl) in (''N01'',''NS1'',''N02'', ''NS2'') then ''N''   --new change updated
when trim(pln_lvl) in (''GH1'',''GH2'') then ''GH'' --new change updated (30-4-24)
else ''Other'' end as plan
from IDENTIFIER(:V_PULL_STATE_OCSS) as a left join IDENTIFIER(:V_MEMBER_DATA_CAM_RTO_DAILY) as b on
a.person_id = b.pers_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_OCSS_TENURE)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


--Web flag

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP33'';

V_STEP_NAME :=  ''create WEB_REG_OCSS table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_WEB_REG_OCSS) COPY GRANTS as 
select distinct * from(select a.*,wr.calculated_web_registration_date from IDENTIFIER(:V_OCSS_TENURE) as a 
left join IDENTIFIER(:V_AC_WEB_REGISTRATION) wr
on  wr.person_id = a.person_id)c ;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_WEB_REG_OCSS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP34'';

V_STEP_NAME :=  ''create OCSS_CAMP_EB table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_OCSS_CAMP_EB) COPY GRANTS as
select distinct * from(select a.*,
case when a.calculated_web_registration_date is not NULL 
and calculated_web_registration_date > date_id2 then ''Yes''
else ''No'' end as web_fg,
case when UTIL.DATE_DIFF_UDF(calculated_web_registration_date,date_id2)>=0 
and UTIL.DATE_DIFF_UDF(calculated_web_registration_date,date_id2)<=30 
and calculated_web_registration_date is not null then 1 else 0 end as web_rg_1mnth, 
case when UTIL.DATE_DIFF_UDF(calculated_web_registration_date,date_id2)>=0 
and UTIL.DATE_DIFF_UDF(calculated_web_registration_date,date_id2)<=60 
and calculated_web_registration_date is not null then 1 else 0 end as web_rg_2mnth
from IDENTIFIER(:V_WEB_REG_OCSS) as a)c;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_OCSS_CAMP_EB)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

--EFT


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP35'';

V_STEP_NAME :=  ''create EFT_OCSS table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_EFT_OCSS) COPY GRANTS as 
select a.*, 
case when (ppm.PAYMENT_METHOD_CODE=3 
and ppm.BEGIN_DATE >= a.date_id2
and (ppm.end_date >= a.date_id2 or ppm.end_date is NULL)) then ppm.eft_frequency_type_id else NULL END AS eft_frequency_type_id, 
case when (ppm.PAYMENT_METHOD_CODE=3 
and ppm.BEGIN_DATE >= a.date_id2
and (ppm.end_date >= a.date_id2 or ppm.end_date is NULL)) then ppm.person_id else NULL end as eft_pers_id, 
case when (ppm.PAYMENT_METHOD_CODE=3 
and ppm.BEGIN_DATE >= a.date_id2
and (ppm.end_date >= a.date_id2 or ppm.end_date is NULL)) then ppm.begin_date else NULL end as begin_date,
case when (ppm.PAYMENT_METHOD_CODE=3 
and ppm.BEGIN_DATE >= a.date_id2
and (ppm.end_date >= a.date_id2 or ppm.end_date is NULL)) then ppm.end_date else NULL end as end_date
from IDENTIFIER(:V_OCSS_CAMP_EB) as a left join IDENTIFIER(:V_PERSON_PAYMENT_METHOD) ppm
on  ppm.person_id = a.person_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EFT_OCSS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP36'';

V_STEP_NAME :=  ''create TEMP table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
create or replace table IDENTIFIER(:V_TEMP) COPY GRANTS as select person_id, interact_offer_code,date_id,
max(case when (BEGIN_DATE >= date_id2 and eft_pers_id is not NULL )then 1
else 0 end) as eft_flg,
max(CASE when UTIL.DATE_DIFF_UDF(BEGIN_DATE,date_id2)>=0 
AND UTIL.DATE_DIFF_UDF(BEGIN_DATE,date_id2)<=30 
AND eft_frequency_type_id = 2
and eft_pers_id is not NULL THEN 1 ELSE 0 END) AS OT_1MNTH,
max(case when UTIL.DATE_DIFF_UDF(BEGIN_DATE,date_id2)>=0 
AND UTIL.DATE_DIFF_UDF(BEGIN_DATE,date_id2)<=60 
AND eft_frequency_type_id = 2 
and eft_pers_id is not NULL THEN 1 ELSE 0 END) AS OT_2MNTH,
max(CASE when UTIL.DATE_DIFF_UDF(BEGIN_DATE,date_id2)>=0 
AND UTIL.DATE_DIFF_UDF(BEGIN_DATE,date_id2)<=30 
AND eft_frequency_type_id = 1
and eft_pers_id is not NULL THEN 1 ELSE 0 END) AS REC_1MNTH,
max(case when UTIL.DATE_DIFF_UDF(BEGIN_DATE,date_id2)>=0 
AND UTIL.DATE_DIFF_UDF(BEGIN_DATE,date_id2)<=60 
AND eft_frequency_type_id = 1 
and eft_pers_id is not NULL THEN 1 ELSE 0 END) AS REC_2MNTH
from IDENTIFIER(:V_EFT_OCSS) as b group by person_id, interact_offer_code,date_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_TEMP)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP37'';

V_STEP_NAME :=  ''create OCSS_CAMP_EFT table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_OCSS_CAMP_EFT) COPY GRANTS as select a.*,eft_flg,
OT_1MNTH as ot_1mo,OT_2MNTH as ot_2mo,
REC_1MNTH as rec_1mo,REC_2MNTH as rec_2mo from
IDENTIFIER(:V_OCSS_CAMP_EB) as a left join IDENTIFIER(:V_TEMP) as b
on a.interact_offer_code = b.interact_offer_code
and a.person_id = b.person_id and a.date_id=b.date_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_OCSS_CAMP_EFT)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


--Privacy Auth


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP38'';

V_STEP_NAME :=  ''create TEMP1 table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_TEMP1) COPY GRANTS as 
select distinct * FROM ( select a.*, 
vap.creation_date as creation_date,AUXILIARY_PERSON_TYPE_ID, xr.UCPS_PERSON_ID
from  IDENTIFIER(:V_OCSS_CAMP_EFT) as a left join IDENTIFIER(:V_SHIP_PERSON_XREF) xr 
on  a.person_id = xr.person_id 
left join IDENTIFIER(:V_AUXILIARY_PERSON) vap
on xr.Ship_person_id=vap.Individual_id)b;  


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_TEMP1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP39'';

V_STEP_NAME :=  ''create TEMP2 table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_TEMP2) COPY GRANTS as
select person_id, interact_offer_code,date_id,
max(case when UTIL.DATE_DIFF_UDF(to_date(creation_date),date_id2) is  not null and
UTIL.DATE_DIFF_UDF(to_date(creation_date),date_id2) >=0 
and AUXILIARY_PERSON_TYPE_ID=6 then 1 else 0 end) as priv_auth_flg,
max(case when UTIL.DATE_DIFF_UDF(to_date(creation_date),date_id2) is  not null and
UTIL.DATE_DIFF_UDF(to_date(creation_date),date_id2) >=0 
and UTIL.DATE_DIFF_UDF(to_date(creation_date),date_id2)<=30 
and  AUXILIARY_PERSON_TYPE_ID=6 then 1 else 0 end) as priv_1mnth, 
max(case when UTIL.DATE_DIFF_UDF(to_date(creation_date),date_id2) is  not null and
UTIL.DATE_DIFF_UDF(to_date(creation_date),date_id2) >=0 
and UTIL.DATE_DIFF_UDF(to_date(creation_date),date_id2)<=60 
and AUXILIARY_PERSON_TYPE_ID=6 then 1 else 0 end) as priv_2mnth
from IDENTIFIER(:V_TEMP1) 
group by
person_id, interact_offer_code,date_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_TEMP2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP40'';

V_STEP_NAME :=  ''create SHIP_OCSS table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_SHIP_OCSS) COPY GRANTS as select distinct * from (select b.*, a.priv_auth_flg,
a.priv_1mnth,a.priv_2mnth,cast(b.zip_code AS INT) as zip_code_num
, xr.UCPS_PERSON_ID 
from IDENTIFIER(:V_TEMP2) as a left join IDENTIFIER(:V_OCSS_CAMP_EFT) as b on 
a.interact_offer_code = b.interact_offer_code
and a.person_id = b.person_id and a.date_id=b.date_id
left join IDENTIFIER(:V_SHIP_PERSON_XREF) xr
on b.person_id = xr.person_id 
)c;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_SHIP_OCSS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



---Nurse healthline 


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP41'';

V_STEP_NAME :=  ''create TEMP table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_TEMP) COPY GRANTS as select person_id, interact_offer_code, date_id,
max(case when nhl.CONTACT_DATE is not null 
and nhl.CONTACT_DATE > date_id2 then 1 else 0 end)
as nurse_health_line,
max(case when UTIL.DATE_DIFF_UDF(CONTACT_DATE,date_id2) is not null and
UTIL.DATE_DIFF_UDF(CONTACT_DATE,date_id2) >=0 and 
UTIL.DATE_DIFF_UDF(CONTACT_DATE,date_id2) <=30 then 1 else 0 end) as nhl_1mnth, 
max(case when UTIL.DATE_DIFF_UDF(CONTACT_DATE,date_id2) is not null and
UTIL.DATE_DIFF_UDF(CONTACT_DATE,date_id2) >=0 and 
UTIL.DATE_DIFF_UDF(CONTACT_DATE,date_id2) <=61 then 1 else 0 end) as nhl_2mnth
from IDENTIFIER(:V_SHIP_OCSS) a left join IDENTIFIER(:V_NHL_201567_DB_ICUE) nhl 
on a.zip_code_num=nhl.zip_code
and a.first_name = nhl.first_name
and a.LAST_NAME=nhl.last_name
and a.person_birth_date=nhl.dob group by person_id, interact_offer_code,date_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_TEMP)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP42'';

V_STEP_NAME :=  ''create NHL_3_OCSS table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_NHL_3_OCSS) COPY GRANTS as select distinct * from( select a.*,
b.nurse_health_line,nhl_1mnth,nhl_2mnth from IDENTIFIER(:V_SHIP_OCSS) as a left join IDENTIFIER(:V_TEMP) as b on 
a.interact_offer_code = b.interact_offer_code
and a.person_id = b.person_id and a.date_id=b.date_id )c;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_NHL_3_OCSS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP43'';

V_STEP_NAME :=  ''create COMBINED_VAS table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_COMBINED_VAS) COPY GRANTS as 
select a.* from IDENTIFIER(:V_OPTUM_SHIP_VAS_ENGAGE_ANALYSIS) a
union all 
select b.* from IDENTIFIER(:V_OPTUM_SHIP_VAS_ENGAGEMENT) b;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_COMBINED_VAS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP44'';

V_STEP_NAME :=  ''create TEMP1 table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_TEMP1) COPY GRANTS as select person_id, interact_offer_code,date_id,

max(case when trim(opt.VALUE_ADDED_SERVICE_CODE)=''ONS'' 
and UTIL.DATE_DIFF_UDF(opt.BEGIN_DATE,date_id2)>=0 
and UTIL.DATE_DIFF_UDF(opt.BEGIN_DATE,date_id2)<=30 then 1 else 0 end) as ONS_1mnth,
max(case when trim(opt.VALUE_ADDED_SERVICE_CODE)=''ONS'' 
and UTIL.DATE_DIFF_UDF(opt.BEGIN_DATE,date_id2)>=0 
and UTIL.DATE_DIFF_UDF(opt.BEGIN_DATE,date_id2)<=60 then 1 else 0 end) as ONS_2mnth,

max(case when trim(opt.VALUE_ADDED_SERVICE_CODE)=''AYB'' 
and trim(opt.AYB_ENGAGED_ACTIVITY)=''G''
and UTIL.DATE_DIFF_UDF(opt.BEGIN_DATE,date_id3)>=0 
and UTIL.DATE_DIFF_UDF(opt.BEGIN_DATE,date_id3)<=30 then 1 else 0 end) as VAS_gym_1mnth,
max(case when trim(opt.VALUE_ADDED_SERVICE_CODE)=''AYB'' 
and trim(opt.AYB_ENGAGED_ACTIVITY)=''G''
and UTIL.DATE_DIFF_UDF(opt.BEGIN_DATE,date_id3)>=0 
and UTIL.DATE_DIFF_UDF(opt.BEGIN_DATE,date_id3)<=60 then 1 else 0 end) as VAS_gym_2mnth,

max(case when trim(opt.VALUE_ADDED_SERVICE_CODE)=''AYB'' 
and trim(opt.AYB_ENGAGED_ACTIVITY)=''R''
and UTIL.DATE_DIFF_UDF(opt.BEGIN_DATE,date_id3)>=0 
and UTIL.DATE_DIFF_UDF(opt.BEGIN_DATE,date_id3)<=30 then 1 else 0 end) as VAS_renew_active_gym_1mnth,
max(case when trim(opt.VALUE_ADDED_SERVICE_CODE)=''AYB'' 
and trim(opt.AYB_ENGAGED_ACTIVITY)=''R''
and UTIL.DATE_DIFF_UDF(opt.BEGIN_DATE,date_id3)>=0 
and UTIL.DATE_DIFF_UDF(opt.BEGIN_DATE,date_id3)<=60 then 1 else 0 end) as VAS_renew_active_gym_2mnth,

max(case when trim(opt.VALUE_ADDED_SERVICE_CODE)=''AYB'' 
and trim(opt.AYB_ENGAGED_ACTIVITY)=''E''
and UTIL.DATE_DIFF_UDF(opt.BEGIN_DATE,date_id2)>=0 
and UTIL.DATE_DIFF_UDF(opt.BEGIN_DATE,date_id2)<=30 then 1 else 0 end) as VAS_event_1mnth,
max(case when trim(opt.VALUE_ADDED_SERVICE_CODE)=''AYB'' 
and trim(opt.AYB_ENGAGED_ACTIVITY)=''E''
and UTIL.DATE_DIFF_UDF(opt.BEGIN_DATE,date_id2)>=0 
and UTIL.DATE_DIFF_UDF(opt.BEGIN_DATE,date_id2)<=60 then 1 else 0 end) as VAS_event_2mnth,

max(case when trim(opt.VALUE_ADDED_SERVICE_CODE)=''AYB'' 
and trim(opt.AYB_ENGAGED_ACTIVITY)=''S''
and UTIL.DATE_DIFF_UDF(opt.BEGIN_DATE,tr.date_id3)>=0 
and UTIL.DATE_DIFF_UDF(opt.BEGIN_DATE,tr.date_id3)<=30 then 1 else 0 end) as VAS_staying_sharp_1mnth,
max(case when trim(opt.VALUE_ADDED_SERVICE_CODE)=''AYB'' 
and trim(opt.AYB_ENGAGED_ACTIVITY)=''S''
and UTIL.DATE_DIFF_UDF(opt.BEGIN_DATE,tr.date_id3)>=0 
and UTIL.DATE_DIFF_UDF(opt.BEGIN_DATE,tr.date_id3)<=60 then 1 else 0 end) as VAS_staying_sharp_2mnth,

max(case when trim(opt.VALUE_ADDED_SERVICE_CODE)=''AYB'' 
and trim(opt.AYB_ENGAGED_ACTIVITY)=''T''
and UTIL.DATE_DIFF_UDF(opt.BEGIN_DATE,date_id2)>=0 
and UTIL.DATE_DIFF_UDF(opt.BEGIN_DATE,date_id2)<=30 then 1 else 0 end) as VAS_telephonic_1mnth,
max(case when trim(opt.VALUE_ADDED_SERVICE_CODE)=''AYB'' 
and trim(opt.AYB_ENGAGED_ACTIVITY)=''T''
and UTIL.DATE_DIFF_UDF(opt.BEGIN_DATE,date_id2)>=0 
and UTIL.DATE_DIFF_UDF(opt.BEGIN_DATE,date_id2)<=60 then 1 else 0 end) as VAS_telephonic_2mnth
from
IDENTIFIER(:V_NHL_3_OCSS) as tr left join IDENTIFIER(:V_COMBINED_VAS) opt
on tr.UCPS_PERSON_ID=opt.UCPS_PERSON_ID group by
person_id, interact_offer_code,date_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_TEMP1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP45'';

V_STEP_NAME :=  ''create OCSS_DIME table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_OCSS_DIME) COPY GRANTS as select distinct * from (select temp2.*,
case when VAS_cnt_2mo >=1 then ''Yes'' else ''No'' end as VAS_regst,
case when VAS_cnt_1mo >=1 then ''Yes'' else ''No'' end as VAS_reg_1mo,
case when VAS_cnt_2mo >=1 then ''Yes'' else ''No'' end as VAS_reg_2mo
from (select a.*,(ONS_1mnth+ VAS_gym_1mnth + VAS_renew_active_gym_1mnth + VAS_event_1mnth + VAS_staying_sharp_1mnth +
VAS_telephonic_1mnth) as VAS_cnt_1mo,
(ONS_2mnth+ VAS_gym_2mnth + VAS_renew_active_gym_2mnth + VAS_event_2mnth + VAS_staying_sharp_2mnth +
VAS_telephonic_2mnth) as VAS_cnt_2mo,
ONS_1mnth,ONS_2mnth,
VAS_gym_1mnth,VAS_gym_2mnth,
VAS_renew_active_gym_1mnth, VAS_renew_active_gym_2mnth,
VAS_event_1mnth,VAS_event_2mnth,
VAS_staying_sharp_1mnth,VAS_staying_sharp_2mnth,
VAS_telephonic_1mnth,VAS_telephonic_2mnth
from IDENTIFIER(:V_TEMP1) as b left join IDENTIFIER(:V_NHL_3_OCSS) as a on
a.interact_offer_code = b.interact_offer_code
and a.person_id = b.person_id and a.date_id=b.date_id )temp2)c;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_OCSS_DIME)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



-- Inbound Calls

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP46'';

V_STEP_NAME :=  ''create OCSS_CALL table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_OCSS_CALL) COPY GRANTS as
select temp2.*,
case when trim(HCO_CONTACT_RSN_TYPE_NAME) = ''PLAN INQUIRY'' then 1 ELSE 0 end as PLAN_INQ,
case when trim(HCO_CONTACT_RSN_TYPE_NAME) = ''BILLING/PAYMENT INQUIRY'' then 1 ELSE 0 end as BILL_PAY_INQ,
case when trim(HCO_CONTACT_RSN_TYPE_NAME) = ''CLAIM INQUIRY'' then 1 ELSE 0 end as CLAIM_INQ,
case when trim(HCO_CONTACT_RSN_TYPE_NAME) = ''TELEMARKETING'' then 1 ELSE 0 end as TELEMARKETING_INQ,
case when trim(HCO_CONTACT_RSN_TYPE_NAME) = ''OPPORTUNITY'' then 1 ELSE 0 end as OPPRTNTY_INQ,
case when trim(HCO_CONTACT_RSN_TYPE_NAME) = ''AUTHORIZATION MAINTENANCE'' then 1 ELSE 0 end as AUTH_MAIN_INQ,
case when trim(HCO_CONTACT_RSN_TYPE_NAME) = ''AUTHORIZATION INQUIRY'' then 1 ELSE 0 end as AUTH_INQ,
case when trim(HCO_CONTACT_RSN_TYPE_NAME) = ''PROGRAM INQUIRY'' then 1 ELSE 0 end as PROGRAM_INQ,
case when trim(HCO_CONTACT_RSN_TYPE_NAME) = ''ENROLLMENT INQUIRY'' then 1 ELSE  0 end as ENRL_INQ,
case when trim(HCO_CONTACT_RSN_TYPE_NAME) = ''FULFILLMENT INQUIRY'' then 1 ELSE 0 end as FULFILL_INQ,
case when trim(HCO_CONTACT_RSN_TYPE_NAME) = ''REBILL/RERATE INQUIRY'' then  1 ELSE  0 end as REBILL_INQ,
case when trim(HCO_CONTACT_RSN_TYPE_NAME) = ''SILVER SNEAKERS'' then  1 ELSE 0 end as SILVER_INQ,
case when trim(HCO_CONTACT_RSN_TYPE_NAME) = ''WEB INQUIRY'' then 1 ELSE  0 end as WEB_INQ,
case when trim(HCO_CONTACT_RSN_TYPE_NAME) = ''DEMOGRAPHIC INQUIRY'' then 1 ELSE 0 end as DEMOG_INQ,
case when UTIL.DATE_DIFF_UDF(contact_date,date_id2) is not null and 
UTIL.DATE_DIFF_UDF(contact_date,date_id2)>=0 then 
1 else 0 end as ocss_call_fg,
case when UTIL.DATE_DIFF_UDF(contact_date,date_id2) is not null and 
UTIL.DATE_DIFF_UDF(contact_date,date_id2)>=0 and 
UTIL.DATE_DIFF_UDF(contact_date,date_id2)<=30 then
 1 else 0 end as ocss_call_1mnth, 
 case when UTIL.DATE_DIFF_UDF(contact_date,date_id2) is not null and 
UTIL.DATE_DIFF_UDF(contact_date,date_id2)>=0 and 
UTIL.DATE_DIFF_UDF(contact_date,date_id2)<=60 then
 1 else 0 end as ocss_call_2mnth
from (select distinct * from (select d.*, a.contact_date
,a.HCO_CONTACT_REQUEST_ID
,b.HCO_CONTACT_RSN_TYPE_NAME,c.hco_contact_rsn_sub_type_name
from IDENTIFIER(:V_OCSS_DIME) d inner join IDENTIFIER(:V_PERSON_HCO_CONTACT_REQUEST) a
on d.person_id=a.person_id
left join IDENTIFIER(:V_HCO_CONTACT_REASON_TYPE) b
on a.HCO_CONTACT_RSN_TYPE_CODE=b.HCO_CONTACT_RSN_TYPE_CODE
left join IDENTIFIER(:V_HCO_CONTACT_REASON_SUB_TYPE) c
on a.HCO_CONTACT_RSN_SUB_TYPE_CODE=c.HCO_CONTACT_RSN_SUB_TYPE_CODE
where d.date_id2 <= a.contact_date
and d.date_id2 > DATEADD(DAY, -180, a.contact_date)
and a.inquiry_type=''T'')temp1)temp2;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_OCSS_CALL)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

--call_summ



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP47'';

V_STEP_NAME :=  ''create CALL_SUMM_OCSS table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_CALL_SUMM_OCSS) COPY GRANTS as select distinct * from( select
person_id, interact_offer_code,date_id,
max(ocss_call_fg) as ocss_call_fg,
max(ocss_call_1mnth) as ocss_call_1mnth,
max(ocss_call_2mnth) as ocss_call_2mnth,
count(distinct case when UTIL.DATE_DIFF_UDF(contact_date,date_id2) < 30 THEN HCO_CONTACT_REQUEST_ID  end ) as no_calls_1_mnths,
count(distinct case when UTIL.DATE_DIFF_UDF(contact_date,date_id2) < 60 THEN HCO_CONTACT_REQUEST_ID  end ) as no_calls_2_mnths,
--count(distinct HCO_CONTACT_REQUEST_ID) as no_calls, 
sum(case when UTIL.DATE_DIFF_UDF(contact_date,date_id2) < 30 THEN BILL_PAY_INQ  end ) as BILL_PAY_INQ_call_1_mnths, --1.6M
sum(case when UTIL.DATE_DIFF_UDF(contact_date,date_id2) < 60 THEN BILL_PAY_INQ  end ) as BILL_PAY_INQ_call_2_mnths, --1.6M
--sum(BILL_PAYABS_INQ) as BILL_PAY_INQ_call,        )
sum(case when UTIL.DATE_DIFF_UDF(contact_date,date_id2) < 30 THEN CLAIM_INQ  end ) as CLAIM_INQ_call_1_mnths,
sum(case when UTIL.DATE_DIFF_UDF(contact_date,date_id2) < 60 THEN CLAIM_INQ  end ) as CLAIM_INQ_call_2_mnths,
--sum(CLAIM_INABSQ) as CLAIM_INQ_call,              )
sum(case when UTIL.DATE_DIFF_UDF(contact_date,date_id2) < 30 THEN TELEMARKETING_INQ  end ) as TELEMARKETING_INQ_call_1_mnths,
sum(case when UTIL.DATE_DIFF_UDF(contact_date,date_id2) < 60 THEN TELEMARKETING_INQ  end ) as TELEMARKETING_INQ_call_2_mnths,
--sum(TELEMARKABSETING_INQ) as TELEMARKETING_INQ_cal)l, 
sum(case when UTIL.DATE_DIFF_UDF(contact_date,date_id2) < 30 THEN OPPRTNTY_INQ  end ) as OPPRTNTY_INQ_call_1_mnths,
sum(case when UTIL.DATE_DIFF_UDF(contact_date,date_id2) < 60 THEN OPPRTNTY_INQ  end ) as OPPRTNTY_INQ_call_2_mnths,
--sum(OPPRTNTYABS_INQ) as OPPRTNTY_INQ_call,        )
sum(case when UTIL.DATE_DIFF_UDF(contact_date,date_id2) < 30 THEN PLAN_INQ  end ) as PLAN_INQ_call_1_mnths,
sum(case when UTIL.DATE_DIFF_UDF(contact_date,date_id2) < 60 THEN PLAN_INQ  end ) as PLAN_INQ_call_2_mnths,
--sum(PLAN_INQABS) as PLAN_INQ_call                 )
sum(case when UTIL.DATE_DIFF_UDF(contact_date,date_id2) < 30 THEN AUTH_MAIN_INQ  end ) as AUTH_MAIN_INQ_call_1_mnths,
sum(case when UTIL.DATE_DIFF_UDF(contact_date,date_id2) < 60 THEN AUTH_MAIN_INQ  end ) as AUTH_MAIN_INQ_call_2_mnths,
--sum(AUTH_MAIABSN_INQ) as AUTH_MAIN_INQ_call,      )
sum(case when UTIL.DATE_DIFF_UDF(contact_date,date_id2) < 30 THEN AUTH_INQ  end ) as AUTH_INQ_call_1_mnths,
sum(case when UTIL.DATE_DIFF_UDF(contact_date,date_id2) < 60 THEN AUTH_INQ  end ) as AUTH_INQ_call_2_mnths,
--sum(AUTH_INQABS) as AUTH_INQ_call,                )
sum(case when UTIL.DATE_DIFF_UDF(contact_date,date_id2) < 30 THEN PROGRAM_INQ  end ) as PROGRAM_INQ_call_1_mnths,
sum(case when UTIL.DATE_DIFF_UDF(contact_date,date_id2) < 60 THEN PROGRAM_INQ  end ) as PROGRAM_INQ_call_2_mnths,
--sum(PROGRAM_ABSINQ) as PROGRAM_INQ_call,          )
sum(case when UTIL.DATE_DIFF_UDF(contact_date,date_id2) < 30 THEN ENRL_INQ  end ) as ENRL_INQ_call_1_mnths,
sum(case when UTIL.DATE_DIFF_UDF(contact_date,date_id2) < 60 THEN ENRL_INQ  end ) as ENRL_INQ_call_2_mnths,
--sum(ENRL_INQABS) as ENRL_INQ_call,                )
sum(case when UTIL.DATE_DIFF_UDF(contact_date,date_id2) < 30 THEN FULFILL_INQ  end ) as FULFILL_INQ_call_1_mnths,
sum(case when UTIL.DATE_DIFF_UDF(contact_date,date_id2) < 60 THEN FULFILL_INQ  end ) as FULFILL_INQ_call_2_mnths,
--sum(FULFILL_ABSINQ) as FULFILL_INQ_call,          )
sum(case when UTIL.DATE_DIFF_UDF(contact_date,date_id2) < 30 THEN REBILL_INQ  end ) as REBILL_INQ_call_1_mnths,--18613
sum(case when UTIL.DATE_DIFF_UDF(contact_date,date_id2) < 60 THEN REBILL_INQ  end ) as REBILL_INQ_call_2_mnths,--18613
--sum(REBILL_IABSNQ) as REBILL_INQ_call,            )
sum(case when UTIL.DATE_DIFF_UDF(contact_date,date_id2) < 30 THEN SILVER_INQ  end ) as SILVER_INQ_call_1_mnths, --0
sum(case when UTIL.DATE_DIFF_UDF(contact_date,date_id2) < 60 THEN SILVER_INQ  end ) as SILVER_INQ_call_2_mnths, --0
--sum(SILVER_IABSNQ) as SILVER_INQ_call,            )
sum(case when UTIL.DATE_DIFF_UDF(contact_date,date_id2) < 30 THEN WEB_INQ  end ) as WEB_INQ_call_1_mnths,
sum(case when UTIL.DATE_DIFF_UDF(contact_date,date_id2) < 60 THEN WEB_INQ  end ) as WEB_INQ_call_2_mnths,
--sum(WEB_INQ)ABS as WEB_INQ_call,                  )
sum(case when UTIL.DATE_DIFF_UDF(contact_date,date_id2) < 30 THEN DEMOG_INQ  end ) as DEMOG_INQ_call_1_mnths,
sum(case when UTIL.DATE_DIFF_UDF(contact_date,date_id2) < 60 THEN DEMOG_INQ  end ) as DEMOG_INQ_call_2_mnths
--sum(DEMOG_INQ) as DEMOG_INQ_call, 
from IDENTIFIER(:V_OCSS_CALL)
group by person_id, interact_offer_code,date_id)c;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_CALL_SUMM_OCSS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

--back to base


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP48'';

V_STEP_NAME :=  ''create OCSS_BASE_CALLS table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_OCSS_BASE_CALLS) COPY GRANTS  as 
select a.*,
case when b.ocss_call_fg =1 then 1 else 0 end as ocss_call_fg,
case when b.ocss_call_1mnth =1 then 1 else 0 end as ocss_call_1mnth,
case when b.ocss_call_2mnth =1 then 1 else 0 end as ocss_call_2mnth,
case when b.no_calls_1_mnths >=1 then b.no_calls_1_mnths else 0 end as no_calls_1_mnths,
case when b.no_calls_2_mnths >=1 then b.no_calls_2_mnths else 0 end as no_calls_2_mnths,
case when b.AUTH_INQ_call_1_mnths >=1 then b.AUTH_INQ_call_1_mnths else 0 end as AUTH_INQ_call_1_mnths,
case when b.AUTH_INQ_call_2_mnths >=1 then b.AUTH_INQ_call_2_mnths else 0 end as AUTH_INQ_call_2_mnths,
case when b.AUTH_MAIN_INQ_call_1_mnths >=1 then b.AUTH_MAIN_INQ_call_1_mnths else 0 end as AUTH_MAIN_INQ_call_1_mnths,
case when b.AUTH_MAIN_INQ_call_2_mnths >=1 then  b.AUTH_MAIN_INQ_call_2_mnths else 0 end as AUTH_MAIN_INQ_call_2_mnths,
case when b.BILL_PAY_INQ_call_1_mnths >=1 then b.BILL_PAY_INQ_call_1_mnths else 0 end as BILL_PAY_INQ_call_1_mnths,
case when b.BILL_PAY_INQ_call_2_mnths >=1 then b.BILL_PAY_INQ_call_2_mnths else 0 end as BILL_PAY_INQ_call_2_mnths,
case when b.CLAIM_INQ_call_1_mnths >=1 then b.CLAIM_INQ_call_1_mnths else 0 end as CLAIM_INQ_call_1_mnths,
case when b.CLAIM_INQ_call_2_mnths >=1 then b.CLAIM_INQ_call_2_mnths else 0 end as CLAIM_INQ_call_2_mnths,
case when b.DEMOG_INQ_call_1_mnths>=1 then b.DEMOG_INQ_call_1_mnths else 0 end as DEMOG_INQ_call_1_mnths,
case when b.DEMOG_INQ_call_2_mnths>=1 then b.DEMOG_INQ_call_2_mnths else 0 end as DEMOG_INQ_call_2_mnths,
case when b.ENRL_INQ_call_1_mnths>=1 then b.ENRL_INQ_call_1_mnths else 0 end as ENRL_INQ_call_1_mnths,
case when b.ENRL_INQ_call_2_mnths>=1 then b.ENRL_INQ_call_2_mnths else 0 end as ENRL_INQ_call_2_mnths,
case when b.FULFILL_INQ_call_1_mnths>=1 then b.FULFILL_INQ_call_1_mnths else 0 end as FULFILL_INQ_call_1_mnths,
case when b.FULFILL_INQ_call_2_mnths>=1 then b.FULFILL_INQ_call_2_mnths else 0 end as FULFILL_INQ_call_2_mnths,
case when b.OPPRTNTY_INQ_call_1_mnths>=1 then b.OPPRTNTY_INQ_call_1_mnths else 0 end as OPPRTNTY_INQ_call_1_mnths,
case when b.OPPRTNTY_INQ_call_2_mnths>=1 then b.OPPRTNTY_INQ_call_2_mnths else 0 end as OPPRTNTY_INQ_call_2_mnths,
case when b.PLAN_INQ_call_1_mnths>=1 then b.PLAN_INQ_call_1_mnths else 0 end as PLAN_INQ_call_1_mnths,
case when b.PLAN_INQ_call_2_mnths>=1 then b.PLAN_INQ_call_2_mnths else 0 end as PLAN_INQ_call_2_mnths,
case when b.PROGRAM_INQ_call_1_mnths>=1 then b.PROGRAM_INQ_call_1_mnths else 0 end as PROGRAM_INQ_call_1_mnths,
case when b.PROGRAM_INQ_call_2_mnths>=1 then b.PROGRAM_INQ_call_2_mnths else 0 end as PROGRAM_INQ_call_2_mnths,
case when b.REBILL_INQ_call_1_mnths>=1 then b.REBILL_INQ_call_1_mnths else 0 end as REBILL_INQ_call_1_mnths,
case when b.REBILL_INQ_call_2_mnths>=1 then b.REBILL_INQ_call_2_mnths else 0 end as REBILL_INQ_call_2_mnths,
case when b.SILVER_INQ_call_1_mnths>=1 then b.SILVER_INQ_call_1_mnths else 0 end as SILVER_INQ_call_1_mnths,
case when b.SILVER_INQ_call_2_mnths>=1 then b.SILVER_INQ_call_2_mnths else 0 end as SILVER_INQ_call_2_mnths,
case when b.TELEMARKETING_INQ_call_1_mnths>=1 then b.TELEMARKETING_INQ_call_1_mnths else 0 end as TELEMARKETING_INQ_call_1_mnths,
case when b.TELEMARKETING_INQ_call_2_mnths>=1 then b.TELEMARKETING_INQ_call_2_mnths else 0 end as TELEMARKETING_INQ_call_2_mnths,
case when b.WEB_INQ_call_1_mnths>=1 then b.WEB_INQ_call_1_mnths else 0 end as WEB_INQ_call_1_mnths,
case when b.WEB_INQ_call_2_mnths>=1 then b.WEB_INQ_call_2_mnths else 0 end as WEB_INQ_call_2_mnths,

case when no_calls_1_mnths >= 1 then 1 else 0 end as Call_1_flag,
case when no_calls_2_mnths >= 1 then 1 else 0 end as Call_2_flag
from IDENTIFIER(:V_OCSS_DIME) a left join IDENTIFIER(:V_CALL_SUMM_OCSS) b  
  on 
a.interact_offer_code = b.interact_offer_code
and a.person_id = b.person_id and a.date_id=b.date_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_OCSS_BASE_CALLS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

--Sale/paid sale

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP49'';

V_STEP_NAME :=  ''create TEMP1 table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_TEMP1) COPY GRANTS as select tr.person_id, interact_offer_code,date_id,
max(case when ms.appl_receipt_date is not null
and UTIL.DATE_DIFF_UDF(ms.appl_receipt_date ,tr.date_id2) >= 0 then ms.sale else 0 end) as sale_fg,
sum(case when ms.appl_receipt_date is not null
and UTIL.DATE_DIFF_UDF(ms.appl_receipt_date ,tr.date_id2) >= 0
and UTIL.DATE_DIFF_UDF(ms.appl_receipt_date ,tr.date_id2) <=30 then ms.sale else 0 end) as sale_1mo,
sum(case when ms.appl_receipt_date is not null 
and UTIL.DATE_DIFF_UDF(ms.appl_receipt_date ,tr.date_id2) >= 0
and UTIL.DATE_DIFF_UDF(ms.appl_receipt_date ,tr.date_id2) <= 60 then ms.sale else 0 end) as sale_2mo,
max(case when ms.appl_receipt_date is not null
and UTIL.DATE_DIFF_UDF(ms.appl_receipt_date ,tr.date_id2) >= 0 then ms.paidsale else 0 end) as paidsale_fg,
sum(case when ms.appl_receipt_date is not null
and UTIL.DATE_DIFF_UDF(ms.appl_receipt_date ,tr.date_id2) >= 0
and UTIL.DATE_DIFF_UDF(ms.appl_receipt_date ,tr.date_id2) <=30  then ms.paidsale else 0 end) as paidsale_1mo,
sum(case when ms.appl_receipt_date is not null
and UTIL.DATE_DIFF_UDF(ms.appl_receipt_date ,tr.date_id2) >= 0
and UTIL.DATE_DIFF_UDF(ms.appl_receipt_date ,tr.date_id2) <= 60 then ms.paidsale else 0 end) as paidsale_2mo

from IDENTIFIER(:V_OCSS_BASE_CALLS) as tr
left join IDENTIFIER(:V_APPS_RPTG_DAILY) ms
on tr.person_id=ms.person_id
group by tr.person_id, interact_offer_code,date_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_TEMP1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP50'';

V_STEP_NAME :=  ''create PAID_SALE_OCSS table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_PAID_SALE_OCSS) COPY GRANTS as select a.*,sale_fg,sale_1mo,sale_2mo,
paidsale_fg,paidsale_1mo,paidsale_2mo
from IDENTIFIER(:V_OCSS_BASE_CALLS) as a left join IDENTIFIER(:V_TEMP1) as b
on 
a.interact_offer_code = b.interact_offer_code and a.date_id=b.date_id
and a.person_id = b.person_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_PAID_SALE_OCSS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


-- 14411660



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP51'';

V_STEP_NAME :=  ''create VOL_LAPSE_OCSS table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_VOL_LAPSE_OCSS) COPY GRANTS as select a.*,
case when term >=1 and UTIL.DATE_DIFF_UDF(prem_due_date,date_id3)>=0 and 
UTIL.DATE_DIFF_UDF(prem_due_date,date_id3)<=31 then ''Yes'' else ''No'' end as vol_lapse_1mo,
case when term >=1 and UTIL.DATE_DIFF_UDF(prem_due_date,date_id3)>=0 and 
UTIL.DATE_DIFF_UDF(prem_due_date,date_id3)<=62 then ''Yes'' else ''No'' end as vol_lapse_2mo
from IDENTIFIER(:V_PAID_SALE_OCSS) as a left join (select * from IDENTIFIER(:V_STR_LAPSE_RTO_DAILY) where 
d_cert_actv_sk between 19 and 49 and d_cert_actv_sk != 47) as b
on a.person_id = b.pers_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_VOL_LAPSE_OCSS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP52'';

V_STEP_NAME :=  ''create DEATH_LAPSE_OCSS table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DEATH_LAPSE_OCSS) COPY GRANTS as select a.*,
case when term >=1 and UTIL.DATE_DIFF_UDF(prem_due_date,date_id3)>=0 and 
UTIL.DATE_DIFF_UDF(prem_due_date,date_id3)<=31 then ''Yes'' else ''No'' end as death_lapse_1mo,
case when term >=1 and UTIL.DATE_DIFF_UDF(prem_due_date,date_id3)>=0 and 
UTIL.DATE_DIFF_UDF(prem_due_date,date_id3)<=62 then ''Yes'' else ''No'' end as death_lapse_2mo
from IDENTIFIER(:V_VOL_LAPSE_OCSS) as a left join (select * from IDENTIFIER(:V_STR_LAPSE_RTO_DAILY) where d_cert_actv_sk = 47) as b
on a.person_id = b.pers_id;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DEATH_LAPSE_OCSS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP53'';

V_STEP_NAME :=  ''create SWITCH_OCSS table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_SWITCH_OCSS) COPY GRANTS as select a.*,
case when term >=1 and UTIL.DATE_DIFF_UDF(prem_due_date,date_id3)>=0 and 
UTIL.DATE_DIFF_UDF(prem_due_date,date_id3)<=31 then ''Yes'' else ''No'' end as switch_1mo,
case when term >=1 and UTIL.DATE_DIFF_UDF(prem_due_date,date_id3)>=0 and 
UTIL.DATE_DIFF_UDF(prem_due_date,date_id3)<=62 then ''Yes'' else ''No'' end as switch_2mo
from IDENTIFIER(:V_DEATH_LAPSE_OCSS) as a left join (select * from IDENTIFIER(:V_STR_LAPSE_RTO_DAILY) where 
d_cert_actv_sk between 3 and 11) as b
on a.person_id = b.pers_id;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_SWITCH_OCSS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP54'';

V_STEP_NAME :=  ''create TEMP table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_TEMP) COPY GRANTS as select a.person_id, interact_offer_code,date_id,
max(case when UTIL.DATE_DIFF_UDF(registered_on_date,date_id2)<=30 
and UTIL.DATE_DIFF_UDF(registered_on_date,date_id2) >= 0 then 1 else 0 end) as ACP_1mo,
max(case when UTIL.DATE_DIFF_UDF(registered_on_date,date_id2)<=60 
and UTIL.DATE_DIFF_UDF(registered_on_date,date_id2) >= 0 then 1 else 0 end) as ACP_2mo
from IDENTIFIER(:V_SWITCH_OCSS) as a left join IDENTIFIER(:V_MYDIRECTIVES_ADVANCE_CARE) as b
on a.person_id = b.person_id
group by a.person_id, interact_offer_code,date_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_TEMP)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);





EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP55'';

V_STEP_NAME :=  ''create ACP_OCSS table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_ACP_OCSS) COPY GRANTS as select a.*,ACP_1mo,ACP_2mo
from IDENTIFIER(:V_SWITCH_OCSS) a left join IDENTIFIER(:V_TEMP) b
on a.interact_offer_code = b.interact_offer_code
and a.person_id = b.person_id and a.date_id=b.date_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_ACP_OCSS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP56'';

V_STEP_NAME :=  ''create SUMM_DATA_OCSS table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_SUMM_DATA_OCSS) COPY GRANTS as  
select offer_name,person_id,
case when uaci_interactive_channel_name =''OCSS_IC'' then ''OCSS-Call Center''
when uaci_interactive_channel_name =''RMPI_IC'' then ''RMPI-Member Portal''
else ''Unknown'' end as uaci_interactive_channel_name,
case when accept_fg = ''Yes'' then ''Accept''
when reject_fg = ''Yes'' then ''Reject''
else ''Unknown'' end as event_name2,
presented_fg,accept_fg,reject_fg,un_reject_fg,
case when acq_channel is NULL then ''Unknown'' 
when acq_channel = ''UNKNOWN'' then ''Unknown'' else acq_channel end as acq_channel,
case when plan is NULL then ''Unknown'' else plan end as plan,
case when tenure is NULL then ''Unknown'' else tenure end as tenure,
case when ACP_1mo = 1 then ''Yes'' else ''No'' end as ACP_1mo,
case when ACP_2mo = 1 then ''Yes'' else ''No'' end as ACP_2mo,
case when trim(state_code) in (''AL'', ''NJ'', ''KY'', ''MD'', ''OR'', ''MO'', ''WA'', ''MI'', ''LA'', ''NV'', ''WV'', ''WY'', ''TX'', ''OH'', ''OK'', ''TN'', ''DE'', ''IA'', ''ID'', 
''KS'', ''MN'', ''MS'', ''MT'', ''ND'', ''NY'', ''SD'', ''AZ'', ''CA'', ''CT'', ''IL'', ''IN'', ''NC'', ''UT'', ''WI'') then ''AYB States''
when trim(state_code) in (''AR'', ''CO'', ''DC'', ''GA'', ''NE'', ''PA'', ''SC'', ''VA'') then ''SS States''
when trim(state_code) is NULL then ''Unknown''
else ''Neither'' end as Service_States,
cast(concat(substr(date_id,1,4),''-'', substr(date_id,5,2),''-'',substr(date_id,7,2)) as date) as date_id,
case when presented_fg = ''No'' and trim(event_name) = ''CONTROL'' then ''Control''
when presented_fg = ''Yes'' then ''Presented''
when presented_fg = ''No'' and trim(event_name) != ''CONTROL'' then ''Not Presented'' 
else ''Unknown'' end as event_name,
case when state_name is not NULL then state_name else ''Unknown'' end as state_name,
case when county_name is not NULL then county_name else ''Unknown'' end as county_name,
VAS_regst,VAS_reg_1mo,
VAS_reg_2mo,vol_lapse_1mo,vol_lapse_2mo,death_lapse_1mo,death_lapse_2mo,switch_1mo,switch_2mo,
case when web_rg_1mnth = 1 then ''Yes'' else ''No'' end as web_rg_1mnth,
case when web_rg_2mnth = 1 then ''Yes'' else ''No'' end as web_rg_2mnth,
case when eft_flg = 1 then ''Yes'' else ''No'' end as eft_flg,
case when ot_1mo = 1 then ''Yes'' else ''No'' end as ot_1mo,
case when ot_2mo = 1 then ''Yes'' else ''No'' end as ot_2mo,
case when rec_1mo = 1 then ''Yes'' else ''No'' end as rec_1mo,
case when rec_2mo = 1 then ''Yes'' else ''No'' end as rec_2mo,
case when priv_1mnth = 1 then ''Yes'' else ''No'' end as priv_1mnth,
case when priv_2mnth = 1 then ''Yes'' else ''No'' end as priv_2mnth,
case when nhl_1mnth = 1 then ''Yes'' else ''No'' end as nhl_1mnth,
case when nhl_2mnth = 1 then ''Yes'' else ''No'' end as nhl_2mnth,
case when ONS_1mnth = 1 then ''Yes'' else ''No'' end as ONS_1mnth,
case when ONS_2mnth = 1 then ''Yes'' else ''No'' end as ONS_2mnth,
case when VAS_gym_1mnth= 1 then ''Yes'' else ''No'' end as VAS_gym_1mnth,
case when VAS_gym_2mnth= 1 then ''Yes'' else ''No'' end as VAS_gym_2mnth,
case when VAS_event_1mnth= 1 then ''Yes'' else ''No'' end as VAS_event_1mnth,
case when VAS_event_2mnth= 1 then ''Yes'' else ''No'' end as VAS_event_2mnth,
case when VAS_renew_active_gym_1mnth = 1 then ''Yes'' else ''No'' end as VAS_renew_active_gym_1mnth,
case when VAS_renew_active_gym_2mnth = 1 then ''Yes'' else ''No'' end as VAS_renew_active_gym_2mnth,
case when VAS_staying_sharp_1mnth = 1 then ''Yes'' else ''No'' end as VAS_staying_sharp_1mnth,
case when VAS_staying_sharp_2mnth = 1 then ''Yes'' else ''No'' end as VAS_staying_sharp_2mnth,
case when VAS_telephonic_1mnth= 1 then ''Yes'' else ''No'' end as VAS_telephonic_1mnth,
case when VAS_telephonic_2mnth= 1 then ''Yes'' else ''No'' end as VAS_telephonic_2mnth,
case when ocss_call_fg= 1 then ''Yes'' else ''No'' end as call_fg,
case when call_1_flag = 1 then ''Yes'' else ''No'' end as call_1_flag,
case when call_2_flag = 1 then ''Yes'' else ''No'' end as call_2_flag,
case when sale_1mo = 1 then ''Yes'' else ''No'' end as sale_1mo,
case when sale_2mo = 1 then ''Yes'' else ''No'' end as sale_2mo,
case when paidsale_1mo = 1 then ''Yes'' else ''No'' end as paidsale_1mo,
case when paidsale_2mo = 1 then ''Yes'' else ''No'' end as paidsale_2mo,
case when priv_auth_flg = 1 then ''Yes'' else ''No'' end as priv_auth_flg,
case when trim(estinc19) in (''A'',''B'') then  ''Less than $19,999''
when trim(estinc19) in (''C'') then ''$20,000 - $29,999''
when trim(estinc19) in (''D'') then ''$30,000 - $39,999''
when trim(estinc19) in (''E'') then ''$40,000 - $49,999''
when trim(estinc19) in (''F'',''G'',''H'',''I'',''J'',''K'',''L'',''M'',''N'',''O'')
then ''$50,000+''
else ''Unknown'' end as income,
case when trim(gender_code) = ''M'' then ''Male''
when trim(gender_code) = ''F'' then ''Female''
else ''Unknown'' end as gender,

case when round(UTIL.DATE_DIFF_UDF(:V_CURRENT_DATE,person_birth_date)/365.25) >=0 and round(UTIL.DATE_DIFF_UDF(:V_CURRENT_DATE,person_birth_date)/365.25)  <=64 THEN ''Less than 64''
when round(UTIL.DATE_DIFF_UDF(:V_CURRENT_DATE,person_birth_date)/365.25) >64 and round(UTIL.DATE_DIFF_UDF(:V_CURRENT_DATE,person_birth_date)/365.25) <=65 then ''64-65''
when round(UTIL.DATE_DIFF_UDF(:V_CURRENT_DATE,person_birth_date)/365.25) >65 and round(UTIL.DATE_DIFF_UDF(:V_CURRENT_DATE,person_birth_date)/365.25) <=70 then ''65-70''
when round(UTIL.DATE_DIFF_UDF(:V_CURRENT_DATE,person_birth_date)/365.25) >70 and round(UTIL.DATE_DIFF_UDF(:V_CURRENT_DATE,person_birth_date)/365.25) <=75 then ''70-75''
when round(UTIL.DATE_DIFF_UDF(:V_CURRENT_DATE,person_birth_date)/365.25) >75 and round(UTIL.DATE_DIFF_UDF(:V_CURRENT_DATE,person_birth_date)/365.25) <=80 then ''75-80''
when round(UTIL.DATE_DIFF_UDF(:V_CURRENT_DATE,person_birth_date)/365.25) >80 and round(UTIL.DATE_DIFF_UDF(:V_CURRENT_DATE,person_birth_date)/365.25) <=85 then ''80-85''
when round(UTIL.DATE_DIFF_UDF(:V_CURRENT_DATE,person_birth_date)/365.25) >85  then ''85+'' 
else ''Unknown'' end as age_group,
case when vas_cnt_1mo =0 then ''No-vas''
when vas_cnt_1mo = 1 then ''1''
when vas_cnt_1mo = 2 then ''2''
when vas_cnt_1mo in (3,4) then ''3-4'' 
when vas_cnt_1mo >=5  then ''5+'' end as vas_cnt_1mo,
case when vas_cnt_2mo =0 then ''No-vas''
when vas_cnt_2mo = 1 then ''1''
when vas_cnt_2mo = 2 then ''2''
when vas_cnt_2mo in (3,4) then ''3-4'' 
when vas_cnt_2mo >=5  then ''5+'' end as vas_cnt_2mo,
case when no_calls_1_mnths = 0 then ''No Calls''
when no_calls_1_mnths = 1 then ''1''
when no_calls_1_mnths = 2 then ''2''
when no_calls_1_mnths in (3,4) then ''3-4''
when no_calls_1_mnths >=5 then ''5+'' end as no_calls_1_mnths,
case when no_calls_2_mnths = 0 then ''No Calls''
when no_calls_2_mnths = 1 then ''1''
when no_calls_2_mnths = 2 then ''2''
when no_calls_2_mnths in (3,4) then ''3-4''
when no_calls_2_mnths >=5 then ''5+'' end as no_calls_2_mnths,
case when bill_pay_inq_call_1_mnths = 0 then ''No Calls''
when bill_pay_inq_call_1_mnths = 1 then ''1''
when bill_pay_inq_call_1_mnths = 2 then ''2''
when bill_pay_inq_call_1_mnths in (3,4) then ''3-4''
when bill_pay_inq_call_1_mnths >=5 then ''5+'' end as bill_pay_inq_call_1_mnths,
case when bill_pay_inq_call_2_mnths = 0 then ''No Calls''
when bill_pay_inq_call_2_mnths = 1 then ''1''
when bill_pay_inq_call_2_mnths = 2 then ''2''
when bill_pay_inq_call_2_mnths in (3,4) then ''3-4''
when bill_pay_inq_call_2_mnths >=5 then ''5+'' end as bill_pay_inq_call_2_mnths,
case when claim_inq_call_1_mnths = 0 then ''No Calls''
when claim_inq_call_1_mnths = 1 then ''1''
when claim_inq_call_1_mnths = 2 then ''2''
when claim_inq_call_1_mnths in (3,4) then ''3-4''
when claim_inq_call_1_mnths >=5 then ''5+'' end as claim_inq_call_1_mnths,
case when claim_inq_call_2_mnths = 0 then ''No Calls''
when claim_inq_call_2_mnths = 1 then ''1''
when claim_inq_call_2_mnths = 2 then ''2''
when claim_inq_call_2_mnths in (3,4) then ''3-4''
when claim_inq_call_2_mnths >=5 then ''5+'' end as claim_inq_call_2_mnths,
case when telemarketing_inq_call_1_mnths = 0 then ''No Calls''
when telemarketing_inq_call_1_mnths = 1 then ''1''
when telemarketing_inq_call_1_mnths = 2 then ''2''
when telemarketing_inq_call_1_mnths in (3,4) then ''3-4''
when telemarketing_inq_call_1_mnths >=5 then ''5+'' end as telemarketing_inq_call_1_mnths,
case when telemarketing_inq_call_2_mnths = 0 then ''No Calls''
when telemarketing_inq_call_2_mnths = 1 then ''1''
when telemarketing_inq_call_2_mnths = 2 then ''2''
when telemarketing_inq_call_2_mnths in (3,4) then ''3-4''
when telemarketing_inq_call_2_mnths >=5 then ''5+'' end as telemarketing_inq_call_2_mnths,
case when opprtnty_inq_call_1_mnths = 0 then ''No Calls''
when opprtnty_inq_call_1_mnths = 1 then ''1''
when opprtnty_inq_call_1_mnths = 2 then ''2''
when opprtnty_inq_call_1_mnths in (3,4) then ''3-4''
when opprtnty_inq_call_1_mnths >=5 then ''5+'' end as opprtnty_inq_call_1_mnths,
case when opprtnty_inq_call_2_mnths = 0 then ''No Calls''
when opprtnty_inq_call_2_mnths = 1 then ''1''
when opprtnty_inq_call_2_mnths = 2 then ''2''
when opprtnty_inq_call_2_mnths in (3,4) then ''3-4''
when opprtnty_inq_call_2_mnths >=5 then ''5+'' end as opprtnty_inq_call_2_mnths,
case when plan_inq_call_1_mnths = 0 then ''No Calls''
when plan_inq_call_1_mnths = 1 then ''1''
when plan_inq_call_1_mnths = 2 then ''2''
when plan_inq_call_1_mnths in (3,4) then ''3-4''
when plan_inq_call_1_mnths >=5 then ''5+'' end as plan_inq_call_1_mnths,
case when plan_inq_call_2_mnths = 0 then ''No Calls''
when plan_inq_call_2_mnths = 1 then ''1''
when plan_inq_call_2_mnths = 2 then ''2''
when plan_inq_call_2_mnths in (3,4) then ''3-4''
when plan_inq_call_2_mnths >=5 then ''5+'' end as plan_inq_call_2_mnths,
case when auth_main_inq_call_1_mnths = 0 then ''No Calls''
when auth_main_inq_call_1_mnths = 1 then ''1''
when auth_main_inq_call_1_mnths = 2 then ''2''
when auth_main_inq_call_1_mnths in (3,4) then ''3-4''
when auth_main_inq_call_1_mnths >=5 then ''5+'' end as auth_main_inq_call_1_mnths,
case when auth_main_inq_call_2_mnths = 0 then ''No Calls''
when auth_main_inq_call_2_mnths = 1 then ''1''
when auth_main_inq_call_2_mnths = 2 then ''2''
when auth_main_inq_call_2_mnths in (3,4) then ''3-4''
when auth_main_inq_call_2_mnths >=5 then ''5+'' end as auth_main_inq_call_2_mnths,
case when auth_inq_call_1_mnths = 0 then ''No Calls''
when auth_inq_call_1_mnths = 1 then ''1''
when auth_inq_call_1_mnths = 2 then ''2''
when auth_inq_call_1_mnths in (3,4) then ''3-4''
when auth_inq_call_1_mnths >=5 then ''5+'' end as auth_inq_call_1_mnths,
case when auth_inq_call_2_mnths = 0 then ''No Calls''
when auth_inq_call_2_mnths = 1 then ''1''
when auth_inq_call_2_mnths = 2 then ''2''
when auth_inq_call_2_mnths in (3,4) then ''3-4''
when auth_inq_call_2_mnths >=5 then ''5+'' end as auth_inq_call_2_mnths,
case when program_inq_call_1_mnths = 0 then ''No Calls''
when program_inq_call_1_mnths = 1 then ''1''
when program_inq_call_1_mnths = 2 then ''2''
when program_inq_call_1_mnths in (3,4) then ''3-4''
when program_inq_call_1_mnths >=5 then ''5+'' end as program_inq_call_1_mnths,
case when program_inq_call_2_mnths = 0 then ''No Calls''
when program_inq_call_2_mnths = 1 then ''1''
when program_inq_call_2_mnths = 2 then ''2''
when program_inq_call_2_mnths in (3,4) then ''3-4''
when program_inq_call_2_mnths >=5 then ''5+'' end as program_inq_call_2_mnths,
case when enrl_inq_call_1_mnths = 0 then ''No Calls''
when enrl_inq_call_1_mnths = 1 then ''1''
when enrl_inq_call_1_mnths = 2 then ''2''
when enrl_inq_call_1_mnths in (3,4) then ''3-4''
when enrl_inq_call_1_mnths >=5 then ''5+'' end as enrl_inq_call_1_mnths,
case when enrl_inq_call_2_mnths = 0 then ''No Calls''
when enrl_inq_call_2_mnths = 1 then ''1''
when enrl_inq_call_2_mnths = 2 then ''2''
when enrl_inq_call_2_mnths in (3,4) then ''3-4''
when enrl_inq_call_2_mnths >=5 then ''5+'' end as enrl_inq_call_2_mnths,
case when fulfill_inq_call_1_mnths = 0 then ''No Calls''
when fulfill_inq_call_1_mnths = 1 then ''1''
when fulfill_inq_call_1_mnths = 2 then ''2''
when fulfill_inq_call_1_mnths in (3,4) then ''3-4''
when fulfill_inq_call_1_mnths >=5 then ''5+'' end as fulfill_inq_call_1_mnths,
case when fulfill_inq_call_2_mnths = 0 then ''No Calls''
when fulfill_inq_call_2_mnths = 1 then ''1''
when fulfill_inq_call_2_mnths = 2 then ''2''
when fulfill_inq_call_2_mnths in (3,4) then ''3-4''
when fulfill_inq_call_2_mnths >=5 then ''5+'' end as fulfill_inq_call_2_mnths,
case when rebill_inq_call_1_mnths = 0 then ''No Calls''
when rebill_inq_call_1_mnths = 1 then ''1''
when rebill_inq_call_1_mnths = 2 then ''2''
when rebill_inq_call_1_mnths in (3,4) then ''3-4''
when rebill_inq_call_1_mnths >=5 then ''5+'' end as rebill_inq_call_1_mnths,
case when rebill_inq_call_2_mnths = 0 then ''No Calls''
when rebill_inq_call_2_mnths = 1 then ''1''
when rebill_inq_call_2_mnths = 2 then ''2''
when rebill_inq_call_2_mnths in (3,4) then ''3-4''
when rebill_inq_call_2_mnths >=5 then ''5+'' end as rebill_inq_call_2_mnths,
case when silver_inq_call_1_mnths = 0 then ''No Calls''
when silver_inq_call_1_mnths = 1 then ''1''
when silver_inq_call_1_mnths = 2 then ''2''
when silver_inq_call_1_mnths in (3,4) then ''3-4''
when silver_inq_call_1_mnths >=5 then ''5+'' end as silver_inq_call_1_mnths,
case when silver_inq_call_2_mnths = 0 then ''No Calls''
when silver_inq_call_2_mnths = 1 then ''1''
when silver_inq_call_2_mnths = 2 then ''2''
when silver_inq_call_2_mnths in (3,4) then ''3-4''
when silver_inq_call_2_mnths >=5 then ''5+'' end as silver_inq_call_2_mnths,
case when web_inq_call_1_mnths = 0 then ''No Calls''
when web_inq_call_1_mnths = 1 then ''1''
when web_inq_call_1_mnths = 2 then ''2''
when web_inq_call_1_mnths in (3,4) then ''3-4''
when web_inq_call_1_mnths >=5 then ''5+'' end as web_inq_call_1_mnths,
case when web_inq_call_2_mnths = 0 then ''No Calls''
when web_inq_call_2_mnths = 1 then ''1''
when web_inq_call_2_mnths = 2 then ''2''
when web_inq_call_2_mnths in (3,4) then ''3-4''
when web_inq_call_2_mnths >=5 then ''5+'' end as web_inq_call_2_mnths,
case when demog_inq_call_1_mnths = 0 then ''No Calls''
when demog_inq_call_1_mnths = 1 then ''1''
when demog_inq_call_1_mnths = 2 then ''2''
when demog_inq_call_1_mnths in (3,4) then ''3-4''
when demog_inq_call_1_mnths >=5 then ''5+'' end as demog_inq_call_1_mnths,
case when demog_inq_call_2_mnths = 0 then ''No Calls''
when demog_inq_call_2_mnths = 1 then ''1''
when demog_inq_call_2_mnths = 2 then ''2''
when demog_inq_call_2_mnths in (3,4) then ''3-4''
when demog_inq_call_2_mnths >=5 then ''5+'' end as demog_inq_call_2_mnths
from  IDENTIFIER(:V_ACP_OCSS) where state_name is not NULL;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_SUMM_DATA_OCSS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP57'';

V_STEP_NAME :=  ''create OCSS_METRIC_SUM table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_OCSS_METRIC_SUM) COPY GRANTS 
   (
    OFR_NM    STRING,
	UACI_INTAC_CHNL_NM  STRING,
	DT_ID    DATE,
	EVNT_NM    STRING,
	EVNT_2_NM    STRING, 
	AGE_GRP_RNG_TXT    STRING,
	GDR_IND    STRING,
	INCM_RNG_TXT    STRING, 
	ST_NM    STRING, 
	CNTY_NM    STRING, 
	PRS_FLG    STRING, 
	ACPT_FLG    STRING, 
	REJ_FLG    STRING, 
	UN_REJ_FLG    STRING, 
	ACQN_CHNL_NM    STRING, 
	PLN_IND    STRING, 
	TNUR_DESC    STRING,
	SRVC_ST_TXT    STRING,
	WEB_RGST_1_MO_IND    STRING, 
	WEB_RGST_2_MO_IND    STRING,
	ONE_TM_1_MO_IND    STRING, 
	ONE_TM_2_MO_IND    STRING,
	RECUR_1_MO_IND    STRING, 
	RECUR_2_MO_IND    STRING, 
	ACP_1_MO_IND    STRING,
	ACP_2_MO_IND    STRING, 
	PRVC_AUTH_1_MO_IND    STRING, 
	PRVC_AUTH_2_MO_IND    STRING, 
	NHL_1_MO_IND    STRING,
	NHL_2_MO_IND    STRING,
	STAYING_SHARP_1_MO_IND    STRING, 
	STAYING_SHARP_2_MO_IND    STRING,
	VAL_ADD_SRVC_1_MO_CNT_RNG_TXT    STRING,
	VAL_ADD_SRVC_2_MO_CNT_RNG_TXT    STRING,
	DIME_RGST_1_MO_IND    STRING,
	DIME_RGST_2_MO_IND    STRING,
	ONGOING_NRS_SUPP_1_MO_IND    STRING,
	ONGOING_NRS_SUPP_2_MO_IND    STRING,
	DIME_GYM_1_MO_IND    STRING,
	DIME_GYM_2_MO_IND    STRING,
	DIME_EVNT_1_MO_IND    STRING,
	DIME_EVNT_2_MO_IND    STRING,
	DIME_TEL_1_MO_IND    STRING,
	DIME_TEL_2_MO_IND   STRING,
	DIME_RNW_ACTV_1_MO_IND STRING,
	DIME_RNW_ACTV_2_MO_IND STRING,
	NBR_OF_CALL_1_MO_VAL    STRING,
	NBR_OF_CALL_2_MO_VAL    STRING,
	BIL_PAY_INQ_CALL_1_MO_TXT    STRING,
	BIL_PAY_INQ_CALL_2_MO_TXT    STRING,
	CLM_INQ_CALL_1_MO_CNT_RNG_TXT    STRING,
	CLM_INQ_CALL_2_MO_CNT_RNG_TXT    STRING,
	TLMKT_INQ_CALL_1_MO_CNT_RNG_TXT    STRING,
	TLMKT_INQ_CALL_2_MO_CNT_RNG_TXT    STRING,
	OPP_INQ_CALL_1_MO_CNT_RNG_TXT    STRING,
	OPP_INQ_CALL_2_MO_CNT_RNG_TXT    STRING,
	PLN_INQ_CALL_1_MO_CNT_RNG_TXT    STRING,
	PLN_INQ_CALL_2_MO_CNT_RNG_TXT    STRING,
	AUTH_MAIN_INQ_CALL_1_MO_CNT_RN    STRING,
	AUTH_MAIN_INQ_CALL_2_MO_CNT_RN    STRING,
	AUTH_INQ_CALL_1_MO_CNT_RNG_TXT    STRING,
	AUTH_INQ_CALL_2_MO_CNT_RNG_TXT    STRING,
	PGM_INQ_CALL_1_MO_CNT_RNG_TXT    STRING,
	PGM_INQ_CALL_2_MO_CNT_RNG_TXT    STRING,
	ENRL_INQ_CALL_1_MO_CNT_RNG_TXT    STRING,
	ENRL_INQ_CALL_2_MO_CNT_RNG_TXT    STRING,
	FLFL_INQ_CALL_1_MO_CNT_RNG_TXT    STRING,
	FLFL_INQ_CALL_2_MO_CNT_RNG_TXT    STRING,
	REBILL_INQ_CALL_1_MO_CNT_RNG_T    STRING,
	REBILL_INQ_CALL_2_MO_CNT_RNG_T    STRING,
	SLVR_INQ_CALL_1_MO_CNT_RNG_TXT    STRING,
	SLVR_INQ_CALL_2_MO_CNT_RNG_TXT    STRING,
	WEB_INQ_CALL_1_MO_CNT_RNG_TXT    STRING,
	WEB_INQ_CALL_2_MO_CNT_RNG_TXT    STRING,
	DEMO_INQ_CALL_1_MO_CNT_RNG_TXT    STRING,
	DEMO_INQ_CALL_2_MO_CNT_RNG_TXT    STRING,
	VOL_LAPSE_1_MO_IND    STRING,
	VOL_LAPSE_2_MO_IND    STRING,
	DTH_LAPSE_1_MO_IND    STRING,
	DTH_LAPSE_2_MO_IND    STRING,
	SW_1_MO_IND    STRING,
	SW_2_MO_IND    STRING,
	SALE_1_MO_IND    STRING,
	SALE_2_MO_IND    STRING,
	PD_SALE_1_MO_IND    STRING,
	PD_SALE_2_MO_IND    STRING,
	PERS_ID_CNT    BIGINT,
	DSTNCT_PERS_ID_CNT    BIGINT,
	CREAT_BY_USER_ID    STRING,
	CREAT_TMSTMP    TIMESTAMP,
	UPD_BY_USER_ID    STRING,
	UPD_TMSTMP    TIMESTAMP
);



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_OCSS_METRIC_SUM)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP58'';

V_STEP_NAME :=  ''insert into OCSS_METRIC_SUM table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

insert into IDENTIFIER(:V_OCSS_METRIC_SUM) 
   (OFR_NM ,
	UACI_INTAC_CHNL_NM ,
	DT_ID ,
	EVNT_NM ,
	EVNT_2_NM ,
	AGE_GRP_RNG_TXT ,
	GDR_IND ,
	INCM_RNG_TXT ,
	ST_NM ,
	CNTY_NM ,
	PRS_FLG ,
	ACPT_FLG ,
	REJ_FLG ,
	UN_REJ_FLG ,
	ACQN_CHNL_NM,
	PLN_IND ,
	TNUR_DESC ,
	SRVC_ST_TXT ,
	WEB_RGST_1_MO_IND ,
	WEB_RGST_2_MO_IND ,
	ONE_TM_1_MO_IND ,
	ONE_TM_2_MO_IND ,
	RECUR_1_MO_IND ,
	RECUR_2_MO_IND ,
	ACP_1_MO_IND ,
	ACP_2_MO_IND ,
	PRVC_AUTH_1_MO_IND ,
	PRVC_AUTH_2_MO_IND ,
	NHL_1_MO_IND ,
	NHL_2_MO_IND ,
	STAYING_SHARP_1_MO_IND ,
	STAYING_SHARP_2_MO_IND ,
	VAL_ADD_SRVC_1_MO_CNT_RNG_TXT ,
	VAL_ADD_SRVC_2_MO_CNT_RNG_TXT ,
	DIME_RGST_1_MO_IND ,
	DIME_RGST_2_MO_IND ,
	ONGOING_NRS_SUPP_1_MO_IND ,
	ONGOING_NRS_SUPP_2_MO_IND ,
	DIME_GYM_1_MO_IND ,
	DIME_GYM_2_MO_IND ,
	DIME_EVNT_1_MO_IND ,
	DIME_EVNT_2_MO_IND ,
	DIME_TEL_1_MO_IND ,
	DIME_TEL_2_MO_IND ,
	DIME_RNW_ACTV_1_MO_IND ,
	DIME_RNW_ACTV_2_MO_IND ,
	NBR_OF_CALL_1_MO_VAL ,
	NBR_OF_CALL_2_MO_VAL ,
	BIL_PAY_INQ_CALL_1_MO_TXT ,
	BIL_PAY_INQ_CALL_2_MO_TXT ,
	CLM_INQ_CALL_1_MO_CNT_RNG_TXT ,
	CLM_INQ_CALL_2_MO_CNT_RNG_TXT ,
	TLMKT_INQ_CALL_1_MO_CNT_RNG_TXT ,
	TLMKT_INQ_CALL_2_MO_CNT_RNG_TXT ,
	OPP_INQ_CALL_1_MO_CNT_RNG_TXT ,
	OPP_INQ_CALL_2_MO_CNT_RNG_TXT ,
	PLN_INQ_CALL_1_MO_CNT_RNG_TXT ,
	PLN_INQ_CALL_2_MO_CNT_RNG_TXT ,
	AUTH_MAIN_INQ_CALL_1_MO_CNT_RN ,
	AUTH_MAIN_INQ_CALL_2_MO_CNT_RN ,
	AUTH_INQ_CALL_1_MO_CNT_RNG_TXT ,
	AUTH_INQ_CALL_2_MO_CNT_RNG_TXT ,
	PGM_INQ_CALL_1_MO_CNT_RNG_TXT ,
	PGM_INQ_CALL_2_MO_CNT_RNG_TXT ,
	ENRL_INQ_CALL_1_MO_CNT_RNG_TXT ,
	ENRL_INQ_CALL_2_MO_CNT_RNG_TXT ,
	FLFL_INQ_CALL_1_MO_CNT_RNG_TXT ,
	FLFL_INQ_CALL_2_MO_CNT_RNG_TXT ,
	REBILL_INQ_CALL_1_MO_CNT_RNG_T ,
	REBILL_INQ_CALL_2_MO_CNT_RNG_T ,
	SLVR_INQ_CALL_1_MO_CNT_RNG_TXT ,
	SLVR_INQ_CALL_2_MO_CNT_RNG_TXT ,
	WEB_INQ_CALL_1_MO_CNT_RNG_TXT ,
	WEB_INQ_CALL_2_MO_CNT_RNG_TXT ,
	DEMO_INQ_CALL_1_MO_CNT_RNG_TXT ,
	DEMO_INQ_CALL_2_MO_CNT_RNG_TXT ,
	VOL_LAPSE_1_MO_IND ,
	VOL_LAPSE_2_MO_IND ,
	DTH_LAPSE_1_MO_IND ,
	DTH_LAPSE_2_MO_IND ,
	SW_1_MO_IND ,
	SW_2_MO_IND ,
	SALE_1_MO_IND ,
	SALE_2_MO_IND ,
	PD_SALE_1_MO_IND,
	PD_SALE_2_MO_IND ,
	PERS_ID_CNT ,
	DSTNCT_PERS_ID_CNT ,
	CREAT_BY_USER_ID ,
	CREAT_TMSTMP ,
	UPD_BY_USER_ID ,
	UPD_TMSTMP)
select 
offer_name as OFR_NM,
uaci_interactive_channel_name as UACI_INTAC_CHNL_NM,
date_id as DT_ID,
event_name as EVNT_NM,
event_name2 as EVNT_2_NM,
age_group as AGE_GRP_RNG_TXT,
gender as GDR_IND,
income as INCM_RNG_TXT,
state_name as ST_NM,
county_name as CNTY_NM,
presented_fg as PRS_FLG,
accept_fg as ACPT_FLG,
reject_fg as REJ_FLG,
un_reject_fg as UN_REJ_FLG,
acq_channel as ACQN_CHNL_NM,
plan as PLN_IND,
tenure as TNUR_DESC,
Service_States as SRVC_ST_TXT,
web_rg_1mnth as WEB_RGST_1_MO_IND,
web_rg_2mnth as WEB_RGST_2_MO_IND,
ot_1mo as ONE_TM_1_MO_IND,
ot_2mo as ONE_TM_2_MO_IND,
rec_1mo as RECUR_1_MO_IND,
rec_2mo as RECUR_2_MO_IND,
ACP_1mo as ACP_1_MO_IND,
ACP_2mo as ACP_2_MO_IND,
priv_1mnth as PRVC_AUTH_1_MO_IND,
priv_2mnth as PRVC_AUTH_2_MO_IND,
nhl_1mnth as NHL_1_MO_IND,
nhl_2mnth as NHL_2_MO_IND,
VAS_staying_sharp_1mnth as STAYING_SHARP_1_MO_IND,
VAS_staying_sharp_2mnth as STAYING_SHARP_2_MO_IND,
vas_cnt_1mo as VAL_ADD_SRVC_1_MO_CNT_RNG_TXT,
vas_cnt_2mo as VAL_ADD_SRVC_2_MO_CNT_RNG_TXT,
VAS_reg_1mo as DIME_RGST_1_MO_IND,
VAS_reg_2mo as DIME_RGST_2_MO_IND,
ons_1mnth as ONGOING_NRS_SUPP_1_MO_IND,
ons_2mnth as ONGOING_NRS_SUPP_2_MO_IND,
--VAS_reg_1mo as DIME_1_MO_IND,
--VAS_reg_2mo as DIME_2_MO_IND,
VAS_gym_1mnth as DIME_GYM_1_MO_IND,
VAS_gym_2mnth as DIME_GYM_2_MO_IND,
VAS_event_1mnth as DIME_EVNT_1_MO_IND,
VAS_event_2mnth as DIME_EVNT_2_MO_IND,
--dime_portal_1mnth as DIME_PRTL_1_MO_IND,
--dime_portal_2mnth as DIME_PRTL_2_MO_IND,
VAS_telephonic_1mnth as DIME_TEL_1_MO_IND,
VAS_telephonic_2mnth as DIME_TEL_2_MO_IND,
VAS_renew_active_gym_1mnth as DIME_RNW_ACTV_1_MO_IND,
VAS_renew_active_gym_2mnth as DIME_RNW_ACTV_2_MO_IND,
CASE WHEN  no_calls_1_mnths = ''No Calls'' OR  no_calls_1_mnths = ''5+'' or no_calls_1_mnths = ''3-4''  THEN NULL ELSE no_calls_1_mnths END as NBR_OF_CALL_1_MO_VAL,
CASE WHEN  no_calls_2_mnths = ''No Calls'' OR  no_calls_2_mnths = ''5+'' or no_calls_2_mnths = ''3-4''  THEN NULL ELSE no_calls_2_mnths END as NBR_OF_CALL_2_MO_VAL,
bill_pay_inq_call_1_mnths as BIL_PAY_INQ_CALL_1_MO_TXT,
bill_pay_inq_call_2_mnths as BIL_PAY_INQ_CALL_2_MO_TXT,
claim_inq_call_1_mnths as CLM_INQ_CALL_1_MO_CNT_RNG_TXT,
claim_inq_call_2_mnths as CLM_INQ_CALL_2_MO_CNT_RNG_TXT,
telemarketing_inq_call_1_mnths as TLMKT_INQ_CALL_1_MO_CNT_RNG_TXT,
telemarketing_inq_call_2_mnths as TLMKT_INQ_CALL_2_MO_CNT_RNG_TXT,
opprtnty_inq_call_1_mnths as OPP_INQ_CALL_1_MO_CNT_RNG_TXT,
opprtnty_inq_call_2_mnths as OPP_INQ_CALL_2_MO_CNT_RNG_TXT,
plan_inq_call_1_mnths as PLN_INQ_CALL_1_MO_CNT_RNG_TXT,
plan_inq_call_2_mnths as PLN_INQ_CALL_2_MO_CNT_RNG_TXT,
auth_main_inq_call_1_mnths as AUTH_MAIN_INQ_CALL_1_MO_CNT_RN,
auth_main_inq_call_2_mnths as AUTH_MAIN_INQ_CALL_2_MO_CNT_RN,
auth_inq_call_1_mnths as AUTH_INQ_CALL_1_MO_CNT_RNG_TXT,
auth_inq_call_2_mnths as AUTH_INQ_CALL_2_MO_CNT_RNG_TXT,
program_inq_call_1_mnths as PGM_INQ_CALL_1_MO_CNT_RNG_TXT,
program_inq_call_2_mnths as PGM_INQ_CALL_2_MO_CNT_RNG_TXT,
enrl_inq_call_1_mnths as ENRL_INQ_CALL_1_MO_CNT_RNG_TXT,
enrl_inq_call_2_mnths as ENRL_INQ_CALL_2_MO_CNT_RNG_TXT,
fulfill_inq_call_1_mnths as FLFL_INQ_CALL_1_MO_CNT_RNG_TXT,
fulfill_inq_call_2_mnths as FLFL_INQ_CALL_2_MO_CNT_RNG_TXT,
rebill_inq_call_1_mnths as REBILL_INQ_CALL_1_MO_CNT_RNG_T,
rebill_inq_call_2_mnths as REBILL_INQ_CALL_2_MO_CNT_RNG_T,
silver_inq_call_1_mnths as SLVR_INQ_CALL_1_MO_CNT_RNG_TXT,
silver_inq_call_2_mnths as SLVR_INQ_CALL_2_MO_CNT_RNG_TXT,
web_inq_call_1_mnths as WEB_INQ_CALL_1_MO_CNT_RNG_TXT,
web_inq_call_2_mnths as WEB_INQ_CALL_2_MO_CNT_RNG_TXT,
demog_inq_call_1_mnths as DEMO_INQ_CALL_1_MO_CNT_RNG_TXT,
demog_inq_call_2_mnths as DEMO_INQ_CALL_2_MO_CNT_RNG_TXT,
vol_lapse_1mo as VOL_LAPSE_1_MO_IND,
vol_lapse_2mo as VOL_LAPSE_2_MO_IND,
death_lapse_1mo as DTH_LAPSE_1_MO_IND,
death_lapse_2mo as DTH_LAPSE_2_MO_IND,
switch_1mo as SW_1_MO_IND,
switch_2mo as SW_2_MO_IND,
sale_1mo as SALE_1_MO_IND,
sale_2mo as SALE_2_MO_IND,
paidsale_1mo as PD_SALE_1_MO_IND,
paidsale_2mo as PD_SALE_2_MO_IND,
c_pid as PERS_ID_CNT,
c_dis_pid as DSTNCT_PERS_ID_CNT,
''isbsqadd'' as CREAT_BY_USER_ID,
:V_CURRENT_DATE as CREAT_TMSTMP,
''isbsqadd'' as UPD_BY_USER_ID,
:V_CURRENT_DATE as UPD_TMSTMP from (
select 
offer_name,
uaci_interactive_channel_name,
date_id
,event_name
,event_name2
,age_group
,gender
,income
,state_name
,county_name
,presented_fg,accept_fg,reject_fg,un_reject_fg,acq_channel,plan,tenure
,Service_States
,web_rg_1mnth --0/1
,web_rg_2mnth --0/1 
,ot_1mo --0/1
,ot_2mo
,rec_1mo --0/1
,rec_2mo
,ACP_1mo,ACP_2mo
--,priv_auth_flg --0/1
,priv_1mnth --0/1
,priv_2mnth
,nhl_1mnth --0/1
,nhl_2mnth
,vas_cnt_1mo
,vas_cnt_2mo
,VAS_reg_1mo
,VAS_reg_2mo
,ons_1mnth
,ons_2mnth
,VAS_gym_1mnth --0/1
,VAS_gym_2mnth
,VAS_event_1mnth --0/1
,VAS_event_2mnth
,VAS_telephonic_1mnth --0/1
,VAS_telephonic_2mnth
,VAS_renew_active_gym_1mnth
,VAS_renew_active_gym_2mnth
,VAS_staying_sharp_1mnth
,VAS_staying_sharp_2mnth
,no_calls_1_mnths
,no_calls_2_mnths
,bill_pay_inq_call_1_mnths
,bill_pay_inq_call_2_mnths
,claim_inq_call_1_mnths
,claim_inq_call_2_mnths
,telemarketing_inq_call_1_mnths
,telemarketing_inq_call_2_mnths
,opprtnty_inq_call_1_mnths
,opprtnty_inq_call_2_mnths
,plan_inq_call_1_mnths
,plan_inq_call_2_mnths
,auth_main_inq_call_1_mnths
,auth_main_inq_call_2_mnths
,auth_inq_call_1_mnths
,auth_inq_call_2_mnths
,program_inq_call_1_mnths
,program_inq_call_2_mnths
,enrl_inq_call_1_mnths
,enrl_inq_call_2_mnths
,fulfill_inq_call_1_mnths
,fulfill_inq_call_2_mnths
,rebill_inq_call_1_mnths
,rebill_inq_call_2_mnths
,silver_inq_call_1_mnths
,silver_inq_call_2_mnths
,web_inq_call_1_mnths
,web_inq_call_2_mnths
,demog_inq_call_1_mnths
,demog_inq_call_2_mnths
,vol_lapse_1mo,vol_lapse_2mo,death_lapse_1mo,death_lapse_2mo,switch_1mo,switch_2mo
,sale_1mo
,sale_2mo
,paidsale_1mo
,paidsale_2mo,
count(person_id) as c_pid, count(distinct person_id) as c_dis_pid
from IDENTIFIER(:V_SUMM_DATA_OCSS)
group by
offer_name,
uaci_interactive_channel_name,
date_id
,event_name
,event_name2
,age_group
,gender
,income
,state_name
,county_name
,presented_fg,accept_fg,reject_fg,un_reject_fg,acq_channel,plan,tenure
,Service_States
,web_rg_1mnth --0/1
,web_rg_2mnth --0/1 
,ot_1mo --0/1
,ot_2mo
,rec_1mo --0/1
,rec_2mo
,ACP_1mo,ACP_2mo
--,priv_auth_flg --0/1
,priv_1mnth --0/1
,priv_2mnth
,nhl_1mnth --0/1
,nhl_2mnth
,vas_cnt_1mo
,vas_cnt_2mo
,VAS_reg_1mo
,VAS_reg_2mo
,ons_1mnth
,ons_2mnth
,VAS_gym_1mnth --0/1
,VAS_gym_2mnth
,VAS_event_1mnth --0/1
,VAS_event_2mnth
,VAS_telephonic_1mnth --0/1
,VAS_telephonic_2mnth
,VAS_renew_active_gym_1mnth
,VAS_renew_active_gym_2mnth
,VAS_staying_sharp_1mnth
,VAS_staying_sharp_2mnth
,no_calls_1_mnths
,no_calls_2_mnths
,bill_pay_inq_call_1_mnths
,bill_pay_inq_call_2_mnths
,claim_inq_call_1_mnths
,claim_inq_call_2_mnths
,telemarketing_inq_call_1_mnths
,telemarketing_inq_call_2_mnths
,opprtnty_inq_call_1_mnths
,opprtnty_inq_call_2_mnths
,plan_inq_call_1_mnths
,plan_inq_call_2_mnths
,auth_main_inq_call_1_mnths
,auth_main_inq_call_2_mnths
,auth_inq_call_1_mnths
,auth_inq_call_2_mnths
,program_inq_call_1_mnths
,program_inq_call_2_mnths
,enrl_inq_call_1_mnths
,enrl_inq_call_2_mnths
,fulfill_inq_call_1_mnths
,fulfill_inq_call_2_mnths
,rebill_inq_call_1_mnths
,rebill_inq_call_2_mnths
,silver_inq_call_1_mnths
,silver_inq_call_2_mnths
,web_inq_call_1_mnths
,web_inq_call_2_mnths
,demog_inq_call_1_mnths
,demog_inq_call_2_mnths
,vol_lapse_1mo,vol_lapse_2mo,death_lapse_1mo,death_lapse_2mo,switch_1mo,switch_2mo
,sale_1mo
,sale_2mo
,paidsale_1mo
,paidsale_2mo ) fltr1;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_OCSS_METRIC_SUM)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);





EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP59'';

V_STEP_NAME :=  ''create OCSS_METRIC_SUM view'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create OR REPLACE view  IDENTIFIER(:V_V_OCSS_METRIC_SUM) COPY GRANTS as select 
OFR_NM as offer_name,
UACI_INTAC_CHNL_NM as uaci_interactive_channel_name,
DT_ID as date_id,
EVNT_NM as event_name,
EVNT_2_NM as event_name2,
AGE_GRP_RNG_TXT as age_group,
GDR_IND as gender,
INCM_RNG_TXT as income,
ST_NM as state_name,
CNTY_NM as county_name,
PRS_FLG as presented_fg,
ACPT_FLG as accept_fg,
REJ_FLG as reject_fg,
UN_REJ_FLG as un_reject_fg,
ACQN_CHNL_NM as acq_channel,
PLN_IND as plan,
TNUR_DESC as tenure,
SRVC_ST_TXT as Service_States,
WEB_RGST_1_MO_IND as web_rg_1mnth,
WEB_RGST_2_MO_IND as web_rg_2mnth,
ONE_TM_1_MO_IND as ot_1mo,
ONE_TM_2_MO_IND as ot_2mo,
RECUR_1_MO_IND as rec_1mo,
RECUR_2_MO_IND as rec_2mo,
ACP_1_MO_IND as ACP_1mo,
ACP_2_MO_IND as ACP_2mo,
PRVC_AUTH_1_MO_IND as priv_1mnth,
PRVC_AUTH_2_MO_IND as priv_2mnth,
NHL_1_MO_IND as nhl_1mnth,
NHL_2_MO_IND as nhl_2mnth,
STAYING_SHARP_1_MO_IND as VAS_staying_sharp_1mnth,
STAYING_SHARP_2_MO_IND as VAS_staying_sharp_2mnth,
VAL_ADD_SRVC_1_MO_CNT_RNG_TXT as vas_cnt_1mo,
VAL_ADD_SRVC_2_MO_CNT_RNG_TXT as vas_cnt_2mo,
DIME_RGST_1_MO_IND as VAS_reg_1mo,
DIME_RGST_2_MO_IND as VAS_reg_2mo,
ONGOING_NRS_SUPP_1_MO_IND as ons_1mnth,
ONGOING_NRS_SUPP_2_MO_IND as ons_2mnth,
-- DIME_1_MO_IND as dime_1mnth,
-- DIME_2_MO_IND as dime_2mnth,
DIME_GYM_1_MO_IND as VAS_gym_1mnth,
DIME_GYM_2_MO_IND as VAS_gym_2mnth,
DIME_EVNT_1_MO_IND as VAS_event_1mnth,
DIME_EVNT_2_MO_IND as VAS_event_2mnth,
-- DIME_PRTL_1_MO_IND as dime_portal_1mnth,
-- DIME_PRTL_2_MO_IND as dime_portal_2mnth,
DIME_TEL_1_MO_IND as VAS_telephonic_1mnth,
DIME_TEL_2_MO_IND as VAS_telephonic_2mnth,
DIME_RNW_ACTV_1_MO_IND as VAS_renew_active_gym_1mnth,
DIME_RNW_ACTV_2_MO_IND as VAS_renew_active_gym_2mnth,
NBR_OF_CALL_1_MO_VAL as no_calls_1_mnths,
NBR_OF_CALL_2_MO_VAL as no_calls_2_mnths,
BIL_PAY_INQ_CALL_1_MO_TXT as bill_pay_inq_call_1_mnths,
BIL_PAY_INQ_CALL_2_MO_TXT as bill_pay_inq_call_2_mnths,
CLM_INQ_CALL_1_MO_CNT_RNG_TXT as claim_inq_call_1_mnths,
CLM_INQ_CALL_2_MO_CNT_RNG_TXT as claim_inq_call_2_mnths,
TLMKT_INQ_CALL_1_MO_CNT_RNG_TXT as telemarketing_inq_call_1_mnths,
TLMKT_INQ_CALL_2_MO_CNT_RNG_TXT as telemarketing_inq_call_2_mnths,
OPP_INQ_CALL_1_MO_CNT_RNG_TXT as opprtnty_inq_call_1_mnths,
OPP_INQ_CALL_2_MO_CNT_RNG_TXT as opprtnty_inq_call_2_mnths,
PLN_INQ_CALL_1_MO_CNT_RNG_TXT as plan_inq_call_1_mnths,
PLN_INQ_CALL_2_MO_CNT_RNG_TXT as plan_inq_call_2_mnths,
AUTH_MAIN_INQ_CALL_1_MO_CNT_RN as auth_main_inq_call_1_mnths,
AUTH_MAIN_INQ_CALL_2_MO_CNT_RN as auth_main_inq_call_2_mnths,
AUTH_INQ_CALL_1_MO_CNT_RNG_TXT as auth_inq_call_1_mnths,
AUTH_INQ_CALL_2_MO_CNT_RNG_TXT as auth_inq_call_2_mnths,
PGM_INQ_CALL_1_MO_CNT_RNG_TXT as program_inq_call_1_mnths,
PGM_INQ_CALL_2_MO_CNT_RNG_TXT as program_inq_call_2_mnths,
ENRL_INQ_CALL_1_MO_CNT_RNG_TXT as enrl_inq_call_1_mnths,
ENRL_INQ_CALL_2_MO_CNT_RNG_TXT as enrl_inq_call_2_mnths,
FLFL_INQ_CALL_1_MO_CNT_RNG_TXT as fulfill_inq_call_1_mnths,
FLFL_INQ_CALL_2_MO_CNT_RNG_TXT as fulfill_inq_call_2_mnths,
REBILL_INQ_CALL_1_MO_CNT_RNG_T as rebill_inq_call_1_mnths,
REBILL_INQ_CALL_2_MO_CNT_RNG_T as rebill_inq_call_2_mnths,
SLVR_INQ_CALL_1_MO_CNT_RNG_TXT as silver_inq_call_1_mnths,
SLVR_INQ_CALL_2_MO_CNT_RNG_TXT as silver_inq_call_2_mnths,
WEB_INQ_CALL_1_MO_CNT_RNG_TXT as web_inq_call_1_mnths,
WEB_INQ_CALL_2_MO_CNT_RNG_TXT as web_inq_call_2_mnths,
DEMO_INQ_CALL_1_MO_CNT_RNG_TXT as demog_inq_call_1_mnths,
DEMO_INQ_CALL_2_MO_CNT_RNG_TXT as demog_inq_call_2_mnths,
VOL_LAPSE_1_MO_IND as vol_lapse_1mo,
VOL_LAPSE_2_MO_IND as vol_lapse_2mo,
DTH_LAPSE_1_MO_IND as death_lapse_1mo,
DTH_LAPSE_2_MO_IND as death_lapse_2mo,
SW_1_MO_IND as switch_1mo,
SW_2_MO_IND as switch_2mo,
SALE_1_MO_IND as sale_1mo,
SALE_2_MO_IND as sale_2mo,
PD_SALE_1_MO_IND as paidsale_1mo,
PD_SALE_2_MO_IND as paidsale_2mo,
PERS_ID_CNT as c_pid,
DSTNCT_PERS_ID_CNT as c_dis_pid 
from IDENTIFIER(:V_OCSS_METRIC_SUM);  


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_OCSS_METRIC_SUM)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



---rto_qc_process 


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP60'';

V_STEP_NAME :=  ''create OCSS_YTD_BASE_QC1 table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_OCSS_YTD_BASE_QC1) COPY GRANTS as 
select (:V_REPORT_DATE) as report_date,count(offer_name) as total_offers,count(distinct offer_name) as unique_offers, 
count(distinct person_id) as unique_persons, 
min(date_id) as start_date, max(date_id) as end_date
from IDENTIFIER(:V_OCSS_YTD_BASE);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_OCSS_YTD_BASE_QC1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);





EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP61'';

V_STEP_NAME :=  ''create OCSS_YTD_BASE_QC2 table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_OCSS_YTD_BASE_QC2) COPY GRANTS  as select 
(:V_REPORT_DATE) as report_date,count(offer_name) as presented_offers from IDENTIFIER(:V_OCSS_YTD_BASE) where presented_fg = ''Yes'';


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_OCSS_YTD_BASE_QC2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP62'';

V_STEP_NAME :=  ''create OCSS_YTD_BASE_QC3 table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_OCSS_YTD_BASE_QC3) COPY GRANTS as select
(:V_REPORT_DATE) as report_date,count(offer_name) as accepted_offers from IDENTIFIER(:V_OCSS_YTD_BASE) where accept_fg = ''Yes'';


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_OCSS_YTD_BASE_QC3)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP63'';

V_STEP_NAME :=  ''create OCSS_YTD_BASE_QC table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create table IDENTIFIER(:V_OCSS_YTD_BASE_QC) if not exists (
total_offers string,
unique_offers string,
unique_persons string,
start_date string,
end_date string,
presented_offers string,
accepted_offers string,
report_date string);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_OCSS_YTD_BASE_QC)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP64'';

V_STEP_NAME :=  ''insert into OCSS_YTD_BASE_QC table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

insert into  IDENTIFIER(:V_OCSS_YTD_BASE_QC)
select qc1.total_offers,qc1.unique_offers,qc1.unique_persons,
qc1.start_date,qc1.end_date,qc2.presented_offers,qc3.accepted_offers, (:V_REPORT_DATE_YMD)  as report_date
from IDENTIFIER(:V_OCSS_YTD_BASE_QC1) qc1 
left join 
IDENTIFIER(:V_OCSS_YTD_BASE_QC2) qc2 
on qc1.report_date=qc2.report_date 
left join 
IDENTIFIER(:V_OCSS_YTD_BASE_QC3) qc3 
on qc1.report_date=qc3.report_date;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_OCSS_YTD_BASE_QC)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP65'';

V_STEP_NAME :=  ''create SUMM_DATA_OCSS_QC1 table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create OR REPLACE table IDENTIFIER(:V_SUMM_DATA_OCSS_QC1) COPY GRANTS as
select (:V_REPORT_DATE) as report_date,event_name, count(offer_name) as voln_lapsers_2mo from IDENTIFIER(:V_SUMM_DATA_OCSS) where vol_lapse_2mo = ''Yes''
group by event_name;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_SUMM_DATA_OCSS_QC1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP66'';

V_STEP_NAME :=  ''create SUMM_DATA_OCSS_QC2 table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_SUMM_DATA_OCSS_QC2) COPY GRANTS as select 
(:V_REPORT_DATE) as report_date,event_name, count(offer_name) as priv_auth_2mo from IDENTIFIER(:V_SUMM_DATA_OCSS)
where priv_2mnth = ''Yes'' group by event_name;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_SUMM_DATA_OCSS_QC2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL_ANALYTICS) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);


RAISE;

END;
';