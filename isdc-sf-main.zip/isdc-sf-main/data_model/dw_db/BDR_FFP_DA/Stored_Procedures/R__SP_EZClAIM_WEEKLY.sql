USE SCHEMA BDR_FFP_DA;
CREATE OR REPLACE PROCEDURE SP_EZClAIM_WEEKLY
( 
 PIPELINE_ID  varchar, 
 PIPELINE_NAME varchar, 
 DB_NAME varchar,
 UTIL_SC varchar,
 TGT_SC varchar,
 FFP_WRK_SC varchar,
 SRC_SC    varchar,
 ONE_SC    varchar,
 TWO_SC varchar,
 WH varchar,
CURR_DATE varchar
)
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS 
$$
DECLARE

V_CURRENT_DATE   DATE := COALESCE(TO_DATE(:CURR_DATE), CURRENT_DATE());



V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := :DB_NAME||'.'||COALESCE(:UTIL_SC, 'UTIL')||'.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS';

V_PROCESS_NAME   VARCHAR DEFAULT 'EZClAIM_WEEKLY';

V_SUB_PROCESS_NAME  VARCHAR DEFAULT 'EZClAIM_WEEKLY';

V_STEP             VARCHAR;

V_STEP_NAME        VARCHAR;

V_START_TIME       VARCHAR;

V_END_TIME         VARCHAR;

V_ROWS_PARSED       INTEGER;

V_ROWS_LOADED       INTEGER;

V_MESSAGE          VARCHAR;

V_LAST_QUERY_ID    VARCHAR;



V_APPS_RPTG_DAILYEZV3 VARCHAR := :DB_NAME || '.' || COALESCE(:TGT_SC, 'BDR_FFP_DA') || '.EZCLAIM_APPS_RPTG_DAILYEZV3';

V_EZ_WEEKLY_SUMMARY VARCHAR := :DB_NAME || '.' || COALESCE(:FFP_WRK_SC, 'BDR_FFP_DA') || '.EZCLAIM_EZ_WEEKLY_SUMMARY';

V_REFINED_ISDW_REF_V_D_MBR_INFO VARCHAR := :DB_NAME || '.' || COALESCE(:SRC_SC, 'BDR_CONF') || '.D_MBR_INFO';

V_APPS_RPTG_DAILYEZV2 VARCHAR := :DB_NAME || '.' || COALESCE(:TGT_SC, 'BDR_FFP_DA') || '.EZCLAIM_APPS_RPTG_DAILYEZV2';

V_APPS_RPTG_DAILYEZ VARCHAR := :DB_NAME || '.' || COALESCE(:FFP_WRK_SC, 'BDR_FFP_DA_WRK') || '.EZCLAIM_APPS_RPTG_DAILYEZ';

V_REFINED_MPO_APPS_RPTG_DAILY VARCHAR := :DB_NAME || '.' || COALESCE(:ONE_SC, 'SRC_MPO') || '.APPS_RPTG_DAILY';

V_APPS_RPTG_DAILYEZUNION VARCHAR := :DB_NAME || '.' || COALESCE(:FFP_WRK_SC, 'BDR_FFP_DA_WRK') || '.EZCLAIM_APPS_RPTG_DAILYEZUNION';

V_REFINED_APEX_EZCP_MEMBER_ENROLLMENT_DETAILS VARCHAR := :DB_NAME || '.' || COALESCE(:TWO_SC, 'SRC_APEX') || '.EZCP_MEMBER_ENROLLMENT_DETAILS';

V_APPS_RPTG_DAILYEZV1 VARCHAR := :DB_NAME || '.' || COALESCE(:FFP_WRK_SC, 'BDR_FFP_DA_WRK') || '.EZCLAIM_APPS_RPTG_DAILYEZV1';




BEGIN


EXECUTE IMMEDIATE 'USE WAREHOUSE '||:WH;

ALTER SESSION SET TIMEZONE = 'America/Chicago';

V_STEP := 'STEP1';

V_STEP_NAME :=  'create EZCLAIM_APPS_RPTG_DAILYEZ table';
   
V_START_TIME := CONVERT_TIMEZONE('America/Chicago', CURRENT_TIMESTAMP());



create or replace table IDENTIFIER(:V_APPS_RPTG_DAILYEZ) COPY GRANTS as 
select
	person_id
	,application_id
	,appl_receipt_date
	,adjudication_date
	,plan_grp
	,mktg_chnl_grp
	,enrollment
	,adjudication_status
	,product
	,ms_insured_at_app
	,spec_type_code
, case 
	when adjudication_date is not null and appl_receipt_date = adjudication_date  
	then  'Y' else 'N' end as same_day_adj
, case 
	when adjudication_date is null and adjudication_status = 'ACCEPTED' 
	then  'Y' else 'N' end as null_adj_accp
from
	IDENTIFIER(:V_refined_mpo_APPS_RPTG_DAILY)
	where appl_receipt_date >= '2024-08-15'
	and plan_grp = 'Plan_G'
	and mktg_chnl_grp = 'DTC'
	and enrollment = 'Voice Signature'
	and adjudication_status = 'ACCEPTED'
	and product	= 'MS'
	and ms_insured_at_app	= 'N' 
	and spec_type_code = 'B'
	;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_APPS_RPTG_DAILYEZ)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, 'PRE_CLM', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), 'SUCCESS', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

/*UNION ALL*/	

EXECUTE IMMEDIATE 'USE WAREHOUSE '||:WH;

ALTER SESSION SET TIMEZONE = 'America/Chicago';

V_STEP := 'STEP2';

V_STEP_NAME :=  'create EZCLAIM_APPS_RPTG_DAILYEZUNION table';
   
V_START_TIME := CONVERT_TIMEZONE('America/Chicago', CURRENT_TIMESTAMP());



create or replace table IDENTIFIER(:V_APPS_RPTG_DAILYEZUNION) COPY GRANTS as 
select * 
from 
	IDENTIFIER(:V_APPS_RPTG_DAILYEZ) 
where 
	same_day_adj = 'Y' 
union all
select * 
from 
	IDENTIFIER(:V_APPS_RPTG_DAILYEZ) 
where 
	null_adj_accp = 'Y'	
;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_APPS_RPTG_DAILYEZUNION)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, 'PRE_CLM', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), 'SUCCESS', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


/*Join with v_d_mbr_info for acct_nbr*/

EXECUTE IMMEDIATE 'USE WAREHOUSE '||:WH;

ALTER SESSION SET TIMEZONE = 'America/Chicago';

V_STEP := 'STEP3';

V_STEP_NAME :=  'create EZCLAIM_APPS_RPTG_DAILYEZV1 table';
   
V_START_TIME := CONVERT_TIMEZONE('America/Chicago', CURRENT_TIMESTAMP());


	


create or replace table IDENTIFIER(:V_APPS_RPTG_DAILYEZV1) COPY GRANTS as 
select 
	a.person_id	
	,a.application_id
	,a.appl_receipt_date	
	,a.adjudication_date
	,a.plan_grp
	,a.mktg_chnl_grp	
	,a.enrollment
	,a.adjudication_status
	,a.same_day_adj
	,a.null_adj_accp
	,LPAD(b.acct_nbr,11,'0') as acct_nbr
	,b.pers_id
from 
	IDENTIFIER(:V_APPS_RPTG_DAILYEZUNION) as a
left join
	IDENTIFIER(:V_refined_isdw_ref_V_D_MBR_INFO) as b
on a.person_id = b.pers_id 
;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_APPS_RPTG_DAILYEZV1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, 'PRE_CLM', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), 'SUCCESS', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


/*Join with ezcp_member_enrollment_details table to get EZ claim registerd information */

EXECUTE IMMEDIATE 'USE WAREHOUSE '||:WH;

ALTER SESSION SET TIMEZONE = 'America/Chicago';

V_STEP := 'STEP4';

V_STEP_NAME :=  'create EZCLAIM_APPS_RPTG_DAILYEZV2 table';
   
V_START_TIME := CONVERT_TIMEZONE('America/Chicago', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_APPS_RPTG_DAILYEZV2) COPY GRANTS as
select 
	a.*
	,b.membership_number
	,LPAD(b.membership_number,11,'0') AS membership_number1
	,b.record_date
	,b.src_rec_created_ts
	,b.enrollment_received_from
,case 
	when b.record_date is null then b.src_rec_created_ts ELSE  b.record_date end as  record_date_new
from 
	IDENTIFIER(:V_APPS_RPTG_DAILYEZV1) as a
left join
	IDENTIFIER(:V_refined_apex_EZCP_MEMBER_ENROLLMENT_DETAILS) as b
on a.acct_nbr = LPAD(b.membership_number,11,'0')
;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_APPS_RPTG_DAILYEZV2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, 'PRE_CLM', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), 'SUCCESS', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



/*Final result*/

EXECUTE IMMEDIATE 'USE WAREHOUSE '||:WH;

ALTER SESSION SET TIMEZONE = 'America/Chicago';

V_STEP := 'STEP5';

V_STEP_NAME :=  'create EZCLAIM_APPS_RPTG_DAILYEZV3 table';
   
V_START_TIME := CONVERT_TIMEZONE('America/Chicago', CURRENT_TIMESTAMP());



create or replace table IDENTIFIER(:V_APPS_RPTG_DAILYEZV3) COPY GRANTS as
select *
, case 
	when appl_receipt_date < record_date_new then 'ez_claim_later'
	when appl_receipt_date = record_date_new then 'same_day'
	when appl_receipt_date > record_date_new then 'application_later'
	else 'No Match Found'
	end as Status 
from 
	IDENTIFIER(:V_APPS_RPTG_DAILYEZV2);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_APPS_RPTG_DAILYEZV3)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, 'PRE_CLM', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), 'SUCCESS', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


/**********************************Final Summary*****************************************888*/

EXECUTE IMMEDIATE 'USE WAREHOUSE '||:WH;

ALTER SESSION SET TIMEZONE = 'America/Chicago';

V_STEP := 'STEP6';

V_STEP_NAME :=  'create EZCLAIM_EZ_WEEKLY_SUMMARY table';
   
V_START_TIME := CONVERT_TIMEZONE('America/Chicago', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_EZ_WEEKLY_SUMMARY) COPY GRANTS as
select 
	case 
		when appl_receipt_date BETWEEN '2024-09-01' and '2024-09-07' THEN '1'
		when appl_receipt_date BETWEEN '2024-09-08' and '2024-09-14' THEN '2'
		when appl_receipt_date BETWEEN '2024-09-15' and '2024-09-21' THEN '3'
		when appl_receipt_date BETWEEN '2024-09-22' and '2024-09-28' THEN '4'
		when appl_receipt_date BETWEEN '2024-09-29' and '2024-10-05' THEN '5'
		when appl_receipt_date BETWEEN '2024-10-06' and '2024-10-12' THEN '6'
		when appl_receipt_date BETWEEN '2024-10-13' and '2024-10-19' THEN '7'
		when appl_receipt_date BETWEEN '2024-10-20' and '2024-10-26' THEN '8'
		when appl_receipt_date BETWEEN '2024-10-27' and '2024-11-02' THEN '9'
		when appl_receipt_date BETWEEN '2024-11-03' and '2024-11-09' THEN '10'
		when appl_receipt_date BETWEEN '2024-11-10' and '2024-11-16' THEN '11'
		when appl_receipt_date BETWEEN '2024-11-17' and '2024-11-23' THEN '12'
		when appl_receipt_date BETWEEN '2024-11-24' and '2024-11-30' THEN '13'
		when appl_receipt_date BETWEEN '2024-12-01' and '2024-12-07' THEN '14'
		when appl_receipt_date BETWEEN '2024-12-08' and '2024-12-14' THEN '15'
		when appl_receipt_date BETWEEN '2024-12-15' and '2024-12-21' THEN '16'
		when appl_receipt_date BETWEEN '2024-12-22' and '2024-12-28' THEN '17'
		when appl_receipt_date BETWEEN '2024-12-29' and '2025-01-04' THEN '18'
		when appl_receipt_date BETWEEN '2025-01-05' and '2025-01-11' THEN '19'
		when appl_receipt_date BETWEEN '2025-01-12' and '2025-01-18' THEN '20'
		when appl_receipt_date BETWEEN '2025-01-19' and '2025-01-25' THEN '21' 
		else 'Other'
	end as 	week
	,count (distinct case 
		when appl_receipt_date = record_date  and membership_number is not null THEN application_id
		end) as Enrolled_on_same_day
	,count (distinct case 
		when appl_receipt_date != record_date and membership_number is not null THEN application_id
		end) as Enrolled_but_not_on_same_day
	,count( distinct case 
		when appl_receipt_date  BETWEEN '2024-09-01' and '2025-01-25' THEN application_id  /* add  '2025-01-25' to weekly refresh*/   
		end) as  Total_Eligible
		,count (DISTINCT application_id) as app
from 
	IDENTIFIER(:V_APPS_RPTG_DAILYEZV2)
group by 
	case 
		when appl_receipt_date BETWEEN '2024-09-01' and '2024-09-07' THEN '1'
		when appl_receipt_date BETWEEN '2024-09-08' and '2024-09-14' THEN '2'
		when appl_receipt_date BETWEEN '2024-09-15' and '2024-09-21' THEN '3'
		when appl_receipt_date BETWEEN '2024-09-22' and '2024-09-28' THEN '4'
		when appl_receipt_date BETWEEN '2024-09-29' and '2024-10-05' THEN '5'
		when appl_receipt_date BETWEEN '2024-10-06' and '2024-10-12' THEN '6'
		when appl_receipt_date BETWEEN '2024-10-13' and '2024-10-19' THEN '7'
		when appl_receipt_date BETWEEN '2024-10-20' and '2024-10-26' THEN '8'
		when appl_receipt_date BETWEEN '2024-10-27' and '2024-11-02' THEN '9'
		when appl_receipt_date BETWEEN '2024-11-03' and '2024-11-09' THEN '10'
		when appl_receipt_date BETWEEN '2024-11-10' and '2024-11-16' THEN '11'
		when appl_receipt_date BETWEEN '2024-11-17' and '2024-11-23' THEN '12'
		when appl_receipt_date BETWEEN '2024-11-24' and '2024-11-30' THEN '13'
		when appl_receipt_date BETWEEN '2024-12-01' and '2024-12-07' THEN '14'
		when appl_receipt_date BETWEEN '2024-12-08' and '2024-12-14' THEN '15'
		when appl_receipt_date BETWEEN '2024-12-15' and '2024-12-21' THEN '16'
		when appl_receipt_date BETWEEN '2024-12-22' and '2024-12-28' THEN '17'
		when appl_receipt_date BETWEEN '2024-12-29' and '2025-01-04' THEN '18'
		when appl_receipt_date BETWEEN '2025-01-05' and '2025-01-11' THEN '19'
		when appl_receipt_date BETWEEN '2025-01-12' and '2025-01-18' THEN '20'
		when appl_receipt_date BETWEEN '2025-01-19' and '2025-01-25' THEN '21'
		else 'Other'
end 
;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EZ_WEEKLY_SUMMARY)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, 'DEEP_PROCESSES', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), 'SUCCESS', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

/*FInal result*/

EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, 'DEEP_PROCESSES', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), 'FAILED', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);



RAISE;

END;

$$
;

;
