USE SCHEMA BDR_FFP_DA;


CREATE OR REPLACE PROCEDURE BDR_FFP_DA.SP_AGENT_QUALITY_06_STATIC_HIERARCHY("PIPELINE_ID" VARCHAR(16777216), "PIPELINE_NAME" VARCHAR(16777216), "DB_NAME" VARCHAR(16777216), "UTIL_SC" VARCHAR(16777216), "TGT_SC" VARCHAR(16777216), "INTRM_SC" VARCHAR(16777216), "ONE_SC" VARCHAR(16777216), "TWO_SC" VARCHAR(16777216), "WH" VARCHAR(16777216), "CURR_DATE" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

V_current_date   DATE := COALESCE(TO_DATE(:CURR_DATE), current_date());

V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := :DB_NAME||''.''||COALESCE(:UTIL_SC, ''UTIL'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';

V_PROCESS_NAME   VARCHAR DEFAULT ''PROCESS_NAME'';

V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''06_agent_quality'';

V_STEP             VARCHAR;

V_STEP_NAME        VARCHAR;

V_START_TIME       VARCHAR;

V_END_TIME         VARCHAR;

V_ROWS_PARSED       INTEGER;

V_ROWS_LOADED       INTEGER;

V_MESSAGE          VARCHAR;

V_LAST_QUERY_ID    VARCHAR;


V_AGENT_QUALITY_SALES_LR_SUMMARIZED_GS_PROFILE_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_SALES_LR_SUMMARIZED_GS_PROFILE_1'';

V_AGENT_QUALITY_CHCK VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_CHCK'';

V_AGENT_QUALITY_CHCK2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_CHCK2'';

V_AGENT_QUALITY_COMBINED_DT_GS_V3 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.AGENT_QUALITY_COMBINED_DT_GS_V3'';

V_AGENT_QUALITY_CHCK5 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_CHCK5'';

V_AGENT_QUALITY_SALES_LR_SUMMARIZED_GS_PROFILE_BACKUP VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.AGENT_QUALITY_SALES_LR_SUMMARIZED_GS_PROFILE_BACKUP'';

V_AGENT_QUALITY_CHCK6 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_CHCK6'';

V_AGENT_QUALITY_ISDW_EFF_SALES_GS_V3 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.AGENT_QUALITY_ISDW_EFF_SALES_GS_V3'';

V_AGENT_QUALITY_CHCK7 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_CHCK7'';

V_AGENT_QUALITY_SALES_LR_SUMMARIZED_GS VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_SALES_LR_SUMMARIZED_GS'';

V_AGENT_QUALITY_CHCK8 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_CHCK8'';

V_AGENT_QUALITY_CHCK8_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_CHCK8_1'';

V_AGENT_QUALITY_CHCK9 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_CHCK9'';

V_AGENT_QUALITY_CHCK10 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_CHCK10'';

V_AGENT_QUALITY_CHCK11 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_CHCK11'';

V_AGENT_QUALITY_CHCK12 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_CHCK12'';

V_AGENT_QUALITY_CHCK14 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_CHCK14'';

V_AGENT_QUALITY_CHCK15 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_CHCK15'';

V_AGENT_QUALITY_AGENT_PROFILE_EXT VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_AGENT_PROFILE_EXT'';

V_AGENT_QUALITY_AGENT_PROFILE_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_AGENT_PROFILE_1'';

V_AGENT_QUALITY_AGENT_PROFILE_2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_AGENT_PROFILE_2'';

V_AGENT_QUALITY_AGENT_PROFILE_3 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_AGENT_PROFILE_3'';

V_AGENT_QUALITY_COMBINED_DT_GS_PROFILE_A  VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_COMBINED_DT_GS_PROFILE_A'';

V_AGENT_QUALITY_COMBINED_DT_GS_PROFILE_BACKUP  VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.AGENT_QUALITY_COMBINED_DT_GS_PROFILE_BACKUP'';

V_AGENT_QUALITY_COMBINED_DT_GS_PROFILE  VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.AGENT_QUALITY_COMBINED_DT_GS_PROFILE'';

V_AGENT_QUALITY_AGENT_QC  VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_AGENT_QC'';

V_AGENT_QUALITY_AGENT_QC_1  VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_AGENT_QC_1'';

V_AGENT_QUALITY_PTY_LR_SMZD  VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.AGENT_QUALITY_PTY_LR_SMZD'';

V_AGENT_QUALITY_NMA_AND_PARENT_CO VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_NMA_AND_PARENT_CO'';

V_AGENT_QUALITY_X1_TEMP VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_X1_TEMP'';

V_AGENT_QUALITY_X1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_X1'';

V_AGENT_QUALITY_X2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_X2'';

V_AGENT_QUALITY_AGENT_PROFILE VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_AGENT_PROFILE'';

V_AGENT_QUALITY_V_D_AGT_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_V_D_AGT_1'';

V_AGENT_QUALITY_V_D_AGT VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_V_D_AGT'';

V_AGENT_QUALITY_COMBINED_DT_GS_PROFILE_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_COMBINED_DT_GS_PROFILE_1'';

V_AGENT_QUALITY_SALES_LR_SUMMARIZED_GS_PROFILE_A VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_SALES_LR_SUMMARIZED_GS_PROFILE_A'';

V_AGENT_QUALITY_SALES_LR_SUMMARIZED_GS_PROFILE_B VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_SALES_LR_SUMMARIZED_GS_PROFILE_B'';

V_AGENT_QUALITY_SALES_LR_SUMMARIZED_GS_PROFILE VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.AGENT_QUALITY_SALES_LR_SUMMARIZED_GS_PROFILE'';

V_HIERARCHY_EXT VARCHAR := :DB_NAME || ''.'' || COALESCE(:TWO_SC, ''SRC_SRA'') || ''.HIERARCHY_EXT'';

V_HIERARCHY_INT VARCHAR := :DB_NAME || ''.'' || COALESCE(:TWO_SC, ''SRC_SRA'') || ''.HIERARCHY_INT'';

V_REF_HIERARCHYTYPE VARCHAR := :DB_NAME || ''.'' || COALESCE(:TWO_SC, ''SRC_SRA'') || ''.REF_HIERARCHYTYPE'';

V_D_AGT VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''BDR_CONF'') || ''.D_AGT'';

V_PRODINFOTYPE VARCHAR := :DB_NAME || ''.'' || COALESCE(:TWO_SC, ''SRC_SRA'') || ''.PRODINFOTYPE'';






BEGIN

-- data backup for previous month
--------UNCOMMENT THIS LATER----------
-----Comment with below run---

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP1'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_CHCK'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_AGENT_QUALITY_CHCK) COPY GRANTS AS  
select distinct party_id as pty_id from IDENTIFIER(:V_HIERARCHY_EXT)
union
select distinct party_id as pty_id from IDENTIFIER(:V_HIERARCHY_INT);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_CHCK)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP2'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_CHCK2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_AGENT_QUALITY_CHCK2) COPY GRANTS AS 
select a.* from IDENTIFIER(:V_HIERARCHY_EXT) as a 
inner join IDENTIFIER(:V_AGENT_QUALITY_CHCK) as b 
on a.party_id = b.pty_id
order by party_id, Start_Date desc;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_CHCK2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP3'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_CHCK5'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_AGENT_QUALITY_CHCK5) COPY GRANTS AS 
select * from 
(select a.* , ROW_NUMBER() OVER(PARTITION BY party_id order by end_date desc,start_date desc) as rownumber
from IDENTIFIER(:V_AGENT_QUALITY_CHCK2) a) v 
where rownumber = 1;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_CHCK5)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP4'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_CHCK6'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_AGENT_QUALITY_CHCK6) COPY GRANTS AS 
select a.*,
case
when Level_01_Title =  ''Field Marketing Organization'' then Level_01_Name
when Level_20_Title =  ''Field Marketing Organization'' then Level_20_Name
when Level_30_Title =  ''Field Marketing Organization'' then Level_30_Name
when Level_40_Title =  ''Field Marketing Organization'' then Level_40_Name
when Level_50_Title =  ''Field Marketing Organization'' then Level_50_Name
when Level_60_Title =  ''Field Marketing Organization'' then Level_60_Name
when Level_70_Title =  ''Field Marketing Organization'' then Level_70_Name
when Level_80_Title =  ''Field Marketing Organization'' then Level_80_Name
end as FMO_Name,
case
when Level_01_Title =  ''Field Marketing Organization'' then Level_01
when Level_20_Title =  ''Field Marketing Organization'' then Level_20
when Level_30_Title =  ''Field Marketing Organization'' then Level_30
when Level_40_Title =  ''Field Marketing Organization'' then Level_40
when Level_50_Title =  ''Field Marketing Organization'' then Level_50
when Level_60_Title =  ''Field Marketing Organization'' then Level_60
when Level_70_Title =  ''Field Marketing Organization'' then Level_70
when Level_80_Title =  ''Field Marketing Organization'' then Level_80
end as FMO_ID,
case
when Level_01_Title =  ''Field Marketing Organization'' then ''Field Marketing Organization'' 
when Level_20_Title =  ''Field Marketing Organization'' then ''Field Marketing Organization'' 
when Level_30_Title =  ''Field Marketing Organization'' then ''Field Marketing Organization'' 
when Level_40_Title =  ''Field Marketing Organization'' then ''Field Marketing Organization'' 
when Level_50_Title =  ''Field Marketing Organization'' then ''Field Marketing Organization'' 
when Level_60_Title =  ''Field Marketing Organization'' then ''Field Marketing Organization'' 
when Level_70_Title =  ''Field Marketing Organization'' then ''Field Marketing Organization'' 
when Level_80_Title =  ''Field Marketing Organization'' then ''Field Marketing Organization'' 
end as FMO_Type,
case
when Level_01_Title =  ''National Marketing Alliance'' then Level_01_Name
when Level_20_Title =  ''National Marketing Alliance'' then Level_20_Name
when Level_30_Title =  ''National Marketing Alliance'' then Level_30_Name
when Level_40_Title =  ''National Marketing Alliance'' then Level_40_Name
when Level_50_Title =  ''National Marketing Alliance'' then Level_50_Name
when Level_60_Title =  ''National Marketing Alliance'' then Level_60_Name
when Level_70_Title =  ''National Marketing Alliance'' then Level_70_Name
when Level_80_Title =  ''National Marketing Alliance'' then Level_80_Name
end as NMA_Name,
case 
when Level_01_Title =  ''National Marketing Alliance'' then Level_01
when Level_20_Title =  ''National Marketing Alliance'' then Level_20
when Level_30_Title =  ''National Marketing Alliance'' then Level_30
when Level_40_Title =  ''National Marketing Alliance'' then Level_40
when Level_50_Title =  ''National Marketing Alliance'' then Level_50
when Level_60_Title =  ''National Marketing Alliance'' then Level_60
when Level_70_Title =  ''National Marketing Alliance'' then Level_70
when Level_80_Title =  ''National Marketing Alliance'' then Level_80
end as NMA_ID,
case
when Level_01_Title =  ''National Marketing Alliance'' then ''National Marketing Alliance'' 
when Level_20_Title =  ''National Marketing Alliance'' then ''National Marketing Alliance'' 
when Level_30_Title =  ''National Marketing Alliance'' then ''National Marketing Alliance'' 
when Level_40_Title =  ''National Marketing Alliance'' then ''National Marketing Alliance'' 
when Level_50_Title =  ''National Marketing Alliance'' then ''National Marketing Alliance'' 
when Level_60_Title =  ''National Marketing Alliance'' then ''National Marketing Alliance'' 
when Level_70_Title =  ''National Marketing Alliance'' then ''National Marketing Alliance'' 
when Level_80_Title =  ''National Marketing Alliance'' then ''National Marketing Alliance''
end as NMA_Type,


case
when Level_01_Title =  ''Strategic Marketing Organization'' then Level_01_Name
when Level_20_Title =  ''Strategic Marketing Organization'' then Level_20_Name
when Level_30_Title =  ''Strategic Marketing Organization'' then Level_30_Name
when Level_40_Title =  ''Strategic Marketing Organization'' then Level_40_Name
when Level_50_Title =  ''Strategic Marketing Organization'' then Level_50_Name
when Level_60_Title =  ''Strategic Marketing Organization'' then Level_60_Name
when Level_70_Title =  ''Strategic Marketing Organization'' then Level_70_Name
when Level_80_Title =  ''Strategic Marketing Organization'' then Level_80_Name
end as SMO_Name,
case
when Level_01_Title =  ''Strategic Marketing Organization'' then Level_01
when Level_20_Title =  ''Strategic Marketing Organization'' then Level_20
when Level_30_Title =  ''Strategic Marketing Organization'' then Level_30
when Level_40_Title =  ''Strategic Marketing Organization'' then Level_40
when Level_50_Title =  ''Strategic Marketing Organization'' then Level_50
when Level_60_Title =  ''Strategic Marketing Organization'' then Level_60
when Level_70_Title =  ''Strategic Marketing Organization'' then Level_70
when Level_80_Title =  ''Strategic Marketing Organization'' then Level_80
end as SMO_ID,
case
when Level_01_Title =  ''Strategic Marketing Organization'' then ''Strategic Marketing Organization'' 
when Level_20_Title =  ''Strategic Marketing Organization'' then ''Strategic Marketing Organization'' 
when Level_30_Title =  ''Strategic Marketing Organization'' then ''Strategic Marketing Organization'' 
when Level_40_Title =  ''Strategic Marketing Organization'' then ''Strategic Marketing Organization'' 
when Level_50_Title =  ''Strategic Marketing Organization'' then ''Strategic Marketing Organization'' 
when Level_60_Title =  ''Strategic Marketing Organization'' then ''Strategic Marketing Organization'' 
when Level_70_Title =  ''Strategic Marketing Organization'' then ''Strategic Marketing Organization'' 
when Level_80_Title =  ''Strategic Marketing Organization'' then ''Strategic Marketing Organization'' 
end as SMO_Type,

case
when Level_01_Title =  ''Master General Agent'' then Level_01_Name
when Level_20_Title =  ''Master General Agent'' then Level_20_Name
when Level_30_Title =  ''Master General Agent'' then Level_30_Name
when Level_40_Title =  ''Master General Agent'' then Level_40_Name
when Level_50_Title =  ''Master General Agent'' then Level_50_Name
when Level_60_Title =  ''Master General Agent'' then Level_60_Name
when Level_70_Title =  ''Master General Agent'' then Level_70_Name
when Level_80_Title =  ''Master General Agent'' then Level_80_Name
end as MGA_Name,
case
when Level_01_Title =  ''Master General Agent'' then Level_01
when Level_20_Title =  ''Master General Agent'' then Level_20
when Level_30_Title =  ''Master General Agent'' then Level_30
when Level_40_Title =  ''Master General Agent'' then Level_40
when Level_50_Title =  ''Master General Agent'' then Level_50
when Level_60_Title =  ''Master General Agent'' then Level_60
when Level_70_Title =  ''Master General Agent'' then Level_70
when Level_80_Title =  ''Master General Agent'' then Level_80
end as MGA_ID,
case 
when Level_01_Title =  ''Master General Agent'' then ''Master General Agent'' 
when Level_20_Title =  ''Master General Agent'' then ''Master General Agent'' 
when Level_30_Title =  ''Master General Agent'' then ''Master General Agent'' 
when Level_40_Title =  ''Master General Agent'' then ''Master General Agent'' 
when Level_50_Title =  ''Master General Agent'' then ''Master General Agent'' 
when Level_60_Title =  ''Master General Agent'' then ''Master General Agent'' 
when Level_70_Title =  ''Master General Agent'' then ''Master General Agent'' 
when Level_80_Title =  ''Master General Agent'' then ''Master General Agent'' 
end as MGA_Type,
case 
when Level_01_Title =  ''General Agent'' then Level_01_Name
when Level_20_Title =  ''General Agent'' then Level_20_Name
when Level_30_Title =  ''General Agent'' then Level_30_Name
when Level_40_Title =  ''General Agent'' then Level_40_Name
when Level_50_Title =  ''General Agent'' then Level_50_Name
when Level_60_Title =  ''General Agent'' then Level_60_Name
when Level_70_Title =  ''General Agent'' then Level_70_Name
when Level_80_Title =  ''General Agent'' then Level_80_Name 
end as GA_Name,
case
when Level_01_Title =  ''General Agent'' then Level_01
when Level_20_Title =  ''General Agent'' then Level_20
when Level_30_Title =  ''General Agent'' then Level_30
when Level_40_Title =  ''General Agent'' then Level_40
when Level_50_Title =  ''General Agent'' then Level_50
when Level_60_Title =  ''General Agent'' then Level_60
when Level_70_Title =  ''General Agent'' then Level_70
when Level_80_Title =  ''General Agent'' then Level_80
end as GA_ID,
case
when Level_01_Title =  ''General Agent'' then  ''General Agent'' 
when Level_20_Title =  ''General Agent'' then  ''General Agent'' 
when Level_30_Title =  ''General Agent'' then  ''General Agent'' 
when Level_40_Title =  ''General Agent'' then  ''General Agent'' 
when Level_50_Title =  ''General Agent'' then  ''General Agent'' 
when Level_60_Title =  ''General Agent'' then  ''General Agent'' 
when Level_70_Title =  ''General Agent'' then  ''General Agent'' 
when Level_80_Title =  ''General Agent'' then  ''General Agent'' 
end as GA_Type
from IDENTIFIER(:V_AGENT_QUALITY_CHCK5) a;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_CHCK6)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP5'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_CHCK9'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_AGENT_QUALITY_CHCK9) COPY GRANTS AS 
select a.* from IDENTIFIER(:V_D_AGT) as a 
inner join IDENTIFIER(:V_AGENT_QUALITY_CHCK) as b 
on a.pty_id = b.pty_id
order by pty_id , row_eff_strt_dt DESC ;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_CHCK9)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP6'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_CHCK10'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_AGENT_QUALITY_CHCK10) COPY GRANTS AS 
select * from 
(select a.*, ROW_NUMBER() over(partition by pty_id order by row_eff_end_dt desc,row_eff_strt_dt desc) as rownumber
from IDENTIFIER(:V_AGENT_QUALITY_CHCK9) a) v
where rownumber =1;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_CHCK10)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP7'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_CHCK11'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_AGENT_QUALITY_CHCK11) COPY GRANTS AS 
select distinct pty_id,agt_nm_fst,agt_nm_midl,agt_nm_lst,agt_cty,agt_st,agt_sub_typ,BUS_NM
from IDENTIFIER(:V_AGENT_QUALITY_CHCK10);

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_CHCK11)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP8'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_CHCK12'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_AGENT_QUALITY_CHCK12) COPY GRANTS AS 
select distinct * from (
select  *, 
(case when (TRIM(BUS_NM) = '''' or BUS_NM is null) then concat_ws('' '',agt_nm_fst,agt_nm_midl,agt_nm_lst) else BUS_NM end) as 
agt_nm 
from IDENTIFIER(:V_AGENT_QUALITY_CHCK11)) b ;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_CHCK12)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP9'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_CHCK7'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_AGENT_QUALITY_CHCK7) COPY GRANTS AS 
select distinct agent_id,party_id from IDENTIFIER(:V_HIERARCHY_EXT);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_CHCK7)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP10'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_CHCK8_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

--set hive.auto.convert.join=false;
create or replace table IDENTIFIER(:V_AGENT_QUALITY_CHCK8_1) COPY GRANTS AS 
select a.*,b.party_id as nma_party_id,
c.party_id as fmo_party_id,
d.party_id as mga_party_id,
e.party_id as ga_party_id,
f.party_id as smo_party_id
from IDENTIFIER(:V_AGENT_QUALITY_CHCK6) as a
left join IDENTIFIER(:V_AGENT_QUALITY_CHCK7) as b on a.nma_id = b.agent_id
left join IDENTIFIER(:V_AGENT_QUALITY_CHCK7) as c on a.fmo_id = c.agent_id
left join IDENTIFIER(:V_AGENT_QUALITY_CHCK7) as d on a.mga_id = d.agent_id
left join IDENTIFIER(:V_AGENT_QUALITY_CHCK7) as e on a.ga_id = e.agent_id
left join IDENTIFIER(:V_AGENT_QUALITY_CHCK7) as f on a.smo_id = f.agent_id
order by party_id;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_CHCK8_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP11'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_CHCK8'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_AGENT_QUALITY_CHCK8) COPY GRANTS AS 
select * from 
(select * , ROW_NUMBER() over(PARTItion by party_id order by party_id) as rownumber1
from  IDENTIFIER(:V_AGENT_QUALITY_CHCK8_1) ) v
where rownumber1 = 1;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_CHCK8)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP12'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_CHCK14'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_AGENT_QUALITY_CHCK14) COPY GRANTS AS 
select a.PTY_ID,a.Agt_NM,a.AGT_CTY,a.AGT_ST,a.AGT_SUB_TYP,b.HierarchyStatus,
b.HierarchyType_ID,
b.FMO_type,b.FMO_name,b.FMO_ID,b.FMO_Party_ID,b.NMA_type,b.NMA_name,NMA_ID,
b.NMA_Party_ID,b.Agent_Level,b.Agent_Level_name,
b.MGA_Type,b.MGA_name,b.MGA_ID,b.MGA_Party_ID,
b.GA_Type,b.GA_name,b.GA_ID,b.GA_Party_ID, b.start_date, b.end_date,
b.smo_name, b.smo_id, b.smo_type, b.smo_party_id
from IDENTIFIER(:V_AGENT_QUALITY_CHCK12) as a 
left join IDENTIFIER(:V_AGENT_QUALITY_CHCK8) as b on a.pty_id = b.Party_ID;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_CHCK14)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP13'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_AGENT_PROFILE_EXT'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_AGENT_QUALITY_AGENT_PROFILE_EXT) COPY GRANTS AS 
select distinct * from (
select a.*, b.HierarchyType
from IDENTIFIER(:V_AGENT_QUALITY_CHCK14) a 
left join IDENTIFIER(:V_REF_HIERARCHYTYPE) b 
on a.HierarchyType_ID = b.HierarchyType_ID) b;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_AGENT_PROFILE_EXT)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP14'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_CHCK2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_AGENT_QUALITY_CHCK2) COPY GRANTS AS 
select a.* from IDENTIFIER(:V_HIERARCHY_INT) as a 
inner join IDENTIFIER(:V_AGENT_QUALITY_CHCK) as b 
on a.party_id = b.pty_id
order by party_id, Start_Date desc;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_CHCK2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP15'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_CHCK5'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_AGENT_QUALITY_CHCK5) COPY GRANTS AS 
select * from 
(select a.* , ROW_NUMBER() OVER(PARTITION BY party_id order by end_date desc,start_date desc) as rownumber
from IDENTIFIER(:V_AGENT_QUALITY_CHCK2) a) v 
where rownumber = 1;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_CHCK5)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP16'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_CHCK6'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_AGENT_QUALITY_CHCK6) COPY GRANTS AS 
select distinct * from(
select *,
'''' as FMO_Name,
'''' as FMO_ID,
'''' as FMO_Type,
'''' as NMA_Name,
'''' as NMA_ID,
'''' as NMA_Type,
'''' as SMO_Name,
'''' as SMO_ID,
'''' as SMO_Type,
'''' as MGA_Name,
'''' as MGA_ID,
'''' as MGA_Type,
'''' as GA_Name,
'''' as GA_ID,
'''' as GA_Type
from IDENTIFIER(:V_AGENT_QUALITY_CHCK5)) a;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_CHCK6)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP17'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_CHCK9'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());



create or replace table IDENTIFIER(:V_AGENT_QUALITY_CHCK9) COPY GRANTS AS 
select a.* from IDENTIFIER(:V_D_AGT) as a inner join IDENTIFIER(:V_AGENT_QUALITY_CHCK) as b 
on a.pty_id = b.pty_id
order by pty_id, row_eff_strt_dt desc;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_CHCK9)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP18'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_CHCK10'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_AGENT_QUALITY_CHCK10) COPY GRANTS AS 
select * from(
select *, ROW_NUMBER() over(partition by pty_id order by row_eff_end_dt desc,row_eff_strt_dt desc) as rownumber
from IDENTIFIER(:V_AGENT_QUALITY_CHCK9)) v 
where rownumber = 1;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_CHCK10)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP19'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_CHCK11'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_AGENT_QUALITY_CHCK11) COPY GRANTS AS 
select distinct pty_id,agt_nm_fst,agt_nm_midl,agt_nm_lst,agt_cty,agt_st,agt_sub_typ,BUS_NM
from IDENTIFIER(:V_AGENT_QUALITY_CHCK10);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_CHCK11)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP20'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_CHCK12'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_AGENT_QUALITY_CHCK12) COPY GRANTS AS 
select distinct * from(
select *, 
(case when (TRIM(BUS_NM) = '''' or BUS_NM is null) then concat_ws('' '',agt_nm_fst,agt_nm_midl,agt_nm_lst) else BUS_NM end) 
as agt_nm 
from IDENTIFIER(:V_AGENT_QUALITY_CHCK11)) v ;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_CHCK12)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP21'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_CHCK7'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_AGENT_QUALITY_CHCK7) COPY GRANTS AS 
select distinct agent_id,party_id from IDENTIFIER(:V_HIERARCHY_INT);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_CHCK7)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP22'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_CHCK8'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_AGENT_QUALITY_CHCK8) COPY GRANTS AS 
select a.*,b.party_id as nma_party_id,
c.party_id as fmo_party_id,
d.party_id as mga_party_id,
e.party_id as ga_party_id,
f.party_id as smo_party_id
from IDENTIFIER(:V_AGENT_QUALITY_CHCK6) as a
left join IDENTIFIER(:V_AGENT_QUALITY_CHCK7) as b 
on a.nma_id = b.agent_id
left join IDENTIFIER(:V_AGENT_QUALITY_CHCK7) as c 
on a.fmo_id = c.agent_id
left join IDENTIFIER(:V_AGENT_QUALITY_CHCK7) as d
on a.mga_id = d.agent_id
left join IDENTIFIER(:V_AGENT_QUALITY_CHCK7) as e
on a.ga_id = e.agent_id
left join IDENTIFIER(:V_AGENT_QUALITY_CHCK7) as f
on a.smo_id = f.agent_id;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_CHCK8)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP23'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_CHCK14'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_AGENT_QUALITY_CHCK14) COPY GRANTS AS 
select distinct a.PTY_ID,a.Agt_NM,a.AGT_CTY,a.AGT_ST,a.AGT_SUB_TYP,b.HierarchyStatus,b.HierarchyType_ID,
b.FMO_type,b.FMO_name,b.FMO_ID,b.FMO_Party_ID,b.NMA_type,b.NMA_name,NMA_ID,
b.NMA_Party_ID,b.Agent_Level,b.Agent_Level_name,
b.MGA_Type,b.MGA_name,b.MGA_ID,b.MGA_Party_ID,
b.GA_Type,b.GA_name,b.GA_ID,b.GA_Party_ID, b.start_date, b.end_date,
b.smo_name, b.smo_id, b.smo_type, b.smo_party_id
from IDENTIFIER(:V_AGENT_QUALITY_CHCK12) as a left join IDENTIFIER(:V_AGENT_QUALITY_CHCK8) as b 
on a.pty_id = b.Party_ID;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_CHCK14)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP24'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_CHCK15'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());



create or replace table IDENTIFIER(:V_AGENT_QUALITY_CHCK15) COPY GRANTS AS 
select distinct * from(
select a.*, b.HierarchyType
from IDENTIFIER(:V_AGENT_QUALITY_CHCK14) a 
left join IDENTIFIER(:V_REF_HIERARCHYTYPE) b 
on a.HierarchyType_ID = b.HierarchyType_ID) b;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_CHCK15)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP25'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_AGENT_PROFILE_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_AGENT_QUALITY_AGENT_PROFILE_1) as 
select distinct * from IDENTIFIER(:V_AGENT_QUALITY_AGENT_PROFILE_EXT)
union 
select distinct * from IDENTIFIER(:V_AGENT_QUALITY_CHCK15);

--select count(*) from agent_profile_1 --566302/568348

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_AGENT_PROFILE_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP26'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_AGENT_PROFILE_2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());



create or replace table IDENTIFIER(:V_AGENT_QUALITY_AGENT_PROFILE_2) COPY GRANTS AS 
select * from IDENTIFIER(:V_AGENT_QUALITY_AGENT_PROFILE_1)
order by pty_id, start_date desc;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_AGENT_PROFILE_2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP27'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_AGENT_PROFILE_3'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_AGENT_QUALITY_AGENT_PROFILE_3) COPY GRANTS AS 
select * from
(select * , ROW_NUMBER() over(partition by pty_id order by end_date desc,start_date desc) as rownumber from IDENTIFIER(:V_AGENT_QUALITY_AGENT_PROFILE_2)) b
where rownumber = 1;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_AGENT_PROFILE_3)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP28'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_X1_TEMP'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_AGENT_QUALITY_X1_TEMP) COPY GRANTS AS 
select party_id, CURRENT_STATUS, CURRENT_STATUS_START_DATE,CURRENT_STATUS_END_DATE
from IDENTIFIER(:V_PRODINFOTYPE) as a 
inner join IDENTIFIER(:V_AGENT_QUALITY_AGENT_PROFILE_3) as b 
on a.party_id = b.pty_id
order by party_id, CURRENT_STATUS_START_DATE desc;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_X1_TEMP)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP29'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_X1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


--query divided
create or replace table IDENTIFIER(:V_AGENT_QUALITY_X1) COPY GRANTS AS 
select distinct party_id, current_status, current_status_start_date, CURRENT_STATUS_END_DATE from IDENTIFIER(:V_AGENT_QUALITY_X1_TEMP);

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_X1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP30'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_X2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_AGENT_QUALITY_X2) COPY GRANTS AS 
select * from (
select *, ROW_NUMBER() over(partition by party_id order by CURRENT_STATUS_END_DATE desc ,CURRENT_STATUS_START_DATE desc) as rownumber
from IDENTIFIER(:V_AGENT_QUALITY_X1)
) v 
where rownumber = 1;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_X2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP31'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_AGENT_PROFILE'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_AGENT_QUALITY_AGENT_PROFILE) COPY GRANTS AS 
select a.*, b.CURRENT_STATUS
from IDENTIFIER(:V_AGENT_QUALITY_AGENT_PROFILE_3) a 
left join IDENTIFIER(:V_AGENT_QUALITY_X2) b 
on a.pty_id = b.party_id;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_AGENT_PROFILE)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP32'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_SALES_LR_SUMMARIZED_GS_PROFILE_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());



-------To add changes here (Simran)------------------------
--set hive.new.job.grouping.set.cardinality=200;
create or replace table IDENTIFIER(:V_AGENT_QUALITY_SALES_LR_SUMMARIZED_GS_PROFILE_1) COPY GRANTS AS 
select distinct a.PTY_ID,a.agt_id,a.principalparty_id_final,a.year,a.undwr_pln_rqr_txt,a.undwr_prdct_rqr_txt,a.age,a.gdr_desc,a.rt_dtrm_cd_desc,
a.d_st_cd,a.rtng_area_nm,a.pln_lvl,a.dscnt_eft_desc,a.dscnt_multi_insd_flg,a.dscnt_multi_insd_desc,a.Agent_Level_Name,a.writing_agent_id,
a.nma_agent_id as nma_id,a.nma_party_id,a.smo_agent_id as smo_id,a.smo_party_id, a.fmo_agent_id as fmo_id,a.fmo_party_id,
a.mga_agent_id as mga_id,a.mga_party_id,a.ga_agent_id as ga_id,
a.ga_party_id,a.agent_ica_agent_id,a.agent_ica_party_id,a.solicitor_agent_id,a.solicitor_party_id,a.tot_annual_sales,a.tot_online_sales,
a.tot_electronic_web_enrol,a.tot_web_enrol_sales,a.tot_dtc_ole_sales,a.tot_paper_sales,a.tot_others_sales,a.tot_aep_online_sales,
a.tot_aep_electronic_web_enrol,a.tot_aep_web_enrol_sales,a.tot_aep_dtc_ole_sales,a.tot_aep_paper_sales,a.tot_aep_others_sales,
a.tot_sm_mo_online_sales,a.tot_sm_mo_electrnic_web_enrol,a.tot_sm_mo_web_enrol_sales,a.tot_sm_mo_dtc_ole_sales,a.tot_sm_mo_paper_sales,
a.tot_sm_mo_others_sales,a.tot_aep_sales,a.tot_same_mo_eff_sales,a.new_busins_claim_aep,a.new_busins_claim_sm_mo,a.new_busins_claim,
a.claim_amt_12months_aep,a.claim_amt_12months_sm_mo,a.claim_amt_12months,a.claim_till_cycle_end_dt_aep,a.claim_till_cycle_end_dt_sm_mo,
a.claim_till_cycle_end_dt,a.total_claim_aep,a.total_claim_sm_mo, a.total_claim, a.new_busins_claim_aep_covid_adj,a.new_busins_claim_sm_mo_covid_adj,
a.new_busins_claim_covid_adj,a.claim_12months_covid_aep,a.claim_12months_covid_sm_mo,a.claim_12months_covid,a.claim_tl_cyc_end_dt_covid_aep,
a.claim_tl_cyc_end_dt_covid_sm_mo,a.claim_tl_cyc_end_dt_covid,a.total_claim_covid_aep,a.total_claim_covid_sm_mo,a.total_claim_covid,
a.new_busins_prem_aep,a.new_busins_prem_sm_mo,a.new_busins_prem,a.paid_prem_12months_aep,a.paid_prem_12months_sm_mo,a.paid_prem_12months,
a.paid_prem_tl_cyc_end_dt_aep,a.paid_prem_tl_cyc_end_dt_sm_mo,a.paid_prem_tl_cyc_end_dt,a.total_paid_prem_aep,a.total_paid_prem_sm_mo,
a.total_paid_prem,a.nblr_le_85,a.nblr_gt_85_lt_150,a.nblr_ge_150_lt_300,a.nblr_ge_300,a.nblr_le_85_covid, a.nblr_gt_85_lt_150_covid, 
a.nblr_ge_150_lt_300_covid, a.nblr_ge_300_covid,a.age_aep,a.age_sm_mo,a.age_tot,b.agt_nm as agt_nm,b.AGT_CTY as AGT_CTY,b.AGT_ST as AGT_ST,
b.AGT_SUB_TYP as AGT_SUB_TYP,b.HierarchyType_ID as HierarchyType_ID,b.FMO_Type as FMO_Type,b.FMO_Name as FMO_Name_SRA,b.FMO_ID as FMO_ID_SRA,
b.fmo_party_id as fmo_party_id_SRA,b.NMA_Type as NMA_Type,b.NMA_Name as NMA_Name_SRA,b.NMA_ID as NMA_ID_SRA,b.nma_party_id as nma_party_id_SRA,
b.SMO_Type as SMO_Type,b.SMO_Name as SMO_Name_SRA,b.SMO_ID as SMO_ID_SRA,b.smo_party_id as smo_party_id_SRA,
b.Agent_Level as Agent_Level_SRA,b.Agent_Level_Name as Agent_Level_Name_SRA,b.MGA_Type as MGA_Type,b.MGA_Name as MGA_Name_SRA,b.MGA_ID as MGA_ID_SRA,
b.mga_party_id as mga_party_id_SRA,b.GA_Type as GA_Type,b.GA_Name as GA_Name_SRA,b.GA_ID as GA_ID_SRA,b.ga_party_id as ga_party_id_SRA,
b.HierarchyStatus,b.HierarchyType as HierarchyType,b.CURRENT_STATUS as CURRENT_STATUS,c.agt_nm as agt_nm_ppl,c.AGT_CTY as AGT_CTY_ppl,
c.AGT_ST as AGT_ST_ppl,c.AGT_SUB_TYP as AGT_SUB_TYP_ppl,c.HierarchyType_ID as HierarchyType_ID_ppl,c.FMO_Type as FMO_Type_ppl,
c.FMO_Name as FMO_Name_SRA_ppl,c.FMO_ID as FMO_ID_SRA_ppl,c.fmo_party_id as fmo_party_id_SRA_ppl,c.NMA_Type as NMA_Type_ppl,
c.NMA_Name as NMA_Name_SRA_ppl,c.NMA_ID as NMA_ID_SRA_ppl,c.nma_party_id as nma_party_id_SRA_ppl,
c.SMO_Type as SMO_Type_ppl,c.SMO_Name as SMO_Name_SRA_ppl,c.SMO_ID as SMO_ID_SRA_ppl,c.smo_party_id as smo_party_id_SRA_ppl,
c.Agent_Level as Agent_Level_SRA_ppl,
c.Agent_Level_Name as Agent_Level_Name_SRA_ppl,c.MGA_Type as MGA_Type_ppl,c.MGA_Name as MGA_Name_SRA_ppl,c.MGA_ID as MGA_ID_SRA_ppl,
c.mga_party_id as mga_party_id_SRA_ppl,c.GA_Type as GA_Type_ppl,c.GA_Name as GA_Name_SRA_ppl,c.GA_ID as GA_ID_SRA_ppl,
c.ga_party_id as ga_party_id_SRA_ppl,c.HierarchyStatus as HierarchyStatus_ppl,c.HierarchyType as HierarchyType_ppl,
c.CURRENT_STATUS as CURRENT_STATUS_ppl,a.Data_Refresh_Date,a.YTD_date,a.ROY_Date,a.latest_sales_YYYYMON,a.latest_sales_yearmon,
a.incurred_till,a.incurred_till_yearmon,a.paid_through,a.paid_through_yearmon,a.powerofattorneyind_fg
from IDENTIFIER(:V_AGENT_QUALITY_SALES_LR_SUMMARIZED_GS) as a
left join IDENTIFIER(:V_AGENT_QUALITY_AGENT_PROFILE) as b 
on a.pty_id = b.pty_id
left join IDENTIFIER(:V_AGENT_QUALITY_AGENT_PROFILE) as c
on a.principalparty_id_final = c.pty_id;

--select count(*) from sales_lr_summarized_gs; --1143532; 1144059
--select count(*) from sales_lr_summarized_gs_profile_1; ---1143532; 1144059

-------------------------------

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_SALES_LR_SUMMARIZED_GS_PROFILE_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP33'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_V_D_AGT_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_AGENT_QUALITY_V_D_AGT_1) COPY GRANTS AS 
select distinct pty_id,  BUS_NM,agt_nm_fst, agt_nm_midl, agt_nm_lst, ROW_EFF_END_DT, row_eff_strt_dt,agt_wrt_strt_dt_id,agt_wrt_end_dt_id
from IDENTIFIER(:V_D_AGT)
order by pty_id, ROW_EFF_END_DT desc;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_V_D_AGT_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP34'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_V_D_AGT'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_AGENT_QUALITY_V_D_AGT) COPY GRANTS AS 
select * from(
select *, ROW_NUMBER () over(PARTITION by pty_id order by ROW_EFF_END_DT desc, row_eff_strt_dt desc) as rownumber from IDENTIFIER(:V_AGENT_QUALITY_V_D_AGT_1)) b
where rownumber = 1;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_V_D_AGT)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP35'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_SALES_LR_SUMMARIZED_GS_PROFILE_A'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table  IDENTIFIER(:V_AGENT_QUALITY_SALES_LR_SUMMARIZED_GS_PROFILE_A) COPY GRANTS AS 
select a.*,
b1.agt_nm as NMA_Name, 
b6.agt_nm as SMO_Name, 
b2.agt_nm as FMO_Name, 
b3.agt_nm as MGA_Name, 
b4.agt_nm as GA_Name,
b5.agt_nm as agent_ica_name
from  IDENTIFIER(:V_AGENT_QUALITY_SALES_LR_SUMMARIZED_GS_PROFILE_1) a 
left join (select distinct pty_id, 
(case when (TRIM(BUS_NM) = '''' or BUS_NM is null) then concat_ws('' '',agt_nm_fst,agt_nm_midl,agt_nm_lst)
else BUS_NM end) as agt_nm from IDENTIFIER(:V_AGENT_QUALITY_V_D_AGT)) b1
on a.nma_party_id = b1.pty_id
left join (select distinct pty_id, 
(case when (TRIM(BUS_NM) = '''' or BUS_NM is null) then concat_ws('' '',agt_nm_fst,agt_nm_midl,agt_nm_lst)
else BUS_NM end) as agt_nm from IDENTIFIER(:V_AGENT_QUALITY_V_D_AGT)) b6
on a.smo_party_id = b6.pty_id
left join (select distinct pty_id,
(case when (TRIM(BUS_NM) = '''' or BUS_NM is null) then concat_ws('' '',agt_nm_fst,agt_nm_midl,agt_nm_lst)
else BUS_NM end) as agt_nm from IDENTIFIER(:V_AGENT_QUALITY_V_D_AGT)) b2
on a.fmo_party_id = b2.pty_id
left join (select distinct pty_id,
(case when (TRIM(BUS_NM) = '''' or BUS_NM is null) then concat_ws('' '',agt_nm_fst,agt_nm_midl,agt_nm_lst)
else BUS_NM end) as agt_nm from IDENTIFIER(:V_AGENT_QUALITY_V_D_AGT)) b3
on a.mga_party_id = b3.pty_id
left join (select distinct pty_id,
(case when (TRIM(BUS_NM) = '''' or BUS_NM is null) then concat_ws('' '',agt_nm_fst,agt_nm_midl,agt_nm_lst)
else BUS_NM end) as agt_nm from IDENTIFIER(:V_AGENT_QUALITY_V_D_AGT)) b4
on a.ga_party_id = b4.pty_id
left join (select distinct pty_id,
(case when (TRIM(BUS_NM) = '''' or BUS_NM is null) then concat_ws('' '',agt_nm_fst,agt_nm_midl,agt_nm_lst)
else BUS_NM end) as agt_nm from IDENTIFIER(:V_AGENT_QUALITY_V_D_AGT)) b5
on a.agent_ica_party_id = b5.pty_id;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_SALES_LR_SUMMARIZED_GS_PROFILE_A)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP36'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_SALES_LR_SUMMARIZED_GS_PROFILE_B'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


---------
--??????---------###############################
create or replace table IDENTIFIER(:V_AGENT_QUALITY_SALES_LR_SUMMARIZED_GS_PROFILE_B) COPY GRANTS AS 
select distinct * from (
select a.*, b.parent as parent_sra, c.parent as parent_dynamic from IDENTIFIER(:V_AGENT_QUALITY_SALES_LR_SUMMARIZED_GS_PROFILE_A) a
left join IDENTIFIER(:V_AGENT_QUALITY_NMA_AND_PARENT_CO) b on a.nma_name_sra = b.nma_sra_static
left join IDENTIFIER(:V_AGENT_QUALITY_NMA_AND_PARENT_CO) c on a.nma_name = c.nma_dynamic) b ;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_SALES_LR_SUMMARIZED_GS_PROFILE_B)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP37'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_SALES_LR_SUMMARIZED_GS_PROFILE'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_AGENT_QUALITY_SALES_LR_SUMMARIZED_GS_PROFILE) COPY GRANTS AS 
select *, to_varchar(current_date,''Mon'') as current_month,
to_varchar(dateadd(month,1,current_date),''Mon'') as next_month
from IDENTIFIER(:V_AGENT_QUALITY_SALES_LR_SUMMARIZED_GS_PROFILE_B);

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_SALES_LR_SUMMARIZED_GS_PROFILE)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP38'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_COMBINED_DT_GS_PROFILE_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table  IDENTIFIER(:V_AGENT_QUALITY_COMBINED_DT_GS_PROFILE_1) COPY GRANTS AS 
select a.pty_id,a.agt_id,a.principalparty_id_final,a.year,a.d_st_cd,a.RDC,a.agent_level_name,a.writing_agent_id ,
a.nma_agent_id as nma_id,a.nma_party_id,
a.smo_agent_id as smo_id,a.smo_party_id,
a.fmo_agent_id as fmo_id,a.fmo_party_id 
,a.mga_agent_id as mga_id,a.mga_party_id,a.ga_agent_id as ga_id,a.ga_party_id,a.agent_ica_agent_id,a.agent_ica_party_id,a.solicitor_agent_id
,a.solicitor_party_id,a.tot_annual_ma_sales as tot_annual_ma_sales,a.tot_aep_ma_sales as tot_aep_ma_sales,a.tot_same_mo_ma_sales as tot_same_mo_ma_sales,
a.tot_annual_pdp_sales as tot_annual_pdp_sales,a.tot_aep_pdp_sales as tot_aep_pdp_sales,a.tot_same_mo_pdp_sales as tot_same_mo_pdp_sales,
a.tot_ms_pdp_annual_sales as tot_ms_pdp_annual_sales,a.tot_ms_pdp_aep_sales as tot_ms_pdp_aep_sales,a.tot_ms_pdp_same_mo_eff_sales as tot_ms_pdp_same_mo_eff_sales,
a.mbrship_12 as mbrship_12,a.mbrship_sy_dec as mbrship_sy_dec,a.mbrship_06 as mbrship_06,a.sum_age_12 as sum_age_12,a.sum_age_sy_dec as sum_age_sy_dec,
a.sum_age_06 as sum_age_06,a.tot_annual_lapsers as tot_annual_lapsers,a.tot_aep_lapsers as tot_aep_lapsers,a.tot_same_mo_lapsers as tot_same_mo_lapsers,
a.tot_annual_invol_lapsers as tot_annual_invol_lapsers,a.tot_aep_invol_lapsers as tot_aep_invol_lapsers,a.tot_same_mo_invol_lapsers as tot_same_mo_invol_lapsers,
a.tot_never_actv_all as tot_never_actv_all,a.tot_never_actv_all_aep as tot_never_actv_all_aep,a.tot_never_actv_all_sm_mo as tot_never_actv_all_sm_mo,
a.tot_never_actv_npop_vol as tot_never_actv_npop_vol,a.tot_never_actv_npop_vol_aep as tot_never_actv_npop_vol_aep,
a.tot_never_actv_npop_vol_sm_mo as tot_never_actv_npop_vol_sm_mo,a.tot_annual_pln_chng as tot_annual_pln_chng,a.tot_aep_pln_chng as tot_aep_pln_chng,
a.tot_same_mo_pln_chng as tot_same_mo_pln_chng,a.tot_claim as tot_claim,a.tot_clm_covid as tot_clm_covid,a.tot_prem as tot_prem,a.actv_mbr as actv_mbr,
a.tot_annual_ms_sales as tot_annual_ms_sales,a.tot_aep_ms_sales as tot_aep_ms_sales,a.tot_same_mo_eff_ms_sales as tot_same_mo_eff_ms_sales,new_busins_claim_aep,
a.new_busins_claim_sm_mo, a.new_busins_claim, a.claim_amt_12months_aep, a.claim_amt_12months_sm_mo, a.claim_amt_12months, a.claim_till_cycle_end_dt_aep,
 a.claim_till_cycle_end_dt_sm_mo, a.claim_till_cycle_end_dt, a.total_claim_aep, a.total_claim_sm_mo, a.total_claim, a.new_busins_claim_aep_covid_adj,
 a.new_busins_claim_sm_mo_covid_adj, a.new_busins_claim_covid_adj,a.claim_12months_covid_aep, a.claim_12months_covid_sm_mo, a.claim_12months_covid, 
 a.claim_tl_cyc_end_dt_covid_aep, a.claim_tl_cyc_end_dt_covid_sm_mo, a.claim_tl_cyc_end_dt_covid, a.total_claim_covid_aep, a.total_claim_covid_sm_mo, 
 a.total_claim_covid, a.new_busins_prem_aep, a.new_busins_prem_sm_mo, a.new_busins_prem, a.paid_prem_12months_aep, a.paid_prem_12months_sm_mo, 
 a.paid_prem_12months, a.paid_prem_tl_cyc_end_dt_aep, a.paid_prem_tl_cyc_end_dt_sm_mo, a.paid_prem_tl_cyc_end_dt, a.total_paid_prem_aep, a.total_paid_prem_sm_mo,
 a.total_paid_prem,a.tot_oe_sales_aep,a.tot_same_mo_eff_oe_sales,a.tot_annual_oe_sales,a.tot_gi_sales_aep,a.tot_same_mo_eff_gi_sales,a.tot_annual_gi_sales,
 a.tot_uw_sales_aep,a.tot_same_mo_eff_uw_sales,a.tot_annual_uw_sales,a.tot_uw_dflt_sales_aep,a.tot_same_mo_eff_uw_dflt_sales,a.tot_annual_uw_dflt_sales,
 a.submitted_apps as submitted_apps,a.approved_apps as approved_apps,a.tot_aep_submitted_apps as tot_aep_submitted_apps,a.tot_aep_approved_apps as tot_aep_approved_apps
  ,a.tot_same_mo_submitted_apps as tot_same_mo_submitted_apps,a.tot_same_mo_approved_apps as tot_same_mo_approved_apps,a.MA_SNP_MS_Switchers as MA_SNP_MS_Switchers
  ,a.MA_Indv_MS_Switchers as MA_Indv_MS_Switchers,a.MA_Group_MS_Switchers as MA_Group_MS_Switchers,a.MA_MS_Switchers as MA_MS_Switchers,
  a.tot_aep_MA_SNP_MS_Switchers as tot_aep_MA_SNP_MS_Switchers,a.tot_aep_MA_Indv_MS_Switchers as tot_aep_MA_Indv_MS_Switchers,
  a.tot_aep_MA_Group_MS_Switchers as tot_aep_MA_Group_MS_Switchers,a.tot_aep_MA_MS_Switchers as tot_aep_MA_MS_Switchers,a.tot_same_mo_MA_SNP_MS_Switchers as tot_same_mo_MA_SNP_MS_Switchers
  ,a.tot_same_mo_MA_Indv_MS_Switchers as tot_same_mo_MA_Indv_MS_Switchers,a.tot_same_mo_MA_Grp_MS_Switchers as tot_same_mo_MA_Grp_MS_Switchers,
  a.tot_same_mo_MA_MS_Switchers as tot_same_mo_MA_MS_Switchers,a.MS_MA_Switchers as MS_MA_Switchers,a.tot_aep_MS_MA_Switchers as tot_aep_MS_MA_Switchers,
  a.tot_same_mo_MS_MA_Switchers as tot_same_mo_MS_MA_Switchers,a.cnt_ma_pdp as cnt_ma_pdp,a.cnt_ms_ms_switchers as cnt_ms_ms_switchers,b.agt_nm as agt_nm,
  b.AGT_CTY as AGT_CTY,b.AGT_ST as AGT_ST,b.AGT_SUB_TYP as AGT_SUB_TYP,b.HierarchyType_ID as HierarchyType_ID, b.FMO_Type as FMO_Type,b.FMO_Name as FMO_Name_SRA,
  b.FMO_ID as FMO_ID_SRA, b.fmo_party_id as fmo_party_id_SRA, 
  b.NMA_Type as NMA_Type, b.NMA_Name as NMA_Name_SRA, b.NMA_ID as NMA_ID_SRA, b.nma_party_id as nma_party_id_SRA,
b.SMO_Type as SMO_Type, b.SMO_Name as SMO_Name_SRA, b.SMO_ID as SMO_ID_SRA, b.smo_party_id as smo_party_id_SRA,
  b.Agent_Level as Agent_Level_SRA, b.Agent_Level_Name as Agent_Level_Name_SRA, 
  b.MGA_Type as MGA_Type,b.MGA_Name as MGA_Name_SRA, b.MGA_ID as MGA_ID_SRA, b.mga_party_id as mga_party_id_SRA, b.GA_Type as GA_Type, b.GA_Name as GA_Name_SRA, b.GA_ID as GA_ID_SRA, b.ga_party_id as ga_party_id_SRA, b.HierarchyStatus, b.HierarchyType as HierarchyType, b.CURRENT_STATUS as CURRENT_STATUS,c.agt_nm as agt_nm_ppl,c.AGT_CTY as AGT_CTY_ppl,c.AGT_ST as AGT_ST_ppl,c.AGT_SUB_TYP as AGT_SUB_TYP_ppl,c.HierarchyType_ID as HierarchyType_ID_ppl, c.FMO_Type as FMO_Type_ppl,c.FMO_Name as FMO_Name_SRA_ppl,
  c.FMO_ID as FMO_ID_SRA_ppl, c.fmo_party_id as fmo_party_id_SRA_ppl, 
  c.NMA_Type as NMA_Type_ppl, c.NMA_Name as NMA_Name_SRA_ppl, c.NMA_ID as NMA_ID_SRA_ppl, c.nma_party_id as nma_party_id_SRA_ppl,
c.SMO_Type as SMO_Type_ppl, c.SMO_Name as SMO_Name_SRA_ppl, c.SMO_ID as SMO_ID_SRA_ppl, c.smo_party_id as smo_party_id_SRA_ppl,
  c.Agent_Level as Agent_Level_SRA_ppl, c.Agent_Level_Name as Agent_Level_Name_SRA_ppl,
  c.MGA_Type as MGA_Type_ppl,c.MGA_Name as MGA_Name_SRA_ppl, c.MGA_ID as MGA_ID_SRA_ppl, c.mga_party_id as mga_party_id_SRA_ppl, c.GA_Type as GA_Type_ppl, c.GA_Name as GA_Name_SRA_ppl, c.GA_ID as GA_ID_SRA_ppl, c.ga_party_id as ga_party_id_SRA_ppl, c.HierarchyStatus as HierarchyStatus_ppl, c.HierarchyType as HierarchyType_ppl, c.CURRENT_STATUS as CURRENT_STATUS_ppl,a.Data_Refresh_Date,a.YTD_date,a.ROY_Date,
  a.latest_sales_YYYYMON,a.latest_sales_yearmon,a.incurred_till,a.incurred_till_yearmon,a.paid_through,a.paid_through_yearmon,
  a.current_month,a.next_month
from  IDENTIFIER(:V_AGENT_QUALITY_COMBINED_DT_GS_V3) as a
left join  IDENTIFIER(:V_AGENT_QUALITY_AGENT_PROFILE) as b on a.pty_id = b.pty_id
left join IDENTIFIER(:V_AGENT_QUALITY_AGENT_PROFILE) as c on a.principalparty_id_final = c.pty_id;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_COMBINED_DT_GS_PROFILE_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP39'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_COMBINED_DT_GS_PROFILE_A'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table  IDENTIFIER(:V_AGENT_QUALITY_COMBINED_DT_GS_PROFILE_A) COPY GRANTS AS 
select a.*,
b1.agt_nm as NMA_Name, 
b6.agt_nm as SMO_Name,
b2.agt_nm as FMO_Name,
b3.agt_nm as MGA_Name,
b4.agt_nm as GA_Name,
b5.agt_nm as agent_ica_name
from  IDENTIFIER(:V_AGENT_QUALITY_COMBINED_DT_GS_PROFILE_1) a 
left join (select distinct pty_id, 
(case when (TRIM(BUS_NM) = '''' or BUS_NM is null) then concat_ws('' '',agt_nm_fst,agt_nm_midl,agt_nm_lst)
else BUS_NM end) as agt_nm from IDENTIFIER(:V_AGENT_QUALITY_V_D_AGT)) b1
on a.nma_party_id = b1.pty_id
left join (select distinct pty_id, 
(case when (TRIM(BUS_NM) = '''' or BUS_NM is null) then concat_ws('' '',agt_nm_fst,agt_nm_midl,agt_nm_lst)
else BUS_NM end) as agt_nm from  IDENTIFIER(:V_AGENT_QUALITY_V_D_AGT)) b6
on a.smo_party_id = b6.pty_id
left join (select distinct pty_id, 
(case when (TRIM(BUS_NM) = '''' or BUS_NM is null) then concat_ws('' '',agt_nm_fst,agt_nm_midl,agt_nm_lst)
else BUS_NM end) as agt_nm from  IDENTIFIER(:V_AGENT_QUALITY_V_D_AGT)) b2
on a.fmo_party_id = b2.pty_id
left join (select distinct pty_id, 
(case when (TRIM(BUS_NM) = '''' or BUS_NM is null) then concat_ws('' '',agt_nm_fst,agt_nm_midl,agt_nm_lst)
else BUS_NM end) as agt_nm from  IDENTIFIER(:V_AGENT_QUALITY_V_D_AGT)) b3
on a.mga_party_id = b3.pty_id
left join (select distinct pty_id, 
(case when (TRIM(BUS_NM) = '''' or BUS_NM is null) then concat_ws('' '',agt_nm_fst,agt_nm_midl,agt_nm_lst)
else BUS_NM end) as agt_nm from  IDENTIFIER(:V_AGENT_QUALITY_V_D_AGT)) b4
on a.ga_party_id = b4.pty_id
left join (select distinct pty_id,
(case when (TRIM(BUS_NM) = '''' or BUS_NM is null) then concat_ws('' '',agt_nm_fst,agt_nm_midl,agt_nm_lst)
else BUS_NM end) as agt_nm from  IDENTIFIER(:V_AGENT_QUALITY_V_D_AGT)) b5
on a.agent_ica_party_id = b5.pty_id;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_COMBINED_DT_GS_PROFILE_A)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP40'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_COMBINED_DT_GS_PROFILE'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


-- Note: desc formatted common_ogs.nma_and_parent_co; ---Wed Nov 17 00:50:16 CST 2021
-- and in production: Nov 20  2021

create or replace table IDENTIFIER(:V_AGENT_QUALITY_COMBINED_DT_GS_PROFILE) COPY GRANTS AS 
select distinct * from (
select a.*, b.parent as parent_sra, c.parent as parent_dynamic from IDENTIFIER(:V_AGENT_QUALITY_COMBINED_DT_GS_PROFILE_A) a
left join IDENTIFIER(:V_AGENT_QUALITY_NMA_AND_PARENT_CO) b on a.nma_name_sra = b.nma_sra_static
left join IDENTIFIER(:V_AGENT_QUALITY_NMA_AND_PARENT_CO) c on a.nma_name = c.nma_dynamic) b ;



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_COMBINED_DT_GS_PROFILE)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP41'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_AGENT_QC'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());



create or replace table IDENTIFIER(:V_AGENT_QUALITY_AGENT_QC) COPY GRANTS AS 
select a.year, tot_annual_ma_sales,tot_aep_ma_sales,tot_same_mo_ma_sales,tot_annual_pdp_sales,tot_aep_pdp_sales,tot_same_mo_pdp_sales,tot_ms_pdp_annual_sales,tot_ms_pdp_aep_sales,tot_ms_pdp_same_mo_eff_sales,mbrship_12,mbrship_06,tot_annual_lapsers,tot_aep_lapsers,tot_same_mo_lapsers,tot_annual_invol_lapsers,tot_aep_invol_lapsers,tot_same_mo_invol_lapsers,tot_never_actv_all,tot_never_actv_all_aep,tot_never_actv_all_sm_mo,tot_never_actv_npop_vol,tot_never_actv_npop_vol_aep,tot_never_actv_npop_vol_sm_mo,tot_annual_pln_chng,tot_aep_pln_chng,tot_same_mo_pln_chng,tot_claim,tot_clm_covid,tot_prem,actv_mbr,tot_annual_ms_sales,tot_aep_ms_sales,tot_same_mo_eff_ms_sales,tot_oe_sales_aep,tot_same_mo_eff_oe_sales,tot_annual_oe_sales,tot_gi_sales_aep,tot_same_mo_eff_gi_sales,tot_annual_gi_sales,tot_uw_sales_aep,tot_same_mo_eff_uw_sales,tot_annual_uw_sales,tot_uw_dflt_sales_aep,tot_same_mo_eff_uw_dflt_sales,tot_annual_uw_dflt_sales,ms_new_busins_claim ,ms_new_busins_prem ,submitted_apps,approved_apps,tot_aep_submitted_apps,tot_aep_approved_apps,tot_same_mo_submitted_apps,tot_same_mo_approved_apps,MA_SNP_MS_Switchers,MA_Indv_MS_Switchers,MA_Group_MS_Switchers,MA_MS_Switchers,tot_aep_MA_SNP_MS_Switchers,tot_aep_MA_Indv_MS_Switchers,tot_aep_MA_Group_MS_Switchers,tot_aep_MA_MS_Switchers,tot_same_mo_MA_SNP_MS_Switchers,tot_same_mo_MA_Indv_MS_Switchers,tot_same_mo_MA_Grp_MS_Switchers,tot_same_mo_MA_MS_Switchers,MS_MA_Switchers,tot_aep_MS_MA_Switchers,tot_same_mo_MS_MA_Switchers,cnt_distinct_pty_ids,cnt_distinct_agt_ids
,tot_annual_ma_sales_prev,tot_aep_ma_sales_prev,tot_same_mo_ma_sales_prev,tot_annual_pdp_sales_prev,tot_aep_pdp_sales_prev,tot_same_mo_pdp_sales_prev,tot_ms_pdp_annual_sales_prev,tot_ms_pdp_aep_sales_prev,tot_ms_pdp_same_mo_eff_sales_prev,mbrship_12_prev,mbrship_06_prev,tot_annual_lapsers_prev,tot_aep_lapsers_prev,tot_same_mo_lapsers_prev,tot_annual_invol_lapsers_prev,tot_aep_invol_lapsers_prev,tot_same_mo_invol_lapsers_prev,tot_never_actv_all_prev,tot_never_actv_all_aep_prev,tot_never_actv_all_sm_mo_prev,tot_never_actv_npop_vol_prev,tot_never_actv_npop_vol_aep_prev,tot_never_actv_npop_vol_sm_mo_prev,tot_annual_pln_chng_prev,tot_aep_pln_chng_prev,tot_same_mo_pln_chng_prev,tot_claim_prev,tot_clm_covid_prev,tot_prem_prev,actv_mbr_prev,tot_annual_ms_sales_prev,tot_aep_ms_sales_prev,tot_same_mo_eff_ms_sales_prev,tot_oe_sales_aep_prev,tot_same_mo_eff_oe_sales_prev,tot_annual_oe_sales_prev,tot_gi_sales_aep_prev,tot_same_mo_eff_gi_sales_prev,tot_annual_gi_sales_prev,tot_uw_sales_aep_prev,tot_same_mo_eff_uw_sales_prev,tot_annual_uw_sales_prev,tot_uw_dflt_sales_aep_prev,tot_same_mo_eff_uw_dflt_sales_prev,tot_annual_uw_dflt_sales_prev,ms_new_busins_claim_prev ,ms_new_busins_prem_prev ,submitted_apps_prev,approved_apps_prev,tot_aep_submitted_apps_prev,tot_aep_approved_apps_prev,tot_same_mo_submitted_apps_prev,tot_same_mo_approved_apps_prev,MA_SNP_MS_Switchers_prev,MA_Indv_MS_Switchers_prev,MA_Group_MS_Switchers_prev,MA_MS_Switchers_prev,tot_aep_MA_SNP_MS_Switchers_prev,tot_aep_MA_Indv_MS_Switchers_prev,tot_aep_MA_Group_MS_Switchers_prev,tot_aep_MA_MS_Switchers_prev,tot_same_mo_MA_SNP_MS_Switchers_prev,tot_same_mo_MA_Indv_MS_Switchers_prev,tot_same_mo_MA_Grp_MS_Switchers_prev,tot_same_mo_MA_MS_Switchers_prev,MS_MA_Switchers_prev,tot_aep_MS_MA_Switchers_prev,tot_same_mo_MS_MA_Switchers_prev,cnt_distinct_pty_ids_prev,cnt_distinct_agt_ids_prev
from
(select year, 
sum(tot_annual_ma_sales/cnt_ma_pdp) as tot_annual_ma_sales,
sum(tot_aep_ma_sales/cnt_ma_pdp) as tot_aep_ma_sales,
sum(tot_same_mo_ma_sales/cnt_ma_pdp) as tot_same_mo_ma_sales,
sum(tot_annual_pdp_sales/cnt_ma_pdp) as tot_annual_pdp_sales,
sum(tot_aep_pdp_sales/cnt_ma_pdp) as tot_aep_pdp_sales,
sum(tot_same_mo_pdp_sales/cnt_ma_pdp) as tot_same_mo_pdp_sales,
sum(tot_ms_pdp_annual_sales) as tot_ms_pdp_annual_sales,
sum(tot_ms_pdp_aep_sales) as tot_ms_pdp_aep_sales,
sum(tot_ms_pdp_same_mo_eff_sales) as tot_ms_pdp_same_mo_eff_sales,
sum(mbrship_12) as mbrship_12,
sum(mbrship_06) as mbrship_06,
sum(tot_annual_lapsers) as tot_annual_lapsers,
sum(tot_aep_lapsers) as tot_aep_lapsers,
sum(tot_same_mo_lapsers) as tot_same_mo_lapsers,
sum(tot_annual_invol_lapsers) as tot_annual_invol_lapsers,
sum(tot_aep_invol_lapsers) as tot_aep_invol_lapsers,
sum(tot_same_mo_invol_lapsers) as tot_same_mo_invol_lapsers,
sum(tot_never_actv_all) as tot_never_actv_all,
sum(tot_never_actv_all_aep) as tot_never_actv_all_aep,
sum(tot_never_actv_all_sm_mo) as tot_never_actv_all_sm_mo,
sum(tot_never_actv_npop_vol) as tot_never_actv_npop_vol,
sum(tot_never_actv_npop_vol_aep) as tot_never_actv_npop_vol_aep,
sum(tot_never_actv_npop_vol_sm_mo) as tot_never_actv_npop_vol_sm_mo,
sum(tot_annual_pln_chng) as tot_annual_pln_chng,
sum(tot_aep_pln_chng) as tot_aep_pln_chng,
sum(tot_same_mo_pln_chng) as tot_same_mo_pln_chng,
sum(tot_claim) as tot_claim,
sum(tot_clm_covid) as tot_clm_covid,
sum(tot_prem) as tot_prem,
sum(actv_mbr) as actv_mbr,
sum(tot_annual_ms_sales) as tot_annual_ms_sales,
sum(tot_aep_ms_sales) as tot_aep_ms_sales,
sum(tot_same_mo_eff_ms_sales) as tot_same_mo_eff_ms_sales,
sum(tot_oe_sales_aep) as tot_oe_sales_aep,
sum(tot_same_mo_eff_oe_sales) as tot_same_mo_eff_oe_sales,
sum(tot_annual_oe_sales) as tot_annual_oe_sales,
sum(tot_gi_sales_aep) as tot_gi_sales_aep,
sum(tot_same_mo_eff_gi_sales) as tot_same_mo_eff_gi_sales,
sum(tot_annual_gi_sales) as tot_annual_gi_sales,
sum(tot_uw_sales_aep) as tot_uw_sales_aep,
sum(tot_same_mo_eff_uw_sales) as tot_same_mo_eff_uw_sales,
sum(tot_annual_uw_sales) as tot_annual_uw_sales,
sum(tot_uw_dflt_sales_aep) as tot_uw_dflt_sales_aep,
sum(tot_same_mo_eff_uw_dflt_sales) as tot_same_mo_eff_uw_dflt_sales,
sum(tot_annual_uw_dflt_sales) as tot_annual_uw_dflt_sales,
sum(new_busins_claim) as ms_new_busins_claim ,
sum(new_busins_prem) as ms_new_busins_prem ,
sum(submitted_apps) as submitted_apps,
sum(approved_apps) as approved_apps,
sum(tot_aep_submitted_apps) as tot_aep_submitted_apps,
sum(tot_aep_approved_apps) as tot_aep_approved_apps,
sum(tot_same_mo_submitted_apps) as tot_same_mo_submitted_apps,
sum(tot_same_mo_approved_apps) as tot_same_mo_approved_apps,
sum(MA_SNP_MS_Switchers) as MA_SNP_MS_Switchers,
sum(MA_Indv_MS_Switchers) as MA_Indv_MS_Switchers,
sum(MA_Group_MS_Switchers) as MA_Group_MS_Switchers,
sum(MA_MS_Switchers) as MA_MS_Switchers,
sum(tot_aep_MA_SNP_MS_Switchers) as tot_aep_MA_SNP_MS_Switchers,
sum(tot_aep_MA_Indv_MS_Switchers) as tot_aep_MA_Indv_MS_Switchers,
sum(tot_aep_MA_Group_MS_Switchers) as tot_aep_MA_Group_MS_Switchers,
sum(tot_aep_MA_MS_Switchers) as tot_aep_MA_MS_Switchers,
sum(tot_same_mo_MA_SNP_MS_Switchers) as tot_same_mo_MA_SNP_MS_Switchers,
sum(tot_same_mo_MA_Indv_MS_Switchers) as tot_same_mo_MA_Indv_MS_Switchers,
sum(tot_same_mo_MA_Grp_MS_Switchers) as tot_same_mo_MA_Grp_MS_Switchers,
sum(tot_same_mo_MA_MS_Switchers) as tot_same_mo_MA_MS_Switchers,
sum(MS_MA_Switchers) as MS_MA_Switchers,
sum(tot_aep_MS_MA_Switchers) as tot_aep_MS_MA_Switchers,
sum(tot_same_mo_MS_MA_Switchers) as tot_same_mo_MS_MA_Switchers,
count(distinct pty_id) as cnt_distinct_pty_ids,
count(distinct agt_id) as cnt_distinct_agt_ids
from IDENTIFIER(:V_AGENT_QUALITY_COMBINED_DT_GS_PROFILE)
group by year) a
left join (select year, 
sum(tot_annual_ma_sales/cnt_ma_pdp) as tot_annual_ma_sales_prev,
sum(tot_aep_ma_sales/cnt_ma_pdp) as tot_aep_ma_sales_prev,
sum(tot_same_mo_ma_sales/cnt_ma_pdp) as tot_same_mo_ma_sales_prev,
sum(tot_annual_pdp_sales/cnt_ma_pdp) as tot_annual_pdp_sales_prev,
sum(tot_aep_pdp_sales/cnt_ma_pdp) as tot_aep_pdp_sales_prev,
sum(tot_same_mo_pdp_sales/cnt_ma_pdp) as tot_same_mo_pdp_sales_prev,
sum(tot_ms_pdp_annual_sales) as tot_ms_pdp_annual_sales_prev,
sum(tot_ms_pdp_aep_sales) as tot_ms_pdp_aep_sales_prev,
sum(tot_ms_pdp_same_mo_eff_sales) as tot_ms_pdp_same_mo_eff_sales_prev,
sum(mbrship_12) as mbrship_12_prev,
sum(mbrship_06) as mbrship_06_prev,
sum(tot_annual_lapsers) as tot_annual_lapsers_prev,
sum(tot_aep_lapsers) as tot_aep_lapsers_prev,
sum(tot_same_mo_lapsers) as tot_same_mo_lapsers_prev,
sum(tot_annual_invol_lapsers) as tot_annual_invol_lapsers_prev,
sum(tot_aep_invol_lapsers) as tot_aep_invol_lapsers_prev,
sum(tot_same_mo_invol_lapsers) as tot_same_mo_invol_lapsers_prev,
sum(tot_never_actv_all) as tot_never_actv_all_prev,
sum(tot_never_actv_all_aep) as tot_never_actv_all_aep_prev,
sum(tot_never_actv_all_sm_mo) as tot_never_actv_all_sm_mo_prev,
sum(tot_never_actv_npop_vol) as tot_never_actv_npop_vol_prev,
sum(tot_never_actv_npop_vol_aep) as tot_never_actv_npop_vol_aep_prev,
sum(tot_never_actv_npop_vol_sm_mo) as tot_never_actv_npop_vol_sm_mo_prev,
sum(tot_annual_pln_chng) as tot_annual_pln_chng_prev,
sum(tot_aep_pln_chng) as tot_aep_pln_chng_prev,
sum(tot_same_mo_pln_chng) as tot_same_mo_pln_chng_prev,
sum(tot_claim) as tot_claim_prev,
sum(tot_clm_covid) as tot_clm_covid_prev,
sum(tot_prem) as tot_prem_prev,
sum(actv_mbr) as actv_mbr_prev,
sum(tot_annual_ms_sales) as tot_annual_ms_sales_prev,
sum(tot_aep_ms_sales) as tot_aep_ms_sales_prev,
sum(tot_same_mo_eff_ms_sales) as tot_same_mo_eff_ms_sales_prev,
sum(tot_oe_sales_aep) as tot_oe_sales_aep_prev,
sum(tot_same_mo_eff_oe_sales) as tot_same_mo_eff_oe_sales_prev,
sum(tot_annual_oe_sales) as tot_annual_oe_sales_prev,
sum(tot_gi_sales_aep) as tot_gi_sales_aep_prev,
sum(tot_same_mo_eff_gi_sales) as tot_same_mo_eff_gi_sales_prev,
sum(tot_annual_gi_sales) as tot_annual_gi_sales_prev,
sum(tot_uw_sales_aep) as tot_uw_sales_aep_prev,
sum(tot_same_mo_eff_uw_sales) as tot_same_mo_eff_uw_sales_prev,
sum(tot_annual_uw_sales) as tot_annual_uw_sales_prev,
sum(tot_uw_dflt_sales_aep) as tot_uw_dflt_sales_aep_prev,
sum(tot_same_mo_eff_uw_dflt_sales) as tot_same_mo_eff_uw_dflt_sales_prev,
sum(tot_annual_uw_dflt_sales) as tot_annual_uw_dflt_sales_prev,
sum(new_busins_claim) as ms_new_busins_claim_prev ,
sum(new_busins_prem) as ms_new_busins_prem_prev ,
sum(submitted_apps) as submitted_apps_prev,
sum(approved_apps) as approved_apps_prev,
sum(tot_aep_submitted_apps) as tot_aep_submitted_apps_prev,
sum(tot_aep_approved_apps) as tot_aep_approved_apps_prev,
sum(tot_same_mo_submitted_apps) as tot_same_mo_submitted_apps_prev,
sum(tot_same_mo_approved_apps) as tot_same_mo_approved_apps_prev,
sum(MA_SNP_MS_Switchers) as MA_SNP_MS_Switchers_prev,
sum(MA_Indv_MS_Switchers) as MA_Indv_MS_Switchers_prev,
sum(MA_Group_MS_Switchers) as MA_Group_MS_Switchers_prev,
sum(MA_MS_Switchers) as MA_MS_Switchers_prev,
sum(tot_aep_MA_SNP_MS_Switchers) as tot_aep_MA_SNP_MS_Switchers_prev,
sum(tot_aep_MA_Indv_MS_Switchers) as tot_aep_MA_Indv_MS_Switchers_prev,
sum(tot_aep_MA_Group_MS_Switchers) as tot_aep_MA_Group_MS_Switchers_prev,
sum(tot_aep_MA_MS_Switchers) as tot_aep_MA_MS_Switchers_prev,
sum(tot_same_mo_MA_SNP_MS_Switchers) as tot_same_mo_MA_SNP_MS_Switchers_prev,
sum(tot_same_mo_MA_Indv_MS_Switchers) as tot_same_mo_MA_Indv_MS_Switchers_prev,
sum(tot_same_mo_MA_Grp_MS_Switchers) as tot_same_mo_MA_Grp_MS_Switchers_prev,
sum(tot_same_mo_MA_MS_Switchers) as tot_same_mo_MA_MS_Switchers_prev,
sum(MS_MA_Switchers) as MS_MA_Switchers_prev,
sum(tot_aep_MS_MA_Switchers) as tot_aep_MS_MA_Switchers_prev,
sum(tot_same_mo_MS_MA_Switchers) as tot_same_mo_MS_MA_Switchers_prev,
count(distinct pty_id) as cnt_distinct_pty_ids_prev,
count(distinct agt_id) as cnt_distinct_agt_ids_prev
from IDENTIFIER(:V_AGENT_QUALITY_COMBINED_DT_GS_PROFILE_BACKUP)
group by year) b 
on a.year = b.year;

-- select * from agent_qc;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_AGENT_QC)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP42'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_AGENT_QC_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_AGENT_QUALITY_AGENT_QC_1) COPY GRANTS AS 
select a.*,b.* from (
select year as yr1
,sum(tot_annual_sales) as tot_annual_sales
,sum(tot_online_sales) as tot_online_sales
,sum(tot_electronic_web_enrol) as tot_electronic_web_enrol
,sum(tot_web_enrol_sales) as tot_web_enrol_sales
,sum(tot_dtc_ole_sales) as tot_dtc_ole_sales
,sum(tot_paper_sales) as tot_paper_sales
,sum(tot_others_sales) as tot_others_sales
,sum(tot_aep_online_sales) as tot_aep_online_sales
,sum(tot_aep_electronic_web_enrol) as tot_aep_electronic_web_enrol
,sum(tot_aep_web_enrol_sales) as tot_aep_web_enrol_sales
,sum(tot_aep_dtc_ole_sales) as tot_aep_dtc_ole_sales
,sum(tot_aep_paper_sales) as tot_aep_paper_sales
,sum(tot_aep_others_sales) as tot_aep_others_sales
,sum(tot_sm_mo_online_sales) as tot_sm_mo_online_sales
,sum(tot_sm_mo_electrnic_web_enrol) as tot_sm_mo_electrnic_web_enrol
,sum(tot_sm_mo_web_enrol_sales) as tot_sm_mo_web_enrol_sales
,sum(tot_sm_mo_dtc_ole_sales) as tot_sm_mo_dtc_ole_sales
,sum(tot_sm_mo_paper_sales) as tot_sm_mo_paper_sales
,sum(tot_sm_mo_others_sales) as tot_sm_mo_others_sales
,sum(tot_aep_sales) as tot_aep_sales
,sum(tot_same_mo_eff_sales) as tot_same_mo_eff_sales
,sum(new_busins_claim_aep) as new_busins_claim_aep
,sum(new_busins_claim_sm_mo) as new_busins_claim_sm_mo
,sum(new_busins_claim) as new_busins_claim
,sum(claim_amt_12months_aep) as claim_amt_12months_aep
,sum(claim_amt_12months_sm_mo) as claim_amt_12months_sm_mo
,sum(claim_amt_12months) as claim_amt_12months
,sum(claim_till_cycle_end_dt_aep) as claim_till_cycle_end_dt_aep
,sum(claim_till_cycle_end_dt_sm_mo) as claim_till_cycle_end_dt_sm_mo
,sum(claim_till_cycle_end_dt) as claim_till_cycle_end_dt
,sum(total_claim_aep) as total_claim_aep
,sum(total_claim_sm_mo) as total_claim_sm_mo
,sum(total_claim) as total_claim
,sum(new_busins_claim_aep_covid_adj) as new_busins_claim_aep_covid_adj
,sum(new_busins_claim_sm_mo_covid_adj) as new_busins_claim_sm_mo_covid_adj
,sum(new_busins_claim_covid_adj) as new_busins_claim_covid_adj
,sum(claim_12months_covid_aep) as claim_12months_covid_aep
,sum(claim_12months_covid_sm_mo) as claim_12months_covid_sm_mo
,sum(claim_12months_covid) as claim_12months_covid
,sum(claim_tl_cyc_end_dt_covid_aep) as claim_tl_cyc_end_dt_covid_aep
,sum(claim_tl_cyc_end_dt_covid_sm_mo) as claim_tl_cyc_end_dt_covid_sm_mo
,sum(claim_tl_cyc_end_dt_covid) as claim_tl_cyc_end_dt_covid
,sum(total_claim_covid_aep) as total_claim_covid_aep
,sum(total_claim_covid_sm_mo) as total_claim_covid_sm_mo
,sum(total_claim_covid) as total_claim_covid
,sum(new_busins_prem_aep) as new_busins_prem_aep
,sum(new_busins_prem_sm_mo) as new_busins_prem_sm_mo
,sum(new_busins_prem) as new_busins_prem
,sum(paid_prem_12months_aep) as paid_prem_12months_aep
,sum(paid_prem_12months_sm_mo) as paid_prem_12months_sm_mo
,sum(paid_prem_12months) as paid_prem_12months
,sum(paid_prem_tl_cyc_end_dt_aep) as paid_prem_tl_cyc_end_dt_aep
,sum(paid_prem_tl_cyc_end_dt_sm_mo) as paid_prem_tl_cyc_end_dt_sm_mo
,sum(paid_prem_tl_cyc_end_dt) as paid_prem_tl_cyc_end_dt
,sum(total_paid_prem_aep) as total_paid_prem_aep
,sum(total_paid_prem_sm_mo) as total_paid_prem_sm_mo
,sum(total_paid_prem) as total_paid_prem
,sum(nblr_le_85) as nblr_le_85
,sum(nblr_gt_85_lt_150) as nblr_gt_85_lt_150
,sum(nblr_ge_150_lt_300) as nblr_ge_150_lt_300
,sum(nblr_ge_300) as nblr_ge_300
,sum(nblr_le_85_covid) as nblr_le_85_covid
,sum(nblr_gt_85_lt_150_covid) as nblr_gt_85_lt_150_covid
,sum(nblr_ge_150_lt_300_covid) as nblr_ge_150_lt_300_covid
,sum(nblr_ge_300_covid) as nblr_ge_300_covid
from IDENTIFIER(:V_AGENT_QUALITY_SALES_LR_SUMMARIZED_GS_PROFILE)
-- from ffp_agent_quality.sales_lr_summarized_gs_profile
  group by year) a
left join (select year as yr2
,sum(tot_annual_sales) as tot_annual_sales_prev
,sum(tot_online_sales) as tot_online_sales_prev
,sum(tot_electronic_web_enrol) as tot_electronic_web_enrol_prev
,sum(tot_web_enrol_sales) as tot_web_enrol_sales_prev
,sum(tot_dtc_ole_sales) as tot_dtc_ole_sales_prev
,sum(tot_paper_sales) as tot_paper_sales_prev
,sum(tot_others_sales) as tot_others_sales_prev
,sum(tot_aep_online_sales) as tot_aep_online_sales_prev
,sum(tot_aep_electronic_web_enrol) as tot_aep_electronic_web_enrol_prev
,sum(tot_aep_web_enrol_sales) as tot_aep_web_enrol_sales_prev
,sum(tot_aep_dtc_ole_sales) as tot_aep_dtc_ole_sales_prev
,sum(tot_aep_paper_sales) as tot_aep_paper_sales_prev
,sum(tot_aep_others_sales) as tot_aep_others_sales_prev
,sum(tot_sm_mo_online_sales) as tot_sm_mo_online_sales_prev
,sum(tot_sm_mo_electrnic_web_enrol) as tot_sm_mo_electrnic_web_enrol_prev
,sum(tot_sm_mo_web_enrol_sales) as tot_sm_mo_web_enrol_sales_prev
,sum(tot_sm_mo_dtc_ole_sales) as tot_sm_mo_dtc_ole_sales_prev
,sum(tot_sm_mo_paper_sales) as tot_sm_mo_paper_sales_prev
,sum(tot_sm_mo_others_sales) as tot_sm_mo_others_sales_prev
,sum(tot_aep_sales) as tot_aep_sales_prev
,sum(tot_same_mo_eff_sales) as tot_same_mo_eff_sales_prev
,sum(new_busins_claim_aep) as new_busins_claim_aep_prev
,sum(new_busins_claim_sm_mo) as new_busins_claim_sm_mo_prev
,sum(new_busins_claim) as new_busins_claim_prev
,sum(claim_amt_12months_aep) as claim_amt_12months_aep_prev
,sum(claim_amt_12months_sm_mo) as claim_amt_12months_sm_mo_prev
,sum(claim_amt_12months) as claim_amt_12months_prev
,sum(claim_till_cycle_end_dt_aep) as claim_till_cycle_end_dt_aep_prev
,sum(claim_till_cycle_end_dt_sm_mo) as claim_till_cycle_end_dt_sm_mo_prev
,sum(claim_till_cycle_end_dt) as claim_till_cycle_end_dt_prev
,sum(total_claim_aep) as total_claim_aep_prev
,sum(total_claim_sm_mo) as total_claim_sm_mo_prev
,sum(total_claim) as total_claim_prev
,sum(new_busins_claim_aep_covid_adj) as new_busins_claim_aep_covid_adj_prev
,sum(new_busins_claim_sm_mo_covid_adj) as new_busins_claim_sm_mo_covid_adj_prev
,sum(new_busins_claim_covid_adj) as new_busins_claim_covid_adj_prev
,sum(claim_12months_covid_aep) as claim_12months_covid_aep_prev
,sum(claim_12months_covid_sm_mo) as claim_12months_covid_sm_mo_prev
,sum(claim_12months_covid) as claim_12months_covid_prev
,sum(claim_tl_cyc_end_dt_covid_aep) as claim_tl_cyc_end_dt_covid_aep_prev
,sum(claim_tl_cyc_end_dt_covid_sm_mo) as claim_tl_cyc_end_dt_covid_sm_mo_prev
,sum(claim_tl_cyc_end_dt_covid) as claim_tl_cyc_end_dt_covid_prev
,sum(total_claim_covid_aep) as total_claim_covid_aep_prev
,sum(total_claim_covid_sm_mo) as total_claim_covid_sm_mo_prev
,sum(total_claim_covid) as total_claim_covid_prev
,sum(new_busins_prem_aep) as new_busins_prem_aep_prev
,sum(new_busins_prem_sm_mo) as new_busins_prem_sm_mo_prev
,sum(new_busins_prem) as new_busins_prem_prev
,sum(paid_prem_12months_aep) as paid_prem_12months_aep_prev
,sum(paid_prem_12months_sm_mo) as paid_prem_12months_sm_mo_prev
,sum(paid_prem_12months) as paid_prem_12months_prev
,sum(paid_prem_tl_cyc_end_dt_aep) as paid_prem_tl_cyc_end_dt_aep_prev
,sum(paid_prem_tl_cyc_end_dt_sm_mo) as paid_prem_tl_cyc_end_dt_sm_mo_prev
,sum(paid_prem_tl_cyc_end_dt) as paid_prem_tl_cyc_end_dt_prev
,sum(total_paid_prem_aep) as total_paid_prem_aep_prev
,sum(total_paid_prem_sm_mo) as total_paid_prem_sm_mo_prev
,sum(total_paid_prem) as total_paid_prem_prev
,sum(nblr_le_85) as nblr_le_85_prev
,sum(nblr_gt_85_lt_150) as nblr_gt_85_lt_150_prev
,sum(nblr_ge_150_lt_300) as nblr_ge_150_lt_300_prev
,sum(nblr_ge_300) as nblr_ge_300_prev
,sum(nblr_le_85_covid) as nblr_le_85_covid_prev
,sum(nblr_gt_85_lt_150_covid) as nblr_gt_85_lt_150_covid_prev
,sum(nblr_ge_150_lt_300_covid) as nblr_ge_150_lt_300_covid_prev
,sum(nblr_ge_300_covid) as nblr_ge_300_covid_prev
from IDENTIFIER(:V_AGENT_QUALITY_SALES_LR_SUMMARIZED_GS_PROFILE_BACKUP)
-- from ffp_agent_quality.sales_lr_summarized_gs_profile_backup 
group by year) b on a.yr1=b.yr2 ;

----------------------------------

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_AGENT_QC_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP43'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_PTY_LR_SMZD'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


----need to create at work schema
create or replace table IDENTIFIER(:V_AGENT_QUALITY_PTY_LR_SMZD) COPY GRANTS AS 
select pty_id,agt_id,principalparty_id_final,
substr(prem_due_mo_id,1,4) as year,
sum(case when month(eff_dt) = 01 then claim_amt_dec end ) as new_busins_claim_aep,
sum(case when month(eff_dt) <= (cast(concat(lpad(year(dateadd(month,-1,current_date)),4,0),lpad(month(dateadd(month,-1,current_date)),2,0)) as int)-substr(cast(concat(lpad(year(dateadd(month,-1,current_date)),4,0),lpad(month(dateadd(month,-1,current_date)),2,0)) as int),1,4)*100) then claim_amt_dec end ) as new_busins_claim_sm_mo,
sum(claim_amt_dec) as new_busins_claim,

sum(case when month(eff_dt) = 01 then claim_amt_12months end ) as claim_amt_12months_aep,
sum(case when month(eff_dt) <= (cast(concat(lpad(year(dateadd(month,-1,current_date)),4,0),lpad(month(dateadd(month,-1,current_date)),2,0)) as int)-substr(cast(concat(lpad(year(dateadd(month,-1,current_date)),4,0),lpad(month(dateadd(month,-1,current_date)),2,0)) as int),1,4)*100) then claim_amt_12months end ) as claim_amt_12months_sm_mo,
sum(claim_amt_12months) as claim_amt_12months,

sum(case when month(eff_dt) = 01 then claim_till_cycle_end_dt end ) as claim_till_cycle_end_dt_aep,
sum(case when month(eff_dt) <= (cast(concat(lpad(year(dateadd(month,-1,current_date)),4,0),lpad(month(dateadd(month,-1,current_date)),2,0)) as int)-substr(cast(concat(lpad(year(dateadd(month,-1,current_date)),4,0),lpad(month(dateadd(month,-1,current_date)),2,0)) as int),1,4)*100) then claim_till_cycle_end_dt end ) as claim_till_cycle_end_dt_sm_mo,
sum(claim_till_cycle_end_dt) as claim_till_cycle_end_dt,

sum(case when month(eff_dt) = 01 then total_claim end ) as total_claim_aep,
sum(case when month(eff_dt) <= (cast(concat(lpad(year(dateadd(month,-1,current_date)),4,0),lpad(month(dateadd(month,-1,current_date)),2,0)) as int)-substr(cast(concat(lpad(year(dateadd(month,-1,current_date)),4,0),lpad(month(dateadd(month,-1,current_date)),2,0)) as int),1,4)*100) then total_claim end ) as total_claim_sm_mo,
sum(total_claim) as total_claim,

sum(case when month(eff_dt) = 01 then claim_till_december_covid_adj end ) as new_busins_claim_aep_covid_adj,
sum(case when month(eff_dt) <= (cast(concat(lpad(year(dateadd(month,-1,current_date)),4,0),lpad(month(dateadd(month,-1,current_date)),2,0)) as int)-substr(cast(concat(lpad(year(dateadd(month,-1,current_date)),4,0),lpad(month(dateadd(month,-1,current_date)),2,0)) as int),1,4)*100) then claim_till_december_covid_adj end ) as new_busins_claim_sm_mo_covid_adj,
sum(claim_till_december_covid_adj) as new_busins_claim_covid_adj,

sum(case when month(eff_dt) = 01 then claim_12months_covid_adj end ) as claim_12months_covid_aep,
sum(case when month(eff_dt) <= (cast(concat(lpad(year(dateadd(month,-1,current_date)),4,0),lpad(month(dateadd(month,-1,current_date)),2,0)) as int)-substr(cast(concat(lpad(year(dateadd(month,-1,current_date)),4,0),lpad(month(dateadd(month,-1,current_date)),2,0)) as int),1,4)*100) then claim_12months_covid_adj end ) as claim_12months_covid_sm_mo,
sum(claim_12months_covid_adj) as claim_12months_covid,

sum(case when month(eff_dt) = 01 then claim_tl_cyc_end_dt_covid end ) as claim_tl_cyc_end_dt_covid_aep,
sum(case when month(eff_dt) <= (cast(concat(lpad(year(dateadd(month,-1,current_date)),4,0),lpad(month(dateadd(month,-1,current_date)),2,0)) as int)-substr(cast(concat(lpad(year(dateadd(month,-1,current_date)),4,0),lpad(month(dateadd(month,-1,current_date)),2,0)) as int),1,4)*100) then claim_tl_cyc_end_dt_covid end ) as claim_tl_cyc_end_dt_covid_sm_mo,
sum(claim_tl_cyc_end_dt_covid) as claim_tl_cyc_end_dt_covid,

sum(case when month(eff_dt) = 01 then total_claim_covid end ) as total_claim_covid_aep,
sum(case when month(eff_dt) <= (cast(concat(lpad(year(dateadd(month,-1,current_date)),4,0),lpad(month(dateadd(month,-1,current_date)),2,0)) as int)-substr(cast(concat(lpad(year(dateadd(month,-1,current_date)),4,0),lpad(month(dateadd(month,-1,current_date)),2,0)) as int),1,4)*100) then total_claim_covid end ) as total_claim_covid_sm_mo,
sum(total_claim_covid) as total_claim_covid,


sum(case when month(eff_dt) = 01 then paid_prem_dec end ) as new_busins_prem_aep,
sum(case when month(eff_dt) <= (cast(concat(lpad(year(dateadd(month,-1,current_date)),4,0),lpad(month(dateadd(month,-1,current_date)),2,0)) as int)-substr(cast(concat(lpad(year(dateadd(month,-1,current_date)),4,0),lpad(month(dateadd(month,-1,current_date)),2,0)) as int),1,4)*100) then paid_prem_dec end ) as new_busins_prem_sm_mo,
sum(paid_prem_dec) as new_busins_prem,

sum(case when month(eff_dt) = 01 then paid_prem_12months end ) as paid_prem_12months_aep,
sum(case when month(eff_dt) <= (cast(concat(lpad(year(dateadd(month,-1,current_date)),4,0),lpad(month(dateadd(month,-1,current_date)),2,0)) as int)-substr(cast(concat(lpad(year(dateadd(month,-1,current_date)),4,0),lpad(month(dateadd(month,-1,current_date)),2,0)) as int),1,4)*100) then paid_prem_12months end ) as paid_prem_12months_sm_mo,
sum(paid_prem_12months) as paid_prem_12months,

sum(case when month(eff_dt) = 01 then paid_prem_tl_cyc_end_dt end ) as paid_prem_tl_cyc_end_dt_aep,
sum(case when month(eff_dt) <= (cast(concat(lpad(year(dateadd(month,-1,current_date)),4,0),lpad(month(dateadd(month,-1,current_date)),2,0)) as int)-substr(cast(concat(lpad(year(dateadd(month,-1,current_date)),4,0),lpad(month(dateadd(month,-1,current_date)),2,0)) as int),1,4)*100) then paid_prem_tl_cyc_end_dt end ) as paid_prem_tl_cyc_end_dt_sm_mo,
sum(paid_prem_tl_cyc_end_dt) as paid_prem_tl_cyc_end_dt,

sum(case when month(eff_dt) = 01 then total_paid_prem end ) as total_paid_prem_aep,
sum(case when month(eff_dt) <= (cast(concat(lpad(year(dateadd(month,-1,current_date)),4,0),lpad(month(dateadd(month,-1,current_date)),2,0)) as int)-substr(cast(concat(lpad(year(dateadd(month,-1,current_date)),4,0),lpad(month(dateadd(month,-1,current_date)),2,0)) as int),1,4)*100) then total_paid_prem end ) as total_paid_prem_sm_mo,
sum(total_paid_prem) as total_paid_prem
from IDENTIFIER(:V_AGENT_QUALITY_ISDW_EFF_SALES_GS_V3)
where pty_id not in (''-1'',''-2'') 
and prem_due_mo_id <= cast(concat(lpad(year(dateadd(month,-3,current_date)),4,0),lpad(month(dateadd(month,-3,current_date)),2,0)) as int)
--and prem_due_mo_id <= cast(concat(lpad(year(${hivevar:CurrentDt}),4,0),lpad(month(${hivevar:CurrentDt})-3,2,0)) as int)
group by pty_id,agt_id,principalparty_id_final,
substr(prem_due_mo_id,1,4)
having count(pers_id) >= 1;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_PTY_LR_SMZD)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);





EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);


RAISE;

END;

';