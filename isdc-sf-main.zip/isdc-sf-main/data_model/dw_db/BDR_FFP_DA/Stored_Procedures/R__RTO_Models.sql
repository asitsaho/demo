--call SP_BASE_POPULATION('1234','RTO_MODELS','UBLIA_DEV_ISDC_DEV_DB','UTIL','BDR_FFP_DA','BDR_FFP_DA_WRK','BDR_SMART','BDR_CONF','UBLIA_DEV_WORK_XS_WH',CURRENT_DATE())
--call SP_BASE_POPULATION('1234','RTO_MODELS','UBLIA_TST_ISDC_DEV_DB','UTIL','BDR_FFP_DA','BDR_FFP_DA_WRK','BDR_SMART','BDR_CONF','UBLIA_TST_WORK_XS_WH',CURRENT_DATE())

USE SCHEMA BDR_FFP_DA;

CREATE OR REPLACE PROCEDURE BDR_FFP_DA.SP_BASE_POPULATION("PIPELINE_ID" VARCHAR(16777216), "PIPELINE_NAME" VARCHAR(16777216), "DB_NAME" VARCHAR(16777216), "UTIL_SC" VARCHAR(16777216), "TGT_SC" VARCHAR(16777216), "FFP_WRK_SC" VARCHAR(16777216), "SRC_SC" VARCHAR(16777216), "ONE_SC" VARCHAR(16777216), "WH" VARCHAR(16777216), "CURR_DATE" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

V_CURRENT_DATE   DATE := COALESCE(TO_DATE(:CURR_DATE), CURRENT_DATE());

V_ACTUAL_DROP_DATE DATE := (SELECT TO_CHAR( DATEADD(DAY, -1, TO_DATE(:V_CURRENT_DATE)),''YYYY-MM-DD''));



V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := :DB_NAME||''.''||COALESCE(:UTIL_SC, ''UTIL'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';

V_PROCESS_NAME   VARCHAR DEFAULT ''RTO MODELS'';

V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''BASE_POPULATION/C0DE1-CODE5'';

V_STEP             VARCHAR;

V_STEP_NAME        VARCHAR;

V_START_TIME       VARCHAR;

V_END_TIME         VARCHAR;

V_ROWS_PARSED       INTEGER;

V_ROWS_LOADED       INTEGER;

V_MESSAGE          VARCHAR;

V_LAST_QUERY_ID    VARCHAR;

V_SQL_QUERY VARCHAR;



V_APPLICATION VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.APPLICATION'';

V_INSURED_PLAN VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.INSURED_PLAN'';

V_SPECIFICATION VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.SPECIFICATION'';

V_PERSON_ADDRESS_PROFILE VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.PERSON_ADDRESS_PROFILE'';

V_SHIP_PERSON_XREF VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.SHIP_PERSON_XREF'';

V_D_MBR_INFO VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''BDR_CONF'') || ''.D_MBR_INFO'';

--Second Script Tables
V_AMERILINK_DATA VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.AMERILINK_DATA '';

V_APPLICATION_REPORTING VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.APPLICATION_REPORTING'';

--Third Script Tables

V_PERSON_POLICY_PROFILE VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.PERSON_POLICY_PROFILE'';

--4th Script Tables
V_PERSON VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.PERSON '';

--Intermediate Tables

V_FFP_EFT_MEDSUPP_PRIV_SYS_01 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_MEDSUPP_PRIV_PRIV_SS_01'';
V_FFP_EFT_MEDSUPP_PRIV_SYS VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_MEDSUPP_PRIV_PRIV_SS'';
V_FFP_EFT_MEDSUPP_PRIV_SYS_BASE1_01 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_MEDSUPP_PRIV_PRIV_SS_BASE1_01'';
V_FFP_EFT_MEDSUPP_PRIV_SYS_BASE1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_MEDSUPP_PRIV_PRIV_SS_BASE1'';
V_FFP_EFT_MATCH_PT VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_MATCH_PT'';
V_FFP_EFT_PERS_ID VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PERS_ID'';
V_FFP_EFT_PULL_D_ACCOUNT VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PULL_D_ACCOUNT'';
V_FFP_EFT_BASE_POP_SYS VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_BASE_POP_PRIV_SS'';

 
--Second Script Tables
V_FFP_EFT_PULL_AMERILINK VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PULL_AMERILINK'';
V_FFP_EFT_PULL_AMERILINK_SYS VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PULL_AMERILINK_PRIV_SS'';
V_FFP_EFT_PULL_APP_REPORTING VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PULL_APP_REPORTING'';
V_FFP_EFT_APP_REPORTING_BASEPOP_SYS VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_APP_REPORTING_BASEPOP_PRIV_SS'';

--Third Script Tables
V_EFT_PULL_PERSON_PROF_SYS VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PULL_PERSON_PROF_PRIV_SS'';

--4th Script Tables
V_EFT_EFT_PULL_PERSON_SYS VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PULL_PERSON_PRIV_SS'';

--5th Script Tables
V_EFT_EFT_PULL_INSPLAN VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PULL_INSPLAN'';
V_EFT_PULL_INSPLAN_SPECIFICATION VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PULL_INSPLAN_SPECIFICATION'';

V_EFT_EFT_PULL_INSPLAN_SPECIFICATION_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PULL_INSPLAN_SPECIFICATION_1'';
V_EFT_PULL_INSPLAN_SPEC_2_SYS_01 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PULL_INSPLAN_SPEC_2_PRIV_SS_01'';
V_EFT_PULL_INSPLAN_SPEC_2_SYS VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PULL_INSPLAN_SPEC_2_PRIV_SS'';




BEGIN


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP1'';

V_STEP_NAME :=  ''create a table FFP_EFT_MEDSUPP_PRIV_SYS_01'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_FFP_EFT_MEDSUPP_PRIV_SYS_01) as
select a.person_id,
a.insured_plan_id,
a.specification_id,
a.PLAN_TERMINATION_REASON_CODE,
b.application_id,
b.APPL_RECEIPT_DATE,
b.ADJUDICATION_DATE,
b.REQUESTED_EFFECTIVE_DATE,
a.EFFECTIVE_DATE,
a.termination_date,
b.REQUESTED_PLAN_CODE_1,
b.REQUESTED_PLAN_CODE_2,
b.AARP_ACQUISITION_STATUS_ID,
b.MSUP_INSURED_STATUS_CODE,
c.PRODUCT_TYPE_CODE,
c.spec_type_code,
c.plan_code,
d.state_code,
d.begin_date,
d.end_date
from IDENTIFIER(:V_INSURED_PLAN) a
inner join IDENTIFIER(:v_APPLICATION) b
on a.person_id=b.person_id 
and a.application_id=b.application_id 
inner join IDENTIFIER(:V_SPECIFICATION) c
on a.specification_id=c.specification_id 
inner join IDENTIFIER(:V_PERSON_ADDRESS_PROFILE) d
on a.person_id = d.person_id
where trim(product_type_code) = ''M''
and trim(spec_type_code) = ''B''
and (a.EFFECTIVE_DATE<= :V_ACTUAL_DROP_DATE and (a.termination_date is null or a.termination_date > :V_ACTUAL_DROP_DATE));



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_FFP_EFT_MEDSUPP_PRIV_SYS_01)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP2'';

V_STEP_NAME :=  ''create a table FFP_EFT_MEDSUPP_PRIV_SYS'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_FFP_EFT_MEDSUPP_PRIV_SYS) as
select  distinct a.person_id,
a.insured_plan_id,
a.specification_id,
a.PLAN_TERMINATION_REASON_CODE,
a.application_id,
a.APPL_RECEIPT_DATE,
a.ADJUDICATION_DATE,
a.REQUESTED_EFFECTIVE_DATE,
a.EFFECTIVE_DATE,
a.termination_date,
a.REQUESTED_PLAN_CODE_1,
a.REQUESTED_PLAN_CODE_2,
a.AARP_ACQUISITION_STATUS_ID,
a.MSUP_INSURED_STATUS_CODE,
a.PRODUCT_TYPE_CODE,
a.spec_type_code,
a.plan_code,
a.state_code,
a.begin_date,
a.end_date, b.shiP_person_id as individual_id 
from  IDENTIFIER(:V_FFP_EFT_MEDSUPP_PRIV_SYS_01) a
left join IDENTIFIER(:V_SHIP_PERSON_XREF) b
on  a.person_id = b.person_id ;



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_FFP_EFT_MEDSUPP_PRIV_SYS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP3'';

V_STEP_NAME :=  ''create a table FFP_EFT_MEDSUPP_PRIV_SYS_BASE1_01'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_FFP_EFT_MEDSUPP_PRIV_SYS_BASE1_01) as
select * 
from
(select *,ROW_NUMBER() OVER (PARTITION BY PERSON_ID order by effective_date desc , termination_date desc , begin_date desc , end_date desc ) AS ROW_NUM from IDENTIFIER(:V_FFP_EFT_MEDSUPP_PRIV_SYS)) as a where a.row_num=1;



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_FFP_EFT_MEDSUPP_PRIV_SYS_BASE1_01)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP4'';

V_STEP_NAME :=  ''create a table FFP_EFT_MEDSUPP_PRIV_SYS_BASE1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_FFP_EFT_MEDSUPP_PRIV_SYS_BASE1) as
select * , :V_ACTUAL_DROP_DATE as actual_drop_date
from IDENTIFIER(:V_FFP_EFT_MEDSUPP_PRIV_SYS_BASE1_01);



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_FFP_EFT_MEDSUPP_PRIV_SYS_BASE1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP5'';

V_STEP_NAME :=  ''create a table FFP_EFT_MATCH_PT'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_FFP_EFT_MATCH_PT) as
select  distinct a.person_id,a.actual_drop_date, b.shiP_person_id as individual_id 
from IDENTIFIER(:V_FFP_EFT_MEDSUPP_PRIV_SYS_BASE1) a
left join IDENTIFIER(:V_SHIP_PERSON_XREF) b
on a.person_id = b.person_id ;



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_FFP_EFT_MATCH_PT)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

V_STEP := ''STEP6'';

V_STEP_NAME :=  ''create a table FFP_EFT_PERS_ID'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_FFP_EFT_PERS_ID) as
select distinct individual_id
from IDENTIFIER(:V_FFP_EFT_MATCH_PT)
where individual_id is not null;




V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_FFP_EFT_PERS_ID)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP7'';

V_STEP_NAME :=  ''create a table FFP_EFT_PULL_D_ACCOUNT'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_FFP_EFT_PULL_D_ACCOUNT) as
select distinct a.individual_id,b.ACCT_NBR as account_number,b.ST_CD as state_code
from IDENTIFIER(:V_FFP_EFT_PERS_ID) a inner join IDENTIFIER(:V_D_MBR_INFO) b
on a.individual_id=b.INDV_ID;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_FFP_EFT_PULL_D_ACCOUNT)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP8'';

V_STEP_NAME :=  ''create a table FFP_EFT_BASE_POP_SYS'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_FFP_EFT_BASE_POP_SYS) as
select distinct a.person_id,a.actual_drop_date, a.individual_id , b.account_number
from IDENTIFIER(:V_FFP_EFT_MATCH_PT) a 
left join IDENTIFIER(:V_FFP_EFT_PULL_D_ACCOUNT) b
on   a.individual_id = b.INDIVIDUAL_ID;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_FFP_EFT_BASE_POP_SYS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


-- Second Script Code 1
V_STEP := ''STEP9'';

V_STEP_NAME :=  ''create a table FFP_EFT_PULL_AMERILINK'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


--create or replace table IDENTIFIER(:V_FFP_EFT_PULL_AMERILINK) as
--select distinct b.person_id,b.individual_id,b.actual_drop_date,
--case when a.FAMP='''' then null else a.FAMP end as FAMP,
--case when a.IOLA='''' then null else a.IOLA end as IOLA,
--case when a.ONLA='''' then null else a.ONLA end as ONLA,
--case when a.RET='''' then null else a.RET end as RET,
--case when a.orac='''' then null else a.orac end as orac,
--case when a.AALZ='''' then null else a.AALZ end as AALZ,
--case when a.AASM='''' then null else a.AASM end as AASM,
--case when a.ABCE='''' then null else a.ABCE end as ABCE,
--case when a.ADBT='''' then null else a.ADBT end as ADBT,
--case when a.AGRESP='''' then null else a.AGRESP end as AGRESP,
--case when a.AHBP='''' then null else a.AHBP end as AHBP,
--case when a.AHRT='''' then null else a.AHRT end as AHRT,
--case when a.ALNG='''' then null else a.ALNG end as ALNG,
--case when a.ARES='''' then null else a.ARES end as ARES,
--case when a.BC='''' then null else a.BC end as BC,
--case when a.HHCOMP='''' then null else a.HHCOMP end as HHCOMP,
--case when a.HOMVAL='''' then null else a.HOMVAL end as HOMVAL,
--case when a.HOMSTAT='''' then null else a.HOMSTAT end as HOMSTAT,
--case when a.NAH19='''' then null else a.NAH19 end as NAH19,
--case when a.NPH19='''' then null else a.NPH19 end as NPH19,
--case when a.NOC19='''' then null else a.NOC19 end as NOC19,
--case when a.POC19='''' then null else a.POC19 end as POC19,
--case when a.NETW19='''' then null else a.NETW19 end as NETW19,
--case when a.PWHEELCH='''' then null else a.PWHEELCH end as PWHEELCH,
--case when a.ESTINC19='''' then null else a.ESTINC19 end as ESTINC19,
--case when a.MR='''' then null else a.MR end as MR,
--case when a.VERI='''' then null else a.VERI  end as VERI
--from IDENTIFIER(:V_AMERILINK_DATA) a inner join IDENTIFIER(:V_FFP_EFT_BASE_POP_SYS) b
--on a.person_id=b.person_id;

create or replace table IDENTIFIER(:V_FFP_EFT_PULL_AMERILINK) as
select distinct b.person_id,b.individual_id,b.actual_drop_date,
case when a.FAMP  is null then null else a.FAMP end as FAMP,
case when a.IOLA is null then null else a.IOLA end as IOLA,
case when a.ONLA is null then null else a.ONLA end as ONLA,
case when a.RET is null then null else a.RET end as RET,
case when a.orac is null then null else a.orac end as orac,
case when a.AALZ is null then null else a.AALZ end as AALZ,
case when a.AASM is null then null else a.AASM end as AASM,
case when a.ABCE is null then null else a.ABCE end as ABCE,
case when a.ADBT is null then null else a.ADBT end as ADBT,
case when a.AGRESP is null then null else a.AGRESP end as AGRESP,
case when a.AHBP is null then null else a.AHBP end as AHBP,
case when a.AHRT is null then null else a.AHRT end as AHRT,
case when a.ALNG is null then null else a.ALNG end as ALNG,
case when a.ARES is null then null else a.ARES end as ARES,
case when a.BC is null then null else a.BC end as BC,
case when a.HHCOMP is null then null else a.HHCOMP end as HHCOMP,
case when a.HOMVAL is null then null else a.HOMVAL end as HOMVAL,
case when a.HOMSTAT is null then null else a.HOMSTAT end as HOMSTAT,
case when a.NAH19 is null then null else a.NAH19 end as NAH19,
case when a.NPH19 is null then null else a.NPH19 end as NPH19,
case when a.NOC19 is null then null else a.NOC19 end as NOC19,
case when a.POC19 is null then null else a.POC19 end as POC19,
case when a.NETW19 is null then null else a.NETW19 end as NETW19,
case when a.PWHEELCH is null then null else a.PWHEELCH end as PWHEELCH,
case when a.ESTINC19 is null then null else a.ESTINC19 end as ESTINC19,
case when a.MR is null then null else a.MR end as MR,
case when a.VERI is null then null else a.VERI  end as VERI
from IDENTIFIER(:V_AMERILINK_DATA) a inner join IDENTIFIER(:V_FFP_EFT_BASE_POP_SYS) b
on a.person_id=b.person_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_FFP_EFT_PULL_AMERILINK)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP10'';

V_STEP_NAME :=  ''create a table FFP_EFT_PULL_AMERILINK_SYS'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_FFP_EFT_PULL_AMERILINK_SYS) as
select * ,
case when (FAMP = ''B'' or FAMP = ''C'' or FAMP = ''G'' or FAMP = ''M'') then 1 else 0 end as FAMP_BCGM,
case when (FAMP = ''F'') then 1 else 0 end as FAMP_F,
case when (FAMP = ''H'' ) then 1 else 0 end as FAMP_H,
CASE WHEN (FAMP = ''P'' or FAMP = ''S'' or FAMP = ''W'') THEN 1 else 0 end as FAMP_PSW,
case when BC=''M'' then 1 else 0 end as Bank_Card_Multiple,
case when BC = ''Y'' then 1 else 0 end as Bank_Card_Single,
case when HOMSTAT= ''Y'' then 1 else 0 end as homeowner_fg,
case when POC19= ''Y'' then 1 else 0 end as Children_present,
case 
when NETW19 = ''A'' THEN 15000
when NETW19 = ''B'' THEN 37500
when NETW19 = ''C'' THEN 62500
when NETW19 = ''D'' THEN 87500
when NETW19 = ''E'' THEN 125000
when NETW19 = ''F'' THEN 200000
when NETW19 = ''G'' THEN 375000
when NETW19 = ''H'' THEN 625000
when NETW19 = ''I'' THEN 875000
when NETW19 = ''J'' THEN 1250000
end as networth,
case 
when ESTINC19 = ''A'' THEN 10000
when ESTINC19 = ''B'' THEN 17500
when ESTINC19 = ''C'' THEN 25000
when ESTINC19 = ''D'' THEN 35000
when ESTINC19 = ''E'' THEN 45000
when ESTINC19 = ''F'' THEN 55000
when ESTINC19 = ''G'' THEN 67500
when ESTINC19 = ''H'' THEN 87500
when ESTINC19 = ''I'' THEN 112500
when ESTINC19 = ''J'' THEN 137500
when ESTINC19 = ''K'' THEN 200000
when ESTINC19 = ''L'' THEN 300000
end as income,
case when MR = ''M'' THEN 1 else 0 end as MR_M,
case when MR = ''Y'' THEN 1 else 0 end as MR_Y,
case when HHCOMP = ''A'' THEN 1 else 0 end as married_with_children,
case when HHCOMP = ''B'' THEN 1 else 0 end as married_No_children,
case when HHCOMP = ''J'' THEN 1 else 0 end as Male_with_No_children,
case when HHCOMP = ''L'' THEN 1 else 0 end as Female_with_No_children
from IDENTIFIER(:V_FFP_EFT_PULL_AMERILINK);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_FFP_EFT_PULL_AMERILINK_SYS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

-- Second Script Code 2  ROW_NUM Needs to be modified in Step 12

V_STEP := ''STEP11'';

V_STEP_NAME :=  ''create a table FFP_EFT_PULL_APP_REPORTING'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_FFP_EFT_PULL_APP_REPORTING) as
select distinct a.person_id,a.individual_id,a.actual_drop_date,b.application_id,b.appl_receipt_date, b.adjudication_date,
UTIL.DATE_DIFF_UDF(adjudication_date,appl_receipt_date) as application_processing_time
from IDENTIFIER(:V_APPLICATION_REPORTING) b inner join IDENTIFIER(:V_FFP_EFT_BASE_POP_SYS) a
on b.person_id=a.person_id
where a.actual_drop_date > b.appl_receipt_date
order by person_id, actual_drop_date, appl_receipt_date;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_FFP_EFT_PULL_APP_REPORTING)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

V_STEP := ''STEP12'';

V_STEP_NAME :=  ''create a table FFP_EFT_APP_REPORTING_BASEPOP_SYS'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_FFP_EFT_APP_REPORTING_BASEPOP_SYS) as
select * 
from
(select *,ROW_NUMBER() OVER (PARTITION BY PERSON_ID order by actual_drop_date desc, appl_receipt_date desc ,application_id desc, adjudication_date desc , application_processing_time desc) AS ROW_NUM from IDENTIFIER(:V_FFP_EFT_PULL_APP_REPORTING)) as a where a.row_num=1;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_FFP_EFT_APP_REPORTING_BASEPOP_SYS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

--/*------------------PERSON_POLICY_PROFILE---------------CODE-3*/

V_STEP := ''STEP13'';

V_STEP_NAME :=  ''create a table EFT_PULL_PERSON_PROF_SYS'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EFT_PULL_PERSON_PROF_SYS) as
select distinct person_id,MSUP_NUM_LAPSES,MSUP_NUM_PLAN_CHANGES,MSUP_ACTIVE_PROD_DURATION,MSUP_RATE_DETERMINATION_CODE
from IDENTIFIER(:V_PERSON_POLICY_PROFILE)
where person_id in (select distinct person_id from IDENTIFIER(:V_FFP_EFT_BASE_POP_SYS));


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EFT_PULL_PERSON_PROF_SYS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

--/*------------------PERSON---------------CODE-4*/

V_STEP := ''STEP14'';

V_STEP_NAME :=  ''create a table EFT_EFT_PULL_PERSON_SYS'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EFT_EFT_PULL_PERSON_SYS) as
select distinct c.person_id,c.individual_id,c.actual_drop_date,GENDER_CODE,birth_date
from IDENTIFIER(:V_PERSON) b inner join IDENTIFIER(:V_FFP_EFT_BASE_POP_SYS) c
on b.person_id=c.person_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EFT_EFT_PULL_PERSON_SYS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

--/*------------------INSURED_PLAN + SPECIFICATION---------------CODE-4*/

V_STEP := ''STEP15'';

V_STEP_NAME :=  ''create a table EFT_EFT_PULL_INSPLAN'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EFT_EFT_PULL_INSPLAN) as
select distinct b.person_id,b.individual_id,b.actual_drop_date,INDIVIDUAL_PREMIUM_AMOUNT,EMPLOYER_PREMIUM_AMOUNT,
effective_date as plan_effective_date,
termination_date as plan_Termination_date,
specification_id,INSURED_PLAN_ID,Ins_Plan_Switcher_Ind,LANGUAGE_PREFERENCE_ID
from IDENTIFIER(:V_FFP_EFT_BASE_POP_SYS) b inner join IDENTIFIER(:V_INSURED_PLAN) c
on b.person_id=c.person_id
where (effective_date <= b.actual_drop_date) and (termination_date is null or termination_date >= b.actual_drop_date);

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EFT_EFT_PULL_INSPLAN)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP16'';

V_STEP_NAME :=  ''create a table EFT_PULL_INSPLAN_SPECIFICATION'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EFT_PULL_INSPLAN_SPECIFICATION) as
select distinct 
b.person_id,
b.individual_id,
b.actual_drop_date,
b.INDIVIDUAL_PREMIUM_AMOUNT,
b.EMPLOYER_PREMIUM_AMOUNT,
b.plan_effective_date,
b.plan_Termination_date,
b.specification_id,
b.INSURED_PLAN_ID,
b.Ins_Plan_Switcher_Ind,
b.LANGUAGE_PREFERENCE_ID,a.specification_name,a.product_type_var,a.plan_code,a.PRODUCT_SECONDARY_VAR_CODE,a.PRODUCT_TYPE_CODE
from IDENTIFIER(:V_EFT_EFT_PULL_INSPLAN) b
left join IDENTIFIER(:V_SPECIFICATION) a 
on b.specification_id=a.specification_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EFT_PULL_INSPLAN_SPECIFICATION)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP17'';

V_STEP_NAME :=  ''create a table EFT_EFT_PULL_INSPLAN_SPECIFICATION_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EFT_EFT_PULL_INSPLAN_SPECIFICATION_1) as
select * from IDENTIFIER(:V_EFT_PULL_INSPLAN_SPECIFICATION)
order by person_id, actual_drop_date, plan_effective_date;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EFT_EFT_PULL_INSPLAN_SPECIFICATION_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

V_STEP := ''STEP18'';

V_STEP_NAME :=  ''create a table EFT_PULL_INSPLAN_SPEC_2_SYS_01'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EFT_PULL_INSPLAN_SPEC_2_SYS_01) as
select * from IDENTIFIER(:V_EFT_EFT_PULL_INSPLAN_SPECIFICATION_1)
order by person_id, actual_drop_date, plan_effective_date;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EFT_PULL_INSPLAN_SPEC_2_SYS_01)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

V_STEP := ''STEP19'';

V_STEP_NAME :=  ''create a table EFT_PULL_INSPLAN_SPEC_2_SYS'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EFT_PULL_INSPLAN_SPEC_2_SYS) as
select * EXCLUDE ROW_NUM
from
(select *,ROW_NUMBER() OVER (PARTITION BY PERSON_ID order by actual_drop_date desc , plan_effective_date desc , INDIVIDUAL_PREMIUM_AMOUNT desc ,EMPLOYER_PREMIUM_AMOUNT desc , specification_id desc ,INSURED_PLAN_ID desc ,plan_code desc  ) AS ROW_NUM from IDENTIFIER(:V_EFT_PULL_INSPLAN_SPEC_2_SYS_01)) as a where a.row_num=1;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EFT_PULL_INSPLAN_SPEC_2_SYS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);


RAISE;

END;

';