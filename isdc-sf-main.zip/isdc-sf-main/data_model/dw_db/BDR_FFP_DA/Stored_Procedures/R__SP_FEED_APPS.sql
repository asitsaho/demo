USE SCHEMA BDR_FFP_DA;


CREATE OR REPLACE PROCEDURE BDR_FFP_DA.SP_FEED_APPS("PIPELINE_ID" VARCHAR(16777216), "PIPELINE_NAME" VARCHAR(16777216), "DB_NAME" VARCHAR(16777216), "UTIL_SC" VARCHAR(16777216), "TGT_SC" VARCHAR(16777216), "FFP_WRK_SC" VARCHAR(16777216), "SRC_SC" VARCHAR(16777216), "ONE_SC" VARCHAR(16777216), "WH" VARCHAR(16777216), "CURR_DATE" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

V_CURRENT_DATE   DATE := COALESCE(TO_DATE(:CURR_DATE), CURRENT_DATE());

--V_SECOND_DATE DATE := ''''''''||''2019-10-01''||'''''''';
V_SECOND_DATE DATE := ''2019-10-01'';
V_PREV_YEAR_FIRST_DATE DATE := (SELECT DATE_TRUNC(''YEAR'', DATEADD(YEAR, -1, CURRENT_DATE)));



V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := :DB_NAME||''.''||COALESCE(:UTIL_SC, ''UTIL'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';

V_PROCESS_NAME   VARCHAR DEFAULT ''PRODUCT_SWITCHER'';

V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''FEED APPS'';

V_STEP             VARCHAR;

V_STEP_NAME        VARCHAR;

V_START_TIME       VARCHAR;

V_END_TIME         VARCHAR;

V_ROWS_PARSED       INTEGER;

V_ROWS_LOADED       INTEGER;

V_MESSAGE          VARCHAR;

V_LAST_QUERY_ID    VARCHAR;

V_SQL_QUERY    VARCHAR;


V_ALL_APPS_FEDERAL VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''SRC_UCEE'') || ''.ALL_APPS_FEDERAL'';
V_MBR_PLAN VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''FILL DEFAULT VALUE'') || ''.MBR_PLAN'';
V_INSURED_PLAN VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.INSURED_PLAN'';
V_SPECIFICATION VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.SPECIFICATION'';
V_PERSON VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.PERSON'';
V_CMDB_SMART_PERSON_PROFILE VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.CMDB_SMART_PERSON_PROFILE'';
V_APPLICATION VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.APPLICATION'';
V_SHIP_PERSON_XREF VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.SHIP_PERSON_XREF'';
V_PERSON_COMPAS_DAILY_SNAPSHOT_DECRYPT VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_sC, ''BDR_SMART'') || ''.PERSON_COMPAS_DAILY_SNAPSHOT'';
V_AMERILINK_DATA VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.AMERILINK_DATA'';
V_PERSON_ADDRESS_HHOLD_PROFILE  VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.PERSON_ADDRESS_HHOLD_PROFILE'';
V_CMS_HICN_TO_MBI_CROSSWALK  VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''SRC_UCEE'') || ''.CMS_HICN_TO_MBI_CROSSWALK'';


--Need To check Table Schemas
V_MBR VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''SRC_UCEE'') || ''.MBR'';
V_PLAN VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''SRC_UCEE'') || ''.PLAN'';
V_PLAN_CAT VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''SRC_UCEE'') || ''.PLAN_CAT'';
V_LOB VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''SRC_UCEE'') || ''.LOB'';
V_INDVDL VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''SRC_UCEE'') || ''.INDVDL'';
V_INDVDL_EXT VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''SRC_UCEE'') || ''.INDVDL_EXT'';
V_ELGBLTY_GROUP VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''SRC_UCEE'') || ''.ELGBLTY_GROUP'';


--Intermediate Tables
V_APPS  VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.PROD_SWITCH_APPS '';
V_APPS1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.PROD_SWITCH_APPS1'';
V_FED_MBRSHIP VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.PROD_SWITCH_FED_MBRSHIP'';
V_FED_MBRSHIP1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.PROD_SWITCH_FED_MBRSHIP1'';
V_FED_MBRSHIP2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.PROD_SWITCH_FED_MBRSHIP2'';
V_FED_MBRSHIP3 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.PROD_SWITCH_FED_MBRSHIP3'';
V_FED_MBRSHIP4 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.PROD_SWITCH_FED_MBRSHIP4'';
V_MS_MBR VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.PROD_SWITCH_MS_MBR'';
V_MS_MBR1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.PROD_SWITCH_MS_MBR1'';
V_MS_FED_MBR VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.PROD_SWITCH_MS_FED_MBR'';
V_MS_FED_MBR1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.PROD_SWITCH_MS_FED_MBR1'';
V_MS_FED_MBR2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.PROD_SWITCH_MS_FED_MBR2'';
V_MS_FED_MBR3  VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.PROD_SWITCH_MS_FED_MBR3 '';
V_MS_FED_MBR4  VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.PROD_SWITCH_MS_FED_MBR4 '';
V_APP_MBR_APLDT VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.PROD_SWITCH_APP_MBR_APLDT'';
V_APP_MBR_APLDT1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.PROD_SWITCH_APP_MBR_APLDT1'';
V_APP_MBR_APLDT2  VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.PROD_SWITCH_APP_MBR_APLDT2 '';
V_APP_MBR_APLDT3 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.PROD_SWITCH_APP_MBR_APLDT3'';
V_FED_APP_PRODSWTCH_APPLDT VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.PROD_SWITCH_FED_APP_PRODSWTCH_APPLDT'';

V_QC_REPORT VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.PROD_SWITCH_QC_REPORT'';


BEGIN

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP1'';

V_STEP_NAME :=  ''create a table APPS'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

-- Select all data from apps adhoc 2020 and 2021 tables
--all_apps_federal refresh daily

create or replace  table IDENTIFIER(:V_APPS) as
select * from IDENTIFIER(:V_ALL_APPS_FEDERAL)
where year > ''2015'';


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_APPS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP2'';

V_STEP_NAME :=  ''create a table EFT_SCORE2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

-- convert INSTITUTIONAL and ERICKSON segments to ''MA INDIVIDUAL''
create or replace  table IDENTIFIER(:V_APPS1) as
select *, case when product_segments in (''INSTITUTIONAL'',''ERICKSON'') then ''MA INDIVIDUAL''
else product_segments end as product_segments1
from IDENTIFIER(:V_APPS);

-- Pull the Federal membership

create or replace  table IDENTIFIER(:V_FED_MBRSHIP) as
select a.medicare_hicn_cd as mbi_1
,b.indvdl_id
,a.mbr_plan_eff_dt
,a.dsenrl_dt
,a.orig_mbr_eff_dt
,c.prod_id
,a.subsidy_lvl_id
,a.plan_cd
,a.group_ind_cd
,c.lob_id
,a.assigned_medicaid_fg
,d.sh_mbr_fg
,d.pdp_mbr_fg
,d.evc_mbr_fg
,d.amc_mbr_fg
,b.mbr_dob as dob
,e.st_cd as State_fed
,a.contract_id_cd
,c.plan_cat_id
,pc.PLAN_CAT_NM
,eg.elgblty_Group_TYPE_cd
,e.gender_cd as Gender_fd
,a.appl_id_cd -- added later
from IDENTIFIER(:V_MBR_PLAN) a
left join IDENTIFIER(:V_MBR) b on a.mbr_id_cd=b.mbr_id_cd and a.src_sys_srcid=b.src_sys_srcid
left join IDENTIFIER(:V_PLAN) c on a.plan_cd=c.plan_cd and a.src_sys_srcid=c.src_sys_srcid
left join IDENTIFIER(:V_PLAN_CAT) pc on pc.plan_cat_id  = c.plan_cat_id
left join IDENTIFIER(:V_LOB) d on c.lob_id=d.lob_id
left join IDENTIFIER(:V_INDVDL) e on b.indvdl_id=e.indvdl_id
left join IDENTIFIER(:V_INDVDL_EXT) ie on e.indvdl_id = ie.indvdl_id
left join IDENTIFIER(:V_ELGBLTY_GROUP) eg on a.elgblty_sys_group_num_cd = eg.elgblty_sys_group_num_cd
--where (a.dsenrl_dt='''' or a.dsenrl_dt is null or a.dsenrl_dt >= :V_SECOND_DATE) and -- Changed By Srikanth (a.dsenrl_dt is null)
where (a.dsenrl_dt is null or a.dsenrl_dt is null or cast(a.dsenrl_dt as date) >= :V_SECOND_DATE) and
(d.sh_mbr_fg = ''Y'' or d.pdp_mbr_fg = ''Y'' or d.evc_mbr_fg = ''Y'' or d.amc_mbr_fg = ''Y'');


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_FED_MBRSHIP)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



V_STEP := ''STEP3'';

V_STEP_NAME :=  ''create a table FED_MBRSHIP1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace  table IDENTIFIER(:V_FED_MBRSHIP1) as
select a.*, b.mbi as mbi_2,
case when b.mbi is null then a.mbi_1 else b.mbi end as mbi
from IDENTIFIER(:V_FED_MBRSHIP) a
left join IDENTIFIER(:V_CMS_HICN_TO_MBI_CROSSWALK) b
on a.mbi_1 = b.medicare_hicn_cd;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_FED_MBRSHIP1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP4'';

V_STEP_NAME :=  ''create a table FED_MBRSHIP2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace  table IDENTIFIER(:V_FED_MBRSHIP2) as
select *,
case when (((sh_mbr_fg = ''Y'' and prod_id in(2051)) or evc_mbr_fg = ''Y'' and prod_id in(2051))
and lob_id not in (10,911) and substr(contract_id_cd, 7, 1) <> ''8''
and plan_cat_nm = ''MAPD'' and prod_id in(2051)) then ''MAPD SNP''

when (((sh_mbr_fg = ''Y'' and prod_id in(2051)) or evc_mbr_fg = ''Y'' and prod_id in(2051))
and lob_id not in (10,911) and substr(contract_id_cd, 7, 1) <> ''8''
and plan_cat_nm = ''MA ONLY'' and prod_id in(2051)) then ''MA SNP''

when (((sh_mbr_fg = ''Y'' and prod_id in(28,2053,2054,27,2004,2001,2005,2029,2034,15,30,37,2082,2069, 2083,2084,5,25,2062,2050,2052))
or evc_mbr_fg = ''Y'' and prod_id not in(2051))
and lob_id not in (10,911) and substr(contract_id_cd, 7, 1) <> ''8''
and plan_cat_nm = ''MA ONLY'' ) then ''MA Indv''

when (((sh_mbr_fg = ''Y'' and prod_id in(28,2053,2054,27,2004,2001,2005,2029,2034,15,30,37,2082,2069, 2083,2084,5,25,2062,2050,2052))
or evc_mbr_fg = ''Y'' and prod_id not in(2051))
and lob_id not in (10,911) and substr(contract_id_cd, 7, 1) <> ''8''
and plan_cat_nm = ''MAPD'' ) then ''MAPD Indv''

when ( pdp_mbr_fg = ''Y'' and plan_cd <> ''O'' and plan_cat_nm = ''PDP''
and (substr(contract_id_cd, 7, 1) = ''8'' or elgblty_Group_TYPE_cd in (''800 SERIES CUSTOM'', ''EMPLOYER'',''800 SERIES REGULAR'')))
then ''PDP Group''

when ( pdp_mbr_fg = ''Y'' and plan_cd <> ''O'' and plan_cat_nm = ''PDP''
and (substr(contract_id_cd, 7, 1) <> ''8''
or elgblty_Group_TYPE_cd not in (''800 SERIES CUSTOM'', ''EMPLOYER'',''800 SERIES REGULAR''))) then ''PDP Indv''
when (((sh_mbr_fg = ''Y'' and prod_id in(28,2053,2054,27,2004,2001,2005,2029,2034,15,30,37,2082,2069, 2083,2084,5,25,2062))
or evc_mbr_fg = ''Y'') and lob_id not in (10,911)
and substr(contract_id_cd, 7, 1) = ''8''
and plan_cat_nm = ''MA ONLY'') then ''MA Group''
when (((sh_mbr_fg = ''Y'' and prod_id in(28,2053,2054,27,2004,2001,2005,2029,2034,15,30,37,2082,2069, 2083,2084,5,25,2062) )
or evc_mbr_fg = ''Y'') and lob_id not in (10,911)
and substr(contract_id_cd, 7, 1) = ''8'' and plan_cat_nm = ''MAPD'') then ''MAPD Group''
when amc_mbr_fg=''Y'' and prod_id in (2050)  then ''c_s_isnp''
when amc_mbr_fg=''Y'' and prod_id in (2051)  then ''c_s_dsnp''
when amc_mbr_fg=''Y'' and prod_id in (2052)  then ''c_s_csnp''
end as Plan_Category ,
substr(contract_id_cd,1,1) as contrct,
substr(contract_id_cd,7,1) as pbp
from IDENTIFIER(:V_FED_MBRSHIP1)
where (mbr_plan_eff_dt <> dsenrl_dt) or dsenrl_dt is null
;



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_FED_MBRSHIP2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

-- Set flags for plans according to plan category

V_STEP := ''STEP5'';

V_STEP_NAME :=  ''create a table FED_MBRSHIP3'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace  table IDENTIFIER(:V_FED_MBRSHIP3) as
select *,
case when plan_cat_nm = ''MAPD'' and pbp=''8'' then ''MA_MAPD_Grp''
when MA_Indv_split is not null then  ''MA_Indvdl'' end as Ovrl_MA
from (
select *,
case when sh_mbr_fg=''Y''
and prod_id in(28,2053,2054,27,2004,2001,2005,2029,2034,15,30,37,2082,2069,2083,2084,5,25,2062,2051,2050,2052) then 1
when evc_mbr_fg=''Y'' then 1 else 0 end as ma_ind ,
case when sh_mbr_fg=''Y'' and prod_id not in(28,2053,2054,27,2004,2001,2005,2029,2034,15,30,37,2082,2069, 2083,2084,5,25,2062,2051,2050,2052)
then 1 else 0 end as sh_ms_ind ,
case when pdp_mbr_fg=''Y'' then 1 else 0 end as pdp_ind ,

case when amc_mbr_fg=''Y'' and prod_id in (2050,2051,2052)
--and contract_id_cd not in (''H0271-005-000'',''H0271-006-000'',''H0271-013-000'',''H0271-014-000'',''H2802-044-000'',''H5253-041-000'')
then 1 else 0 end as snp ,

case when Plan_Category = ''PDP Indv'' then 1 else 0 end as pdp_indv_ind,
case when Plan_Category = ''PDP Group'' then 1 else 0 end as pdp_grp_ind,

case when plan_cat_nm = ''MA ONLY'' and pbp <> ''8'' then ''MA_Only''
when Plan_Category = ''MAPD Indv'' then ''MAPD''
when Plan_Category = ''MAPD SNP'' then ''M&R_SNP'' end as MA_Indv_split
from IDENTIFIER(:V_FED_MBRSHIP2)) fltr ;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_FED_MBRSHIP3)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


-- Set flags for plans according to plan category

V_STEP := ''STEP6'';

V_STEP_NAME :=  ''create a table FED_MBRSHIP4'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace  table IDENTIFIER(:V_FED_MBRSHIP4) COPY GRANTS as
select *,
case when MA_Indv_split = ''MA_Only'' then 1 else 0 end as ma_only_ind,
case when MA_Indv_split = ''MAPD''  then 1 else 0 end as mapd_ind ,
case when MA_Indv_split = ''M&R_SNP'' then 1
--when contract_id_cd in (''H0271-005-000'',''H0271-006-000'',''H0271-013-000'',''H0271-014-000'',''H2802-044-000'',''H5253-041-000'') then 1
else 0 end as mnr_snp_ind,
case when Ovrl_MA= ''MA_MAPD_Grp'' then 1 else 0 end as ma_grp_ind
from IDENTIFIER(:V_FED_MBRSHIP3)
where mbi <> '''' and mbi is not null;

-- MS Data Pull
V_STEP := ''STEP7'';

V_STEP_NAME :=  ''create a table MS_MBR'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace  table IDENTIFIER(:V_MS_MBR) as
select p.birth_date
,ip.person_id
,ip.source_insured_plan_id
,ip.application_id
,a.source_application_id
,c.cmdb_person_id as cust_id
,psds.medicare_claim_number as MBI
,ip.effective_date
,ip.termination_date,
p.gender_code as gender_code_ms,
psds.state_code as State_MS,
am.amlk_id as amlk_id_ms,
hh.hh_address_id

,case
when trim(s1.product_type_code)=''M'' and trim(s1.product_type_var)=''P'' then ''Pre-std''
when trim(s1.product_type_code)=''M'' and trim(s1.product_type_var) in(''S'',''U'',''4'',''3'') then ''std''
when trim(s1.product_type_code)=''M'' and trim(s1.product_type_var) not in(''P'',''S'',''U'',''4'',''3'') then ''oth''
else '' '' end as ms_type

,case when trim(s1.product_type_code)=''H'' and trim(s1.product_type_var)=''E'' then 1 else 0 end as ehi
,case when trim(s1.product_type_code)=''H'' and trim(s1.product_type_var)=''A'' then 1 else 0 end as hap
,case when trim(s1.product_type_code)=''H'' and trim(s1.product_type_var)=''I'' then 1 else 0 end as hip
,case when trim(s1.product_type_code)=''H'' and trim(s1.product_type_var)=''B'' then 1 else 0 end as mapp
,case when trim(s1.product_type_code)=''P'' then 1 else 0 end as phip
,case when trim(s1.product_type_code)=''H'' and trim(s1.product_type_var)=''D'' then 1 else 0 end as smp

from IDENTIFIER(:V_INSURED_PLAN) ip
left join IDENTIFIER(:V_SPECIFICATION) s1 on ip.specification_id=s1.specification_id
left join IDENTIFIER(:V_PERSON) p on ip.person_id=p.person_id
left join IDENTIFIER(:V_CMDB_SMART_PERSON_PROFILE) c on ip.person_id=c.smart_person_id
left join IDENTIFIER(:V_APPLICATION) a on ip.application_id=a.application_id and ip.person_id=a.person_id
left join IDENTIFIER(:V_SHIP_PERSON_XREF) spx on ip.person_id = spx.person_id
left outer join IDENTIFIER(:V_PERSON_COMPAS_DAILY_SNAPSHOT_DECRYPT) psds on ip.person_id = psds.person_id and spx.ship_person_id = psds.ship_person_id
left join IDENTIFIER(:V_AMERILINK_DATA) am on ip.person_id = am.person_id
left join IDENTIFIER(:V_PERSON_ADDRESS_HHOLD_PROFILE) hh on ip.person_id = hh.person_id

where (ip.termination_date is null or ip.termination_date is null or ip.termination_date >= :V_SECOND_DATE ) --IS NULL ADD BY SRIKANTH
;

--termination_date : needs to cinfirm with jiayun (it will be same as above date)
-- Set flags for MS plans


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_MS_MBR)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

V_STEP := ''STEP8'';

V_STEP_NAME :=  ''create a table MS_MBR1/Combine MS and Fed member tables'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace  table IDENTIFIER(:V_MS_MBR1) COPY GRANTS as
select *,
case when ms_type in (''std'', ''Pre-std'') then 1 else 0 end as ms,
case when ehi=1 or hap=1 or hip=1 or mapp=1 or phip=1 or smp=1 then 1 else 0 end as ind
from IDENTIFIER(:V_MS_MBR)
where (effective_date <> termination_date) or termination_date is null;


-- Combine MS and Fed member tables

create or replace  table  IDENTIFIER(:V_MS_FED_MBR) as
select MBI
,mbr_plan_eff_dt as Eff_dt
,dsenrl_dt
,ma_ind, sh_ms_ind, pdp_ind, pdp_grp_ind, pdp_indv_ind, snp, ma_grp_ind, ma_only_ind, mapd_ind, mnr_snp_ind
,0 as ms
,0 as ind
from IDENTIFIER(:V_FED_MBRSHIP4) 
union all
select MBI
,effective_date as Eff_dt
,termination_date as dsenrl_dt
,0 as ma_ind, 0 as sh_ms_ind, 0 as pdp_ind, 0 as pdp_grp_ind, 0 as pdp_indv_ind,
0 as snp, 0 as ma_grp_ind, 0 as ma_only_ind, 0 as mapd_ind, 0 as mnr_snp_ind
,ms ,ind
from IDENTIFIER(:V_MS_MBR1)  ;


-- Assign 0 to null values
create or replace  table  IDENTIFIER(:V_MS_FED_MBR1) as
select MBI
,Eff_dt
,dsenrl_dt
, case when ma_ind is null then 0 else ma_ind end as ma_ind
, case when ma_only_ind is null then 0 else ma_only_ind end as ma_only_ind
, case when mapd_ind is null then 0 else mapd_ind end as mapd_ind
, case when mnr_snp_ind is null then 0 else mnr_snp_ind end as mnr_snp_ind
, case when ma_grp_ind is null then 0 else ma_grp_ind end as ma_grp_ind
, case when sh_ms_ind is null then 0 else sh_ms_ind end as sh_ms_ind
, case when pdp_ind is null then 0 else pdp_ind end as pdp_ind
, case when pdp_indv_ind is null then 0 else pdp_indv_ind end as pdp_indv_ind
, case when pdp_grp_ind is null then 0 else pdp_grp_ind end as pdp_grp_ind
, case when snp is null then 0 else snp end as snp
, case when ms is null then 0 else ms end as ms
, case when ind is null then 0 else ind end as ind
from IDENTIFIER(:V_MS_FED_MBR);



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_MS_FED_MBR1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

---- Define Plans  categories
V_STEP := ''STEP9'';

V_STEP_NAME :=  ''create a table Fed member tables 2/3/4'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace  table IDENTIFIER(:V_MS_FED_MBR2) as
 select *,
case
when (ms=1 and ind=1 and ma_ind=0 and sh_ms_ind=0 and pdp_ind=0) then ''MS + Ind''
when ( ma_ind=0 and sh_ms_ind=0 and pdp_ind=1 and ms=1 and ind=1 ) then ''MS + PDP + Ind''
when (pdp_ind=1 and ms=1 and ind=0 and ma_ind=0 and sh_ms_ind=0) then ''MS + PDP''
when ( ma_ind=0 and sh_ms_ind=1 and pdp_ind=0 and ms=0 and ind=1 ) then ''Fed MS + IND''
when ( ma_ind=0 and sh_ms_ind=1 and pdp_ind=1 and ms=0 and ind=0 ) then ''Fed MS + PDP''
when ( ma_ind=0 and sh_ms_ind=1 and pdp_ind=1 and ms=0 and ind=1 ) then ''Fed MS + PDP + IND''
when ( ma_ind=1 and sh_ms_ind=0 and pdp_ind=1 and ms=0 and ind=0 ) then ''MA + PDP''
when ( ma_ind=1 and sh_ms_ind=0 and pdp_ind=0 and ind=1 and ms=0) then ''MA + IND''
when ( ma_ind=1 and sh_ms_ind=0 and pdp_ind=1 and ms=0 and ind=1 ) then ''MA + PDP + Ind''
when ( ma_ind=0 and sh_ms_ind=0 and pdp_ind=1 and ms=0 and ind=1 ) then ''PDP + Ind''
when ( ma_ind=0 and sh_ms_ind=1 and pdp_ind=0  and ms=0 and ind=0) then ''Fed MS only''
when ( ma_ind=0 and sh_ms_ind=0 and pdp_indv_ind=1 and ms = 0 and ind = 0 ) then ''PDP Indv''
when ( ma_ind=0 and sh_ms_ind=0 and pdp_grp_ind=1 and ms = 0 and ind = 0 ) then ''PDP Group''
when ( ma_ind=0 and sh_ms_ind=0 and pdp_ind=0 and ms=0 and ind=1 and snp=0) then ''Ind only''
when ( ma_ind=0 and sh_ms_ind=0 and pdp_ind=0 and ms=1 and ind=0 and snp=0) then ''MS only''
when ( ma_ind=0 and sh_ms_ind=0 and pdp_ind=0 and ms=0 and ind=0  and snp=1) then ''C&S DSNP''
when ( ma_ind=1 and sh_ms_ind=0 and pdp_ind=0 and ms=1 and ind=0  and snp=0) then ''MA + MS''
when ( ma_only_ind=1 and sh_ms_ind=0 and pdp_ind=0 and ms=0 and ind=0 and snp=0) then ''MA''
when ( mapd_ind=1 and sh_ms_ind=0 and pdp_ind=0 and ms=0 and ind=0 and snp=0) then ''MAPD''
when ( mnr_snp_ind=1 and sh_ms_ind=0 and pdp_ind=0 and ms=0 and ind=0 and snp=0) then ''M&R DSNP''
when ( ma_grp_ind=1 and sh_ms_ind=0 and pdp_ind=0 and ms=0 and ind=0 and snp=0) then ''MA Group''
else ''Other'' end as Plan
from IDENTIFIER(:V_MS_FED_MBR1) ;

-- Define Product  categories
create or replace table IDENTIFIER(:V_MS_FED_MBR3) COPY GRANTS as
select *,
case when Plan in (''MA'',''MAPD'',''MA + IND'',''MA + PDP'',''MA + MS'') then ''MA''
when Plan in (''M&R DSNP'',''C&S DSNP'') then ''DSNP''
when Plan in (''MA Group'',''PDP Group'') then ''Group''
when Plan in (''MS only'',''MS + PDP + Ind'',''MS + PDP'',''MA + MS'',''MS + Ind'') then ''MS''
when Plan in (''Ind only'',''MA + IND'',''MS + Ind'',''MS + PDP + Ind'',''PDP + Ind'') then ''IND''
when Plan in (''Fed MS + PDP'',''MA + PDP'',''MS + PDP'',''MS + PDP + Ind'',''PDP Indv'',''PDP + Ind'') then ''PDP''
when Plan in (''Other'',''Fed MS only'',''Fed MS + PDP'') then ''Other''
else '''' end as Product_der
from IDENTIFIER(:V_MS_FED_MBR2) ;


-- Create segments column similar to product_segments column in apps table


create or replace table IDENTIFIER(:V_MS_FED_MBR4) COPY GRANTS as 
select 
CASE WHEN LENGTH(mbi) > 0 THEN mbi ELSE ''-9999'' END AS mbi,
eff_dt      ,
dsenrl_dt   ,
ma_ind      ,
ma_only_ind ,
mapd_ind    ,
mnr_snp_ind ,
ma_grp_ind  ,
sh_ms_ind   ,
pdp_ind     ,
pdp_indv_ind,
pdp_grp_ind ,
snp         ,
ms          ,
ind         ,
plan        ,
product_der ,
case when Plan= ''C&S DSNP'' then ''C&S SNP''
when Plan= ''M&R DSNP'' then ''M&R SNP''
when Plan= ''PDP Group'' then ''PDP GROUP''
when Plan= ''MA Group'' then ''MA GROUP''
when Plan in (''MA'',''MAPD'') then ''MA INDIVIDUAL''
when Plan= ''PDP Indv'' then ''PDP''
else '''' end as Segment_der
from IDENTIFIER(:V_MS_FED_MBR3);



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_MS_FED_MBR4)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

---- -- Create new fields
V_STEP := ''STEP10'';

V_STEP_NAME :=  ''create a table APP_MBR_APLDT tables 1/2/3'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace  table IDENTIFIER(:V_APP_MBR_APLDT) as
select a.*, b.mbi, b.eff_dt, b.dsenrl_dt, b.Plan, b.Product_der, b.Segment_der
from IDENTIFIER(:V_APPS1) a
left join IDENTIFIER(:V_MS_FED_MBR4) b
on a.medicare_hicn_cd=b.mbi
and ((A.appl_dt > B.Eff_dt and A.appl_dt <= dateadd(''day'',31,B.dsenrl_dt))
or (A. appl_dt > B.Eff_dt and (B.dsenrl_dt is null or B.dsenrl_dt is null))) 
;

create or replace  table IDENTIFIER(:V_APP_MBR_APLDT1) as
select *,
-- status=new
case when status = ''NEW'' and product_segments1 in (''MA INDIVIDUAL'',''MA GROUP'',''PDP'',''PDP GROUP'',''M&R SNP'',''C&S SNP'',''OTHER'')
and (Product_der = '''' or Product_der is NULL) then ''New Enroll''
when status = ''NEW'' and product_segments1 in (''MA INDIVIDUAL'',''MA GROUP'',''PDP'',''PDP GROUP'')
and (product_segments1 <> segment_der and  product_segments1 <> '''') then ''Product Switcher''
when status = ''NEW'' and product_segments1 in (''M&R SNP'')
and segment_der not in (''M&R SNP'',''C&S SNP'') then ''Product Switcher''
when status = ''NEW'' and product_segments1 in (''C&S SNP'')
and segment_der not in (''M&R SNP'',''C&S SNP'') then ''Product Switcher''
when status = ''NEW'' and product_segments1 = segment_der
then ''Same Product''
when status = ''NEW'' and product_segments1 in (''M&R SNP'',''C&S SNP'')
and segment_der in (''M&R SNP'',''C&S SNP'') then ''Same Product''
-- status=duplicate
when status=''DUPLICATE'' and product_segments1 in (''MA INDIVIDUAL'',''MA GROUP'',''PDP'',''PDP GROUP'',''M&R SNP'',''C&S SNP'',''OTHER'')
--and (Product_der <> '''' or Product_der is not NULL)
then ''Duplicate''
-- status=winback and Plan Change
when status in (''WINBACK'',''PLAN CHANGE'') and product_segments1 in (''MA INDIVIDUAL'',''MA GROUP'',''PDP'',''PDP GROUP'',''OTHER'')
and product_segments1 <> segment_der then ''Product Switcher''
when status in (''WINBACK'',''PLAN CHANGE'') and product_segments1 in (''M&R SNP'')
and segment_der not in (''M&R SNP'',''C&S SNP'') then ''Product Switcher''
when status in (''WINBACK'',''PLAN CHANGE'') and product_segments1 in (''C&S SNP'')
and segment_der not in (''M&R SNP'',''C&S SNP'') then ''Product Switcher''
when status in (''WINBACK'',''PLAN CHANGE'') and product_segments1 = segment_der
then ''Same Product''
when status in (''WINBACK'',''PLAN CHANGE'') and product_segments1 in (''M&R SNP'',''C&S SNP'')
and segment_der in (''M&R SNP'',''C&S SNP'') then ''Same Product''
-- ''Other'' product segment
when product_segments1 = ''OTHER'' and plan <> ''Fed MS only'' then ''Product Switcher''
when product_segments1 = ''OTHER'' and plan = ''Fed MS only'' then ''Other Product''
else '''' end as GovtPrg_ProdSwtch
from IDENTIFIER(:V_APP_MBR_APLDT) ;


create or replace  table IDENTIFIER(:V_APP_MBR_APLDT2) as
select *,
case when GovtPrg_ProdSwtch in (''New Enroll'',''Duplicate'') then ''''
when GovtPrg_ProdSwtch in (''Product Switcher'',''Same Product'',''Other Product'') then Product_der
else '''' end as GovtPrg_Prev_ProdSwtch

--added this part for Fed MS plan members only
,case when GovtPrg_ProdSwtch in (''Product Switcher'') and plan=''Fed MS only'' then plan
else '''' end as govtprg_prev_plan

,case when GovtPrg_ProdSwtch in (''New Enroll'',''Duplicate'') then ''''
--when GovtPrg_ProdSwtch in (''Product Switcher'',''Same Product'',''Other Product'') then Eff_dt
when GovtPrg_ProdSwtch in (''Product Switcher'',''Same Product'',''Other Product'') then TO_VARCHAR(Eff_dt::TIMESTAMP, ''YYYY-MM-DD HH24:MI:SS.FF3'')
else '''' end as GovtPrg_Prev_PlanEffdt



,case when GovtPrg_ProdSwtch in (''New Enroll'',''Duplicate'') then ''''
--when GovtPrg_ProdSwtch in (''Product Switcher'',''Same Product'',''Other Product'') then dsenrl_dt
when GovtPrg_ProdSwtch in (''Product Switcher'',''Same Product'',''Other Product'') then TO_VARCHAR(dsenrl_dt::TIMESTAMP, ''YYYY-MM-DD HH24:MI:SS.FF3'')
else '''' end as GovtPrg_Prev_Dserlldt

--add a numeric column for sorting and keep MS plan on top while de-duping
,case when plan=''MS only'' then 1 else 2 end as plan_num
from IDENTIFIER(:V_APP_MBR_APLDT1);


-- Remove duplicate


create or replace  table IDENTIFIER(:V_APP_MBR_APLDT3) COPY GRANTS
as select *
from (
select *, row_number() over (partition by medicare_hicn_cd,status,appl_id_cd,appl_dt,product_segments
order by medicare_hicn_cd,status,appl_id_cd,appl_dt,plan_eff_dt,product_segments,eff_dt,dsenrl_dt,plan_num) as rank_1
from IDENTIFIER(:V_APP_MBR_APLDT2)) fltr
where rank_1=1;

-- Keep selected columns
create or replace  table IDENTIFIER(:V_FED_APP_PRODSWTCH_APPLDT) COPY GRANTS
as select
a.*,
b.GovtPrg_ProdSwtch,b.GovtPrg_Prev_ProdSwtch,b.govtprg_prev_plan,
b.GovtPrg_Prev_PlanEffdt,b.GovtPrg_Prev_Dserlldt
from IDENTIFIER(:V_APPS) a left join IDENTIFIER(:V_APP_MBR_APLDT3) b
on a.medicare_hicn_cd=b.medicare_hicn_cd
and a.status=b.status
and a.appl_id_cd=b.appl_id_cd
and a.appl_dt=b.appl_dt
and a.product_segments=b.product_segments
;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_FED_APP_PRODSWTCH_APPLDT)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


---------------------------------QC Reporting

V_STEP := ''STEP11'';

V_STEP_NAME :=  ''QC Reporting'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_QC_REPORT) (QUERY VARCHAR, COUNT VARCHAR);
INSERT INTO IDENTIFIER(:V_QC_REPORT)
select CURRENT_STATEMENT() AS QUERY,count (*) AS COUNT from IDENTIFIER(:V_APPS);
INSERT INTO IDENTIFIER(:V_QC_REPORT)
select CURRENT_STATEMENT() AS QUERY,count (distinct appl_id_cd) AS COUNT from IDENTIFIER(:V_APPS);
INSERT INTO IDENTIFIER(:V_QC_REPORT)
select CURRENT_STATEMENT() AS QUERY,count (*) AS COUNT from IDENTIFIER(:V_APPS1);
INSERT INTO IDENTIFIER(:V_QC_REPORT)
select CURRENT_STATEMENT() AS QUERY,count(*) AS COUNT from IDENTIFIER(:V_APP_MBR_APLDT3);
INSERT INTO IDENTIFIER(:V_QC_REPORT)
select CURRENT_STATEMENT() AS QUERY,count( distinct medicare_hicn_cd,status,appl_id_cd,appl_dt,product_segments) AS COUNT from IDENTIFIER(:V_APPS);
INSERT INTO IDENTIFIER(:V_QC_REPORT)
select CURRENT_STATEMENT() AS QUERY,count(*) AS COUNT from IDENTIFIER(:V_FED_APP_PRODSWTCH_APPLDT);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_QC_REPORT)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);


RAISE;

END;

';