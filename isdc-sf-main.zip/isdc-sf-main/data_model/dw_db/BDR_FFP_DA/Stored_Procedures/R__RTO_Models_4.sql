--call SP_BASE_POPULATION('1234','RTO_MODELS','UBLIA_TST_ISDC_DEV_DB','UTIL','BDR_FFP_DA','BDR_FFP_DA_WRK','BDR_SMART','BDR_CONF','UBLIA_TST_WORK_XS_WH',CURRENT_DATE())
--call SP_RTO_MODELS_1('1234','RTO_MODELS','UBLIA_TST_ISDC_DEV_DB','UTIL','BDR_FFP_DA','BDR_FFP_DA_WRK','BDR_SMART','BDR_DM','UBLIA_TST_WORK_XS_WH',CURRENT_DATE())
--call SP_RTO_MODELS_2('1234','RTO_MODELS','UBLIA_TST_ISDC_DEV_DB','UTIL','BDR_FFP_DA','BDR_FFP_DA_WRK','BDR_SMART','BDR_DM','UBLIA_TST_WORK_XS_WH',CURRENT_DATE())
--call SP_RTO_MODELS_3('1234','RTO_MODELS','UBLIA_TST_ISDC_DEV_DB','UTIL','BDR_FFP_DA','BDR_FFP_DA_WRK','BDR_SMART','UBLIA_TST_WORK_XS_WH',CURRENT_DATE())
--call SP_RTO_MODELS_4('1234','RTO_MODELS','UBLIA_TST_ISDC_DEV_DB','UTIL','BDR_FFP_DA','BDR_FFP_DA_WRK','BDR_SMART','UBLIA_TST_WORK_XS_WH',CURRENT_DATE())
USE SCHEMA BDR_FFP_DA;

CREATE OR REPLACE PROCEDURE BDR_FFP_DA.SP_RTO_MODELS_4("PIPELINE_ID" VARCHAR(16777216), "PIPELINE_NAME" VARCHAR(16777216), "DB_NAME" VARCHAR(16777216), "UTIL_SC" VARCHAR(16777216), "TGT_SC" VARCHAR(16777216), "FFP_WRK_SC" VARCHAR(16777216), "SRC_SC" VARCHAR(16777216), "WH" VARCHAR(16777216), "CURR_DATE" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

V_CURRENT_DATE   DATE := COALESCE(TO_DATE(:CURR_DATE), CURRENT_DATE());

V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := :DB_NAME||''.''||COALESCE(:UTIL_SC, ''UTIL'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';

V_PROCESS_NAME   VARCHAR DEFAULT ''RTO MODELS'';

V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''CODE18-20'';

V_STEP             VARCHAR;

V_STEP_NAME        VARCHAR;

V_START_TIME       VARCHAR;

V_END_TIME         VARCHAR;

V_ROWS_PARSED       INTEGER;

V_ROWS_LOADED       INTEGER;

V_MESSAGE          VARCHAR;

V_LAST_QUERY_ID    VARCHAR;



--5TH Part Start
--CODE 18
V_EFT_SCORE1  VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_SCORE1'';
V_EFT_SCORE2  VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_SCORE2'';
V_EFT_SCORE3  VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_SCORE3'';
V_EFT_SYS_FINAL_DATASET9 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PRIV_SS_FINAL_DATASET9'';



BEGIN

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP1'';

V_STEP_NAME :=  ''create a table EFT_SCORE1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EFT_SCORE1) as
select * EXCLUDE ROW_NUM FROM (
select *
from
(select person_id,
individual_id,
tot_proc_days::bigint as tot_proc_days,
avg_proc_days::double as avg_proc_days,
max_proc_days::int as max_proc_days,
tot_benefit_amt_6_mnths::double as tot_benefit_amt_6_mnths,
tot_benefit_amt::double as tot_benefit_amt,
ecc_bl_payment_amount_3_mnths::double as ecc_bl_payment_amount_3_mnths,
ecc_bl_payment_amount_6_mnths::double as ecc_bl_payment_amount_6_mnths,
ecc_coins_amount_3_mnths::double as ecc_coins_amount_3_mnths,
a_ecc_coins_amount_3_mnths::double as a_ecc_coins_amount_3_mnths,
a_ecc_coins_amount::double as a_ecc_coins_amount,
ecc_claim_total_amt_paid::double as ecc_claim_total_amt_paid,
a_ecc_claim_total_amt_pd_6_mnths::double as a_ecc_claim_total_amt_pd_6_mnths,
a_ecc_claim_total_amt_paid::double as a_ecc_claim_total_amt_paid,
ecc_claim_total_app_3_mnths::double as ecc_claim_total_app_3_mnths,
ecc_claim_total_app_amt::double as ecc_claim_total_app_amt,
a_ecc_claim_total_app_3_mnths::double as a_ecc_claim_total_app_3_mnths,
a_ecc_claim_total_app_6_mnths::double as a_ecc_claim_total_app_6_mnths,
a_ecc_claim_total_app_amt::double as a_ecc_claim_total_app_amt,
a_ecc_claim_total_charge::double as a_ecc_claim_total_charge,
ecc_claim_total_deuct_6_mnths::double as ecc_claim_total_deuct_6_mnths,
ecc_claim_total_deuct::double as ecc_claim_total_deuct,
a_ecc_claim_total_deuct_6_mnths::double as a_ecc_claim_total_deuct_6_mnths,
a_ecc_claim_total_deuct::double as a_ecc_claim_total_deuct,
a_ecc_clm_tot_inelig_amt::double as a_ecc_clm_tot_inelig_amt,
no_calls_3_mnths::bigint as no_calls_3_mnths,
no_calls_6_mnths::bigint as no_calls_6_mnths,
no_calls::bigint as no_calls,
bill_pay_inq_call::bigint as bill_pay_inq_call,
claim_inq_call_3_mnths::bigint as claim_inq_call_3_mnths,
telemarketing_inq_call::bigint as telemarketing_inq_call,
opprtnty_inq_call_6_mnths::bigint as opprtnty_inq_call_6_mnths,
opprtnty_inq_call::bigint as opprtnty_inq_call,
plan_inq_call_3_mnths::bigint as plan_inq_call_3_mnths,
no_treatment_3_mnths::bigint as no_treatment_3_mnths,
no_treatment_6_mnths::bigint as no_treatment_6_mnths,
no_treatment::bigint as no_treatment,
no_pres_priv_auth_3_mnths::bigint as no_pres_priv_auth_3_mnths,
no_pres_priv_auth::bigint as no_pres_priv_auth,
no_pres_web_reg::bigint as no_pres_web_reg,
application_processing_time::int as application_processing_time,
msup_num_lapses::int as msup_num_lapses,
msup_active_prod_duration::int as msup_active_prod_duration,
tenure::bigint as tenure,
network_hosp_dist::double as network_hosp_dist,
no_claims::bigint as no_claims,
part_b_deduct::double as part_b_deduct,
avg_part_b_deduct::double as avg_part_b_deduct,
avg_benefit_amount::double as avg_benefit_amount,
tot_covered_expense::double as tot_covered_expense,
avg_covered_expense_6_mnths::double as avg_covered_expense_6_mnths,
charge_amount::double as charge_amount,
avg_charge_amount_3_mnths::double as avg_charge_amount_3_mnths,
avg_charge_amount_6_mnths::double as avg_charge_amount_6_mnths,
avg_charge_amount::double as avg_charge_amount,
deductible_amount_3_mnths::double as deductible_amount_3_mnths,
deductible_amount_6_mnths::double as deductible_amount_6_mnths,
avg_deductible_amount::double as avg_deductible_amount,
medicare_app_amount_6_mnths::double as medicare_app_amount_6_mnths,
medicare_app_amount::double as medicare_app_amount,
avg_medicare_app_amount::double as avg_medicare_app_amount,
medicare_pay_amount_6_mnths::double as medicare_pay_amount_6_mnths,
medicare_pay_amount_12_mnths::double as medicare_pay_amount_12_mnths,
avg_medicare_pay_amount::double as avg_medicare_pay_amount,
no_premium_3_mnths::bigint as no_premium_3_mnths,
no_premium_6_mnths::bigint as no_premium_6_mnths,
no_premium::bigint as no_premium,
tot_eft_disc_amount_3_mnths::double as tot_eft_disc_amount_3_mnths,
tot_eft_disc_amount_6_mnths::double as tot_eft_disc_amount_6_mnths,
tot_eft_disc_amount::double as tot_eft_disc_amount,
tot_loyalty_disc_amount::double as tot_loyalty_disc_amount,
tot_premium_amt_3_mnths::double as tot_premium_amt_3_mnths,
tot_premium_amt_6_mnths::double as tot_premium_amt_6_mnths,
tot_premium_amt::double as tot_premium_amt,
paid_net_memb_cont_amt_3_mnths::double as paid_net_memb_cont_amt_3_mnths,
paid_net_memb_cont_amt_6_mnths::double as paid_net_memb_cont_amt_6_mnths,
paid_net_memb_cont_amt::double as paid_net_memb_cont_amt,
tot_spouse_disc_amt_3_mnths::double as tot_spouse_disc_amt_3_mnths,
tot_spouse_disc_amt_6_mnths::double as tot_spouse_disc_amt_6_mnths,
paid_cert_qnty::bigint as paid_cert_qnty,
individual_premium_amount::double as individual_premium_amount,
specification_name::string as specification_name,
plan_code::string as plan_code,
ret::string as ret,
homval::double as homval,
famp_f::int as famp_f,
bank_card_single::int as bank_card_single,
networth::int as networth,
income::int as income,
pdp_fg_final::int as pdp_fg_final,
rdc_1::int as rdc_1,
new_member_fg::int as new_member_fg,
age::bigint as age,
gender_f::int as gender_f,
no_nba_camp_sent_before::bigint as no_nba_camp_sent_before,
no_nba_sent_12mnths::bigint as no_nba_sent_12mnths,
no_late_12_mnths::bigint as no_late_12_mnths,
no_1timeeft_6mths::bigint as no_1timeeft_6mths,
previous_recc_eft_360days::int as previous_recc_eft_360days,
no_camp_c000002230_180days::bigint as no_camp_c000002230_180days,
no_camp_c000003460_180days::bigint as no_camp_c000003460_180days,
no_camp_c000003601_360days::bigint as no_camp_c000003601_360days ,ROW_NUMBER() OVER (order by PERSON_ID
,individual_id
,MSUP_NUM_LAPSES
,tenure
,age
,PLAN_CODE
,Bank_Card_Single
,INDIVIDUAL_PREMIUM_AMOUNT
,OPPRTNTY_INQ_call
,CHARGE_amount
,MEDICARE_APP_amount
,tot_COVERED_EXPENSE
,avg_CHARGE_amount_6_mnths
,tot_benefit_amt_6_mnths
,MEDICARE_PAY_amount_12_mnths
,ECC_claim_total_deuct
,Gender_F
,new_member_fg
,tot_proc_days
,PART_B_DEDUCT
,paid_net_memb_cont_amt
,RDC_1
,no_claims
,application_processing_time
,avg_Benefit_amount
,avg_CHARGE_amount
,avg_DEDUCTIBLE_amount
,avg_MEDICARE_APP_amount
,avg_MEDICARE_PAY_amount
,avg_PART_B_DEDUCT
,avg_proc_days
,a_ECC_claim_total_amt_paid
,a_ECC_claim_total_app_amt
,a_ECC_claim_total_charge
,a_ECC_claim_total_deuct
,a_ECC_clm_tot_inelig_amt
,a_ECC_coins_amount
-- /*,no_held_days*/
,HOMVAL
,income
,NETWORK_HOSP_DIST
,networth
,no_calls
,tot_EFT_disc_amount
,tot_loyalty_disc_amount
,paid_net_memb_cont_amt_6_mnths
,ECC_BL_payment_amount_3_mnths
,ECC_coins_amount_3_mnths
,a_ECC_claim_total_app_6_mnths
,ECC_claim_total_amt_paid
,tot_benefit_amt
-- /*,held_days_6_mnths*/
,max_proc_days
,no_premium_6_mnths
,no_nba_camp_sent_before
,no_pres_PRIV_AUTH_3_mnths
,tot_Spouse_disc_amt_3_mnths
,tot_Spouse_disc_amt_6_mnths
,no_calls_3_mnths
,no_treatment_3_mnths
-- /*,time_service_days_6_mnths*/
,avg_CHARGE_amount_3_mnths
,a_ECC_claim_total_amt_pd_6_mnths
,ECC_BL_payment_amount_6_mnths
,BILL_PAY_INQ_call
,MSUP_NUM_LAPSES
,no_pres_PRIV_AUTH
,RET
,FAMP_F
,PLAN_INQ_call_3_mnths
,tot_EFT_disc_amount_3_mnths
,tot_EFT_disc_amount_6_mnths
,pdp_fg_final
,CLAIM_INQ_call_3_mnths
,no_nba_sent_12mnths
,OPPRTNTY_INQ_call_6_mnths
,DEDUCTIBLE_amount_3_mnths
,DEDUCTIBLE_amount_6_mnths
,TELEMARKETING_INQ_call
,no_pres_WEB_REG
,no_treatment_6_mnths
,no_camp_C000002230_180days
,previous_recc_EFT_360days
,no_1timeEFT_6mths
,no_late_12_mnths
,ECC_claim_total_app_amt
,no_treatment
,no_camp_C000003601_360days
,no_calls_6_mnths
,MEDICARE_APP_amount_6_mnths
,tot_premium_amt_3_mnths
-- /*,held_days_3_mnths*/
,a_ECC_claim_total_app_3_mnths
,PAID_CERT_QNTY
,no_premium_3_mnths
,tot_premium_amt_6_mnths
,ECC_claim_total_app_3_mnths
,ECC_claim_total_deuct_6_mnths
,MEDICARE_PAY_amount_6_mnths
,avg_COVERED_EXPENSE_6_mnths
,a_ECC_coins_amount_3_mnths
,no_camp_C000003460_180days
,paid_net_memb_cont_amt_3_mnths
-- /*,no_time_service_days*/
,a_ECC_claim_total_deuct_6_mnths
,SPECIFICATION_NAME
,MSUP_ACTIVE_PROD_DURATION
,no_premium
,tot_premium_amt) AS ROW_NUM from IDENTIFIER(:V_EFT_SYS_FINAL_DATASET9)) as a where a.row_num between 1 and 2000000
);





V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EFT_SCORE1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


--CODE 19
V_STEP := ''STEP2'';

V_STEP_NAME :=  ''create a table EFT_SCORE2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EFT_SCORE2) as
select * EXCLUDE ROW_NUM FROM (
select * 
from
(select person_id ,
individual_id ,
tot_proc_days ,
avg_proc_days ,
max_proc_days ,
tot_benefit_amt_6_mnths ,
tot_benefit_amt ,
ECC_BL_payment_amount_3_mnths ,
ECC_BL_payment_amount_6_mnths ,
ECC_coins_amount_3_mnths ,
a_ECC_coins_amount_3_mnths ,
a_ECC_coins_amount ,
ECC_claim_total_amt_paid ,
 a_ecc_claim_total_amt_pd_6_mnths ,
a_ECC_claim_total_amt_paid ,
ecc_claim_total_app_3_mnths ,
ECC_claim_total_app_amt ,
a_ECC_claim_total_app_3_mnths ,
a_ECC_claim_total_app_6_mnths ,
a_ECC_claim_total_app_amt ,
a_ECC_claim_total_charge ,
ECC_claim_total_deuct_6_mnths ,
ECC_claim_total_deuct ,
a_ECC_claim_total_deuct_6_mnths ,
a_ECC_claim_total_deuct ,
a_ECC_clm_tot_inelig_amt ,
no_calls_3_mnths ,
no_calls_6_mnths ,
no_calls ,
bill_pay_inq_call ,
claim_inq_call_3_mnths ,
telemarketing_inq_call ,
opprtnty_inq_call_6_mnths ,
opprtnty_inq_call ,
plan_inq_call_3_mnths ,
no_treatment_3_mnths ,
no_treatment_6_mnths ,
no_treatment ,
no_pres_priv_auth_3_mnths ,
no_pres_priv_auth ,
no_pres_web_reg ,
application_processing_time ,
msup_num_lapses ,
msup_active_prod_duration ,
tenure ,
network_hosp_dist ,
no_claims ,
PART_B_DEDUCT ,
avg_PART_B_DEDUCT ,
avg_Benefit_amount ,
tot_COVERED_EXPENSE ,
avg_COVERED_EXPENSE_6_mnths ,
CHARGE_amount ,
avg_CHARGE_amount_3_mnths ,
avg_CHARGE_amount_6_mnths ,
avg_CHARGE_amount ,
DEDUCTIBLE_amount_3_mnths,
DEDUCTIBLE_amount_6_mnths ,
avg_DEDUCTIBLE_amount ,
MEDICARE_APP_amount_6_mnths ,
medicare_app_amount ,
avg_MEDICARE_APP_amount ,
MEDICARE_PAY_amount_6_mnths ,
MEDICARE_PAY_amount_12_mnths ,
avg_MEDICARE_PAY_amount ,
no_premium_3_mnths ,
no_premium_6_mnths ,
no_premium ,
tot_EFT_disc_amount_3_mnths ,
tot_EFT_disc_amount_6_mnths ,
tot_EFT_disc_amount ,
tot_loyalty_disc_amount ,
tot_premium_amt_3_mnths ,
tot_premium_amt_6_mnths ,
tot_premium_amt ,
paid_net_memb_cont_amt_3_mnths ,
paid_net_memb_cont_amt_6_mnths ,
paid_net_memb_cont_amt ,
tot_Spouse_disc_amt_3_mnths ,
tot_Spouse_disc_amt_6_mnths ,
paid_cert_qnty ,
individual_premium_amount ,
specification_name ,
plan_code ,
ret ,
homval ,
famp_f ,
bank_card_single ,
networth ,
income ,
pdp_fg_final ,
rdc_1 ,
new_member_fg ,
age ,
gender_f ,
no_nba_camp_sent_before ,
no_nba_sent_12mnths ,
no_late_12_mnths ,
no_1timeeft_6mths ,
previous_recc_eft_360days ,
no_camp_c000002230_180days ,
no_camp_c000003460_180days ,
no_camp_c000003601_360days ,ROW_NUMBER() over(order by PERSON_ID
,individual_id
,MSUP_NUM_LAPSES
,tenure
,age
,PLAN_CODE
,Bank_Card_Single
,INDIVIDUAL_PREMIUM_AMOUNT
,OPPRTNTY_INQ_call
,CHARGE_amount
,MEDICARE_APP_amount
,tot_COVERED_EXPENSE
,avg_CHARGE_amount_6_mnths
,tot_benefit_amt_6_mnths
,MEDICARE_PAY_amount_12_mnths
,ECC_claim_total_deuct
,Gender_F
,new_member_fg
,tot_proc_days
,PART_B_DEDUCT
,paid_net_memb_cont_amt
,RDC_1
,no_claims
,application_processing_time
,avg_Benefit_amount
,avg_CHARGE_amount
,avg_DEDUCTIBLE_amount
,avg_MEDICARE_APP_amount
,avg_MEDICARE_PAY_amount
,avg_PART_B_DEDUCT
,avg_proc_days
,a_ECC_claim_total_amt_paid
,a_ECC_claim_total_app_amt
,a_ECC_claim_total_charge
,a_ECC_claim_total_deuct
,a_ECC_clm_tot_inelig_amt
,a_ECC_coins_amount
-- /*,no_held_days*/
,HOMVAL
,income
,NETWORK_HOSP_DIST
,networth
,no_calls
,tot_EFT_disc_amount
,tot_loyalty_disc_amount
,paid_net_memb_cont_amt_6_mnths
,ECC_BL_payment_amount_3_mnths
,ECC_coins_amount_3_mnths
,a_ECC_claim_total_app_6_mnths
,ECC_claim_total_amt_paid
,tot_benefit_amt
-- /*,held_days_6_mnths*/
,max_proc_days
,no_premium_6_mnths
,no_nba_camp_sent_before
,no_pres_PRIV_AUTH_3_mnths
,tot_Spouse_disc_amt_3_mnths
,tot_Spouse_disc_amt_6_mnths
,no_calls_3_mnths
,no_treatment_3_mnths
-- /*,time_service_days_6_mnths*/
,avg_CHARGE_amount_3_mnths
,a_ECC_claim_total_amt_pd_6_mnths
,ECC_BL_payment_amount_6_mnths
,BILL_PAY_INQ_call
,MSUP_NUM_LAPSES
,no_pres_PRIV_AUTH
,RET
,FAMP_F
,PLAN_INQ_call_3_mnths
,tot_EFT_disc_amount_3_mnths
,tot_EFT_disc_amount_6_mnths
,pdp_fg_final
,CLAIM_INQ_call_3_mnths
,no_nba_sent_12mnths
,OPPRTNTY_INQ_call_6_mnths
,DEDUCTIBLE_amount_3_mnths
,DEDUCTIBLE_amount_6_mnths
,TELEMARKETING_INQ_call
,no_pres_WEB_REG
,no_treatment_6_mnths
,no_camp_C000002230_180days
,previous_recc_EFT_360days
,no_1timeEFT_6mths
,no_late_12_mnths
,ECC_claim_total_app_amt
,no_treatment
,no_camp_C000003601_360days
,no_calls_6_mnths
,MEDICARE_APP_amount_6_mnths
,tot_premium_amt_3_mnths
-- /*,held_days_3_mnths*/
,a_ECC_claim_total_app_3_mnths
,PAID_CERT_QNTY
,no_premium_3_mnths
,tot_premium_amt_6_mnths
,ECC_claim_total_app_3_mnths
,ECC_claim_total_deuct_6_mnths
,MEDICARE_PAY_amount_6_mnths
,avg_COVERED_EXPENSE_6_mnths
,a_ECC_coins_amount_3_mnths
,no_camp_C000003460_180days
,paid_net_memb_cont_amt_3_mnths
-- /*,no_time_service_days*/
,a_ECC_claim_total_deuct_6_mnths
,SPECIFICATION_NAME
,MSUP_ACTIVE_PROD_DURATION
,no_premium
,tot_premium_amt) AS ROW_NUM from IDENTIFIER(:V_EFT_SYS_FINAL_DATASET9)) as a where a.row_num between 2000001 and 4000000);




V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EFT_SCORE2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--CODE 20
V_STEP := ''STEP3'';

V_STEP_NAME :=  ''create a table EFT_SCORE3'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EFT_SCORE3) as
select * EXCLUDE ROW_NUM FROM (
select *
from
(select person_id ,
individual_id ,
tot_proc_days ,
avg_proc_days ,
max_proc_days ,
tot_benefit_amt_6_mnths ,
tot_benefit_amt ,
ECC_BL_payment_amount_3_mnths ,
ECC_BL_payment_amount_6_mnths ,
ECC_coins_amount_3_mnths ,
a_ECC_coins_amount_3_mnths ,
a_ECC_coins_amount ,
ECC_claim_total_amt_paid ,
 a_ecc_claim_total_amt_pd_6_mnths ,
a_ECC_claim_total_amt_paid ,
ecc_claim_total_app_3_mnths ,
ECC_claim_total_app_amt ,
a_ECC_claim_total_app_3_mnths ,
a_ECC_claim_total_app_6_mnths ,
a_ECC_claim_total_app_amt ,
a_ECC_claim_total_charge ,
ECC_claim_total_deuct_6_mnths ,
ECC_claim_total_deuct ,
a_ECC_claim_total_deuct_6_mnths ,
a_ECC_claim_total_deuct ,
a_ECC_clm_tot_inelig_amt ,
no_calls_3_mnths ,
no_calls_6_mnths ,
no_calls ,
bill_pay_inq_call ,
claim_inq_call_3_mnths ,
telemarketing_inq_call ,
opprtnty_inq_call_6_mnths ,
opprtnty_inq_call ,
plan_inq_call_3_mnths ,
no_treatment_3_mnths ,
no_treatment_6_mnths ,
no_treatment ,
no_pres_priv_auth_3_mnths ,
no_pres_priv_auth ,
no_pres_web_reg ,
application_processing_time ,
msup_num_lapses ,
msup_active_prod_duration ,
tenure ,
network_hosp_dist ,
no_claims ,
PART_B_DEDUCT ,
avg_PART_B_DEDUCT ,
avg_Benefit_amount ,
tot_COVERED_EXPENSE ,
avg_COVERED_EXPENSE_6_mnths ,
CHARGE_amount ,
avg_CHARGE_amount_3_mnths ,
avg_CHARGE_amount_6_mnths ,
avg_CHARGE_amount ,
DEDUCTIBLE_amount_3_mnths,
DEDUCTIBLE_amount_6_mnths ,
avg_DEDUCTIBLE_amount ,
MEDICARE_APP_amount_6_mnths ,
medicare_app_amount ,
avg_MEDICARE_APP_amount ,
MEDICARE_PAY_amount_6_mnths ,
MEDICARE_PAY_amount_12_mnths ,
avg_MEDICARE_PAY_amount ,
no_premium_3_mnths ,
no_premium_6_mnths ,
no_premium ,
tot_EFT_disc_amount_3_mnths ,
tot_EFT_disc_amount_6_mnths ,
tot_EFT_disc_amount ,
tot_loyalty_disc_amount ,
tot_premium_amt_3_mnths ,
tot_premium_amt_6_mnths ,
tot_premium_amt ,
paid_net_memb_cont_amt_3_mnths ,
paid_net_memb_cont_amt_6_mnths ,
paid_net_memb_cont_amt ,
tot_Spouse_disc_amt_3_mnths ,
tot_Spouse_disc_amt_6_mnths ,
paid_cert_qnty ,
individual_premium_amount ,
specification_name ,
plan_code ,
ret ,
homval ,
famp_f ,
bank_card_single ,
networth ,
income ,
pdp_fg_final ,
rdc_1 ,
new_member_fg ,
age ,
gender_f ,
no_nba_camp_sent_before ,
no_nba_sent_12mnths ,
no_late_12_mnths ,
no_1timeeft_6mths ,
previous_recc_eft_360days ,
no_camp_c000002230_180days ,
no_camp_c000003460_180days ,
no_camp_c000003601_360days ,ROW_NUMBER() OVER (order by PERSON_ID
,individual_id
,MSUP_NUM_LAPSES
,tenure
,age
,PLAN_CODE
,Bank_Card_Single
,INDIVIDUAL_PREMIUM_AMOUNT
,OPPRTNTY_INQ_call
,CHARGE_amount
,MEDICARE_APP_amount
,tot_COVERED_EXPENSE
,avg_CHARGE_amount_6_mnths
,tot_benefit_amt_6_mnths
,MEDICARE_PAY_amount_12_mnths
,ECC_claim_total_deuct
,Gender_F
,new_member_fg
,tot_proc_days
,PART_B_DEDUCT
,paid_net_memb_cont_amt
,RDC_1
,no_claims
,application_processing_time
,avg_Benefit_amount
,avg_CHARGE_amount
,avg_DEDUCTIBLE_amount
,avg_MEDICARE_APP_amount
,avg_MEDICARE_PAY_amount
,avg_PART_B_DEDUCT
,avg_proc_days
,a_ECC_claim_total_amt_paid
,a_ECC_claim_total_app_amt
,a_ECC_claim_total_charge
,a_ECC_claim_total_deuct
,a_ECC_clm_tot_inelig_amt
,a_ECC_coins_amount
-- /*,no_held_days*/
,HOMVAL
,income
,NETWORK_HOSP_DIST
,networth
,no_calls
,tot_EFT_disc_amount
,tot_loyalty_disc_amount
,paid_net_memb_cont_amt_6_mnths
,ECC_BL_payment_amount_3_mnths
,ECC_coins_amount_3_mnths
,a_ECC_claim_total_app_6_mnths
,ECC_claim_total_amt_paid
,tot_benefit_amt
-- /*,held_days_6_mnths*/
,max_proc_days
,no_premium_6_mnths
,no_nba_camp_sent_before
,no_pres_PRIV_AUTH_3_mnths
,tot_Spouse_disc_amt_3_mnths
,tot_Spouse_disc_amt_6_mnths
,no_calls_3_mnths
,no_treatment_3_mnths
-- /*,time_service_days_6_mnths*/
,avg_CHARGE_amount_3_mnths
,a_ECC_claim_total_amt_pd_6_mnths
,ECC_BL_payment_amount_6_mnths
,BILL_PAY_INQ_call
,MSUP_NUM_LAPSES
,no_pres_PRIV_AUTH
,RET
,FAMP_F
,PLAN_INQ_call_3_mnths
,tot_EFT_disc_amount_3_mnths
,tot_EFT_disc_amount_6_mnths
,pdp_fg_final
,CLAIM_INQ_call_3_mnths
,no_nba_sent_12mnths
,OPPRTNTY_INQ_call_6_mnths
,DEDUCTIBLE_amount_3_mnths
,DEDUCTIBLE_amount_6_mnths
,TELEMARKETING_INQ_call
,no_pres_WEB_REG
,no_treatment_6_mnths
,no_camp_C000002230_180days
,previous_recc_EFT_360days
,no_1timeEFT_6mths
,no_late_12_mnths
,ECC_claim_total_app_amt
,no_treatment
,no_camp_C000003601_360days
,no_calls_6_mnths
,MEDICARE_APP_amount_6_mnths
,tot_premium_amt_3_mnths
-- /*,held_days_3_mnths*/
,a_ECC_claim_total_app_3_mnths
,PAID_CERT_QNTY
,no_premium_3_mnths
,tot_premium_amt_6_mnths
,ECC_claim_total_app_3_mnths
,ECC_claim_total_deuct_6_mnths
,MEDICARE_PAY_amount_6_mnths
,avg_COVERED_EXPENSE_6_mnths
,a_ECC_coins_amount_3_mnths
,no_camp_C000003460_180days
,paid_net_memb_cont_amt_3_mnths
-- /*,no_time_service_days*/
,a_ECC_claim_total_deuct_6_mnths
,SPECIFICATION_NAME
,MSUP_ACTIVE_PROD_DURATION
,no_premium
,tot_premium_amt) AS ROW_NUM from IDENTIFIER(:V_EFT_SYS_FINAL_DATASET9)) as a where a.row_num > 4000000);





V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EFT_SCORE3)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);


RAISE;

END;

';