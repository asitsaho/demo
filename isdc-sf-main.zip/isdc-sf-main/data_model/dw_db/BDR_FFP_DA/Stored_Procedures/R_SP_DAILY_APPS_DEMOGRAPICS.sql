USE SCHEMA BDR_FFP_DA;




CREATE OR REPLACE PROCEDURE BDR_FFP_DA.SP_DAILY_APPS_DEMOGRAPICS("PIPELINE_ID" VARCHAR(16777216), "PIPELINE_NAME" VARCHAR(16777216), "DB_NAME" VARCHAR(16777216), "UTIL_SC" VARCHAR(16777216), "ONE_SC" VARCHAR(16777216), "TWO_SC" VARCHAR(16777216), "THREE_SC" VARCHAR(16777216), "INTRM_SC" VARCHAR(16777216), "TGT_SC" VARCHAR(16777216), "WH" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE


V_CURRENT_DATE   DATE := COALESCE(CURRENT_DATE(), CURRENT_DATE());

V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := :DB_NAME||''.''||COALESCE(:UTIL_SC, ''UTIL'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';
        
V_PROCESS_NAME VARCHAR DEFAULT ''DAILY_APPS_DEMOGRAPICS_AMLK'';

V_SUB_PROCESS_NAME VARCHAR DEFAULT ''DAILY_APPS_DEMOGRAPICS'';

V_STEP             VARCHAR;

V_STEP_NAME        VARCHAR;

V_START_TIME       VARCHAR;

V_END_TIME         VARCHAR;

V_ROWS_PARSED       INTEGER;

V_ROWS_LOADED       INTEGER;

V_MESSAGE          VARCHAR;

V_LAST_QUERY_ID    VARCHAR;

V_amerilink_data_subset VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.apps_demog_amerilink_data_subset'';

V_amerilink_data VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''BDR_SMART'') || ''.amerilink_data'';

V_amlk_subset VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.apps_demog_amlk_subset'';

V_amlk VARCHAR := :DB_NAME || ''.'' || COALESCE(:TWO_SC, ''SRC_UCEE'') || ''.amlk'';

V_indvdl_subset VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.apps_demog_indvdl_subset'';

V_indvdl VARCHAR := :DB_NAME || ''.'' || COALESCE(:TWO_SC, ''SRC_UCEE'') || ''.indvdl'';

V_apps_indv_amlk_psc_lw VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.apps_demog_apps_indv_amlk_psc_lw'';

V_all_apps_federal VARCHAR:= :DB_NAME || ''.'' || COALESCE(:TWO_SC, ''SRC_UCEE'') || ''.all_apps_federal'';

V_new_categorization_psc_all VARCHAR := :DB_NAME || ''.'' || COALESCE(:TWO_SC, ''SRC_UCEE'') || ''.new_categorization_psc_all'';

V_bottomsup_campaignref_depotprj VARCHAR := :DB_NAME || ''.'' || COALESCE(:THREE_SC, ''SRC_FIN360'') || ''.bottomsup_campaignref_depotprj'';

V_ma_and_pdp_footprint VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.apps_demog_ma_and_pdp_footprint'';

V_zip_codes VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.apps_demog_zip_codes'';

V_qc_report VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.apps_demog_qc_report'';

V_qc_report_daily_apps_demographics_history VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.apps_demog_qc_report_daily_apps_demographics_history'';


BEGIN

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP1'';
  
V_STEP_NAME := ''Loading table apps_demog_amerilink_data_subset'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH; 

create or replace table IDENTIFIER(:V_amerilink_data_subset) COPY GRANTS as select
amd.person_id,
amd.amlk_id
from IDENTIFIER(:V_amerilink_data) amd;

V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_amerilink_data_subset) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP2'';
   
V_STEP_NAME := ''Loading table apps_demog_amlk_subset'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
use secondary roles all ;
create or replace table IDENTIFIER(:V_amlk_subset) COPY GRANTS as select
am.amlk_id,
am.CMYS,
am.Estinc30,
am.Nph19,
am.hhcomp,
am.geners
from IDENTIFIER(:V_amlk) am;

V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_amlk_subset) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP3'';
   
V_STEP_NAME := ''Loading table apps_demog_indvdl_subset'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
use secondary roles all ;
create or replace table IDENTIFIER(:V_indvdl_subset) COPY GRANTS as select
i.amlk_id,
i.dob,
i.gender_cd,
i.hh_id,
i.indvdl_id,
i.st_cd,
i.zip_cd
from IDENTIFIER(:V_indvdl) i;

V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_indvdl_subset) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



V_STEP := ''STEP4'';
   
V_STEP_NAME := ''Loading table apps_demog_apps_indv_amlk_psc_lw'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
create or replace table IDENTIFIER(:V_apps_indv_amlk_psc_lw) COPY GRANTS as
select a.appl_dt,
a.appl_id_cd,
a.attr_cd,
a.contract_id_cd,
a.credited_psc_trtmnt_cd,
a.lob as apps_table_lob,
a.product_segments,
a.status as apps_table_status,
a.year,
i.dob,
i.gender_cd,
i.hh_id,
i.indvdl_id,
i.st_cd,
i.zip_cd,
p.bilingual_flag,
p.brand,
p.budgetmonth,
p.callexperience,
p.calltoaction,
p.campaign,
p.channel,
p.costperpiece,
p.depot_project_cd,
p.enddate,
p.enrollmentoption,
p.geography,
p.inhomedate,
p.issourcecode,
p.istfn,
p.language,
p.leadsource,
p.mktgmedium,
p.objective,
p.period,
p.pricing,
p.productoffer,
p.program_cd,
p.program_nm,
p.project_cd,
p.project_id,
p.project_nm,
p.psc,
p.psc_month,
p.reporting,
p.requester,
p.site,
p.type,
p.value_prop_name,
p.version,
am.amlk_id,
am.cmys,
am.estinc30,
am.nph19,
am.hhcomp,
am.geners,
z.state_county,
z.postal_code,
z.scc,
z.place_name,
z.state,
z.state_abbreviation,
z.county,
z.fips_code,
z.fips_state_county_code,
f.contract_id_join,
f.nextyear_plan_id,
f.currentyear,
f.nextbidyear,
f.ownership,
f.mapped_to,
f.mapped_from,
f."2023contract",
f."2023pbp",
f."2023_segment_id",
f."2023_plan_id_segmented",
f.line_of_business,
f.legal_entity,
f."2022_plan_name",
f."2023_plan_name",
f."2022_plan_type",
f."2023_plantype",
f."2023_snptype",
f."2023_snpstatus",
f."2023_snp_description",
f.medicaid_eligibility_type_dsnp_subtype,
f."2023_product_focus",
f."2023_mapd",
f."2023_aarp",
f.claimssystem,
f.plannamechange,
f.plantypechange,
f.snpstatuschange,
f.mapdchange,
f.aarp_change,
f."2022_psp",
f."2023_psp",
f."2022_pos_sa",
f."2023_pos_sa",
f."2022_formularyid",
f."2022_formulary_name",
f."2023_formularyid",
f."2023_formulary_name",
f.hpms_crosswalk,
f.anoc,
f.file_source,
f.flag,
t2.campaigngroup,
t2.campaigndetail,
t2.`2023_projectcode`,
t2.`2023_projectname`,
t2.`2022_projectcode`,
t2.`2022_projectname`,
t2.`2021_projectcode`,
t2.`2021_projectname`
from IDENTIFIER(:V_all_apps_federal) a 
left join IDENTIFIER(:V_indvdl_subset) i on a.indvdl_id = i.indvdl_id
left join IDENTIFIER(:V_new_categorization_psc_all) p on a.credited_psc_trtmnt_cd = p.psc
left join IDENTIFIER(:V_amlk_subset) am on i.amlk_id = am.amlk_id 
left join IDENTIFIER(:V_bottomsup_campaignref_depotprj) t2 on p.depot_project_cd = t2.`2022_projectcode`
and t2.`2022_projectcode` <> ''''
left join IDENTIFIER(:V_ma_and_pdp_footprint) f on a.contract_id_cd = f.contract_id_join 
left join IDENTIFIER(:V_zip_codes) z on a.zip_cd = z.postal_code 
where a.product_segments in (''M&R SNP'', ''C&S SNP'', ''PDP'', ''MA INDIVIDUAL'')
and a.status <> ''DUPLICATE''
and year(a.appl_dt) = 2022

Union All

select a.appl_dt,
a.appl_id_cd,
a.attr_cd,
a.contract_id_cd,
a.credited_psc_trtmnt_cd,
a.lob as apps_table_lob,
a.product_segments,
a.status as apps_table_status,
a.year,
i.dob,
i.gender_cd,
i.hh_id,
i.indvdl_id,
i.st_cd,
i.zip_cd,
p.bilingual_flag,
p.brand,
p.budgetmonth,
p.callexperience,
p.calltoaction,
p.campaign,
p.channel,
p.costperpiece,
p.depot_project_cd,
p.enddate,
p.enrollmentoption,
p.geography,
p.inhomedate,
p.issourcecode,
p.istfn,
p.language,
p.leadsource,
p.mktgmedium,
p.objective,
p.period,
p.pricing,
p.productoffer,
p.program_cd,
p.program_nm,
p.project_cd,
p.project_id,
p.project_nm,
p.psc,
p.psc_month,
p.reporting,
p.requester,
p.site,
p.type,
p.value_prop_name,
p.version,
am.amlk_id,
am.cmys,
am.estinc30,
am.nph19,
am.hhcomp,
am.geners,
z.state_county,
z.postal_code,
z.scc,
z.place_name,
z.state,
z.state_abbreviation,
z.county,
z.fips_code,
z.fips_state_county_code,
f.contract_id_join,
f.nextyear_plan_id,
f.currentyear,
f.nextbidyear,
f.ownership,
f.mapped_to,
f.mapped_from,
f."2023contract",
f."2023pbp",
f."2023_segment_id",
f."2023_plan_id_segmented",
f.line_of_business,
f.legal_entity,
f."2022_plan_name",
f."2023_plan_name",
f."2022_plan_type",
f."2023_plantype",
f."2023_snptype",
f."2023_snpstatus",
f."2023_snp_description",
f.medicaid_eligibility_type_dsnp_subtype,
f."2023_product_focus",
f."2023_mapd",
f."2023_aarp",
f.claimssystem,
f.plannamechange,
f.plantypechange,
f.snpstatuschange,
f.mapdchange,
f.aarp_change,
f."2022_psp",
f."2023_psp",
f."2022_pos_sa",
f."2023_pos_sa",
f."2022_formularyid",
f."2022_formulary_name",
f."2023_formularyid",
f."2023_formulary_name",
f.hpms_crosswalk,
f.anoc,
f.file_source,
f.flag,
t2.campaigngroup,
t2.campaigndetail,
t2.`2023_projectcode`,
t2.`2023_projectname`,
t2.`2022_projectcode`,
t2.`2022_projectname`,
t2.`2021_projectcode`,
t2.`2021_projectname`
from IDENTIFIER(:V_all_apps_federal) a 
left join IDENTIFIER(:V_indvdl_subset) i on a.indvdl_id = i.indvdl_id
left join IDENTIFIER(:V_new_categorization_psc_all) p on a.credited_psc_trtmnt_cd = p.psc
left join IDENTIFIER(:V_amlk_subset) am on i.amlk_id = am.amlk_id 
left join IDENTIFIER(:V_bottomsup_campaignref_depotprj) t2 on p.depot_project_cd = t2.`2023_projectcode` 
and t2.`2023_projectcode` <> ''''
left join IDENTIFIER(:V_ma_and_pdp_footprint) f on a.contract_id_cd = f.contract_id_join 
left join IDENTIFIER(:V_zip_codes) z on a.zip_cd = z.postal_code 
where a.product_segments in (''M&R SNP'', ''C&S SNP'', ''PDP'', ''MA INDIVIDUAL'')
and a.status <> ''DUPLICATE''
and year(a.appl_dt) = 2023;

V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_apps_indv_amlk_psc_lw) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP5'';
   
V_STEP_NAME := ''Loading table apps_demog_qc_report '';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
create or replace table IDENTIFIER(:V_qc_report) COPY GRANTS as
select a.appl_dt, 
count(distinct a.appl_id_cd) count_apps,
count(distinct i.indvdl_id ) count_indvdl,
count(credited_psc_trtmnt_cd) as count_a_psc,
count(psc) as count_p_psc,
count(i.amlk_id) as count_I_amlk,
count(am.amlk_id) as count_am_amlk,
count(amd.amlk_id) as count_amd_amlk
from IDENTIFIER(:V_all_apps_federal) a
left join IDENTIFIER(:V_indvdl_subset) i on a.indvdl_id = i.indvdl_id
left join IDENTIFIER(:V_new_categorization_psc_all) p on a.credited_psc_trtmnt_cd = p.psc
left join IDENTIFIER(:V_amlk_subset) am on i.amlk_id = am.amlk_id 
left join IDENTIFIER(:V_amerilink_data_subset) amd on i.amlk_id = amd.amlk_id 
where year(appl_dt) = 2023
and CURRENT_DATE() >= a.appl_dt 
and a.product_segments in (''M&R SNP'', ''C&S SNP'', ''PDP'', ''MA INDIVIDUAL'')
and a.status <> ''DUPLICATE''
group by a.appl_dt ;
	
V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_qc_report) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


/*  V_STEP := ''STEP6'';
   
   V_STEP_NAME := ''Creating table apps_demog_qc_report_daily_apps_demographics_history'';
   
   V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
create or replace table IDENTIFIER(:V_qc_report_daily_apps_demographics_history) COPY GRANTS (
appl_dt date
, count_apps bigint
, count_indvdl bigint
, count_a_psc bigint
, count_p_psc bigint
, count_i_amlk bigint
, count_am_amlk bigint
, count_amd_amlk bigint
, report_date date
);

V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_qc_report_daily_apps_demographics_history) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
 */

V_STEP := ''STEP6'';
   
V_STEP_NAME := ''Insert data into table apps_demog_qc_report_daily_apps_demographics_history'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

DELETE FROM IDENTIFIER(:V_qc_report_daily_apps_demographics_history) WHERE report_date=:V_CURRENT_DATE;
   
insert into IDENTIFIER(:V_qc_report_daily_apps_demographics_history)
select 
cast(appl_dt as date)
, count_apps 
, count_indvdl 
, count_a_psc 
, count_p_psc 
, count_i_amlk 
, count_am_amlk 
, count_amd_amlk 
, cast(CURRENT_DATE as date) as report_date 
from IDENTIFIER(:V_qc_report);

V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_qc_report_daily_apps_demographics_history) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);








EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);


RAISE;

END;

';
