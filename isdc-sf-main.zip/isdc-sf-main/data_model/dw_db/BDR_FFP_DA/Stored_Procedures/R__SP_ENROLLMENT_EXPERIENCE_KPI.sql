USE SCHEMA BDR_FFP_DA;

CREATE OR REPLACE PROCEDURE SP_ENROLLMENT_EXPERIENCE_KPI
( 
     PIPELINE_ID   varchar, 
     PIPELINE_NAME varchar, 
     DB_NAME       varchar,
     UTIL_SC       varchar,
     TGT_SC        varchar,
     INTRM_SC      varchar,
     SRC_APEX_SC   varchar,
     SRC_COMPAS_SC varchar,
     WH            varchar,
     CURR_DATE     varchar
)
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS 
$$
DECLARE

    V_CURRENT_DATE             DATE := COALESCE(TO_DATE(:CURR_DATE), CURRENT_DATE());
    V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := :DB_NAME||'.'||COALESCE(:UTIL_SC, 'UTIL')||'.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS';
    V_PROCESS_NAME             VARCHAR DEFAULT 'ENROLLMENT_EXPERIENCE_KPI';
    V_SUB_PROCESS_NAME         VARCHAR DEFAULT 'ENROLLMENT_EXPERIENCE_KPI';
    V_STEP                     VARCHAR;
    V_STEP_NAME                VARCHAR;
    V_START_TIME               VARCHAR;
    V_END_TIME                 VARCHAR;
    V_ROWS_PARSED              INTEGER;
    V_ROWS_LOADED              INTEGER;
    V_MESSAGE                  VARCHAR;
    V_LAST_QUERY_ID            VARCHAR;

    -- Temporary tables
    V_SMITTA40_UW_DASHBOARD_POS_REASON           VARCHAR := :DB_NAME || '.' || COALESCE(:INTRM_SC,  'BDR_FFP_DA_WRK') || '.ENROLL_EXP_KPI_UW_DASHBOARD_POS_REASON';
    V_SMITTA40_UW_DASHBOARD_UW_MANUALLY_REVIEWED VARCHAR := :DB_NAME || '.' || COALESCE(:INTRM_SC,  'BDR_FFP_DA_WRK') || '.ENROLL_EXP_KPI_UW_DASHBOARD_UW_MANUALLY_REVIEWED';
    V_SMITTA40_UW_DASHBOARD_DATA_UW_APPS         VARCHAR := :DB_NAME || '.' || COALESCE(:INTRM_SC,  'BDR_FFP_DA_WRK') || '.ENROLL_EXP_KPI_UW_DASHBOARD_DATA_UW_APPS';
    V_SMITTA40_UW_DASHBOARD_AUTO_MANUAL          VARCHAR := :DB_NAME || '.' || COALESCE(:INTRM_SC,  'BDR_FFP_DA_WRK') || '.ENROLL_EXP_KPI_UW_DASHBOARD_AUTO_MANUAL';  
    V_SMITTA40_UW_DASHBOARD_DATA_SUBTOTAL_AUTO   VARCHAR := :DB_NAME || '.' || COALESCE(:INTRM_SC,  'BDR_FFP_DA_WRK') || '.ENROLL_EXP_KPI_UW_DASHBOARD_DATA_SUBTOTAL_AUTO'; 
    V_SMITTA40_SUB_TOTAL_AUTO_DECISIONED         VARCHAR := :DB_NAME || '.' || COALESCE(:INTRM_SC,  'BDR_FFP_DA_WRK') || '.ENROLL_EXP_KPI_SUB_TOTAL_AUTO_DECISIONED'; 
    V_SMITTA40_UW_DASHBOARD_AUTO_DECISIONED      VARCHAR := :DB_NAME || '.' || COALESCE(:INTRM_SC,  'BDR_FFP_DA_WRK') || '.ENROLL_EXP_KPI_UW_DASHBOARD_AUTO_DECISIONED';     
    V_SMITTA40_UW_DASHBOARD_POS_MANUAL_SUB       VARCHAR := :DB_NAME || '.' || COALESCE(:INTRM_SC,  'BDR_FFP_DA_WRK') || '.ENROLL_EXP_KPI_UW_DASHBOARD_POS_MANUAL_SUB';     
    V_SMITTA40_UW_DASHBOARD_POS_MANUAL           VARCHAR := :DB_NAME || '.' || COALESCE(:INTRM_SC,  'BDR_FFP_DA_WRK') || '.ENROLL_EXP_KPI_UW_DASHBOARD_POS_MANUAL';          
    V_SMITTA40_UW_DASHBOARD_MANUAL_SUB           VARCHAR := :DB_NAME || '.' || COALESCE(:INTRM_SC,  'BDR_FFP_DA_WRK') || '.ENROLL_EXP_KPI_UW_DASHBOARD_MANUAL_SUB';    
    V_SMITTA40_UW_DASHBOARD_MANUAL1              VARCHAR := :DB_NAME || '.' || COALESCE(:INTRM_SC,  'BDR_FFP_DA_WRK') || '.ENROLL_EXP_KPI_UW_DASHBOARD_MANUAL1';    
    V_SMITTA40_UW_DASHBOARD_MANUAL2              VARCHAR := :DB_NAME || '.' || COALESCE(:INTRM_SC,  'BDR_FFP_DA_WRK') || '.ENROLL_EXP_KPI_UW_DASHBOARD_MANUAL2';
    V_SMITTA40_UW_DASHBOARD_MANUAL               VARCHAR := :DB_NAME || '.' || COALESCE(:INTRM_SC,  'BDR_FFP_DA_WRK') || '.ENROLL_EXP_KPI_UW_DASHBOARD_MANUAL';
    V_SMITTA40_NON_UW_APPS                       VARCHAR := :DB_NAME || '.' || COALESCE(:INTRM_SC,  'BDR_FFP_DA_WRK') || '.ENROLL_EXP_KPI_NON_UW_APPS';    
    V_SMITTA40_KPI_ENROLL_TAT_1                  VARCHAR := :DB_NAME || '.' || COALESCE(:INTRM_SC,  'BDR_FFP_DA_WRK') || '.ENROLL_EXP_KPI_ENROLL_TAT_1'; 
    V_SMITTA40_KPI_ENROLL_TAT2                   VARCHAR := :DB_NAME || '.' || COALESCE(:INTRM_SC,  'BDR_FFP_DA_WRK') || '.ENROLL_EXP_KPI_ENROLL_TAT2';
    V_SMITTA40_KPI_ENROLL_TAT                    VARCHAR := :DB_NAME || '.' || COALESCE(:INTRM_SC,  'BDR_FFP_DA_WRK') || '.ENROLL_EXP_KPI_ENROLL_TAT';    
    V_SMITTA40_AEP_UW_TAT1                       VARCHAR := :DB_NAME || '.' || COALESCE(:INTRM_SC,  'BDR_FFP_DA_WRK') || '.ENROLL_EXP_KPI_AEP_UW_TAT1'; 
    V_SMITTA40_KPI_UW_TAT                        VARCHAR := :DB_NAME || '.' || COALESCE(:INTRM_SC,  'BDR_FFP_DA_WRK') || '.ENROLL_EXP_KPI_UW_TAT';          
    
    -- Target Tables
    V_COMMON_KPI_ENROLL_TAT                      VARCHAR := :DB_NAME || '.' || COALESCE(:TGT_SC, 'BDR_FFP_DA') || '.ENROLL_EXP_KPI_ENROLL_TAT';  
    V_COMMON_KPI_UW_TAT                          VARCHAR := :DB_NAME || '.' || COALESCE(:TGT_SC, 'BDR_FFP_DA') || '.ENROLL_EXP_KPI_UW_TAT';          
    V_COMMON_KPI_COMPILATION_NEW_ENROLL_APPS     VARCHAR := :DB_NAME || '.' || COALESCE(:TGT_SC, 'BDR_FFP_DA') || '.ENROLL_EXP_KPI_COMPILATION_NEW_ENROLL_APPS'; 

    -- FFP Table
    V_FFP_POS_UW_UNDERWRITING_DASHBOARD_DATA     VARCHAR := :DB_NAME || '.' || COALESCE(:TGT_SC, 'BDR_FFP_DA') || '.POS_UW_UNDERWRITING_DASHBOARD_DATA';
    
    -- Source tables
    V_REFINED_APEX_AUDIT_COMPLETED_VW            VARCHAR := :DB_NAME || '.' || COALESCE(:SRC_APEX_SC, 'SRC_APEX') || '.AUDIT_COMPLETED_VW';
    V_REFINED_COMPAS_APPLICATION                 VARCHAR := :DB_NAME || '.' || COALESCE(:SRC_COMPAS_SC, 'SRC_COMPAS') || '.APPLICATION';
    V_REFINED_COMPAS_APPLICATION_ACTOR           VARCHAR := :DB_NAME || '.' || COALESCE(:SRC_COMPAS_SC, 'SRC_COMPAS') || '.APPLICATION_ACTOR';
    V_REFINED_COMPAS_APPLICATION_MECHANISM       VARCHAR := :DB_NAME || '.' || COALESCE(:SRC_COMPAS_SC, 'SRC_COMPAS') || '.APPLICATION_MECHANISM';
    V_REFINED_COMPAS_ARC_WORK_QUEUE_HISTORY      VARCHAR := :DB_NAME || '.' || COALESCE(:SRC_COMPAS_SC, 'SRC_COMPAS') || '.ARC_WORK_QUEUE_HISTORY';
    V_REFINED_COMPAS_ARC_WORK_QUEUE_REC_ID       VARCHAR := :DB_NAME || '.' || COALESCE(:SRC_COMPAS_SC, 'SRC_COMPAS') || '.ARC_WORK_QUEUE_REC_ID';
    V_REFINED_COMPAS_CONTACT_HIST_CONTACT_TYPE   VARCHAR := :DB_NAME || '.' || COALESCE(:SRC_COMPAS_SC, 'SRC_COMPAS') || '.CONTACT_HIST_CONTACT_TYPE';
    V_REFINED_COMPAS_INSURED_PLAN                VARCHAR := :DB_NAME || '.' || COALESCE(:SRC_COMPAS_SC, 'SRC_COMPAS') || '.INSURED_PLAN';
    V_REFINED_COMPAS_REASON                      VARCHAR := :DB_NAME || '.' || COALESCE(:SRC_COMPAS_SC, 'SRC_COMPAS') || '.REASON';
    V_REFINED_COMPAS_TERMINATION_REASON          VARCHAR := :DB_NAME || '.' || COALESCE(:SRC_COMPAS_SC, 'SRC_COMPAS') || '.TERMINATION_REASON';
    V_REFINED_COMPAS_WORK_QUEUE_FAMILY           VARCHAR := :DB_NAME || '.' || COALESCE(:SRC_COMPAS_SC, 'SRC_COMPAS') || '.WORK_QUEUE_FAMILY';
    V_REFINED_COMPAS_WORK_QUEUE_HISTORY          VARCHAR := :DB_NAME || '.' || COALESCE(:SRC_COMPAS_SC, 'SRC_COMPAS') || '.WORK_QUEUE_HISTORY';
    V_REFINED_COMPAS_WORK_QUEUE_REC_ID           VARCHAR := :DB_NAME || '.' || COALESCE(:SRC_COMPAS_SC, 'SRC_COMPAS') || '.WORK_QUEUE_REC_ID';
    V_REFINED_COMPAS_WORK_QUEUE_TYPE             VARCHAR := :DB_NAME || '.' || COALESCE(:SRC_COMPAS_SC, 'SRC_COMPAS') || '.WORK_QUEUE_TYPE';

BEGIN

    -------------------------------------------START OF CODE-----------------------

    EXECUTE IMMEDIATE 'USE WAREHOUSE '||:WH;
    ALTER SESSION SET TIMEZONE = 'America/Chicago';

    V_STEP       := 'STEP1';
    V_STEP_NAME  :=  'create '||V_SMITTA40_UW_DASHBOARD_POS_REASON;
    V_START_TIME := CONVERT_TIMEZONE('America/Chicago', CURRENT_TIMESTAMP());

    CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_POS_REASON) COPY GRANTS AS 
    select *, case reason_text
    WHEN 'AUTO DENY DUE TO IRIX' THEN 'Auto Deny   IRIX'
    WHEN 'AUTO DENY SELF DISCLOSED CONDITION' THEN 'Auto Deny - Self Disclosed'
    WHEN 'UW IRIX AUTO-ACCEPTED AT LEVEL 2 RATE' THEN 'Auto Rated   IRIX'
    WHEN 'UW SELF DISCLOSED CONDITION AUTO-ACCEPTED AT LEVEL 2 RATE' THEN 'Auto Rated - Self Disclosed'
    ELSE 'Other'
    END as POS_REASON
    from IDENTIFIER(:V_ffp_pos_uw_UNDERWRITING_DASHBOARD_DATA);

    V_ROWS_LOADED   :=  (select  count(1)  from  IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_POS_REASON))  ;
    V_LAST_QUERY_ID :=  (SELECT  LAST_QUERY_ID(-2))  ;
    CALL  IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL)  (:DB_NAME,  :UTIL_SC,  'DEEP',  :PIPELINE_ID,  :PIPELINE_NAME,  :V_PROCESS_NAME,  :V_SUB_PROCESS_NAME,
                     :V_STEP,  :V_STEP_NAME,  :V_START_TIME,  CURRENT_TIMESTAMP(),  'SUCCESS',  :V_LAST_QUERY_ID,  :V_ROWS_PARSED,  :V_ROWS_LOADED,  NULL,  NULL,  NULL);      


    ----------------------------------------------------------------------------------

    V_STEP := 'STEP2';
    V_STEP_NAME :=  'create '||V_SMITTA40_UW_DASHBOARD_UW_MANUALLY_REVIEWED;
    V_START_TIME := CONVERT_TIMEZONE('America/Chicago', CURRENT_TIMESTAMP());

    CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_UW_MANUALLY_REVIEWED) COPY GRANTS AS 
    SELECT *
    FROM 
    (

    SELECT *,COALESCE (UW_MANUALLY_REVIEWED,MANUALLY_REVIEWED) AS UW_MANUALLY_REVIEWED_1
    FROM 

    (
    SELECT *,
    CASE 
      WHEN ASSIGNED_TO IS NULL  THEN 
      CASE 
        WHEN TRIM(POS_REASON) IN ('Auto Deny - Self Disclosed',
    'Auto Deny   IRIX',
    'Auto Deny   IRIX',
    'Auto Rated - Self Disclosed',
    'Auto Rated   IRIX') THEN 'N'

    ELSE MANUALLY_REVIEWED
    END
    END as UW_MANUALLY_REVIEWED

    FROM IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_POS_REASON)
    ) A
    ) B;

    V_ROWS_LOADED   :=  (select  count(1)  from  IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_UW_MANUALLY_REVIEWED))  ;
    V_LAST_QUERY_ID :=  (SELECT  LAST_QUERY_ID(-2))  ;
    CALL  IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL)  (:DB_NAME,  :UTIL_SC,  'DEEP',  :PIPELINE_ID,  :PIPELINE_NAME,  :V_PROCESS_NAME,  :V_SUB_PROCESS_NAME,
                     :V_STEP,  :V_STEP_NAME,  :V_START_TIME,  CURRENT_TIMESTAMP(),  'SUCCESS',  :V_LAST_QUERY_ID,  :V_ROWS_PARSED,  :V_ROWS_LOADED,  NULL,  NULL,  NULL);      


    --------------------------------------------------------------------------
    V_STEP := 'STEP3';
    V_STEP_NAME :=  'create '||V_SMITTA40_UW_DASHBOARD_DATA_UW_APPS;
    V_START_TIME := CONVERT_TIMEZONE('America/Chicago', CURRENT_TIMESTAMP());

    CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_DATA_UW_APPS) COPY GRANTS AS 

    SELECT *, case 
      when ((UW_PRDCT_RQR IS NULL AND ADJUDICATION_CD IN ('D','W','P') AND UW_MANUALLY_REVIEWED_1='Y')
    OR UW_PRDCT_RQR='UW'
    OR POS_REASON!='Other') then 'Y' 
    ELSE 'N'
    end  as UW_APP_FLAG,
    case 
      when UPPER(appl_mechanism_description) IN ('WEB','INTERFACE') then 'WEB' ELSE UPPER(appl_mechanism_description) end as APPL_MECH_DESC
    FROM  IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_UW_MANUALLY_REVIEWED)
    where MS_INSURED_AT_APP='N' and appl_receipt_date>=date '2022-01-01';

    V_ROWS_LOADED   :=  (select  count(1)  from  IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_DATA_UW_APPS))  ;
    V_LAST_QUERY_ID :=  (SELECT  LAST_QUERY_ID(-2))  ;
    CALL  IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL)  (:DB_NAME,  :UTIL_SC,  'DEEP',  :PIPELINE_ID,  :PIPELINE_NAME,  :V_PROCESS_NAME,  :V_SUB_PROCESS_NAME,
                     :V_STEP,  :V_STEP_NAME,  :V_START_TIME,  CURRENT_TIMESTAMP(),  'SUCCESS',  :V_LAST_QUERY_ID,  :V_ROWS_PARSED,  :V_ROWS_LOADED,  NULL,  NULL,  NULL);      


    ---------------------------------------------------------------------------

    V_STEP := 'STEP4';
    V_STEP_NAME :=  'create '||V_SMITTA40_UW_DASHBOARD_AUTO_MANUAL;
    V_START_TIME := CONVERT_TIMEZONE('America/Chicago', CURRENT_TIMESTAMP());

	CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_AUTO_MANUAL) COPY GRANTS AS 

    SELECT *,YEAR(appl_receipt_date::DATE) as YEAR_DATE,MONTH(appl_receipt_date::DATE) as MONTH_DATE,CASE
      WHEN TYPE_ID=2053 AND UW_MANUALLY_REVIEWED_1='N' AND TOUCHED_BY_ENROLLMENT='N' AND POS_REASON!='Other' THEN 'Auto Adjudicated App'
      WHEN TOUCHED_BY_ENROLLMENT='N' and RTUW_AUTO_BASE_RATE='Y' AND AUTO_ADJUDICATED_APP_FLAG='Manual App'  THEN 'Auto Adjudicated App'
      ELSE AUTO_ADJUDICATED_APP_FLAG
      END as AUTO_MANUAL_APP 
      FROM IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_DATA_UW_APPS);
      
    V_ROWS_LOADED   :=  (select  count(1)  from  IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_AUTO_MANUAL))  ;
    V_LAST_QUERY_ID :=  (SELECT  LAST_QUERY_ID(-2))  ;
    CALL  IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL)  (:DB_NAME,  :UTIL_SC,  'DEEP',  :PIPELINE_ID,  :PIPELINE_NAME,  :V_PROCESS_NAME,  :V_SUB_PROCESS_NAME,
                     :V_STEP,  :V_STEP_NAME,  :V_START_TIME,  CURRENT_TIMESTAMP(),  'SUCCESS',  :V_LAST_QUERY_ID,  :V_ROWS_PARSED,  :V_ROWS_LOADED,  NULL,  NULL,  NULL);      
      
    ----------------------------------------------SUB_AUTO_ADJUDICATED_APPS----------------------------

    V_STEP := 'STEP5';
    V_STEP_NAME :=  'create '||V_SMITTA40_UW_DASHBOARD_DATA_SUBTOTAL_AUTO;
    V_START_TIME := CONVERT_TIMEZONE('America/Chicago', CURRENT_TIMESTAMP());

    CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_DATA_SUBTOTAL_AUTO) COPY GRANTS AS 
    SELECT *, CASE 
      WHEN AUTO_MANUAL_APP ='Manual App' AND TOUCHED_BY_ENROLLMENT='Y' AND RTUW_AUTO_BASE_RATE='Y' AND UW_MANUALLY_REVIEWED_1='N' AND POS_REASON='Other'
      THEN 'SUBTOTAL_1'
      WHEN AUTO_MANUAL_APP ='Manual App' AND TOUCHED_BY_ENROLLMENT='Y' AND AUTO_RATED='Y' AND UW_MANUALLY_REVIEWED_1='N' AND POS_REASON='Other'
      THEN 'SUBTOTAL_2'
      WHEN AUTO_MANUAL_APP ='Manual App' AND reason_text='UW SELF DISCLOSED CONDITION AUTO-ACCEPTED AT LEVEL 2 RATE' AND UW_MANUALLY_REVIEWED_1='N' 
      AND TOUCHED_BY_ENROLLMENT='Y' THEN 'SUBTOTAL_3'
      WHEN AUTO_MANUAL_APP ='Manual App' AND reason_text='AUTO DENY SELF DISCLOSED CONDITION' AND  UW_MANUALLY_REVIEWED_1='N' 
      AND TOUCHED_BY_ENROLLMENT='Y' THEN 'SUBTOTAL_4'
      WHEN AUTO_MANUAL_APP ='Manual App' AND reason_text='UW IRIX AUTO-ACCEPTED AT LEVEL 2 RATE' AND  UW_MANUALLY_REVIEWED_1='N' 
      AND TOUCHED_BY_ENROLLMENT='Y' THEN 'SUBTOTAL_5' 
      WHEN AUTO_MANUAL_APP ='Manual App' AND reason_text='AUTO DENY DUE TO IRIX' AND  UW_MANUALLY_REVIEWED_1='N' 
      AND TOUCHED_BY_ENROLLMENT='Y' THEN 'SUBTOTAL_6' 
      END AS SUB_TOTAL_AUTO
      FROM IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_AUTO_MANUAL);
      
    V_ROWS_LOADED   :=  (select  count(1)  from  IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_DATA_SUBTOTAL_AUTO))  ;
    V_LAST_QUERY_ID :=  (SELECT  LAST_QUERY_ID(-2))  ;
    CALL  IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL)  (:DB_NAME,  :UTIL_SC,  'DEEP',  :PIPELINE_ID,  :PIPELINE_NAME,  :V_PROCESS_NAME,  :V_SUB_PROCESS_NAME,
                     :V_STEP,  :V_STEP_NAME,  :V_START_TIME,  CURRENT_TIMESTAMP(),  'SUCCESS',  :V_LAST_QUERY_ID,  :V_ROWS_PARSED,  :V_ROWS_LOADED,  NULL,  NULL,  NULL);      


    ----------------------------------SUBTOTAL_AUTO---------------------------------------

    V_STEP := 'STEP6';
    V_STEP_NAME :=  'create '||V_SMITTA40_SUB_TOTAL_AUTO_DECISIONED;
    V_START_TIME := CONVERT_TIMEZONE('America/Chicago', CURRENT_TIMESTAMP());	

      CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_SMITTA40_SUB_TOTAL_AUTO_DECISIONED) COPY GRANTS as 
      SELECT SUM(SUB) as SUB_TOTAL ,year_date,month_date,APPL_MECH_DESC,AUTO_MANUAL_APP,UW_APP_FLAG,MS_INSURED_AT_APP from 
      (
      SELECT COUNT(DISTINCT APPLICATION_ID) as SUB,year_date,month_date,APPL_MECH_DESC,AUTO_MANUAL_APP,UW_APP_FLAG,MS_INSURED_AT_APP fROM IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_DATA_SUBTOTAL_AUTO)
      WHERE SUB_TOTAL_AUTO IN ('SUBTOTAL_1') and UW_APP_FLAG='Y'
      group by year_date,month_date,APPL_MECH_DESC,AUTO_MANUAL_APP,UW_APP_FLAG,MS_INSURED_AT_APP
      UNION ALL 
      SELECT COUNT(DISTINCT APPLICATION_ID) as SUB,year_date,month_date,APPL_MECH_DESC,AUTO_MANUAL_APP,UW_APP_FLAG,MS_INSURED_AT_APP fROM IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_DATA_SUBTOTAL_AUTO)
      WHERE SUB_TOTAL_AUTO IN ('SUBTOTAL_2') and UW_APP_FLAG='Y'
      group by year_date,month_date,APPL_MECH_DESC,AUTO_MANUAL_APP,UW_APP_FLAG,MS_INSURED_AT_APP
      UNION ALL 
      SELECT COUNT(DISTINCT APPLICATION_ID) as SUB,year_date,month_date,APPL_MECH_DESC,AUTO_MANUAL_APP,UW_APP_FLAG,MS_INSURED_AT_APP fROM IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_DATA_SUBTOTAL_AUTO)
      WHERE SUB_TOTAL_AUTO IN ('SUBTOTAL_3') and UW_APP_FLAG='Y'
      group by year_date,month_date,APPL_MECH_DESC,AUTO_MANUAL_APP,UW_APP_FLAG,MS_INSURED_AT_APP
      UNION ALL 
      SELECT COUNT(DISTINCT APPLICATION_ID) as SUB,year_date,month_date,APPL_MECH_DESC,AUTO_MANUAL_APP,UW_APP_FLAG,MS_INSURED_AT_APP fROM IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_DATA_SUBTOTAL_AUTO)
      WHERE SUB_TOTAL_AUTO IN ('SUBTOTAL_4') and UW_APP_FLAG='Y'
      group by year_date,month_date,APPL_MECH_DESC,AUTO_MANUAL_APP,UW_APP_FLAG,MS_INSURED_AT_APP
      UNION ALL 
      SELECT COUNT(DISTINCT APPLICATION_ID) as SUB,year_date,month_date,APPL_MECH_DESC,AUTO_MANUAL_APP,UW_APP_FLAG,MS_INSURED_AT_APP fROM IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_DATA_SUBTOTAL_AUTO)
      WHERE SUB_TOTAL_AUTO IN ('SUBTOTAL_5') and UW_APP_FLAG='Y'
      group by year_date,month_date,APPL_MECH_DESC,AUTO_MANUAL_APP,UW_APP_FLAG,MS_INSURED_AT_APP
      UNION ALL 
      SELECT COUNT(DISTINCT APPLICATION_ID) as SUB,year_date,month_date,APPL_MECH_DESC,AUTO_MANUAL_APP,UW_APP_FLAG,MS_INSURED_AT_APP fROM IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_DATA_SUBTOTAL_AUTO)
      WHERE SUB_TOTAL_AUTO IN ('SUBTOTAL_6') and UW_APP_FLAG='Y'
      group by year_date,month_date,APPL_MECH_DESC,AUTO_MANUAL_APP,UW_APP_FLAG,MS_INSURED_AT_APP
      
      ) A group by year_date,month_date,APPL_MECH_DESC,AUTO_MANUAL_APP,UW_APP_FLAG,MS_INSURED_AT_APP;
      
    V_ROWS_LOADED   :=  (select  count(1)  from  IDENTIFIER(:V_SMITTA40_SUB_TOTAL_AUTO_DECISIONED))  ;
    V_LAST_QUERY_ID :=  (SELECT  LAST_QUERY_ID(-2))  ;
    CALL  IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL)  (:DB_NAME,  :UTIL_SC,  'DEEP',  :PIPELINE_ID,  :PIPELINE_NAME,  :V_PROCESS_NAME,  :V_SUB_PROCESS_NAME,
                     :V_STEP,  :V_STEP_NAME,  :V_START_TIME,  CURRENT_TIMESTAMP(),  'SUCCESS',  :V_LAST_QUERY_ID,  :V_ROWS_PARSED,  :V_ROWS_LOADED,  NULL,  NULL,  NULL);      

      
    ---------------------------  AUTO DECISIONED-----------------------------------

    V_STEP := 'STEP7';
    V_STEP_NAME :=  'create '||V_SMITTA40_UW_DASHBOARD_AUTO_DECISIONED;
    V_START_TIME := CONVERT_TIMEZONE('America/Chicago', CURRENT_TIMESTAMP());	
		
    CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_AUTO_DECISIONED) COPY GRANTS as 
      SELECT SUM(AUTO) AS AUTO_DECISIONED,year_date,month_date,APPL_MECH_DESC,AUTO_MANUAL_APP,UW_APP_FLAG,MS_INSURED_AT_APP from 
    (
    SELECT COUNT(DISTINCT APPLICATION_ID) as AUTO,year_date,month_date,APPL_MECH_DESC,AUTO_MANUAL_APP,UW_APP_FLAG,MS_INSURED_AT_APP  FROM   
    IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_AUTO_MANUAL)
    where AUTO_MANUAL_APP='Auto Adjudicated App'
    GROUP BY year_date,month_date,APPL_MECH_DESC,AUTO_MANUAL_APP,UW_APP_FLAG,MS_INSURED_AT_APP
    UNION ALL
    SELECT SUM(SUB_TOTAL) as AUTO,year_date,month_date,APPL_MECH_DESC,AUTO_MANUAL_APP,UW_APP_FLAG,MS_INSURED_AT_APP from IDENTIFIER(:V_SMITTA40_SUB_TOTAL_AUTO_DECISIONED)
    GROUP BY year_date,month_date,APPL_MECH_DESC,AUTO_MANUAL_APP,UW_APP_FLAG,MS_INSURED_AT_APP
      ) A GROUP BY year_date,month_date,APPL_MECH_DESC,AUTO_MANUAL_APP,UW_APP_FLAG,MS_INSURED_AT_APP;
      
    V_ROWS_LOADED   :=  (select  count(1)  from  IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_AUTO_DECISIONED))  ;
    V_LAST_QUERY_ID :=  (SELECT  LAST_QUERY_ID(-2))  ;
    CALL  IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL)  (:DB_NAME,  :UTIL_SC,  'DEEP',  :PIPELINE_ID,  :PIPELINE_NAME,  :V_PROCESS_NAME,  :V_SUB_PROCESS_NAME,
                     :V_STEP,  :V_STEP_NAME,  :V_START_TIME,  CURRENT_TIMESTAMP(),  'SUCCESS',  :V_LAST_QUERY_ID,  :V_ROWS_PARSED,  :V_ROWS_LOADED,  NULL,  NULL,  NULL);      



    ----------------------------------POS MANUAL_SUB----------------------------------

    V_STEP := 'STEP8';
    V_STEP_NAME :=  'create '||V_SMITTA40_UW_DASHBOARD_POS_MANUAL_SUB;
    V_START_TIME := CONVERT_TIMEZONE('America/Chicago', CURRENT_TIMESTAMP());	
		
    CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_POS_MANUAL_SUB) COPY GRANTS as 
      SELECT *,
    CASE 
      WHEN AUTO_MANUAL_APP ='Manual App' AND TOUCHED_BY_ENROLLMENT='N' AND POS_UW='Y' THEN 'POS_MANUAL_1'
      WHEN  AUTO_MANUAL_APP ='Manual App' AND TOUCHED_BY_ENROLLMENT='Y' AND POS_UW='Y' THEN 'POS_MANUAL_2'
      END as POS_MANUAL_FILTER
        FROM  IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_AUTO_MANUAL)  ;

    V_ROWS_LOADED   :=  (select  count(1)  from  IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_POS_MANUAL_SUB))  ;
    V_LAST_QUERY_ID :=  (SELECT  LAST_QUERY_ID(-2))  ;
    CALL  IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL)  (:DB_NAME,  :UTIL_SC,  'DEEP',  :PIPELINE_ID,  :PIPELINE_NAME,  :V_PROCESS_NAME,  :V_SUB_PROCESS_NAME,
                     :V_STEP,  :V_STEP_NAME,  :V_START_TIME,  CURRENT_TIMESTAMP(),  'SUCCESS',  :V_LAST_QUERY_ID,  :V_ROWS_PARSED,  :V_ROWS_LOADED,  NULL,  NULL,  NULL);      

    ---------------------------------POS_MANUAL_TOTAL---------------------------------------

    V_STEP := 'STEP9';
    V_STEP_NAME :=  'create '||V_SMITTA40_UW_DASHBOARD_POS_MANUAL;
    V_START_TIME := CONVERT_TIMEZONE('America/Chicago', CURRENT_TIMESTAMP());	
		
    CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_POS_MANUAL) COPY GRANTS AS 
      SELECT SUM(POS_MANUAL_SUB) as POS_MANUAL,year_date,month_date,APPL_MECH_DESC,AUTO_MANUAL_APP,UW_APP_FLAG,MS_INSURED_AT_APP FROM 
    (
    SELECT COUNT(DISTINCT APPLICATION_ID) as POS_MANUAL_SUB,year_date,month_date,APPL_MECH_DESC,AUTO_MANUAL_APP,UW_APP_FLAG,MS_INSURED_AT_APP from IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_POS_MANUAL_SUB)
    WHERE POS_MANUAL_FILTER ='POS_MANUAL_1' and UW_APP_FLAG='Y'
    GROUP BY year_date,month_date,APPL_MECH_DESC,AUTO_MANUAL_APP,UW_APP_FLAG,MS_INSURED_AT_APP
    UNION ALL 
    SELECT COUNT(DISTINCT APPLICATION_ID) as POS_MANUAL_SUB,year_date,month_date,APPL_MECH_DESC,AUTO_MANUAL_APP,UW_APP_FLAG,MS_INSURED_AT_APP from IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_POS_MANUAL_SUB)
    WHERE POS_MANUAL_FILTER ='POS_MANUAL_2' and UW_APP_FLAG='Y'
    GROUP BY year_date,month_date,APPL_MECH_DESC,AUTO_MANUAL_APP,UW_APP_FLAG,MS_INSURED_AT_APP
    ) A GROUP BY year_date,month_date,APPL_MECH_DESC,AUTO_MANUAL_APP,UW_APP_FLAG,MS_INSURED_AT_APP;

    V_ROWS_LOADED   :=  (select  count(1)  from  IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_POS_MANUAL))  ;
    V_LAST_QUERY_ID :=  (SELECT  LAST_QUERY_ID(-2))  ;
    CALL  IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL)  (:DB_NAME,  :UTIL_SC,  'DEEP',  :PIPELINE_ID,  :PIPELINE_NAME,  :V_PROCESS_NAME,  :V_SUB_PROCESS_NAME,
                     :V_STEP,  :V_STEP_NAME,  :V_START_TIME,  CURRENT_TIMESTAMP(),  'SUCCESS',  :V_LAST_QUERY_ID,  :V_ROWS_PARSED,  :V_ROWS_LOADED,  NULL,  NULL,  NULL);      



    --------------------------------MANUAL_SUB-----------------------------------------------

    V_STEP := 'STEP10';
    V_STEP_NAME :=  'create '||V_SMITTA40_UW_DASHBOARD_MANUAL_SUB;
    V_START_TIME := CONVERT_TIMEZONE('America/Chicago', CURRENT_TIMESTAMP());	
		
    CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_MANUAL_SUB) COPY GRANTS AS 
    SELECT *,CASE 
      WHEN AUTO_MANUAL_APP ='Manual App' AND TOUCHED_BY_ENROLLMENT='N' AND POS_REASON!='Other' THEN 'MANUAL_1'
      WHEN  AUTO_MANUAL_APP ='Manual App' AND TOUCHED_BY_ENROLLMENT='N' AND (NOT POS_UW='Y') and RTUW_AUTO_BASE_RATE='N' and POS_REASON='Other' THEN 'MANUAL_2'
      WHEN AUTO_MANUAL_APP ='Manual App' AND TOUCHED_BY_ENROLLMENT='Y' THEN 'MANUAL_3'
      END as MANUAL_FILTER,
      CASE 
        WHEN AUTO_MANUAL_APP ='Manual App' AND TOUCHED_BY_ENROLLMENT='Y' AND POS_UW='Y' THEN 'MANUAL_4'
        END AS MANUAL_FILTER1
      
      FROM 
        
      IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_AUTO_MANUAL);
      
     V_ROWS_LOADED   :=  (select  count(1)  from  IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_MANUAL_SUB))  ;
    V_LAST_QUERY_ID :=  (SELECT  LAST_QUERY_ID(-2))  ;
    CALL  IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL)  (:DB_NAME,  :UTIL_SC,  'DEEP',  :PIPELINE_ID,  :PIPELINE_NAME,  :V_PROCESS_NAME,  :V_SUB_PROCESS_NAME,
                     :V_STEP,  :V_STEP_NAME,  :V_START_TIME,  CURRENT_TIMESTAMP(),  'SUCCESS',  :V_LAST_QUERY_ID,  :V_ROWS_PARSED,  :V_ROWS_LOADED,  NULL,  NULL,  NULL);      
     
    ---------------------------MANUAL_TOTAL---------------------------------------------------

    V_STEP := 'STEP11';
    V_STEP_NAME :=  'create '||V_SMITTA40_UW_DASHBOARD_MANUAL1;
    V_START_TIME := CONVERT_TIMEZONE('America/Chicago', CURRENT_TIMESTAMP());	
		
    CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_MANUAL1) as  
    SELECT COUNT(DISTINCT APPLICATION_ID) as MANUAL_SUB,year_date,month_date,APPL_MECH_DESC,AUTO_MANUAL_APP,UW_APP_FLAG,MS_INSURED_AT_APP FROM 
    IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_MANUAL_SUB)    
    WHERE MANUAL_FILTER = 'MANUAL_3' and UW_APP_FLAG='Y'
    GROUP BY year_date,month_date,APPL_MECH_DESC,AUTO_MANUAL_APP,UW_APP_FLAG,MS_INSURED_AT_APP;

    V_ROWS_LOADED   :=  (select  count(1)  from  IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_MANUAL1))  ;
    V_LAST_QUERY_ID :=  (SELECT  LAST_QUERY_ID(-2))  ;
    CALL  IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL)  (:DB_NAME,  :UTIL_SC,  'DEEP',  :PIPELINE_ID,  :PIPELINE_NAME,  :V_PROCESS_NAME,  :V_SUB_PROCESS_NAME,
                     :V_STEP,  :V_STEP_NAME,  :V_START_TIME,  CURRENT_TIMESTAMP(),  'SUCCESS',  :V_LAST_QUERY_ID,  :V_ROWS_PARSED,  :V_ROWS_LOADED,  NULL,  NULL,  NULL);      


    -----------------------------MANUAL_OTHER-----------------------------------------------

    V_STEP := 'STEP12';
    V_STEP_NAME :=  'create '||V_SMITTA40_UW_DASHBOARD_MANUAL2;
    V_START_TIME := CONVERT_TIMEZONE('America/Chicago', CURRENT_TIMESTAMP());	
		
    CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_MANUAL2) COPY GRANTS as 

    SELECT SUM(SUB_TOTAL) as SUB_TOTAL,year_date,month_date,APPL_MECH_DESC,AUTO_MANUAL_APP,UW_APP_FLAG,MS_INSURED_AT_APP from 
    (
      SELECT SUM(SUB_TOTAL)  as sub_total,year_date,month_date,APPL_MECH_DESC,AUTO_MANUAL_APP,UW_APP_FLAG,MS_INSURED_AT_APP 
    FROM IDENTIFIER(:V_SMITTA40_SUB_TOTAL_AUTO_DECISIONED)
      GROUP BY year_date,month_date,APPL_MECH_DESC,AUTO_MANUAL_APP,UW_APP_FLAG,MS_INSURED_AT_APP
    UNION ALL    
    SELECT COUNT(DISTINCT APPLICATION_ID) as sub_total,year_date,month_date,APPL_MECH_DESC,AUTO_MANUAL_APP,UW_APP_FLAG,MS_INSURED_AT_APP  FROM IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_MANUAL_SUB)    
    WHERE MANUAL_FILTER1 = 'MANUAL_4' and UW_APP_FLAG='Y'
      GROUP BY year_date,month_date,APPL_MECH_DESC,AUTO_MANUAL_APP,UW_APP_FLAG,MS_INSURED_AT_APP
      
      ) A GROUP BY year_date,month_date,APPL_MECH_DESC,AUTO_MANUAL_APP,UW_APP_FLAG,MS_INSURED_AT_APP;
      
    V_ROWS_LOADED   :=  (select  count(1)  from  IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_MANUAL2))  ;
    V_LAST_QUERY_ID :=  (SELECT  LAST_QUERY_ID(-2))  ;
    CALL  IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL)  (:DB_NAME,  :UTIL_SC,  'DEEP',  :PIPELINE_ID,  :PIPELINE_NAME,  :V_PROCESS_NAME,  :V_SUB_PROCESS_NAME,
                     :V_STEP,  :V_STEP_NAME,  :V_START_TIME,  CURRENT_TIMESTAMP(),  'SUCCESS',  :V_LAST_QUERY_ID,  :V_ROWS_PARSED,  :V_ROWS_LOADED,  NULL,  NULL,  NULL);      


    ---------------------------- MANUAL_FINAL-----------------------------------------------------

    V_STEP := 'STEP13';
    V_STEP_NAME :=  'create '||V_SMITTA40_UW_DASHBOARD_MANUAL;
    V_START_TIME := CONVERT_TIMEZONE('America/Chicago', CURRENT_TIMESTAMP());	
		
    CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_MANUAL) COPY GRANTS as 

      SELECT SUM(MANUAL) as MANUAL,year_date,month_date,APPL_MECH_DESC,AUTO_MANUAL_APP,UW_APP_FLAG,MS_INSURED_AT_APP from 
    (
    SELECT SUM((m1.MANUAL_SUB)-(m2.SUB_TOTAL)) as MANUAL,m1.year_date,m1.month_date,m1.APPL_MECH_DESC,m1.AUTO_MANUAL_APP,m1.UW_APP_FLAG,m1.MS_INSURED_AT_APP from 
    IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_MANUAL1) m1 LEFT JOIN 
    IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_MANUAL2) m2 on 
    m1.year_date=m2.year_date and m1.month_date=m2.month_date
    and m1.auto_manual_app=m2.auto_manual_app and m1.uw_app_flag=m2.uw_app_flag and m1.ms_insured_at_app=m2.ms_insured_at_app
    and m1.appl_mech_desc=m2.appl_mech_desc
    GROUP BY m1.year_date,m1.month_date,m1.APPL_MECH_DESC,m1.AUTO_MANUAL_APP,m1.UW_APP_FLAG,m1.MS_INSURED_AT_APP
    UNION ALL 
    SELECT COUNT(DISTINCT APPLICATION_ID) as MANUAL,year_date,month_date,APPL_MECH_DESC,AUTO_MANUAL_APP,UW_APP_FLAG,MS_INSURED_AT_APP
    FROM IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_MANUAL_SUB)    
    WHERE MANUAL_FILTER IN ( 'MANUAL_1','MANUAL_2') and UW_APP_FLAG='Y'
    GROUP BY year_date,month_date,APPL_MECH_DESC,AUTO_MANUAL_APP,UW_APP_FLAG,MS_INSURED_AT_APP
    ) A GROUP BY year_date,month_date,APPL_MECH_DESC,AUTO_MANUAL_APP,UW_APP_FLAG,MS_INSURED_AT_APP;

    V_ROWS_LOADED   :=  (select  count(1)  from  IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_MANUAL))  ;
    V_LAST_QUERY_ID :=  (SELECT  LAST_QUERY_ID(-2))  ;
    CALL  IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL)  (:DB_NAME,  :UTIL_SC,  'DEEP',  :PIPELINE_ID,  :PIPELINE_NAME,  :V_PROCESS_NAME,  :V_SUB_PROCESS_NAME,
                     :V_STEP,  :V_STEP_NAME,  :V_START_TIME,  CURRENT_TIMESTAMP(),  'SUCCESS',  :V_LAST_QUERY_ID,  :V_ROWS_PARSED,  :V_ROWS_LOADED,  NULL,  NULL,  NULL);      

    --------------------------------------NON UW APPS_NEW_REQ_ADD---------------------------------------------- 

    V_STEP := 'STEP14';
    V_STEP_NAME :=  'create '||V_SMITTA40_NON_UW_APPS;
    V_START_TIME := CONVERT_TIMEZONE('America/Chicago', CURRENT_TIMESTAMP());	
		 
    CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_SMITTA40_NON_UW_APPS) COPY GRANTS AS 
    SELECT count(application_id ) as apps,year_date,month_date,APPL_MECH_DESC,AUTO_MANUAL_APP,UW_APP_FLAG,MS_INSURED_AT_APP
    from IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_AUTO_MANUAL)
    where UW_APP_FLAG='N'
    group by year_date,month_date,APPL_MECH_DESC,AUTO_MANUAL_APP,UW_APP_FLAG,MS_INSURED_AT_APP;

    V_ROWS_LOADED   :=  (select  count(1)  from  IDENTIFIER(:V_SMITTA40_NON_UW_APPS))  ;
    V_LAST_QUERY_ID :=  (SELECT  LAST_QUERY_ID(-2))  ;
    CALL  IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL)  (:DB_NAME,  :UTIL_SC,  'DEEP',  :PIPELINE_ID,  :PIPELINE_NAME,  :V_PROCESS_NAME,  :V_SUB_PROCESS_NAME,
                     :V_STEP,  :V_STEP_NAME,  :V_START_TIME,  CURRENT_TIMESTAMP(),  'SUCCESS',  :V_LAST_QUERY_ID,  :V_ROWS_PARSED,  :V_ROWS_LOADED,  NULL,  NULL,  NULL);      


    -----------------------------------FINAL TABLE ------------------------------------------

    V_STEP := 'STEP15';
    V_STEP_NAME :=  'create '||V_common_KPI_COMPILATION_NEW_ENROLL_APPS;
    V_START_TIME := CONVERT_TIMEZONE('America/Chicago', CURRENT_TIMESTAMP());	
		
    CREATE OR REPLACE TABLE IDENTIFIER(:V_common_KPI_COMPILATION_NEW_ENROLL_APPS)
    COPY GRANTS  as 

    SELECT auto_decisioned as apps ,'AUTO_DECSIONED' as UW_CATEGORY,year_date,month_date ,appl_mech_desc,case auto_manual_app
    when 'Manual App' then 'N'
    when 'Auto Adjudicated App' then 'Y'
    end as auto_adj_app_flag,uw_app_flag ,ms_insured_at_app  
    FROM IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_AUTO_DECISIONED)
    where uw_app_flag='Y'
    UNION ALL 
    select pos_manual as apps,'POS_MANUAL' as UW_CATEGORY,year_date,month_date,appl_mech_desc,case auto_manual_app
    when 'Manual App' then 'N'
    when 'Auto Adjudicated App' then 'Y'
    end as auto_adj_app_flag,uw_app_flag ,ms_insured_at_app 
    from IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_POS_MANUAL)
    UNION ALL 
    select manual as apps,'MANUAL' as UW_CATEGORY,year_date,month_date,appl_mech_desc,case auto_manual_app
    when 'Manual App' then 'N'
    when 'Auto Adjudicated App' then 'Y'
    end as auto_adj_app_flag,uw_app_flag ,ms_insured_at_app  from IDENTIFIER(:V_SMITTA40_UW_DASHBOARD_MANUAL) 
    UNION ALL 
    select apps,'NA' as UW_CATEGORY,year_date,month_date,appl_mech_desc,case auto_manual_app
    when 'Manual App' then 'N'
    when 'Auto Adjudicated App' then 'Y'
    end as auto_adj_app_flag,uw_app_flag ,ms_insured_at_app  from IDENTIFIER(:V_SMITTA40_NON_UW_APPS);

    V_ROWS_LOADED   :=  (select  count(1)  from  IDENTIFIER(:V_common_KPI_COMPILATION_NEW_ENROLL_APPS))  ;
    V_LAST_QUERY_ID :=  (SELECT  LAST_QUERY_ID(-2))  ;
    CALL  IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL)  (:DB_NAME,  :UTIL_SC,  'DEEP',  :PIPELINE_ID,  :PIPELINE_NAME,  :V_PROCESS_NAME,  :V_SUB_PROCESS_NAME,
                     :V_STEP,  :V_STEP_NAME,  :V_START_TIME,  CURRENT_TIMESTAMP(),  'SUCCESS',  :V_LAST_QUERY_ID,  :V_ROWS_PARSED,  :V_ROWS_LOADED,  NULL,  NULL,  NULL);      

    ---------------------------------------------TAT CODE-------------------------------------------------

    V_STEP := 'STEP16';
    V_STEP_NAME :=  'create '||V_SMITTA40_KPI_ENROLL_TAT_1;
    V_START_TIME := CONVERT_TIMEZONE('America/Chicago', CURRENT_TIMESTAMP());	
		


    CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_smitta40_KPI_ENROLL_TAT_1) COPY GRANTS as
    
    select * from (
    select a.application_id, a.individual_id, aa.APPLICATION_ACTOR_DESCRIPTION, chct.CONTACT_TYPE_DESC, am.APPL_MECHANISM_DESCRIPTION, a.appl_receipt_date, a.adjudication_date, a.adjudication_cd, awqri.tracking_number, awqh_1.type_id, wqt.type_desc,
      case when wqt.type_id in (2023, 2035, 2039, 2040, 2042, 2043, 2047, 2048, 2049, 2050, 2051, 2052, 2053, 2054, 2055) then 'UNDERWRITING'
          when wqt.type_id in (2003, 2029) then 'GRS'
          when wqt.type_id = 2032 then 'VENDOR MANAGEMENT'
          else wqf.family_desc
          end as family_desc,
      max(ip.insured_plan_effective_date) as ip_eff_date,
      max(nvl(TO_DATE(ip.insured_plan_termination_date), date '9999-01-01')) as ip_term_date,
      ip.termination_reason_id, ip.conservation_reason_id,
      --nvl(awqh_2.time_stamp, awqh_1.completed_date) as x,
      --awqh_1.time_stamp as y,
      --awqh_2.time_stamp,awqh_1.completed_date,
      -- DATEDIFF( (nvl(awqh_2.time_stamp, awqh_1.completed_date)),awqh_1.time_stamp) as time_spent
      --  SUM((unix_timestamp(nvl(awqh_2.time_stamp, awqh_1.completed_date))-unix_timestamp(awqh_1.time_stamp))/3600) AS HOUR_DIFFERENCE
      SUM(datediff(hour,awqh_1.time_stamp,nvl(awqh_2.time_stamp, awqh_1.completed_date))) AS HOUR_DIFFERENCE
    from IDENTIFIER(:V_refined_compas_APPLICATION) a
    inner join IDENTIFIER(:V_refined_compas_ARC_WORK_QUEUE_REC_ID) awqri on a.application_id = awqri.identifier_value and awqri.identifier_type_id = 2011
    left join IDENTIFIER(:V_refined_compas_ARC_WORK_QUEUE_HISTORY) awqh_1 on awqh_1.tracking_number = awqri.tracking_number
                         -- and date_sub(a.appl_receipt_date,1) <= awqh_1.time_stamp
                         and dateadd(day,-1,a.appl_receipt_date) <= awqh_1.time_stamp
    left join IDENTIFIER(:V_refined_compas_ARC_WORK_QUEUE_HISTORY) awqh_2 on awqh_1.tracking_number = awqh_2.tracking_number and awqh_1.history_id = awqh_2.history_id - 1
    left join IDENTIFIER(:V_refined_compas_WORK_QUEUE_TYPE) wqt on awqh_1.type_id = wqt.type_id
    left join IDENTIFIER(:V_refined_compas_WORK_QUEUE_FAMILY) wqf on wqf.family_id = wqt.family_id
    left join IDENTIFIER(:V_refined_compas_APPLICATION_ACTOR) aa on a.APPL_ACTOR_ID = aa.APPLICATION_ACTOR_ID
    left join IDENTIFIER(:V_refined_compas_CONTACT_HIST_CONTACT_TYPE) chct on a.APPL_CHANNEL_ID = chct.CONTACT_TYPE_ID
    left join IDENTIFIER(:V_refined_compas_APPLICATION_MECHANISM) am on a.APPL_MECHANISM_ID = am.APPLICATION_MECHANISM_ID
    left join (select individual_id, application_id, termination_reason_id, conservation_reason_id,
    max(insured_plan_effective_date) as insured_plan_effective_date,
    max(nvl(TO_DATE(insured_plan_termination_date) , date '9999-01-01')) as insured_plan_termination_date
          from IDENTIFIER(:V_refined_compas_INSURED_PLAN)  
          where insured_plan_effective_date >= date '2019-01-01'
          group by  individual_id, application_id,termination_reason_id, conservation_reason_id ) ip on a.application_id = ip.application_id
    where extract(year from a.appl_receipt_date) >= 2020 and a.adjudication_cd <> 'P'
    group by a.application_id, a.individual_id, aa.APPLICATION_ACTOR_DESCRIPTION, chct.CONTACT_TYPE_DESC, am.APPL_MECHANISM_DESCRIPTION, a.appl_receipt_date, a.adjudication_date, a.adjudication_cd, awqri.tracking_number, awqh_1.type_id, wqt.type_desc,
      case when wqt.type_id in (2023, 2035, 2039, 2040, 2042, 2043, 2047, 2048, 2049, 2050, 2051, 2052, 2053, 2054, 2055) then 'UNDERWRITING'
          when wqt.type_id in (2003, 2029) then 'GRS'
          when wqt.type_id = 2032 then 'VENDOR MANAGEMENT'
          else wqf.family_desc  end,
          ip.termination_reason_id, ip.conservation_reason_id,awqh_1.time_stamp,awqh_2.time_stamp,awqh_1.completed_date
          --datediff(nvl(awqh_2.time_stamp, awqh_1.completed_date) , awqh_1.time_stamp)
        
    union
    
    select a.application_id, a.individual_id, aa.APPLICATION_ACTOR_DESCRIPTION, chct.CONTACT_TYPE_DESC, am.APPL_MECHANISM_DESCRIPTION, a.appl_receipt_date, a.adjudication_date, a.adjudication_cd, wqri.tracking_number, wqh_1.type_id, wqt.type_desc,
      case when wqt.type_id in (2023, 2035, 2039, 2040, 2042, 2043, 2047, 2048, 2049, 2050, 2051, 2052, 2053, 2054, 2055) then 'UNDERWRITING'
          when wqt.type_id in (2003, 2029) then 'GRS'
          when wqt.type_id = 2032 then 'VENDOR MANAGEMENT'
          else wqf.family_desc
          end as family_desc,
      max(ip.insured_plan_effective_date) as ip_eff_date,
      max(nvl(TO_DATE(ip.insured_plan_termination_date) , date '9999-01-01')) as ip_term_date, ip.termination_reason_id, ip.conservation_reason_id,
      --datediff(nvl(wqh_2.time_stamp, wqh_1.creation_date) , wqh_1.time_stamp) as time_spent
      --SUM((unix_timestamp(nvl(wqh_2.time_stamp, wqh_1.creation_date))-unix_timestamp(wqh_1.time_stamp))/3600) AS HOUR_DIFFERENCE
      SUM(datediff(hour,wqh_1.time_stamp,nvl(wqh_2.time_stamp, wqh_1.creation_date))) AS HOUR_DIFFERENCE

    from IDENTIFIER(:V_refined_compas_APPLICATION) a
    inner join IDENTIFIER(:V_refined_compas_WORK_QUEUE_REC_ID) wqri on a.application_id = wqri.identifier_value and wqri.identifier_type_id = 2011
    left join IDENTIFIER(:V_refined_compas_WORK_QUEUE_HISTORY) wqh_1 on wqh_1.tracking_number = wqri.tracking_number
                        --and date_sub(a.appl_receipt_date,1) <= wqh_1.time_stamp
                       and  dateadd(day,-1,a.appl_receipt_date) <= wqh_1.time_stamp
    left join IDENTIFIER(:V_refined_compas_WORK_QUEUE_HISTORY) wqh_2 on wqh_1.tracking_number = wqh_2.tracking_number and wqh_1.history_id = wqh_2.history_id - 1
    left join IDENTIFIER(:V_refined_compas_WORK_QUEUE_TYPE) wqt on wqh_1.type_id = wqt.type_id
    left join IDENTIFIER(:V_refined_compas_WORK_QUEUE_FAMILY) wqf on wqf.family_id = wqt.family_id
    left join IDENTIFIER(:V_refined_compas_APPLICATION_ACTOR) aa on a.APPL_ACTOR_ID = aa.APPLICATION_ACTOR_ID
    left join IDENTIFIER(:V_refined_compas_CONTACT_HIST_CONTACT_TYPE) chct on a.APPL_CHANNEL_ID = chct.CONTACT_TYPE_ID
    left join IDENTIFIER(:V_refined_compas_APPLICATION_MECHANISM) am on a.APPL_MECHANISM_ID = am.APPLICATION_MECHANISM_ID
    left join (select individual_id, application_id, termination_reason_id, conservation_reason_id, max(insured_plan_effective_date) as insured_plan_effective_date, max(nvl(TO_DATE(insured_plan_termination_date), date '9999-01-01')) as insured_plan_termination_date
          from IDENTIFIER(:V_refined_compas_INSURED_PLAN)  
          where insured_plan_effective_date >= date '2019-01-01'
          group by  individual_id, application_id,termination_reason_id, conservation_reason_id ) ip on a.application_id = ip.application_id
    where extract(year from a.appl_receipt_date) >= 2020 and a.adjudication_cd <> 'P'
    group by a.application_id, a.individual_id, aa.APPLICATION_ACTOR_DESCRIPTION, chct.CONTACT_TYPE_DESC, am.APPL_MECHANISM_DESCRIPTION, a.appl_receipt_date, a.adjudication_date, a.adjudication_cd, wqri.tracking_number, wqh_1.type_id, wqt.type_desc,
      case when wqt.type_id in (2023, 2035, 2039, 2040, 2042, 2043, 2047, 2048, 2049, 2050, 2051, 2052, 2053, 2054, 2055) then 'UNDERWRITING'
          when wqt.type_id in (2003, 2029) then 'GRS'
          when wqt.type_id = 2032 then 'VENDOR MANAGEMENT'
          else wqf.family_desc  end,
          ip.termination_reason_id, ip.conservation_reason_id,wqh_1.time_stamp,wqh_2.time_stamp,wqh_1.creation_date
    ) a;

    V_ROWS_LOADED   :=  (select  count(1)  from  IDENTIFIER(:V_SMITTA40_KPI_ENROLL_TAT_1))  ;
    V_LAST_QUERY_ID :=  (SELECT  LAST_QUERY_ID(-2))  ;
    CALL  IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL)  (:DB_NAME,  :UTIL_SC,  'DEEP',  :PIPELINE_ID,  :PIPELINE_NAME,  :V_PROCESS_NAME,  :V_SUB_PROCESS_NAME,
                     :V_STEP,  :V_STEP_NAME,  :V_START_TIME,  CURRENT_TIMESTAMP(),  'SUCCESS',  :V_LAST_QUERY_ID,  :V_ROWS_PARSED,  :V_ROWS_LOADED,  NULL,  NULL,  NULL);      


    -------------------------------------------------

    V_STEP := 'STEP17';
    V_STEP_NAME :=  'create '||V_smitta40_KPI_ENROLL_TAT2;
    V_START_TIME := CONVERT_TIMEZONE('America/Chicago', CURRENT_TIMESTAMP());	
	

    CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_smitta40_KPI_ENROLL_TAT2)
    COPY GRANTS as
    
    SELECT * FROM 
    (
    SELECT adjudication_date,
    
    AVG(TIME_SPENT) as time_spent
    FROM 
    (
    SELECT application_id,adjudication_date,family_desc,SUM(hour_difference) AS TIME_SPENT
    FROM 
    (
    
    select a.application_id, a.individual_id, a.APPLICATION_ACTOR_DESCRIPTION, a.CONTACT_TYPE_DESC, a.APPL_MECHANISM_DESCRIPTION, a.appl_receipt_date,
    a.adjudication_date, a.adjudication_cd, a.tracking_number, a.type_id, a.type_desc, 
        a.family_desc, a.ip_eff_date, a.ip_term_date,
        min(ip.insured_plan_effective_date) as min_ip_eff_date, min(ip.insured_plan_termination_date) as min_ip_term_date, 
        tr.termination_reason_name, r.reason_text, a.HOUR_DIFFERENCE
    from IDENTIFIER(:V_smitta40_KPI_ENROLL_TAT_1) a 
    left join IDENTIFIER(:V_refined_compas_INSURED_PLAN) ip on a.individual_id = ip.individual_id 
                    and datediff(day,ip.insured_plan_effective_date, a.ip_eff_date) between 0 and 63
                    and nvl(ip.insured_plan_termination_date, CAST('9999-01-01 00:00:00' AS TIMESTAMP)) > ip.insured_plan_effective_date
    left join IDENTIFIER(:V_refined_compas_TERMINATION_REASON) tr on tr.termination_reason_id = a.termination_reason_id                                
    left join IDENTIFIER(:V_refined_compas_REASON) r on r.reason_id = a.conservation_reason_id
    where a.family_desc='ENROLLMENT' and a.adjudication_cd IN ('A','D') AND a.type_desc NOT IN ('UW - Plan Changer','ENROLLMENT COMPLEX') 
    group by a.application_id, a.individual_id, a.APPLICATION_ACTOR_DESCRIPTION, a.CONTACT_TYPE_DESC, a.APPL_MECHANISM_DESCRIPTION,
    a.appl_receipt_date, a.adjudication_date, a.adjudication_cd, a.tracking_number, a.type_id, a.type_desc, 
        a.family_desc, a.ip_eff_date, a.ip_term_date ,tr.termination_reason_name, r.reason_text,A.HOUR_DIFFERENCE
        
        ) A GROUP BY application_id,adjudication_date,family_desc 
      )B   GROUP BY ADJUDICATION_DATE
    ) C;

    V_ROWS_LOADED   :=  (select  count(1)  from  IDENTIFIER(:V_smitta40_KPI_ENROLL_TAT2))  ;
    V_LAST_QUERY_ID :=  (SELECT  LAST_QUERY_ID(-2))  ;
    CALL  IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL)  (:DB_NAME,  :UTIL_SC,  'DEEP',  :PIPELINE_ID,  :PIPELINE_NAME,  :V_PROCESS_NAME,  :V_SUB_PROCESS_NAME,
                     :V_STEP,  :V_STEP_NAME,  :V_START_TIME,  CURRENT_TIMESTAMP(),  'SUCCESS',  :V_LAST_QUERY_ID,  :V_ROWS_PARSED,  :V_ROWS_LOADED,  NULL,  NULL,  NULL);      



    -----------------------------------------------------------------------------------

    V_STEP := 'STEP18';
    V_STEP_NAME :=  'create '||V_smitta40_KPI_ENROLL_TAT;
    V_START_TIME := CONVERT_TIMEZONE('America/Chicago', CURRENT_TIMESTAMP());	
		
    CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_smitta40_KPI_ENROLL_TAT) COPY GRANTS as
    select YEAR(adjudication_date) as year_date,quarter(adjudication_date) as quarter_date,(AVG(time_spent)/24) as time_spent_minutes
    from IDENTIFIER(:V_smitta40_KPI_ENROLL_TAT2)
    group by YEAR(adjudication_date),quarter(adjudication_date);

    V_ROWS_LOADED   :=  (select  count(1)  from  IDENTIFIER(:V_smitta40_KPI_ENROLL_TAT))  ;
    V_LAST_QUERY_ID :=  (SELECT  LAST_QUERY_ID(-2))  ;
    CALL  IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL)  (:DB_NAME,  :UTIL_SC,  'DEEP',  :PIPELINE_ID,  :PIPELINE_NAME,  :V_PROCESS_NAME,  :V_SUB_PROCESS_NAME,
                     :V_STEP,  :V_STEP_NAME,  :V_START_TIME,  CURRENT_TIMESTAMP(),  'SUCCESS',  :V_LAST_QUERY_ID,  :V_ROWS_PARSED,  :V_ROWS_LOADED,  NULL,  NULL,  NULL);      


    ---------------------------------------------------------------------------------------------------

    V_STEP := 'STEP19';
    V_STEP_NAME :=  'create '||V_common_KPI_ENROLL_TAT;
    V_START_TIME := CONVERT_TIMEZONE('America/Chicago', CURRENT_TIMESTAMP());	
		
    CREATE OR REPLACE TABLE IDENTIFIER(:V_common_KPI_ENROLL_TAT) COPY GRANTS as 
    select YEAR(adjudication_date) as year_date,quarter(adjudication_date) as quarter_date,(AVG(time_spent)/24) as time_spent_minutes
    from IDENTIFIER(:V_smitta40_KPI_ENROLL_TAT2)
    group by YEAR(adjudication_date),quarter(adjudication_date);

    V_ROWS_LOADED   :=  (select  count(1)  from  IDENTIFIER(:V_common_KPI_ENROLL_TAT))  ;
    V_LAST_QUERY_ID :=  (SELECT  LAST_QUERY_ID(-2))  ;
    CALL  IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL)  (:DB_NAME,  :UTIL_SC,  'DEEP',  :PIPELINE_ID,  :PIPELINE_NAME,  :V_PROCESS_NAME,  :V_SUB_PROCESS_NAME,
                     :V_STEP,  :V_STEP_NAME,  :V_START_TIME,  CURRENT_TIMESTAMP(),  'SUCCESS',  :V_LAST_QUERY_ID,  :V_ROWS_PARSED,  :V_ROWS_LOADED,  NULL,  NULL,  NULL);      


    ----------------------------------------------------------------------------------------

    V_STEP := 'STEP20';
    V_STEP_NAME :=  'create '||V_smitta40_AEP_UW_TAT1;
    V_START_TIME := CONVERT_TIMEZONE('America/Chicago', CURRENT_TIMESTAMP());	
		

    CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_smitta40_AEP_UW_TAT1) COPY GRANTS as
    SELECT completion_date,avg(tat) as tat FROM IDENTIFIER(:V_refined_apex_AUDIT_COMPLETED_VW) 
    where completion_date>='2021-01-01' and upper(outcome_type) in ('ACCEPT','DENY','RATE')
    group by completion_date;


    V_ROWS_LOADED   :=  (select  count(1)  from  IDENTIFIER(:V_smitta40_AEP_UW_TAT1))  ;
    V_LAST_QUERY_ID :=  (SELECT  LAST_QUERY_ID(-2))  ;
    CALL  IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL)  (:DB_NAME,  :UTIL_SC,  'DEEP',  :PIPELINE_ID,  :PIPELINE_NAME,  :V_PROCESS_NAME,  :V_SUB_PROCESS_NAME,
                     :V_STEP,  :V_STEP_NAME,  :V_START_TIME,  CURRENT_TIMESTAMP(),  'SUCCESS',  :V_LAST_QUERY_ID,  :V_ROWS_PARSED,  :V_ROWS_LOADED,  NULL,  NULL,  NULL);      


    -------------------------------------------------------------------------------------

    V_STEP := 'STEP21';
    V_STEP_NAME :=  'create '||V_smitta40_KPI_UW_TAT;
    V_START_TIME := CONVERT_TIMEZONE('America/Chicago', CURRENT_TIMESTAMP());	
		
    CREATE OR REPLACE TEMPORARY TABLE IDENTIFIER(:V_smitta40_KPI_UW_TAT) COPY GRANTS as
    SELECT year(completion_date) as TAT_Year,quarter(completion_date) as TAT_Quarter,avg(tat) as tat
    FROM IDENTIFIER(:V_smitta40_AEP_UW_TAT1)
    group by year(completion_date),quarter(completion_date);


    V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_smitta40_KPI_UW_TAT)) ;

    V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
    
    CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, 'DEEP', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                    :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), 'SUCCESS', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

    -----------------------------------------------------------------------


    V_STEP := 'STEP22';
    V_STEP_NAME :=  'create '||V_common_KPI_UW_TAT;
    V_START_TIME := CONVERT_TIMEZONE('America/Chicago', CURRENT_TIMESTAMP());	
	
    CREATE OR REPLACE TABLE IDENTIFIER(:V_common_KPI_UW_TAT) COPY GRANTS as
    SELECT year(completion_date) as TAT_Year,quarter(completion_date) as TAT_Quarter,avg(tat) as tat
    FROM IDENTIFIER(:V_smitta40_AEP_UW_TAT1)
    group by year(completion_date),quarter(completion_date);


    V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_common_KPI_UW_TAT)) ;

    V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
    
    CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, 'DEEP', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                    :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), 'SUCCESS', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

    ---------------------------------END-------------------------------------------------------



EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, 'DEEP', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), 'FAILED', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);


RAISE;

END;

$$
;