USE SCHEMA BDR_FFP_DA;





CREATE OR REPLACE PROCEDURE BDR_FFP_DA.SP_AEP_UW("PIPELINE_ID" VARCHAR(16777216), "PIPELINE_NAME" VARCHAR(16777216), "DB_NAME" VARCHAR(16777216), "UTIL_SC" VARCHAR(16777216), "TGT_SC" VARCHAR(16777216), "FFP_WRK_SC" VARCHAR(16777216), "SRC_SC" VARCHAR(16777216), "ONE_SC" VARCHAR(16777216), "TWO_SC" VARCHAR(16777216), "THREE_SC" VARCHAR(16777216), "WH" VARCHAR(16777216), "CURR_DATE" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE


V_CURRENT_DATE   DATE := COALESCE(TO_DATE(:CURR_DATE), CURRENT_DATE());


V_PREV_YEAR_FIRST_DATE DATE := (SELECT DATE_TRUNC(''YEAR'', DATEADD(YEAR, -1, CURRENT_DATE)));

V_CURR_YR_FIRST_DATE DATE := (SELECT DATE_TRUNC(''YEAR'', DATEADD(YEAR, -0, TO_DATE(:CURR_DATE))));
V_CURR_YR_1_FIRST_DATE DATE := (SELECT DATE_TRUNC(''YEAR'', DATEADD(YEAR, -1, TO_DATE(:CURR_DATE))));
V_CURR_YR_2_FIRST_DATE DATE := (SELECT DATE_TRUNC(''YEAR'', DATEADD(YEAR, -2, TO_DATE(:CURR_DATE))));
V_CURR_YR_3_FIRST_DATE DATE := (SELECT DATE_TRUNC(''YEAR'', DATEADD(YEAR, -3, TO_DATE(:CURR_DATE))));
V_CURR_YR_1_LAST_DATE DATE := LAST_DAY((SELECT DATE_TRUNC(''YEAR'', DATEADD(YEAR, -1, TO_DATE(:CURR_DATE)))),''YEAR'');
V_CURR_YR_2_LAST_DATE DATE := LAST_DAY((SELECT DATE_TRUNC(''YEAR'', DATEADD(YEAR, -2, TO_DATE(:CURR_DATE)))),''YEAR'');

V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := :DB_NAME||''.''||COALESCE(:UTIL_SC, ''UTIL'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';

V_PROCESS_NAME   VARCHAR DEFAULT ''AEP_UW'';

V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''AEP_UW'';

V_STEP             VARCHAR;

V_STEP_NAME        VARCHAR;

V_START_TIME       VARCHAR;

V_END_TIME         VARCHAR;

V_ROWS_PARSED       INTEGER;

V_ROWS_LOADED       INTEGER;

V_MESSAGE          VARCHAR;

V_LAST_QUERY_ID    VARCHAR;

V_SQL_QUERY VARCHAR;




V_UW_AUDIT_MAIN VARCHAR := :DB_NAME || ''.'' || COALESCE(:TWO_SC, ''SRC_APEX'') || ''.UW_AUDIT_MAIN'';
V_UW_OUTCOMES VARCHAR := :DB_NAME || ''.'' || COALESCE(:TWO_SC, ''SRC_APEX'') || ''.UW_OUTCOMES'';
V_UW_OUTCOME_SOURCE VARCHAR := :DB_NAME || ''.'' || COALESCE(:TWO_SC, ''SRC_APEX'') || ''.UW_OUTCOME_SOURCE'';
V_AUDIT_COMPLETED_VW  VARCHAR := :DB_NAME || ''.'' || COALESCE(:TWO_SC, ''SRC_APEX'') || ''.AUDIT_COMPLETED_VW '';
V_OLE_APPLICATION VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''SRC_COMPAS'') || ''.OLE_APPLICATION'';
V_APPLICATION_ACTOR VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''SRC_COMPAS'') || ''.APPLICATION_ACTOR'';
V_WORK_QUEUE_REC_ID VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''SRC_COMPAS'') || ''.WORK_QUEUE_REC_ID'';
V_ARC_WORK_QUEUE_REC_ID VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''SRC_COMPAS'') || ''.ARC_WORK_QUEUE_REC_ID'';
V_APPLICATION_MECHANISM VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''SRC_COMPAS'') || ''.APPLICATION_MECHANISM'';
V_PHONE_ENROLLMENT_TYPE VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''SRC_COMPAS'') || ''.PHONE_ENROLLMENT_TYPE'';
V_WORK_QUEUE_HISTORY VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''SRC_COMPAS'') || ''.WORK_QUEUE_HISTORY'';
V_ARC_WORK_QUEUE_HISTORY VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''SRC_COMPAS'') || ''.ARC_WORK_QUEUE_HISTORY'';
V_APPLICATION_AGENT VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''SRC_COMPAS'') || ''.APPLICATION_AGENT'';
V_APPLICATION_REPORTING VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.APPLICATION_REPORTING'';
V_APPLICATION_INDICATOR VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''SRC_COMPAS'') || ''.APPLICATION_INDICATOR'';
V_APPLICATION VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''SRC_COMPAS'') || ''.APPLICATION'';
V_APP_ENROLL_STORE VARCHAR := :DB_NAME || ''.'' || COALESCE(:THREE_SC, ''SRC_ACESX'') || ''.APP_ENROLL_STORE'';
V_AUDIT_PENDING_VW VARCHAR := :DB_NAME || ''.'' || COALESCE(:TWO_SC, ''SRC_APEX'') || ''.AUDIT_PENDING_VW'';
V_APPLICATION_EVENT_LOG VARCHAR := :DB_NAME || ''.'' || COALESCE(:THREE_SC, ''SRC_ACESX'') || ''.APPLICATION_EVENT_LOG'';


--Intermediate Tables
V_AEP_UW1  VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.AEP_UW1'';
V_AEP_UW2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.AEP_UW2'';
V_AEP_UW3 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.AEP_UW3'';
V_COMPAS_RTUW VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.COMPAS_RTUW'';
V_RTUW_APEX VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTUW_APEX'';
V_RTUW_SMART VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTUW_SMART'';
V_RTUW_ACESX VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTUW_ACESX'';
V_UW_AEP_RTUW1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.UW_AEP_RTUW1'';
V_UW_AEP_RTUW2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.UW_AEP_RTUW2'';
V_UW_AEP_RTUW3 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.UW_AEP_RTUW3'';
V_UW_AEP_RTUW4 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.UW_AEP_RTUW4'';
V_UW_AEP_RTUW5 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.UW_AEP_RTUW5'';
V_UW_AEP_RTUW6 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.UW_AEP_RTUW6'';
V_UW_AEP_PEN_SUSP VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.UW_AEP_PEN_SUSP'';

--TARGET Tables
V_UW_AEP_RTUW_FINAL VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.UW_AEP_RTUW_FINAL'';
V_AEP_UW_INCOMING VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.AEP_UW_INCOMING'';
V_AEP_UW_INCOMING_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.AEP_UW_INCOMING_1'';
V_AEP_UW_INCOMING_CHART1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.AEP_UW_INCOMING_CHART1'';
V_AEP_UW_INCOMING_CHART VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.AEP_UW_INCOMING_CHART'';
V_AEP_UW_FINAL1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.AEP_UW_FINAL1'';
V_AEP_UW_FINAL  VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.AEP_UW_FINAL '';
V_UW_AEP_MASTER_FILE  VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.UW_AEP_MASTER_FILE '';
V_AEP_UW_DOS_CHART1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.AEP_UW_DOS_CHART1'';
V_AEP_UW_DOS_CHART VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.AEP_UW_DOS_CHART'';
V_AEP_UW_TAT VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.AEP_UW_TAT'';
V_AEP_UW_CHART VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.AEP_UW_CHART'';



BEGIN

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP1'';

V_STEP_NAME :=  ''create a table AEP_UW1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

--Phsase 1
create or replace table IDENTIFIER(:V_AEP_UW1) COPY GRANTS as
select am.report_date
      ,am.completion_date
      ,am.assigned_to
      ,am.application_id
      ,am.img_number
      ,am.medpoint_result
      ,am.UW_type
      ,am.curr_stage
      ,am.Process_step
      ,o.uw_outcomes
      ,os.uw_outcome_source
      ,am.comments
      ,am.app_recd_date
      ,am.agent_id
,am.member_number
,WORKBENCH_UW_TYPE
,ENTITY,COMPAS_UW_TYPE
,APPLICATION_TYPE
from IDENTIFIER(:V_UW_AUDIT_MAIN) am
left join IDENTIFIER(:V_UW_OUTCOMES) o on am.outcome = o.id
left join IDENTIFIER(:V_UW_OUTCOME_SOURCE) os on os.id = am.outcome_source;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AEP_UW1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP2'';

V_STEP_NAME :=  ''create a table AEP_UW2/AEP_UW3'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_AEP_UW2) COPY GRANTS as
SELECT DOS,On_Hand,Awaiting_Initial_Handling
--current_date as TODAY_DATE FROM 
,current_date() as today_date from

(   -----------------------------Metric 2 & 9(Total On hand)
select count(distinct application_id) as On_Hand,current_date() as today_date
 
 from IDENTIFIER(:V_AEP_UW1)
--where upper(curr_stage) not in (''COMPLETED'')
where upper(curr_stage) in (''PENDING'',''SUSPENDED'',''NEW'')

 --group by Report_date
) Y

left join ( ----------------------Metric 1 & 6 (Awaiting Initial Handling)
select count(distinct application_id) as Awaiting_Initial_Handling, current_date() as today_date
 
 from IDENTIFIER(:V_AEP_UW1)
  where upper(curr_stage)  in (''NEW'')
--and upper(workbench_uw_type)  in (''ELIGIBILITY'',''SET RATE'')
 --group by report_date
) Y1 on Y1.today_date=y.today_date

left join -------------------------------------Metric 3,6 & 10 (Day Of service)
(

select  (case when aging is null then 1 else aging end) as DOS,current_date() as today_date
FROM 
(
SELECT ROW_NUMBER() over (order by aging desc) as row_num,aging,current_date() as TODAY_DATE FROM 
(
SELECT 
UTIL.DATE_DIFF_UDF(current_date,report_date)+1 as AGING,COUNT1,
sum(count1) over (order by UTIL.DATE_DIFF_UDF(current_date,report_date)+1 DESC) as running_sum
FROM 
(
select count(distinct application_id) as COUNT1 ,report_date, CURRENT_DATE() as TODAY_DATE , 
 --to_date(from_unixtime(unix_timestamp(report_date,''mm/dd/yyyy''),'' yyyy-mm-dd'')) as report_date1 
to_date(report_date) as TODAY_DATE
 from IDENTIFIER(:V_AEP_UW1)
 --mm/dd/yyyy
where upper(CURR_STAGE)=''NEW''
--and lower(workbench_UW_Type) in (''eligibility'' ,''set rate'')
 group by 
report_date,--to_date(from_unixtime(unix_timestamp(report_date,''mm/dd/yyyy''),'' yyyy-MM-dd''))
to_date(report_date)
)A
)B where running_sum>100
) C where row_num=1

) X

on x.today_date=y.today_date;


create or replace table IDENTIFIER(:V_AEP_UW3) COPY GRANTS as
select (case when dos is null then 1 else dos end) as DOS ,on_hand,awaiting_initial_handling,today_date
from IDENTIFIER(:V_AEP_UW2);




V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AEP_UW3)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP3'';

V_STEP_NAME :=  ''create a table AEP_UW_TAT/CHART'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

/**************************Metric 4 ,12(TAT)*********************/


create or replace table IDENTIFIER(:V_AEP_UW_TAT) COPY GRANTS as
SELECT completion_date,avg(tat) as tat FROM IDENTIFIER(:V_AUDIT_COMPLETED_VW)
where completion_date>=:V_CURR_YR_2_FIRST_DATE and upper(outcome_type) in (''ACCEPT'',''DENY'',''RATE'') --------------Dynamic date should be first day of (current year-2)
group by completion_date;



---------------------------------Create dataset for TAT chart
create or replace table IDENTIFIER(:V_AEP_UW_CHART) COPY GRANTS as
select a.completion_date,a.prev_year_date,a.prev_2_year_date,a.current_TAT,b.prev_year_TAT,c.prev_2_year_TAT from 
(
select completion_date,
DATEADD(day,-364,completion_date) as prev_year_date,DATEADD(day,-728,completion_date) as prev_2_year_date ,
avg(TAT) as current_TAT
from IDENTIFIER(:V_AEP_UW_TAT)
where 
--completion_date>=date ''${hivevar:curr_yr_first_date}'' and --------------Dynamic date should be first day of current date
--pmod(datediff(''day'',completion_date,''1900-01-07''),7) + 1=2
((MOD(UTIL.DATE_DIFF_UDF(completion_date,''1900-01-07''),7)+7)%7) +1 =2 
group by completion_date
) a 
left join 
(
select completion_date,
avg(TAT) as prev_year_TAT
from IDENTIFIER(:V_AEP_UW_TAT)
-- where completion_date>=date ''${hivevar:curr_yr_1_first_date}'' and --------------Dynamic date should be first day of (current year -1)
--completion_date<=date ''${hivevar:curr_yr_1_last_date}''
group by completion_date
)b on a.prev_year_date=b.completion_date

left join 
(select completion_date,
avg(TAT) as prev_2_year_TAT
from IDENTIFIER(:V_AEP_UW_TAT)
--where completion_date>=date ''${hivevar:curr_yr_2_first_date}'' and --------------Dynamic date should be first day of (current year -2)
--completion_date<=date ''${hivevar:curr_yr_2_last_date}''
group by completion_date)c on a.prev_2_year_date=c.completion_date;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AEP_UW_CHART)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP4'';

V_STEP_NAME :=  ''create a table compas_RTUW'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_COMPAS_RTUW) COPY GRANTS as
  SELECT  a.application_id
       ,a.APPL_IMAGE_NUM_ORIG
       ,o.OLE_REFERENCE_IDENTIFIER
       ,a.APPL_RECEIPT_DATE
       ,a.ADJUDICATION_DATE
       ,a.ADJUDICATION_CD
       ,case when nvl(r.tracking_number, ar.tracking_number) is null then ''Auto'' else ''Manual'' end as AA_ind
       ,am.APPL_MECHANISM_DESCRIPTION
       ,a.health_profile_tracking_id
       --,o.CREATION_DATE as OLE_Creation_dt
       ,a.CREATION_DATE as App_creation_dt
       ,a.last_modified_date as App_last_modified_date  -- o.CREATED_BY as O_Created_by, 
       ,a.last_modified_by as App_last_modified_by -- = ''UNAUTHENTICATED''
       --,aag_1.agent_ID as Writing_Agent
       ,aag_2.agent_ID as Selling_Agent
       ,case
  when aag_2.agent_id is null then ''DTC''
  when aag_2.agent_id in (''INS2222'', ''EHC2222'', ''SQS2222'', ''SQS3333'', ''SQS4444'', ''GOH2222'') then ''DTC''
  when aag_2.agent_id in (''EHEA111'', ''ETQ1111'', ''EXT1111'', ''GHI1111'', ''2140505'', ''INS1111'', ''2099352'', ''2097836'', ''SQS1111'', ''SQS2222'', ''BG0000'', ''2008052'', ''2161623'', ''SPR1111'', ''2109060'', 
                          ''TIB1111'', ''2034019'', ''2118752'', ''EHC11111'', ''EHC1111'', ''GOH1111'', ''ENS1111'', ''CIS1111'', ''2163980'', ''2083212'') THEN ''E-Alliance''
  else ''Agent'' end as Agent_Ind
    ,a.RDC_FIRST_CHOICE
  ,ai2.UNDERWRITING_RATE_UP_IND 

  ,max(CASE WHEN nvl(awqh_uw.TYPE_ID, wqh_uw.TYPE_ID) is null then 0 else 1 end) AS UW_Q_Ind,
case when am.APPL_MECHANISM_DESCRIPTION = ''WEB'' and aa.APPLICATION_ACTOR_DESCRIPTION = ''CSR'' then ''Telesale'' 
            when aag_2.agent_id in (''INS2222'', ''EHC2222'', ''SQS2222'', ''SQS3333'', ''SQS4444'', ''GOH2222'' ) then ''E-Alliance''
            when aag_2.agent_id in (''2013969'', ''EXT1111'', ''ff3000'', ''AG0000'', ''BG0000'', ''2083751'', ''2034386'', ''2083750'', ''SQS1111'', ''ZZ0001'', ''2097836'', ''2118752'',
                                  ''ETQ1111'',''2078319'',''EHEA111'',''2109060'',''2099352'',''ADS1111'',''2140505'',''TIB1111'',''INS1111'',''2008052'',''GHI1111'',''2161623'',''SPR1111'',''EHC1111'',''2034019'',''ENS1111'',
                                  ''GOH1111'',''2083212'',''2163980'') then ''E-Alliance''
            when aag_2.agent_id is null then ''DTC''                      
            else ''Agent'' end as Channel
,pet.phone_enrollment_type_code
      ,pet.phone_enrollment_type_desc
FROM  IDENTIFIER(:V_APPLICATION) a
left join IDENTIFIER(:V_OLE_APPLICATION) o on a.application_id = o.application_id
left join IDENTIFIER(:V_APPLICATION_ACTOR) aa on aa.APPLICATION_ACTOR_ID = a.APPL_ACTOR_ID
left join IDENTIFIER(:V_WORK_QUEUE_REC_ID) r on r.identifier_value = a.application_id AND r.identifier_type_id = 2011
left join IDENTIFIER(:V_ARC_WORK_QUEUE_REC_ID) ar on ar.identifier_value = a.application_id AND ar.identifier_type_id = 2011
left join IDENTIFIER(:V_APPLICATION_MECHANISM) am on am.application_mechanism_id = a.appl_mechanism_id
left join IDENTIFIER(:V_PHONE_ENROLLMENT_TYPE) pet on pet.PHONE_ENROLLMENT_type_id = a.PHONE_ENROLLMENT_type_id
left join IDENTIFIER(:V_WORK_QUEUE_HISTORY) wqh_uw on wqh_uw.tracking_number = r.tracking_number
                                          and wqh_uw.TYPE_ID in (2057,2039,2055,2047,2050,2054,2042,2043,2048,2040,2035,2023,2049)   -- UW queues
left join IDENTIFIER(:V_ARC_WORK_QUEUE_HISTORY) awqh_uw on awqh_uw.TRACKING_NUMBER = ar.TRACKING_NUMBER 
                                               and awqh_uw.TYPE_ID in (2057,2039,2055,2047,2050,2054,2042,2043,2048,2040,2035,2023,2049)   -- UW queues
                                               
left join IDENTIFIER(:V_APPLICATION_AGENT) aag_1 on aag_1.application_id = a.application_id and aag_1.agent_type_id =1
left join IDENTIFIER(:V_APPLICATION_AGENT) aag_2 on aag_2.application_id = a.application_id and aag_2.agent_type_id =2
left JOIN IDENTIFIER(:V_APPLICATION_INDICATOR) ai2 ON ai2.APPLICATION_ID = a.APPLICATION_ID
WHERE a.CREATION_DATE >= :V_CURR_YR_3_FIRST_DATE --------------Dynamic date should be first day of (current year -3)
and a.APPL_IMAGE_NUM_ORIG != ''SYSTEMGEN''
--and nvl(r.tracking_number, ar.tracking_number) is not null 
and a.health_profile_tracking_id is not null
group by a.application_id
       ,a.APPL_IMAGE_NUM_ORIG
       ,o.OLE_REFERENCE_IDENTIFIER
       ,a.APPL_RECEIPT_DATE
       ,a.ADJUDICATION_DATE
       ,a.ADJUDICATION_CD
       ,case when nvl(r.tracking_number, ar.tracking_number) is null then ''Auto'' else ''Manual'' end 
       ,am.APPL_MECHANISM_DESCRIPTION
       ,a.health_profile_tracking_id
       --,o.CREATION_DATE as OLE_Creation_dt
       ,a.CREATION_DATE 
       ,a.last_modified_date   -- o.CREATED_BY as O_Created_by, 
       ,a.last_modified_by  -- = ''UNAUTHENTICATED''
       --,aag_1.agent_ID as Writing_Agent
       ,aag_2.agent_ID 
       ,case
  when aag_2.agent_id is null then ''DTC''
  when aag_2.agent_id in (''INS2222'', ''EHC2222'', ''SQS2222'', ''SQS3333'', ''SQS4444'', ''GOH2222'') then ''DTC''
  when aag_2.agent_id in (''EHEA111'', ''ETQ1111'', ''EXT1111'', ''GHI1111'', ''2140505'', ''INS1111'', ''2099352'', ''2097836'', ''SQS1111'', ''SQS2222'', ''BG0000'', ''2008052'', ''2161623'', ''SPR1111'', ''2109060'', 
                          ''TIB1111'', ''2034019'', ''2118752'', ''EHC11111'', ''EHC1111'', ''GOH1111'', ''ENS1111'', ''CIS1111'', ''2163980'', ''2083212'') THEN ''E-Alliance''
  else ''Agent'' end
      ,a.RDC_FIRST_CHOICE
    ,ai2.UNDERWRITING_RATE_UP_IND
,case when am.APPL_MECHANISM_DESCRIPTION = ''WEB'' and aa.APPLICATION_ACTOR_DESCRIPTION = ''CSR'' then ''Telesale'' 
            when aag_2.agent_id in (''INS2222'', ''EHC2222'', ''SQS2222'', ''SQS3333'', ''SQS4444'', ''GOH2222'' ) then ''E-Alliance''
            when aag_2.agent_id in (''2013969'', ''EXT1111'', ''ff3000'', ''AG0000'', ''BG0000'', ''2083751'', ''2034386'', ''2083750'', ''SQS1111'', ''ZZ0001'', ''2097836'', ''2118752'',
                                  ''ETQ1111'',''2078319'',''EHEA111'',''2109060'',''2099352'',''ADS1111'',''2140505'',''TIB1111'',''INS1111'',''2008052'',''GHI1111'',''2161623'',''SPR1111'',''EHC1111'',''2034019'',''ENS1111'',
                                  ''GOH1111'',''2083212'',''2163980'') then ''E-Alliance''
            when aag_2.agent_id is null then ''DTC''                      
            else ''Agent'' end
,pet.phone_enrollment_type_code
      ,pet.phone_enrollment_type_desc;



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_COMPAS_RTUW)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP5'';

V_STEP_NAME :=  ''create a table rtuw_apex/smart/rtuw_acesx'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace  table IDENTIFIER(:V_RTUW_APEX) COPY GRANTS as 
select report_date as apex_rpt_dt, application_id as apex_app_id
from IDENTIFIER(:V_UW_AUDIT_MAIN)
where report_date >=:V_CURR_YR_3_FIRST_DATE --------------Dynamic date should be first day of (current year -3)
order by report_date,application_id;



create or replace  table IDENTIFIER(:V_RTUW_SMART) COPY GRANTS as
--select a.source_APPLICATION_ID s_app_id, ar.ENROLLMENT_PROCESS as s_enroll_proc
  select a.APPLICATION_ID s_app_id, ar.ENROLLMENT_PROCESS as s_enroll_proc
from IDENTIFIER(:V_APPLICATION) a
left join IDENTIFIER(:V_APPLICATION_REPORTING) ar on a.APPLICATION_ID = ar.APPLICATION_ID
where a.APPL_RECEIPT_DATE >= :V_CURR_YR_3_FIRST_DATE;--------------Dynamic date should be first day of (current year -3)

create or replace  table IDENTIFIER(:V_RTUW_ACESX) COPY GRANTS as
select * from (select aces_app_id,system_application_id,adjudication_status,ole_reference_id,
min(sent_date) as sent_date,min(adjudicated_date) as adjudicated_date
from 

(SELECT aes.aces_app_id, 
aes.system_application_id, 
aes.adjudication_status,aes.ole_reference_id,a.created_date as sent_date, b.created_date as adjudicated_date
FROM  IDENTIFIER(:V_APP_ENROLL_STORE) aes
       LEFT JOIN IDENTIFIER(:V_APPLICATION_EVENT_LOG) b ON AES.ACES_APP_ID=B.ACES_APP_ID 
FULL join IDENTIFIER(:V_APPLICATION_EVENT_LOG)  a  -- try full join
on a.aces_app_id = b.aces_app_id 
WHERE  aes.aces_app_id = a.aces_app_id
and a.event_name = ''SUBMITTED''  -- all "COMPLETED_ADJUDICATION" should have this event
and b.event_name = ''COMPLETED_ADJUDICATION''  
--and aes.system_application_id = 12036485
and b.created_date >=:V_CURR_YR_3_FIRST_DATE--------------Dynamic date should be first day of (current year -3)
--and a.created_date >= ''2023-07-01''
) x group by aces_app_id,system_application_id,adjudication_status,ole_reference_id
) y;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_RTUW_ACESX)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

V_STEP := ''STEP6'';

V_STEP_NAME :=  ''create tables UW_AEP_RTUW'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_UW_AEP_RTUW1) COPY GRANTS as 
select a.*,b.*,c.*,d.* from 
IDENTIFIER(:V_COMPAS_RTUW) a
left join IDENTIFIER(:V_RTUW_ACESX) b on a.ole_reference_identifier=b.ole_reference_id
left join IDENTIFIER(:V_RTUW_APEX) c on a.application_id=c.apex_app_id
left join IDENTIFIER(:V_RTUW_SMART) d on a.application_id=d.s_app_id;

create or replace table IDENTIFIER(:V_UW_AEP_RTUW2) as 
select *,
(case when upper(SELLING_AGENT)=''EHEA111'' then ''Batch''
when upper(SELLING_AGENT)=''BG0000'' then ''Batch''
when upper(SELLING_AGENT)=''EXT1111'' then ''Batch''
else ''Other''
end) as eAlliance_batch
from IDENTIFIER(:V_UW_AEP_RTUW1);

create or replace table IDENTIFIER(:V_UW_AEP_RTUW3) as  --------------------------------RTUW Cat
select *,

 (  --case when isnull(HEALTH_PROFILE_TRACKING_ID)=false 
  case when IFF(HEALTH_PROFILE_TRACKING_ID IS NULL,TRUE,FALSE)=FALSE
   --and isnull(OLE_REFERENCE_IDENTIFIER)=false
  and IFF(OLE_REFERENCE_IDENTIFIER IS NULL,TRUE,FALSE)=FALSE
   and ADJUDICATION_CD=''A'' and AA_IND=''Auto'' and eAlliance_batch!=''Batch'' then ''Happy Path''
--when isnull(HEALTH_PROFILE_TRACKING_ID)=FALSE 
  when IFF(HEALTH_PROFILE_TRACKING_ID IS NULL,TRUE,FALSE)=FALSE
   --and isnull(OLE_REFERENCE_IDENTIFIER)=false
  and IFF(OLE_REFERENCE_IDENTIFIER IS NULL,TRUE,FALSE)=FALSE
   and ADJUDICATION_CD=''A'' and AA_IND=''Auto'' and eAlliance_batch=''Batch'' then ''RTUW Ealliance Batch''
when ADJUDICATION_CD=''A'' and 
  --isnull(HEALTH_PROFILE_TRACKING_ID)=false 
  IFF(OLE_REFERENCE_IDENTIFIER IS NULL,TRUE,FALSE)=FALSE
   and UW_Q_IND=0 and (case when RDC_FIRST_CHOICE is null then 0 else RDC_FIRST_CHOICE end)!=2 
   and UNDERWRITING_RATE_UP_IND!=''Y'' THEN ''Other Auto UW Apps''
ELSE ''Other'' end) as RTUW_Cat
from IDENTIFIER(:V_UW_AEP_RTUW2);

create or replace table IDENTIFIER(:V_UW_AEP_RTUW4) as  --------------------------------OLE Response Time
select *,

(case when RTUW_Cat=''Happy Path'' and eAlliance_batch=''Batch''  then ''eAlliance Batch''
when RTUW_Cat=''Happy Path'' and  (TO_DATE(ADJUDICATED_DATE)-TO_DATE(SENT_DATE)) <= 40 then ''<= 40s''
when RTUW_Cat=''Happy Path'' and (TO_DATE(ADJUDICATED_DATE)-TO_DATE(SENT_DATE))> 40 then ''> 40s''
when RTUW_Cat=''Happy Path'' and 
  IFF((TO_DATE(ADJUDICATED_DATE)-TO_DATE(SENT_DATE)) IS NULL,TRUE,FALSE)=TRUE and IFF(OLE_REFERENCE_IDENTIFIER IS NULL,TRUE,FALSE)=FALSE
then ''Not Available'' 
when upper(APPL_MECHANISM_DESCRIPTION)=''MAIL'' then ''Other Auto-UW Apps - Mail''
else ''Other Auto-UW Apps - Web''
end) as OLE_Response_Time
from IDENTIFIER(:V_UW_AEP_RTUW3);

create or replace table IDENTIFIER(:V_UW_AEP_RTUW5) as  --------------------------------All Categories
select *,

(case when RTUW_Cat=''Happy Path''
 and OLE_Response_Time=''<= 40s'' and (TO_DATE(ADJUDICATED_DATE)-TO_DATE(SENT_DATE)) <= 40 then APPLICATION_ID
END) as le_40,

(case when RTUW_Cat=''Happy Path'' and OLE_Response_Time=''> 40s''
and (TO_DATE(ADJUDICATED_DATE)-TO_DATE(SENT_DATE)) > 40 then APPLICATION_ID
end ) as e_40,

(case when RTUW_Cat=''Happy Path'' 
and IFF((TO_DATE(ADJUDICATED_DATE)-TO_DATE(SENT_DATE)) IS NULL,TRUE,FALSE)=TRUE 
and IFF(OLE_REFERENCE_IDENTIFIER IS NULL,TRUE,FALSE)=FALSE 
and OLE_Response_Time=''Not Available''
then APPLICATION_ID
end ) as Not_Available,

(case when  RTUW_Cat=''RTUW Ealliance Batch''
then APPLICATION_ID
END) as eAlliance_Batch1,

(case when RTUW_Cat=''Other Auto UW Apps''
and APPL_MECHANISM_DESCRIPTION=''MAIL'' 
then APPLICATION_ID
END) as Other_AU_Mail,

(case when RTUW_Cat=''Other Auto UW Apps''
and OLE_Response_Time=''Other Auto-UW Apps - Web'' then APPLICATION_ID
end) as Other_AU_Web
from IDENTIFIER(:V_UW_AEP_RTUW4);


create or replace table IDENTIFIER(:V_UW_AEP_RTUW6) COPY GRANTS as 
select adjudication_date,count(distinct le_40) as a,count(distinct e_40) as b,count(distinct Not_Available ) as c,
count(distinct eAlliance_Batch1) as d,count(distinct Other_AU_Mail) as e,count(distinct Other_AU_Web) as f
from IDENTIFIER(:V_UW_AEP_RTUW5)  group by adjudication_date;


create or replace table IDENTIFIER(:V_UW_AEP_RTUW_FINAL) COPY GRANTS as 
select adjudication_date,sum(a+b+c+d+e+f) as RTUW
from IDENTIFIER(:V_UW_AEP_RTUW6)
group by adjudication_date;



/****************************Metric 7 & 8**************************/

create or replace table IDENTIFIER(:V_UW_AEP_PEN_SUSP) COPY GRANTS as 
select a.today_date,a.Pending ,a_1.Pending_onhand ,b.Suspended,b_1.Suspended_onhand from 
( SELECT current_date() as today_date,
AVG( Days_pending) as Pending,
Count( Distinct ID) as Pending_Onhand
FROM
IDENTIFIER(:V_AUDIT_PENDING_VW) x
where current_status =''PENDING''
group by 
current_date
) a
left join 
(SELECT current_date() as today_date,
Count( Distinct application_id) as Pending_Onhand
FROM
IDENTIFIER(:V_AEP_UW1) x
where upper(curr_stage) =''PENDING''
group by 
current_date
)a_1 on a.today_date=a_1.today_date
left join 
( SELECT current_date as today_date,
AVG( Days_pending) as Suspended
FROM
IDENTIFIER(:V_AUDIT_PENDING_VW) x
where current_status =''SUSPENDED''
group by 
current_date
) b 
on a.today_date=b.today_date
left join 
( SELECT current_date() as today_date,
Count( Distinct application_id ) as Suspended_Onhand
FROM
IDENTIFIER(:V_AEP_UW1) x
where upper(curr_stage) =''SUSPENDED''
group by 
current_date()
) b_1
on b.today_date=b_1.today_date; 
    

/******************************Metric 11 Incoming*********************/

   
create or replace  table IDENTIFIER(:V_AEP_UW_INCOMING) COPY GRANTS as
SELECT

    --to_date(from_unixtime(unix_timestamp(report_date,''mm/dd/yyyy''),'' yyyy-MM-dd'')) as report_date,  
    TO_DATE(report_date) as report_date,
    COUNT(distinct application_id)AS Incoming
FROM
    IDENTIFIER(:V_UW_AUDIT_MAIN)
   where report_date >=:V_CURR_YR_2_FIRST_DATE --------------Dynamic date should be first day of (current year -2)
--group by to_date(from_unixtime(unix_timestamp(report_date,''mm/dd/yyyy''),'' yyyy-MM-dd''));
  group by TO_DATE(report_date);


create or replace  table IDENTIFIER(:V_AEP_UW_INCOMING_1) COPY GRANTS as
select a.report_date,a.prev_year_date,a.current_Incoming,b.prev_year_Incoming from
(
select report_date,
DATEADD(''day'',-364,report_date) as prev_year_date,Incoming as current_Incoming
from IDENTIFIER(:V_AEP_UW_INCOMING) where report_date>=:V_CURR_YR_FIRST_DATE
) a
left join
(
select report_date,
Incoming as prev_year_Incoming
from IDENTIFIER(:V_AEP_UW_INCOMING) where report_date>=:V_CURR_YR_1_FIRST_DATE and
report_date<=:V_CURR_YR_1_LAST_DATE
)b on a.prev_year_date=b.report_date;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AEP_UW_INCOMING_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

V_STEP := ''STEP7'';

V_STEP_NAME :=  ''create tables AEP_UW_INCOMING_CHART1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_AEP_UW_INCOMING_CHART1) COPY GRANTS as 
select Incoming ,dateadd(day,2,Saturday) as report_date
from (
select sum(Incoming) as Incoming,
dateadd(day,-7,next_day(report_date,''SAT'')) as Saturday
from IDENTIFIER(:V_AEP_UW_INCOMING)
group by dateadd(day,-7,next_day(report_date,''SAT''))
) x;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AEP_UW_INCOMING_CHART1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP8'';

V_STEP_NAME :=  ''create tables AEP_UW_INCOMING_CHART'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_AEP_UW_INCOMING_CHART) COPY GRANTS as 
select a.report_date,a.prev_year_date,a.prev_2_year_date,a.current_Incoming,b.prev_year_Incoming,c.prev_2_year_Incoming from 
(
select report_date,
DATEADD(''day'',-364,report_date) as prev_year_date,DATEADD(''day'',-728,report_date) as prev_2_year_date ,
Incoming as current_Incoming
from IDENTIFIER(:V_AEP_UW_INCOMING_CHART1)
--where report_date>=date ''${hivevar:curr_yr_first_date}'' --------------Dynamic date should be first day of (current year)

) a 
left join 
(
select report_date,
Incoming as prev_year_Incoming
from IDENTIFIER(:V_AEP_UW_INCOMING_CHART1)
--where report_date>=date ''${hivevar:curr_yr_1_first_date}'' and --------------Dynamic date should be first day of (current year -1)
--report_date<=date ''${hivevar:curr_yr_1_last_date}''

)b on a.prev_year_date=b.report_date

left join 
(select report_date,
Incoming as prev_2_year_Incoming
from IDENTIFIER(:V_AEP_UW_INCOMING_CHART1)
--where report_date>=date ''${hivevar:curr_yr_2_first_date}'' and --------------Dynamic date should be first day of (current year -2)
--report_date<=date ''${hivevar:curr_yr_2_last_date}''
)c on a.prev_2_year_date=c.report_date;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AEP_UW_INCOMING_CHART)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



V_STEP := ''STEP8'';

V_STEP_NAME :=  ''create tables AEP_UW_FINAL1/V_AEP_UW_CHART'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

----------------------------------------Joining all the tables for phase 1------------------


create or replace table IDENTIFIER(:V_AEP_UW_FINAL1) COPY GRANTS as 
select a.*,b.tat,c.rtuw,d.pending,d.pending_onhand,d.suspended,d.suspended_onhand,e.Incoming
from IDENTIFIER(:V_AEP_UW3) a left join IDENTIFIER(:V_AEP_UW_TAT) b on a.today_date=b.completion_date
left join IDENTIFIER(:V_UW_AEP_RTUW_FINAL) c on a.today_date=c.adjudication_date
left join IDENTIFIER(:V_UW_AEP_PEN_SUSP) d on a.today_date=d.today_date 
left join IDENTIFIER(:V_AEP_UW_INCOMING) e on a.today_date=e.report_date;

-------------------------------------Appending in master table

create or replace table IDENTIFIER(:V_AEP_UW_FINAL) COPY GRANTS as 
select date,dos,on_hand,awaiting_initial_handling ,pending ,pending_onhand,suspended,suspended_onhand 
from IDENTIFIER(:V_UW_AEP_MASTER_FILE)
  ----------------------------For first time run this dataset should be same as master dataset for AEP UW.As we have to append data everyday into Master data.
union
select today_date as date,dos,on_hand,awaiting_initial_handling ,pending ,pending_onhand,suspended,suspended_onhand 
from IDENTIFIER(:V_AEP_UW_FINAL1);


-------------------------------------Creating master table

create or replace table IDENTIFIER(:V_UW_AEP_MASTER_FILE) as 
select * from IDENTIFIER(:V_AEP_UW_FINAL);

---------------------------------------Creating DOS chart data


create or replace table IDENTIFIER(:V_AEP_UW_DOS_CHART1) COPY GRANTS as 
select DOS ,date
from (
select DOS,date
from IDENTIFIER(:V_AEP_UW_FINAL)
--where pmod(datediff(date,''1900-01-07''),7) + 1=2
) x;

create or replace table IDENTIFIER(:V_AEP_UW_DOS_CHART) COPY GRANTS as 
select a.date,a.prev_year_date,a.current_dos,b.prev_year_dos from 
(
select date,
DATEADD(''day'',-364,DATE) as prev_year_date ,DOS as current_dos
from IDENTIFIER(:V_AEP_UW_DOS_CHART1)
--where date>=date ''${hivevar:curr_yr_first_date}'' --------------Dynamic date should be first day of (current year)

) a 
left join 
(
select date,
dos as prev_year_dos
from IDENTIFIER(:V_AEP_UW_DOS_CHART1)
--where date>=date ''${hivevar:curr_yr_1_first_date}'' and --------------Dynamic date should be first day of (current year -1)
--date<=date ''${hivevar:curr_yr_1_last_date}''

)b on a.prev_year_date=b.date;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AEP_UW_DOS_CHART)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);


RAISE;

END;

';