USE SCHEMA BDR_FFP_DA;


CREATE OR REPLACE PROCEDURE BDR_FFP_DA.SP_HCI_SURVEY_DASHBOARD("PIPELINE_ID" VARCHAR(16777216), "PIPELINE_NAME" VARCHAR(16777216), "DB_NAME" VARCHAR(16777216), "UTIL_SC" VARCHAR(16777216), "SRC_SC_1" VARCHAR(16777216), "SRC_SC_2" VARCHAR(16777216), "SRC_SC_3" VARCHAR(16777216), "SRC_SC_4" VARCHAR(16777216), "SRC_SC_5" VARCHAR(16777216), "SRC_SC_6" VARCHAR(16777216), "SRC_SC_7" VARCHAR(16777216), "WRK_SC" VARCHAR(16777216), "TGT_SC" VARCHAR(16777216), "WH" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

V_CURRENT_DATE   DATE := CURRENT_DATE();

V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := :DB_NAME||''.''||COALESCE(:UTIL_SC, ''UTIL'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';

V_PROCESS_NAME   VARCHAR DEFAULT ''HCI_SURVEY_DASHBOARD'';

V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''HCI_SURVEY_DASHBOARD'';

V_STEP             VARCHAR;

V_STEP_NAME        VARCHAR;

V_START_TIME       VARCHAR;

V_END_TIME         VARCHAR;

V_ROWS_PARSED       INTEGER;

V_ROWS_LOADED       INTEGER;

V_MESSAGE          VARCHAR;

V_LAST_QUERY_ID    VARCHAR;

V_HCI_SUR_REQ_DEDUP VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.HCI_SUR_REQ_DEDUP''; 

V_HCI_ASSESS_DT_CAL VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.HCI_ASSESS_DT_CAL'';

V_HCI_CAL_RESPONDER_TYPE_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.HCI_CAL_RESPONDER_TYPE_1'';

V_HCI_RESPONDER_TYPE_DEDUP_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.HCI_RESPONDER_TYPE_DEDUP_1'';

V_HCI_RESPONDER_TYPE_DEDUP_2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.HCI_RESPONDER_TYPE_DEDUP_2'';

V_HCI_FIX_SUR_GE_ASSESS_DT_CASE VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.HCI_FIX_SUR_GE_ASSESS_DT_CASE'';

V_HCI_PER_ID_FROM_MBR_INFO VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.HCI_PER_ID_FROM_MBR_INFO'';

V_HCI_INDV_ID_FROM_COMPASS VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.HCI_INDV_ID_FROM_COMPASS'';

V_FF_RAP_MEMBER_REQUEST_ID_DATA VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_1, ''SRC_FILES'') || ''.FF_RAP_MEMBER_REQUEST_ID_DATA'';

V_FF_HCI_ASSESSMENT_DATA VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.FF_HCI_ASSESSMENT_DATA_20241231'';

V_D_MBR_INFO VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_2, ''BDR_CONF'') || ''.D_MBR_INFO'';

V_SHIP_PERSON_XREF VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_3, ''BDR_SMART'') || ''.SHIP_PERSON_XREF'';

V_APPLICATION VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_4, ''SRC_COMPAS'') || ''.APPLICATION'';
 
V_HCI_CAL_MBR_TYPE_PER_ID VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.HCI_CAL_MBR_TYPE_PER_ID'';

V_P_LVL_CLAIM_INFO VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.INFORCELR_P_LVL_CLAIM_INFO'';  

V_HCI_CAL_MBR_TYPE_INDV_ID VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.HCI_CAL_MBR_TYPE_INDV_ID'';

V_HCI_CAL_MBR_TYPE_MERGE VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.HCI_CAL_MBR_TYPE_MERGE'';

V_HCI_MBR_TYPE_DEDUP_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.HCI_MBR_TYPE_DEDUP_1'';

V_HCI_MBR_TYPE_DEDUP_2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.HCI_MBR_TYPE_DEDUP_2'';

V_HCI_MBR_TYPE_DEDUP_3 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.HCI_MBR_TYPE_DEDUP_3'';

V_HCI_MBR_TYPE_DEDUP_4 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.HCI_MBR_TYPE_DEDUP_4'';

V_HCI_VAS_ONS_FLAG VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.HCI_VAS_ONS_FLAG'';

V_VAS_HNW_MASTER VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.VAS_HNW_MASTER'';

V_HCI_ALLLAPSER_BASE_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.HCI_ALLLAPSER_BASE_1'';

V_F_PREM_TRANS_DAY VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_5, ''BDR_DM'') || ''.F_PREM_TRANS_DAY'';

V_D_CERT_ACTV VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_2, ''BDR_CONF'') || ''.D_CERT_ACTV'';

V_D_PLN_BEN_MOD VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_2, ''BDR_CONF'') || ''.D_PLN_BEN_MOD'';

V_HCI_ALLLAPSER_BASE_2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.HCI_ALLLAPSER_BASE_2'';

V_HCI_ALLLAPSER_BASE_3 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.HCI_ALLLAPSER_BASE_3'';

V_HCI_ALLLAPSER_BASE_4 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.HCI_ALLLAPSER_BASE_4'';

V_HCI_LAPSER_POST_SURV_DT VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.HCI_LAPSER_POST_SURV_DT'';

V_HCI_CLAIMS_PREM_NEW_ENR_Y1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.HCI_CLAIMS_PREM_NEW_ENR_Y1'';

V_LRCCO_FINAL_0811 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.NEW_BUS_EXPNS_LRCCO_FINAL_0811'';

V_HCI_CLAIMS_PREM_NEW_ENR_Y2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.HCI_CLAIMS_PREM_NEW_ENR_Y2'';

V_HCI_MBR_TYPE_DEDUP_4_INF VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.HCI_MBR_TYPE_DEDUP_4_INF'';

V_HCI_CLAIMS_PREM_INF_PRE_Y1_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.HCI_CLAIMS_PREM_INF_PRE_Y1_1'';

V_HCI_CLAIMS_PREM_INF_PRE_Y1_2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.HCI_CLAIMS_PREM_INF_PRE_Y1_2'';

V_HCI_CLAIMS_PREM_INF_PRE_Y2_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.HCI_CLAIMS_PREM_INF_PRE_Y2_1'';

V_HCI_CLAIMS_PREM_INF_PRE_Y2_2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.HCI_CLAIMS_PREM_INF_PRE_Y2_2'';

V_HCI_CLAIMS_PREM_INF_POST_Y1_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.HCI_CLAIMS_PREM_INF_POST_Y1_1'';

V_HCI_CLAIMS_PREM_INF_POST_Y1_2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.HCI_CLAIMS_PREM_INF_POST_Y1_2'';

V_HCI_CLAIMS_PREM_INF_POST_Y2_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.HCI_CLAIMS_PREM_INF_POST_Y2_1'';

V_HCI_CLAIMS_PREM_INF_POST_Y2_2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.HCI_CLAIMS_PREM_INF_POST_Y2_2'';

V_HCI_DISB_SALES_ENROLL_FLAG_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.HCI_DISB_SALES_ENROLL_FLAG_1'';

V_APPS_RPTG_DAILY VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_6, ''SRC_MPO'') || ''.APPS_RPTG_DAILY'';

V_HCI_DISB_SALES_ENROLL_FLAG_2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.HCI_DISB_SALES_ENROLL_FLAG_2'';

V_APPS_RPTG_DAILY_2000_2024 VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_6, ''SRC_MPO'') || ''.APPS_RPTG_DAILY_2000_2024'';

V_HCI_DISB_SALES_ENROLL_FLAG_3 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.HCI_DISB_SALES_ENROLL_FLAG_3'';

V_HCI_EZ_CLM_REG VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.HCI_EZ_CLM_REG'';

V_EZCLAIM_ENROLLED_FOR_LAPSE_SA VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.EZCLAIM_EZCLAIM_ENROLLED_FOR_LAPSE_SA'';

V_HCI_MA_CONT_MEMBERSHIP_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.HCI_MA_CONT_MEMBERSHIP_1'';

V_MA_MBR_CONT VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_7, ''SRC_FIN360'') || ''.MA_MBR_CONT''; 

V_HCI_MA_MIGRATORS_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.HCI_MA_MIGRATORS_1'';

V_HCI_DASH_PHASE_2_SUMM_BKP VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.HCI_DASH_PHASE_2_SUMM_BKP'';

V_HCI_DASH_PHASE_2_SUMM VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.HCI_DASH_PHASE_2_SUMM'';


BEGIN

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP1'';

V_STEP_NAME :=  ''Create table HCI_Sur_req_dedup'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


CREATE OR REPLACE TABLE IDENTIFIER(:V_HCI_SUR_REQ_DEDUP) COPY GRANTS  as select * EXCLUDE(ROW_NUM_SUR) from 
(select 
* 
,ROW_NUMBER() OVER(PARTITION By ucps_id,request_dttm 
order by  file_name ) as row_num_sur
from IDENTIFIER(:V_FF_RAP_MEMBER_REQUEST_ID_DATA)) as hci 
where hci.row_num_sur=1;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCI_SUR_REQ_DEDUP)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP2'';

V_STEP_NAME :=  ''Create table HCI_assess_dt_cal'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_HCI_ASSESS_DT_CAL) COPY GRANTS  as
select 
hci_assessment_data_sk
,lpad(ucps_id,11,''0'') as ucps_id 
,asmt_id
,asmt_date as asmt_mon_id
,asmt_dttm
,Case when asmt_dttm is not null and asmt_dttm RLIKE ''^[0-9]{2}[A-Z]{3}[0-9]{4}:[0-9]{2}:[0-9]{2}:[0-9]{2}\\.[0-9]{3}$'' 
then TO_CHAR(TO_TIMESTAMP(TRIM(asmt_dttm), ''DDMONYYYY:HH24:MI:SS.FF3''),''yyyy-MM-dd'')
WHEN asmt_dttm is not null and asmt_dttm RLIKE ''^[0-9]{2}[A-Z]{3}[0-9]{4}:[0-9]{2}:[0-9]{2}:[0-9]{2}\\.[0-9]{6}$'' 
then TO_CHAR(TO_TIMESTAMP(TRIM(asmt_dttm), ''DDMONYYYY:HH24:MI:SS.FF6''),''yyyy-MM-dd'')
else 
TO_CHAR(TO_TIMESTAMP(TRIM(asmt_dttm), ''DDMONYY:HH24:MI:SS''),''yyyy-MM-dd'') 
end as asmt_date
,bld_asmt_id
,gender
,state_cd
,zip_cd
,age_int
,age
,legal_entity
,q10730
,q14047
,q14050
,q14046
,q14056
,q14057
,q14323
,q3869
,q3870
,q3872
,q51622
,q51625
,q51624
,q12181
,q10697
,q10696
,q14052
,q10698
,q14051
,q14058
,q3619
,q3871
,pain
,q14054
,q394
,q14055
,q14053
,q395
,lonely_level
,lonely_lvl
,dep_flag
,q51623
,q51621
,q51626
,q54801
,creat_dt
,creat_by
,lst_mod_dt
,lst_mod_by
,etl_lst_btch_id
,file_name
,file_month_id

from IDENTIFIER(:V_FF_HCI_ASSESSMENT_DATA) 
where to_date(CONCAT(substr(asmt_date,1,4),''-'',substr(asmt_date,5,2),''-01''))
>=''2021-01-01'';


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCI_ASSESS_DT_CAL)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP3'';

V_STEP_NAME :=  ''Create table HCI_Cal_Responder_Type_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_HCI_CAL_RESPONDER_TYPE_1) COPY GRANTS  as
select 
a.ff_rap_member_request_id_sk as rap_member_request_id_sk
,a.mbr_asmt_srvc_req_id
,a.ucps_id
,to_char(to_timestamp(a.request_dttm,''MM/DD/YYYY''),''YYYY-MM-DD'') as survey_request_date
,b.hci_assessment_data_sk
,b.asmt_date 
,DATEDIFF(day,to_char(to_timestamp(a.request_dttm,''MM/DD/YYYY''),''YYYY-MM-DD''),b.asmt_date) as asmt_surv_req_dt_Diff

,case when b.ucps_id is not NULL 
and to_char(to_timestamp(a.request_dttm,''MM/DD/YYYY''),''YYYY-MM-DD'')<=
b.asmt_date then ''Responders''
when b.ucps_id is not NULL 
and to_char(to_timestamp(a.request_dttm,''MM/DD/YYYY''),''YYYY-MM-DD'') > b.asmt_date then ''Survey Req dt>Assessment dt''

when b.ucps_id is not NULL then ''Match Found-need to review''
else ''Non-Responders'' end as Responder_type

from IDENTIFIER(:V_HCI_SUR_REQ_DEDUP) as a 
left join IDENTIFIER(:V_HCI_ASSESS_DT_CAL) as b
on lpad(a.ucps_id,11,''0'')=lpad(b.ucps_id,11,''0'')
;




V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCI_CAL_RESPONDER_TYPE_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP4'';

V_STEP_NAME :=  ''Create table HCI_Responder_Type_Dedup_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_HCI_RESPONDER_TYPE_DEDUP_1) COPY GRANTS  as
select t1.*   
,ROW_NUMBER() OVER(PARTITION By t1.ucps_id,t1.survey_request_date 
order by  t1.asmt_surv_req_dt_Diff_F,t1.hci_assessment_data_sk asc) as row_num_inf
from 
(select * 
,Case when asmt_surv_req_dt_Diff<0 and asmt_date is not NULL then 99999 
when asmt_date is NULL then 999999
else asmt_surv_req_dt_Diff
end as asmt_surv_req_dt_Diff_F
from IDENTIFIER(:V_HCI_CAL_RESPONDER_TYPE_1) ) as t1;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCI_RESPONDER_TYPE_DEDUP_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP5'';

V_STEP_NAME :=  ''Create TABLE HCI_Responder_Type_Dedup_2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_HCI_RESPONDER_TYPE_DEDUP_2) COPY GRANTS  as
select * EXCLUDE(row_num_inf) from IDENTIFIER(:V_HCI_RESPONDER_TYPE_DEDUP_1)
where row_num_inf=1;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCI_RESPONDER_TYPE_DEDUP_2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP6'';

V_STEP_NAME :=  ''Create table HCI_Fix_Sur_GE_Assess_dt_Case'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_HCI_FIX_SUR_GE_ASSESS_DT_CASE) COPY GRANTS  as
select 
rap_member_request_id_sk
,mbr_asmt_srvc_req_id
,ucps_id
,case when Responder_type=''Survey Req dt>Assessment dt'' then asmt_date
else survey_request_date end as survey_request_date
,hci_assessment_data_sk
,asmt_date
,case when Responder_type=''Survey Req dt>Assessment dt'' then 0
else asmt_surv_req_dt_diff end as asmt_surv_req_dt_diff
,case when Responder_type=''Survey Req dt>Assessment dt'' then ''Responders''
else Responder_type end as Responder_type
,case when Responder_type=''Survey Req dt>Assessment dt'' then 0
else asmt_surv_req_dt_diff_f end as asmt_surv_req_dt_diff_f
from IDENTIFIER(:V_HCI_RESPONDER_TYPE_DEDUP_2)
;



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCI_FIX_SUR_GE_ASSESS_DT_CASE)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP7'';

V_STEP_NAME :=  ''Create table HCI_Per_id_from_Mbr_info'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


CREATE OR REPLACE TABLE IDENTIFIER(:V_HCI_PER_ID_FROM_MBR_INFO) COPY GRANTS  as
select 
hci.*
,mi.d_mbr_info_sk
,mi.MEDCR_CLM_NBR
,(case when xref.person_id is null then mi.pers_id else xref.person_id end) as pers_id
,case when mi.d_mbr_info_sk is not null then ''Y'' else ''N'' end as v_d_mbr_info_match

from IDENTIFIER(:V_HCI_FIX_SUR_GE_ASSESS_DT_CASE) as hci
left join IDENTIFIER(:V_D_MBR_INFO) as mi
on hci.ucps_id=lpad(mi.acct_nbr,11,''0'')

left join IDENTIFIER(:V_SHIP_PERSON_XREF) as xref 
on mi.INDV_ID = xref.SHIP_PERSON_ID	
;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCI_PER_ID_FROM_MBR_INFO)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP8'';

V_STEP_NAME :=  ''Create table HCI_indv_id_from_Compass'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_HCI_INDV_ID_FROM_COMPASS) COPY GRANTS  as
select 
hci.*
,com.individual_id
,case when hci.v_d_mbr_info_match=''Y'' then ''NA'' 
when hci.v_d_mbr_info_match=''N'' and com.individual_id is not null then ''Y'' 
else ''N'' end as Compass_App_match

from IDENTIFIER(:V_HCI_PER_ID_FROM_MBR_INFO) as hci
left join IDENTIFIER(:V_APPLICATION) as com
on hci.ucps_id=lpad(com.membership_number||com.association_id||com.insured_cd,11,''0'')
and hci.v_d_mbr_info_match=''N''
;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCI_INDV_ID_FROM_COMPASS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP9'';

V_STEP_NAME :=  ''Create table HCI_Cal_Mbr_Type_per_id'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


CREATE OR REPLACE TABLE IDENTIFIER(:V_HCI_Cal_Mbr_Type_per_id) COPY GRANTS  as
select 
hci.*
,Inf.compas_insd_pln_id as compas_insd_pln_id_inf
,Inf.prdct_eff_dt as prdct_eff_dt
,Inf.prem_due_dt as prem_due_dt

,DATEDIFF(day,Inf.prdct_eff_dt,hci.survey_request_date) as surv_req_prdct_eff_dt_Diff
,DATEDIFF(day,Inf.prem_due_dt,hci.survey_request_date) as surv_req_prem_due_dt_Diff

,case when DATEDIFF(day,Inf.prdct_eff_dt,hci.survey_request_date) >365 then ''Inforce''
when DATEDIFF(day,Inf.prdct_eff_dt,hci.survey_request_date) between 0 and 365 then ''New Enrollee'' 
when DATEDIFF(day,Inf.prdct_eff_dt,hci.survey_request_date) <0 then ''prdct_eff_dt>survey_request_date''

when Inf.pers_id is NULL then ''Not found in Inforce'' 
else ''Unknown'' end as Member_Type
,Inf.prem_due_age_id
,Inf.partb_eff_age_lessthan65
,Inf.age
,Inf.agt_sub_typ
,Inf.agt_typ_final
,Inf.cnty_cd
,Inf.cnty_nm
,Inf.d_st_cd
,Inf.dob
,Inf.dscnt_annl_payr_desc
,Inf.dscnt_eft_desc
,Inf.dscnt_erly_enrl_desc
,Inf.dscnt_multi_insd_desc
,Inf.e_alliance_new_category
,Inf.e_alliance_old_category
,Inf.gdr_desc
,Inf.lgl_enty_nm
,Inf.marketing_channel_final
,Inf.pdp_fg
,Inf.plan_cd
,Inf.pln_lvl
,Inf.rt_dtrm_cd_desc
,Inf.rtng_area_nm
,Inf.surchrg_tbcc_user_flg
,Inf.uw_prdct_rqr_txt
,Inf.undwr_pln_rqr_txt
,Inf.undwr_prdct_rqr_txt
,Inf.zip_cd

/* pull fields required to calculate enrollment_type and sub_channel_final */
,Inf.agt_id_final
,Inf.prdct_ACQN_CHNL_LVL_1
,Inf.ref_ealliance_pref_nm


from IDENTIFIER(:V_HCI_INDV_ID_FROM_COMPASS) as hci
left join IDENTIFIER(:V_P_LVL_CLAIM_INFO) as Inf
on hci.pers_id=Inf.pers_id
where hci.v_d_mbr_info_match=''Y''
;
    

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCI_CAL_MBR_TYPE_PER_ID)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP10'';

V_STEP_NAME :=  ''Create table HCI_Cal_Mbr_Type_indv_id'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_HCI_CAL_MBR_TYPE_INDV_ID) COPY GRANTS  as
select 
hci.rap_member_request_id_sk
,hci.mbr_asmt_srvc_req_id
,hci.ucps_id
,hci.survey_request_date
,hci.hci_assessment_data_sk
,hci.asmt_date
,hci.asmt_surv_req_dt_diff
,hci.responder_type
,hci.asmt_surv_req_dt_diff_f
,hci.d_mbr_info_sk

--used pers_id from Inforce since these are not found in v_d_mbr_info cases where pers_id is null 

,coalesce(HCI.MEDCR_CLM_NBR, Inf.medcr_id) as medcr_id
,coalesce(HCI.pers_id, Inf.pers_id) as pers_id
,hci.v_d_mbr_info_match
,hci.individual_id
,hci.compass_app_match

,Inf.compas_insd_pln_id as compas_insd_pln_id_inf
,Inf.prdct_eff_dt as prdct_eff_dt
,Inf.prem_due_dt as prem_due_dt
,DATEDIFF(day,Inf.prdct_eff_dt,hci.survey_request_date) as surv_req_prdct_eff_dt_Diff
,DATEDIFF(day,Inf.prem_due_dt,hci.survey_request_date) as surv_req_prem_due_dt_Diff

,case when DATEDIFF(day,Inf.prdct_eff_dt,hci.survey_request_date) >365 then ''Inforce''
when DATEDIFF(day,Inf.prdct_eff_dt,hci.survey_request_date) between 0 and 365 then ''New Enrollee'' 
when DATEDIFF(day,Inf.prdct_eff_dt,hci.survey_request_date) <0 then ''prdct_eff_dt>survey_request_date''

when hci.Compass_App_match=''Y'' and Inf.indv_id is NULL then ''Not found in Inforce'' 
when hci.Compass_App_match=''N'' then ''Not found in v_d_mbr_info & Compass_App'' 

else ''Unknown'' end as Member_Type

,Inf.prem_due_age_id
,Inf.partb_eff_age_lessthan65
,Inf.age
,Inf.agt_sub_typ
,Inf.agt_typ_final
,Inf.cnty_cd
,Inf.cnty_nm
,Inf.d_st_cd
,Inf.dob
,Inf.dscnt_annl_payr_desc
,Inf.dscnt_eft_desc
,Inf.dscnt_erly_enrl_desc
,Inf.dscnt_multi_insd_desc
,Inf.e_alliance_new_category
,Inf.e_alliance_old_category
,Inf.gdr_desc
,Inf.lgl_enty_nm
,Inf.marketing_channel_final
,Inf.pdp_fg
,Inf.plan_cd
,Inf.pln_lvl
,Inf.rt_dtrm_cd_desc
,Inf.rtng_area_nm
,Inf.surchrg_tbcc_user_flg
,Inf.uw_prdct_rqr_txt
,Inf.undwr_pln_rqr_txt
,Inf.undwr_prdct_rqr_txt
,Inf.zip_cd

/* pull fields required to calculate enrollment_type and sub_channel_final */
,Inf.agt_id_final
,Inf.prdct_ACQN_CHNL_LVL_1
,Inf.ref_ealliance_pref_nm

from IDENTIFIER(:V_HCI_INDV_ID_FROM_COMPASS) as hci
left join IDENTIFIER(:V_P_LVL_CLAIM_INFO) as Inf
on hci.individual_id=Inf.indv_id
where hci.v_d_mbr_info_match=''N''
;



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCI_CAL_MBR_TYPE_INDV_ID)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP11'';

V_STEP_NAME :=  ''Create table HCI_Cal_Mbr_Type_Merge'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


CREATE OR REPLACE TABLE IDENTIFIER(:V_HCI_CAL_MBR_TYPE_MERGE) COPY GRANTS  as
select * from IDENTIFIER(:V_HCI_CAL_MBR_TYPE_PER_ID)
union all 
select * from IDENTIFIER(:V_HCI_CAL_MBR_TYPE_INDV_ID);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCI_CAL_MBR_TYPE_MERGE)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP12'';

V_STEP_NAME :=  ''Create table HCI_Mbr_Type_Dedup_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_HCI_MBR_TYPE_DEDUP_1) COPY GRANTS  as
select *
,ROW_NUMBER() OVER(PARTITION By ucps_id,survey_request_date, prdct_eff_dt 
order by  surv_req_prem_due_dt_Diff_F nulls first,hci_assessment_data_sk asc nulls first,pers_id desc nulls last,d_mbr_info_sk desc nulls last) as row_num_inf_2
from 
(select * 
,Case when surv_req_prem_due_dt_Diff<0 and prem_due_dt is not NULL then 99999+(surv_req_prem_due_dt_Diff*-1) 
when prem_due_dt is NULL then 999999
else surv_req_prem_due_dt_Diff
end as surv_req_prem_due_dt_Diff_F
from IDENTIFIER(:V_HCI_CAL_MBR_TYPE_MERGE)) as t1
;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCI_MBR_TYPE_DEDUP_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP13'';

V_STEP_NAME :=  ''Create table HCI_Mbr_Type_Dedup_2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


CREATE OR REPLACE TABLE IDENTIFIER(:V_HCI_MBR_TYPE_DEDUP_2) COPY GRANTS  as
select *
,dense_rank() OVER(PARTITION By ucps_id,survey_request_date  
order by  surv_req_prdct_eff_dt_Diff_F nulls first) as row_num_inf_3
from 
(select * 
,Case when surv_req_prdct_eff_dt_Diff<0 and prdct_eff_dt is not NULL then 99999+(surv_req_prdct_eff_dt_Diff*-1)  
when prdct_eff_dt is NULL then 999999
else surv_req_prdct_eff_dt_Diff
end as surv_req_prdct_eff_dt_Diff_F
from IDENTIFIER(:V_HCI_MBR_TYPE_DEDUP_1)) as t1
;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCI_MBR_TYPE_DEDUP_2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP14'';

V_STEP_NAME :=  ''Create table HCI_Mbr_Type_Dedup_3'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


CREATE OR REPLACE TABLE IDENTIFIER(:V_HCI_MBR_TYPE_DEDUP_3) COPY GRANTS  as
select * from IDENTIFIER(:V_HCI_MBR_TYPE_DEDUP_2)
where row_num_inf_2=1 and row_num_inf_3=1;
             

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCI_MBR_TYPE_DEDUP_3)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP15'';

V_STEP_NAME :=  ''Create table HCI_MBR_TYPE_DEDUP_4'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_HCI_MBR_TYPE_DEDUP_4) COPY GRANTS  as
select t1.* from 
(select *
,ROW_NUMBER() OVER(PARTITION By pers_id 
order by responder_type desc,rap_member_request_id_sk asc) as row_num_pers
from IDENTIFIER(:V_HCI_MBR_TYPE_DEDUP_3)) as t1 
where t1.row_num_pers=1 and t1.pers_id is not null 
;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCI_MBR_TYPE_DEDUP_4)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP16'';

V_STEP_NAME :=  ''Create table HCI_VAS_ONS_Flag'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_HCI_VAS_ONS_Flag) COPY GRANTS  as
SELECT  
hci.mbr_asmt_srvc_req_id
,hci.pers_id

,case when (sum(case when DATEDIFF(day, cast(extract(year from cast(hci.survey_request_date as date))||''-''||extract(month from cast(hci.survey_request_date as date))||''-01''  as date) ,vas.visit_month) between 0 and 365 
and gym_fg =''Yes'' then 1 else 0 end)>0) then ''Yes'' else ''No'' end as VAS_GYM_Y1

,case when (sum(case when DATEDIFF(day, cast(extract(year from cast(hci.survey_request_date as date))||''-''||extract(month from cast(hci.survey_request_date as date))||''-01''  as date) ,vas.visit_month) between 0 and 365 and digital_fg =''Yes'' 
then 1 else 0 end )>0) then ''Yes'' else ''No'' end as VAS_DIG_Y1

,case when (sum(case when DATEDIFF(day, cast(extract(year from cast(hci.survey_request_date as date))||''-''||extract(month from cast(hci.survey_request_date as date))||''-01''  as date) ,vas.visit_month) between 0 and 365 and cognitive_fg =''Yes'' 
then 1 else 0 end)>0) then ''Yes'' else ''No'' end as VAS_COG_Y1

,case when (sum(case when DATEDIFF(day, cast(extract(year from cast(hci.survey_request_date as date))||''-''||extract(month from cast(hci.survey_request_date as date))||''-01''  as date) ,vas.visit_month) between 0 and 365 and social_fg =''Yes'' 
then 1 else 0 end)>0) then ''Yes'' else ''No'' end as VAS_SOC_Y1

,case when (sum(case when DATEDIFF(day, cast(extract(year from cast(hci.survey_request_date as date))||''-''||extract(month from cast(hci.survey_request_date as date))||''-01''  as date) ,vas.visit_month) between 0 and 365 and nurseline_inbound_fg =''Yes'' 
then 1 else 0 end)>0) then ''Yes'' else ''No'' end as VAS_NL_Y1

,case when (sum(case when DATEDIFF(day, cast(extract(year from cast(hci.survey_request_date as date))||''-''||extract(month from cast(hci.survey_request_date as date))||''-01''  as date) ,vas.visit_month) between 0 and 365 and ons_fg =''Yes'' 
then 1 else 0 end)>0) then ''Yes'' else ''No'' end as VAS_ONS_Y1

,case when (sum(case when DATEDIFF(day, cast(extract(year from cast(hci.survey_request_date as date))||''-''||extract(month from cast(hci.survey_request_date as date))||''-01''  as date) ,vas.visit_month) between 366 and 730 and gym_fg =''Yes'' 
then 1 else 0 end)>0) then ''Yes'' else ''No'' end as VAS_GYM_Y2

,case when (sum(case when DATEDIFF(day, cast(extract(year from cast(hci.survey_request_date as date))||''-''||extract(month from cast(hci.survey_request_date as date))||''-01''  as date) ,vas.visit_month) between 366 and 730 and digital_fg =''Yes'' 
then 1 else 0 end)>0) then ''Yes'' else ''No'' end as VAS_DIG_Y2

,case when (sum(case when DATEDIFF(day, cast(extract(year from cast(hci.survey_request_date as date))||''-''||extract(month from cast(hci.survey_request_date as date))||''-01''  as date) ,vas.visit_month) between 366 and 730 and cognitive_fg =''Yes'' 
then 1 else 0 end)>0) then ''Yes'' else ''No'' end as VAS_COG_Y2

,case when (sum(case when DATEDIFF(day, cast(extract(year from cast(hci.survey_request_date as date))||''-''||extract(month from cast(hci.survey_request_date as date))||''-01''  as date) ,vas.visit_month) between 366 and 730 and social_fg =''Yes'' 
then 1 else 0 end)>0) then ''Yes'' else ''No'' end as VAS_SOC_Y2

,case when (sum(case when DATEDIFF(day, cast(extract(year from cast(hci.survey_request_date as date))||''-''||extract(month from cast(hci.survey_request_date as date))||''-01''  as date) ,vas.visit_month) between 366 and 730 and nurseline_inbound_fg =''Yes'' 
then 1 else 0 end)>0) then ''Yes'' else ''No'' end as VAS_NL_Y2

,case when (sum(case when DATEDIFF(day, cast(extract(year from cast(hci.survey_request_date as date))||''-''||extract(month from cast(hci.survey_request_date as date))||''-01''  as date) ,vas.visit_month) between 366 and 730 and ons_fg =''Yes'' 
then 1 else 0 end)>0) then ''Yes'' else ''No'' end as VAS_ONS_Y2

from IDENTIFIER(:V_HCI_MBR_TYPE_DEDUP_4) as hci
left join IDENTIFIER(:V_VAS_HNW_MASTER) as vas
on hci.pers_id=vas.pers_id
and cast(extract(year from cast(hci.survey_request_date as date))||''-''||extract(month from cast(hci.survey_request_date as date))||''-01''  as date) <= vas.visit_month
group by hci.mbr_asmt_srvc_req_id, hci.pers_id;
           


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCI_VAS_ONS_Flag)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP17'';

V_STEP_NAME :=  ''Create table HCI_AllLapser_Base_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_HCI_ALLLAPSER_BASE_1) COPY GRANTS as 
select 
a11.prem_due_dt_id
,a11.prdct_eff_dt_id
,a11.acct_nbr
,a11.d_mbr_info_sk
,(case when a31.person_id is null then a27.pers_id else a31.person_id end) as pers_id
,a11.D_CERT_ACTV_SK 
,a12.CERT_ACTV_LVL_1_TXT
,a12.CERT_ACTV_LVL_2_TXT
,a12.CERT_ACTV_LVL_3_TXT		
,sum(a11.TERM_CERT_QTY) as term
		
from IDENTIFIER(:V_F_PREM_TRANS_DAY) a11         
        left join IDENTIFIER(:V_D_CERT_ACTV) a12
		on (a11.D_CERT_ACTV_SK = a12.D_CERT_ACTV_SK) 
		left join IDENTIFIER(:V_D_PLN_BEN_MOD) a13 
		on (a11.D_PLN_BEN_MOD_SK = a13.D_PLN_BEN_MOD_SK) 
        left join IDENTIFIER(:V_D_MBR_INFO) as a27
        on a11.d_mbr_info_sk = a27.d_mbr_info_sk
        left join IDENTIFIER(:V_SHIP_PERSON_XREF) a31
        on a27.INDV_ID = a31.SHIP_PERSON_ID		
		
where (

floor(a11.prem_due_dt_id/100) >= 202101
and

a13.PRDCT_SUB_GRP in (''Med Supp Base'')

and a11.D_CERT_ACTV_SK in 
(
19
,20
,21
,22
,23
,24
,25
,26
,27
,28
,29
,30
,31
,32
,33
,34
,35
,36
,37
,38
,39
,40
,41
,42
,43
,47
)
)

group by 
a11.prem_due_dt_id
,a11.prdct_eff_dt_id
,a11.acct_nbr
,a11.d_mbr_info_sk
,(case when a31.person_id is null then a27.pers_id else a31.person_id end)
,a11.D_CERT_ACTV_SK 
,a12.CERT_ACTV_LVL_1_TXT
,a12.CERT_ACTV_LVL_2_TXT
,a12.CERT_ACTV_LVL_3_TXT

having (term >0) 
order by pers_id, a11.prem_due_dt_id  desc
;
               

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCI_ALLLAPSER_BASE_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP18'';

V_STEP_NAME :=  ''Create table HCI_AllLapser_Base_2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_HCI_ALLLAPSER_BASE_2) COPY GRANTS  as
select *,cast(concat(substr(prem_due_dt_id,1,4), ''-'',substr(prem_due_dt_id,5,2), ''-'',''01'') as date) as trm_date
        ,cast(concat(substr(prdct_eff_dt_id,1,4), ''-'',substr(prdct_eff_dt_id,5,2), ''-'',''01'') as date) as prdct_eff_dt		
	,Case when D_CERT_ACTV_SK between 19 and 42 then ''Voluntary'' 
		when D_CERT_ACTV_SK in (43) then ''NPOP'' 
		when D_CERT_ACTV_SK in (47) then ''Involuntary-Death'' 
		else ''Others'' end as Lapse_Type
	, substr(CERT_ACTV_LVL_3_TXT, REGEXP_INSTR(CERT_ACTV_LVL_3_TXT,''-'')+1 ) as Lapse_reason	
	,Case when D_CERT_ACTV_SK between 19 and 42 then 1 else 0 end as Vol_Lapsers_Flg
	,Case when D_CERT_ACTV_SK in (43) then 1 else 0 end as NPOP_Lapsers_Flg 
	,Case when D_CERT_ACTV_SK in (47) then 1 else 0 end as Death_Lapsers_Flg 		
		
from IDENTIFIER(:V_HCI_ALLLAPSER_BASE_1);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCI_ALLLAPSER_BASE_2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP19'';

V_STEP_NAME :=  ''Create table HCI_AllLapser_Base_3'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_HCI_ALLLAPSER_BASE_3) COPY GRANTS  as
SELECT  
hci.mbr_asmt_srvc_req_id
,hci.pers_id
,hci.survey_request_date
,Lap.trm_date
,Lap.prdct_eff_dt
,Lap.Lapse_Type
,Lap.Lapse_reason
,Lap.Vol_Lapsers_Flg
,Lap.NPOP_Lapsers_Flg
,Lap.Death_Lapsers_Flg

,DATEDIFF(day,Lap.trm_date,hci.survey_request_date) as surv_req_trm_date_Diff

from IDENTIFIER(:V_HCI_MBR_TYPE_DEDUP_4) as hci
inner join IDENTIFIER(:V_HCI_ALLLAPSER_BASE_2) as Lap
on hci.pers_id=Lap.pers_id
and hci.survey_request_date <= Lap.trm_date
;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCI_ALLLAPSER_BASE_3)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP20'';

V_STEP_NAME :=  ''Create table HCI_AllLapser_Base_4'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_HCI_ALLLAPSER_BASE_4) COPY GRANTS  as
select *
,ROW_NUMBER() OVER(PARTITION By pers_id,survey_request_date  
order by  surv_req_trm_date_Diff ) as row_num_lap
from IDENTIFIER(:V_HCI_ALLLAPSER_BASE_3) 
;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCI_ALLLAPSER_BASE_4)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP21'';

V_STEP_NAME :=  ''Create table HCI_Lapser_post_Surv_dt'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_HCI_LAPSER_POST_SURV_DT) COPY GRANTS  as
select * from IDENTIFIER(:V_HCI_ALLLAPSER_BASE_4)
where row_num_lap=1; 

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCI_LAPSER_POST_SURV_DT)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP22'';

V_STEP_NAME :=  ''Create table HCI_claims_prem_New_Enr_Y1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_HCI_CLAIMS_PREM_NEW_ENR_Y1) COPY GRANTS  as
select 
hci.mbr_asmt_srvc_req_id
,hci.pers_id
,cast(concat(substr(clm.prem_due_mo_id,1,4), ''-'',substr(clm.prem_due_mo_id,5,2), ''-'',''01'') as date) as prem_due_dt 
,clm.paid_prem_paid_date
,clm.claim_paid_date
,clm.claim_covid_adj_paid_date
,clm.month_total
 
from 
( select * from IDENTIFIER(:V_HCI_MBR_TYPE_DEDUP_4) where Member_Type=''New Enrollee'' ) as hci
inner join IDENTIFIER(:V_LRCCO_FINAL_0811) as clm
on hci.pers_id=clm.pers_id
and 
 Cast(extract(year from cast(hci.survey_request_date as date))||''-''||extract(month from cast(hci.survey_request_date as date))||''-01'' as date) = cast(concat(substr(clm.prem_due_mo_id,1,4), ''-'',substr(clm.prem_due_mo_id,5,2), ''-'',''01'') as date)

and clm.eff_dt >=''2019-01-01'' and clm.year =1
;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCI_CLAIMS_PREM_NEW_ENR_Y1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP23'';

V_STEP_NAME :=  ''Create table HCI_claims_prem_New_Enr_Y2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


CREATE OR REPLACE TABLE IDENTIFIER(:V_HCI_CLAIMS_PREM_NEW_ENR_Y2) COPY GRANTS  as
select 
hci.mbr_asmt_srvc_req_id
,hci.pers_id
,cast(concat(substr(clm.prem_due_mo_id,1,4), ''-'',substr(clm.prem_due_mo_id,5,2), ''-'',''01'') as date) as prem_due_dt 
,clm.paid_prem_paid_date
,clm.claim_paid_date
,clm.claim_covid_adj_paid_date
,clm.month_total
 
from 
( select * from IDENTIFIER(:V_HCI_MBR_TYPE_DEDUP_4) where Member_Type=''New Enrollee'' ) as hci
inner join IDENTIFIER(:V_LRCCO_FINAL_0811) as clm
on hci.pers_id=clm.pers_id
and 
 Cast(extract(year from cast(hci.survey_request_date as date))||''-''||extract(month from cast(hci.survey_request_date as date))||''-01'' as date) = cast(concat(substr(clm.prem_due_mo_id,1,4), ''-'',substr(clm.prem_due_mo_id,5,2), ''-'',''01'') as date)

and clm.eff_dt >=''2019-01-01'' and clm.year =2
;



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCI_CLAIMS_PREM_NEW_ENR_Y2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP24'';

V_STEP_NAME :=  ''Create table HCI_Mbr_Type_Dedup_4_inf'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_HCI_MBR_TYPE_DEDUP_4_INF) COPY GRANTS  as
select 
mbr_asmt_srvc_req_id
,pers_id
,cast(extract(year from cast(survey_request_date as date))||''-''||extract(month from cast(survey_request_date as date))||''-01''  as date) as survey_request_date
,prdct_eff_dt
from IDENTIFIER(:V_HCI_MBR_TYPE_DEDUP_4) where Member_Type=''Inforce'' 
;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCI_MBR_TYPE_DEDUP_4_INF)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP25'';

V_STEP_NAME :=  ''Create table HCI_claims_prem_Inf_Pre_Y1_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


CREATE OR REPLACE TABLE IDENTIFIER(:V_HCI_CLAIMS_PREM_INF_PRE_Y1_1) COPY GRANTS  as
select 
hci.mbr_asmt_srvc_req_id
,hci.pers_id
,hci.survey_request_date
,hci.prdct_eff_dt
,Inf.prem_due_dt
,months_between(hci.survey_request_date,Inf.prem_due_dt) as Sur_req_prem_due_dt_Diff
,Inf.paid_prem
,Inf.claim
,Inf.claim_cf_covid

from IDENTIFIER(:V_HCI_MBR_TYPE_DEDUP_4_INF) as hci
left join IDENTIFIER(:V_P_LVL_CLAIM_INFO) as Inf
on hci.pers_id=Inf.pers_id
and hci.prdct_eff_dt=Inf.prdct_eff_dt
and months_between(hci.survey_request_date,Inf.prem_due_dt) between 1 and 12
order by 1,2,3,4
;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCI_CLAIMS_PREM_INF_PRE_Y1_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP26'';

V_STEP_NAME :=  ''Create table HCI_claims_prem_Inf_Pre_Y1_2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_HCI_CLAIMS_PREM_INF_PRE_Y1_2) COPY GRANTS  as
select 
mbr_asmt_srvc_req_id
,pers_id
,prdct_eff_dt
,count(distinct prem_due_dt) as month_total
,sum(paid_prem) as paid_prem
,sum(claim) as claim
,sum(claim_cf_covid) as claim_cf_covid
from IDENTIFIER(:V_HCI_CLAIMS_PREM_INF_PRE_Y1_1)
group by 1,2,3
order by 1,2,3
;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCI_CLAIMS_PREM_INF_PRE_Y1_2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP27'';

V_STEP_NAME :=  ''Create table HCI_claims_prem_Inf_Pre_Y2_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_HCI_CLAIMS_PREM_INF_PRE_Y2_1) COPY GRANTS  as
select 
hci.mbr_asmt_srvc_req_id
,hci.pers_id
,hci.survey_request_date
,hci.prdct_eff_dt
,Inf.prem_due_dt
,months_between(hci.survey_request_date,Inf.prem_due_dt) as Sur_req_prem_due_dt_Diff
,Inf.paid_prem
,Inf.claim
,Inf.claim_cf_covid

from IDENTIFIER(:V_HCI_MBR_TYPE_DEDUP_4_INF) as hci
left join IDENTIFIER(:V_P_LVL_CLAIM_INFO) as Inf
on hci.pers_id=Inf.pers_id
and hci.prdct_eff_dt=Inf.prdct_eff_dt
and months_between(hci.survey_request_date,Inf.prem_due_dt) between 1 and 24
order by 1,2,3,4
;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCI_CLAIMS_PREM_INF_PRE_Y2_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP28'';

V_STEP_NAME :=  ''Create table HCI_claims_prem_Inf_Pre_Y2_2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_HCI_CLAIMS_PREM_INF_PRE_Y2_2) COPY GRANTS  as
select 
mbr_asmt_srvc_req_id
,pers_id
,prdct_eff_dt
,count(distinct prem_due_dt) as month_total
,sum(paid_prem) as paid_prem
,sum(claim) as claim
,sum(claim_cf_covid) as claim_cf_covid
from IDENTIFIER(:V_HCI_CLAIMS_PREM_INF_PRE_Y2_1)
group by 1,2,3
order by 1,2,3
;



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCI_CLAIMS_PREM_INF_PRE_Y2_2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP29'';

V_STEP_NAME :=  ''Create table HCI_claims_prem_Inf_Post_Y1_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_HCI_CLAIMS_PREM_INF_POST_Y1_1) COPY GRANTS  as
select 
hci.mbr_asmt_srvc_req_id
,hci.pers_id
,hci.survey_request_date
,hci.prdct_eff_dt
,Inf.prem_due_dt
,months_between(Inf.prem_due_dt,hci.survey_request_date) as Sur_req_prem_due_dt_Diff
,Inf.paid_prem
,Inf.claim
,Inf.claim_cf_covid

from IDENTIFIER(:V_HCI_MBR_TYPE_DEDUP_4_INF) as hci
left join IDENTIFIER(:V_P_LVL_CLAIM_INFO) as Inf
on hci.pers_id=Inf.pers_id
and hci.prdct_eff_dt=Inf.prdct_eff_dt
and months_between(Inf.prem_due_dt,hci.survey_request_date) between 1 and 12
order by 1,2,3,4
;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCI_CLAIMS_PREM_INF_POST_Y1_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP30'';

V_STEP_NAME :=  ''Create table HCI_claims_prem_Inf_Post_Y1_2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_HCI_CLAIMS_PREM_INF_POST_Y1_2) COPY GRANTS  as
select 
mbr_asmt_srvc_req_id
,pers_id
,prdct_eff_dt
,count(distinct prem_due_dt) as month_total
,sum(paid_prem) as paid_prem
,sum(claim) as claim
,sum(claim_cf_covid) as claim_cf_covid
from IDENTIFIER(:V_HCI_CLAIMS_PREM_INF_POST_Y1_1)
group by 1,2,3
order by 1,2,3
;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCI_CLAIMS_PREM_INF_POST_Y1_2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP31'';

V_STEP_NAME :=  ''Create table HCI_claims_prem_Inf_Post_Y2_1,'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_HCI_CLAIMS_PREM_INF_POST_Y2_1) COPY GRANTS  as
select 
hci.mbr_asmt_srvc_req_id
,hci.pers_id
,hci.survey_request_date
,hci.prdct_eff_dt
,Inf.prem_due_dt
,months_between(Inf.prem_due_dt,hci.survey_request_date) as Sur_req_prem_due_dt_Diff
,Inf.paid_prem
,Inf.claim
,Inf.claim_cf_covid

from IDENTIFIER(:V_HCI_MBR_TYPE_DEDUP_4_INF) as hci
left join IDENTIFIER(:V_P_LVL_CLAIM_INFO) as Inf
on hci.pers_id=Inf.pers_id
and hci.prdct_eff_dt=Inf.prdct_eff_dt
and months_between(Inf.prem_due_dt,hci.survey_request_date) between 1 and 24
order by 1,2,3,4
;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCI_CLAIMS_PREM_INF_POST_Y2_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP32'';

V_STEP_NAME :=  ''Create table HCI_claims_prem_Inf_Post_Y2_2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_HCI_CLAIMS_PREM_INF_POST_Y2_2) COPY GRANTS  as
select 
mbr_asmt_srvc_req_id
,pers_id
,prdct_eff_dt
,count(distinct prem_due_dt) as month_total
,sum(paid_prem) as paid_prem
,sum(claim) as claim
,sum(claim_cf_covid) as claim_cf_covid
from IDENTIFIER(:V_HCI_CLAIMS_PREM_INF_POST_Y2_1)
group by 1,2,3
order by 1,2,3
;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCI_CLAIMS_PREM_INF_POST_Y2_2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP33'';

V_STEP_NAME :=  ''Create table HCI_disb_sales_enroll_flag_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_HCI_DISB_SALES_ENROLL_FLAG_1) COPY GRANTS  as
SELECT distinct
hci.mbr_asmt_srvc_req_id
,hci.pers_id
,hci.compas_insd_pln_id_inf
,hci.e_alliance_old_category
,app.source_insured_plan_id as source_insured_plan_id_1

,hci.agt_id_final
,hci.prdct_ACQN_CHNL_LVL_1
,hci.ref_ealliance_pref_nm

,case when app.source_insured_plan_id is not NULL then app.disabled else NULL end as disabled_sales_flag_1
,case when app.source_insured_plan_id is not NULL then app.Enrollment else NULL end as Enrollment_1
,case when app.source_insured_plan_id is not NULL then app.ENROLLMENT_CALL_CENTER_SOURCE else NULL end as ENROLLMENT_CALL_CENTER_SOURCE_1
,case when app.source_insured_plan_id is not NULL then app.enrollment_process else NULL end as enrollment_process_1

from IDENTIFIER(:V_HCI_MBR_TYPE_DEDUP_4) as hci
left join IDENTIFIER(:V_APPS_RPTG_DAILY) as App
on hci.compas_insd_pln_id_inf =app.source_insured_plan_id
and App.appl_receipt_date >= ''2018-01-01'' 
;



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCI_DISB_SALES_ENROLL_FLAG_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP34'';

V_STEP_NAME :=  ''Create table HCI_disb_sales_enroll_flag_2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_HCI_DISB_SALES_ENROLL_FLAG_2) COPY GRANTS  as
SELECT distinct
hci.mbr_asmt_srvc_req_id
,hci.pers_id
,hci.compas_insd_pln_id_inf
,hci.agt_id_final
,hci.prdct_ACQN_CHNL_LVL_1
,hci.e_alliance_old_category
,hci.ref_ealliance_pref_nm

,coalesce(hci.source_insured_plan_id_1, app.source_insured_plan_id) as source_insured_plan_id

,coalesce(hci.disabled_sales_flag_1, case when app.source_insured_plan_id is not NULL then app.disabled else NULL end) as disabled_sales_flag

,coalesce(hci.Enrollment_1, case when app.source_insured_plan_id is not NULL then app.Enrollment else NULL end) as Enrollment

,coalesce(hci.ENROLLMENT_CALL_CENTER_SOURCE_1, case when app.source_insured_plan_id is not NULL then app.ENROLLMENT_CALL_CENTER_SOURCE else NULL end) as ENROLLMENT_CALL_CENTER_SOURCE

,coalesce(hci.enrollment_process_1 ,case when app.source_insured_plan_id is not NULL then app.enrollment_process else NULL end) as enrollment_process

from IDENTIFIER(:V_HCI_DISB_SALES_ENROLL_FLAG_1) as hci
left join IDENTIFIER(:v_apps_rptg_daily_2000_2024) as App
on hci.compas_insd_pln_id_inf =app.source_insured_plan_id
and App.appl_receipt_date <= ''2023-12-31'' 
;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCI_DISB_SALES_ENROLL_FLAG_2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP35'';

V_STEP_NAME :=  ''Create table HCI_disb_sales_enroll_flag_3'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_HCI_DISB_SALES_ENROLL_FLAG_3) COPY GRANTS  as
select a.*,
(case when a.source_insured_plan_id is null then ''Not Found''
when a.agt_id_final in (''SQS3333'',''SQS4444'') then ''SQS_VS''
when a.agt_id_final in (''SQS2222'',''GOH2222'',''INS2222'',''EHC2222'') then ''MA-Leads_Captives''
when a.Enrollment = ''Application Assistance'' and a.ENROLLMENT_CALL_CENTER_SOURCE = ''CSS'' then ''Optum AS''
when a.Enrollment = ''Application Assistance'' and a.ENROLLMENT_CALL_CENTER_SOURCE = ''UCC'' then ''UCC_AS''
when a.Enrollment = ''Voice Signature'' and a.ENROLLMENT_CALL_CENTER_SOURCE = ''CSS'' then ''Optum VS''
when a.Enrollment = ''Voice Signature'' and a.ENROLLMENT_CALL_CENTER_SOURCE = ''UCC'' then ''UCC_VS''
when a.prdct_ACQN_CHNL_LVL_1= ''Agent'' and a.enrollment_type in (''Agent Mailed'', ''Agent OLE'') then enrollment_type
when a.prdct_ACQN_CHNL_LVL_1 in  (''DTC'',''UNKNOWN'')  and a.enrollment = (''Customer Mailed App'') then ''Cust Mailed''
when a.prdct_ACQN_CHNL_LVL_1 in  (''DTC'',''UNKNOWN'')  and a.enrollment = (''Customer OLE'') then ''Cust OLE''
when (a.prdct_ACQN_CHNL_LVL_1 = ''Aggregator'' and a.e_alliance_old_category is not null) and  a.enrollment = (''Agent Aggr'') then ''Aggr Web''
when (a.ref_ealliance_pref_nm is not null and a.ref_ealliance_pref_nm not in (''NotApplicable'',''Unknown''))  and a.enrollment = (''Agent Aggr'') then ''Aggr Web''
when (a.prdct_ACQN_CHNL_LVL_1 =''Aggregator'' and a.e_alliance_old_category is null ) then ''Others''
when a.prdct_ACQN_CHNL_LVL_1 = ''Employer'' and a.enrollment = (''Customer Mailed App'') then ''Cust Mailed''
when a.prdct_ACQN_CHNL_LVL_1 = ''Employer'' and a.enrollment = (''Customer OLE'') then ''Cust OLE''
else ''Others'' end) as sub_channel from
(
	select 
	b.*
	,(case when b.enrollment_process in (''CUSTOMER MAILED APPLICATION'',''CUSTOMER BEGAN WEB ENROLL - MAILED APP'') then ''Cust Mailed''
	when b.enrollment_process in (''TSR: APP ASSIST PHONE ENROLLMENT'',''TSR:APP ASSIST DIGITAL ENROLLMENT'') then ''App Assist''
	when b.enrollment_process in (''TSR: VOICE SIGNATURE PHONE ENROLLMENT'') then ''Voice Sign''
	when b.enrollment_process in (''CUSTOMER WEB ENROLLMENT'') then ''Cust OLE''
	when b.enrollment_process in (''TSR: PLAN CHANGE PHONE'',''OPERATIONS - PLAN CHANGE GENERATED VIA UI'',''AGENT FIELDS: PLAN CHANGE'') then ''Plan Change''
	when b.enrollment_process in (''AGENT ELECTRONIC WEB ENROLLMENT'') then ''Aggr Web''
	when b.enrollment_process in (''APP ASSIST - AGENT COVERAGE'') then ''Agent App Assist''
	when b.enrollment_process in (''AGENT: MAILED APP'') then ''Agent Mailed''
	when b.enrollment_process in (''AGENT: WEB ENROLLMENT'')  then ''Agent OLE''
	when b.enrollment_process in (''OPERATIONS - UNKNOWN CHANNEL - GENERATED VIA UI'',''AGENT: CHANNEL UNK -  UI'') then ''Other''
	when b.enrollment_process in (''INVALID'') then ''Other''
	else ''CHECK'' end) as enrollment_type

	from IDENTIFIER(:V_HCI_DISB_SALES_ENROLL_FLAG_2) as b
) as a
;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCI_DISB_SALES_ENROLL_FLAG_3)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP36'';

V_STEP_NAME :=  ''Create table HCI_ez_clm_reg'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


CREATE OR REPLACE TABLE IDENTIFIER(:V_HCI_EZ_CLM_REG) COPY GRANTS  as
SELECT distinct
hci.mbr_asmt_srvc_req_id
,hci.pers_id
,(case when ez.acct_nbr is null then ''N'' else ''Y'' end) as ez_clm_reg
from IDENTIFIER(:V_HCI_MBR_TYPE_DEDUP_4) as hci
left join IDENTIFIER(:V_EZCLAIM_ENROLLED_FOR_LAPSE_SA)  as ez
on hci.ucps_id=lpad(ez.acct_nbr,11,''0'')
;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCI_EZ_CLM_REG)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP37'';

V_STEP_NAME :=  ''Create TABLE HCI_ma_cont_membership_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_HCI_MA_CONT_MEMBERSHIP_1) COPY GRANTS  as
select 
medicare_hicn_cd
,mbr_plan_eff_dt
,dsenrl_dt
from IDENTIFIER(:V_MA_MBR_CONT)
where to_date(dsenrl_dt)>to_date(mbr_plan_eff_dt);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCI_MA_CONT_MEMBERSHIP_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP38'';

V_STEP_NAME :=  ''Create TABLE HCI_ma_migrators_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_HCI_MA_MIGRATORS_1) COPY GRANTS  as
SELECT distinct
hci.mbr_asmt_srvc_req_id
,hci.pers_id
,(case when b.medicare_hicn_cd is null then ''N'' else ''Y'' end) as ma_ms_migrator_flag

from IDENTIFIER(:V_HCI_MBR_TYPE_DEDUP_4) as hci
left join IDENTIFIER(:V_HCI_MA_CONT_MEMBERSHIP_1) as b 
on hci.medcr_id=b.medicare_hicn_cd
and DATEDIFF(day, to_date(add_months(hci.prdct_eff_dt,1)),to_date(b.mbr_plan_eff_dt))>=0 
and DATEDIFF(day, to_date(add_months(hci.prdct_eff_dt,1)),to_date(b.mbr_plan_eff_dt))<=63;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCI_MA_MIGRATORS_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP39'';

V_STEP_NAME :=  ''Create TABLE hci_dash_phase_2_summ_bkp'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_HCI_DASH_PHASE_2_SUMM_BKP) COPY GRANTS  as
select * from IDENTIFIER(:V_HCI_DASH_PHASE_2_SUMM);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCI_DASH_PHASE_2_SUMM_BKP)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP40'';

V_STEP_NAME :=  ''Create table hci_dash_phase_2_summ'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_HCI_DASH_PHASE_2_SUMM) COPY GRANTS  as
Select  
hci.rap_member_request_id_sk
,hci.mbr_asmt_srvc_req_id
,hci.ucps_id as acct_nbr
,hci.hci_assessment_data_sk
,hci.pers_id
,hci.survey_request_date
,hci.asmt_date
,case when DATEDIFF(day,hci.survey_request_date,hci.asmt_date) between 0 AND 30 then ''1 month''
when DATEDIFF(day,hci.survey_request_date,hci.asmt_date) between 31 AND 90 then ''2 to 3 month''
when DATEDIFF(day,hci.survey_request_date,hci.asmt_date) between 91 AND 180 then ''4 to 6 month''
when DATEDIFF(day,hci.survey_request_date,hci.asmt_date) between 180 AND 365 then ''7 to 12 months''
when DATEDIFF(day,hci.survey_request_date,hci.asmt_date) >365 then ''>1 Year'' 
when hci.asmt_date is NULL then ''Non-Responders'' 
else ''Others'' 
end as Response_Time_period

,hci.prdct_eff_dt
,hci.responder_type
,hci.member_type
,case when hci.pers_id is not null then 1 else 0 end as mbr 
,Lap.trm_date as term_date1
,Lap.Lapse_Type
,Lap.Lapse_reason
,Lap.Vol_Lapsers_Flg
,Lap.NPOP_Lapsers_Flg
,Lap.Death_Lapsers_Flg

,VAS.vas_gym_y1
,VAS.vas_dig_y1
,VAS.vas_cog_y1
,VAS.vas_soc_y1
,VAS.vas_nl_y1
,VAS.vas_ons_y1
,VAS.vas_gym_y2
,VAS.vas_dig_y2
,VAS.vas_cog_y2
,VAS.vas_soc_y2
,VAS.vas_nl_y2
,VAS.vas_ons_y2

,enr.disabled_sales_flag
,enr.sub_channel as sub_channel_final
,enr.enrollment_type
,ez.ez_clm_reg
,mig.ma_ms_migrator_flag


,COALESCE(Enr_y2.paid_prem_paid_date,Inf_Post_y2.paid_prem,0) as y2_Post_paid_prem
,COALESCE(Enr_y2.claim_paid_date,Inf_Post_y2.claim,0) as y2_Post_claims
,COALESCE(Enr_y2.claim_covid_adj_paid_date,Inf_Post_y2.claim_cf_covid,0) as y2_Post_claims_covid_adj
,COALESCE(Enr_y2.month_total,Inf_Post_y2.month_total,0) as y2_Post_cert_qty

,COALESCE(Enr_y1.paid_prem_paid_date,Inf_Post_y1.paid_prem,0) as y1_Post_paid_prem
,COALESCE(Enr_y1.claim_paid_date,Inf_Post_y1.claim,0) as y1_Post_claims
,COALESCE(Enr_y1.claim_covid_adj_paid_date,Inf_Post_y1.claim_cf_covid,0) as y1_Post_claims_covid_adj
,COALESCE(Enr_y1.month_total,Inf_Post_y1.month_total,0) as y1_Post_cert_qty

,COALESCE(Inf_pre_y2.paid_prem,0) as y2_Pre_paid_prem
,COALESCE(Inf_pre_y2.claim,0) as y2_Pre_claims
,COALESCE(Inf_pre_y2.claim_cf_covid,0) as y2_Pre_claims_covid_adj
,COALESCE(Inf_pre_y2.month_total,0) as y2_Pre_cert_qty

,COALESCE(Inf_pre_y1.paid_prem,0) as y1_Pre_paid_prem
,COALESCE(Inf_pre_y1.claim,0) as y1_Pre_claims
,COALESCE(Inf_pre_y1.claim_cf_covid,0) as y1_Pre_claims_covid_adj
,COALESCE(Inf_pre_y1.month_total,0)as y1_Pre_cert_qty

,hci.prem_due_age_id
,hci.partb_eff_age_lessthan65
,hci.age
,hci.agt_sub_typ
,hci.agt_typ_final
,hci.cnty_cd
,hci.cnty_nm
,hci.d_st_cd
,hci.dob
,hci.dscnt_annl_payr_desc
,hci.dscnt_eft_desc
,hci.dscnt_erly_enrl_desc
,hci.dscnt_multi_insd_desc
,hci.e_alliance_new_category
,hci.e_alliance_old_category
,hci.gdr_desc
,hci.lgl_enty_nm
,hci.marketing_channel_final
,hci.pdp_fg as ms_pdp_combo_flag
,hci.plan_cd
,hci.pln_lvl
,hci.rt_dtrm_cd_desc
,hci.rtng_area_nm
,hci.surchrg_tbcc_user_flg
,hci.undwr_pln_rqr_txt
,hci.undwr_prdct_rqr_txt
,hci.zip_cd

,case when hci.pln_lvl in (''F'',''F01'',''FS1'',''F02'',''FS2'') then ''F'' 
	when hci.pln_lvl in (''G'',''G01'',''GS1'',''G02'',''GS2'') THEN ''G'' 
	when hci.pln_lvl in (''GH1'',''GH2'')  THEN ''GH''	
	when hci.pln_lvl in (''N'',''N01'',''NS1'',''N02'',''NS2'') then ''N''
	when hci.pln_lvl in (''K'',''K01'') then ''K''
	when hci.pln_lvl='''' then ''Unknown''
	ELSE ''Others''
END as plan_grp 

,asmt.q10730
,asmt.q14047
,asmt.q14050
,asmt.q14046
,asmt.q14056
,asmt.q14057
,asmt.q14323
,asmt.q3869
,asmt.q3870
,asmt.q3872
,asmt.q51622
,asmt.q51625
,asmt.q51624
,asmt.q12181
,asmt.q10697
,asmt.q10696
,asmt.q14052
,asmt.q10698
,asmt.q14051
,asmt.q14058
,asmt.q3619
,asmt.q3871
,asmt.pain
,asmt.q14054
,asmt.q394
,asmt.q14055
,asmt.q14053
,asmt.q395
,asmt.lonely_level
,asmt.lonely_lvl
,asmt.dep_flag
,asmt.q51623
,asmt.q51621
,asmt.q51626
,asmt.q54801

from IDENTIFIER(:V_HCI_MBR_TYPE_DEDUP_4) as hci
left join IDENTIFIER(:V_HCI_ASSESS_DT_CAL) as asmt
on hci.hci_assessment_data_sk =asmt.hci_assessment_data_sk

left join IDENTIFIER(:V_HCI_VAS_ONS_FLAG) as VAS 
on hci.mbr_asmt_srvc_req_id =VAS.mbr_asmt_srvc_req_id

left join IDENTIFIER(:V_HCI_LAPSER_POST_SURV_DT) as Lap
on hci.mbr_asmt_srvc_req_id =Lap.mbr_asmt_srvc_req_id

left join IDENTIFIER(:V_HCI_DISB_SALES_ENROLL_FLAG_3) as enr
on hci.mbr_asmt_srvc_req_id =enr.mbr_asmt_srvc_req_id

left join IDENTIFIER(:V_HCI_EZ_CLM_REG) as ez
on hci.mbr_asmt_srvc_req_id =ez.mbr_asmt_srvc_req_id

left join IDENTIFIER(:V_HCI_MA_MIGRATORS_1) as mig
on hci.mbr_asmt_srvc_req_id =mig.mbr_asmt_srvc_req_id

left join IDENTIFIER(:V_HCI_CLAIMS_PREM_NEW_ENR_Y2) as Enr_y2
on hci.mbr_asmt_srvc_req_id =Enr_y2.mbr_asmt_srvc_req_id
left join IDENTIFIER(:V_HCI_CLAIMS_PREM_NEW_ENR_Y1) as Enr_y1
on hci.mbr_asmt_srvc_req_id =Enr_y1.mbr_asmt_srvc_req_id

left join IDENTIFIER(:V_HCI_CLAIMS_PREM_INF_POST_Y2_2) as Inf_post_y2
on hci.mbr_asmt_srvc_req_id =Inf_post_y2.mbr_asmt_srvc_req_id
left join IDENTIFIER(:V_HCI_CLAIMS_PREM_INF_POST_Y1_2) as Inf_post_y1
on hci.mbr_asmt_srvc_req_id =Inf_post_y1.mbr_asmt_srvc_req_id

left join IDENTIFIER(:V_HCI_CLAIMS_PREM_INF_PRE_Y2_2) as Inf_pre_y2
on hci.mbr_asmt_srvc_req_id =Inf_pre_y2.mbr_asmt_srvc_req_id
left join IDENTIFIER(:V_HCI_CLAIMS_PREM_INF_PRE_Y1_2) as Inf_pre_y1
on hci.mbr_asmt_srvc_req_id =Inf_pre_y1.mbr_asmt_srvc_req_id


where hci.Member_Type in ( ''Inforce'', ''New Enrollee'' )
;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_HCI_DASH_PHASE_2_SUMM)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);


RAISE;

END;

';