USE SCHEMA BDR_FFP_DA;

CREATE OR REPLACE PROCEDURE BDR_FFP_DA.SP_EZCLAIM("PIPELINE_ID" VARCHAR(16777216), "PIPELINE_NAME" VARCHAR(16777216), "DB_NAME" VARCHAR(16777216), "UTIL_SC" VARCHAR(16777216), "SRC_SC_1" VARCHAR(16777216), "SRC_SC_2" VARCHAR(16777216), "SRC_SC_3" VARCHAR(16777216), "SRC_SC_4" VARCHAR(16777216), "SRC_SC_5" VARCHAR(16777216), "SRC_SC_6" VARCHAR(16777216), "SRC_SC_7" VARCHAR(16777216), "SRC_SC_8" VARCHAR(16777216), "WRK_SC" VARCHAR(16777216), "TGT_SC" VARCHAR(16777216), "WH" VARCHAR(16777216), "CURR_DATE" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

V_CURRENT_DATE   DATE := COALESCE(TO_DATE(:CURR_DATE), CURRENT_DATE());

V_REPORT_DATE VARCHAR := COALESCE(:V_CURRENT_DATE, CURRENT_DATE());

V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := :DB_NAME||''.''||COALESCE(:UTIL_SC, ''UTIL'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';

V_PROCESS_NAME   VARCHAR DEFAULT ''EZCLAIM'';

V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''EZCLAIM'';

V_STEP             VARCHAR;

V_STEP_NAME        VARCHAR;

V_START_TIME       VARCHAR;

V_END_TIME         VARCHAR;

V_ROWS_PARSED       INTEGER;

V_ROWS_LOADED       INTEGER;

V_MESSAGE          VARCHAR;

V_LAST_QUERY_ID    VARCHAR;



V_D_ST VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_1, ''BDR_CONF'') || ''.D_ST'';

V_EZ_CLM_CAMP5 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.EZ_CLM_CAMP5'';

V_MEMBERSHIP_2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.MEMBERSHIP_2'';

V_EZ_CLM_CAMP_SA_DATE VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.EZCLAIM_EZ_CLM_CAMP_SA_DATE'';

V_D_SURCHRG_TIER VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_2, ''BDR_DM'') || ''.D_SURCHRG_TIER'';

V_EZ_CLM_CAMP4 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.EZ_CLM_CAMP4'';

V_D_SURCHRG_TBCC_USER VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_2, ''BDR_DM'') || ''.D_SURCHRG_TBCC_USER'';

V_D_GDR_LOOK VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_1, ''BDR_CONF'') || ''.D_GDR_LOOK'';

V_EZ_CLM_MBR_2022_23_24 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.EZ_CLM_MBR_2022_23_24'';

V_CMS_HICN_TO_MBI_CROSSWALK VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_3, ''SRC_UCEE'') || ''.CMS_HICN_TO_MBI_CROSSWALK'';

V_D_DSCNT_ERLY_ENRL VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_2, ''BDR_DM'') || ''.D_DSCNT_ERLY_ENRL'';

V_EZ_CLM_CAMP9_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.EZ_CLM_CAMP9_1'';

V_PRIV_AUTH1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.PRIV_AUTH1'';

V_AMERILINK_SNAPSHOT_JUL23 VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_4, ''SRC_FIN360'') || ''.AMERILINK_SNAPSHOT_JUL23'';

V_D_MBR_INFO VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_1, ''BDR_CONF'') || ''.D_MBR_INFO''; 

V_MBR_DT_CHK2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.EZCLAIM_MBR_DT_CHK2'';

V_EZ_CLM_CAMP_PERS VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.EZ_CLM_CAMP_PERS'';

V_EZCLAIM_ENROLLED_FOR_LAPSE_SA VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.EZCLAIM_EZCLAIM_ENROLLED_FOR_LAPSE_SA'';

V_D_ACQN_CHNL VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_1, ''BDR_CONF'') || ''.D_ACQN_CHNL'';

V_EZ_CLM_CAMP6 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.EZ_CLM_CAMP6'';

V_EZ_CLM_PMNT_22_23_24 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.EZ_CLM_PMNT_22_23_24'';

V_EZ_CLM_PMNT VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.EZ_CLM_PMNT'';

V_SHIP_PERSON_XREF VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_5, ''BDR_SMART'') || ''.SHIP_PERSON_XREF'';

V_ENROLLMENT_PILOT VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.ENROLLMENT_PILOT'';

V_EZ_CLM_CAMP_V0 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.EZ_CLM_CAMP_V0'';

V_ENROLLMENT_PILOT_WRK VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.ENROLLMENT_PILOT'';

V_EZ_CLM_PMNT_SA VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.EZCLAIM_EZ_CLM_PMNT_SA'';

V_EZ_CLM_CAMP9 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.EZ_CLM_CAMP9'';

V_D_LGL_ENTY VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_1, ''BDR_CONF'') || ''.D_LGL_ENTY'';

V_EZ_CLM_CAMP_V1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.EZ_CLM_CAMP_V1'';

V_REL_MBR_INFO1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.REL_MBR_INFO1'';

V_EZ_CLM_CAMP_SA VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.EZCLAIM_EZ_CLM_CAMP_SA'';

V_PDP_MBR VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.PDP_MBR'';

V_D_PLN_BEN_MOD VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_1, ''BDR_CONF'') || ''.D_PLN_BEN_MOD'';

V_WEB_REG1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.WEB_REG1'';

V_CAMPAIGN_EXTRACT VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_5, ''BDR_SMART'') || ''.CAMPAIGN_EXTRACT'';

V_EZ_CLM_CAMP8 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.EZ_CLM_CAMP8'';

V_EZ_CLM_CAMP3 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.EZ_CLM_CAMP3'';

V_D_DSCNT_MULTI_INSD VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_2, ''BDR_DM'') || ''.D_DSCNT_MULTI_INSD'';

V_MEMBERSHIP_5 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.MEMBERSHIP_5'';

V_D_GEO_XREF VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_1, ''BDR_CONF'') || ''.D_GEO_XREF'';

V_ENROLLMENT_PILOT1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.ENROLLMENT_PILOT1'';

V_REL_MBR_INFO2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.REL_MBR_INFO2'';

V_D_AGT VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_1, ''BDR_CONF'') || ''.D_AGT'';

V_EZ_CLM_CAMP_SA_BCK VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.EZCLAIM_EZ_CLM_CAMP_SA_BCK'';

V_EZ_CLM_CAMP10 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.EZ_CLM_CAMP10'';

V_EZ_CLM_PMNT_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.EZ_CLM_PMNT_1'';

V_ENROLLMENT_PILOT2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.ENROLLMENT_PILOT2'';

V_D_CERT_ACTV VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_1, ''BDR_CONF'') || ''.D_CERT_ACTV'';

V_EZ_CLM_PMNT_SA_BCK VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.EZCLAIM_EZ_CLM_PMNT_SA_BCK'';

V_D_DSCNT_EFT VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_2, ''BDR_DM'') || ''.D_DSCNT_EFT'';

V_EZCLAIM_ENROLLED_FOR_LAPSE_SA_WRK VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.EZCLAIM_EZCLAIM_ENROLLED_FOR_LAPSE_SA'';

V_EZCP_SUBACCOUNT_LAYOUT_SUMMARY VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_6, ''SRC_APEX'') || ''.EZCP_SUBACCOUNT_LAYOUT_SUMMARY'';

V_EZ_CAMPAIGN VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.EZ_CAMPAIGN'';

V_PERSON_AUXILIARY_PARTY VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_5, ''BDR_SMART'') || ''.PERSON_AUXILIARY_PARTY'';

V_D_DSCNT_ANNL_PAYR VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_2, ''BDR_DM'') || ''.D_DSCNT_ANNL_PAYR'';

V_D_UNDWR_TAG VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_1, ''BDR_CONF'') || ''.D_UNDWR_TAG'';

V_WEB_REG VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.WEB_REG'';

V_MARKETING_CONTACT VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_5, ''BDR_SMART'') || ''.MARKETING_CONTACT'';

V_EZ_CLM_CAMP VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.EZ_CLM_CAMP'';

V_D_RTNG_AREA VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_1, ''BDR_CONF'') || ''.D_RTNG_AREA'';

V_PDP_MBR_V2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.PDP_MBR_V2'';

V_MEMBERSHIP_4 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.MEMBERSHIP_4'';

V_MEMBERSHIP_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.MEMBERSHIP_1'';

V_FED_MEMBERS VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_3, ''SRC_UCEE'') || ''.FED_MEMBERS'';

V_REFINED_FEDERAL_REF_AMLK VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_3, ''SRC_UCEE'') || ''.AMLK'';

V_D_CNTY VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_1, ''BDR_CONF'') || ''.D_CNTY'';

V_EZ_CLM_CAMP7 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.EZ_CLM_CAMP7'';

V_P_LVL_CLAIM_INFO VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.INFORCELR_P_LVL_CLAIM_INFO'';

V_EZ_CLM_MS_CLM VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.EZ_CLM_MS_CLM'';

V_PERSON_AUXILIARY_PARTY1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.PERSON_AUXILIARY_PARTY1'';

V_AUXILIARY_PERSON VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_7, ''SRC_COMPAS'') || ''.AUXILIARY_PERSON'';

V_PRIV_AUTH VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.PRIV_AUTH'';

V_EZ_CLM_MBR2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.EZ_CLM_MBR2'';

V_EZ_CLM_CAMP_MON VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.EZ_CLM_CAMP_MON'';

V_EZCP_MEMBER_ENROLLMENT_DETAILS VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_6, ''SRC_APEX'') || ''.EZCP_MEMBER_ENROLLMENT_DETAILS'';

V_F_PREM_TRANS_DAY VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_2, ''BDR_DM'') || ''.F_PREM_TRANS_DAY'';

V_SM_CAMPAIGN VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_5, ''BDR_SMART'') || ''.SM_CAMPAIGN'';

V_AC_WEB_REGISTRATION VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_5, ''BDR_SMART'') || ''.V_AC_WEB_REGISTRATION'';

V_EALLIANCE VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_8, ''SRC_MPO'') || ''.EALLIANCE'';

V_REL_MBR_INFO VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.REL_MBR_INFO'';

V_EZCP_CLAIMS_PAYMENT_DETAILS VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_6, ''SRC_APEX'') || ''.EZCP_CLAIMS_PAYMENT_DETAILS'';

V_EZ_CLM_PMNT_SA_DATE VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.EZCLAIM_EZ_CLM_PMNT_SA_DATE'';

V_EZ_CLM_CAMP_SA_DATE_BCK VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.EZCLAIM_EZ_CLM_CAMP_SA_DATE_BCK'';

V_MBR_DT_CHK1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.MBR_DT_CHK1'';

V_EZCLAIM_ENROLLED_FOR_LAPSE_SA_BCK VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.EZCLAIM_EZCLAIM_ENROLLED_FOR_LAPSE_SA_BCK'';

V_EZ_CLM_PMNT_SA_DATE_BCK VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.EZCLAIM_EZ_CLM_PMNT_SA_DATE_BCK'';

V_EZ_CLM_PMNT_QC VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.EZCLAIM_EZ_CLM_PMNT_QC'';

V_EZ_CLM_MBR_QC VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.EZCLAIM_EZ_CLM_MBR_QC'';

V_EZ_CLM_CAMP2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.EZ_CLM_CAMP2'';

V_MEMBERSHIP VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.EZCLAIM_MEMBERSHIP'';

V_MEMBERSHIP_3 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_wrk'') || ''.MEMBERSHIP_3'';

V_CAMPSA_PMNTSA_QC VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.EZCLAIM_CAMPSA_PMNTSA_QC'';



BEGIN


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP1'';

V_STEP_NAME :=  ''create a table EZ_CLM_CAMP_SA_BCK'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EZ_CLM_CAMP_SA_BCK) COPY GRANTS as select * from IDENTIFIER(:V_EZ_CLM_CAMP_SA);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EZ_CLM_CAMP_SA_BCK)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP2'';

V_STEP_NAME :=  ''create a table EZ_CLM_CAMP_SA_DATE_BCK'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EZ_CLM_CAMP_SA_DATE_BCK) COPY GRANTS as select * from IDENTIFIER(:V_EZ_CLM_CAMP_SA_DATE);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:v_ez_clm_camp_sa_date_bck)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP3'';

V_STEP_NAME :=  ''create a table EZ_CLM_PMNT_SA_BCK'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:v_ez_clm_pmnt_sa_bck) COPY GRANTS as select * from IDENTIFIER(:V_EZ_CLM_PMNT_SA);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EZ_CLM_PMNT_SA_BCK)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP4'';

V_STEP_NAME :=  ''create a table EZ_CLM_PMNT_SA_DATE_BCK'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:v_ez_clm_pmnt_sa_date_bck) COPY GRANTS as select * from IDENTIFIER(:V_EZ_CLM_PMNT_SA_DATE);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EZ_CLM_PMNT_SA_DATE_BCK)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP5'';

V_STEP_NAME :=  ''create a table EZCLAIM_ENROLLED_FOR_LAPSE_SA_BCK'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:v_ezclaim_enrolled_for_lapse_sa_bck) COPY GRANTS as select * from IDENTIFIER(:V_EZCLAIM_ENROLLED_FOR_LAPSE_SA);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EZCLAIM_ENROLLED_FOR_LAPSE_SA_BCK)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP6'';

V_STEP_NAME :=  ''create a table EZ_CLM_PMNT_22_23_24'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EZ_CLM_PMNT_22_23_24) COPY GRANTS as SELECT distinct
LPAD(ecpd.acct_nbr,11,''0'') as acct_nbr,
ecpd.clm_num as claim_number,
CAST(esls.account_number as INTEGER) as sub_account_number,
ecpd.status as status,
to_date(to_char(ecpd.date_of_service,''yyyy-MM-dd'')) as date_of_service,
date(ecpd.dt_proc) as date_proccessed,
date(ecpd.dt_cmpltd) as date_completed,
ecpd.bus_nm as business_name,
ecpd.cty as city,
ecpd.st as state,
ecpd.zip_cd as zip_code,
ecpd.amount_due as amount_due,
to_date(to_char(ecpd.SRC_REC_created_ts,''yyyy-MM-dd'')) as created_ts,
to_date(to_char(ecpd.SRC_REC_updated_ts,''yyyy-MM-dd'')) as updated_ts,
to_date(to_char(ecpd.integrated_pay_submit_date,''yyyy-MM-dd'')) as integrated_pay_submit_date,
to_date(to_char(ecpd.payer_exp_submit_date,''yyyy-MM-dd'')) as payer_exp_submit_date,
to_date(to_char(ecpd.sub_account_submit_date,''yyyy-MM-dd'')) as sub_account_submit_date,
to_date(emed.SRC_REC_CREATED_TS) as enrollment_date
FROM
    IDENTIFIER(:V_EZCP_CLAIMS_PAYMENT_DETAILS)  ecpd,
    IDENTIFIER(:V_EZCP_SUBACCOUNT_LAYOUT_SUMMARY) esls,
    IDENTIFIER(:V_EZCP_MEMBER_ENROLLMENT_DETAILS) emed
WHERE 
cast(esls.member_number as BIGINT) = cast(ecpd.acct_nbr as BIGINT)
and year(ecpd.date_of_service) = esls.member_number_year
and REGEXP_REPLACE(emed.membership_number,''^0+'','''') = REGEXP_REPLACE(ecpd.acct_nbr,''^0+'','''') 
and year(ecpd.date_of_service) in (2022,2023,2024,2025)
AND esls.account_number IS NOT NULL;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EZ_CLM_PMNT_22_23_24)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP7'';

V_STEP_NAME :=  ''create a table EZ_CLM_MBR_2022_23_24'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EZ_CLM_MBR_2022_23_24) COPY GRANTS as
select 
case when abp_type= 2 then ''Pay As You Go'' when abp_type= 1 then ''Pre-funded'' else ''not found'' end as abp_type, 
insured_name,
membership_number as member_number,
cast(membership_number as STRING) as member_number_str,
status,
record_date,
date(SRC_REC_CREATED_TS) as enrollment_form_received_date,
state_code,
date(suspended_date) as suspended_date,
date(termination_date) as termination_date,
date(cancellation_date) as cancellation_date,
bank_account_type,
date(confirm_submission_date) as confirm_submission_date,
date(payer_express_date) as payer_express_date,
date(subacct_submitted_date) as subacct_submitted_date,
zip_code,
REGEXP_REPLACE(phone_number,''s+$'','''') as phone_number
from IDENTIFIER(:V_EZCP_MEMBER_ENROLLMENT_DETAILS);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EZ_CLM_MBR_2022_23_24)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP8'';

V_STEP_NAME :=  ''create a table ENROLLMENT_PILOT'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_ENROLLMENT_PILOT_WRK) COPY GRANTS as 
select * EXCLUDE(ROW_NUM) from
(SELECT *,regexp_replace(membership_number, ''-'', '''') as membership_number1 ,ROW_NUMBER() OVER
(PARTITION BY regexp_replace(membership_number, ''-'', '''')
order by ltr_date) 
AS ROW_NUM 
FROM IDENTIFIER(:V_ENROLLMENT_PILOT)) as a where a.row_num=1;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_ENROLLMENT_PILOT_WRK)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP9'';

V_STEP_NAME :=  ''create a table ENROLLMENT_PILOT1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_ENROLLMENT_PILOT1) COPY GRANTS as
select distinct x.* from (
select (case when a31.person_id is not null then a31.person_id else a27.pers_id end) as person_id,ep.*
from IDENTIFIER(:V_ENROLLMENT_PILOT_WRK) ep
left join IDENTIFIER(:V_D_MBR_INFO) as a27 on ep.membership_number1 = a27.acct_nbr
left join IDENTIFIER(:V_SHIP_PERSON_XREF) a31 on a27.INDV_ID = a31.SHIP_PERSON_ID
) x;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_ENROLLMENT_PILOT1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP10'';

V_STEP_NAME :=  ''create a table ENROLLMENT_PILOT2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_ENROLLMENT_PILOT2) COPY GRANTS as
select a.*,
cast(concat(substr(ltr_date, -4), ''-'',
(case 
when upper(regexp_replace(ltr_date, ''[^a-zA-Z]'', '''')) = ''JANUARY'' then 1
when upper(regexp_replace(ltr_date, ''[^a-zA-Z]'', '''')) = ''FEBRUARY'' then 2
when upper(regexp_replace(ltr_date, ''[^a-zA-Z]'', '''')) = ''MARCH'' then 3
when upper(regexp_replace(ltr_date, ''[^a-zA-Z]'', '''')) = ''APRIL'' then 4
when upper(regexp_replace(ltr_date, ''[^a-zA-Z]'', '''')) = ''MAY'' then 5
when upper(regexp_replace(ltr_date, ''[^a-zA-Z]'', '''')) = ''JUNE'' then 6
when upper(regexp_replace(ltr_date, ''[^a-zA-Z]'', '''')) = ''JULY'' then 7
when upper(regexp_replace(ltr_date, ''[^a-zA-Z]'', '''')) = ''AUGUST'' then 8
when upper(regexp_replace(ltr_date, ''[^a-zA-Z]'', '''')) = ''SEPTEMBER'' then 9
when upper(regexp_replace(ltr_date, ''[^a-zA-Z]'', '''')) = ''OCTOBER'' then 10
when upper(regexp_replace(ltr_date, ''[^a-zA-Z]'', '''')) = ''NOVEMBER'' then 11
when upper(regexp_replace(ltr_date, ''[^a-zA-Z]'', '''')) = ''DECEMBER'' then 12 else 13 end),
''-'',substr(lpad(regexp_replace(ltr_date, ''([a-zA-Z]|[" "]|[/,])'', ''''),6,''0''), -6,2)) as date) as ltr_date1
from IDENTIFIER(:V_ENROLLMENT_PILOT1) a;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_ENROLLMENT_PILOT2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP11'';

V_STEP_NAME :=  ''create a table EZ_CAMPAIGN'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EZ_CAMPAIGN) COPY GRANTS as
select x.*,c.campaigncode,c.initiative,c.name from IDENTIFIER(:V_CAMPAIGN_EXTRACT) as x 
inner join (select * from IDENTIFIER(:V_SM_CAMPAIGN) where campaigncode in (''C000004420'',''C000004660'')) as c 
on x.campaignid =c.campaignid;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EZ_CAMPAIGN)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP12'';

V_STEP_NAME :=  ''create a table EZ_CLM_CAMP_V0'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EZ_CLM_CAMP_V0) COPY GRANTS as 
select a.*,b.actual_drop_date,b.campaignid,b.cellcode,b.cellname,b.extract_date,
b.campaigncode,b.initiative,b.name
from IDENTIFIER(:V_MARKETING_CONTACT)  as a 
inner join IDENTIFIER(:V_EZ_CAMPAIGN) b on a.campaign_extract_id =b.campaign_extract_id ;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EZ_CLM_CAMP_V0)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP13'';

V_STEP_NAME :=  ''create a table EZ_CLM_CAMP_V1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EZ_CLM_CAMP_V1) COPY GRANTS as
select distinct x.* from(
(select a.person_id, ''Y'' as Pilot_fg from IDENTIFIER(:V_ENROLLMENT_PILOT2) a where  a.person_id is not null)
union
(select a.person_id, ''N'' as Pilot_fg from IDENTIFIER(:V_EZ_CLM_CAMP_V0) a left join IDENTIFIER(:V_ENROLLMENT_PILOT2) b on a.person_id =b.person_id
where b.person_id is null)
) x;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EZ_CLM_CAMP_V1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP14'';

V_STEP_NAME :=  ''create a table EZ_CLM_CAMP'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EZ_CLM_CAMP) COPY GRANTS as 
select a.*,
(case when b.person_id is not null and c.person_id is not null then ''1.Both''
when b.person_id is not null then ''2.Pilot Only''
when c.person_id is not null then ''3.Non Pilot Only'' else ''4.Others'' end) as Pilot_fg1,
b.ltr_date1 as ltr_date_pilot,b.membership_number1 as membership_number_pilot,
c.actual_drop_date as actual_drop_date_ce, c.extract_date as extract_date_ce,
(case when b.person_id is not null then  b.ltr_date1 else c.extract_date end) as extract_date
from IDENTIFIER(:V_EZ_CLM_CAMP_V1) a
left join IDENTIFIER(:V_ENROLLMENT_PILOT2) b on a.person_id = b.person_id
left join IDENTIFIER(:V_EZ_CLM_CAMP_V0) c on a.person_id = c.person_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EZ_CLM_CAMP)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP15'';

V_STEP_NAME :=  ''create a table EZ_CLM_CAMP_MON'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EZ_CLM_CAMP_MON) COPY GRANTS as
select distinct person_id,year(extract_date)*100+month(extract_date) as Mon from IDENTIFIER(:V_EZ_CLM_CAMP)
where extract_date is not null;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EZ_CLM_CAMP_MON)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP16'';

V_STEP_NAME :=  ''create a table EZ_CLM_CAMP_PERS'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EZ_CLM_CAMP_PERS) COPY GRANTS as
select distinct person_id from IDENTIFIER(:V_EZ_CLM_CAMP);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EZ_CLM_CAMP_PERS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP17'';

V_STEP_NAME :=  ''create a table REL_MBR_INFO'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_REL_MBR_INFO) COPY GRANTS as
select a27.*,a31.person_id
from IDENTIFIER(:V_EZ_CLM_CAMP_PERS) a
inner join IDENTIFIER(:V_SHIP_PERSON_XREF) a31 on a.person_id = a31.person_id
inner join IDENTIFIER(:V_D_MBR_INFO) as a27 on a31.SHIP_PERSON_ID = a27.INDV_ID;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_REL_MBR_INFO)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP18'';

V_STEP_NAME :=  ''create a table REL_MBR_INFO1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_REL_MBR_INFO1) COPY GRANTS as
select a27.*,a27.pers_id as person_id
from (select x.* from IDENTIFIER(:V_EZ_CLM_CAMP_PERS) x left join IDENTIFIER(:V_REL_MBR_INFO) y on x.person_id = y.person_id 
where y.person_id is null) a
inner join IDENTIFIER(:V_D_MBR_INFO) as a27 on a.person_id = a27.pers_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_REL_MBR_INFO1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP19'';

V_STEP_NAME :=  ''create a table REL_MBR_INFO2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_REL_MBR_INFO2) COPY GRANTS as
select * from IDENTIFIER(:V_REL_MBR_INFO) union
select * from IDENTIFIER(:V_REL_MBR_INFO1);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_REL_MBR_INFO2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP20'';

V_STEP_NAME :=  ''create a table MBR_DT_CHK1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_MBR_DT_CHK1) COPY GRANTS as
select a11.prem_due_dt_id
		,a11.acct_nbr
		,a11.d_mbr_info_sk
		,a11.COMPAS_INSD_PLN_ID
		,a11.D_LGL_ENTY_SK
		,a11.D_CERT_ACTV_SK,
		a11.PRDCT_D_ACQN_CHNL_SK,
		a11.RES_D_GEO_XREF_SK,
		a11.CERT_D_ACQN_CHNL_SK,
		a11.D_DSCNT_ANNL_PAYR_SK,
		a11.D_DSCNT_EFT_SK,
		a11.D_DSCNT_ERLY_ENRL_SK,
		a11.D_RTNG_AREA_SK,
		a11.D_GDR_ID_SK,
				a11.prem_due_age_id,
		a11.D_DSCNT_multi_insd_SK,
		a11.D_Surchrg_tbcc_user_sk,
		a11.D_UNDWR_TAG_Sk,
		a11.agt_sel_orig_d_agt_sk,
		a11.agt_wrt_d_agt_sk ,
		a11.agt_ref_orig_d_agt_sk,
		a11.D_SURCHRG_TIER_sk
		,a11.prdct_eff_dt_id
		,a27.person_id as pers_id
        ,a27.isid
        ,a27.INDV_ID
        ,a27.PART_B_EFF_DT_ID
        ,a27.DOB_ID
        ,a27.MEDCR_CLM_NBR AS medcr_id
		,a13.LF_CATGY_NM
        ,a13.PRDCT_SUB_GRP
        ,a13.pln_lvl_desc
        ,a13.pln_typ
        ,a13.prdct_typ
		,a13.pln_grp
		,a13.smart_prdct_typ_var
		,a13.PLN_LVL
		,sum(a11.PD_CERT_QTY + a11.DELQ_CERT_QTY) as mbr
		,max(f_prem_trans_day_sk) as f_prem_trans_day_sk 
from IDENTIFIER(:V_F_PREM_TRANS_DAY) a11   
		inner join IDENTIFIER(:V_REL_MBR_INFO2) as a27 on a11.d_mbr_info_sk = a27.d_mbr_info_sk
		inner join IDENTIFIER(:V_EZ_CLM_CAMP_MON) ez_pers_mon on  a27.person_id  = ez_pers_mon.person_id and floor(a11.prem_due_dt_id/100)  >= ez_pers_mon.Mon
        inner join  
		(select * from IDENTIFIER(:V_D_PLN_BEN_MOD) where prdct_sub_grp in (''Med Supp Base'')) a13 on (a11.D_PLN_BEN_MOD_SK = a13.D_PLN_BEN_MOD_SK)
group by 
		a11.prem_due_dt_id
		,a11.acct_nbr
		,a11.d_mbr_info_sk
		,a11.COMPAS_INSD_PLN_ID
		,a11.D_CERT_ACTV_SK,
		a11.PRDCT_D_ACQN_CHNL_SK,
		a11.RES_D_GEO_XREF_SK,
		a11.CERT_D_ACQN_CHNL_SK,
		a11.D_DSCNT_ANNL_PAYR_SK,
		a11.D_DSCNT_EFT_SK,
		a11.D_DSCNT_ERLY_ENRL_SK,
		a11.D_RTNG_AREA_SK,
		a11.D_GDR_ID_SK,
		a11.D_DSCNT_multi_insd_SK,
		a11.D_Surchrg_tbcc_user_sk,
		a11.D_UNDWR_TAG_Sk,
		a11.agt_sel_orig_d_agt_sk,
		a11.prem_due_age_id,
		a11.agt_wrt_d_agt_sk ,
		a11.agt_ref_orig_d_agt_sk,
		a11.D_LGL_ENTY_SK,
		a11.D_SURCHRG_TIER_sk
		,a11.prdct_eff_dt_id
		,a27.person_id
        ,a27.isid
        ,a27.INDV_ID
        ,a27.PART_B_EFF_DT_ID
        ,a27.DOB_ID
        ,a27.MEDCR_CLM_NBR
		,a13.LF_CATGY_NM
        ,a13.PRDCT_SUB_GRP
        ,a13.pln_lvl_desc
        ,a13.pln_typ
        ,a13.prdct_typ
		,a13.pln_grp
		,a13.smart_prdct_typ_var
		,a13.PLN_LVL
having mbr>0;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_MBR_DT_CHK1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP21'';

V_STEP_NAME :=  ''create a table MBR_DT_CHK2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_MBR_DT_CHK2) COPY GRANTS as
select a.* from
(select * ,ROW_NUMBER() OVER
(PARTITION BY pers_id
order by PREM_DUE_dt_ID,f_prem_trans_day_sk desc) 
AS ROW_NUM 
from IDENTIFIER(:V_MBR_DT_CHK1)) a where row_num = 1;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_MBR_DT_CHK2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP22'';

V_STEP_NAME :=  ''create a table MEMBERSHIP'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_MEMBERSHIP) COPY GRANTS as 
select distinct
        a11.pers_id
		,floor(a11.prem_due_dt_id/100) as prem_due_mo_id
        ,a15.D_ST_CD
        ,a11.LF_CATGY_NM
        ,a11.PRDCT_SUB_GRP
        ,a11.pln_lvl_desc
        ,a11.pln_typ
        ,a11.prdct_typ
        ,a11.pln_grp
        ,a11.smart_prdct_typ_var
        ,a14.ACQN_CHNL_LVL_1 as prdct_ACQN_CHNL_LVL_1
        ,a17.ACQN_CHNL_LVL_1 as cert_ACQN_CHNL_LVL_1
        ,a14.ACQN_CHNL_LVL_2 as prdct_ACQN_CHNL_LVL_2
        ,a17.ACQN_CHNL_LVL_2 as cert_ACQN_CHNL_LVL_2
        ,a12.CERT_ACTV_LVL_1_TXT
        ,a11.PLN_LVL
        ,a12.CERT_ACTV_LVL_2_TXT
        ,DSCNT_ANNL_PAYR_DESC,DSCNT_EFT_DESC
        ,DSCNT_ERLY_ENRL_FLG
        ,DSCNT_ERLY_ENRL_DESC
        ,DSCNT_ERLY_ENRL_NM
        ,RTNG_AREA_CD
        ,RTNG_AREA_NM
        ,gdr_desc
        ,DSCNT_multi_insd_flg
        ,Surchrg_tbcc_user_flg
        ,DSCNT_ERLY_ENRL_yr
        ,DSCNT_ERLY_ENRL_adj_amt
        ,undwr_pln_rqr_txt
        ,undwr_prdct_rqr_txt
        ,prem_due_age_id
        ,(case when floor(prem_due_age_id) <65 then ''<65'' 
                when floor(prem_due_age_id) =65 then ''65'' 
                when (floor(prem_due_age_id) >65 and floor(prem_due_age_id) <=69) then ''66-69'' 
                when (floor(prem_due_age_id) >69 and floor(prem_due_age_id) <=74) then ''70-74''
                when (floor(prem_due_age_id) >74 and floor(prem_due_age_id) <=79) then ''75-79''
                when floor(prem_due_age_id) >79  then ''80+''
        end) as age 
        ,a11.isid
        ,a11.INDV_ID
        ,a11.PART_B_EFF_DT_ID
        ,a11.DOB_ID
        ,a11.medcr_id
        ,(case when c.medicare_hicn_cd is not null then c.MBI else a11.medcr_id end) as MBI_FINAL
        ,a15.zip_cd
        ,a15.cnty_cd
        ,a15.rgn
        ,a15.cty
        ,a15.area_cd
        ,a28.cnty_nm
        ,a12.CERT_ACTV_LVL_3_TXT
        ,a29.pty_id
        ,a29.pty_typ
        ,a29.agt_id
        ,a29.agt_typ
        ,a29.agt_sub_typ
        ,a29.ealliance_pref_nm
        ,a51.pty_id as wrt_pty_id
        ,a51.pty_typ as wrt_pty_typ
        ,a51.agt_id as wrt_agt_id				
        ,a51.agt_typ as wrt_agt_typ
        ,a51.agt_sub_typ as wrt_agt_sub_typ				
        ,a51.ealliance_pref_nm as wrt_ealliance_pref_nm	
        ,a52.pty_id as ref_pty_id
        ,a52.pty_typ as ref_pty_typ
        ,a52.agt_id as ref_agt_id		
        ,a52.agt_typ as ref_agt_typ,a52.agt_sub_typ as ref_agt_sub_typ	
        ,a52.ealliance_pref_nm as ref_ealliance_pref_nm																				 
        ,a30.rt_dtrm_cd_desc
        ,a11.acct_nbr
        ,a11.d_mbr_info_sk
        ,a11.COMPAS_INSD_PLN_ID
        ,a11.D_LGL_ENTY_SK
        ,a53.LGL_ENTY_NM
        ,a53.LGL_ENTY_SHRT_DESC
        ,floor(a11.prdct_eff_dt_id/100) as PRDCT_EFF_MO_ID
        ,mbr

		from IDENTIFIER(:V_MBR_DT_CHK2) a11
		left join IDENTIFIER(:V_CMS_HICN_TO_MBI_CROSSWALK) c on a11.medcr_id = c.medicare_hicn_cd
        left join IDENTIFIER(:V_D_CERT_ACTV) a12 on (a11.D_CERT_ACTV_SK = a12.D_CERT_ACTV_SK)                                              
        left join IDENTIFIER(:V_D_ACQN_CHNL) a14 on (a11.PRDCT_D_ACQN_CHNL_SK = a14.D_ACQN_CHNL_SK)            
        left join IDENTIFIER(:V_D_GEO_XREF) a15 on (a11.RES_D_GEO_XREF_SK = a15.D_GEO_XREF_SK)                                                         
        left join IDENTIFIER(:V_D_ST) a16 on (a15.D_ST_CD = a16.D_ST_CD)   
        left join IDENTIFIER(:V_D_ACQN_CHNL) a17 on (a11.CERT_D_ACQN_CHNL_SK = a17.D_ACQN_CHNL_SK)   
        left join IDENTIFIER(:V_D_DSCNT_ANNL_PAYR) a22 on (a11.D_DSCNT_ANNL_PAYR_SK = a22.D_DSCNT_ANNL_PAYR_SK)
        left join IDENTIFIER(:V_D_DSCNT_EFT) a18 on (a11.D_DSCNT_EFT_SK = a18.D_DSCNT_EFT_SK)
        left join IDENTIFIER(:V_D_DSCNT_ERLY_ENRL) a19 on (a11.D_DSCNT_ERLY_ENRL_SK = a19.D_DSCNT_ERLY_ENRL_SK)
        left join IDENTIFIER(:V_D_RTNG_AREA) a20 on (a11.D_RTNG_AREA_SK = a20.D_RTNG_AREA_SK)--
        left join IDENTIFIER(:V_D_GDR_LOOK) a21 on (a11.D_GDR_ID_SK = a21.D_GDR_ID_SK)
        left join IDENTIFIER(:V_D_DSCNT_MULTI_INSD) a25 on (a11.D_DSCNT_multi_insd_SK = a25.D_DSCNT_multi_insd_SK)
        left join IDENTIFIER(:V_D_SURCHRG_TBCC_USER) a26 on (a11.D_Surchrg_tbcc_user_sk = a26.D_Surchrg_tbcc_user_sk)
        left join IDENTIFIER(:V_D_UNDWR_TAG) a24 on (a11.D_UNDWR_TAG_Sk = a24.D_UNDWR_TAG_Sk)
        left join IDENTIFIER(:V_D_CNTY) as a28 on a15.D_ST_CD = a28.D_ST_CD and  a15.cnty_cd = a28.cnty_cd
        left join IDENTIFIER(:V_D_AGT) as a29 on a11.agt_sel_orig_d_agt_sk = a29.d_agt_sk
        left join IDENTIFIER(:V_D_AGT) as a51 on a11.agt_wrt_d_agt_sk = a51.d_agt_sk
        left join IDENTIFIER(:V_D_AGT) as a52  on a11.agt_ref_orig_d_agt_sk = a52.d_agt_sk	
        left join IDENTIFIER(:V_D_LGL_ENTY) as a53 on a11.D_LGL_ENTY_SK = a53.D_LGL_ENTY_SK		
        left join IDENTIFIER(:V_D_SURCHRG_TIER) as a30 on a11.D_SURCHRG_TIER_sk = a30.D_SURCHRG_TIER_sk
;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_MEMBERSHIP)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP23'';

V_STEP_NAME :=  ''create a table MEMBERSHIP_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_MEMBERSHIP_1) COPY GRANTS as
select * EXCLUDE(ROW_NUM) from
(SELECT *,cast(concat(substr(prem_due_mo_id,1,4), ''-'',substr(prem_due_mo_id,5,2), ''-'',''01'') as date) as prem_due_dt,
cast(concat(substr(prdct_eff_mo_id,1,4), ''-'',substr(prdct_eff_mo_id,5,2), ''-'',''01'') as date) as prdct_eff_dt,

(case when ref_ealliance_pref_nm is not null and ref_ealliance_pref_nm <> ''NotApplicable'' then ''Y'' else ''N'' end) as self_enroll_flag,
(case when (ref_ealliance_pref_nm is not null and ref_ealliance_pref_nm <> ''NotApplicable'') and pty_id in (''-1'',''-2'') then ref_pty_id else pty_id end) as pty_id_final,
(case when (ref_ealliance_pref_nm is not null and ref_ealliance_pref_nm <> ''NotApplicable'') and agt_id in (''-1'',''-2'') then ref_agt_id else agt_id end) as agt_id_final,
(case when (ref_ealliance_pref_nm is not null and ref_ealliance_pref_nm <> ''NotApplicable'') and pty_id in (''-1'',''-2'') then ref_pty_typ else pty_typ end) as pty_typ_final,
(case when (ref_ealliance_pref_nm is not null and ref_ealliance_pref_nm <> ''NotApplicable'') and agt_id in (''-1'',''-2'') then ref_agt_typ else agt_typ end) as agt_typ_final,
(case when (ref_ealliance_pref_nm is not null and ref_ealliance_pref_nm <> ''NotApplicable'') and (ealliance_pref_nm is not null and ealliance_pref_nm = ''NotApplicable'') then ref_ealliance_pref_nm else ealliance_pref_nm end) as ref_ealliance_pref_nm_final

,ROW_NUMBER() OVER
(PARTITION BY pers_id
order by PREM_DUE_MO_ID) 
AS ROW_NUM 
FROM IDENTIFIER(:V_MEMBERSHIP)) as a where a.row_num=1;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_MEMBERSHIP_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP24'';

V_STEP_NAME :=  ''create a table MEMBERSHIP_2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_MEMBERSHIP_2) COPY GRANTS as 
select a.*,b.e_alliance_partner_name,b.nickname,b.e_alliance_old_category,b.e_alliance_new_category,

(case when agt_id_final in (''SQS3333'',''SQS4444'') then ''DTC''
when agt_id_final in (''SQS2222'',''GOH2222'',''INS2222'',''EHC2222'') then ''DTC''
when prdct_ACQN_CHNL_LVL_1 =''UNKNOWN'' then ''DTC''
when ref_ealliance_pref_nm is not null and ref_ealliance_pref_nm not in (''NotApplicable'',''Unknown'') then ''ealliance-Self-Enroll''
when prdct_ACQN_CHNL_LVL_1 = ''Aggregator'' and e_alliance_old_category is not null then lower(replace(e_alliance_old_category,'' '',''''))
when prdct_ACQN_CHNL_LVL_1 =''Aggregator'' and e_alliance_old_category is null then ''ealliance-Others'' else prdct_ACQN_CHNL_LVL_1 end) as marketing_channel_final,

(case when ref_ealliance_pref_nm is not null and ref_ealliance_pref_nm not in (''NotApplicable'',''Unknown'') then ''ealliance-Self-Enroll''
when prdct_ACQN_CHNL_LVL_1 in(''Aggregator'',''DTC'',''UNKNOWN'') and e_alliance_new_category is not null then lower(replace(e_alliance_new_category,'' '',''''))
when prdct_ACQN_CHNL_LVL_1 =''Aggregator'' and e_alliance_new_category is null then ''ealliance-Others'' 
when prdct_ACQN_CHNL_LVL_1 =''UNKNOWN'' then ''DTC''
when prdct_ACQN_CHNL_LVL_1 =''UNKNOWN'' then ''DTC'' else prdct_ACQN_CHNL_LVL_1 end) as marketing_channel_cat_2,

(case when agt_id_final in (''SQS3333'',''SQS4444'') then ''DTC''
when agt_id_final in (''SQS2222'',''GOH2222'',''INS2222'',''EHC2222'') then ''DTC''
when prdct_ACQN_CHNL_LVL_1 =''UNKNOWN'' then ''DTC''
when prdct_ACQN_CHNL_LVL_1 = ''Aggregator'' and e_alliance_old_category is not null then lower(replace(e_alliance_old_category,'' '',''''))
when prdct_ACQN_CHNL_LVL_1 =''Aggregator'' and e_alliance_old_category is null then ''ealliance-Others'' else prdct_ACQN_CHNL_LVL_1 end) as marketing_channel_cat_3,

(case when prdct_ACQN_CHNL_LVL_1 =''Aggregator'' and nickname is not NULL and nickname <> '''' then nickname else ref_ealliance_pref_nm_final end) as ealliance_partner_name_new,
(case when ref_ealliance_pref_nm is not null and ref_ealliance_pref_nm <> ''NotApplicable'' then ''ealliance-Self-Enroll''
when prdct_ACQN_CHNL_LVL_1 in(''Aggregator'',''DTC'',''UNKNOWN'') and e_alliance_new_category is not null then lower(replace(e_alliance_new_category,'' '',''''))
when prdct_ACQN_CHNL_LVL_1 =''Aggregator'' and e_alliance_new_category is null then ''ealliance-Others'' else ''Others'' end) as ealliance_cat_new,

(case when CAST(MONTHS_BETWEEN(cast(concat(substr(PART_B_EFF_DT_ID,1,4), ''-'',substr(PART_B_EFF_DT_ID,5,2),
''-'',substr(PART_B_EFF_DT_ID,7,2)) as date), 
cast(concat(substr(DOB_ID,1,4), ''-'',substr(DOB_ID,5,2), ''-'',substr(DOB_ID,7,2)) as date)) AS INT) < 779 
then ''Y'' else ''N'' end) as PartB_eff_Age_Lessthan65,

(case when UNDWR_PLN_RQR_TXT = ''Default'' then ''Default''
when UNDWR_PLN_RQR_TXT = ''Not U/W - Open Enrollment'' then ''OE''
when UNDWR_PLN_RQR_TXT = ''Not U/W - Plan Change'' then ''Plan Change''
when UNDWR_PLN_RQR_TXT = ''Not U/W Guaranteed Issue Reason not specified'' then ''GI''
else ''UW'' end) as UW_PLN_RQR_TXT,

(case when UNDWR_PRDCT_RQR_TXT = ''Default'' then ''Default''
when UNDWR_PRDCT_RQR_TXT = ''Not U/W - Open Enrollment'' then ''OE''
when UNDWR_PRDCT_RQR_TXT = ''Not U/W - Plan Change'' then ''Plan Change''
when UNDWR_PRDCT_RQR_TXT = ''Not U/W Guaranteed Issue Reason not specified'' then ''GI''
else ''UW'' end) as UW_PRDCT_RQR_TXT,

(case when pln_lvl in (''F'',''F01'',''FS1'',''F02'',''FS2'') then ''F''
when pln_lvl in (''G'',''G01'',''GS1'',''G02'',''GS2'') then ''G''
when pln_lvl in (''N'',''N01'',''NS1'',''N02'',''NS2'') then ''N''
when pln_lvl in (''GH1'',''GH2'') then ''GH''
else ''Others'' end) as Plan
from IDENTIFIER(:V_MEMBERSHIP_1) a 
left join IDENTIFIER(:V_EALLIANCE) b
on a.pty_id_final = b.pty_id and a.agt_id_final = b.agt_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_MEMBERSHIP_2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP25'';

V_STEP_NAME :=  ''create a table PDP_MBR'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_PDP_MBR) COPY GRANTS as
select * from IDENTIFIER(:V_FED_MEMBERS)
where pdp_mbr_fg = ''Y'' and to_date(coalesce(dsenrl_dt, ''9999-12-31''))> ''2018-01-01'';


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_PDP_MBR)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP26'';

V_STEP_NAME :=  ''create a table PDP_MBR_V2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_PDP_MBR_V2) COPY GRANTS as
select p.*
,(case when b.medicare_hicn_cd is not null then b.MBI else p.medicare_hicn_cd end) as MBI_FINAL
from IDENTIFIER(:V_PDP_MBR) p
left join IDENTIFIER(:V_CMS_HICN_TO_MBI_CROSSWALK) b on p.medicare_hicn_cd = b.medicare_hicn_cd;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_PDP_MBR_V2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP27'';

V_STEP_NAME :=  ''create a table MEMBERSHIP_3'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_MEMBERSHIP_3) COPY GRANTS as
select a.*, to_date(mbr_plan_eff_dt) as mbr_plan_eff_dt, to_date(coalesce(dsenrl_dt, ''9999-12-31'')) as dsenrl_dt,
        case when pdp_mbr_fg is null then ''N'' else ''Y'' end as pdp_fg
from IDENTIFIER(:V_MEMBERSHIP_2) a
left join IDENTIFIER(:V_PDP_MBR_V2) b on a.mbi_final = b.mbi_final
and to_date(mbr_plan_eff_dt)<=prem_due_dt and to_date(coalesce(dsenrl_dt, ''9999-12-31''))> prem_due_dt;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_MEMBERSHIP_3)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP28'';

V_STEP_NAME :=  ''create a table MEMBERSHIP_4'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_MEMBERSHIP_4) COPY GRANTS as
 select * EXCLUDE(ROW_NUM) from
(SELECT *,ROW_NUMBER() OVER
(PARTITION BY pers_id,PREM_DUE_MO_ID
order by mbr_plan_eff_dt desc, dsenrl_dt desc) 
AS ROW_NUM 
FROM IDENTIFIER(:V_MEMBERSHIP_3)) as a where a.row_num=1;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_MEMBERSHIP_4)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP29'';

V_STEP_NAME :=  ''create a table MEMBERSHIP_5'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_MEMBERSHIP_5) COPY GRANTS as
select a.*,b.HOMVAL,b.HOMSTAT, b.GENERS, b.NPH19,b.COLLEGE,b.OC, b.amlk_id,
c.LVWL20, c.SNIC, c.GENERS20, c.NETW30, c.ESTINC30, c.C210MYS, c.ESTINV30, c.IRISNR, c.MB3G, c.ESTDII30
from IDENTIFIER(:V_MEMBERSHIP_4) as a 
left join IDENTIFIER(:V_AMERILINK_SNAPSHOT_JUL23) as b on a.pers_id =b.person_id 
left join IDENTIFIER(:V_refined_federal_ref_AMLK) as c on b.amlk_id =c.amlk_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_MEMBERSHIP_5)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP30'';

V_STEP_NAME :=  ''create a table EZ_CLM_CAMP2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EZ_CLM_CAMP2) COPY GRANTS as 
select a.*,b.*,
(case
when year(a.extract_date)*100+month(a.extract_date) = b.prem_due_mo_id then ''1.Extract Month''
when year(a.extract_date)*100+month(a.extract_date) < b.prem_due_mo_id then ''2. After Extract Month''
else ''3.Not Found'' end) as Mbr_details_mon,
months_between(cast(concat(year(extract_date), ''-'',month(extract_date), ''-'',''01'') as date) 
,b.prem_due_dt) as Extract_Mbr_mon_diff
from IDENTIFIER(:V_EZ_CLM_CAMP) as a left join IDENTIFIER(:V_MEMBERSHIP_5) as b 
on a.person_id = b.pers_id ;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EZ_CLM_CAMP2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP31'';

V_STEP_NAME :=  ''create a table EZ_CLM_CAMP3'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EZ_CLM_CAMP3) COPY GRANTS as 
select * from
(SELECT * ,ROW_NUMBER() OVER
(PARTITION BY person_id,extract_date
order by Mbr_details_mon, prem_due_mo_id) 
AS ROW_NUM 
FROM IDENTIFIER(:V_EZ_CLM_CAMP2)) as a where a.row_num=1;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EZ_CLM_CAMP3)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP32'';

V_STEP_NAME :=  ''create a table PERSON_AUXILIARY_PARTY1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_PERSON_AUXILIARY_PARTY1) COPY GRANTS as 
select ez_pers.person_id,

(case when pap1.person_id is not null then ''Y'' else ''N'' end) as AUX1_ALTERNATE_PAYER,
(case when pap1.person_id is not null then pap1.begin_date end) as AUX1_ALTERNATE_PAYER_BG_DT,
(case when pap1.person_id is not null then pap1.end_date end) as AUX1_ALTERNATE_PAYER_END_DT,

(case when pap2.person_id is not null then ''Y'' else ''N'' end) as AUX2_THIRD_PARTY_DESIGNEE,
(case when pap2.person_id is not null then pap2.begin_date end) as AUX2_THIRD_PARTY_DESIGNEE_BG_DT,
(case when pap2.person_id is not null then pap2.end_date end) as AUX2_THIRD_PARTY_DESIGNEE_END_DT,

(case when pap3.person_id is not null then ''Y'' else ''N'' end) as AUX3_POWER_OF_ATTORNEY,
(case when pap3.person_id is not null then pap3.begin_date end) as AUX3_POWER_OF_ATTORNEY_BG_DT,
(case when pap3.person_id is not null then pap3.end_date end) as AUX3_POWER_OF_ATTORNEY_END_DT,

(case when pap4.person_id is not null then ''Y'' else ''N'' end) as AUX4_GUARDIAN,
(case when pap4.person_id is not null then pap4.begin_date end) as AUX4_GUARDIAN_BG_DT,
(case when pap4.person_id is not null then pap4.end_date end) as AUX4_GUARDIAN_END_DT,

(case when pap5.person_id is not null then ''Y'' else ''N'' end) as AUX5_CONSERVATOR,
(case when pap5.person_id is not null then pap5.begin_date end) as AUX5_CONSERVATOR_BG_DT,
(case when pap5.person_id is not null then pap5.end_date end) as AUX5_CONSERVATOR_END_DT,

(case when pap6.person_id is not null then ''Y'' else ''N'' end) as AUX6_AUTHORIZED_REPRESENTATIVE,
(case when pap6.person_id is not null then pap6.begin_date end) as AUX6_AUTHORIZED_REPRESENTATIVE_BG_DT,
(case when pap6.person_id is not null then pap6.end_date end) as AUX6_AUTHORIZED_REPRESENTATIVE_END_DT,

(case when pap7.person_id is not null then ''Y'' else ''N'' end) as AUX7_TRUSTEE,
(case when pap7.person_id is not null then pap7.begin_date end) as AUX7_TRUSTEE_BG_DT,
(case when pap7.person_id is not null then pap7.end_date end) as AUX7_TRUSTEE_END_DT,

(case when pap8.person_id is not null then ''Y'' else ''N'' end) as AUX8_SPONSOR,
(case when pap8.person_id is not null then pap8.begin_date end) as AUX8_SPONSOR_BG_DT,
(case when pap8.person_id is not null then pap8.end_date end) as AUX8_SPONSOR_END_DT,

(case when pap9.person_id is not null then ''Y'' else ''N'' end) as AUX9_CUSTODIAL_GUARDIAN,
(case when pap9.person_id is not null then pap9.begin_date end) as AUX9_CUSTODIAL_GUARDIAN_BG_DT,
(case when pap9.person_id is not null then pap9.end_date end) as AUX9_CUSTODIAL_GUARDIAN_END_DT

from IDENTIFIER(:V_EZ_CLM_CAMP_PERS) ez_pers
left join (select * from IDENTIFIER(:V_PERSON_AUXILIARY_PARTY) where aux_party_type_code = 1)
pap1 on ez_pers.person_id = pap1.person_id
left join (select * from IDENTIFIER(:V_PERSON_AUXILIARY_PARTY) where aux_party_type_code = 2)
pap2 on ez_pers.person_id = pap2.person_id
left join (select * from IDENTIFIER(:V_PERSON_AUXILIARY_PARTY) where aux_party_type_code = 3)
pap3 on ez_pers.person_id = pap3.person_id
left join (select * from IDENTIFIER(:V_PERSON_AUXILIARY_PARTY) where aux_party_type_code = 4)
pap4 on ez_pers.person_id = pap4.person_id
left join (select * from IDENTIFIER(:V_PERSON_AUXILIARY_PARTY) where aux_party_type_code = 5)
pap5 on ez_pers.person_id = pap5.person_id
left join (select * from IDENTIFIER(:V_PERSON_AUXILIARY_PARTY) where aux_party_type_code = 6)
pap6 on ez_pers.person_id = pap6.person_id
left join (select * from IDENTIFIER(:V_PERSON_AUXILIARY_PARTY) where aux_party_type_code = 7)
pap7 on ez_pers.person_id = pap7.person_id
left join (select * from IDENTIFIER(:V_PERSON_AUXILIARY_PARTY) where aux_party_type_code = 8)
pap8 on ez_pers.person_id = pap8.person_id
left join (select * from IDENTIFIER(:V_PERSON_AUXILIARY_PARTY) where aux_party_type_code = 9)
pap9 on ez_pers.person_id = pap9.person_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_PERSON_AUXILIARY_PARTY1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP33'';

V_STEP_NAME :=  ''create a table EZ_CLM_CAMP4'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EZ_CLM_CAMP4) COPY GRANTS as 
select a.*,
pap.aux1_alternate_payer,
pap.aux1_alternate_payer_bg_dt,
pap.aux1_alternate_payer_end_dt,
pap.aux2_third_party_designee,
pap.aux2_third_party_designee_bg_dt,
pap.aux2_third_party_designee_end_dt,
pap.aux3_power_of_attorney,
pap.aux3_power_of_attorney_bg_dt,
pap.aux3_power_of_attorney_end_dt,
pap.aux4_guardian,
pap.aux4_guardian_bg_dt,
pap.aux4_guardian_end_dt,
pap.aux5_conservator,
pap.aux5_conservator_bg_dt,
pap.aux5_conservator_end_dt,
pap.aux6_authorized_representative,
pap.aux6_authorized_representative_bg_dt,
pap.aux6_authorized_representative_end_dt,
pap.aux7_trustee,
pap.aux7_trustee_bg_dt,
pap.aux7_trustee_end_dt,
pap.aux8_sponsor,
pap.aux8_sponsor_bg_dt,
pap.aux8_sponsor_end_dt,
pap.aux9_custodial_guardian,
pap.aux9_custodial_guardian_bg_dt,
pap.aux9_custodial_guardian_end_dt
 from IDENTIFIER(:V_EZ_CLM_CAMP3) a
left join IDENTIFIER(:V_PERSON_AUXILIARY_PARTY1) pap on a.person_id = pap.person_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EZ_CLM_CAMP4)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP34'';

V_STEP_NAME :=  ''create a table EZ_CLM_MS_CLM'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EZ_CLM_MS_CLM) COPY GRANTS as
select pers_id,prdct_eff_mo_id,
COALESCE(sum(case when prem_due_mo_id between 202101 and 202112 then claim else 0 end ),0) as claim_2021 , 
COALESCE(sum(case when prem_due_mo_id between 202101 and 202112 then claim_cf_covid else 0 end ),0) as claim_cf_covid_2021,
COALESCE(sum(case when prem_due_mo_id between 202101 and 202112 then paid_prem  else 0 end ),0) as paid_prem_2021,

COALESCE(sum(case when prem_due_mo_id between 202201 and 202212 then claim else 0 end ),0) as claim_2022 , 
COALESCE(sum(case when prem_due_mo_id between 202201 and 202212 then claim_cf_covid else 0 end ),0) as claim_cf_covid_2022,
COALESCE(sum(case when prem_due_mo_id between 202201 and 202212 then paid_prem  else 0 end ),0) as paid_prem_2022,

COALESCE(sum(case when prem_due_mo_id between 202301 and 202312 then claim else 0 end ),0) as claim_2023 , 
COALESCE(sum(case when prem_due_mo_id between 202301 and 202312 then claim_cf_covid else 0 end ),0) as claim_cf_covid_2023,
COALESCE(sum(case when prem_due_mo_id between 202301 and 202312 then paid_prem  else 0 end ),0) as paid_prem_2023,

COALESCE(sum(case when prem_due_mo_id between 202401 and 202412 then claim else 0 end ),0) as claim_2024 , 
COALESCE(sum(case when prem_due_mo_id between 202401 and 202412 then claim_cf_covid else 0 end ),0) as claim_cf_covid_2024,
COALESCE(sum(case when prem_due_mo_id between 202401 and 202412 then paid_prem  else 0 end ),0) as paid_prem_2024

from IDENTIFIER(:V_P_LVL_CLAIM_INFO) a
inner join IDENTIFIER(:V_EZ_CLM_CAMP_PERS) b on a.pers_id  = b.person_id
where a.prem_due_mo_id between 202101 and 202412
group by pers_id,prdct_eff_mo_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EZ_CLM_MS_CLM)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP35'';

V_STEP_NAME :=  ''create a table EZ_CLM_CAMP5'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EZ_CLM_CAMP5) COPY GRANTS as
select a.*,
(case when b.pers_id is not null then 1 else 0 end) as Inforce_LR_found,
b.claim_2021,b.claim_cf_covid_2021,b.paid_prem_2021,
b.claim_2022,b.claim_cf_covid_2022,b.paid_prem_2022,
b.claim_2023,b.claim_cf_covid_2023,b.paid_prem_2023,
b.claim_2024,b.claim_cf_covid_2024,b.paid_prem_2024

 
from IDENTIFIER(:V_EZ_CLM_CAMP4) a left join IDENTIFIER(:V_EZ_CLM_MS_CLM) b
on a.person_id = b.pers_id and a.prdct_eff_mo_id = b.prdct_eff_mo_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EZ_CLM_CAMP5)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP36'';

V_STEP_NAME :=  ''create a table EZ_CLM_CAMP6'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EZ_CLM_CAMP6) COPY GRANTS as
select * from IDENTIFIER(:V_EZ_CLM_CAMP5);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EZ_CLM_CAMP6)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP37'';

V_STEP_NAME :=  ''create a table PRIV_AUTH'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_PRIV_AUTH) COPY GRANTS as
Select a.*,xr.Ship_person_id as Ship_person_id, xr.UCPS_PERSON_ID,
vap.creation_date as PA_creation_date,
year(vap.creation_date)*100+month(vap.creation_date) as PA_creation_month,
vap.aux_person_start_date as PA_aux_person_start_date,
year(vap.aux_person_start_date)*100+month(vap.aux_person_start_date) as PA_aux_person_start_month,
vap.aux_person_stop_date as PA_aux_person_stop_date,
year(vap.aux_person_stop_date)*100+month(vap.aux_person_stop_date) as PA_aux_person_stop_month,
AUXILIARY_PERSON_TYPE_ID
from (select distinct person_id , extract_date  from IDENTIFIER(:V_EZ_CLM_CAMP6)) a inner join IDENTIFIER(:V_SHIP_PERSON_XREF) xr  
on a.person_id = xr.person_id
inner join (select * from IDENTIFIER(:V_AUXILIARY_PERSON) where AUXILIARY_PERSON_TYPE_ID=6) vap 
on xr.Ship_person_id = vap.Individual_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_PRIV_AUTH)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP38'';

V_STEP_NAME :=  ''create a table PRIV_AUTH1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_PRIV_AUTH1) COPY GRANTS as
select person_id, extract_date,
max(case when date(PA_creation_date)<=extract_date then 1  end) as Priv_Auth_Date_flag,
max(case when PA_creation_month<=(year(extract_date)*100+month(extract_date)) then 1  end)
as Priv_Auth_Mon_flag
from IDENTIFIER(:V_PRIV_AUTH) group by person_id, extract_date;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_PRIV_AUTH1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP39'';

V_STEP_NAME :=  ''create a table EZ_CLM_CAMP7'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EZ_CLM_CAMP7) COPY GRANTS as
select a.* , COALESCE(b.Priv_Auth_Date_flag,0) as Priv_Auth_Date_flag,
COALESCE(b.Priv_Auth_Mon_flag,0) as Priv_Auth_Mon_flag,
cast(concat(substr(dob_id,1,4), ''-'',substr(dob_id,5,2), ''-'',substr(dob_id,7,2)) as date) as person_birth_date
from IDENTIFIER(:V_EZ_CLM_CAMP6) a left join IDENTIFIER(:V_PRIV_AUTH1) b on 
a.person_id =b.person_id and a.extract_date =b.extract_date;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EZ_CLM_CAMP7)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP40'';

V_STEP_NAME :=  ''create a table WEB_REG'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_WEB_REG) COPY GRANTS as
select a.*,wr.calculated_web_registration_date,
year(wr.calculated_web_registration_date)*100+month(wr.calculated_web_registration_date) 
calculated_web_registration_month
from 
(select distinct person_id , extract_date from IDENTIFIER(:V_EZ_CLM_CAMP6)) as a
inner join 
(select distinct person_id, calculated_web_registration_date from IDENTIFIER(:V_AC_WEB_REGISTRATION)) wr
on a.person_id = wr.person_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_WEB_REG)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP41'';

V_STEP_NAME :=  ''create a table WEB_REG1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_WEB_REG1) COPY GRANTS as
select person_id, extract_date,
max(case when calculated_web_registration_date<=extract_date then 1  end) as Web_Reg_Date_flag,
max(case when calculated_web_registration_month<=(year(extract_date)*100+month(extract_date)) then 1  end)
as Web_Reg_Mon_flag
from IDENTIFIER(:V_WEB_REG) group by person_id, extract_date;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_WEB_REG1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP42'';

V_STEP_NAME :=  ''create a table EZ_CLM_CAMP8'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EZ_CLM_CAMP8) COPY GRANTS as
select a.* , COALESCE(b.Web_Reg_Date_flag,0) as Web_Reg_Date_flag,
COALESCE(b.Web_Reg_Mon_flag,0) as Web_Reg_Mon_flag,
months_between(a.extract_date,prdct_Eff_dt) as Tenure_months,
(case when floor(months_between(a.extract_date,prdct_Eff_dt)) between 0 and 12 then ''0-1 year''
when floor(months_between(a.extract_date,prdct_Eff_dt)) between 13 and 24 then ''1-2 years''
when floor(months_between(a.extract_date,prdct_Eff_dt)) between 25 and 36 then ''2-3 years''
when floor(months_between(a.extract_date,prdct_Eff_dt)) between 37 and 60 then ''3-5 years''
when floor(months_between(a.extract_date,prdct_Eff_dt)) >60 then ''5+ years''
else ''Others'' end) as Tenure_buckets,

(case when floor(datediff(day,person_birth_date,a.extract_date)/365) <65 then ''<65'' 
        when floor(datediff(day,person_birth_date,a.extract_date)/365) =65 then ''65'' 
        when floor(datediff(day,person_birth_date,a.extract_date)/365) >65 and floor(datediff(day,person_birth_date,a.extract_date)/365) <=69 then ''66-69'' 
        when floor(datediff(day,person_birth_date,a.extract_date)/365) >69 and floor(datediff(day,person_birth_date,a.extract_date)/365) <=74 then ''70-74''
        when floor(datediff(day,person_birth_date,a.extract_date)/365) >74 and floor(datediff(day,person_birth_date,a.extract_date)/365) <=79 then ''75-79''
        when floor(datediff(day,person_birth_date,a.extract_date)/365) >79  then ''80+''
end) as age_at_extract_dt,

(case when floor(datediff(day,person_birth_date,a.prdct_eff_dt)/365) <65 then ''<65'' 
        when floor(datediff(day,person_birth_date,a.prdct_eff_dt)/365) =65 then ''65'' 
        when floor(datediff(day,person_birth_date,a.prdct_eff_dt)/365) >65 and floor(datediff(day,person_birth_date,a.prdct_eff_dt)/365) <=69 then ''66-69'' 
        when floor(datediff(day,person_birth_date,a.prdct_eff_dt)/365) >69 and floor(datediff(day,person_birth_date,a.prdct_eff_dt)/365) <=74 then ''70-74''
        when floor(datediff(day,person_birth_date,a.prdct_eff_dt)/365) >74 and floor(datediff(day,person_birth_date,a.prdct_eff_dt)/365) <=79 then ''75-79''
        when floor(datediff(day,person_birth_date,a.prdct_eff_dt)/365) >79  then ''80+''
end) as age_at_enrollment

from IDENTIFIER(:V_EZ_CLM_CAMP7) a left join IDENTIFIER(:V_WEB_REG1) b on 
a.person_id =b.person_id and a.extract_date =b.extract_date;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EZ_CLM_CAMP8)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP43'';

V_STEP_NAME :=  ''create a table EZ_CLM_MBR2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EZ_CLM_MBR2) COPY GRANTS as 
select *, LPAD(member_number_str,11,''0'') as acct_nbr
from IDENTIFIER(:V_EZ_CLM_MBR_2022_23_24) where member_number is not null;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EZ_CLM_MBR2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP44'';

V_STEP_NAME :=  ''create a table EZCLAIM_ENROLLED_FOR_LAPSE_SA_WRK'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EZCLAIM_ENROLLED_FOR_LAPSE_SA_WRK) COPY GRANTS as
select acct_nbr,status,

subacct_submitted_date as Start_date,
(case when status <> ''SUB_ACCOUNT_SUBMITTED'' and 
least(COALESCE(cancellation_date,''2099-12-31''),COALESCE(suspended_date,''2099-12-31''),
COALESCE(termination_date,''2099-12-31''))  <> ''2099-12-31''
THEN 
least(COALESCE(cancellation_date,''2099-12-31''),COALESCE(suspended_date,''2099-12-31''),
COALESCE(termination_date,''2099-12-31'')) end) as end_date_min,

(case when status <> ''SUB_ACCOUNT_SUBMITTED'' and 
greatest(COALESCE(cancellation_date,''1900-12-31''),COALESCE(suspended_date,''1900-12-31''),
COALESCE(termination_date,''1900-12-31'')) <> ''1900-12-31''
THEN 
greatest(COALESCE(cancellation_date,''1900-12-31''),COALESCE(suspended_date,''1900-12-31''),
COALESCE(termination_date,''1900-12-31'')) end) as end_date_max
from IDENTIFIER(:V_EZ_CLM_MBR2) where subacct_submitted_date is not null;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EZCLAIM_ENROLLED_FOR_LAPSE_SA_WRK)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP45'';

V_STEP_NAME :=  ''create a table EZ_CLM_CAMP9'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EZ_CLM_CAMP9) COPY GRANTS as
select 
a.person_id,a.pilot_fg,a.pilot_fg1,a.ltr_date_pilot,a.membership_number_pilot,a.actual_drop_date_ce,a.extract_date_ce,a.extract_date,
a.prem_due_mo_id,a.d_st_cd,a.lf_catgy_nm,a.prdct_sub_grp,a.pln_lvl_desc,a.pln_typ,a.prdct_typ,a.pln_grp,a.smart_prdct_typ_var,
a.prdct_acqn_chnl_lvl_1,a.cert_acqn_chnl_lvl_1,a.prdct_acqn_chnl_lvl_2,a.cert_acqn_chnl_lvl_2,a.cert_actv_lvl_1_txt,
a.pln_lvl,a.cert_actv_lvl_2_txt,a.dscnt_annl_payr_desc,a.dscnt_eft_desc,a.dscnt_erly_enrl_flg,
a.dscnt_erly_enrl_desc,a.dscnt_erly_enrl_nm,a.rtng_area_cd,a.rtng_area_nm,a.gdr_desc,
a.dscnt_multi_insd_flg,a.surchrg_tbcc_user_flg,a.dscnt_erly_enrl_yr,a.dscnt_erly_enrl_adj_amt,
a.undwr_pln_rqr_txt,a.undwr_prdct_rqr_txt,a.prem_due_age_id,a.age,a.pers_id,a.isid,a.indv_id,
a.part_b_eff_dt_id,a.dob_id,a.medcr_id,a.mbi_final,a.zip_cd,a.cnty_cd,a.rgn,a.cty,a.area_cd,
a.cnty_nm,a.cert_actv_lvl_3_txt,a.pty_id,a.pty_typ,a.agt_id,a.agt_typ,a.agt_sub_typ,a.ealliance_pref_nm,
a.wrt_pty_id,a.wrt_pty_typ,a.wrt_agt_id,a.wrt_agt_typ,a.wrt_agt_sub_typ,a.wrt_ealliance_pref_nm,
a.ref_pty_id,a.ref_pty_typ,a.ref_agt_id,a.ref_agt_typ,a.ref_agt_sub_typ,a.ref_ealliance_pref_nm,a.rt_dtrm_cd_desc,
a.acct_nbr as acct_nbr_mbr,a.d_mbr_info_sk,a.compas_insd_pln_id,a.d_lgl_enty_sk,a.lgl_enty_nm,a.lgl_enty_shrt_desc,
a.prdct_eff_mo_id,a.mbr,a.prem_due_dt,a.prdct_eff_dt,a.self_enroll_flag,a.pty_id_final,a.agt_id_final,
a.pty_typ_final,a.agt_typ_final,a.ref_ealliance_pref_nm_final,a.e_alliance_partner_name,a.nickname,a.e_alliance_old_category,
a.e_alliance_new_category,a.marketing_channel_final,a.marketing_channel_cat_2,a.marketing_channel_cat_3,a.ealliance_partner_name_new,
a.ealliance_cat_new,a.partb_eff_age_lessthan65,a.uw_pln_rqr_txt,a.uw_prdct_rqr_txt,a.plan,a.mbr_plan_eff_dt,a.dsenrl_dt,
a.pdp_fg,a.homval,a.homstat,a.geners,a.nph19,a.college,a.oc,a.amlk_id,a.lvwl20,a.snic,a.geners20,a.netw30,
a.estinc30,a.c210mys,a.estinv30,a.irisnr,a.mb3g,a.estdii30,a.mbr_details_mon,a.extract_mbr_mon_diff,a.row_num,
a.aux1_alternate_payer,a.aux1_alternate_payer_bg_dt,a.aux1_alternate_payer_end_dt,a.aux2_third_party_designee,
a.aux2_third_party_designee_bg_dt,a.aux2_third_party_designee_end_dt,a.aux3_power_of_attorney,a.aux3_power_of_attorney_bg_dt,
a.aux3_power_of_attorney_end_dt,a.aux4_guardian,a.aux4_guardian_bg_dt,a.aux4_guardian_end_dt,a.aux5_conservator,
a.aux5_conservator_bg_dt,a.aux5_conservator_end_dt,a.aux6_authorized_representative,a.aux6_authorized_representative_bg_dt,a.aux6_authorized_representative_end_dt,a.aux7_trustee,a.aux7_trustee_bg_dt,a.aux7_trustee_end_dt,a.aux8_sponsor,a.aux8_sponsor_bg_dt,a.aux8_sponsor_end_dt,a.aux9_custodial_guardian,a.aux9_custodial_guardian_bg_dt,a.aux9_custodial_guardian_end_dt,a.inforce_lr_found,
a.claim_2021,a.claim_cf_covid_2021,a.paid_prem_2021,
a.claim_2022,a.claim_cf_covid_2022,a.paid_prem_2022,
a.claim_2023,a.claim_cf_covid_2023,a.paid_prem_2023,
a.claim_2024,a.claim_cf_covid_2024,a.paid_prem_2024,
a.priv_auth_date_flag,a.priv_auth_mon_flag,a.person_birth_date,a.web_reg_date_flag,a.web_reg_mon_flag,a.tenure_months,a.tenure_buckets,a.age_at_extract_dt,a.age_at_enrollment,

b.acct_nbr as acct_nbr_reg, b.abp_type,b.insured_name,b.member_number_str,b.status,
b.record_date,b.Enrollment_Form_Received_Date as create_ts,b.confirm_submission_date,
b.payer_express_date,b.subacct_submitted_date,b.cancellation_date,b.suspended_date,b.termination_date
,(case when b.acct_nbr is null then ''N'' else ''Y'' end) as ez_clm_reg
from IDENTIFIER(:V_EZ_CLM_CAMP8) as a full join IDENTIFIER(:V_EZ_CLM_MBR2) as b 
on a.acct_nbr = b.acct_nbr;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EZ_CLM_CAMP9)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP46'';

V_STEP_NAME :=  ''create a table EZ_CLM_CAMP9_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EZ_CLM_CAMP9_1) COPY GRANTS as 
select a.*,coalesce(acct_nbr_mbr,acct_nbr_reg) as acct_nbr
from IDENTIFIER(:V_EZ_CLM_CAMP9) as a ;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EZ_CLM_CAMP9_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP47'';

V_STEP_NAME :=  ''create a table EZ_CLM_CAMP10'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EZ_CLM_CAMP10) COPY GRANTS as 
select a.*,''Enrollment Received'' as Status1
,create_ts as Final_Date
 from IDENTIFIER(:V_EZ_CLM_CAMP9_1) as a where ez_clm_reg = ''Y''
union
select b.*,Status as Status1,
(case when status = ''SUSPENDED'' then coalesce(suspended_date,subacct_submitted_date) 
when status = ''CANCELLED'' then coalesce(cancellation_date,subacct_submitted_date) 
when status = ''TERMINATED'' then coalesce(termination_date,subacct_submitted_date) 
when status = ''UNDER_REVIEW'' then create_ts end ) as Final_Date
from IDENTIFIER(:V_EZ_CLM_CAMP9_1) as b  where ez_clm_reg = ''Y''  and 
Status in (''SUSPENDED'',''CANCELLED'',''TERMINATED'',''UNDER_REVIEW'')
;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EZ_CLM_CAMP10)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP48'';

V_STEP_NAME :=  ''create a table EZ_CLM_PMNT'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EZ_CLM_PMNT) COPY GRANTS as
select a.*,
(case when b.acct_nbr is not null then 1 else 0 end) as campaign_fg,
b.extract_date as extract_date_mbr,
b.extract_date_ce as extract_date_ce_mbr,
b.actual_drop_date_ce as actual_drop_date_ce_mbr,
b.d_st_cd as d_st_cd_mbr,
b.pln_lvl_desc as pln_lvl_desc_mbr,
b.prdct_acqn_chnl_lvl_1 as prdct_acqn_chnl_lvl_1_mbr,
b.pln_lvl as pln_lvl_mbr,
b.gdr_desc as gdr_desc_mbr,
b.dscnt_eft_desc as dscnt_eft_desc_mbr,
b.dscnt_multi_insd_flg as dscnt_multi_insd_flg_mbr,
b.undwr_pln_rqr_txt as undwr_pln_rqr_txt_mbr,
b.undwr_prdct_rqr_txt as undwr_prdct_rqr_txt_mbr,
b.age as age_mbr,
b.part_b_eff_dt_id as part_b_eff_dt_id_mbr,
b.lgl_enty_nm as lgl_enty_nm_mbr,
b.lgl_enty_shrt_desc as lgl_enty_shrt_desc_mbr,
b.prdct_eff_mo_id as prdct_eff_mo_id_mbr,
b.marketing_channel_final as marketing_channel_final_mbr,
b.marketing_channel_cat_2 as marketing_channel_cat_2_mbr,
b.marketing_channel_cat_3 as marketing_channel_cat_3_mbr,
b.uw_pln_rqr_txt as uw_pln_rqr_txt_mbr,
b.uw_prdct_rqr_txt as uw_prdct_rqr_txt_mbr,
b.pdp_fg as pdp_fg_mbr,
b.homval as homval_mbr,
b.homstat as homstat_mbr,
b.geners as geners_mbr,
b.nph19 as nph19_mbr,
b.college as college_mbr,
b.oc as oc_mbr,
b.lvwl20 as lvwl20_mbr,
b.snic as snic_mbr,
b.geners20 as geners20_mbr,
b.netw30 as netw30_mbr,
b.estinc30 as estinc30_mbr,
b.c210mys as c210mys_mbr,
b.estinv30 as estinv30_mbr,
b.irisnr as irisnr_mbr,
b.mb3g as mb3g_mbr,
b.estdii30 as estdii30_mbr,
b.aux1_alternate_payer as aux1_alternate_payer_mbr,
b.aux2_third_party_designee as aux2_third_party_designee_mbr,
b.aux3_power_of_attorney as aux3_power_of_attorney_mbr,
b.aux4_guardian as aux4_guardian_mbr,
b.aux5_conservator as aux5_conservator_mbr,
b.aux6_authorized_representative as aux6_authorized_representative_mbr,
b.aux7_trustee as aux7_trustee_mbr,
b.aux8_sponsor as aux8_sponsor_mbr,
b.aux9_custodial_guardian as aux9_custodial_guardian_mbr,
b.age_at_extract_dt as age_at_extract_dt_mbr,
b.age_at_enrollment as age_at_enrollment_mbr,

(case when c.acct_nbr is not null then 1 else 0 end) as enrlmnt_fg,
c.abp_type as abp_type_mbr,
c.status  as status_mbr,
--c.bank_account_type as bank_account_type_mbr,
c.record_date as record_date_mbr,
c.Enrollment_Form_Received_Date as create_ts_mbr,
c.confirm_submission_date as confirm_submission_date_mbr,
c.payer_express_date as payer_express_date_mbr,
c.subacct_submitted_date as subacct_submitted_date_mbr,
c.cancellation_date as cancellation_date_mbr,
c.suspended_date as suspended_date_mbr,
c.termination_date as termination_date_mbr
from IDENTIFIER(:V_EZ_CLM_PMNT_22_23_24)  a left join IDENTIFIER(:V_EZ_CLM_CAMP9_1) b on a.acct_nbr = b.acct_nbr
left join IDENTIFIER(:V_EZ_CLM_MBR2) c on a.acct_nbr = c.acct_nbr ;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EZ_CLM_PMNT)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP49'';

V_STEP_NAME :=  ''create a table EZ_CLM_PMNT_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EZ_CLM_PMNT_1) COPY GRANTS as
select a.*, ''Created TS'' as Filter_Dataset,created_ts as Final_Date
from IDENTIFIER(:V_EZ_CLM_PMNT) a where created_ts is not null
union
select b.*, ''Payer Exp Submit Date'' as Filter_Dataset,payer_exp_submit_date as Final_Date
from IDENTIFIER(:V_EZ_CLM_PMNT) b where payer_exp_submit_date is not null
union
select c.*, ''Integrated Pay Submit Date'' as Filter_Dataset,integrated_pay_submit_date as Final_Date
from IDENTIFIER(:V_EZ_CLM_PMNT) c where integrated_pay_submit_date is not null;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EZ_CLM_PMNT_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP50'';

V_STEP_NAME :=  ''create a table EZ_CLM_CAMP_SA'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EZ_CLM_CAMP_SA) COPY GRANTS as
select *
, cast(to_date(:V_REPORT_DATE) as date) as refresh_date 
 from IDENTIFIER(:V_EZ_CLM_CAMP9_1);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EZ_CLM_CAMP_SA)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP51'';

V_STEP_NAME :=  ''create a table EZ_CLM_CAMP_SA_DATE'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EZ_CLM_CAMP_SA_DATE) COPY GRANTS as
select * 
, cast(to_date(:V_REPORT_DATE) as date) as refresh_date 
from IDENTIFIER(:V_EZ_CLM_CAMP10);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EZ_CLM_CAMP_SA_DATE)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP52'';

V_STEP_NAME :=  ''create a table EZ_CLM_PMNT_SA'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EZ_CLM_PMNT_SA) COPY GRANTS as
select * 
,regexp_replace(status,''_'','' '') as status2
, cast(to_date(:V_REPORT_DATE) as date) as refresh_date 
from IDENTIFIER(:V_EZ_CLM_PMNT);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EZ_CLM_PMNT_SA)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP53'';

V_STEP_NAME :=  ''create a table EZ_CLM_PMNT_SA_DATE'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EZ_CLM_PMNT_SA_DATE) COPY GRANTS as
select * 
, cast(to_date(:V_REPORT_DATE) as date) as refresh_date 
from IDENTIFIER(:V_EZ_CLM_PMNT_1);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EZ_CLM_PMNT_SA_DATE)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP54'';

V_STEP_NAME :=  ''create a table EZCLAIM_ENROLLED_FOR_LAPSE_SA'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EZCLAIM_ENROLLED_FOR_LAPSE_SA) COPY GRANTS as
select * 
from IDENTIFIER(:V_EZCLAIM_ENROLLED_FOR_LAPSE_SA_WRK);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EZCLAIM_ENROLLED_FOR_LAPSE_SA)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP55'';

V_STEP_NAME :=  ''create a table EZ_CLM_MBR_QC'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EZ_CLM_MBR_QC) COPY GRANTS as 
select a.dt, b.reached,b.reached_null,d.registration, c.reached_prev ,c.reached_prev_null, e.registration_prev
FROM 

(select extract_date as dt from IDENTIFIER(:V_EZ_CLM_CAMP_SA)
UNION
select extract_date as dt from IDENTIFIER(:V_EZ_CLM_CAMP_SA_BCK)
UNION
select create_ts as dt from IDENTIFIER(:V_EZ_CLM_CAMP_SA) where create_ts is not null
UNION
select create_ts as dt from IDENTIFIER(:V_EZ_CLM_CAMP_SA_BCK) where create_ts is not null) a
left join (select extract_date,count(distinct person_id) as reached,count(case when marketing_channel_final is null then person_id end) as reached_null from IDENTIFIER(:V_EZ_CLM_CAMP_SA) group by extract_date) b 
on a.dt = b.extract_date
left join (select extract_date,count(distinct person_id) as reached_prev,count(case when marketing_channel_final is null then person_id end) as reached_prev_null  from IDENTIFIER(:V_EZ_CLM_CAMP_SA_BCK) group by extract_date) c
on a.dt = c.extract_date
left join (select create_ts,count(distinct person_id) as registration from IDENTIFIER(:V_EZ_CLM_CAMP_SA) group by create_ts) d
on a.dt = d.create_ts
left join (select create_ts,count(distinct person_id) as registration_prev from IDENTIFIER(:V_EZ_CLM_CAMP_SA_BCK) group by create_ts) e
on a.dt = e.create_ts;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EZ_CLM_MBR_QC)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP56'';

V_STEP_NAME :=  ''create a table EZ_CLM_PMNT_QC'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EZ_CLM_PMNT_QC) COPY GRANTS as 
select a.dt,b.distinct_current_claim,c.distinct_previous_claim 
FROM 

(select created_ts as dt from IDENTIFIER(:V_EZ_CLM_PMNT_SA)
UNION
select created_ts as dt from IDENTIFIER(:V_EZ_CLM_PMNT_SA_BCK)) a
left join (select created_ts,count(distinct claim_number) as distinct_current_claim from IDENTIFIER(:V_EZ_CLM_PMNT_SA) group by created_ts) b
on a.dt = b.created_ts
left join (select created_ts,count(distinct claim_number) as distinct_previous_claim from IDENTIFIER(:V_EZ_CLM_PMNT_SA_BCK) group by created_ts) c
on a.dt = c.created_ts;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EZ_CLM_PMNT_QC)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP57'';

V_STEP_NAME :=  ''create a table CAMPSA_PMNTSA_QC'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE  IDENTIFIER(:V_CAMPSA_PMNTSA_QC) COPY GRANTS AS
SELECT
    COALESCE(a.marketing_channel_final, b.marketing_channel_final_mbr) AS marketing_channel,
    a.cnt_camp,
    b.cnt_payment
FROM
    (SELECT marketing_channel_final, COUNT(*) AS cnt_camp
     FROM  IDENTIFIER(:V_EZ_CLM_CAMP_SA)
     GROUP BY marketing_channel_final) a
FULL OUTER JOIN
    (SELECT marketing_channel_final_mbr, COUNT(*) AS cnt_payment
     FROM IDENTIFIER(:V_EZ_CLM_PMNT_SA)
     GROUP BY marketing_channel_final_mbr) b
ON
    a.marketing_channel_final = b.marketing_channel_final_mbr;
	
V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_CAMPSA_PMNTSA_QC)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);


RAISE;

END;

';
