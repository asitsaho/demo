USE SCHEMA BDR_FFP_DA;



CREATE OR REPLACE PROCEDURE BDR_FFP_DA.SP_RETENTION_CAMPAIGN_SUPP("PIPELINE_ID" VARCHAR(16777216), "PIPELINE_NAME" VARCHAR(16777216), "DB_NAME" VARCHAR(16777216), "UTIL_SC" VARCHAR(16777216), "TGT_SC" VARCHAR(16777216), "FFP_WRK_SC" VARCHAR(16777216), "SRC_SC" VARCHAR(16777216), "ONE_SC" VARCHAR(16777216), "TWO_SC" VARCHAR(16777216), "THREE_SC" VARCHAR(16777216), "WH" VARCHAR(16777216), "CURR_DATE" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

V_CURRENT_DATE   DATE := COALESCE(TO_DATE(:CURR_DATE), CURRENT_DATE());

V_REPORT_DATE DATE := COALESCE(TO_DATE(:CURR_DATE), CURRENT_DATE());

V_VAR_DT VARCHAR := (select year(CURRENT_DATE())*100+month(CURRENT_DATE()));
V_VAR_DT1 DATE := (select date_trunc(''month'',current_date()));
V_VAR_DT2 DATE := (select date_trunc(''month'',DATEADD(month,-35,current_date())));

V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := :DB_NAME||''.''||COALESCE(:UTIL_SC, ''UTIL'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';

V_PROCESS_NAME   VARCHAR DEFAULT ''RETENTION_CAMPAIGN_SUPPRESSION'';

V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''RETENTION_CAMPAIGN_SUPPRESSION'';

V_STEP             VARCHAR;

V_STEP_NAME        VARCHAR;

V_START_TIME       VARCHAR;

V_END_TIME         VARCHAR;

V_ROWS_PARSED       INTEGER;

V_ROWS_LOADED       INTEGER;

V_MESSAGE          VARCHAR;

V_LAST_QUERY_ID    VARCHAR;

V_FILE_QUERY VARCHAR;

V_F_CLM_BIL_LN_HIST VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''BDR_DM'') || ''.F_CLM_BIL_LN_HIST'';
V_D_CLM_ICD VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''BDR_DM'') || ''.D_CLM_ICD'';
V_D_PLN_BEN_MOD VARCHAR := :DB_NAME || ''.'' || COALESCE(:TWO_SC, ''BDR_CONF'') || ''.D_PLN_BEN_MOD'';
V_D_MBR_INFO VARCHAR := :DB_NAME || ''.'' || COALESCE(:TWO_SC, ''BDR_CONF'') || ''.D_MBR_INFO'';
V_SHIP_PERSON_XREF VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.SHIP_PERSON_XREF'';
V_APPS_RPTG_DAILY VARCHAR := :DB_NAME || ''.'' || COALESCE(:THREE_SC, ''SRC_MPO'') || ''.APPS_RPTG_DAILY'';
V_D_ICD_LOOK VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''BDR_DM'') || ''.D_ICD_LOOK'';




V_ICD VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.ICD'';
V_V_F_CLM_BIL_LN_HIST_TEMP VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.V_F_CLM_BIL_LN_HIST_TEMP'';
V_P_LVL_CONDITIONS_INFO VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RETENTION_CMPGN_SUPP_P_LVL_CONDITIONS_INFO'';
V_RETENTION_CAMPAIGN VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RETENTION_CAMPAIGN'';
V_P_LVL_CLAIM_INFO VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.INFORCELR_P_LVL_CLAIM_INFO'';
V_RETENTION_CAMPAIGN_MLR VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA_WRK'') || ''.RETENTION_CMPGN_SUPP_RETENTION_CAMPAIGN_MLR'';
V_RETENTION_CAMPAIGN_ESRD_CLM VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RETENTION_CAMPAIGN_ESRD_CLM'';
V_RETENTION_MKTG_SUPPR_INTERIM VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA_WRK'') || ''.RETENTION_MKTG_SUPPR_INTERIM'';
V_RETENTION_MKTG_SUPPR_INTERIM_BACKUP VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA_WRK'') || ''.RETENTION_MKTG_SUPPR_INTERIM_BACKUP'';
V_RETENTION_MKTG_SUPPR VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA_WRK'') || ''.RETENTION_CMPGN_SUPP_RETENTION_MKTG_SUPPR'';
V_RETENTION_MKTG_SUPPR_BACKUP VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA_WRK'') || ''.RETENTION_CMPGN_SUPP_RETENTION_MKTG_SUPPR_BACKUP'';
V_P_LVL_CONDITIONS_INFO_SUMMARY  VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA_WRK'') || ''.RETENTION_CMPGN_SUPP_P_LVL_CONDITIONS_INFO_SUMMARY '';
V_P_LVL_CONDITIONS_INFO_BACKUP VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA_WRK'') || ''.RETENTION_CMPGN_SUPP_P_LVL_CONDITIONS_INFO_BACKUP'';
V_RETENTION_MKTG_SUPPR_SUMMARY  VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA_WRK'') || ''.RETENTION_CMPGN_SUPP_RETENTION_MKTG_SUPPR_SUMMARY '';
V_RETENTION_MKTG_SUPPR_LAM_SUMMARY  VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA_WRK'') || ''.RETENTION_MKTG_SUPPR_LAM_SUMMARY '';



BEGIN

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP1'';

V_STEP_NAME :=  ''create backup Tables'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_P_LVL_CONDITIONS_INFO_BACKUP) COPY GRANTS as
select * from IDENTIFIER(:V_P_LVL_CONDITIONS_INFO);



create or replace table IDENTIFIER(:V_RETENTION_MKTG_SUPPR_INTERIM_BACKUP) COPY GRANTS as
select * from IDENTIFIER(:V_RETENTION_MKTG_SUPPR_INTERIM);

create or replace table IDENTIFIER(:V_RETENTION_MKTG_SUPPR_BACKUP) COPY GRANTS as
select * from IDENTIFIER(:V_RETENTION_MKTG_SUPPR) ;

--V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_RETENTION_MKTG_SUPPR_BACKUP)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, NULL, NULL, NULL, NULL);


V_STEP := ''STEP2'';

V_STEP_NAME :=  ''create a RTUW_MASTER'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_ICD) as
select distinct F_CLM_HIST_SK from 
(select * from IDENTIFIER(:V_D_ICD_LOOK) where icd_cd like ''N186%'') icd inner join 
IDENTIFIER(:V_D_CLM_ICD) lkup
ON icd.D_ICD_LOOK_SK = lkup.D_ICD_LOOK_SK;


create or replace  table IDENTIFIER(:V_V_F_CLM_BIL_LN_HIST_TEMP) as 
select clm_nbr,incur_dt_id,f_clm_hist_sk,
d_pln_ben_mod_sk,d_mbr_info_sk from IDENTIFIER(:V_F_CLM_BIL_LN_HIST) where incur_dt_id>=20170101;



create or replace table IDENTIFIER(:V_P_LVL_CONDITIONS_INFO) COPY GRANTS as
select
(case when a31.person_id is not null then a31.person_id else a15.pers_id end) as pers_id,
a15.isid,
floor(a01.INCUR_DT_ID/100) as incur_month,
count(distinct clm_nbr) as Distinct_Claims_N186
from IDENTIFIER(:V_ICD) lkup  inner join IDENTIFIER(:V_V_F_CLM_BIL_LN_HIST_TEMP) as a01
on lkup.F_CLM_HIST_SK = a01.F_CLM_HIST_SK 
inner join (select D_PLN_BEN_MOD_SK from IDENTIFIER(:V_D_PLN_BEN_MOD)
where prdct_sub_grp in (''Med Supp Base'',''Med Supp Rider'') and D_PLN_BEN_MOD_SK is not null) a12
on (a01.D_PLN_BEN_MOD_SK = a12.D_PLN_BEN_MOD_SK)
inner join IDENTIFIER(:V_D_MBR_INFO) a15
on a01.d_mbr_info_sk = a15.d_mbr_info_sk
left join (select SHIP_PERSON_ID,person_id from IDENTIFIER(:V_SHIP_PERSON_XREF)
where SHIP_PERSON_ID is not null) a31
on a15.INDV_ID = a31.SHIP_PERSON_ID
group by 1,2,3;


Create or replace table IDENTIFIER(:V_RETENTION_CAMPAIGN) as
Select a.person_id, a.compas_insd_pln_id,b.insured_plan_id, a.Eff_month, a.prdct_eff_dt, a.Latest_Active_Mth, a.Cur_Mth_Active_Flag, 
a.Cur_Mth_Minus_00_YYYYMM
from 
(
Select distinct a.pers_id as person_id,
a.compas_insd_pln_id,
a.prdct_eff_mo_id as Eff_month,
a.prdct_eff_dt,
a.prem_due_mo_id as Latest_Active_Mth,
ROW_NUMBER() over(partition by a.pers_id order by prem_due_mo_id desc)  as rownumber,
Case when a.prem_due_mo_id = :V_VAR_DT then ''Y'' else ''N'' END AS Cur_Mth_Active_Flag,
:V_VAR_DT as Cur_Mth_Minus_00_YYYYMM  
from (select * from IDENTIFIER(:V_P_LVL_CLAIM_INFO) where pers_id is not null and (coalesce(round(paid_prem,2),0)>0 or coalesce(round(claim,2),0)>0)) a 
where a.prem_due_dt between :V_VAR_DT2 and :V_VAR_DT1) a 
left join IDENTIFIER(:V_APPS_RPTG_DAILY) as b
on a.COMPAS_INSD_PLN_ID = b.source_insured_plan_id
where rownumber = 1;



Create or replace table IDENTIFIER(:V_RETENTION_CAMPAIGN_MLR) COPY GRANTS as 
select a.person_id,
a.compas_insd_pln_id,
a.insured_plan_id,
a.Eff_month,
a.Latest_Active_Mth,
a.Cur_Mth_Active_Flag,
a.Cur_Mth_Minus_00_YYYYMM,
sum(case when abs(datediff(month,:V_VAR_DT1,b.prem_due_dt)) between 3 and 26 then coalesce(round(b.claim,2),0) else 0 end)/
NULLIF(sum(case when abs(datediff(month,:V_VAR_DT1,b.prem_due_dt)) between 3 and 26 then coalesce(round(b.paid_prem,2),0) else 0 end),0)
as Cur_Mth_Minus_03_MLR
from IDENTIFIER(:V_RETENTION_CAMPAIGN) a left join IDENTIFIER(:V_P_LVL_CLAIM_INFO) b on 
a.person_id = b.pers_id 
group by 
a.person_id,
a.compas_insd_pln_id,
a.insured_plan_id,
a.Eff_month,
a.Latest_Active_Mth,
a.Cur_Mth_Active_Flag,
a.Cur_Mth_Minus_00_YYYYMM;


create or replace table IDENTIFIER(:V_RETENTION_CAMPAIGN_ESRD_CLM) as
select a.person_id,
a.compas_insd_pln_id,
a.insured_plan_id,
a.Eff_month,
a.Latest_Active_Mth,
a.Cur_Mth_Active_Flag,
a.Cur_Mth_Minus_00_YYYYMM,
sum(case when abs(datediff(month,:V_VAR_DT1,b.incur_month_dt)) between 3 and 14 then distinct_claims_n186 else 0 end) as Cur_Mth_Minus_03_ESRD_CLM
from IDENTIFIER(:V_RETENTION_CAMPAIGN) a left join 
(Select *,TO_DATE(CONCAT(SUBSTR(incur_month,1,4),''-'',SUBSTR(incur_month,5,2),''-01'')) as incur_month_dt 
from IDENTIFIER(:V_P_LVL_CONDITIONS_INFO)) b on 
a.person_id = b.pers_id 
group by 
a.person_id,
a.compas_insd_pln_id,
a.insured_plan_id,
a.Eff_month,
a.Latest_Active_Mth,
a.Cur_Mth_Active_Flag,
a.Cur_Mth_Minus_00_YYYYMM;



create or replace table IDENTIFIER(:V_RETENTION_MKTG_SUPPR_INTERIM) COPY GRANTS as
select a.person_id,
a.compas_insd_pln_id,
a.insured_plan_id,
a.Eff_month,
a.Latest_Active_Mth,
a.Cur_Mth_Active_Flag,
a.Cur_Mth_Minus_00_YYYYMM,
a.Cur_Mth_Minus_03_MLR,
x.cur_mth_minus_03_mlr as cur_mth_minus_04_mlr,
x.cur_mth_minus_04_mlr as cur_mth_minus_05_mlr,
x.cur_mth_minus_05_mlr as cur_mth_minus_06_mlr,
x.cur_mth_minus_06_mlr as cur_mth_minus_07_mlr,
x.cur_mth_minus_07_mlr as cur_mth_minus_08_mlr,
x.cur_mth_minus_08_mlr as cur_mth_minus_09_mlr,
x.cur_mth_minus_09_mlr as cur_mth_minus_10_mlr,
x.cur_mth_minus_10_mlr as cur_mth_minus_11_mlr,
x.cur_mth_minus_11_mlr as cur_mth_minus_12_mlr,
x.cur_mth_minus_12_mlr as cur_mth_minus_13_mlr,
x.cur_mth_minus_13_mlr as cur_mth_minus_14_mlr,
x.cur_mth_minus_14_mlr as cur_mth_minus_15_mlr,
x.cur_mth_minus_15_mlr as cur_mth_minus_16_mlr,
x.cur_mth_minus_16_mlr as cur_mth_minus_17_mlr,
x.cur_mth_minus_17_mlr as cur_mth_minus_18_mlr,
x.cur_mth_minus_18_mlr as cur_mth_minus_19_mlr,
x.cur_mth_minus_19_mlr as cur_mth_minus_20_mlr,
x.cur_mth_minus_20_mlr as cur_mth_minus_21_mlr,
x.cur_mth_minus_21_mlr as cur_mth_minus_22_mlr,
x.cur_mth_minus_22_mlr as cur_mth_minus_23_mlr,
x.cur_mth_minus_23_mlr as cur_mth_minus_24_mlr,
x.cur_mth_minus_24_mlr as cur_mth_minus_25_mlr,
x.cur_mth_minus_25_mlr as cur_mth_minus_26_mlr,
x.cur_mth_minus_26_mlr as cur_mth_minus_27_mlr,
x.cur_mth_minus_27_mlr as cur_mth_minus_28_mlr,
x.cur_mth_minus_28_mlr as cur_mth_minus_29_mlr,
x.cur_mth_minus_29_mlr as cur_mth_minus_30_mlr,
x.cur_mth_minus_30_mlr as cur_mth_minus_31_mlr,
x.cur_mth_minus_31_mlr as cur_mth_minus_32_mlr,
x.cur_mth_minus_32_mlr as cur_mth_minus_33_mlr,
x.cur_mth_minus_33_mlr as cur_mth_minus_34_mlr,
x.cur_mth_minus_34_mlr as cur_mth_minus_35_mlr,

b.Cur_Mth_Minus_03_ESRD_CLM,
x.cur_mth_minus_03_esrd_clm as cur_mth_minus_04_esrd_clm,
x.cur_mth_minus_04_esrd_clm as cur_mth_minus_05_esrd_clm,
x.cur_mth_minus_05_esrd_clm as cur_mth_minus_06_esrd_clm,
x.cur_mth_minus_06_esrd_clm as cur_mth_minus_07_esrd_clm,
x.cur_mth_minus_07_esrd_clm as cur_mth_minus_08_esrd_clm,
x.cur_mth_minus_08_esrd_clm as cur_mth_minus_09_esrd_clm,
x.cur_mth_minus_09_esrd_clm as cur_mth_minus_10_esrd_clm,
x.cur_mth_minus_10_esrd_clm as cur_mth_minus_11_esrd_clm,
x.cur_mth_minus_11_esrd_clm as cur_mth_minus_12_esrd_clm,
x.cur_mth_minus_12_esrd_clm as cur_mth_minus_13_esrd_clm,
x.cur_mth_minus_13_esrd_clm as cur_mth_minus_14_esrd_clm,
x.cur_mth_minus_14_esrd_clm as cur_mth_minus_15_esrd_clm,
x.cur_mth_minus_15_esrd_clm as cur_mth_minus_16_esrd_clm,
x.cur_mth_minus_16_esrd_clm as cur_mth_minus_17_esrd_clm,
x.cur_mth_minus_17_esrd_clm as cur_mth_minus_18_esrd_clm,
x.cur_mth_minus_18_esrd_clm as cur_mth_minus_19_esrd_clm,
x.cur_mth_minus_19_esrd_clm as cur_mth_minus_20_esrd_clm,
x.cur_mth_minus_20_esrd_clm as cur_mth_minus_21_esrd_clm,
x.cur_mth_minus_21_esrd_clm as cur_mth_minus_22_esrd_clm,
x.cur_mth_minus_22_esrd_clm as cur_mth_minus_23_esrd_clm,
x.cur_mth_minus_23_esrd_clm as cur_mth_minus_24_esrd_clm,
x.cur_mth_minus_24_esrd_clm as cur_mth_minus_25_esrd_clm,
x.cur_mth_minus_25_esrd_clm as cur_mth_minus_26_esrd_clm,
x.cur_mth_minus_26_esrd_clm as cur_mth_minus_27_esrd_clm,
x.cur_mth_minus_27_esrd_clm as cur_mth_minus_28_esrd_clm,
x.cur_mth_minus_28_esrd_clm as cur_mth_minus_29_esrd_clm,
x.cur_mth_minus_29_esrd_clm as cur_mth_minus_30_esrd_clm,
x.cur_mth_minus_30_esrd_clm as cur_mth_minus_31_esrd_clm,
x.cur_mth_minus_31_esrd_clm as cur_mth_minus_32_esrd_clm,
x.cur_mth_minus_32_esrd_clm as cur_mth_minus_33_esrd_clm,
x.cur_mth_minus_33_esrd_clm as cur_mth_minus_34_esrd_clm,
x.cur_mth_minus_34_esrd_clm as cur_mth_minus_35_esrd_clm

from IDENTIFIER(:V_RETENTION_CAMPAIGN_MLR) a 
left join IDENTIFIER(:V_RETENTION_CAMPAIGN_ESRD_CLM) b on a.person_id = b.person_id and a.Eff_month = b.Eff_month
left join IDENTIFIER(:V_RETENTION_MKTG_SUPPR_INTERIM_BACKUP) x on a.person_id = x.person_id
and a.Eff_month = x.Eff_month; 




create or replace table IDENTIFIER(:V_RETENTION_MKTG_SUPPR) COPY GRANTS as
select a.person_id,
a.compas_insd_pln_id,
a.insured_plan_id,
a.Eff_month,
a.Latest_Active_Mth,
a.Cur_Mth_Active_Flag,
a.Cur_Mth_Minus_00_YYYYMM,
CONCAT((case when a.Cur_Mth_Minus_03_ESRD_CLM>=2 then ''1'' else ''0'' end),(case when a.Cur_Mth_Minus_03_MLR>0.9 then ''1'' else ''0'' end)) as Cur_Mth_Minus_03_ESRD_MLR90_Flag,
CONCAT((case when a.Cur_Mth_Minus_04_ESRD_CLM>=2 then ''1'' else ''0'' end),(case when a.Cur_Mth_Minus_04_MLR>0.9 then ''1'' else ''0'' end)) as Cur_Mth_Minus_04_ESRD_MLR90_Flag,
CONCAT((case when a.Cur_Mth_Minus_05_ESRD_CLM>=2 then ''1'' else ''0'' end),(case when a.Cur_Mth_Minus_05_MLR>0.9 then ''1'' else ''0'' end)) as Cur_Mth_Minus_05_ESRD_MLR90_Flag,
CONCAT((case when a.Cur_Mth_Minus_06_ESRD_CLM>=2 then ''1'' else ''0'' end),(case when a.Cur_Mth_Minus_06_MLR>0.9 then ''1'' else ''0'' end)) as Cur_Mth_Minus_06_ESRD_MLR90_Flag,
CONCAT((case when a.Cur_Mth_Minus_07_ESRD_CLM>=2 then ''1'' else ''0'' end),(case when a.Cur_Mth_Minus_07_MLR>0.9 then ''1'' else ''0'' end)) as Cur_Mth_Minus_07_ESRD_MLR90_Flag,
CONCAT((case when a.Cur_Mth_Minus_08_ESRD_CLM>=2 then ''1'' else ''0'' end),(case when a.Cur_Mth_Minus_08_MLR>0.9 then ''1'' else ''0'' end)) as Cur_Mth_Minus_08_ESRD_MLR90_Flag,
CONCAT((case when a.Cur_Mth_Minus_09_ESRD_CLM>=2 then ''1'' else ''0'' end),(case when a.Cur_Mth_Minus_09_MLR>0.9 then ''1'' else ''0'' end)) as Cur_Mth_Minus_09_ESRD_MLR90_Flag,
CONCAT((case when a.Cur_Mth_Minus_10_ESRD_CLM>=2 then ''1'' else ''0'' end),(case when a.Cur_Mth_Minus_10_MLR>0.9 then ''1'' else ''0'' end)) as Cur_Mth_Minus_10_ESRD_MLR90_Flag,
CONCAT((case when a.Cur_Mth_Minus_11_ESRD_CLM>=2 then ''1'' else ''0'' end),(case when a.Cur_Mth_Minus_11_MLR>0.9 then ''1'' else ''0'' end)) as Cur_Mth_Minus_11_ESRD_MLR90_Flag,
CONCAT((case when a.Cur_Mth_Minus_12_ESRD_CLM>=2 then ''1'' else ''0'' end),(case when a.Cur_Mth_Minus_12_MLR>0.9 then ''1'' else ''0'' end)) as Cur_Mth_Minus_12_ESRD_MLR90_Flag,
CONCAT((case when a.Cur_Mth_Minus_13_ESRD_CLM>=2 then ''1'' else ''0'' end),(case when a.Cur_Mth_Minus_13_MLR>0.9 then ''1'' else ''0'' end)) as Cur_Mth_Minus_13_ESRD_MLR90_Flag,
CONCAT((case when a.Cur_Mth_Minus_14_ESRD_CLM>=2 then ''1'' else ''0'' end),(case when a.Cur_Mth_Minus_14_MLR>0.9 then ''1'' else ''0'' end)) as Cur_Mth_Minus_14_ESRD_MLR90_Flag,
CONCAT((case when a.Cur_Mth_Minus_15_ESRD_CLM>=2 then ''1'' else ''0'' end),(case when a.Cur_Mth_Minus_15_MLR>0.9 then ''1'' else ''0'' end)) as Cur_Mth_Minus_15_ESRD_MLR90_Flag,
CONCAT((case when a.Cur_Mth_Minus_16_ESRD_CLM>=2 then ''1'' else ''0'' end),(case when a.Cur_Mth_Minus_16_MLR>0.9 then ''1'' else ''0'' end)) as Cur_Mth_Minus_16_ESRD_MLR90_Flag,
CONCAT((case when a.Cur_Mth_Minus_17_ESRD_CLM>=2 then ''1'' else ''0'' end),(case when a.Cur_Mth_Minus_17_MLR>0.9 then ''1'' else ''0'' end)) as Cur_Mth_Minus_17_ESRD_MLR90_Flag,
CONCAT((case when a.Cur_Mth_Minus_18_ESRD_CLM>=2 then ''1'' else ''0'' end),(case when a.Cur_Mth_Minus_18_MLR>0.9 then ''1'' else ''0'' end)) as Cur_Mth_Minus_18_ESRD_MLR90_Flag,
CONCAT((case when a.Cur_Mth_Minus_19_ESRD_CLM>=2 then ''1'' else ''0'' end),(case when a.Cur_Mth_Minus_19_MLR>0.9 then ''1'' else ''0'' end)) as Cur_Mth_Minus_19_ESRD_MLR90_Flag,
CONCAT((case when a.Cur_Mth_Minus_20_ESRD_CLM>=2 then ''1'' else ''0'' end),(case when a.Cur_Mth_Minus_20_MLR>0.9 then ''1'' else ''0'' end)) as Cur_Mth_Minus_20_ESRD_MLR90_Flag,
CONCAT((case when a.Cur_Mth_Minus_21_ESRD_CLM>=2 then ''1'' else ''0'' end),(case when a.Cur_Mth_Minus_21_MLR>0.9 then ''1'' else ''0'' end)) as Cur_Mth_Minus_21_ESRD_MLR90_Flag,
CONCAT((case when a.Cur_Mth_Minus_22_ESRD_CLM>=2 then ''1'' else ''0'' end),(case when a.Cur_Mth_Minus_22_MLR>0.9 then ''1'' else ''0'' end)) as Cur_Mth_Minus_22_ESRD_MLR90_Flag,
CONCAT((case when a.Cur_Mth_Minus_23_ESRD_CLM>=2 then ''1'' else ''0'' end),(case when a.Cur_Mth_Minus_23_MLR>0.9 then ''1'' else ''0'' end)) as Cur_Mth_Minus_23_ESRD_MLR90_Flag,
CONCAT((case when a.Cur_Mth_Minus_24_ESRD_CLM>=2 then ''1'' else ''0'' end),(case when a.Cur_Mth_Minus_24_MLR>0.9 then ''1'' else ''0'' end)) as Cur_Mth_Minus_24_ESRD_MLR90_Flag,
CONCAT((case when a.Cur_Mth_Minus_25_ESRD_CLM>=2 then ''1'' else ''0'' end),(case when a.Cur_Mth_Minus_25_MLR>0.9 then ''1'' else ''0'' end)) as Cur_Mth_Minus_25_ESRD_MLR90_Flag,
CONCAT((case when a.Cur_Mth_Minus_26_ESRD_CLM>=2 then ''1'' else ''0'' end),(case when a.Cur_Mth_Minus_26_MLR>0.9 then ''1'' else ''0'' end)) as Cur_Mth_Minus_26_ESRD_MLR90_Flag,
CONCAT((case when a.Cur_Mth_Minus_27_ESRD_CLM>=2 then ''1'' else ''0'' end),(case when a.Cur_Mth_Minus_27_MLR>0.9 then ''1'' else ''0'' end)) as Cur_Mth_Minus_27_ESRD_MLR90_Flag,
CONCAT((case when a.Cur_Mth_Minus_28_ESRD_CLM>=2 then ''1'' else ''0'' end),(case when a.Cur_Mth_Minus_28_MLR>0.9 then ''1'' else ''0'' end)) as Cur_Mth_Minus_28_ESRD_MLR90_Flag,
CONCAT((case when a.Cur_Mth_Minus_29_ESRD_CLM>=2 then ''1'' else ''0'' end),(case when a.Cur_Mth_Minus_29_MLR>0.9 then ''1'' else ''0'' end)) as Cur_Mth_Minus_29_ESRD_MLR90_Flag,
CONCAT((case when a.Cur_Mth_Minus_30_ESRD_CLM>=2 then ''1'' else ''0'' end),(case when a.Cur_Mth_Minus_30_MLR>0.9 then ''1'' else ''0'' end)) as Cur_Mth_Minus_30_ESRD_MLR90_Flag,
CONCAT((case when a.Cur_Mth_Minus_31_ESRD_CLM>=2 then ''1'' else ''0'' end),(case when a.Cur_Mth_Minus_31_MLR>0.9 then ''1'' else ''0'' end)) as Cur_Mth_Minus_31_ESRD_MLR90_Flag,
CONCAT((case when a.Cur_Mth_Minus_32_ESRD_CLM>=2 then ''1'' else ''0'' end),(case when a.Cur_Mth_Minus_32_MLR>0.9 then ''1'' else ''0'' end)) as Cur_Mth_Minus_32_ESRD_MLR90_Flag,
CONCAT((case when a.Cur_Mth_Minus_33_ESRD_CLM>=2 then ''1'' else ''0'' end),(case when a.Cur_Mth_Minus_33_MLR>0.9 then ''1'' else ''0'' end)) as Cur_Mth_Minus_33_ESRD_MLR90_Flag,
CONCAT((case when a.Cur_Mth_Minus_34_ESRD_CLM>=2 then ''1'' else ''0'' end),(case when a.Cur_Mth_Minus_34_MLR>0.9 then ''1'' else ''0'' end)) as Cur_Mth_Minus_34_ESRD_MLR90_Flag,
CONCAT((case when a.Cur_Mth_Minus_35_ESRD_CLM>=2 then ''1'' else ''0'' end),(case when a.Cur_Mth_Minus_35_MLR>0.9 then ''1'' else ''0'' end)) as Cur_Mth_Minus_35_ESRD_MLR90_Flag
from IDENTIFIER(:V_RETENTION_MKTG_SUPPR_INTERIM) a; 


Create or replace table IDENTIFIER(:V_P_LVL_CONDITIONS_INFO_SUMMARY) COPY GRANTS as
Select a.*, b.pers_id_prev, b.Distinct_Claims_N186_prev , (a.pers_id_curr - b.pers_id_prev) as check_pers_id, 
(a.Distinct_Claims_N186_curr - b.Distinct_Claims_N186_prev) as check_Distinct_Claims_N186 from
(select incur_month, count(distinct pers_id) as pers_id_curr, sum(Distinct_Claims_N186) as Distinct_Claims_N186_curr
from IDENTIFIER(:V_P_LVL_CONDITIONS_INFO)
group by incur_month) a
left join 
(select incur_month, count(distinct pers_id) as pers_id_prev, sum(Distinct_Claims_N186) as Distinct_Claims_N186_prev
from IDENTIFIER(:V_P_LVL_CONDITIONS_INFO_BACKUP)
group by incur_month) b
on a.incur_month = b.incur_month;


create or replace table IDENTIFIER(:V_RETENTION_MKTG_SUPPR_SUMMARY) COPY GRANTS as 
Select a.*,b.person_id_prev, (person_id_prev - person_id_curr) as check1  from 
(Select cur_mth_minus_03_esrd_mlr90_flag,cur_mth_minus_04_esrd_mlr90_flag,cur_mth_minus_05_esrd_mlr90_flag,
cur_mth_minus_35_esrd_mlr90_flag, cur_mth_active_flag, count(person_id) as person_id_curr
from IDENTIFIER(:V_RETENTION_MKTG_SUPPR)
group by cur_mth_minus_03_esrd_mlr90_flag,cur_mth_minus_04_esrd_mlr90_flag,cur_mth_minus_05_esrd_mlr90_flag,
cur_mth_minus_35_esrd_mlr90_flag, cur_mth_active_flag) a
left join 
(
Select cur_mth_minus_03_esrd_mlr90_flag,cur_mth_minus_04_esrd_mlr90_flag,cur_mth_minus_05_esrd_mlr90_flag,
cur_mth_minus_35_esrd_mlr90_flag, cur_mth_active_flag, count(person_id) as person_id_prev
from IDENTIFIER(:V_RETENTION_MKTG_SUPPR_BACKUP)
group by cur_mth_minus_03_esrd_mlr90_flag,cur_mth_minus_04_esrd_mlr90_flag,cur_mth_minus_05_esrd_mlr90_flag,
cur_mth_minus_35_esrd_mlr90_flag, cur_mth_active_flag
) b
on a.cur_mth_minus_03_esrd_mlr90_flag = b.cur_mth_minus_03_esrd_mlr90_flag and
a.cur_mth_minus_04_esrd_mlr90_flag = b.cur_mth_minus_04_esrd_mlr90_flag and
a.cur_mth_minus_05_esrd_mlr90_flag = b.cur_mth_minus_05_esrd_mlr90_flag and
a.cur_mth_minus_35_esrd_mlr90_flag = b.cur_mth_minus_35_esrd_mlr90_flag
and a.cur_mth_active_flag = b.cur_mth_active_flag
order by cur_mth_minus_03_esrd_mlr90_flag,cur_mth_minus_04_esrd_mlr90_flag,cur_mth_minus_05_esrd_mlr90_flag,
cur_mth_minus_35_esrd_mlr90_flag,cur_mth_active_flag ;


create or replace table IDENTIFIER(:V_RETENTION_MKTG_SUPPR_LAM_SUMMARY) COPY GRANTS as 
select a.latest_active_mth,a.count_of_records as count_of_records_curr, b.count_of_records as count_of_records_prev
from 
(
select latest_active_mth, count(*) as count_of_records  from IDENTIFIER(:V_RETENTION_MKTG_SUPPR) 
group by latest_active_mth) a
left join 
(
select latest_active_mth, count(*) as count_of_records  from IDENTIFIER(:V_RETENTION_MKTG_SUPPR_BACKUP) 
group by latest_active_mth) b
on a.latest_active_mth = b.latest_active_mth
order by latest_active_mth;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_RETENTION_MKTG_SUPPR_LAM_SUMMARY)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

V_FILE_QUERY := ''COPY INTO ''||''@UTIL.STAGE_AZURE_ISDC/analytics/outbox/retention_campaign_supression/ecg_transfer/RETENTION_SUPPRESSION_''||:V_CURRENT_DATE||''.dat''||'' FROM (
           select * from BDR_FFP_DA.RETENTION_MKTG_SUPPR_INTERIM ORDER BY PERSON_ID
               )
file_format = (type = ''''CSV''''
               field_delimiter = '''',''''
               record_delimiter = ''''
''''
               compression = None 
               FIELD_OPTIONALLY_ENCLOSED_BY = None
               EMPTY_FIELD_AS_NULL = FALSE
               ESCAPE_UNENCLOSED_FIELD = NONE
              )
HEADER = True
OVERWRITE = True
MAX_FILE_SIZE = 4900000000
SINGLE = True'';

execute immediate  :V_FILE_QUERY;

EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);


RAISE;

END;

';