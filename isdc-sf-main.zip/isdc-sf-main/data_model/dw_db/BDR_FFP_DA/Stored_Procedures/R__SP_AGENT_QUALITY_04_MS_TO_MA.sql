USE SCHEMA BDR_FFP_DA;


CREATE OR REPLACE PROCEDURE BDR_FFP_DA.SP_AGENT_QUALITY_04_MS_TO_MA("PIPELINE_ID" VARCHAR(16777216), "PIPELINE_NAME" VARCHAR(16777216), "DB_NAME" VARCHAR(16777216), "UTIL_SC" VARCHAR(16777216), "TGT_SC" VARCHAR(16777216), "INTRM_SC" VARCHAR(16777216), "ONE_SC" VARCHAR(16777216), "TWO_SC" VARCHAR(16777216), "THREE_SC" VARCHAR(16777216), "FOUR_SC" VARCHAR(16777216), "WH" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := :DB_NAME||''.''||COALESCE(:UTIL_SC, ''UTIL'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';

V_PROCESS_NAME   VARCHAR DEFAULT ''PROCESS_NAME'';

V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''01_TNA_RDC'';

V_STEP             VARCHAR;

V_STEP_NAME        VARCHAR;

V_START_TIME       VARCHAR;

V_END_TIME         VARCHAR;

V_ROWS_PARSED       INTEGER;

V_ROWS_LOADED       INTEGER;

V_MESSAGE          VARCHAR;

V_LAST_QUERY_ID    VARCHAR;



V_AGENT_QUALITY_MA_SALES VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_MA_SALES'';

V_ALL_APPS_FEDERAL VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''SRC_UCEE'') || ''.ALL_APPS_FEDERAL'';

V_FED_MEMBERS VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''SRC_UCEE'') || ''.FED_MEMBERS'';--changed

V_CMS_HICN_TO_MBI_CROSSWALK VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''SRC_UCEE'') || ''.CMS_HICN_TO_MBI_CROSSWALK'';

V_AGENT_QUALITY_MS_MA_SALES VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_MS_MA_SALES'';

V_ISDW_EFF_SALES_DASHBOARD VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.LOSS_RATIO_ISDW_EFF_SALES_DASHBOARD'';

V_AGENT_QUALITY_FED_HIERARCHY_FINAL VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.AGENT_QUALITY_FED_HIERARCHY_FINAL'';

V_CMDB_PERSON_XREF_INTERFACE VARCHAR := :DB_NAME || ''.'' || COALESCE(:TWO_SC, ''BDR_SMART'') || ''.CMDB_PERSON_XREF_INTERFACE'';

V_AGENT_QUALITY_MA_SALES_V1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_MA_SALES_V1'';

V_AGENT_QUALITY_MA_SALES_2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_MA_SALES_2'';

V_AGENT_QUALITY_MS_MA_SALES_2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_MS_MA_SALES_2'';

V_AGENT_QUALITY_MS_MA_SALES_V1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_MS_MA_SALES_V1'';

V_AGENT_QUALITY_MS_MA_SALES_V2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_MS_MA_SALES_V2'';

V_AGENT_QUALITY_MS_MA_SALES_V3 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_MS_MA_SALES_V3'';

V_AGENT_QUALITY_PRINCIPAL_ORG_2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_PRINCIPAL_ORG_2'';

V_AGENT_QUALITY_MS_MA_SALES_V4 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_MS_MA_SALES_V4'';

V_AGENT_QUALITY_SWITCHERS_MS_MA VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.AGENT_QUALITY_SWITCHERS_MS_MA'';

V_SHIP_PERSON_XREF VARCHAR := :DB_NAME || ''.'' || COALESCE(:TWO_SC, ''BDR_SMART'') || ''.SHIP_PERSON_XREF'';

V_F_PREM_TRANS_MO VARCHAR := :DB_NAME || ''.'' || COALESCE(:FOUR_SC, ''BDR_DM'') || ''.F_PREM_TRANS_MO'';

V_D_SURCHRG_TIER VARCHAR := :DB_NAME || ''.'' || COALESCE(:FOUR_SC, ''BDR_DM'') || ''.D_SURCHRG_TIER'';

V_D_CERT_ACTV VARCHAR := :DB_NAME || ''.'' || COALESCE(:THREE_SC, ''BDR_CONF'') || ''.D_CERT_ACTV'';

V_D_PLN_BEN_MOD VARCHAR := :DB_NAME || ''.'' || COALESCE(:THREE_SC, ''BDR_CONF'') || ''.D_PLN_BEN_MOD'';

V_D_ACQN_CHNL VARCHAR := :DB_NAME || ''.'' || COALESCE(:THREE_SC, ''BDR_CONF'') || ''.D_ACQN_CHNL'';

V_D_MBR_INFO_TEST VARCHAR := :DB_NAME || ''.'' || COALESCE(:THREE_SC, ''BDR_CONF'') || ''.D_MBR_INFO'';

V_D_AGT VARCHAR := :DB_NAME || ''.'' || COALESCE(:THREE_SC, ''BDR_CONF'') || ''.D_AGT'';--changed

BEGIN


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP1'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_MA_SALES'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


use secondary roles all ;
create or replace table IDENTIFIER(:V_AGENT_QUALITY_MA_SALES) COPY GRANTS AS  
select distinct pty_id,
person_id,
indvdl_id,
appl_id_cd,
PLAN_EFF_DT,
a.broker_id_cd,
APPL_DT,
ADJUDICATION_DT,
substr(stfips,1,2) as st_cd,
add_months(plan_eff_dt,-1) as PLAN_EFF_DT_prev,
(case when d.medicare_hicn_cd is not null then d.MBI else a.medicare_hicn_cd end) as MBI_FINAL
from (select * from IDENTIFIER(:V_ALL_APPS_FEDERAL) 
where PRODUCT_SEGMENTS in (''MA INDIVIDUAL'',''M&R SNP'')
and broker_id_cd is not null
and (PLAN_EFF_DT between ''2015-01-01'' and to_date(concat(lpad(year(current_date),4,0),''-'',lpad(month(current_date),2,0),''-01'')))
and STATUS in (''NEW'',''WINBACK'') 
and ADJUDICATION_STAT_CD = 1) a
inner join(select distinct pty_id_final as PTY_ID, agt_id_final as broker_id_cd
from IDENTIFIER(:V_ISDW_EFF_SALES_DASHBOARD)
where marketing_channel_final in (''Agent'')) b 
on a.broker_id_cd = b.broker_id_cd
left join IDENTIFIER(:V_CMDB_PERSON_XREF_INTERFACE) c on
a.indvdl_id = c.CMDB_PERSON_ID
left join IDENTIFIER(:V_CMS_HICN_TO_MBI_CROSSWALK) d
on a.medicare_hicn_cd=d.medicare_hicn_cd 
order by pty_id,
person_id,
indvdl_id,
PLAN_EFF_DT,
APPL_DT,
ADJUDICATION_DT,
APPL_ID_CD ; 

		V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_MA_SALES)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP2'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_MA_SALES_2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

										   
							  
create or replace table IDENTIFIER(:V_AGENT_QUALITY_MA_SALES_2) COPY GRANTS AS  
select *, year(PLAN_EFF_DT_prev)*100+month(PLAN_EFF_DT_prev) as PLAN_EFF_DT_prev1
from   IDENTIFIER(:V_AGENT_QUALITY_MA_SALES)
order by person_id, PLAN_EFF_DT, APPL_DT, ADJUDICATION_DT,  APPL_ID_CD; 

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_MA_SALES_2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP3'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_MA_SALES_V1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

										   
									   
create or replace table IDENTIFIER(:V_AGENT_QUALITY_MA_SALES_V1) COPY GRANTS AS  
select * from 
(
select * ,
ROW_NUMBER() over(partition by mbi_final, PLAN_EFF_DT order by APPL_DT desc, ADJUDICATION_DT desc,  APPL_ID_CD desc) as rownumber
from IDENTIFIER(:V_AGENT_QUALITY_MA_SALES_2))  v
where v.rownumber = 1; 

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_MA_SALES_V1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP4'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_MS_MA_SALES'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

										   
			use secondary roles all ;						   
create or replace table IDENTIFIER(:V_AGENT_QUALITY_MS_MA_SALES) COPY GRANTS AS  
select a.prem_due_mo_id,
a.person_id as pers_id,
a.CERT_EFF_MO_ID,
a.CERT_TRM_MO_ID,
a.PRDCT_EFF_MO_ID,
a.CERT_ACTV_LVL_1_TXT,
a.CERT_ACTV_LVL_2_TXT,
b.INDVDL_ID,
b.appl_id_cd,
b.PLAN_EFF_DT,
b.broker_id_cd,
b.pty_id as ma_pty_id,
b.st_cd,b.PLAN_EFF_DT_prev,b.PLAN_EFF_DT_prev1,
a.pty_id as ms_pty_id,
a.ACQN_CHNL_LVL_1 as prdct_ACQN_CHNL_LVL_1,
a.rt_dtrm_cd_desc,
a.mbi_final,
term from
(
select a11.prem_due_mo_id,
a31.person_id,
a11.CERT_EFF_MO_ID,
a11.CERT_TRM_MO_ID,
a11.PRDCT_EFF_MO_ID,
a12.CERT_ACTV_LVL_1_TXT,
a12.CERT_ACTV_LVL_2_TXT,
a29.pty_id,
a14.ACQN_CHNL_LVL_1,
a30.rt_dtrm_cd_desc,
(case when b.medicare_hicn_cd is not null then b.MBI else a27.MEDCR_CLM_NBR end) as MBI_FINAL,
sum(a11.TERM_CERT_QTY) as term 
from IDENTIFIER(:V_F_PREM_TRANS_MO) a11             
left join IDENTIFIER(:V_D_CERT_ACTV) a12 on a11.D_CERT_ACTV_SK = a12.D_CERT_ACTV_SK
left join IDENTIFIER(:V_D_PLN_BEN_MOD) a13 on a11.D_PLN_BEN_MOD_SK = a13.D_PLN_BEN_MOD_SK
left join IDENTIFIER(:V_D_ACQN_CHNL) a14 on a11.PRDCT_D_ACQN_CHNL_SK = a14.D_ACQN_CHNL_SK
left join IDENTIFIER(:V_D_MBR_INFO_TEST) a27 on a11.d_mbr_info_sk = a27.d_mbr_info_sk  
left join IDENTIFIER(:V_SHIP_PERSON_XREF) a31 on a27.INDV_ID = a31.SHIP_PERSON_ID
left join IDENTIFIER(:V_D_AGT) as a29 on a11.agt_sel_orig_d_agt_sk = a29.d_agt_sk
left join IDENTIFIER(:V_D_SURCHRG_TIER) as a30 on a11.D_SURCHRG_TIER_sk = a30.D_SURCHRG_TIER_sk
left join IDENTIFIER(:V_CMS_HICN_TO_MBI_CROSSWALK) b on a27.MEDCR_CLM_NBR = b.medicare_hicn_cd 
where a13.PRDCT_SUB_GRP in (''Med Supp Base'') 
and a12.CERT_ACTV_LVL_1_TXT  in (''PLAN TERM (TERM DT GT EFF DT)'')
and a12.CERT_ACTV_LVL_2_TXT not in (''PLAN TERM (TERM DT GT EFF DT)-PLAN CHANGE'') 

group by 
a11.prem_due_mo_id,
a31.person_id,
a11.CERT_EFF_MO_ID,
a11.CERT_TRM_MO_ID,
a11.PRDCT_EFF_MO_ID,
a12.CERT_ACTV_LVL_1_TXT,
a12.CERT_ACTV_LVL_2_TXT,
a29.pty_id,
a14.ACQN_CHNL_LVL_1,
a30.rt_dtrm_cd_desc,
(case when b.medicare_hicn_cd is not null then b.MBI else a27.MEDCR_CLM_NBR end)
having ( sum(a11.TERM_CERT_QTY) >0)
) a
inner join IDENTIFIER(:V_AGENT_QUALITY_MA_SALES_V1) b on a.mbi_final = b.mbi_final 
where (b.PLAN_EFF_DT_prev1  between a.PRDCT_EFF_MO_ID  and  a.prem_due_mo_id);

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_MS_MA_SALES)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP5'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_MS_MA_SALES_2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

										   
										 
create or replace table IDENTIFIER(:V_AGENT_QUALITY_MS_MA_SALES_2) COPY GRANTS AS  
select * from  IDENTIFIER(:V_AGENT_QUALITY_MS_MA_SALES)
order by  pers_id ,  PLAN_EFF_DT,  PRDCT_EFF_MO_ID desc, prem_due_mo_id;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_MS_MA_SALES_2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP6'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_MS_MA_SALES_V1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

										   
										  
create or replace table IDENTIFIER(:V_AGENT_QUALITY_MS_MA_SALES_V1) COPY GRANTS AS  
select prem_due_mo_id, pers_id, cert_eff_mo_id, 
cert_trm_mo_id, prdct_eff_mo_id, cert_actv_lvl_1_txt, cert_actv_lvl_2_txt, indvdl_id,appl_id_cd,
plan_eff_dt, broker_id_cd, ma_pty_id, st_cd, plan_eff_dt_prev,
plan_eff_dt_prev1, ms_pty_id, prdct_acqn_chnl_lvl_1, rt_dtrm_cd_desc, term 
from(
select *,
row_number() over (partition by pers_id ,  PLAN_EFF_DT order by PRDCT_EFF_MO_ID desc, prem_due_mo_id) as rownumber
from IDENTIFIER(:V_AGENT_QUALITY_MS_MA_SALES_2)
) v
where v.rownumber = 1; 

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_MS_MA_SALES_V1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP7'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_MS_MA_SALES_V2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

										   

create or replace table IDENTIFIER(:V_AGENT_QUALITY_MS_MA_SALES_V2) COPY GRANTS AS  
select distinct prem_due_mo_id, pers_id, cert_eff_mo_id, 
cert_trm_mo_id, prdct_eff_mo_id, cert_actv_lvl_1_txt, cert_actv_lvl_2_txt, indvdl_id,appl_id_cd,
plan_eff_dt, broker_id_cd, ma_pty_id, st_cd, plan_eff_dt_prev,
plan_eff_dt_prev1, ms_pty_id, prdct_acqn_chnl_lvl_1, rt_dtrm_cd_desc, term , Was_Already_member ,
flag_state from(
select * from (
Select a.*, b.mbr_plan_eff_dt , b.dsenrl_dt, 
(case when b.INDVDL_ID is not null then 1 else 0 end) as Was_Already_member,
(case when a.st_cd = b.ST_CD then 1 else 0 end) as flag_state
from IDENTIFIER(:V_AGENT_QUALITY_MS_MA_SALES_V1) a left join IDENTIFIER(:V_FED_MEMBERS) b
on a.INDVDL_ID = b.INDVDL_ID and 
(b.mbr_plan_eff_dt)<= a.PLAN_EFF_DT_prev and
((b.dsenrl_dt) >= a.PLAN_EFF_DT_prev or (b.dsenrl_dt) IS NULL)
and(b.sh_mbr_fg = ''Y'' or b.evc_mbr_fg = ''Y'') and
b.lob_id not in (10, 911) and
b.plan_cat_nm <> ''MED SUPP'' and (b.mbr_plan_eff_dt) <> COALESCE ((b.dsenrl_dt), ''2099-01-01'')) v
order by pers_id, PLAN_EFF_DT,
flag_state desc, mbr_plan_eff_dt desc, dsenrl_dt) b ; 

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_MS_MA_SALES_V2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP8'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_MS_MA_SALES_V3'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

										   
										  
create or replace table IDENTIFIER(:V_AGENT_QUALITY_MS_MA_SALES_V3) COPY GRANTS AS  
select distinct prem_due_mo_id, pers_id, cert_eff_mo_id, 
cert_trm_mo_id, prdct_eff_mo_id, cert_actv_lvl_1_txt, cert_actv_lvl_2_txt, indvdl_id,appl_id_cd,
plan_eff_dt, broker_id_cd, ma_pty_id, st_cd, plan_eff_dt_prev,
plan_eff_dt_prev1, ms_pty_id, prdct_acqn_chnl_lvl_1, rt_dtrm_cd_desc, term , Was_Already_member ,
flag_state, Was_member_at_eff from
(Select a.*, b.mbr_plan_eff_dt ,b.dsenrl_dt,
(case when b.INDVDL_ID is not null then 1 else 0 end) as Was_member_at_eff
from IDENTIFIER(:V_AGENT_QUALITY_MS_MA_SALES_V2) a
left join IDENTIFIER(:V_FED_MEMBERS) b 
on a.INDVDL_ID = b.INDVDL_ID and 
b.mbr_plan_eff_dt <= a.PLAN_EFF_DT and 
((b.dsenrl_dt) > a.PLAN_EFF_DT or b.dsenrl_dt is null)
and
(b.sh_mbr_fg = ''Y'' or b.evc_mbr_fg = ''Y'') and
b.lob_id not in (10, 911) and
b.plan_cat_nm <> ''MED SUPP'' and
(b.mbr_plan_eff_dt) <> COALESCE ((b.dsenrl_dt),''2099-01-01'')
order by a.pers_id,a.PLAN_EFF_DT,
 a.flag_state desc,b.mbr_plan_eff_dt desc,b.dsenrl_dt ) v; 

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_MS_MA_SALES_V3)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP9'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_MS_MA_SALES_V4'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_AGENT_QUALITY_MS_MA_SALES_V4) COPY GRANTS AS  
select  a.*,
months_between(to_date(cast(concat((lpad((prem_due_mo_id/100),4,0)),''-'',(lpad(prem_due_mo_id-substr(prem_due_mo_id,1,4)::number(38,0)*100,2,0)),''-01'') as string)), a.PLAN_EFF_DT) as Months_diff,
b.agent_level_name,
b.nma_agent_id,b.nma_party_id,
b.smo_agent_id,b.smo_party_id,--changes
b.fmo_agent_id,b.fmo_party_id,
b.mga_agent_id,b.mga_party_id,b.ga_agent_id,
b.ga_party_id,b.agent_ica_agent_id,
b.agent_ica_party_id,b.solicitor_agent_id,b.solicitor_party_id
,principalparty_id,COALESCE(principalparty_id,ma_pty_id) as principalparty_id_final
from IDENTIFIER(:V_AGENT_QUALITY_MS_MA_SALES_V3) a
left join IDENTIFIER(:V_AGENT_QUALITY_FED_HIERARCHY_FINAL) b
on a.plan_eff_dt = b.plan_eff_dt and a.broker_id_cd = b.broker_id_cd
and a.appl_id_cd = b.appl_id_cd
left join IDENTIFIER(:V_AGENT_QUALITY_PRINCIPAL_ORG_2) c 
on a.ma_pty_id = c.org_party_id and ((year(a.plan_eff_dt)*100+month(a.plan_eff_dt)) between c.startdate_yearmon and c.enddate_yearmon); 

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_MS_MA_SALES_V4)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP10'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_SWITCHERS_MS_MA'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

										   
										   
create or replace table IDENTIFIER(:V_AGENT_QUALITY_SWITCHERS_MS_MA) COPY GRANTS AS  
select ma_pty_id,principalparty_id_final,st_cd,year(PLAN_EFF_DT) as Year,broker_id_cd,
rt_dtrm_cd_desc,
agent_level_name,
nma_agent_id,
nma_party_id,
smo_agent_id,
smo_party_id,-- --changes

fmo_agent_id,
fmo_party_id,
mga_agent_id,
mga_party_id,
ga_agent_id,
ga_party_id,
agent_ica_agent_id,
agent_ica_party_id,
solicitor_agent_id,
solicitor_party_id,
count(*) as MS_MA_Switchers,
count(case when prdct_ACQN_CHNL_LVL_1 = ''Agent'' then pers_id end) as MS_MA_Switchers_Agent,
count(case when prdct_ACQN_CHNL_LVL_1 in (''DTC'',''UNKNOWN'') then pers_id end) as MS_MA_Switchers_DTC,
count(case when prdct_ACQN_CHNL_LVL_1 not in (''Agent'',''DTC'',''UNKNOWN'') then pers_id end) as MS_MA_Switchers_OTHERS,
count(case when ma_pty_id = ms_pty_id then pers_id end) as MS_MA_Switchers_same_pty_id,

count(case when month(PLAN_EFF_DT) = 01 then pers_id end) as tot_aep_MS_MA_Switchers,
count(case when prdct_ACQN_CHNL_LVL_1 = ''Agent'' and month(PLAN_EFF_DT) = 01 then pers_id end) as tot_aep_MS_MA_Swth_Agent,
count(case when prdct_ACQN_CHNL_LVL_1 in (''DTC'',''UNKNOWN'') and month(PLAN_EFF_DT) = 01 then pers_id end) as tot_aep_MS_MA_Swth_DTC,
count(case when prdct_ACQN_CHNL_LVL_1 not in (''Agent'',''DTC'',''UNKNOWN'') and month(PLAN_EFF_DT) = 01 then pers_id end) as tot_aep_MS_MA_Swth_OTHERS,
count(case when ma_pty_id = ms_pty_id and month(PLAN_EFF_DT) = 01 then pers_id end) as tot_aep_MS_MA_Swth_same_pty_id,

count(case when month(PLAN_EFF_DT) <= (concat(lpad(year(current_date),4,0),lpad(month(current_date),2,0))-(concat(lpad(year(current_date),4,0),lpad(month(current_date),2,0))/100)*100) then pers_id end) as tot_same_mo_MS_MA_Switchers,
count(case when prdct_ACQN_CHNL_LVL_1 = ''Agent'' and month(PLAN_EFF_DT) <= (concat(lpad(year(current_date),4,0),lpad(month(current_date),2,0))-(concat(lpad(year(current_date),4,0),lpad(month(current_date),2,0))/100)*100) then pers_id end) as tot_same_mo_MS_MA_Swth_Agent,
count(case when prdct_ACQN_CHNL_LVL_1 in (''DTC'',''UNKNOWN'') and month(PLAN_EFF_DT) <= (concat(lpad(year(current_date),4,0),lpad(month(current_date),2,0))-(concat(lpad(year(current_date),4,0),lpad(month(current_date),2,0))/100)*100) then pers_id end) as tot_same_mo_MS_MA_Swth_DTC,
count(case when prdct_ACQN_CHNL_LVL_1 not in (''Agent'',''DTC'',''UNKNOWN'') and month(PLAN_EFF_DT) <= (concat(lpad(year(current_date),4,0),lpad(month(current_date),2,0))-(concat(lpad(year(current_date),4,0),lpad(month(current_date),2,0))/100)*100) then pers_id end) as tot_same_mo_MS_MA_Swth_OTHERS,
count(case when ma_pty_id = ms_pty_id and month(PLAN_EFF_DT) <= (concat(lpad(year(current_date),4,0),lpad(month(current_date),2,0))-(concat(lpad(year(current_date),4,0),lpad(month(current_date),2,0))/100)*100) then pers_id end) as tot_sm_mo_MS_MA_Swth_sm_pty_id

from IDENTIFIER(:V_AGENT_QUALITY_MS_MA_SALES_V4) 
where Months_diff in (-1,0,1) and Was_member_at_eff = 1 and Was_Already_member = 0
group by ma_pty_id,principalparty_id_final,st_cd,year(PLAN_EFF_DT),rt_dtrm_cd_desc,broker_id_cd,
agent_level_name,
nma_agent_id,
nma_party_id,
smo_agent_id,
smo_party_id,--changes

fmo_agent_id,
fmo_party_id,
mga_agent_id,
mga_party_id,
ga_agent_id,
ga_party_id,
agent_ica_agent_id,
agent_ica_party_id,
solicitor_agent_id,
solicitor_party_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_SWITCHERS_MS_MA)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);


RAISE;

END;

';