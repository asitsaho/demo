USE SCHEMA BDR_FFP_DA;

CREATE OR REPLACE PROCEDURE SP_DRIVE_TO_DIGITAL("PIPELINE_ID" VARCHAR(16777216), "PIPELINE_NAME" VARCHAR(16777216), "DB_NAME" VARCHAR(16777216), "UTIL_SC" VARCHAR(16777216), "TGT_SC" VARCHAR(16777216), "FFP_WRK_SC" VARCHAR(16777216), "BDR_SMART_SC" VARCHAR(16777216), "BDR_CONF_SC" VARCHAR(16777216), "WH" VARCHAR(16777216), "STAGE_NAME" VARCHAR(16777216), "CURR_DATE" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

V_CURRENT_DATE   DATE := COALESCE(TO_DATE(:CURR_DATE), CURRENT_DATE());

V_REPORT_DATE DATE := COALESCE(TO_DATE(:CURR_DATE), CURRENT_DATE());

V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := :DB_NAME||''.''||COALESCE(:UTIL_SC, ''UTIL'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';

V_PROCESS_NAME   VARCHAR DEFAULT ''DRIVE_TO_DIGITAL'';

V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''DRIVE_TO_DIGITAL'';

V_STEP             VARCHAR;

V_STEP_NAME        VARCHAR;

V_FILE_QUERY       VARCHAR;

V_START_TIME       VARCHAR;

V_END_TIME         VARCHAR;

V_ROWS_PARSED       INTEGER;

V_ROWS_LOADED       INTEGER;

V_MESSAGE          VARCHAR;

V_LAST_QUERY_ID    VARCHAR;

V_PORTAL_REGISTRATION VARCHAR := :DB_NAME || ''.'' || COALESCE(:BDR_SMART_SC, ''BDR_SMART'') || ''.PORTAL_REGISTRATION'';
V_RTO_RESPONSE_HISTORY VARCHAR := :DB_NAME || ''.'' || COALESCE(:BDR_SMART_SC, ''BDR_SMART'') || ''.RTO_RESPONSE_HISTORY'';
V_PERSON_CONSOLIDATION VARCHAR := :DB_NAME || ''.'' || COALESCE(:BDR_SMART_SC, ''BDR_SMART'') || ''.PERSON_CONSOLIDATION'';
V_INFORCELR_P_LVL_CLAIM_INFO VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.INFORCELR_P_LVL_CLAIM_INFO'';
V_D_MBR_INFO VARCHAR := :DB_NAME || ''.'' || COALESCE(:BDR_CONF_SC, ''BDR_CONF'') || ''.V_D_MBR_INFO'';


V_DRIVE_TO_DIGITAL1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.DRIVE_TO_DIGITAL1'';
V_DRIVE_TO_DIGITAL_OPP VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.DRIVE_TO_DIGITAL_OPP'';
V_DRIVE_TO_DIGITAL1A VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.DRIVE_TO_DIGITAL1A'';
V_DRIVE_TO_DIGITAL2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.DRIVE_TO_DIGITAL2'';
V_DRIVE_TO_DIGITAL3 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.DRIVE_TO_DIGITAL3'';
V_DRIVE_TO_DIGITAL4 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.DRIVE_TO_DIGITAL4'';
V_D2D_TOTAL_OPPORTUNITIES_WEEK VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.D2D_TOTAL_OPPORTUNITIES_WEEK'';
V_D2D_DIGITAL_INTERACTIONS_WEEK VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.D2D_DIGITAL_INTERACTIONS_WEEK'';
V_D2D_DIGITAL_INTERACTIONS_2_DAYS_WEEK VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.D2D_DIGITAL_INTERACTIONS_2_DAYS_WEEK'';
V_D2D_WEEKLY_REGISTRATIONS_WEEK VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.D2D_WEEKLY_REGISTRATIONS_WEEK'';
V_D2D_DASHBOARD_FINAL_WEEK VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.D2D_DASHBOARD_FINAL_WEEK'';
V_D2D_TOTAL_OPPORTUNITIES_MONTH VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.D2D_TOTAL_OPPORTUNITIES_MONTH'';
V_D2D_DIGITAL_INTERACTIONS_MONTH VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.D2D_DIGITAL_INTERACTIONS_MONTH'';
V_D2D_DIGITAL_INTERACTIONS_2_DAYS_MONTH VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.D2D_DIGITAL_INTERACTIONS_2_DAYS_MONTH'';
V_D2D_WEEKLY_REGISTRATIONS_MONTH VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.D2D_WEEKLY_REGISTRATIONS_MONTH'';
V_D2D_DASHBOARD_FINAL_MONTH VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.D2D_DASHBOARD_FINAL_MONTH'';


BEGIN

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP1'';

V_STEP_NAME :=  ''CREATE TABLE DRIVE_TO_DIGITAL1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


CREATE OR REPLACE TABLE IDENTIFIER(:V_DRIVE_TO_DIGITAL1) AS
SELECT 
    person_id,
    ship_person_id,
    event_name,
    reason,
    response_datetime,
    TO_VARCHAR(TO_DATE(response_datetime), ''YYYY-MM-DD'') AS contact_date,
    CAST(SUBSTRING(date_id, 1, 6) AS INT) AS yearmonth,
    is_session_id
FROM 
    IDENTIFIER(:V_RTO_RESPONSE_HISTORY) rch 
WHERE 
    TO_VARCHAR(TO_DATE(response_datetime), ''YYYY-MM-DD'') >= ''2024-04-26''
    AND TO_VARCHAR(TO_DATE(response_datetime), ''YYYY-MM-DD'') <= (
        SELECT DATEADD(''DAY'', -2, MAX(calculated_web_registration_date)) 
        FROM IDENTIFIER(:V_PORTAL_REGISTRATION)
    )
    AND offer_name = ''PROMOTE MEMBER PORTAL''
    AND event_name IN (''ACCEPT'', ''REJECT'');  

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DRIVE_TO_DIGITAL1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, NULL, NULL, NULL, NULL);


V_STEP := ''STEP2'';

V_STEP_NAME :=  ''CREATE TABLE DRIVE_TO_DIGITAL_OPP'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_DRIVE_TO_DIGITAL_OPP) AS
SELECT 
    person_id,
    ship_person_id,
    event_name,
    reason,
    response_datetime,
    TO_VARCHAR(TO_DATE(response_datetime), ''YYYY-MM-DD'') AS contact_date,
    CAST(SUBSTRING(date_id, 1, 6) AS INT) AS yearmonth,
    is_session_id
FROM 
    IDENTIFIER(:V_RTO_RESPONSE_HISTORY) rch 
WHERE 
    TO_VARCHAR(TO_DATE(response_datetime), ''YYYY-MM-DD'') >= ''2024-04-26''
    AND TO_VARCHAR(TO_DATE(response_datetime), ''YYYY-MM-DD'') <= (
        SELECT DATEADD(''DAY'', -2, MAX(calculated_web_registration_date)) 
        FROM IDENTIFIER(:V_PORTAL_REGISTRATION)
    )
    AND offer_name = ''PROMOTE MEMBER PORTAL'';



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DRIVE_TO_DIGITAL_OPP)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



V_STEP := ''STEP3'';

V_STEP_NAME :=  ''CREATE TABLE DRIVE_TO_DIGITAL1A'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_DRIVE_TO_DIGITAL1A) AS
SELECT 
    a.*, 
    pc.retained_person_id,
    CASE 
        WHEN a.person_id = pc.retained_person_id THEN 1
        ELSE 0
    END AS id_flag
FROM 
    IDENTIFIER(:V_DRIVE_TO_DIGITAL1) a
LEFT JOIN 
    IDENTIFIER(:V_PERSON_CONSOLIDATION) pc
ON 
    a.person_id = pc.merged_person_id;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DRIVE_TO_DIGITAL1A)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



V_STEP := ''STEP4'';

V_STEP_NAME :=  ''create a DRIVE_TO_DIGITAL2 table '';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_DRIVE_TO_DIGITAL2) AS
SELECT 
    a.*, 
    b.calculated_web_registration_date,
    DATEDIFF(day, a.contact_date, b.calculated_web_registration_date) as day_difference,
    CASE 
        WHEN DATEDIFF(day, a.contact_date, b.calculated_web_registration_date) BETWEEN 0 AND 2 THEN ''Registered within 2 days''
        WHEN DATEDIFF(day, a.contact_date, b.calculated_web_registration_date) < 0 THEN ''Registered prior to call''
        WHEN DATEDIFF(day, a.contact_date, b.calculated_web_registration_date) > 2 THEN ''Registered after 2 days''
        ELSE ''No Registration Found''
    END AS registration_flag
FROM 
    IDENTIFIER(:V_DRIVE_TO_DIGITAL1A) a
LEFT JOIN 
    IDENTIFIER(:V_PORTAL_REGISTRATION) b 
ON 
    a.retained_person_id = b.person_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DRIVE_TO_DIGITAL2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP5'';

V_STEP_NAME :=  ''CREATE TABLE DRIVE_TO_DIGITAL3 '';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_DRIVE_TO_DIGITAL3) AS 
SELECT 
    a.*, 
    b.age, 
    b.eft_info, 
    b.email_fg, 
    b.enrollment, 
    b.marketing_channel_final,
    b.undwr_pln_rqr_txt,
    CASE 
        WHEN b.undwr_pln_rqr_txt = ''Default'' THEN ''Default''
        WHEN b.undwr_pln_rqr_txt = ''Not U/W - Open Enrollment'' THEN ''OE''
        WHEN b.undwr_pln_rqr_txt = ''Not U/W - Plan Change'' THEN ''Plan Change''
        WHEN b.undwr_pln_rqr_txt = ''Not U/W - Employer Group'' THEN ''Employer Group''
        WHEN b.undwr_pln_rqr_txt = ''Not U/W Guaranteed Issue Reason not specified'' THEN ''GI''
        WHEN b.undwr_pln_rqr_txt = ''Not U/W - HIP Plan'' THEN ''HIP Plan''
        WHEN b.undwr_pln_rqr_txt = ''Unknown'' THEN ''Unknown''
        WHEN b.undwr_pln_rqr_txt IS NULL THEN NULL
        ELSE ''UW'' 
    END AS UW_new,
    plan,
    pln_lvl,
    CASE 
        WHEN b.prem_due_mo_id IS NULL THEN ''N''
        ELSE ''Y''
    END AS premium_paid_flag,
    sub_channel
FROM 
    IDENTIFIER(:V_DRIVE_TO_DIGITAL2) a
LEFT JOIN 
    IDENTIFIER(:V_INFORCELR_P_LVL_CLAIM_INFO) b
ON 
    a.retained_person_id = b.pers_id 
    AND a.yearmonth = b.prem_due_mo_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DRIVE_TO_DIGITAL3)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								

V_STEP := ''STEP6'';

V_STEP_NAME :=  ''CREATE TABLE DRIVE_TO_DIGITAL4 '';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_DRIVE_TO_DIGITAL4) AS 
SELECT 
    a.*, 
    t2.acct_nbr, 
    t2.name, 
    t2.dob_id, 
    t2.dob_day, 
    CONCAT(SUBSTRING(t2.acct_nbr, 1, 10), t2.dob_day) AS match_id 
FROM  
    IDENTIFIER(:V_DRIVE_TO_DIGITAL3) a
LEFT JOIN (
    SELECT 
        CONCAT(b.fst_nm, '' '', b.lst_nm) AS name, 
        dob_id, 
        SUBSTRING(dob_id, 7, 2) AS dob_day, 
        b.acct_nbr, 
        b.indv_id, 
        ROW_NUMBER() OVER(PARTITION BY b.indv_id ORDER BY b.mbr_info_sk_end_dt DESC) AS RowNo 
    FROM 
        IDENTIFIER(:V_D_MBR_INFO) b
) AS t2 
ON 
    a.ship_person_id = t2.indv_id 
    AND t2.RowNo = 1;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DRIVE_TO_DIGITAL4)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
V_STEP := ''STEP7'';

V_STEP_NAME :=  ''CREATE TABLE D2D_TOTAL_OPPORTUNITIES_WEEK '';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_D2D_TOTAL_OPPORTUNITIES_WEEK) AS 
SELECT 
    DATEADD(day, - (DAYOFWEEKISO(TO_DATE(contact_date))), contact_date) AS week_start_date,
    COUNT(person_id) AS total_opportunities
FROM 
	IDENTIFIER(:V_DRIVE_TO_DIGITAL_OPP)
GROUP BY 
    DATEADD(day, - (DAYOFWEEKISO(TO_DATE(contact_date))), contact_date) 
ORDER BY 
    week_start_date;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_D2D_TOTAL_OPPORTUNITIES_WEEK)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP8'';

V_STEP_NAME :=  ''CREATE TABLE D2D_DIGITAL_INTERACTIONS_WEEK '';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_D2D_DIGITAL_INTERACTIONS_WEEK) AS 
SELECT 
    DATEADD(day, - (DAYOFWEEK(TO_DATE(contact_date))), contact_date) AS week_start_date,
    COUNT(*) AS digital_assistance_interactions
FROM 
	IDENTIFIER(:V_DRIVE_TO_DIGITAL3) dtd 
GROUP BY 
    DATEADD(day, - (DAYOFWEEK(TO_DATE(contact_date))), contact_date)
ORDER BY 
    week_start_date;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_D2D_DIGITAL_INTERACTIONS_WEEK)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
								
V_STEP := ''STEP9'';

V_STEP_NAME :=  ''CREATE TABLE D2D_DIGITAL_INTERACTIONS_2_DAYS_WEEK '';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_D2D_DIGITAL_INTERACTIONS_2_DAYS_WEEK) AS 
SELECT 
    DATEADD(day, - (DAYOFWEEK(TO_DATE(contact_date))), TO_DATE(contact_date)) AS week_start_date,
    COUNT(person_id) AS online_registrations_2_days
FROM 
	IDENTIFIER(:V_DRIVE_TO_DIGITAL3)
GROUP BY 
    DATEADD(day, - (DAYOFWEEK(TO_DATE(contact_date))), TO_DATE(contact_date)), 
    registration_flag
HAVING 
    registration_flag = ''Registered within 2 days''
ORDER BY 
    week_start_date;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_D2D_DIGITAL_INTERACTIONS_2_DAYS_WEEK)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP10'';

V_STEP_NAME :=  ''CREATE TABLE D2D_WEEKLY_REGISTRATIONS_WEEK '';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_D2D_WEEKLY_REGISTRATIONS_WEEK) AS 
SELECT 
    DATEADD(day, - (DAYOFWEEK(TO_DATE(calculated_web_registration_date))), TO_DATE(calculated_web_registration_date)) AS week_start_date,
    COUNT(person_id) AS total_online_registrations
FROM 
    IDENTIFIER(:V_PORTAL_REGISTRATION)
WHERE 
    calculated_web_registration_date >= ''2024-04-26''
GROUP BY 
    DATEADD(day, - (DAYOFWEEK(TO_DATE(calculated_web_registration_date))), TO_DATE(calculated_web_registration_date))
ORDER BY 
    week_start_date;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_D2D_WEEKLY_REGISTRATIONS_WEEK)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
								
V_STEP := ''STEP11'';

V_STEP_NAME :=  ''CREATE TABLE D2D_DASHBOARD_FINAL_WEEK '';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_D2D_DASHBOARD_FINAL_WEEK) AS 
SELECT 
    a.*,
    ab.digital_assistance_interactions,
    (ab.digital_assistance_interactions / a.total_opportunities) AS Percent_delivered,
    b.online_registrations_2_days,
    (b.online_registrations_2_days / ab.digital_assistance_interactions) AS registration_rate_2_days,
    c.total_online_registrations,
    (b.online_registrations_2_days / c.total_online_registrations) AS total_online_registrations_rate
FROM 
    IDENTIFIER(:V_D2D_TOTAL_OPPORTUNITIES_WEEK)a
LEFT JOIN 
    IDENTIFIER(:V_D2D_DIGITAL_INTERACTIONS_WEEK) ab
    ON a.week_start_date = ab.week_start_date
LEFT JOIN 
    IDENTIFIER(:V_D2D_DIGITAL_INTERACTIONS_2_DAYS_WEEK) b
    ON a.week_start_date = b.week_start_date
LEFT JOIN 
    IDENTIFIER(:V_D2D_WEEKLY_REGISTRATIONS_WEEK) c
    ON a.week_start_date = c.week_start_date
ORDER BY 
    a.week_start_date;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_D2D_DASHBOARD_FINAL_WEEK)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								

								
V_STEP := ''STEP12'';

V_STEP_NAME :=  ''CREATE TABLE D2D_TOTAL_OPPORTUNITIES_MONTH '';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_D2D_TOTAL_OPPORTUNITIES_MONTH) AS 
SELECT 
    SUBSTR(contact_date,1,7) AS year_month,
    COUNT(person_id) AS total_opportunities
FROM 
    IDENTIFIER(:V_DRIVE_TO_DIGITAL_OPP)
GROUP BY 
    SUBSTR(contact_date,1,7)
ORDER BY 
    year_month;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_D2D_TOTAL_OPPORTUNITIES_MONTH)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



V_STEP := ''STEP13'';

V_STEP_NAME :=  ''CREATE TABLE D2D_DIGITAL_INTERACTIONS_MONTH '';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_D2D_DIGITAL_INTERACTIONS_MONTH) AS 
SELECT 
    SUBSTR(contact_date,1,7) AS year_month
    ,count(*) as digital_assistance_interactions
FROM 
    IDENTIFIER(:V_DRIVE_TO_DIGITAL3) dtd 
GROUP BY 
    SUBSTR(contact_date,1,7)
ORDER BY 
    year_month;;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_D2D_DIGITAL_INTERACTIONS_MONTH)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP14'';

V_STEP_NAME :=  ''CREATE TABLE D2D_DIGITAL_INTERACTIONS_2_DAYS_MONTH '';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_D2D_DIGITAL_INTERACTIONS_2_DAYS_MONTH) AS 
SELECT 
    SUBSTR(contact_date,1,7) AS year_month
    , COUNT(person_id) as online_registrations_2_days
FROM 
    IDENTIFIER(:V_DRIVE_TO_DIGITAL3)
GROUP BY 
    SUBSTR(contact_date,1,7), registration_flag
HAVING 
    registration_flag = ''Registered within 2 days''
ORDER BY year_month;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_D2D_DIGITAL_INTERACTIONS_2_DAYS_MONTH)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								

V_STEP := ''STEP15'';

V_STEP_NAME :=  ''CREATE TABLE D2D_WEEKLY_REGISTRATIONS_MONTH '';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_D2D_WEEKLY_REGISTRATIONS_MONTH) AS 
SELECT 
    SUBSTRING(calculated_web_registration_date,1,7) AS year_month
    , COUNT(person_id) as total_online_registrations
FROM 
    IDENTIFIER(:V_PORTAL_REGISTRATION)
where 
    calculated_web_registration_date >= ''2024-04-26''
GROUP BY 
    SUBSTRING(calculated_web_registration_date,1,7)
ORDER BY 
    year_month;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_D2D_WEEKLY_REGISTRATIONS_MONTH)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP16'';

V_STEP_NAME :=  ''CREATE TABLE D2D_DASHBOARD_FINAL_MONTH '';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_D2D_DASHBOARD_FINAL_MONTH) AS 
SELECT 
    a.*
    , ab.digital_assistance_interactions
    , (ab.digital_assistance_interactions/a.total_opportunities) AS Percent_delivered
    , b.online_registrations_2_days
    , (b.online_registrations_2_days/ab.digital_assistance_interactions) AS registration_rate_2_days
    ,c.total_online_registrations
    ,(b.online_registrations_2_days/c.total_online_registrations) AS total_online_registrations_rate
FROM 
    IDENTIFIER(:V_D2D_TOTAL_OPPORTUNITIES_MONTH) a
LEFT JOIN 
    IDENTIFIER(:V_D2D_DIGITAL_INTERACTIONS_MONTH) ab
ON 
    a.year_month = ab.year_month
LEFT JOIN 
    IDENTIFIER(:V_D2D_DIGITAL_INTERACTIONS_2_DAYS_MONTH) b
ON 
    a.year_month = b.year_month
LEFT JOIN 
    IDENTIFIER(:V_D2D_WEEKLY_REGISTRATIONS_MONTH) c
ON 
    a.year_month = c.year_month
ORDER BY 
    a.year_month
;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_D2D_DASHBOARD_FINAL_MONTH)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_FILE_QUERY := ''COPY INTO ''||''@UTIL.STAGE_AZURE_ISDC/analytics/outbox/drive_to_digital/drive_to_digital_qc_''||:V_CURRENT_DATE||''.csv''||'' FROM (
           SELECT DISTINCT
				SUBSTRING(CALCULATED_WEB_REGISTRATION_DATE,1,10) as yyyymm,
				ROW_INS_TIMESTAMP
			FROM
				BDR_SMART.PORTAL_REGISTRATION
			WHERE 
				ROW_INS_TIMESTAMP between DATEADD(MONTH, -1, DATE_TRUNC(MONTH, CURRENT_DATE())) and CURRENT_DATE()
			ORDER BY 
				yyyymm DESC
               )
file_format = (type = ''''CSV'''' 
               field_delimiter = '''',''''
               record_delimiter = ''''
''''
               compression = None 
               FIELD_OPTIONALLY_ENCLOSED_BY=''''"''''
              )
HEADER = True
OVERWRITE = True
MAX_FILE_SIZE = 4900000000
SINGLE = True''
;

EXECUTE IMMEDIATE  :V_FILE_QUERY;


EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);


RAISE;

END;

';