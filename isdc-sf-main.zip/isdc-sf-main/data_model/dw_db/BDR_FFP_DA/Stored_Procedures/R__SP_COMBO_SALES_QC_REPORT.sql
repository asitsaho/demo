
USE SCHEMA BDR_FFP_DA;

CREATE OR REPLACE PROCEDURE "BDR_FFP_DA"."SP_COMBO_SALES_QC_REPORT"("PIPELINE_ID" VARCHAR(16777216), "PIPELINE_NAME" VARCHAR(16777216), "DB_NAME" VARCHAR(16777216), "UTIL_SC" VARCHAR(16777216), "TGT_SC" VARCHAR(16777216),"WH" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE

V_CURRENT_DATE   VARCHAR := (SELECT CURRENT_DATE());


V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := :DB_NAME||'.'||COALESCE(:UTIL_SC, 'UTIL')||'.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS';

V_PROCESS_NAME   VARCHAR DEFAULT 'COMBO_SALES_QC_REPORT';

V_SUB_PROCESS_NAME  VARCHAR DEFAULT 'COMBO_SALES_QC_REPORT';

V_STEP             VARCHAR;

V_STEP_NAME        VARCHAR;

V_START_TIME       VARCHAR;

V_END_TIME         VARCHAR;

V_ROWS_PARSED       INTEGER;

V_ROWS_LOADED       INTEGER;

V_MESSAGE          VARCHAR;

V_LAST_QUERY_ID    VARCHAR;

V_FILE_QUERY VARCHAR;

V_ACTUAL_FILE_NAME VARCHAR;

--QC Table

BEGIN

EXECUTE IMMEDIATE 'USE WAREHOUSE '||:WH;

ALTER SESSION SET TIMEZONE = 'America/Chicago';

V_STEP := 'STEP1';

V_STEP_NAME :=  'Blob File Creation';
   
V_START_TIME := CONVERT_TIMEZONE('America/Chicago', CURRENT_TIMESTAMP());


V_FILE_QUERY := 'COPY INTO '||'@UTIL.STAGE_AZURE_ISDC/analytics/outbox/ms_pdp_combo_sales/curr_month_summ_ms_' ||(SELECT CURRENT_DATE())||'.csv'||' FROM (
           select * from BDR_FFP_DA.COMBOSALES_CURR_MONTH_SUMM_MS
               )
file_format = (type = ''CSV'' 
               field_delimiter = '',''
               record_delimiter = ''\n''
               compression = None 
               FIELD_OPTIONALLY_ENCLOSED_BY=''"''
              )
HEADER = True
OVERWRITE = True
MAX_FILE_SIZE = 4900000000
SINGLE = True'
;

execute immediate  :V_FILE_QUERY;


V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, 'DEEP_PROCESS', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), 'SUCCESS', :V_LAST_QUERY_ID, :V_ROWS_PARSED,NULL, NULL, NULL, NULL);



V_FILE_QUERY := 'COPY INTO '||'@UTIL.STAGE_AZURE_ISDC/analytics/outbox/ms_pdp_combo_sales/curr_month_summ_pdp_' ||(SELECT CURRENT_DATE())||'.csv'||' FROM (
           select * from BDR_FFP_DA.COMBOSALES_CURR_MONTH_SUMM_PDP
               )
file_format = (type = ''CSV'' 
               field_delimiter = '',''
               record_delimiter = ''\n''
               compression = None 
               FIELD_OPTIONALLY_ENCLOSED_BY=''"''
              )
HEADER = True
OVERWRITE = True
MAX_FILE_SIZE = 4900000000
SINGLE = True'
;

execute immediate  :V_FILE_QUERY;


V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, 'DEEP_PROCESS', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), 'SUCCESS', :V_LAST_QUERY_ID, :V_ROWS_PARSED,NULL, NULL, NULL, NULL);



V_FILE_QUERY := 'COPY INTO '||'@UTIL.STAGE_AZURE_ISDC/analytics/outbox/ms_pdp_combo_sales/curr_ms_sales_qc_' ||(SELECT CURRENT_DATE())||'.csv'||' FROM (
           select * from BDR_FFP_DA_WRK.COMBOSALES_MS_SALES_QC
               )
file_format = (type = ''CSV'' 
               field_delimiter = '',''
               record_delimiter = ''\n''
               compression = None 
               FIELD_OPTIONALLY_ENCLOSED_BY=''"''
              )
HEADER = True
OVERWRITE = True
MAX_FILE_SIZE = 4900000000
SINGLE = True'
;

execute immediate  :V_FILE_QUERY;


V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, 'DEEP_PROCESS', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), 'SUCCESS', :V_LAST_QUERY_ID, :V_ROWS_PARSED,NULL, NULL, NULL, NULL);

V_FILE_QUERY := 'COPY INTO '||'@UTIL.STAGE_AZURE_ISDC/analytics/outbox/ms_pdp_combo_sales/curr_pd_sales_qc_' ||(SELECT CURRENT_DATE())||'.csv'||' FROM (
           select * from BDR_FFP_DA_WRK.COMBOSALES_PDP_SALES_QC
               )
file_format = (type = ''CSV'' 
               field_delimiter = '',''
               record_delimiter = ''\n''
               compression = None 
               FIELD_OPTIONALLY_ENCLOSED_BY=''"''
              )
HEADER = True
OVERWRITE = True
MAX_FILE_SIZE = 4900000000
SINGLE = True'
;

execute immediate  :V_FILE_QUERY;


V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, 'DEEP_PROCESS', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), 'SUCCESS', :V_LAST_QUERY_ID, :V_ROWS_PARSED,NULL, NULL, NULL, NULL);



CREATE OR REPLACE TEMPORARY TABLE BDR_FFP_DA_WRK.CHECK_FILES AS SELECT DISTINCT SPLIT_PART(METADATA$FILENAME,'/',-1) AS ACTUAL_FILE_NAME FROM @UTIL.STAGE_AZURE_ISDC/analytics/outbox/ms_pdp_combo_sales/ ;

V_ACTUAL_FILE_NAME := (SELECT COUNT(*) FROM BDR_FFP_DA_WRK.CHECK_FILES);


IF (V_ACTUAL_FILE_NAME >= 4) THEN

V_FILE_QUERY := 'COPY INTO '||'@UTIL.STAGE_AZURE_ISDC/analytics/outbox/ms_pdp_combo_sales/curmonthrcombosales'||'.csv'||' FROM (
           select 1 from DUAL
               )
file_format = (type = ''CSV'' 
               field_delimiter = '',''
               record_delimiter = ''\n''
               compression = None 
               FIELD_OPTIONALLY_ENCLOSED_BY=''"''
              )
HEADER = True
OVERWRITE = True
MAX_FILE_SIZE = 4900000000
SINGLE = True'
;

execute immediate  :V_FILE_QUERY;
END IF; 

EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, 'DEEP_PROCESSES', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), 'FAILED', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);


RAISE;

END;

$$;
