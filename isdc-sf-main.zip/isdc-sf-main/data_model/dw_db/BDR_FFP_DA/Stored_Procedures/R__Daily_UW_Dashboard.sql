--call SP_DAILY_UW_DASHBOARD('1234','DAILY_UW_DASHBOARD','UBLIA_TST_ISDC_DEV_DB','UTIL','BDR_FFP_DA','BDR_FFP_DA_WRK','SRC_APEX','UBLIA_TST_WORK_XS_WH',CURRENT_DATE())

USE SCHEMA BDR_FFP_DA;


CREATE OR REPLACE PROCEDURE "SP_DAILY_UW_DASHBOARD"("PIPELINE_ID" VARCHAR(16777216), "PIPELINE_NAME" VARCHAR(16777216), "DB_NAME" VARCHAR(16777216), "UTIL_SC" VARCHAR(16777216), "TGT_SC" VARCHAR(16777216),"FFP_WRK_SC" VARCHAR(16777216),"SRC_SC" VARCHAR(16777216), "WH" VARCHAR(16777216), "CURR_DATE" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE

V_CURRENT_DATE   DATE := COALESCE(TO_DATE(:CURR_DATE), CURRENT_DATE());

V_REPORT_DATE DATE := COALESCE(TO_DATE(:CURR_DATE), CURRENT_DATE());

V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := :DB_NAME||'.'||COALESCE(:UTIL_SC, 'UTIL')||'.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS';

V_PROCESS_NAME   VARCHAR DEFAULT 'DAILY_UW_DASHBOARD';

V_SUB_PROCESS_NAME  VARCHAR DEFAULT 'DAILY_UW_DASHBOARD';

V_STEP             VARCHAR;

V_STEP_NAME        VARCHAR;

V_START_TIME       VARCHAR;

V_END_TIME         VARCHAR;

V_ROWS_PARSED       INTEGER;

V_ROWS_LOADED       INTEGER;

V_MESSAGE          VARCHAR;

V_LAST_QUERY_ID    VARCHAR;

V_UW_AUDIT_MAIN VARCHAR := :DB_NAME || '.' || COALESCE(:SRC_SC, 'SRC_APEX') || '.UW_AUDIT_MAIN';
V_UW_OUTCOMES VARCHAR := :DB_NAME || '.' || COALESCE(:SRC_SC, 'SRC_APEX') || '.UW_OUTCOMES';
V_UW_OUTCOME_SOURCE VARCHAR := :DB_NAME || '.' || COALESCE(:SRC_SC, 'SRC_APEX') || '.UW_OUTCOME_SOURCE';
V_IN_INQUIRY VARCHAR := :DB_NAME || '.' || COALESCE(:SRC_SC, 'SRC_APEX') || '.IN_INQUIRY';
V_IN_INQ_PROCESS_STEP_VW VARCHAR := :DB_NAME || '.' || COALESCE(:SRC_SC, 'SRC_APEX') || '.IN_INQ_PROCESS_STEP_VW';
V_UW_AGENTS VARCHAR := :DB_NAME || '.' || COALESCE(:SRC_SC, 'SRC_APEX') || '.UW_AGENTS';
V_UW_AUDIT_COND VARCHAR := :DB_NAME || '.' || COALESCE(:SRC_SC, 'SRC_APEX') || '.UW_AUDIT_COND';
V_UW_OUTCOME_REASON VARCHAR := :DB_NAME || '.' || COALESCE(:SRC_SC, 'SRC_APEX') || '.UW_OUTCOME_REASON';


V_DAILY_UW_DB_TABLE1  VARCHAR := :DB_NAME || '.' || COALESCE(:TGT_SC, 'BDR_FFP_DA') || '.DAILY_UW_DB_TABLE1';
V_UW_QUERY2  VARCHAR := :DB_NAME || '.' || COALESCE(:FFP_WRK_SC, 'BDR_FFP_DA_WRK') || '.UW_QUERY2';
V_OUTCOME_REASON2 VARCHAR := :DB_NAME || '.' || COALESCE(:FFP_WRK_SC, 'BDR_FFP_DA_WRK') || '.OUTCOME_REASON2';
V_DAILY_UW_DB_TABLE2 VARCHAR := :DB_NAME || '.' || COALESCE(:TGT_SC, 'BDR_FFP_DA') || '.DAILY_UW_DB_TABLE2';

BEGIN

EXECUTE IMMEDIATE 'USE WAREHOUSE '||:WH;

ALTER SESSION SET TIMEZONE = 'America/Chicago';

V_STEP := 'STEP1';

V_STEP_NAME :=  'create table DAILY_UW_DB_TABLE1';
   
V_START_TIME := CONVERT_TIMEZONE('America/Chicago', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DAILY_UW_DB_TABLE1) COPY GRANTS as 
select
	am.report_date
    ,am.completion_date
	,am.assigned_to
	,am.application_id
	,am.img_number
	,am.medpoint_result
	,am.UW_type
	,am.curr_stage
	,am.Process_step
	,o.uw_outcomes
	,os.uw_outcome_source
	,am.comments
	,am.app_recd_date
	,am.agent_id
	,am.member_number
	,WORKBENCH_UW_TYPE
	,ENTITY
	,COMPAS_UW_TYPE
	,APPLICATION_TYPE
from
	IDENTIFIER(:V_UW_AUDIT_MAIN) am
left join
	IDENTIFIER(:V_UW_OUTCOMES) o
on 	am.outcome = o.id
left join
	IDENTIFIER(:V_UW_OUTCOME_SOURCE) os
on 	os.id = am.outcome_source
where am.report_date >= '2021-01-01'
;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DAILY_UW_DB_TABLE1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, 'DEEP_PROCESS', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), 'SUCCESS', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := 'STEP2';

V_STEP_NAME :=  'create a UW_QUERY2';
   
V_START_TIME := CONVERT_TIMEZONE('America/Chicago', CURRENT_TIMESTAMP());


create or replace temporary table IDENTIFIER(:V_UW_QUERY2) as
select
  i.inquiry_id,
  i.a_id,
  to_date(i.date_received) as inquiry_date,
  cast (null as int ) as inquiry_review_type,
  i.status,
  i.assigned as assigned_to,
  to_date(i.assigned_date) as assigned_date,
  --datediff (day,to_date(i.assigned_date),to_date(i.date_received)) as TAT,
    UTIL.DATE_DIFF_UDF(to_date(i.assigned_date),to_date(i.date_received)) as TAT,
  UTIL.DATE_DIFF_UDF(CURRENT_DATE(),to_date(i.assigned_date)) as age,
  --datediff(day,CURRENT_DATE(),to_date(i.assigned_date)) as age,
  i.inquiry_dcn,
  i.member_number,
  i.first_name,
  i.last_name,
  i.dob,
  i.state,
  case
    when i.agent_id is not null then
      i.agent_id

    when i.agent_of_record is not null then
      i.agent_of_record
  end agent_id,
  i.inquiry_type as inquiry_type,
  i.inquiry_decision as inquiry_decision,
  i.inquiry_source as inquiry_source,
  i.application_dcn as original_application_dcn,
  i.uw_outcome_type as uw_outcome,
  i.uw_outcome_source as uw_source,
  i.uw_type,
  i.plan_code
from (  select 
  i.id as inquiry_id,
  a.id as a_id,
  i.inquiry_dcn as inquiry_dcn,
  a.DCN_Number as application_dcn,
  i.date_received as date_received,
  i.member_number as member_number,
  i.first_name as first_name,
  i.last_name as last_name,
  a.DOB as dob,
  a.Agent_ID as agent_id,
  a.Agent_of_Record as agent_of_record,
  a.State as state,
  i.uw_audit_main_id as uw_audit_main_id,
  i.inquiry_type as inquiry_type,
  i.inquiry_decision as inquiry_decision,
  i.inquiry_source as inquiry_source,
  a.Outcome_Type as uw_outcome_type,
  a.Outcome_Source as uw_outcome_source,
  a.UW_Type as uw_type,
  a.Plan_Code as plan_code,
  --i.created_ts as created_ts,
  --i.created_by as created_by,
  --i.updated_ts as updated_ts,
  --i.updated_by as updated_by,
  i.CREAT_DT as created_ts,
  i.CREAT_BY as created_by,
  i.LST_MOD_DT as updated_ts,
  i.LST_MOD_BY as updated_by,
  p.process_step as process_step,
  p.stage as status,
  p.assigned as assigned,
  p.created_ts as assigned_date,
  p.note as note
from IDENTIFIER(:V_IN_INQUIRY) i
join IDENTIFIER(:V_IN_INQ_PROCESS_STEP_VW) p
on i.id = p.inquiry_id
left join (SELECT m.id  AS ID,
  to_char(m.report_date, 'MM/DD/YYYY')  AS Report_Date,
  --DATE_FORMAT (to_date (from_unixtime(unix_timestamp(m.audit_date,'dd-MMM-yy'))),'MM/DD/YYYY') AS Audit_Date,
  TO_CHAR(to_date(m.audit_date),'MM/DD/YYYY') AS Audit_Date,
  TO_CHAR(m.app_recd_date, 'MM/DD/YYYY') AS App_Recd_Date,
  m.uw_type                                          AS Underwriting_Type,
  m.member_number                                    AS Member_Number,
  m.first_name                                       AS First_Name,
  m.last_name                                        AS Last_Name,
  --DATE_FORMAT (to_date (from_unixtime(unix_timestamp(m.dob,'dd-MMM-yy'))),'MM/DD/YY') AS DOB,
  TO_CHAR(to_date(m.dob),'MM/DD/YY') AS DOB,
  
  m.gender                                           AS Gender,
  m.zip                                              AS Zip,
  m.address1                                         AS Address,
  m.city                                             AS City,
  m.state                                            AS State,
  m.phone                                            AS Phone,
  m.img_number                                       AS DCN_Number,
  m.application_id                                   AS Application_Id,
    case 
	  when m.screen_result = 'RFA' THEN 'Ready for audit'	
	  when m.screen_result = 'EWN' THEN 'Enrollment work needed'
	  when m.screen_result = 'DFA' THEN 'Delete from audit'
	  else SCREEN_RESULT 
	  END as Screening_Result,
  
  --DATE_FORMAT (m.completion_date, 'MM/DD/YYYY') AS Completion_Date,
   TO_CHAR(m.completion_date, 'MM/DD/YYYY') AS Completion_Date,
  CASE
    WHEN m.report_date IS NOT NULL
    THEN(datediff(day,completion_date,report_date))
	ELSE 'N/A'
	END AS TAT,
   assigned_to                           AS Completed_By,
  --DATE_FORMAT (m.letter_date, 'MM/DD/YYYY') AS Letter_Date,
  TO_CHAR(m.letter_date, 'MM/DD/YYYY') AS Letter_Date,
  m.comments                            AS Comments,
  o.uw_outcomes                         AS Outcome_Type,
    
  s.uw_outcome_source                                                  AS Outcome_Source,
  m.uw_type                                                            AS UW_Type,
  m.written                                                            AS Written,
  m.written_comment_source                                             AS Written_Comment_Source,
  m.curr_stage                                                         AS Status,
  m.agent_id                                                           AS Agent_ID,
  a.agg                                                                 AS AGG,
  m.hash_id                                                            AS Hash_ID,
  CASE 
  WHEN SUBSTR (HASH_ID, 1, 10) = '2460720307' THEN 'Agent'
  ELSE 'Non-Agent'
  END AS Agent_NonAgent,
  m.request_id AS Request_ID,
  m.agent_of_record as Agent_of_Record,
  m.plan_code as Plan_Code,
  m.gi_self_ident as GI_Self_Indentify,
  m.ole_ref_id as OLE_Reference_Id,
  m.application_version as Application_Version,
  m.reason_code as Reason_Code,
  m.pos_call_time as POS_Call_Time
FROM IDENTIFIER(:V_UW_AUDIT_MAIN) m
	left join IDENTIFIER(:V_UW_OUTCOMES) o
	on m.outcome = o.id
 left join IDENTIFIER(:V_UW_OUTCOME_SOURCE) s
 on m.outcome_source = s.id
 left join IDENTIFIER(:V_UW_AGENTS) a
 on m.agent_id = a.agent_id
) a
on i.uw_audit_main_id = a.id
) i;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_UW_QUERY2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, 'DEEP_PROCESS', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), 'SUCCESS', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := 'STEP3';

V_STEP_NAME :=  'create a OUTCOME_REASON2';
   
V_START_TIME := CONVERT_TIMEZONE('America/Chicago', CURRENT_TIMESTAMP());


create or replace temporary table IDENTIFIER(:V_OUTCOME_REASON2) as
SELECT
	--concat_ws(',',collect_list(i.uw_outcome_reason)) AS outcome_reason
    LISTAGG(i.uw_outcome_reason,',') AS outcome_reason
 	,m_id
FROM
	(
		SELECT r.uw_outcome_reason ,m.id as m_id
	    FROM IDENTIFIER(:V_UW_AUDIT_COND) as c
	    inner join 
	      IDENTIFIER(:V_UW_OUTCOME_REASON) as r
	    on c.outcome_reason = r.id
	    inner join IDENTIFIER(:V_UW_AUDIT_MAIN) m
	    on c.recid  = m.id
	    GROUP BY r.uw_outcome_reason,m.id
    ) i
GROUP BY
	uw_outcome_reason,m_id; 


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_OUTCOME_REASON2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, 'DEEP_PROCESS', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), 'SUCCESS', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

V_STEP := 'STEP4';

V_STEP_NAME :=  'create a DAILY_UW_DB_TABLE2';
   
V_START_TIME := CONVERT_TIMEZONE('America/Chicago', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_DAILY_UW_DB_TABLE2) COPY GRANTS as 
select
	b.outcome_reason as uw_reason
	,a.inquiry_id
	,a.inquiry_date
	,a.inquiry_review_type
	,a.status
	,a.assigned_to
	,a.assigned_date
	,a.tat
	,a.age
	,a.inquiry_dcn
	,a.member_number
	,a.first_name
	,a.last_name
	,a.dob
	,a.state
	,a.agent_id
	,a.inquiry_type
	,a.inquiry_decision
	,a.inquiry_source
	,a.original_application_dcn
	,a.uw_outcome
	--,a.uw_reason
	,a.uw_source
	,a.uw_type
	,a.plan_code
from
	IDENTIFIER(:V_UW_QUERY2) as a
left join
	IDENTIFIER(:V_OUTCOME_REASON2) as b
on 	a.a_id = b.m_id;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DAILY_UW_DB_TABLE2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, 'DEEP_PROCESS', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), 'SUCCESS', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, 'DEEP_PROCESSES', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), 'FAILED', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);


RAISE;

END;

$$;