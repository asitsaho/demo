USE SCHEMA BDR_FFP_DA;

CREATE OR REPLACE PROCEDURE BDR_FFP_DA.SP_SALES_ACCOUNTABLE_CALLS_MEDSUP("PIPELINE_ID" VARCHAR(16777216), "PIPELINE_NAME" VARCHAR(16777216), "DB_NAME" VARCHAR(16777216), "UTIL_SC" VARCHAR(16777216), "ONE_SC" VARCHAR(16777216), "TWO_SC" VARCHAR(16777216), "INTRM_SC" VARCHAR(16777216), "TGT_SC" VARCHAR(16777216), "WH" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE



V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := :DB_NAME||''.''||COALESCE(:UTIL_SC, ''UTIL'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';
        
V_PROCESS_NAME VARCHAR DEFAULT ''SALES_ACCOUNTABLE_CALLS_MEDSUP'';

V_SUB_PROCESS_NAME VARCHAR DEFAULT ''SALES_ACCOUNTABLE_CALLS_MEDSUP'';

V_STEP             VARCHAR;

V_STEP_NAME        VARCHAR;

V_START_TIME       VARCHAR;

V_END_TIME         VARCHAR;

V_ROWS_PARSED       INTEGER;

V_ROWS_LOADED       INTEGER;

V_MESSAGE          VARCHAR;

V_LAST_QUERY_ID    VARCHAR;

V_medsupcalls VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.sales_accntble_call_medsupcalls'';

V_uhcaccountablecalls_data VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''SRC_FIN360'') || ''.uhcaccountablecalls_data'';

V_actuals_calls VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.sales_accntble_call_actuals_calls'';

V_tfn_ad_channel VARCHAR := :DB_NAME || ''.'' || COALESCE(:TWO_SC, ''SRC_MPO'') || ''.tfn_ad_channel'';

V_bottomupsup_LY VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.sales_accntble_call_bottomupsup_LY'';

V_bottomsup_campaignref_depotprj VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''SRC_FIN360'') || ''.bottomsup_campaignref_depotprj'';

V_bottomupsup_CY VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.sales_accntble_call_bottomupsup_CY'';

V_bottomups_combine1 VARCHAR:= :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.sales_accntble_call_bottomups_combine1'';

V_bottomups_combine VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.sales_accntble_call_bottomups_combine'';

V_project_campaign_final VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.sales_accntble_call_project_campaign_final'';

V_depot_project_program VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''SRC_FIN360'') || ''.depot_project_program'';

V_mapping2025_24 VARCHAR:= :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.sales_accntble_call_mapping2025_24'';

V_Camp_Prj_info VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.sales_accntble_call_Camp_Prj_info'';

V_actuals_CY_LY2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.sales_accntble_call_actuals_CY_LY2'';

V_toll_free_log VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.toll_free_log'';

V_actuals_CY_LY3 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.sales_accntble_call_actuals_CY_LY3'';

V_actuals_CY_LY VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.sales_accntble_call_actuals_CY_LY'';

V_PortfolioCombine_3 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.sales_accntble_call_PortfolioCombine_3'';

V_PortfolioCombine_4 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.sales_accntble_call_PortfolioCombine_4'';

V_PortfolioCombine_5 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.sales_accntble_call_PortfolioCombine_5'';

V_PortfolioCombine_5b VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.sales_accntble_call_PortfolioCombine_5b'';

V_PortfolioCombine_6 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.sales_accntble_call_PortfolioCombine_6'';

V_forecast_final_2025 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.sales_accntble_call_forecast_final_2025'';

V_forecast_file_2025_ingest VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.SALES_ACCNTBLE_CALL_FORECAST_FILE_2025_INGEST'';

V_medsup_nonresp_CS VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.sales_accntble_call_medsup_nonresp_CS'';

V_genesys_fcst_2025_ingest VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.SALES_ACCNTBLE_CALL_GENESYS_FCST_2025_INGEST'';

V_fcst_group_medsup_camp_lvl VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.sales_accntble_call_fcst_group_medsup_camp_lvl'';

V_genesys_fcst VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.sales_accntble_call_genesys_fcst'';

V_fcst_group_medsup_camp_lvla VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.sales_accntble_call_fcst_group_medsup_camp_lvla'';

V_fcst_group_medsup_camp_lvl2b VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.sales_accntble_call_fcst_group_medsup_camp_lvl2b'';

V_fcst_group_medsup_camp_lvl2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.sales_accntble_call_fcst_group_medsup_camp_lvl2'';

V_fcst_group_medsup_camp_lvl3 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.sales_accntble_call_fcst_group_medsup_camp_lvl3'';

V_fcst_group_nonresp_CSE_CSS VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.sales_accntble_call_fcst_group_nonresp_CSE_CSS'';

V_medsup_nonresp_CS2nd VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.sales_accntble_call_medsup_nonresp_CS2nd'';

V_fcst_group_medsup_other_combine VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.sales_accntble_call_fcst_group_medsup_other_combine'';

V_fcst_group_DRTV1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.sales_accntble_call_fcst_group_DRTV1'';

V_fcst_group_DRTV2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.sales_accntble_call_fcst_group_DRTV2'';

V_fcst_group_DRTV VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.sales_accntble_call_fcst_group_DRTV'';

V_fcst_group_Portfolio1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.sales_accntble_call_fcst_group_Portfolio1'';

V_fcst_group_Portfolio2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.sales_accntble_call_fcst_group_Portfolio2'';

V_fcst_group_Portfolio VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.sales_accntble_call_fcst_group_Portfolio'';

V_combine_all_2025 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.sales_accntble_call_combine_all_2025'';


BEGIN

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP1'';
  
V_STEP_NAME := ''Loading table sales_accntble_call_medsupcalls'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH; 

create or replace table IDENTIFIER(:V_medsupcalls) COPY GRANTS as 
select 
Calldate,
seqstart,
partner,
tfn,
function,
subfunction,
language,
vq,
sum(calls_accountable) as calls_accountable,
sum(direct_accountable) as direct_accountable,
sum(transfers_accountable) as transfers_accountable,
sum(calls_answered) as calls_answered
from IDENTIFIER(:V_uhcaccountablecalls_data)
where function IN (''Sales'')
and year(Calldate) IN (''2024'', ''2025'') 
and transfers_accountable =0 
group by Calldate,
seqstart,
partner,
tfn,
function,
subfunction,
language,
vq;

V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_medsupcalls) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP2'';
   
V_STEP_NAME := ''Loading table sales_accntble_call_actuals_calls'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_actuals_calls) COPY GRANTS as 
SELECT distinct   
sc.response_id,
sc.source_code,
sc.ad_type_name,
sc.solicitation_category,
sc.solicitation_channel,
sc.comm_medium_name,
sc.projectcode_depot,
sc.projectname_depot,
sc.adv_channel,
sc.adv_channel_grp,
sc.spend,
sc.portfolio_flag,
sc.resp_class_desc,
cl.vq,
cl.Calldate,
sc.Response_BEGIN_DATE,
sc.Response_END_DATE,
cl.seqstart,
Cl.partner,
cl.tfn,
sc.response_VDN_number,
cl.function,
cl.subfunction,
cl.language,
CASE WHEN cl.Calldate >= ''2025-01-01'' and cl.Calldate <= ''2025-12-31'' THEN cl.calls_accountable ELSE 0 END AS calls_accountable_CY,
CASE WHEN cl.Calldate >= ''2025-01-01'' and cl.Calldate <= ''2025-12-31'' THEN cl.direct_accountable ELSE 0 END AS direct_accountable_CY,
CASE WHEN cl.Calldate >= ''2025-01-01'' and cl.Calldate <= ''2025-12-31'' THEN cl.transfers_accountable ELSE 0 END AS transfers_accountable_CY,
CASE WHEN cl.Calldate >= ''2025-01-01'' and cl.Calldate <= ''2025-12-31'' THEN cl.calls_answered ELSE 0 END AS calls_answered_CY,

CASE WHEN cl.Calldate >= ''2024-01-01'' and cl.Calldate <= ''2024-12-31'' THEN cl.calls_accountable ELSE 0 END AS calls_accountable_LY,
CASE WHEN cl.Calldate >= ''2024-01-01'' and cl.Calldate <= ''2024-12-31'' THEN cl.direct_accountable ELSE 0 END AS direct_accountable_LY,
CASE WHEN cl.Calldate >= ''2024-01-01'' and cl.Calldate <= ''2024-12-31'' THEN cl.transfers_accountable ELSE 0 END AS transfers_accountable_LY,
CASE WHEN cl.Calldate >= ''2024-01-01'' and cl.Calldate <= ''2024-12-31'' THEN cl.calls_answered ELSE 0 END AS calls_answered_LY
FROM IDENTIFIER(:V_medsupcalls) cl
LEFT JOIN IDENTIFIER(:V_tfn_ad_channel) sc
ON trim(cast(cl.tfn as string)) = trim(sc.response_VDN_number)
AND cl.tfn is not null
AND sc.Response_BEGIN_DATE <= cl.Calldate
AND (sc.Response_END_DATE >= cl.Calldate or sc.Response_END_DATE is null);

V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_actuals_calls) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP3'';
   
V_STEP_NAME := ''Loading table sales_accntble_call_bottomupsup_LY'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
create or replace table IDENTIFIER(:V_bottomupsup_LY) COPY GRANTS as 
Select distinct 2024 as year,
CampaignGroup, CampaignDetail,campaignsummary,productoffer as ProductOffer_PRJ, mktgmedium as Mktgmedium_PRJ, "`2024_PROJECTCODE`" as ProjectCode,"`2024_PROJECTNAME`" as Projectname
from IDENTIFIER(:V_bottomsup_campaignref_depotprj)
where "`2024_PROJECTCODE`" is not null;

V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_bottomupsup_LY) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



V_STEP := ''STEP4'';
   
V_STEP_NAME := ''Loading table sales_accntble_call_bottomupsup_CY'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
create or replace table IDENTIFIER(:V_bottomupsup_CY) COPY GRANTS as 
Select distinct 2025 as year,
CampaignGroup, CampaignDetail,campaignsummary,productoffer as ProductOffer_PRJ, mktgmedium as Mktgmedium_PRJ, "`2025_PROJECTCODE`" as ProjectCode,"`2025_PROJECTNAME`" as Projectname
from IDENTIFIER(:V_bottomsup_campaignref_depotprj)
where "`2025_PROJECTCODE`" is not null;

V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_bottomupsup_CY) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP5'';
   
V_STEP_NAME := ''Loading table sales_accntble_call_bottomups_combine1 '';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
create or replace table IDENTIFIER(:V_bottomups_combine1) COPY GRANTS as
Select *
from IDENTIFIER(:V_bottomupsup_LY)
Union All
Select * from IDENTIFIER(:V_bottomupsup_CY);
	
V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_bottomups_combine1) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP6'';
   
V_STEP_NAME := ''Loading table sales_accntble_call_bottomups_combine'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
create or replace table IDENTIFIER(:V_bottomups_combine) COPY GRANTS as
Select *
from IDENTIFIER(:V_bottomups_combine1)
WHERE ProductOffer_PRJ NOT IN (''MA'')
;

V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_bottomups_combine) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP7'';
   
V_STEP_NAME := ''Loading table sales_accntble_call_project_campaign_final'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
create or replace table IDENTIFIER(:V_project_campaign_final) COPY GRANTS as 
Select t2.*,
b.Plan_cd, 
b.Plan_nm,
b.program_cd, 
b.program_nm,
b.depot_project_cd as Project_cd,
b.project_nm,
b.depot_project_cd
from IDENTIFIER(:V_bottomups_combine) t2
left join IDENTIFIER(:V_depot_project_program) b 
on t2.ProjectCode = b.DEPOT_PROJECT_CD;

V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_project_campaign_final) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP8'';
   
V_STEP_NAME := ''Loading table sales_accntble_call_mapping2025_24'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
create or replace table IDENTIFIER(:V_mapping2025_24) COPY GRANTS as
select * from  IDENTIFIER(:V_bottomsup_campaignref_depotprj)
where "`2024_PROJECTCODE`" is not null;

V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_mapping2025_24) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP9'';
   
V_STEP_NAME := ''Loading table sales_accntble_call_Camp_Prj_info'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
create or replace table IDENTIFIER(:V_Camp_Prj_info) COPY GRANTS as
select A.*,
(case when A.response_id is null then ''Non-response ID'' else B.CampaignDetail end) as Campaign_Detail,
(case when A.response_id is null then ''Non-response ID'' else B.CampaignGroup end) as Campaign_Group,
B.campaignsummary,
B.ProductOffer_PRJ, 
B.Mktgmedium_PRJ, 
B.ProjectCode,
B.Projectname,
b.Plan_cd, 
b.Plan_nm,
b.program_cd, 
b.program_nm,
b.Project_cd,
b.project_nm,
b.depot_project_cd
from IDENTIFIER(:V_actuals_calls) A
left join IDENTIFIER(:V_project_campaign_final) B
on A.projectcode_depot = B.ProjectCode and year(A.Calldate) = B.year and A.projectcode_depot is not null
left join IDENTIFIER(:V_mapping2025_24) c on A.projectcode_depot= c."`2025_PROJECTCODE`";

V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_Camp_Prj_info) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP10'';
   
V_STEP_NAME := ''Loading table sales_accntble_call_actuals_CY_LY2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
create or replace table IDENTIFIER(:V_actuals_CY_LY2) COPY GRANTS as
select 
A.*,
B.tfn_type,
case when A.response_id is not null and B.tfn_type not in (''Customer Service English'', ''Customer Service Spanish'') then ''With Response ID'' else ''Without Response ID'' end as flag,
(case when B.tfn_type = ''Customer Service English'' /*and A.response_id is null*/ then ''Customer Service English''
	  when B.tfn_type = ''Customer Service Spanish'' /*and A.response_id is null*/ then ''Customer Service Spanish'' else A.Campaign_Detail end) as Campaign_Detail2,
	    
(case when B.tfn_type = ''Customer Service English'' /*and A.response_id is null*/ then ''Customer Service English''
	  when B.tfn_type = ''Customer Service Spanish'' /*and A.response_id is null*/ then ''Customer Service Spanish'' else A.Campaign_Group end) as CampaignGroup2

from IDENTIFIER(:V_Camp_Prj_info) A
LEFT JOIN IDENTIFIER(:V_toll_free_log) B 
ON trim(cast(A.tfn as string))= trim(B.toll_free_number);

V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_actuals_CY_LY2) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP11'';
   
V_STEP_NAME := ''Loading table sales_accntble_call_actuals_CY_LY3'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
create or replace table IDENTIFIER(:V_actuals_CY_LY3) COPY GRANTS as
select *,
(case when /*response_id is not null and*/ vq in (''VQ_OPT_AARPHealth_UHC_Sales_Portfolio'') then ''PORTFOLIO''  
	 when /*response_id is not null and*/ vq in (''VQ_OPT_AARPHealth_UHC_Sales_DirectTV'') then ''DRTV''
        /* when  vq in (''VQ_OPT_AARPHealth_UHC_Sales'',''VQ_OPT_AARPHealth_UHC_Sales_GRSSales'',''VQ_OPT_AARPHealth_UHC_Sales_Spanish''
	 ,''VQ_OPT_AARPHealth_UHC_Sales_PartD'') then ''medsup''*/
	 else ''MEDSUP'' end) as fcst_group
	 from IDENTIFIER(:V_actuals_CY_LY2);

V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_actuals_CY_LY3) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP12'';
   
V_STEP_NAME := ''Loading table sales_accntble_call_actuals_CY_LY'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
create or replace table IDENTIFIER(:V_actuals_CY_LY) COPY GRANTS as
select 
response_id,
source_code,
ad_type_name,
solicitation_category,
solicitation_channel,
comm_medium_name,
projectcode_depot,
projectname_depot,
adv_channel,
adv_channel_grp,
spend,
portfolio_flag,
resp_class_desc,
vq,
Calldate,
fcst_group,
Response_BEGIN_DATE,
Response_END_DATE,
seqstart,
partner,
tfn,
response_VDN_number,
function,
subfunction,
language,
calls_accountable_CY,
direct_accountable_CY,
transfers_accountable_CY,
calls_answered_CY,
calls_accountable_LY,
direct_accountable_LY,
transfers_accountable_LY,
calls_answered_LY,
Campaign_Detail2 as CampaignDetail,
CampaignGroup2 as CampaignGroup,
campaignsummary,
ProductOffer_PRJ, 
Mktgmedium_PRJ, 
ProjectCode,
Projectname,
Plan_cd, 
Plan_nm,
program_cd, 
program_nm,
Project_cd,
project_nm,
depot_project_cd,
flag
from IDENTIFIER(:V_actuals_CY_LY3);

V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_actuals_CY_LY) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP13'';
   
V_STEP_NAME := ''Loading table sales_accntble_call_PortfolioCombine_3'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
create or replace table IDENTIFIER(:V_PortfolioCombine_3) COPY GRANTS as 
select A.*,
CASE 
	when A.CampaignGroup = ''Program in Run Rate'' then A.CampaignDetail
	WHEN A.Portfolio_flag=''Y'' and A.adv_channel in (''AARP Member Office Transfers'') then ''Portfolio - AARP Member Office Transfers''
	when A.Portfolio_flag <>''Y'' and A.adv_channel in (''AARP Member Office Transfers'') then ''AARP Member Office Transfers''
	when A.Portfolio_flag=''Y'' and A.adv_channel in  (''United Call Center Transfers'') then ''Portfolio - United Call Transfers''
	when A.Portfolio_flag<>''Y'' and A.adv_channel in  (''United Call Center Transfers'') then ''United Call Transfers''
		
	when A.Portfolio_flag=''Y'' and A.adv_channel in (''SQS Call Center Transfers'') then ''Portfolio - Select Quote Transfers''
	when A.Portfolio_flag<>''Y'' and A.adv_channel in (''SQS Call Center Transfers'') then ''Select Quote Transfers''
	when A.Portfolio_flag=''Y'' and A.adv_channel in (''Green Bay Portfolio Call Center'') then ''Portfolio - United Call Center''
	when A.Portfolio_flag<>''Y'' and A.adv_channel in (''Green Bay Portfolio Call Center'') then ''United Call Center''
	when A.Portfolio_flag=''Y'' and A.adv_channel in (''Bounded List'') then ''Portfolio - Bounded List''
		when A.Portfolio_flag<>''Y'' and A.adv_channel in (''Bounded List'') then ''Bounded List''
		when A.Portfolio_flag=''Y'' and A.adv_channel in (''General Program'') then ''Portfolio - General Program''
		when A.Portfolio_flag<>''Y'' and A.adv_channel in (''General Program'') then ''General Program''
		when A.Portfolio_flag=''Y'' and A.adv_channel in (''MS Other Spend'',''UHG Other Spend'',''Agent'') then ''Portfolio - SBU Other''
		when A.Portfolio_flag<>''Y'' and A.adv_channel in (''MS Other Spend'',''UHG Other Spend'',''Agent'') then ''SBU Other''
		when A.Portfolio_flag=''Y'' and A.adv_channel in (''Provider Pack'') then ''Portfolio - Provider Pack''
		when A.Portfolio_flag<>''Y'' and A.adv_channel in (''Provider Pack'') then ''Provider Pack''
		when A.Portfolio_flag=''Y'' and A.adv_channel_grp in (''Print'') and A.adv_channel not in (''Provider Pack'') then ''Portfolio - Print''
		when A.Portfolio_flag<>''Y'' and A.adv_channel_grp in (''Print'') and A.adv_channel not in (''Provider Pack'') then ''Print''
		when A.Portfolio_flag=''Y'' and A.adv_channel_grp in (''Direct Marketing'') then ''Portfolio - Direct Marketing''
		when A.Portfolio_flag<>''Y'' and A.adv_channel_grp in (''Direct Marketing'') then ''Direct Marketing''
		when A.Portfolio_flag=''Y'' and A.adv_channel_grp in (''Digital Paid'') then ''Portfolio - Digital Paid''
		when A.Portfolio_flag<>''Y'' and A.adv_channel_grp in (''Digital Paid'') then ''Digital Paid''
		when A.Portfolio_flag=''Y'' and A.adv_channel in (''Third Party Referral Traffic'') then ''Portfolio - Third Party Referral Traffic''
		when A.Portfolio_flag<>''Y'' and A.adv_channel in (''Third Party Referral Traffic'') then ''Third Party Referral Traffic''
		when A.Portfolio_flag=''Y'' and A.adv_channel_grp in (''Digital Non-Paid'') and A.adv_channel not in (''Third Party Referral Traffic'')  then ''Portfolio - Digital Non-Paid''
		when A.Portfolio_flag<>''Y'' and A.adv_channel_grp in (''Digital Non-Paid'') and A.adv_channel not in (''Third Party Referral Traffic'')  then ''Digital Non-Paid''
		when A.Portfolio_flag=''Y'' and A.adv_channel_grp in (''TV'') then ''Portfolio - TV''
		when A.Portfolio_flag<>''Y'' and A.adv_channel_grp in (''TV'') then ''TV''
		When A.TFN in (8666604118) then ''United Call Center Transfers to MS Mem Service''		
ELSE ''Run Rate - Other'' end as Grouping_RRTrans
from IDENTIFIER(:V_actuals_CY_LY) A;

V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_PortfolioCombine_3) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP14'';
   
V_STEP_NAME := ''Loading table sales_accntble_call_PortfolioCombine_4'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
create or replace table IDENTIFIER(:V_PortfolioCombine_4) COPY GRANTS AS
select *,
CASE WHEN year(Calldate) = ''2024'' THEN DATEADD(DAY, 364, Calldate) 
ELSE Calldate END AS interaction_date
from IDENTIFIER(:V_PortfolioCombine_3);

V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_PortfolioCombine_4) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP15'';
   
V_STEP_NAME := ''Loading table sales_accntble_call_PortfolioCombine_5'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
create or replace table IDENTIFIER(:V_PortfolioCombine_5) COPY GRANTS as
select  
interaction_date,
seqstart,
hour(seqstart) as hours,
adv_channel,
adv_channel_grp,
fcst_group,
response_id,
source_code,
ad_type_name,
solicitation_category,
solicitation_channel,
comm_medium_name,
spend,
tfn,
resp_class_desc,
vq,
(case when CampaignDetail like (''%Program in Run Rate%'') then UPPER(Productoffer_PRJ) 
when CampaignDetail like (''Non-Paid Digital%'') then UPPER(Productoffer_PRJ) 
when CampaignDetail like (''%Transfer'') then UPPER(Productoffer_PRJ)
when Grouping_RRTrans like ''%Transfer%'' then UPPER(Productoffer_PRJ)
when CampaignDetail is null then UPPER(Productoffer_PRJ)
else UPPER(Productoffer_PRJ) end) as Product_Offered,	  
Mktgmedium_PRJ as Marketing_Medium,
(case when Grouping_RRTrans like ''%Transfer%'' then ''Transfer'' 
	  when CampaignSummary is not null then CampaignSummary else ''Run Rate'' end) as Campaign_Summary,
	  
(case when Grouping_RRTrans like ''%Transfer%'' then ''Transfer''
	  when CampaignDetail is not null then CampaignDetail else ''Run Rate'' end) as Campaign_Detail,
	  
(case when Grouping_RRTrans like ''%Transfer%'' then ''Transfer''
	  when CampaignGroup is not null and CampaignGroup not in (''Program in Run Rate'') then CampaignGroup else ''Run Rate'' end) as Campaign_Group,
Grouping_RRTrans,
project_cd,
project_nm,
program_cd,
program_nm,
plan_cd,
plan_nm,
flag,
calls_accountable_CY,
direct_accountable_CY,
transfers_accountable_CY,
calls_answered_CY,
calls_accountable_LY,
direct_accountable_LY,
transfers_accountable_LY,
calls_answered_LY
from IDENTIFIER(:V_PortfolioCombine_4);

V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_PortfolioCombine_5) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP16'';
   
V_STEP_NAME := ''Loading table sales_accntble_call_PortfolioCombine_5b'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
create or replace table IDENTIFIER(:V_PortfolioCombine_5b) COPY GRANTS as
select
interaction_date,
seqstart,
hour(seqstart) as hours,
adv_channel,
adv_channel_grp,
fcst_group,
response_id,
source_code,
ad_type_name,
solicitation_category,
solicitation_channel,
comm_medium_name,
spend,
tfn,
resp_class_desc,
vq,
Product_Offered,
Marketing_Medium,
Campaign_Summary,
Campaign_Detail,
Campaign_Group,
Grouping_RRTrans,
project_cd,
project_nm,
program_cd,
program_nm,
plan_cd,
plan_nm,
flag,
calls_accountable_CY,
direct_accountable_CY,
transfers_accountable_CY,
calls_answered_CY,
calls_accountable_LY,
direct_accountable_LY,
transfers_accountable_LY,
calls_answered_LY
from IDENTIFIER(:V_PortfolioCombine_5);

V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_PortfolioCombine_5b) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP17'';
   
V_STEP_NAME := ''Loading table sales_accntble_call_PortfolioCombine_6'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
create or replace table IDENTIFIER(:V_PortfolioCombine_6) COPY GRANTS as
select 
interaction_date,
seqstart,
hours,
Product_Offered,
Marketing_Medium,
fcst_group,
Campaign_Summary,
Campaign_Detail,
Campaign_Group,
Grouping_RRTrans,
project_cd,
project_nm,
program_cd,
program_nm,
plan_cd,
plan_nm,
flag,
sum(calls_accountable_CY) as calls_accountable_CY,
sum(direct_accountable_CY) as direct_accountable_CY,
sum(transfers_accountable_CY) as transfers_accountable_CY,
sum(calls_answered_CY) as calls_answered_CY,
sum(calls_accountable_LY) as calls_accountable_LY,
sum(direct_accountable_LY) as direct_accountable_LY,
sum(transfers_accountable_LY) as transfers_accountable_LY,
sum(calls_answered_LY) as calls_answered_LY
from IDENTIFIER(:V_PortfolioCombine_5b)
group by 
interaction_date,
seqstart,
hours,
Product_Offered,
Marketing_Medium,
fcst_group,
Campaign_Summary,
Campaign_Detail,
Campaign_Group,
Grouping_RRTrans,
project_cd,
project_nm,
program_cd,
program_nm,
plan_cd,
plan_nm,
flag;

V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_PortfolioCombine_6) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP18'';
   
V_STEP_NAME := ''Loading table sales_accntble_call_forecast_final_2025'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
create or replace table IDENTIFIER(:V_forecast_final_2025) COPY GRANTS as 
select distinct "2025_WEEK_START" as WEEK, medsup_matrans_arrptrans as medsupp, drtv,portfolio 
from IDENTIFIER(:V_forecast_file_2025_ingest) 
order by "2025_WEEK_START";

V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_forecast_final_2025) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP19'';
   
V_STEP_NAME := ''Loading table sales_accntble_call_medsup_nonresp_CS'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
create or replace table IDENTIFIER(:V_medsup_nonresp_CS) COPY GRANTS as
	 select 
	 a.*,
	 f.week,
	 CASE 
		 WHEN sum(a.calls_accountable_LY) over (partition by f.week) = 0 
	 THEN medsupp * (1 / sum(1) over (partition by f.week))
	 ELSE medsupp * (calls_accountable_LY/sum(calls_accountable_LY) over (partition by week)) end as daily_forecast 
from IDENTIFIER(:V_PortfolioCombine_6) a
LEFT JOIN IDENTIFIER(:V_forecast_final_2025) f
ON a.interaction_date >= f.week and a.interaction_date < DATEADD(DAY, 7, f.week) 
where fcst_group not in (''DRTV'',''PORTFOLIO'') and Campaign_Detail not in 
(select  Campaign_Detail 
from IDENTIFIER(:V_genesys_fcst_2025_ingest) 
group by Campaign_Detail 
having sum(FCST)= 0
);

V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_medsup_nonresp_CS) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP20'';
   
V_STEP_NAME := ''Loading table sales_accntble_call_fcst_group_medsup_camp_lvl'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
create or replace table IDENTIFIER(:V_fcst_group_medsup_camp_lvl) COPY GRANTS as
select *
from IDENTIFIER(:V_medsup_nonresp_CS) 
where flag in (''With Response ID'');

V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_fcst_group_medsup_camp_lvl) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP21'';
   
V_STEP_NAME := ''Loading table sales_accntble_call_genesys_fcst'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
create or replace table IDENTIFIER(:V_genesys_fcst) COPY GRANTS as 
select 
dateadd(day, -cast(datediff(day, ''1900-01-07'', interaction_date) % 7 as int), interaction_date) AS week_start_date, 
interaction_date,
campaign_group,
Campaign_Detail,
sum(fcst) as FCST
from IDENTIFIER(:V_genesys_fcst_2025_ingest)
where Campaign_Detail not in 
(select  Campaign_Detail 
from IDENTIFIER(:V_genesys_fcst_2025_ingest) 
group by Campaign_Detail 
having sum(FCST)= 0
)
group by interaction_date,campaign_group,Campaign_Detail;

V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_genesys_fcst) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP22'';
   
V_STEP_NAME := ''Loading table sales_accntble_call_fcst_group_medsup_camp_lvla'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
create or replace table IDENTIFIER(:V_fcst_group_medsup_camp_lvla) COPY GRANTS as 
select week,interaction_date,campaign_group,Campaign_Detail, sum(daily_forecast) as daily_forecast
from IDENTIFIER(:V_fcst_group_medsup_camp_lvl)
group by week,interaction_date,campaign_group,Campaign_Detail;

V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_fcst_group_medsup_camp_lvla) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP23'';
   
V_STEP_NAME := ''Loading table sales_accntble_call_fcst_group_medsup_camp_lvl2b'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
create or replace table IDENTIFIER(:V_fcst_group_medsup_camp_lvl2b) COPY GRANTS as 
select a.*,
FCST,
(FCST/sum(FCST) over (partition by week))as propotion,
CASE 
 WHEN SUM(COALESCE(FCST, 0)) OVER (PARTITION BY week) = 0 THEN
 SUM(COALESCE(daily_forecast, 0)) OVER (PARTITION BY week) 
 / NULLIF(SUM(1) OVER (PARTITION BY week), 0) -- Divide by the total number of records
 ELSE
 SUM(COALESCE(daily_forecast, 0)) OVER (PARTITION BY week) * 
 (COALESCE(FCST, 0) / NULLIF(SUM(COALESCE(FCST, 0)) OVER (PARTITION BY week), 0)) -- Normal distribution when FCST is not NULL
END AS daily_forecast2
from IDENTIFIER(:V_fcst_group_medsup_camp_lvla) A
left join IDENTIFIER(:V_genesys_fcst) B
on A.campaign_group = B.campaign_group
and A.campaign_detail = B.Campaign_Detail
and A.interaction_date= B.interaction_date
where week is not null;
V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_fcst_group_medsup_camp_lvl2b) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP24'';
   
V_STEP_NAME := ''Loading table sales_accntble_call_fcst_group_medsup_camp_lvl2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
create or replace table IDENTIFIER(:V_fcst_group_medsup_camp_lvl2) COPY GRANTS AS
SELECT
a.*,

 CASE 
		 WHEN sum(a.calls_accountable_LY) over (partition by a.interaction_date,a.campaign_group,a.campaign_detail) = 0 
	 THEN daily_forecast2 * (1/ sum(1) over (partition by a.interaction_date,a.campaign_group,a.campaign_detail))
	 ELSE
daily_forecast2  * (a.calls_accountable_lY/sum(a.calls_accountable_lY)over (partition by a.interaction_date,a.campaign_group,a.campaign_detail)) end as daily_forecast3

FROM
IDENTIFIER(:V_fcst_group_medsup_camp_lvl)  a
LEFT JOIN
IDENTIFIER(:V_fcst_group_medsup_camp_lvl2b) f
on A.campaign_group = f.campaign_group
and A.campaign_detail = f.Campaign_Detail
and  a.interaction_date = f.interaction_date;

V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_fcst_group_medsup_camp_lvl2) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP25'';
   
V_STEP_NAME := ''Loading table sales_accntble_call_fcst_group_medsup_camp_lvl3'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
create or replace table IDENTIFIER(:V_fcst_group_medsup_camp_lvl3) COPY GRANTS as 
select
interaction_date,
seqstart,
hours,
Product_Offered,
Marketing_Medium,
fcst_group,
Campaign_Summary,
Campaign_Detail,
Campaign_Group,
Grouping_RRTrans,
project_cd,
project_nm,
program_cd,
program_nm,
plan_cd,
plan_nm,
flag,
calls_accountable_CY,
direct_accountable_CY,
transfers_accountable_CY,
calls_answered_CY,
calls_accountable_LY,
direct_accountable_LY,
transfers_accountable_LY,
calls_answered_LY,
week,
daily_forecast3 as daily_forecast
from IDENTIFIER(:V_fcst_group_medsup_camp_lvl2);

V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_fcst_group_medsup_camp_lvl3) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP26'';
   
V_STEP_NAME := ''Loading table sales_accntble_call_fcst_group_nonresp_CSE_CSS'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
create or replace table IDENTIFIER(:V_fcst_group_nonresp_CSE_CSS) COPY GRANTS as
	 select *
	 from IDENTIFIER(:V_medsup_nonresp_CS) 
	 where flag not in (''With Response ID'');

V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_fcst_group_nonresp_CSE_CSS) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP27'';
   
V_STEP_NAME := ''Loading table sales_accntble_call_medsup_nonresp_CS2nd'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
create or replace table IDENTIFIER(:V_medsup_nonresp_CS2nd) COPY GRANTS as
	 select 
	 a.*,
	 f.week,
	 cast(NULL as DECIMAL(18,2)) as daily_forecast 
from IDENTIFIER(:V_PortfolioCombine_6) a
LEFT JOIN IDENTIFIER(:V_forecast_final_2025) f
ON a.interaction_date >= f.week and a.interaction_date < DATEADD(day, 7, f.week)
where fcst_group not in (''DRTV'',''PORTFOLIO'') and Campaign_Detail in 
(select  Campaign_Detail 
from IDENTIFIER(:V_genesys_fcst_2025_ingest) 
group by Campaign_Detail 
having sum(FCST)= 0
);

V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_medsup_nonresp_CS2nd) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP28'';
   
V_STEP_NAME := ''Loading table sales_accntble_call_fcst_group_medsup_other_combine'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
create or replace table IDENTIFIER(:V_fcst_group_medsup_other_combine) COPY GRANTS as
	 select *
	 from IDENTIFIER(:V_fcst_group_medsup_camp_lvl3) 
UNION
	 select *
	 from IDENTIFIER(:V_fcst_group_nonresp_CSE_CSS)
UNION 
 select *
	 from IDENTIFIER(:V_medsup_nonresp_CS2nd);

V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_fcst_group_medsup_other_combine) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP29'';
   
V_STEP_NAME := ''Loading table sales_accntble_call_fcst_group_DRTV1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
create or replace table IDENTIFIER(:V_fcst_group_DRTV1) COPY GRANTS AS
SELECT
a.*,
f.week,
CASE
WHEN sum(a.calls_accountable_LY) over (partition by f.week) = 0 THEN
drtv * (1 / sum(1) over (partition by f.week))
ELSE
DRTV * (a.calls_accountable_lY/sum(a.calls_accountable_lY) over (partition by week)) end as daily_forecast  
FROM
IDENTIFIER(:V_PortfolioCombine_6) a
LEFT JOIN
IDENTIFIER(:V_forecast_final_2025) f
ON a.interaction_date >= f.week and a.interaction_date < DATEADD(DAY, 7, f.week)
where fcst_group in (''DRTV'') and Campaign_Detail not in 
(select  Campaign_Detail 
from IDENTIFIER(:V_genesys_fcst_2025_ingest)
group by Campaign_Detail 
having sum(FCST)= 0
)
order by a.interaction_date;


V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_fcst_group_DRTV1) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								 


V_STEP := ''STEP30'';
   
V_STEP_NAME := ''Loading table sales_accntble_call_fcst_group_DRTV2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
create or replace table IDENTIFIER(:V_fcst_group_DRTV2) COPY GRANTS AS
SELECT
a.*,
f.week,
cast(0 as DECIMAL(18,2)) as daily_forecast 
FROM
IDENTIFIER(:V_PortfolioCombine_6) a
LEFT JOIN
IDENTIFIER(:V_forecast_final_2025) f
ON a.interaction_date >= f.week and a.interaction_date < DATEADD(DAY, 7, f.week)
where fcst_group in (''DRTV'') and Campaign_Detail in 
(select  Campaign_Detail 
from IDENTIFIER(:V_genesys_fcst_2025_ingest) 
group by Campaign_Detail 
having sum(FCST)= 0
)
order by a.interaction_date;


V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_fcst_group_DRTV2) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);		


V_STEP := ''STEP31'';
   
V_STEP_NAME := ''Loading table sales_accntble_call_fcst_group_DRTV'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
create or replace table IDENTIFIER(:V_fcst_group_DRTV) COPY GRANTS AS
select *
	 from IDENTIFIER(:V_fcst_group_DRTV1)
UNION
	 select *
	 from IDENTIFIER(:V_fcst_group_DRTV2)
;

V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_fcst_group_DRTV) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								 



V_STEP := ''STEP32'';
   
V_STEP_NAME := ''Loading table sales_accntble_call_fcst_group_Portfolio1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
create or replace table IDENTIFIER(:V_fcst_group_Portfolio1) COPY GRANTS AS
SELECT
a.*,
f.week,
CASE
WHEN sum(a.calls_accountable_LY) over (partition by f.week) = 0 THEN
Portfolio * (1 / sum(1) over (partition by f.week))
ELSE
Portfolio * (a.calls_accountable_LY / sum(a.calls_accountable_LY) over (partition by f.week)) end as daily_forecast 
FROM
IDENTIFIER(:V_PortfolioCombine_6) a
LEFT JOIN
IDENTIFIER(:V_forecast_final_2025) f
ON
a.interaction_date >= f.week AND a.interaction_date < DATEADD(DAY, 7, f.week)
WHERE
fcst_group IN (''PORTFOLIO'') and Campaign_Detail not in 
(select  Campaign_Detail 
from IDENTIFIER(:V_genesys_fcst_2025_ingest)
group by Campaign_Detail 
having sum(FCST)= 0
)
ORDER BY
a.interaction_date;

V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_fcst_group_Portfolio1) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								 

V_STEP := ''STEP33'';
   
V_STEP_NAME := ''Loading table sales_accntble_call_fcst_group_Portfolio2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
create or replace table IDENTIFIER(:V_fcst_group_Portfolio2) COPY GRANTS AS
SELECT
a.*,
f.week,
cast(0 as DECIMAL(18,2)) as daily_forecast  
FROM
IDENTIFIER(:V_PortfolioCombine_6) a
LEFT JOIN
IDENTIFIER(:V_forecast_final_2025) f
ON
a.interaction_date >= f.week AND a.interaction_date < DATEADD(DAY, 7, f.week)
WHERE
fcst_group IN (''PORTFOLIO'') and Campaign_Detail in 
(select  Campaign_Detail 
from IDENTIFIER(:V_genesys_fcst_2025_ingest)
group by Campaign_Detail 
having sum(FCST)= 0
)
ORDER BY
a.interaction_date;

V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_fcst_group_Portfolio2) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);		


V_STEP := ''STEP34'';
   
V_STEP_NAME := ''Loading table sales_accntble_call_fcst_group_Portfolio'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
create or replace table IDENTIFIER(:V_fcst_group_Portfolio) COPY GRANTS AS
	 select *
	 from IDENTIFIER(:V_fcst_group_Portfolio1 )
UNION
	 select *
	 from IDENTIFIER(:V_fcst_group_Portfolio2)
;

V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_fcst_group_Portfolio) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);									 


V_STEP := ''STEP35'';
   
V_STEP_NAME := ''Loading table sales_accntble_call_combine_all_2025'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
create or replace table IDENTIFIER(:V_combine_all_2025) COPY GRANTS as
	 select *
	 from IDENTIFIER(:V_fcst_group_DRTV) 
UNION ALL
	 select *
	 from IDENTIFIER(:V_fcst_group_Portfolio) 
 UNION ALL
	 select *
	 from IDENTIFIER(:V_fcst_group_medsup_other_combine);

V_ROWS_LOADED := (SELECT count(*) FROM IDENTIFIER(:V_combine_all_2025) ) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   

   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);






EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'',  :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);


RAISE;

END;

';