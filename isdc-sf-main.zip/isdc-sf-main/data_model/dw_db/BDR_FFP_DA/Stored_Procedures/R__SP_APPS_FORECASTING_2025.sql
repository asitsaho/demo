USE SCHEMA BDR_FFP_DA;


CREATE OR REPLACE PROCEDURE SP_APPS_FORECASTING_2025("PIPELINE_ID" VARCHAR(16777216), "PIPELINE_NAME" VARCHAR(16777216), "DB_NAME" VARCHAR(16777216), "UTIL_SC" VARCHAR(16777216), "TGT_SC" VARCHAR(16777216), "TGT2_SC" VARCHAR(16777216), "SRC_SC" VARCHAR(16777216), "SRC2_SC" VARCHAR(16777216), "SRC3_SC" VARCHAR(16777216), "SRC4_SC" VARCHAR(16777216), "WH" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

V_STEP             			   VARCHAR;
V_LAST_QUERY_ID    			   VARCHAR;
V_ROWS_LOADED      			   VARCHAR;
V_START_TIME       			   VARCHAR;
V_SP_PROCESS_RUN_LOGS_DTL      VARCHAR := :DB_NAME||''.''||COALESCE(:UTIL_SC, ''UTIL'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';
V_PROCESS_NAME                 VARCHAR DEFAULT ''apps_forecasting'';
V_SUB_PROCESS_NAME             VARCHAR DEFAULT ''apps_forecasting'';
V_STEP_NAME                    VARCHAR;
V_ROWS_PARSED                  INTEGER;
V_FILE_QUERY                   VARCHAR;
V_CURRENT_DATE                 DATE := COALESCE(CURRENT_DATE(), CURRENT_DATE());

V_apps_dt_0                    VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT2_SC, ''BDR_FFP_DA_WRK'') || ''.apps_frcst_wkly_dt_0'';
V_apps_dt_1_0                  VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT2_SC, ''BDR_FFP_DA_WRK'') || ''.apps_frcst_wkly_dt_1_0'';
V_apps_dt_2                    VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT2_SC, ''BDR_FFP_DA_WRK'') || ''.apps_frcst_wkly_dt_2'';
V_apps_dt_3                    VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT2_SC, ''BDR_FFP_DA_WRK'') || ''.apps_frcst_wkly_dt_3'';
V_apps_dt_3_2                  VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT2_SC, ''BDR_FFP_DA_WRK'') || ''.apps_frcst_wkly_dt_3_2'';
V_apps_dt_4                    VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT2_SC, ''BDR_FFP_DA_WRK'') || ''.apps_frcst_wkly_dt_4'';
V_apps_dt_4_2                  VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT2_SC, ''BDR_FFP_DA_WRK'') || ''.apps_frcst_wkly_dt_4_2'';
V_apps_dt_5                    VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT2_SC, ''BDR_FFP_DA_WRK'') || ''.apps_frcst_wkly_dt_5'';
V_ealliance_map                VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT2_SC, ''BDR_FFP_DA_WRK'') || ''.apps_frcst_wkly_ealliance_map'';
V_apps_dt_5_1                  VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT2_SC, ''BDR_FFP_DA_WRK'') || ''.apps_frcst_wkly_5_1'';

V_apps_dt_6_1                  VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT2_SC, ''BDR_FFP_DA_WRK'') || ''.apps_frcst_wkly_dt_6_1'';
V_apps_dt_6_2                  VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT2_SC, ''BDR_FFP_DA_WRK'') || ''.apps_frcst_wkly_dt_6_2'';
V_tst1                         VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT2_SC, ''BDR_FFP_DA_WRK'') || ''.apps_frcst_wkly_tst1'';
V_apps_dt_6                    VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT2_SC, ''BDR_FFP_DA_WRK'') || ''.apps_frcst_wkly_dt_6'';
V_apps_dt_7                    VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT2_SC, ''BDR_FFP_DA_WRK'') || ''.apps_frcst_wkly_dt_7'';
V_apps_dt_7_1                  VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT2_SC, ''BDR_FFP_DA_WRK'') || ''.apps_frcst_wkly_dt_7_1'';

V_apps_smzd_daily_nodup_0      VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT2_SC, ''BDR_FFP_DA_WRK'') || ''.apps_frcst_wkly_smzd_daily_nodup_0'';
V_apps_smzd_daily_nodup_1      VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT2_SC, ''BDR_FFP_DA_WRK'') || ''.apps_frcst_wkly_smzd_daily_nodup_1'';
V_apps_smzd_daily_nodup        VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT2_SC, ''BDR_FFP_DA_WRK'') || ''.apps_frcst_wkly_smzd_daily_nodup'';
V_apps_smzd_daily_nodup_final  VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT2_SC, ''BDR_FFP_DA_WRK'') || ''.apps_frcst_wkly_smzd_daily_nodup_final'';

V_daily_forecast_all_0         VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT2_SC, ''BDR_FFP_DA_WRK'') || ''.apps_frcst_wkly_forecast_all_0'';
V_daily_forecast_all_0_1       VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT2_SC, ''BDR_FFP_DA_WRK'') || ''.apps_frcst_wkly_forecast_all_0_1'';
V_daily_forecast_all_1         VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT2_SC, ''BDR_FFP_DA_WRK'') || ''.apps_frcst_wkly_forecast_all_1'';
V_daily_forecast_all_2         VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT2_SC, ''BDR_FFP_DA_WRK'') || ''.apps_frcst_wkly_forecast_all_2'';

V_daily_forecast_bckup         VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'')      || ''.apps_frcst_wkly_forecast_2025_bckup'';
V_daily_forecast_rw            VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'')      || ''.apps_frcst_wkly_forecast_2025_rw '';
V_daily_dashboard_summary	   VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'')      || ''.apps_frcst_wkly_dashboard_summary_2025'';

V_qc_file                      VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'')     || ''.apps_frcst_wkly_2025_qc_file'';
V_qc_file2                     VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'')     || ''.apps_frcst_wkly_2025_qc_file2'';

-- SOURCE Tables
V_REFINED_MPO_APPS_RPTG_DAILY        VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC4_SC, ''SRC_MPO'') 		|| ''.APPS_RPTG_DAILY'';  -- PROD
--V_REFINED_MPO_APPS_RPTG_DAILY      VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT2_SC, ''BDR_FFP_DA_WRK'') || ''.APPS_RPTG_DAILY'';  -- NON-PROD
V_DTC_GROUPTWO_MAPPING_2022          VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') 		|| ''.DTC_GROUPTWO_MAPPING_2022''; --prod
--V_DTC_GROUPTWO_MAPPING_2022        VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC4_SC, ''SRC_MPO'') 		|| ''.DTC_GROUPTWO_MAPPING_2022''; --NOn-PROD

--v_daily_forecast_ref3              VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT2_SC, ''BDR_FFP_DA_WRK'') || ''.DAILY_FORECAST_FINAL_2025''; -- NON-Prod
v_daily_forecast_ref3                VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'')      || ''.DAILY_FORECAST_FINAL_2025''; --PROD

V_REFINED_POLICY_APPLICATION_AGENT   VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC2_SC, ''BDR_SMART'') 		|| ''.APPLICATION_AGENT'';
V_BDR_CONF_D_AGT                     VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC3_SC, ''BDR_CONF'') 		|| ''.D_AGT'';
V_EALLIANCE                          VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC4_SC, ''SRC_MPO'') 		|| ''.EALLIANCE'';
V_STATE_STRATEGIES_2023              VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC4_SC, ''SRC_MPO'') 		|| ''.STATE_STRATEGIES_2023'';
V_REFINED_POLICY_APPLICATION         VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC2_SC, ''BDR_SMART'') 		|| ''.APPLICATION'';

BEGIN

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP1'';

V_STEP_NAME :=  ''CREATE TABLE apps_dt_0'';

V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_apps_dt_0) COPY GRANTS AS 
SELECT person_id,
application_id,
source_application_id, 
Rptg_EFFECTIVE_DATE,
APPL_RECEIPT_DATE,
((year(Rptg_EFFECTIVE_DATE)*100)+month(Rptg_EFFECTIVE_DATE)) as year_mon,
(case when Mktg_Chnl_grp in (''Unknown'', ''UNKNOWN'', '''', ''DTC'') then ''DTC''
when Mktg_Chnl_grp = ''Agent Aggr'' then  ''Aggregator''
when Mktg_Chnl_grp = ''Agent FTF'' then ''Agent''
when Mktg_Chnl_grp = ''GRS'' then ''Employer'' else ''CHECK'' end) as Mktg_Chnl_grp,
response_id,
source_code,
RELATED_RESPONSE_ID,
rptg_adv_channel,
rptg_ad_type_name,
rptg_comm_medium_name,
rptg_component_desc,
rptg_portfolio_flag,
rptg_solicitation_category,
rptg_solicitation_channel,
enrollment_process,
max(b.sale) as sale,
max(b.app) as app,
MARKETING_CHANNEL,
STATE_CODE,
Mktg_Chnl_Dtl_grp,
Mktg_Chnl_Dtl,
Campaign_Grp,
RELATED_COMM_MEDIUM_NAME,
COMM_MEDIUM_NAME,
Mktg_Chnl_grp as Mktg_Chnl_grp_O,
ATTRIBUTION_TYPE,
campaign_name,
initiating_vendor_name,
ENROLLMENT_CALL_CENTER_SOURCE,
Enrollment,
(case when floor(age_at_eff) <65 then ''<65'' 
when floor(age_at_eff) =65 then ''65'' 
when (floor(age_at_eff) >65 and floor(age_at_eff) <=69) then ''66-69'' 
when (floor(age_at_eff) >69 and floor(age_at_eff) <=74) then ''70-74''
when (floor(age_at_eff) >74 and floor(age_at_eff) <=79) then ''75-79''
when floor(age_at_eff) >79  then ''80+''
end) as age,
(case when CAST(MONTHS_BETWEEN(rptg_effective_date::DATE, birth_date::DATE) AS INT) < 779 then ''Y'' else ''N'' end) as  disabled_sales_flag ,
app_gender_code as gender,	
influence,
(case when CAST(MONTHS_BETWEEN(medb_date::DATE, birth_date::DATE) AS INT) < 779 then ''Y'' else ''N'' end) as PartB_eff_Age_Lessthan65,
plan_code,
rptg_adv_channel_grp,
rptg_response_id,
rptg_source_code,
(case when STATE_CODE in (''FL'',''GA'',''ID'',''MO'',''NH'') then ''Entry Age Rated''
when STATE_CODE in (''AS'',''AR'',''CT'',''GU'',''ME'',''MN'',''NY'',''VI'',''VT'',''WA'') then ''Community Rated''
else ''CREEED'' end) as st_group_rtng			
from IDENTIFIER(:v_REFINED_MPO_APPS_RPTG_DAILY) as b 
where year(b.Rptg_EFFECTIVE_DATE) = 2025
and Plan_Grp not in (''Rider'')
and MS_Insured_at_app = ''N''
group by person_id,
application_id,
source_application_id,
Rptg_EFFECTIVE_DATE,
APPL_RECEIPT_DATE,
((year(b.Rptg_EFFECTIVE_DATE)*100)+month(b.Rptg_EFFECTIVE_DATE)),
(case when b.Mktg_Chnl_grp in (''Unknown'', ''UNKNOWN'','''', ''DTC'') then ''DTC''
when b.Mktg_Chnl_grp = ''Agent Aggr'' then  ''Aggregator''
when b.Mktg_Chnl_grp = ''Agent FTF'' then ''Agent''
when b.Mktg_Chnl_grp = ''GRS'' then ''Employer'' else ''CHECK'' end),
response_id,
source_code,
RELATED_RESPONSE_ID,
rptg_adv_channel,
rptg_ad_type_name,
rptg_comm_medium_name,
rptg_component_desc,
rptg_portfolio_flag,
rptg_solicitation_category,
rptg_solicitation_channel,
enrollment_process,
MARKETING_CHANNEL,
STATE_CODE,
Mktg_Chnl_Dtl_grp,
Mktg_Chnl_Dtl,
Campaign_Grp,
RELATED_COMM_MEDIUM_NAME,
COMM_MEDIUM_NAME,
Mktg_Chnl_grp,
ATTRIBUTION_TYPE,
campaign_name,
initiating_vendor_name,
ENROLLMENT_CALL_CENTER_SOURCE,
Enrollment,
(case when floor(age_at_eff) <65 then ''<65'' 
when floor(age_at_eff) =65 then ''65'' 
when (floor(age_at_eff) >65 and floor(age_at_eff) <=69) then ''66-69'' 
when (floor(age_at_eff) >69 and floor(age_at_eff) <=74) then ''70-74''
when (floor(age_at_eff) >74 and floor(age_at_eff) <=79) then ''75-79''
when floor(age_at_eff) >79  then ''80+''
end),
(CASE WHEN CAST(MONTHS_BETWEEN(rptg_effective_date::DATE, birth_date::DATE) AS INT) < 779 THEN ''Y'' ELSE ''N'' END),
app_gender_code,	
influence,
(CASE WHEN CAST(MONTHS_BETWEEN(medb_date::DATE, birth_date::DATE) AS INT) < 779 THEN ''Y'' ELSE ''N'' END),
plan_code,
rptg_adv_channel_grp,
rptg_response_id,
rptg_source_code,
(case when STATE_CODE in (''FL'',''GA'',''ID'',''MO'',''NH'') then ''Entry Age Rated''
when STATE_CODE in (''AS'',''AR'',''CT'',''GU'',''ME'',''MN'',''NY'',''VI'',''VT'',''WA'') then ''Community Rated''
else ''CREEED'' end);

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:v_apps_dt_0)) ;

CALL IDENTIFIER(:v_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

    

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP2'';

V_STEP_NAME :=  ''CREATE TABLE apps_dt_1_0'';

V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());	

CREATE OR REPLACE TABLE IDENTIFIER(:v_apps_dt_1_0) COPY GRANTS AS 
SELECT a.*
from (select a.*,row_number() over (partition by a.person_id, a.rptg_effective_date order by a.appl_receipt_date desc) as rowNum
from IDENTIFIER(:v_apps_dt_0) a
order by a.application_id, a.APPL_RECEIPT_DATE desc) a 
where rowNum = 1;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:v_apps_dt_1_0)) ;

CALL IDENTIFIER(:v_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP3'';

V_STEP_NAME :=  ''CREATE TABLE apps_dt_2'';

V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:v_apps_dt_2) COPY GRANTS AS 
select a.*,
b.PROMOTION_CODE as app_PROMOTION_CODE
from IDENTIFIER(:v_apps_dt_1_0) as a
left join IDENTIFIER(:V_REFINED_POLICY_APPLICATION) as b
on a.APPLICATION_ID = b.APPLICATION_ID 
and a.person_id = b.person_id;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:v_apps_dt_2)) ;

CALL IDENTIFIER(:v_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP4'';

V_STEP_NAME :=  ''CREATE TABLE apps_dt_3'';

V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:v_apps_dt_3) COPY GRANTS AS 
select a.*, 
b.agent_id as agt_id
from IDENTIFIER(:v_apps_dt_2) a 
left join IDENTIFIER(:v_refined_policy_APPLICATION_AGENT) b 
on  a.application_id = b.application_id;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:v_apps_dt_3)) ;

CALL IDENTIFIER(:v_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP5'';

V_STEP_NAME :=  ''CREATE TABLE apps_dt_3_2'';

V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:v_apps_dt_3_2) COPY GRANTS AS 
select a.*
from (select a.*,row_number() over (partition by a.person_id, a.rptg_effective_date order by a.appl_receipt_date desc) as rowNum1
from IDENTIFIER(:v_apps_dt_3) a
order by a.application_id, a.APPL_RECEIPT_DATE desc) a 
where rowNum1 = 1;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:v_apps_dt_3_2)) ;

CALL IDENTIFIER(:v_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP6'';

V_STEP_NAME :=  ''CREATE TABLE apps_dt_4'';

V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:v_apps_dt_4) COPY GRANTS AS 
select a.*,b.pty_id ,b.ealliance_pref_nm 
from IDENTIFIER(:v_apps_dt_3_2) as a 
left join (select distinct pty_id, agt_id,ealliance_pref_nm,ROW_EFF_STRT_DT from IDENTIFIER(:V_BDR_CONF_D_AGT)) as b 
on a.agt_id = b.agt_id;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:v_apps_dt_4)) ;

CALL IDENTIFIER(:v_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP7'';

V_STEP_NAME :=  ''CREATE TABLE apps_dt_4_2'';

V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:v_apps_dt_4_2) COPY GRANTS AS 
select a.*
from (select a.*,row_number() over (partition by a.person_id, a.rptg_effective_date order by a.appl_receipt_date desc) as rowNum2
from IDENTIFIER(:v_apps_dt_4) a
order by a.application_id, a.APPL_RECEIPT_DATE desc) a
where rowNum2 = 1;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:v_apps_dt_4_2)) ;

CALL IDENTIFIER(:v_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP8'';

V_STEP_NAME :=  ''CREATE TABLE apps_dt_5'';

V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:v_apps_dt_5) COPY GRANTS AS 
select *,
(case when enrollment_process in (''CUSTOMER MAILED APPLICATION'',''CUSTOMER BEGAN WEB ENROLL - MAILED APP'') then ''Cust Mailed''
when enrollment_process in (''TSR: APP ASSIST PHONE ENROLLMENT'', ''TSR:APP ASSIST DIGITAL ENROLLMENT'') then ''App Assist''
when enrollment_process in (''TSR: VOICE SIGNATURE PHONE ENROLLMENT'') then ''Voice Sign''
when enrollment_process in (''CUSTOMER WEB ENROLLMENT'') then ''Cust OLE''
when enrollment_process in (''TSR: PLAN CHANGE PHONE'',''OPERATIONS - PLAN CHANGE GENERATED VIA UI'',''AGENT FIELDS: PLAN CHANGE'') then ''Plan Change''
when enrollment_process in (''AGENT ELECTRONIC WEB ENROLLMENT'') then ''Aggr Web''
when enrollment_process in (''APP ASSIST - AGENT COVERAGE'') then ''Agent App Assist''
when enrollment_process in (''AGENT: MAILED APP'') then ''Agent Mailed''
when enrollment_process in (''AGENT: WEB ENROLLMENT'')  then ''Agent OLE''
when enrollment_process in (''OPERATIONS - UNKNOWN CHANNEL - GENERATED VIA UI'',''AGENT: CHANNEL UNK -  UI'') then ''Other''
when enrollment_process in (''INVALID'') then ''Other''
else ''CHECK'' end) as enrollment_type
from IDENTIFIER(:v_apps_dt_4_2);

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:v_apps_dt_5)) ;

CALL IDENTIFIER(:v_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP9'';

V_STEP_NAME :=  ''CREATE TABLE ealliance_map'';

V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:v_ealliance_map) COPY GRANTS AS 
select pty_id,agt_id,e_alliance_partner_name,nickname,
(case when e_alliance_old_category in (''eAlliance - Retail'') then ''ealliance-Retail'' else e_alliance_old_category end) as e_alliance_old_category,
(case when e_alliance_new_category in (''eAlliance - Retail'') then ''ealliance-Retail'' else e_alliance_new_category end) as e_alliance_new_category
from IDENTIFIER(:V_EALLIANCE);

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:v_ealliance_map)) ;

CALL IDENTIFIER(:v_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP10'';

V_STEP_NAME :=  ''CREATE TABLE apps_dt_5_1'';

V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:v_apps_dt_5_1) COPY GRANTS AS 
select a.*, b.e_alliance_old_category
from IDENTIFIER(:v_apps_dt_5) a 
left join IDENTIFIER(:v_ealliance_map) b 
on a.pty_id = b.pty_id and a.agt_id = b.agt_id;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:v_apps_dt_5_1)) ;

CALL IDENTIFIER(:v_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP11'';

V_STEP_NAME :=  ''CREATE TABLE apps_frcst_apps_dt_6_1'';

V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:v_apps_dt_6_1) COPY GRANTS AS 
select *,
(case when agt_id in (''SQS3333'',''SQS4444'') then ''DTC''
when agt_id in (''SQS2222'',''GOH2222'',''INS2222'',''EHC2222'',''SQA2222'') then ''DTC''
when Mktg_Chnl_grp =''UNKNOWN'' then ''DTC''
when e_alliance_old_category <> '''' then e_alliance_old_category
when Mktg_Chnl_grp =''Aggregator'' and (e_alliance_old_category = '''' or e_alliance_old_category is null) then ''ealliance-Others'' 
else Mktg_Chnl_grp end) as mktng_channel
from IDENTIFIER(:v_apps_dt_5_1);

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:v_apps_dt_6_1)) ;

CALL IDENTIFIER(:v_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP12'';

V_STEP_NAME :=  ''CREATE TABLE apps_dt_6_2'';

V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:v_apps_dt_6_2) COPY GRANTS AS 
select *, 
(case when TRIM(REGEXP_SUBSTR(MARKETING_CHANNEL,''.*\-(.*)'',1)) = ''TELEQUOTE'' then ''E-TELEQUOTE''
else TRIM(REGEXP_SUBSTR(MARKETING_CHANNEL,''.*\-(.*)'',1)) end) as agt_nm
from IDENTIFIER(:v_apps_dt_6_1);

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:v_apps_dt_6_2)) ;

CALL IDENTIFIER(:v_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP13'';

V_STEP_NAME :=  ''CREATE TABLE tst1'';

V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:v_tst1) COPY GRANTS AS 
select distinct LOWER(TRIM(e_alliance_partner_name)) as nm, e_alliance_old_category
from IDENTIFIER(:v_ealliance_map)
where e_alliance_old_category <> ''Lead Captive''
union 
select distinct LOWER(TRIM(nickname)) as nm, e_alliance_old_category
from IDENTIFIER(:v_ealliance_map)
where e_alliance_old_category <> ''Lead Captive'';

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:v_tst1)) ;

CALL IDENTIFIER(:v_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';


V_STEP := ''STEP14'';

V_STEP_NAME :=  ''CREATE TABLE apps_frcst_apps_dt_6'';

V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE or REPLACE TABLE IDENTIFIER(:v_apps_dt_6) COPY GRANTS AS 
select a.*, (case when mktng_channel = ''ealliance-Others'' and nm <> '''' then e_alliance_old_category_1 else mktng_channel end) as mkt_chnl_2
from (select a.*, b.nm, b.e_alliance_old_category as e_alliance_old_category_1
from IDENTIFIER(:v_apps_dt_6_2) a
left join (SELECT DISTINCT * from  IDENTIFIER(:v_tst1) where nm <> '''') b 
on LOWER(TRIM(a.agt_nm)) = b.nm) a;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:v_apps_dt_6)) ;

CALL IDENTIFIER(:v_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP15'';

V_STEP_NAME :=  ''CREATE TABLE apps_dt_7'';

V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_apps_dt_7) COPY GRANTS AS 
select *, 
(case when agt_id in (''SQS3333'',''SQS4444'') then ''SQS_VS'' 
when agt_id in (''SQS2222'',''GOH2222'',''INS2222'',''EHC2222'',''SQA2222'') then ''MA-Leads_Captives''
when Enrollment = ''Application Assistance'' and ENROLLMENT_CALL_CENTER_SOURCE = ''CSS'' then ''Optum AS''
when Enrollment = ''Application Assistance'' and ENROLLMENT_CALL_CENTER_SOURCE = ''UCC'' then ''UCC_AS''
when Enrollment = ''Voice Signature'' and ENROLLMENT_CALL_CENTER_SOURCE = ''CSS'' then ''Optum VS''
when Enrollment = ''Voice Signature'' and ENROLLMENT_CALL_CENTER_SOURCE = ''UCC'' then ''UCC_VS''
when mkt_chnl_2 = ''Agent'' and enrollment_type in (''Agent Mailed'', ''Agent OLE'') then enrollment_type
when mkt_chnl_2 = ''DTC'' and enrollment = (''Customer Mailed App'') then ''Cust Mailed''
when mkt_chnl_2 = ''DTC'' and enrollment = (''Customer OLE'') then ''Cust OLE''
when mkt_chnl_2 = ''ealliance-Classic'' and  enrollment = (''Agent Aggr'') then ''Aggr Web''
when mkt_chnl_2 = ''ealliance-Retail'' and enrollment = (''Agent Aggr'') then ''Aggr Web''
when mkt_chnl_2 = ''ealliance-Others'' then ''Others''
when mkt_chnl_2 = ''Employer'' and enrollment = (''Customer Mailed App'') then ''Cust Mailed''
when mkt_chnl_2 = ''Employer'' and enrollment = (''Customer OLE'') then ''Cust OLE''
else ''Others'' end) as sub_channel
from IDENTIFIER(:v_apps_dt_6);

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:v_apps_dt_7)) ;

CALL IDENTIFIER(:v_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP16'';

V_STEP_NAME :=  ''CREATE TABLE apps_dt_7_1'';

V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_apps_dt_7_1) COPY GRANTS AS
select a.*
from (select a.*,row_number() over (partition by a.person_id,a.rptg_effective_date order by a.appl_receipt_date desc) as rowNum0
from IDENTIFIER(:V_apps_dt_7) a
order by a.application_id, a.Rptg_EFFECTIVE_DATE desc) a
where rowNum0 = 1;


V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:V_apps_dt_7_1)) ;

CALL IDENTIFIER(:v_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP17'';

V_STEP_NAME :=  ''CREATE TABLE apps_smzd_daily_nodup_0'';

V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:v_apps_smzd_daily_nodup_0) COPY GRANTS AS 
select *, 
(case when mkt_chnl_2 = ''Agent'' then ''Agent''
when mkt_chnl_2 = ''Employer'' then ''Employer''
when mkt_chnl_2 = ''ealliance-Retail'' then ''ealliance-Retail''
when mkt_chnl_2 = ''ealliance-Classic'' then ''ealliance-Classic''
when mkt_chnl_2 = ''ealliance-Others'' then ''ealliance-Others''
when mkt_chnl_2 = ''DTC'' and sub_channel in (''UCC_AS'',''UCC_VS'') then ''DTC-UCC''
when mkt_chnl_2 = ''DTC'' then concat(mkt_chnl_2,''-'',sub_channel) else ''chk'' end) as cat
from IDENTIFIER(:V_apps_dt_7_1);


V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:v_apps_smzd_daily_nodup_0)) ;

CALL IDENTIFIER(:v_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP18'';

V_STEP_NAME :=  ''CREATE TABLE apps_smzd_daily_nodup_1'';

V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:v_apps_smzd_daily_nodup_1) COPY GRANTS AS 
select year_mon as Mon,
APPL_RECEIPT_DATE, 
mkt_chnl_2,
cat,
STATE_CODE,
Mktg_Chnl_Dtl_grp,
Mktg_Chnl_Dtl
,age
,disabled_sales_flag
,gender
,Influence
,PartB_eff_Age_Lessthan65
,PLAN_CODE
,Rptg_Adv_Channel
,Rptg_Adv_Channel_grp
,rptg_ad_type_name
,rptg_comm_medium_name
,rptg_component_desc
,rptg_portfolio_flag
,Rptg_Response_ID
,rptg_solicitation_category
,rptg_solicitation_channel
,Rptg_Source_Code
,st_group_rtng
,Campaign_Grp
,RELATED_COMM_MEDIUM_NAME
,COMM_MEDIUM_NAME
,Mktg_Chnl_grp_O
,ATTRIBUTION_TYPE
,CAMPAIGN_NAME
,INITIATING_VENDOR_NAME
,sum(app) as submitted_apps					   
from IDENTIFIER(:v_apps_smzd_daily_nodup_0)
group by year_mon,
APPL_RECEIPT_DATE, 
mkt_chnl_2,
cat,
STATE_CODE
,Mktg_Chnl_Dtl_grp
,Mktg_Chnl_Dtl
,age
,disabled_sales_flag
,gender
,Influence
,PartB_eff_Age_Lessthan65
,PLAN_CODE
,Rptg_Adv_Channel
,Rptg_Adv_Channel_grp
,rptg_ad_type_name
,rptg_comm_medium_name
,rptg_component_desc
,rptg_portfolio_flag
,Rptg_Response_ID
,rptg_solicitation_category
,rptg_solicitation_channel
,Rptg_Source_Code
,st_group_rtng
,Campaign_Grp
,RELATED_COMM_MEDIUM_NAME
,COMM_MEDIUM_NAME
,Mktg_Chnl_grp_O
,ATTRIBUTION_TYPE
,CAMPAIGN_NAME
,INITIATING_VENDOR_NAME;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:v_apps_smzd_daily_nodup_1)) ;

CALL IDENTIFIER(:v_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP19'';

V_STEP_NAME :=  ''CREATE TABLE apps_smzd_daily_nodup'';

V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:v_apps_smzd_daily_nodup) COPY GRANTS AS 
select *, 
(case when APPL_RECEIPT_DATE <= cast(''2024-09-30'' as date) then cast(''2024-09-30'' as date)
when Mon = 202501 and APPL_RECEIPT_DATE >= cast(''2025-02-28'' as date) then cast(''2025-02-28'' as date)--leap year date change
when Mon = 202502 and APPL_RECEIPT_DATE >= cast(''2025-03-31'' as date) then cast(''2025-03-31'' as date)
when Mon = 202503 and APPL_RECEIPT_DATE >= cast(''2025-04-30'' as date) then cast(''2025-04-30'' as date) 
when Mon = 202504 and APPL_RECEIPT_DATE >= cast(''2025-05-31'' as date) then cast(''2025-05-31'' as date)
when Mon = 202505 and APPL_RECEIPT_DATE >= cast(''2025-06-30'' as date) then cast(''2025-06-30'' as date)
when Mon = 202506 and APPL_RECEIPT_DATE >= cast(''2025-07-31'' as date) then cast(''2025-07-31'' as date) 
when Mon = 202507 and APPL_RECEIPT_DATE >= cast(''2025-08-31'' as date) then cast(''2025-08-31'' as date)
when Mon = 202508 and APPL_RECEIPT_DATE >= cast(''2025-09-30'' as date) then cast(''2025-09-30'' as date)
when Mon = 202509 and APPL_RECEIPT_DATE >= cast(''2025-10-31'' as date) then cast(''2025-10-31'' as date)
when Mon = 202510 and APPL_RECEIPT_DATE >= cast(''2025-11-30'' as date) then cast(''2025-11-30'' as date)
when Mon = 202511 and APPL_RECEIPT_DATE >= cast(''2025-12-31'' as date) then cast(''2025-12-31'' as date)
when Mon = 202512 and APPL_RECEIPT_DATE >= cast(''2025-12-31'' as date) then cast(''2025-12-31'' as date)
else APPL_RECEIPT_DATE end) as APPL_RECEIPT_DATE_1
from IDENTIFIER(:v_apps_smzd_daily_nodup_1);

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:v_apps_smzd_daily_nodup)) ;

CALL IDENTIFIER(:v_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP20'';

V_STEP_NAME :=  ''CREATE TABLE apps_smzd_daily_nodup_final'';

V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:v_apps_smzd_daily_nodup_final) COPY GRANTS AS 
select a.*, 
(case when cat = ''Agent'' then ''Agent''
when cat = ''ealliance-Retail'' then ''ealliance-Retail''
when cat = ''ealliance-Classic'' then ''ealliance-Classic''
when cat = ''ealliance-Others'' then ''ealliance-Others''
when cat = ''Employer'' then ''Employer'' else ''DTC'' end) as marketing_channel,
(case when cat = ''DTC-Cust Mailed'' then  ''Cust Mailed''
when cat = ''DTC-Others'' then ''Others''
when cat = ''DTC-Cust OLE'' then ''Cust OLE''
when cat = ''DTC-MA-Leads_Captives'' then ''MA-Leads_Captives''
when cat = ''DTC-Optum AS'' then ''Optum AS''
when cat = ''DTC-Optum VS'' then ''Optum VS''
when cat = ''DTC-UCC'' then ''UCC''
else '''' end) as sub_channel 
from IDENTIFIER(:v_apps_smzd_daily_nodup) a
where STATE_CODE not in (''ZZ'',''XX'');


V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:v_apps_smzd_daily_nodup_final)) ;

CALL IDENTIFIER(:v_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP21'';

V_STEP_NAME :=  ''CREATE TABLE daily_forecast_all_0'';

V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:v_daily_forecast_all_0) COPY GRANTS AS 
SELECT
CAST(a.mon as INTEGER) as mon,
a.state_cd,
cast(application_date as date) as application_date,
marketing_channel,
sub_channel,
a.cat, 
COALESCE(cast(forecast_final as float),0) as forecast,
COALESCE(cast(active_goals_st as float),0) as active_goals_st,
COALESCE(cast(apps_prev_yr as float), 0) as apps_prev,
(case when sub_channel = ''UCC'' then ''Federal Telesales''
when sub_channel = ''MA-Leads_Captives'' then ''MA Lead Captive'' 
else sub_channel end) as sub_channel_final,
0 as actual, 
mktg_chnl_dtl_grp,
mktg_chnl_dtl,
age,
disabled_sales_flag,
gender,
influence,
partb_eff_age_lessthan65,
plan_code,
rptg_adv_channel_grp,
rptg_adv_channel,
rptg_ad_type_name,
Rptg_COMM_MEDIUM_NAME,
Rptg_COMPONENT_DESC,
Rptg_Portfolio_Flag,
Rptg_SOLICITATION_CATEGORY,
Rptg_SOLICITATION_CHANNEL,
cast(rptg_response_id as bigint) as rptg_response_id,
rptg_source_code,
Campaign_Grp,
RELATED_COMM_MEDIUM_NAME,
COMM_MEDIUM_NAME,
Mktg_Chnl_grp_O, 
ATTRIBUTION_TYPE,
CAMPAIGN_NAME,
INITIATING_VENDOR_NAME,
st_group_rtng
from IDENTIFIER(:v_daily_forecast_ref3) a
union all
SELECT
cast(mon as INTEGER),
state_code as state_cd,
appl_receipt_date_1 as application_date,
marketing_channel,
sub_channel,
cat,
0 as forecast,
0 as active_goals_st,
0 as apps_prev,
(case when sub_channel = ''UCC'' then ''Federal Telesales''
when sub_channel = ''MA-Leads_Captives'' then ''MA Lead Captive'' else sub_channel end) as sub_channel_final,
COALESCE(submitted_apps, 0) as actual, 
mktg_chnl_dtl_grp,
mktg_chnl_dtl,
age,
disabled_sales_flag,
gender,
influence,
partb_eff_age_lessthan65,
plan_code,
rptg_adv_channel_grp,
rptg_adv_channel,
rptg_ad_type_name,
Rptg_COMM_MEDIUM_NAME,
Rptg_COMPONENT_DESC,
Rptg_Portfolio_Flag,
Rptg_SOLICITATION_CATEGORY,
Rptg_SOLICITATION_CHANNEL,
rptg_response_id,
rptg_source_code,
Campaign_Grp,
RELATED_COMM_MEDIUM_NAME,
COMM_MEDIUM_NAME,
Mktg_Chnl_grp_O, 
ATTRIBUTION_TYPE,
CAMPAIGN_NAME,
INITIATING_VENDOR_NAME,
st_group_rtng
from IDENTIFIER(:v_apps_smzd_daily_nodup_final);

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:v_daily_forecast_all_0)) ;

CALL IDENTIFIER(:v_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP22'';

V_STEP_NAME :=  ''CREATE TABLE daily_forecast_all_0_1'';

V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:v_daily_forecast_all_0_1) COPY GRANTS AS 
select a.*, 
case when a.Mktg_Chnl_grp_O in (''Unknown'', ''UNKNOWN'','''', ''DTC'') and a.Rptg_Adv_Channel_grp = ''Direct Marketing'' and a.Rptg_Adv_Channel in (''Direct Mail Acq'', ''Email Acq'') and a.Rptg_Portfolio_Flag = ''Y'' then ''DM/EM - CF''
when a.Mktg_Chnl_grp_O in (''Unknown'', ''UNKNOWN'','''', ''DTC'') and a.Rptg_Adv_Channel_grp is not null and a.Rptg_Adv_Channel is not null and a.Rptg_Portfolio_Flag = ''Y'' then concat(b.Group2, '' - CF'')
when a.Mktg_Chnl_grp_O in (''Unknown'', ''UNKNOWN'','''', ''DTC'') and a.Rptg_Adv_Channel_grp is not null and a.Rptg_Adv_Channel is not null and a.Rptg_Portfolio_Flag = ''N'' then b.Group2
when a.Mktg_Chnl_grp_O in (''Unknown'', ''UNKNOWN'','''', ''DTC'') and a.Rptg_Adv_Channel_grp is null and a.Rptg_Adv_Channel is null and lower(a.Mktg_Chnl_Dtl_grp) like ''%inquiry%'' then ''Inquiry''
when a.Mktg_Chnl_grp_O in (''Unknown'', ''UNKNOWN'','''', ''DTC'') and a.Rptg_Adv_Channel_grp is null and a.Rptg_Adv_Channel is null and not(lower(a.Mktg_Chnl_Dtl_grp) like ''%inquiry%'') then ''Other Channels w/out Attrib Media''
else '''' end as GroupTwo
from IDENTIFIER(:v_daily_forecast_all_0) a 
left join IDENTIFIER(:V_DTC_GROUPTWO_MAPPING_2022) b
on lower(trim(a.Rptg_Adv_Channel_grp)) = lower(trim(b.Rptg_Adv_Channel_grp)) and lower(trim(a.Rptg_Adv_Channel)) = lower(trim(b.Rptg_Adv_Channel));


V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:v_daily_forecast_all_0_1)) ;

CALL IDENTIFIER(:v_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP23'';

V_STEP_NAME :=  ''CREATE TABLE daily_forecast_all_1'';

V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:v_daily_forecast_all_1) COPY GRANTS AS 
select Mon,
state_cd,
application_date,
marketing_channel,
sub_channel,
cat,
sub_channel_final,
(case when a.Mktg_Chnl_Dtl_grp = '''' then NULL else a.Mktg_Chnl_Dtl_grp end) as Mktg_Chnl_Dtl_grp,
(case when a.Mktg_Chnl_Dtl = '''' then NULL else a.Mktg_Chnl_Dtl end) as Mktg_Chnl_Dtl,
(case when a.GroupTwo = '''' then NULL else a.GroupTwo end) as GroupTwo,
(case when a.age = '''' then NULL else a.age end) as age,
(case when a.disabled_sales_flag = '''' then NULL else a.disabled_sales_flag end) as disabled_sales_flag,
(case when a.gender = '''' then NULL else a.gender end) as gender,
(case when a.influence = '''' then NULL else a.influence end) as influence,
(case when a.partb_eff_age_lessthan65 = '''' then NULL else a.partb_eff_age_lessthan65 end) as partb_eff_age_lessthan65,
(case when a.plan_code = '''' then NULL else a.plan_code end) as plan_code,
(case when a.rptg_adv_channel_grp = '''' then NULL else a.rptg_adv_channel_grp end) as rptg_adv_channel_grp,
(case when a.rptg_response_id is null then 0 else a.rptg_response_id end) as rptg_response_id,
(case when a.rptg_source_code = '''' then NULL else a.rptg_source_code end) as rptg_source_code,
(case when state_cd in (''FL'',''GA'',''ID'',''MO'',''NH'') then ''Entry Age Rated''
	   when state_cd in (''AS'',''AR'',''CT'',''GU'',''ME'',''MN'',''NY'',''VI'',''VT'',''WA'') then ''Community Rated''
	   else ''CREEED'' end) as st_group_rtng,
(case when a.rptg_adv_channel = '''' then NULL else a.rptg_adv_channel end) as rptg_adv_channel,	   
(case when a.rptg_ad_type_name = '''' then NULL else a.rptg_ad_type_name end) as rptg_ad_type_name,	
(case when a.rptg_comm_medium_name = '''' then NULL else a.rptg_comm_medium_name end) as rptg_comm_medium_name,	
(case when a.rptg_component_desc = '''' then NULL else a.rptg_component_desc end) as rptg_component_desc,
(case when a.rptg_portfolio_flag = '''' then NULL else a.rptg_portfolio_flag end) as rptg_portfolio_flag,
(case when a.rptg_solicitation_category = '''' then NULL else a.rptg_solicitation_category end) as rptg_solicitation_category,
(case when a.rptg_solicitation_channel = '''' then NULL else a.rptg_solicitation_channel end) as rptg_solicitation_channel,
(case when a.campaign_grp = '''' then NULL else a.campaign_grp end) as campaign_grp,
(case when a.related_comm_medium_name = '''' then NULL else a.related_comm_medium_name end) as related_comm_medium_name,
(case when a.comm_medium_name = '''' then NULL else a.comm_medium_name end) as comm_medium_name,
(case when a.attribution_type = '''' then NULL else a.attribution_type end) as attribution_type,
(case when a.campaign_name = '''' then NULL else a.campaign_name end) as campaign_name,
(case when a.initiating_vendor_name = '''' then NULL else a.initiating_vendor_name end) as initiating_vendor_name,
sum(actual) as actual,
sum(apps_prev) as apps_prev,
sum(forecast) as forecast,
sum(active_goals_st) as active_goals_st
from IDENTIFIER(:v_daily_forecast_all_0_1) a 
group by Mon,
state_cd,
application_date,
marketing_channel,
sub_channel,
cat,
sub_channel_final,
(case when a.Mktg_Chnl_Dtl_grp = '''' then NULL else a.Mktg_Chnl_Dtl_grp end),
(case when a.Mktg_Chnl_Dtl = '''' then NULL else a.Mktg_Chnl_Dtl end),
(case when a.GroupTwo = '''' then NULL else a.GroupTwo end),
(case when a.age = '''' then NULL else a.age end),
(case when a.disabled_sales_flag = '''' then NULL else a.disabled_sales_flag end),
(case when a.gender = '''' then NULL else a.gender end),
(case when a.influence = '''' then NULL else a.influence end),
(case when a.partb_eff_age_lessthan65 = '''' then NULL else a.partb_eff_age_lessthan65 end),
(case when a.plan_code = '''' then NULL else a.plan_code end),
(case when a.rptg_adv_channel_grp = '''' then NULL else a.rptg_adv_channel_grp end),
(case when a.rptg_response_id is null then 0 else a.rptg_response_id end),
(case when a.rptg_source_code = '''' then NULL else a.rptg_source_code end),
(case when state_cd in (''FL'',''GA'',''ID'',''MO'',''NH'') then ''Entry Age Rated''
	   when state_cd in (''AS'',''AR'',''CT'',''GU'',''ME'',''MN'',''NY'',''VI'',''VT'',''WA'') then ''Community Rated''
	   else ''CREEED'' end),
(case when a.rptg_adv_channel = '''' then NULL else a.rptg_adv_channel end),	   
(case when a.rptg_ad_type_name = '''' then NULL else a.rptg_ad_type_name end) ,	
(case when a.rptg_comm_medium_name = '''' then NULL else a.rptg_comm_medium_name end),	
(case when a.rptg_component_desc = '''' then NULL else a.rptg_component_desc end),
(case when a.rptg_portfolio_flag = '''' then NULL else a.rptg_portfolio_flag end),
(case when a.rptg_solicitation_category = '''' then NULL else a.rptg_solicitation_category end),
(case when a.rptg_solicitation_channel = '''' then NULL else a.rptg_solicitation_channel end) ,
(case when a.campaign_grp = '''' then NULL else a.campaign_grp end),
(case when a.related_comm_medium_name = '''' then NULL else a.related_comm_medium_name end),
(case when a.comm_medium_name = '''' then NULL else a.comm_medium_name end),
(case when a.attribution_type = '''' then NULL else a.attribution_type end),
(case when a.campaign_name = '''' then NULL else a.campaign_name end),
(case when a.initiating_vendor_name = '''' then NULL else a.initiating_vendor_name end);

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:v_daily_forecast_all_1)) ;

CALL IDENTIFIER(:v_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP24'';

V_STEP_NAME :=  ''CREATE TABLE apps_frcst_daily_forecast_all_2'';

V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:v_daily_forecast_all_2) COPY GRANTS AS 
select a.*, 
b.nle_start_date,
b.nle_wave
from IDENTIFIER(:v_daily_forecast_all_1) a 
left join IDENTIFIER(:V_STATE_STRATEGIES_2023) b
on a.state_cd = b.state_cd;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:v_daily_forecast_all_2)) ;

CALL IDENTIFIER(:v_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP25'';

V_STEP_NAME :=  ''CREATE TABLE daily_forecast_2025_bckup'';

V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:v_daily_forecast_bckup) COPY GRANTS AS 
select a.* 
from IDENTIFIER(:v_daily_forecast_rw) a;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:v_daily_forecast_bckup)) ;

CALL IDENTIFIER(:v_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';


V_STEP := ''STEP26'';

V_STEP_NAME :=  ''CREATE TABLE daily_forecast_rw'';

V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE or REPLACE TABLE IDENTIFIER(:v_daily_forecast_rw) COPY GRANTS AS 
select a.*, b.a as Data_Refresh_Date
from (select * from IDENTIFIER(:v_daily_forecast_all_2) where CAST(mon/100 as INTEGER) <= 2025) a
cross join (select max(application_date) as a from IDENTIFIER(:v_daily_forecast_all_2) where CAST(mon/100 as INTEGER) <= 2025 
and application_date <= DATEADD(''DAY'', -4, current_date) having sum(actual) > 0) b;


V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:v_daily_forecast_rw)) ;

CALL IDENTIFIER(:v_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP27'';

V_STEP_NAME :=  ''CREATE TABLE daily_dashboard_summary'';

V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:v_daily_dashboard_summary) COPY GRANTS AS 
SELECT 
a.mon, marketing_channel,sub_channel_final,a.cat,
a.state_cd,
a.nle_start_date,
a.nle_wave,
sum(active_goals_st)  as active_goals_st,
sum(forecast) as forecast
from IDENTIFIER(:v_daily_forecast_rw) a
group by a.mon, marketing_channel,sub_channel_final,a.cat,
a.state_cd,
a.nle_start_date,
a.nle_wave;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:v_daily_dashboard_summary)) ;

CALL IDENTIFIER(:v_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP28'';

V_STEP_NAME :=  ''CREATE TABLE qc_file'';

V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:v_qc_file) COPY GRANTS AS 
select a.mon, b.cat,a.forecast as forecast, a.actual as actual, a.apps_prev as apps_2024,
b.forecast as forecast_previous, b.actual as actual_previous, b.apps_prev as apps_2024_previous
from
(select mon, cat,sum(forecast) as forecast, sum(actual) as actual, sum(apps_prev) as apps_prev
from IDENTIFIER(:v_daily_forecast_rw)
group by mon,cat) a 
join (select mon, cat,sum(forecast) as forecast, sum(actual) as actual, sum(apps_prev) as apps_prev
from IDENTIFIER(:v_daily_forecast_bckup)
group by mon,cat) b
on a.mon = b.mon and a.cat = b.cat ;


V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:v_qc_file)) ;

CALL IDENTIFIER(:v_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP33'';

V_STEP_NAME :=  ''CREATE TABLE qc_file2'';

V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:v_qc_file2) COPY GRANTS AS 
select a.mon, b.cat,a.forecast as forecast, a.actual as actual, a.apps_prev as apps_2024,
b.forecast as forecast_previous, b.actual as actual_previous, b.apps_prev as apps_2024_previous
from
(select mon, cat,sum(forecast) as forecast, sum(actual) as actual, sum(apps_prev) as apps_prev
from IDENTIFIER(:v_daily_forecast_rw)
where application_date<= data_refresh_date
group by mon,cat) a 
join (select mon, cat,sum(forecast) as forecast, sum(actual) as actual, sum(apps_prev) as apps_prev
from IDENTIFIER(:v_daily_forecast_bckup)
where application_date<= data_refresh_date
group by mon,cat) b
on a.mon = b.mon and a.cat = b.cat ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
V_ROWS_LOADED := (SELECT COUNT(1) FROM IDENTIFIER(:v_qc_file2)) ;



V_FILE_QUERY := ''COPY INTO ''||''@UTIL.STAGE_AZURE_ISDC/analytics/outbox/app_forecasting/summary_2025_apps_forecasting_final_qc_''||:V_CURRENT_DATE||''.csv''||'' FROM (
           select * from BDR_FFP_DA.apps_frcst_wkly_2025_qc_file
               )
file_format = (type = ''''CSV'''' 
               field_delimiter = '''',''''
               record_delimiter = ''''
''''
               compression = None 
               FIELD_OPTIONALLY_ENCLOSED_BY=''''"''''
              )
HEADER = True
OVERWRITE = True
MAX_FILE_SIZE = 4900000000
SINGLE = True''
;

execute immediate  :V_FILE_QUERY;


V_FILE_QUERY := ''COPY INTO ''||''@UTIL.STAGE_AZURE_ISDC/analytics/outbox/app_forecasting/summary_2025_apps_forecasting_final_qc2_''||:V_CURRENT_DATE||''.csv''||'' FROM (
           select * from BDR_FFP_DA.apps_frcst_wkly_2025_qc_file2
               )
file_format = (type = ''''CSV'''' 
               field_delimiter = '''',''''
               record_delimiter = ''''
''''
               compression = None 
               FIELD_OPTIONALLY_ENCLOSED_BY=''''"''''
              )
HEADER = True
OVERWRITE = True
MAX_FILE_SIZE = 4900000000
SINGLE = True''
;

execute immediate  :V_FILE_QUERY;


CALL IDENTIFIER(:v_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


END;
';