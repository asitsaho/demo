USE SCHEMA BDR_FFP_DA;

CREATE OR REPLACE PROCEDURE SP_FINAL_SCORE 
( PIPELINE_ID  varchar,
PIPELINE_NAME varchar,
DB_NAME varchar,
UTIL_SC varchar,
TGT_SC_1 varchar,
TGT_SC_2 varchar,
WH varchar,
STAGE_NAME varchar,
FILE_FORMAT_CSV varchar,
FOLDER_PATH varchar,
CURR_DATE DATE)
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS 
$$
DECLARE

V_CURRENT_DATE   DATE := COALESCE(:CURR_DATE, CURRENT_DATE());

V_DATE_EXT VARCHAR := TO_CHAR(:V_CURRENT_DATE,'YYYY-MM-DD');

V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := :DB_NAME||'.'||COALESCE(:UTIL_SC, 'UTIL')||'.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS';

V_STAGE_NAME VARCHAR := '@'||:UTIL_SC||'.'||:STAGE_NAME;

V_FOLDER_PATH VARCHAR :='analytics/inbox/'||:FOLDER_PATH;

V_FILE_FORMAT_CSV VARCHAR := :UTIL_SC||'.'||:FILE_FORMAT_CSV;

V_INPUT_FILE VARCHAR := 'analytics/outbox/lapser_uplift_model/'||'R_Models/'||'uplift_combo_vars_'||:V_DATE_EXT||'.csv' ;

V_FINAL_FILE VARCHAR := :V_FOLDER_PATH||'/'||'final_export_file.csv';

V_PROCESS_NAME   VARCHAR DEFAULT 'LAPSER_UPLIFT_MODEL';

V_SUB_PROCESS_NAME  VARCHAR DEFAULT 'final_score';

V_STEP             VARCHAR;

V_STEP_NAME        VARCHAR;

V_START_TIME       VARCHAR;

V_END_TIME         VARCHAR;

V_ROWS_PARSED       INTEGER;

V_ROWS_LOADED       INTEGER;

V_MESSAGE          VARCHAR;

V_LAST_QUERY_ID    VARCHAR;


V_UPLIFT_COMBO_VARS VARCHAR := :DB_NAME || '.' || COALESCE(:TGT_SC_2, 'BDR_FFP_DA') || '.RETENTION_UPLIFT_UPLIFT_COMBO_VARS';

V_UPLIFT_COMBO_VARS_RAW VARCHAR := :DB_NAME || '.' || COALESCE(:TGT_SC_1, 'BDR_FFP_DA_WRK') || '.UPLIFT_COMBO_VARS_RAW';

V_UPLIFT_COMBO_VARS_EXPORT VARCHAR := :DB_NAME || '.' || COALESCE(:TGT_SC_2, 'BDR_FFP_DA') || '.RETENTION_UPLIFT_UPLIFT_COMBO_VARS_EXPORT';

V_UPLIFT_COMBO_VARS_FILE VARCHAR := 'uplift_combo_vars_' || :V_DATE_EXT || '.csv' ;

V_COPY_STMT VARCHAR := 'COPY INTO '||:V_UPLIFT_COMBO_VARS_RAW||' FROM '||:V_STAGE_NAME||'/'||:V_INPUT_FILE||' FILE_FORMAT= '||:V_FILE_FORMAT_CSV ;

V_COPY_TOFILE_STMT VARCHAR := 'COPY INTO ' ||:V_STAGE_NAME||'/'||:V_FINAL_FILE || ' from (
select pers_id,147,mdl_scor,case when raw_scor is null or raw_scor=null then '||''''||''''||' else cast(raw_scor as varchar) end as raw_scor,
case when mail_mdl_rnk is null or mail_mdl_rnk=null then '||''''||''''||' else cast(mail_mdl_rnk as varchar) end as mail_mdl_rnk,
case when holdout_mdl_rnk is null or holdout_mdl_rnk=null then '||''''||''''||' else cast(holdout_mdl_rnk as varchar) end as holdout_mdl_rnk,
case when mail_mdl_scor is null or mail_mdl_scor=null then '||''''||''''||' else cast(mail_mdl_scor as varchar) end as mail_mdl_scor,
case when holdout_mdl_scor is null or holdout_mdl_scor=null then '||''''||''''||' else cast(holdout_mdl_scor as varchar) end as holdout_mdl_scor from '||:DB_NAME || '.' ||:TGT_SC_2|| '.RETENTION_UPLIFT_UPLIFT_COMBO_VARS_EXPORT)'||'FILE_FORMAT=(TYPE=CSV FIELD_OPTIONALLY_ENCLOSED_BY = '||''''||'\"'||''''||' compression = None)'||'HEADER=TRUE'|| ' OVERWRITE=TRUE';


BEGIN


EXECUTE IMMEDIATE 'USE WAREHOUSE '||:WH;

ALTER SESSION SET TIMEZONE = 'America/Chicago';

V_STEP := 'STEP1';

V_STEP_NAME :=  'create a table uplift_combo_vars_raw';
   
V_START_TIME := CONVERT_TIMEZONE('America/Chicago', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_UPLIFT_COMBO_VARS_RAW)(
person_id string ,
adj_ben_amt string ,
adj_ben_amt_2yr string ,
age string ,
age_extract string ,
age_first_individual string ,
agent_appt_requests_1yr string ,
apprec string ,
apps1yr string ,
apps1yr_ae string ,
apps1yr_dtc string ,
apps2yr string ,
apps2yr_ae string ,
apps2yr_dtc string ,
ben_b3 string ,
ben_b4 string ,
ben_b4_1yr string ,
ben_b4_2yr string ,
claim_count string ,
claims_2yr_sum string ,
clm_pd_1yr string ,
constructionloan string ,
cov_expn_amt string ,
cpt_cat1 string ,
cpt_cat1_2yr string ,
cpt_cat20 string ,
cpt_cat22 string ,
cpt_cat7 string ,
cpt_catg string ,
cpt_catl string ,
cpt_catz string ,
cur_adjud_recency_day string ,
cur_adjud_recency_mth string ,
cur_adjud_recency_yrs string ,
cur_plan_recency_day string ,
cur_plan_recency_mth string ,
cur_plan_recency_yrs string ,
ded_amt string ,
ded_amt_1yr string ,
ded_amt_2yr string ,
delq_certs string ,
delq_certs_1yr string ,
delq_certs_2yr string ,
display_plan_code_curr string ,
ee_3yr string ,
ee_3yr_1yr string ,
ee_3yr_2yr string ,
ee_3yr_ex string ,
ee_6mo_1yr string ,
ee_6mo_2yr string ,
ee_6yr_1yr string ,
ee_6yr_2yr string ,
email_requests_1yr string ,
email_requests_2yr string ,
emp_delq_prem string ,
emp_delq_prem_1yr string ,
emp_delq_prem_2yr string ,
employer_acct_ind string ,
evc_ins_ind string ,
evc_months_w_product string ,
everact_2yr string ,
gender_rate_type_cd_curr string ,
geners20 string ,
global_supp_ind string ,
graduatedloan string ,
hco_1yr string ,
hco_2yr string ,
hco_inbound_1yr string ,
hco_opportunity_1yr string ,
hco_opportunity_2yr string ,
hco_reason_18 string ,
hco_reason_32 string ,
hco_reason_36 string ,
hco_reason_4 string ,
hco_reason_5 string ,
hco_resp_prod_not_avail_1yr string ,
hco_succ_opp_1yr string ,
hco_succ_opp_2yr string ,
hco_touchpoint_1yr string ,
hco_touchpoint_2yr string ,
hh_curr_ins_othper_v2_ms string ,
home_assessed_value_ranges string ,
icd_ccs12 string ,
icd_ccs17 string ,
icd_ccs6 string ,
im_pen_mem_50_ov string ,
im_pen_mem_65_ov string ,
inqrec string ,
k0083_comb string ,
k0464_comb string ,
loyalty_program_code_curr string ,
ma_indiv_pl_ch_denials1yr string ,
ma_indiv_pl_ch_denials2yr string ,
ma_pl_ch_denials1yr string ,
marketing_channel_curr string ,
mbr_pd_prem string ,
mbr_pd_prem_1yr string ,
mbr_pd_prem_2yr string ,
medb_coverage_days string ,
medb_coverage_mths string ,
medb_coverage_yrs string ,
mnt_snc_app_ag string ,
mnt_snc_app_dtc string ,
mnt_snc_ms_app_ag string ,
mnt_snc_ms_app_dtc string ,
mnth_snc_ms_app_othper_v2 string ,
mnths_sinc_prd_not_avl string ,
mnths_sinc_tp_enroll_inq string ,
mnths_since_pdp_indiv_new_app string ,
mnths_since_pdp_new_app string ,
months_sinc_ms_app_othrprs string ,
months_since_app_otherpers string ,
months_since_b4 string ,
months_since_opportunity string ,
months_since_pensive string ,
months_since_pensive2 string ,
months_since_suc_opport string ,
months_since_tm_contact string ,
months_since_treat_not string ,
months_since_treat_pres string ,
months_since_treatment string ,
months_since_web_reg string ,
msapprec string ,
msapps string ,
msapps1yr string ,
msapps1yr_ae string ,
msapps1yr_dtc string ,
msapps2yr string ,
msapps2yr_ae string ,
msapps2yr_dtc string ,
msinqrec string ,
nbr_ms_plans_lifetime string ,
netw19 string ,
nurse_fac_denial string ,
old_delq_certs string ,
old_delq_certs_1yr string ,
old_delq_certs_2yr string ,
old_pd_certs string ,
old_pd_certs_1yr string ,
old_pd_certs_2yr string ,
old_term_certs_1yr string ,
old_term_certs_2yr string ,
part_b_ded_amt string ,
part_b_ded_amt_2yr string ,
pd_certs string ,
pd_certs_1yr string ,
pd_certs_2yr string ,
pd_prem string ,
pd_prem_1yr string ,
pd_prem_2yr string ,
pdp_ins_ind string ,
pdp_months_w_product string ,
pdprems_2yr_sum string ,
pensive_contacts_1yr string ,
pensive_contacts_1yr2 string ,
persclust70 string ,
prior_effective_date_mths string ,
prior_termination_date_mths string ,
rev_delq_certs string ,
rev_delq_certs_1yr string ,
rev_delq_certs_2yr string ,
sales string ,
sales1yr string ,
sales2yr string ,
seclerical string ,
semgmt string ,
semgmt2 string ,
semgmtb string ,
seother string ,
seother2 string ,
seotherb string ,
sestudent string ,
sestudent2 string ,
sestudentb string ,
snic string ,
snp_pl_ch_apps string ,
snp_pl_ch_apps1yr string ,
snp_pl_ch_apps2yr string ,
snp_pl_ch_denials string ,
snp_pl_ch_denials1yr string ,
snp_pl_ch_denials2yr string ,
snp_pl_ch_sales string ,
snp_pl_ch_sales1yr string ,
snp_pl_ch_sales2yr string ,
srvc_from_1yr string ,
srvc_to_1yr string ,
term_certs_1yr string ,
term_certs_2yr string ,
term_rec string ,
term_rec_ms string ,
timeshare string ,
tos_b string ,
tos_b_1yr string ,
uhc_ms_loyalty_days string ,
uhc_ms_loyalty_mths string ,
uhc_ms_loyalty_pct string ,
uhc_ms_loyalty_yrs string ,
underwriting_rate_up_ind_curr string ,
PDP_ins_ind_2 string ,
bau_lapse_predict string ,
bau_reten_score string ,
bau_lapse_score string ,
predict string ,
Dont_Dstrb string ,
Lost_Causes string ,
Persuadable string ,
Sure_Things string) COPY GRANTS;



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_UPLIFT_COMBO_VARS_RAW)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, 'DEEP_PROCESSES', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), 'SUCCESS',  :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXECUTE IMMEDIATE 'USE WAREHOUSE '||:WH;

ALTER SESSION SET TIMEZONE = 'America/Chicago';

V_STEP := 'STEP2';

V_STEP_NAME :=  'load data into table uplift_combo_vars_raw';
   
V_START_TIME := CONVERT_TIMEZONE('America/Chicago', CURRENT_TIMESTAMP());



EXECUTE IMMEDIATE :V_COPY_STMT;



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_UPLIFT_COMBO_VARS_RAW)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, 'DEEP_PROCESSES', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), 'SUCCESS',  :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE 'USE WAREHOUSE '||:WH;

ALTER SESSION SET TIMEZONE = 'America/Chicago';

V_STEP := 'STEP3';

V_STEP_NAME :=  'create a table uplift_combo_vars';
   
V_START_TIME := CONVERT_TIMEZONE('America/Chicago', CURRENT_TIMESTAMP());




create or replace table IDENTIFIER(:V_UPLIFT_COMBO_VARS) COPY GRANTS as 
select 
cast(person_id as bigint) as person_id ,
cast(adj_ben_amt as double) as adj_ben_amt ,
cast(adj_ben_amt_2yr as double) as adj_ben_amt_2yr ,
cast(age as int) as age ,
cast(age_extract as double) as age_extract ,
age_first_individual  ,
cast(agent_appt_requests_1yr as bigint) as agent_appt_requests_1yr ,
cast(apprec as double) as apprec ,
cast(apps1yr as bigint) as apps1yr ,
cast(apps1yr_ae as bigint) as apps1yr_ae ,
cast(apps1yr_dtc as bigint) as apps1yr_dtc ,
cast(apps2yr as bigint) as apps2yr ,
cast(apps2yr_ae as bigint) as apps2yr_ae ,
cast(apps2yr_dtc as bigint) as apps2yr_dtc ,
cast(ben_b3 as bigint) as ben_b3 ,
cast(ben_b4 as bigint) as ben_b4 ,
cast(ben_b4_1yr as bigint) as ben_b4_1yr ,
cast(ben_b4_2yr as bigint) as ben_b4_2yr ,
cast(claim_count as bigint) as claim_count ,
cast(claims_2yr_sum as NUMBER(38,15)) as claims_2yr_sum ,
cast(clm_pd_1yr as bigint) as clm_pd_1yr ,
cast(constructionloan as int) as constructionloan ,
cast(cov_expn_amt as double) as cov_expn_amt ,
cast(cpt_cat1 as bigint) as cpt_cat1 ,
cast(cpt_cat1_2yr as bigint) as cpt_cat1_2yr ,
cast(cpt_cat20 as bigint) as cpt_cat20 ,
cast(cpt_cat22 as bigint) as cpt_cat22 ,
cast(cpt_cat7 as bigint) as cpt_cat7 ,
cast(cpt_catg as bigint) as cpt_catg ,
cast(cpt_catl as bigint) as cpt_catl ,
cast(cpt_catz as bigint) as cpt_catz ,
cast(cur_adjud_recency_day as int) as cur_adjud_recency_day ,
cast(cur_adjud_recency_mth as double) as cur_adjud_recency_mth ,
cast(cur_adjud_recency_yrs as double) as cur_adjud_recency_yrs ,
cast(cur_plan_recency_day as int) as cur_plan_recency_day ,
cast(cur_plan_recency_mth as double) as cur_plan_recency_mth ,
cast(cur_plan_recency_yrs as double) as cur_plan_recency_yrs ,
cast(ded_amt as double) as ded_amt ,
cast(ded_amt_1yr as double) as ded_amt_1yr ,
cast(ded_amt_2yr as double) as ded_amt_2yr ,
cast(delq_certs as bigint) as delq_certs ,
cast(delq_certs_1yr as bigint) as delq_certs_1yr ,
cast(delq_certs_2yr as bigint) as delq_certs_2yr ,
display_plan_code_curr  ,
cast(ee_3yr as int) as ee_3yr ,
cast(ee_3yr_1yr as int) as ee_3yr_1yr ,
cast(ee_3yr_2yr as int) as ee_3yr_2yr ,
cast(ee_3yr_ex as int) as ee_3yr_ex ,
cast(ee_6mo_1yr as int) as ee_6mo_1yr ,
cast(ee_6mo_2yr as int) as ee_6mo_2yr ,
cast(ee_6yr_1yr as int) as ee_6yr_1yr ,
cast(ee_6yr_2yr as int) as ee_6yr_2yr ,
cast(email_requests_1yr as bigint) as email_requests_1yr ,
cast(email_requests_2yr as bigint) as email_requests_2yr ,
cast(emp_delq_prem as double) as emp_delq_prem ,
cast(emp_delq_prem_1yr as double) as emp_delq_prem_1yr ,
cast(emp_delq_prem_2yr as double) as emp_delq_prem_2yr ,
cast(employer_acct_ind as int) as employer_acct_ind ,
cast(evc_ins_ind as int) as evc_ins_ind ,
cast(evc_months_w_product as int) as evc_months_w_product ,
cast(everact_2yr as int) as everact_2yr ,
gender_rate_type_cd_curr  ,
geners20  ,
cast(global_supp_ind as int) as global_supp_ind ,
cast(graduatedloan as int) as graduatedloan ,
cast(hco_1yr as bigint) as hco_1yr ,
cast(hco_2yr as bigint) as hco_2yr ,
cast(hco_inbound_1yr as bigint) as hco_inbound_1yr ,
cast(hco_opportunity_1yr as bigint) as hco_opportunity_1yr ,
cast(hco_opportunity_2yr as bigint) as hco_opportunity_2yr ,
cast(hco_reason_18 as bigint) as hco_reason_18 ,
cast(hco_reason_32 as bigint) as hco_reason_32 ,
cast(hco_reason_36 as bigint) as hco_reason_36 ,
cast(hco_reason_4 as bigint) as hco_reason_4 ,
cast(hco_reason_5 as bigint) as hco_reason_5 ,
cast(hco_resp_prod_not_avail_1yr as bigint) as hco_resp_prod_not_avail_1yr ,
cast(hco_succ_opp_1yr as bigint) as hco_succ_opp_1yr ,
cast(hco_succ_opp_2yr as bigint) as hco_succ_opp_2yr ,
cast(hco_touchpoint_1yr as bigint) as hco_touchpoint_1yr ,
cast(hco_touchpoint_2yr as bigint) as hco_touchpoint_2yr ,
cast(hh_curr_ins_othper_v2_ms as int) as hh_curr_ins_othper_v2_ms ,
home_assessed_value_ranges  ,
cast(icd_ccs12 as bigint) as icd_ccs12 ,
cast(icd_ccs17 as bigint) as icd_ccs17 ,
cast(icd_ccs6 as bigint) as icd_ccs6 ,
im_pen_mem_50_ov ,
im_pen_mem_65_ov,
cast(inqrec as double) as inqrec ,
k0083_comb  ,
k0464_comb  ,
cast(loyalty_program_code_curr as bigint) as loyalty_program_code_curr ,
cast(ma_indiv_pl_ch_denials1yr as bigint) as ma_indiv_pl_ch_denials1yr ,
cast(ma_indiv_pl_ch_denials2yr as bigint) as ma_indiv_pl_ch_denials2yr ,
cast(ma_pl_ch_denials1yr as bigint) as ma_pl_ch_denials1yr ,
marketing_channel_curr  ,
cast(mbr_pd_prem as double) as mbr_pd_prem ,
cast(mbr_pd_prem_1yr as double) as mbr_pd_prem_1yr ,
cast(mbr_pd_prem_2yr as double) as mbr_pd_prem_2yr ,
cast(medb_coverage_days as int) as medb_coverage_days ,
cast(medb_coverage_mths as double) as medb_coverage_mths ,
cast(medb_coverage_yrs as double) as medb_coverage_yrs ,
cast(mnt_snc_app_ag as double) as mnt_snc_app_ag ,
cast(mnt_snc_app_dtc as double) as mnt_snc_app_dtc ,
cast(mnt_snc_ms_app_ag as double) as mnt_snc_ms_app_ag ,
cast(mnt_snc_ms_app_dtc as double) as mnt_snc_ms_app_dtc ,
cast(mnth_snc_ms_app_othper_v2 as double) as mnth_snc_ms_app_othper_v2 ,
cast(mnths_sinc_prd_not_avl as double) as mnths_sinc_prd_not_avl ,
cast(mnths_sinc_tp_enroll_inq as double) as mnths_sinc_tp_enroll_inq ,
cast(mnths_since_pdp_indiv_new_app as double) as mnths_since_pdp_indiv_new_app ,
cast(mnths_since_pdp_new_app as double) as mnths_since_pdp_new_app ,
cast(months_sinc_ms_app_othrprs as double) as months_sinc_ms_app_othrprs ,
cast(months_since_app_otherpers as double) as months_since_app_otherpers ,
cast(months_since_b4 as double) as months_since_b4 ,
cast(months_since_opportunity as NUMBER(38,15)) as months_since_opportunity ,
cast(months_since_pensive as NUMBER(38,15)) as months_since_pensive ,
cast(months_since_pensive2 as NUMBER(38,15)) as months_since_pensive2 ,
cast(months_since_suc_opport as double) as months_since_suc_opport ,
cast(months_since_tm_contact as double) as months_since_tm_contact ,
cast(months_since_treat_not as double) as months_since_treat_not ,
cast(months_since_treat_pres as double) as months_since_treat_pres ,
cast(months_since_treatment as double) as months_since_treatment ,
cast(months_since_web_reg as double) as months_since_web_reg ,
cast(msapprec as double) as msapprec ,
cast(msapps as bigint) as msapps ,
cast(msapps1yr as bigint) as msapps1yr ,
cast(msapps1yr_ae as bigint) as msapps1yr_ae ,
cast(msapps1yr_dtc as bigint) as msapps1yr_dtc ,
cast(msapps2yr as bigint) as msapps2yr ,
cast(msapps2yr_ae as bigint) as msapps2yr_ae ,
cast(msapps2yr_dtc as bigint) as msapps2yr_dtc ,
cast(msinqrec as double) as msinqrec ,
cast(nbr_ms_plans_lifetime as bigint) as nbr_ms_plans_lifetime ,
netw19  ,
cast(nurse_fac_denial as int) as nurse_fac_denial ,
cast(old_delq_certs as bigint) as old_delq_certs ,
cast(old_delq_certs_1yr as bigint) as old_delq_certs_1yr ,
cast(old_delq_certs_2yr as bigint) as old_delq_certs_2yr ,
cast(old_pd_certs as bigint) as old_pd_certs ,
cast(old_pd_certs_1yr as bigint) as old_pd_certs_1yr ,
cast(old_pd_certs_2yr as bigint) as old_pd_certs_2yr ,
cast(old_term_certs_1yr as bigint) as old_term_certs_1yr ,
cast(old_term_certs_2yr as bigint) as old_term_certs_2yr ,
cast(part_b_ded_amt as double) as part_b_ded_amt ,
cast(part_b_ded_amt_2yr as double) as part_b_ded_amt_2yr ,
cast(pd_certs as bigint) as pd_certs ,
cast(pd_certs_1yr as bigint) as pd_certs_1yr ,
cast(pd_certs_2yr as bigint) as pd_certs_2yr ,
cast(pd_prem as double) as pd_prem ,
cast(pd_prem_1yr as double) as pd_prem_1yr ,
cast(pd_prem_2yr as double) as pd_prem_2yr ,
cast(pdp_ins_ind as int) as pdp_ins_ind ,
cast(pdp_months_w_product as int) as pdp_months_w_product ,
cast(pdprems_2yr_sum as NUMBER(38,15)) as pdprems_2yr_sum ,
cast(pensive_contacts_1yr as bigint) as pensive_contacts_1yr ,
cast(pensive_contacts_1yr2 as bigint) as pensive_contacts_1yr2 ,
cast(persclust70 as int) as persclust70 ,
cast(prior_effective_date_mths as double) as prior_effective_date_mths ,
cast(prior_termination_date_mths as double) as prior_termination_date_mths ,
cast(rev_delq_certs as bigint) as rev_delq_certs ,
cast(rev_delq_certs_1yr as bigint) as rev_delq_certs_1yr ,
cast(rev_delq_certs_2yr as bigint) as rev_delq_certs_2yr ,
cast(sales as bigint) as sales ,
cast(sales1yr as bigint) as sales1yr ,
cast(sales2yr as bigint) as sales2yr ,
cast(seclerical as int) as seclerical ,
cast(semgmt as int) as semgmt ,
cast(semgmt2 as int) as semgmt2 ,
cast(semgmtb as int) as semgmtb ,
cast(seother as int) as seother ,
cast(seother2 as int) as seother2 ,
cast(seotherb as int) as seotherb ,
cast(sestudent as int) as sestudent ,
cast(sestudent2 as int) as sestudent2 ,
cast(sestudentb as int) as sestudentb ,
snic  ,
cast(snp_pl_ch_apps as bigint) as snp_pl_ch_apps ,
cast(snp_pl_ch_apps1yr as bigint) as snp_pl_ch_apps1yr ,
cast(snp_pl_ch_apps2yr as bigint) as snp_pl_ch_apps2yr ,
cast(snp_pl_ch_denials as bigint) as snp_pl_ch_denials ,
cast(snp_pl_ch_denials1yr as bigint) as snp_pl_ch_denials1yr ,
cast(snp_pl_ch_denials2yr as bigint) as snp_pl_ch_denials2yr ,
cast(snp_pl_ch_sales as bigint) as snp_pl_ch_sales ,
cast(snp_pl_ch_sales1yr as bigint) as snp_pl_ch_sales1yr ,
cast(snp_pl_ch_sales2yr as bigint) as snp_pl_ch_sales2yr ,
cast(srvc_from_1yr as bigint) as srvc_from_1yr ,
cast(srvc_to_1yr as bigint) as srvc_to_1yr ,
cast(term_certs_1yr as bigint) as term_certs_1yr ,
cast(term_certs_2yr as bigint) as term_certs_2yr ,
cast(term_rec as NUMBER(38,15)) as term_rec ,
cast(term_rec_ms as NUMBER(38,15)) as term_rec_ms ,
cast(timeshare as int) as timeshare ,
cast(tos_b as bigint) as tos_b ,
cast(tos_b_1yr as bigint) as tos_b_1yr ,
cast(uhc_ms_loyalty_days as bigint) as uhc_ms_loyalty_days ,
cast(uhc_ms_loyalty_mths as double) as uhc_ms_loyalty_mths ,
cast(uhc_ms_loyalty_pct as double) as uhc_ms_loyalty_pct ,
cast(uhc_ms_loyalty_yrs as double) as uhc_ms_loyalty_yrs ,
underwriting_rate_up_ind_curr  ,
cast(PDP_ins_ind_2 as int) as PDP_ins_ind_2 ,
cast(bau_lapse_predict as double) as bau_lapse_predict ,
cast(bau_reten_score as NUMBER(38,15)) as bau_reten_score ,
cast(bau_lapse_score as NUMBER(38,15)) as bau_lapse_score ,
predict  ,
cast(Dont_Dstrb as NUMBER(38,15)) as Dont_Dstrb ,
cast(Lost_Causes as NUMBER(38,15)) as Lost_Causes ,
cast(Persuadable as NUMBER(38,15)) as Persuadable ,
cast(Sure_Things as NUMBER(38,15)) as Sure_Things 
from IDENTIFIER(:V_UPLIFT_COMBO_VARS_RAW);



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_UPLIFT_COMBO_VARS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, 'DEEP_PROCESSES', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), 'SUCCESS',  :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE 'USE WAREHOUSE '||:WH;

ALTER SESSION SET TIMEZONE = 'America/Chicago';

V_STEP := 'STEP4';

V_STEP_NAME :=  'create a table uplift_combo_vars_export';
   
V_START_TIME := CONVERT_TIMEZONE('America/Chicago', CURRENT_TIMESTAMP());



create or replace table IDENTIFIER(:V_UPLIFT_COMBO_VARS_EXPORT) COPY GRANTS as
 select
person_id as pers_id,
predict,
case when predict = 'Persuadable' then 99 else 9 end as MDL_SCOR,
Persuadable as RAW_SCOR,
case when predict = 'Sure Things' then 55 else 5 end  as MAIL_MDL_RNK,
case when predict = 'Don''t Dstrb' then 22 else 2 end  as HOLDOUT_MDL_RNK,
Sure_Things as MAIL_MDL_SCOR,
Dont_Dstrb as HOLDOUT_MDL_SCOR,
'isbsqadp' as CREAT_BY_USER_ID,
to_timestamp(DATE_PART('epoch', CURRENT_TIMESTAMP())) as CREAT_TMSTMP,
'isbsqadp' as UPDT_BY_USER_ID,
to_timestamp(DATE_PART('epoch', CURRENT_TIMESTAMP())) as UPDT_TMSTMP
from IDENTIFIER(:V_UPLIFT_COMBO_VARS);

 

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_UPLIFT_COMBO_VARS_EXPORT)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, 'DEEP_PROCESSES', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), 'SUCCESS',  :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE 'USE WAREHOUSE '||:WH;

ALTER SESSION SET TIMEZONE = 'America/Chicago';

V_STEP := 'STEP5';

V_STEP_NAME :=  'copy the final data to a file in  BLOB STORAGE ';
   
V_START_TIME := CONVERT_TIMEZONE('America/Chicago', CURRENT_TIMESTAMP());


EXECUTE IMMEDIATE :V_COPY_TOFILE_STMT;



V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, 'DEEP_PROCESSES', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), 'SUCCESS',  :V_LAST_QUERY_ID,:V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, 'DEEP_PROCESSES', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,:V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), 'FAILED', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);


RAISE;

END;

$$
;