USE SCHEMA BDR_FFP_DA;

CREATE OR REPLACE PROCEDURE SP_IS_KPI_BUSS_PERFORMANCE_DASH("PIPELINE_ID" VARCHAR, "PIPELINE_NAME" VARCHAR, "DB_NAME" VARCHAR, "UTIL_SC" VARCHAR, "TGT_SC" VARCHAR, "TGT_SC_2" VARCHAR, "SRC_SC" VARCHAR, "SRC_SC_2" VARCHAR, "SRC_SC_3" VARCHAR, "WH" VARCHAR, "STAGE_NAME" VARCHAR, "CURR_DATE" VARCHAR)
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := :DB_NAME||''.''||COALESCE(:UTIL_SC, ''UTIL'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';

V_PROCESS_NAME   VARCHAR DEFAULT ''IS_KPI_BUSS_PERFORMANCE_DASH'';

V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''IS_KPI_BUSS_PERFORMANCE_DASH'';

V_STEP             VARCHAR;

V_STEP_NAME        VARCHAR;

V_START_TIME       VARCHAR;

V_END_TIME         VARCHAR;

V_ROWS_PARSED       INTEGER;

V_ROWS_LOADED       INTEGER;

V_MESSAGE          VARCHAR;

V_LAST_QUERY_ID    VARCHAR;

V_CURRENT_DATE   DATE := COALESCE(TO_DATE(:CURR_DATE), CURRENT_DATE());

V_FFP_INFORCE_LR_P_LVL_CLAIM_INFO VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.INFORCELR_P_LVL_CLAIM_INFO'';

V_COMMON_KPI_INFORCE_AVG_PREM_INCREASE VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.IS_KPI_BPD_INFORCE_AVG_PREM_INCREASE'';

V_GARYA3_TMP_AVG_INFORCE_YTD VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2, ''BDR_FFP_DA_WRK'') || ''.IS_KPI_BPD_TMP_AVG_INFORCE_YTD'';

V_GARYA3_TMP_KPI_COMPILATION_INFORCE_LR VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2, ''BDR_FFP_DA_WRK'') || ''.IS_KPI_BPD_TMP_COMPILATION_INFORCE_LR'';

V_GARYA3_TMP_AVG_INFORCE VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2, ''BDR_FFP_DA_WRK'') || ''.IS_KPI_BPD_TMP_AVG_INFORCE'';

V_COMMON_KPI_COMPILATION_INFORCE_LR VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.IS_KPI_BPD_COMPILATION_INFORCE_LR'';

V_GARYA3_TMP_KPI_COMPILATION_INFORCE_LR_STATE VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2, ''BDR_FFP_DA_WRK'') || ''.IS_KPI_BPD_TMP_COMPILATION_INFORCE_LR_STATE'';

V_GARYA3_TMP_KPI_COMPILATION_INFORCE_LR_UW VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2, ''BDR_FFP_DA_WRK'') || ''.IS_KPI_BPD_TMP_COMPILATION_INFORCE_LR_UW'';

V_COMMON_KPI_COMPILATION_INFORCE_LR_BY_STATE VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.IS_KPI_BPD_COMPILATION_INFORCE_LR_BY_STATE'';

V_GARYA3_TMP_KPI_COMPILATION_INFORCE_LR_CHL VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2, ''BDR_FFP_DA_WRK'') || ''.IS_KPI_BPD_TMP_COMPILATION_INFORCE_LR_CHL'';

V_COMMON_KPI_COMPILATION_INFORCE_LR_BY_UW VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.IS_KPI_BPD_COMPILATION_INFORCE_LR_BY_UW'';

V_COMMON_KPI_COMPILATION_INFORCE_LR_BY_CHANNEL VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.IS_KPI_BPD_COMPILATION_INFORCE_LR_BY_CHANNEL'';

V_COMMON_KPI_COMPILATION_INFORCE_LR_LTM VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.IS_KPI_BPD_COMPILATION_INFORCE_LR_LTM'';

V_COMMON_OGS_KPI_COMPILATION_SALES_NBLR_SA VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.IS_KPI_LR_KPI_COMPILATION_SALES_NBLR_SA'';

V_GARYA3_CY_MLR_STATEWISE VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2, ''BDR_FFP_DA_WRK'') || ''.IS_KPI_BPD_CY_MLR_STATEWISE'';

V_COMMON_KPI_COMPILATION_NBLR_MLR_STATEWISE_SUMMARY VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.IS_KPI_BPD_COMPILATION_NBLR_MLR_STATEWISE_SUMMARY'';

V_GARYA3_CY_NBLR_STATEWISE VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2, ''BDR_FFP_DA_WRK'') || ''.IS_KPI_BPD_CY_NBLR_STATEWISE'';

V_COMMON_KPI_COMPILATION_DURATION1PMPM VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.IS_KPI_BPD_COMPILATION_DURATION1PMPM'';

V_FFP_NPS_DASHBOARD_NPS_DATASET VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.NPS_DASHBOARD_NPS_DATASET'';

V_COMMON_KPI_COMPILATION_NPS_SUMMARY VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.IS_KPI_BPD_COMPILATION_NPS_SUMMARY'';

V_COMMON_KPI_COMPILATION_NBLR_LTM VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.IS_KPI_BPD_COMPILATION_NBLR_LTM'';

V_COMMON_KPI_COMPILATION_SALES VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.IS_KPI_BPD_COMPILATION_SALES'';

V_COMMON_KPI_COMPILATION_NEW_MEMBER_LAPSE VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.IS_KPI_BPD_COMPILATION_NEW_MEMBER_LAPSE'';

V_FFP_LOSS_RATIO_ISDW_EFF_SALES_DASHBOARD VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.LOSS_RATIO_ISDW_EFF_SALES_DASHBOARD'';

V_GARYA3_TMP_NEW_MEMBER_LAPSE_V2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2, ''BDR_FFP_DA_WRK'') || ''.IS_KPI_BPD_TMP_NEW_MEMBER_LAPSE_V2'';

V_GARYA3_TMP_NEW_MEMBER_LAPSE_V3 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2, ''BDR_FFP_DA_WRK'') || ''.IS_KPI_BPD_TMP_NEW_MEMBER_LAPSE_V3'';

V_REFINED_CAMPAIGN_V_AC_WEB_REGISTRATION VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.V_AC_WEB_REGISTRATION'';

V_GARYA3_TMP_KPI_COMPILATION_NEW_SALES_V1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2, ''BDR_FFP_DA_WRK'') || ''.IS_KPI_BPD_TMP_KPI_COMPILATION_NEW_SALES_V1'';

V_COMMON_KPI_COMPILATION_NEW_MBR_WEB_REGISTRATIONS VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.IS_KPI_BPD_COMPILATION_NEW_MBR_WEB_REGISTRATIONS'';

V_FFP_CSAT_DASHBOARD_CSAT_DATA VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.CSAT_DATA'';

V_ralwani_IS_KPI_ENROLLMENT_SCORE VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.IS_KPI_BPD_ENROLLMENT_SCORE'';

V_COMMON_KPI_COMPILATION_EASE_OF_DOING_BUSINESS VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.IS_KPI_BPD_COMPILATION_EASE_OF_DOING_BUSINESS'';

V_GARYA3_TMP_KPI_LAPSE_MLR_V3 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2, ''BDR_FFP_DA_WRK'') || ''.IS_KPI_BPD_TMP_KPI_LAPSE_MLR_V3'';

V_REFINED_ISDW_PREM_V_F_PREM_TRANS_DAY VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_2, ''BDR_DM'') || ''.F_PREM_TRANS_DAY'';

V_GARYA3_TMP_INVOL_LAPSE_CLAIMS_PM VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2, ''BDR_FFP_DA_WRK'') || ''.IS_KPI_BPD_TMP_INVOL_LAPSE_CLAIMS_PM'';

V_REFINED_ISDW_REF_V_D_GEO_XREF VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_3, ''BDR_CONF'') || ''.D_GEO_XREF'';

V_REFINED_ISDW_REF_V_D_ST VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_3, ''BDR_CONF'') || ''.D_ST'';

V_GARYA3_TMP_KPI_LAPSE_DAILY VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2, ''BDR_FFP_DA_WRK'') || ''.IS_KPI_BPD_TMP_KPI_LAPSE_DAILY'';

V_GARYA3_TMP_KPI_LAPSE_MLR_V2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2, ''BDR_FFP_DA_WRK'') || ''.IS_KPI_BPD_TMP_KPI_LAPSE_MLR_V2'';

V_GARYA3_TMP_KPI_STR_LAPSE_DAILY VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2, ''BDR_FFP_DA_WRK'') || ''.IS_KPI_BPD_TMP_KPI_STR_LAPSE_DAILY'';

V_GARYA3_TMP_KPI_VOLN_LAPSE_DAILY VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2, ''BDR_FFP_DA_WRK'') || ''.IS_KPI_BPD_TMP_KPI_VOLN_LAPSE_DAILY'';

V_GARYA3_TMP_INFORCE_MLR VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2, ''BDR_FFP_DA_WRK'') || ''.IS_KPI_BPD_TMP_INFORCE_MLR'';

V_REFINED_ISDW_REF_V_D_MBR_INFO VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_3, ''BDR_CONF'') || ''.D_MBR_INFO'';

V_GARYA3_TMP_VOL_LAPSE_CLAIMS_PM VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2, ''BDR_FFP_DA_WRK'') || ''.IS_KPI_BPD_TMP_VOL_LAPSE_CLAIMS_PM'';

V_GARYA3_TMP_VOL_LAPSE_PREM_PM VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2, ''BDR_FFP_DA_WRK'') || ''.IS_KPI_BPD_TMP_VOL_LAPSE_PREM_PM'';

V_GARYA3_TMP_KPI_TRANS_DAY VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2, ''BDR_FFP_DA_WRK'') || ''.IS_KPI_BPD_TMP_KPI_TRANS_DAY'';

V_GARYA3_TMP_KPI_LAPSE_MLR VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2, ''BDR_FFP_DA_WRK'') || ''.IS_KPI_BPD_TMP_KPI_LAPSE_MLR'';

V_GARYA3_TMP_VOL_LAPSE_MLR VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2, ''BDR_FFP_DA_WRK'') || ''.IS_KPI_BPD_TMP_VOL_LAPSE_MLR'';

V_GARYA3_KPI_CLAIMS_PMPM VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.IS_KPI_BPD_KPI_CLAIMS_PMPM'';

V_GARYA3_TMP_INVOL_LAPSE_MLR VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2, ''BDR_FFP_DA_WRK'') || ''.IS_KPI_BPD_TMP_INVOL_LAPSE_MLR'';

V_REFINED_ISDW_REF_V_D_PLN_BEN_MOD VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_3, ''BDR_CONF'') || ''.D_PLN_BEN_MOD'';

V_REFINED_ISDW_REF_V_D_CERT_ACTV VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_3, ''BDR_CONF'') || ''.D_CERT_ACTV'';

V_GARYA3_KPI_PREM_PMPM VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.IS_KPI_BPD_KPI_PREM_PMPM'';

V_GARYA3_TMP_INFORCE_BASE VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2, ''BDR_FFP_DA_WRK'') || ''.IS_KPI_BPD_TMP_INFORCE_BASE'';

V_GARYA3_TMP_INFORCE_BASE_V2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2, ''BDR_FFP_DA_WRK'') || ''.IS_KPI_BPD_TMP_INFORCE_BASE_V2'';

V_GARYA3_TMP_INVOL_LAPSE_PREM_PM VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2, ''BDR_FFP_DA_WRK'') || ''.IS_KPI_BPD_TMP_INVOL_LAPSE_PREM_PM'';

V_GARYA3_TMP_INFORCE_PREM_PM VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2, ''BDR_FFP_DA_WRK'') || ''.IS_KPI_BPD_TMP_INFORCE_PREM_PM'';

V_GARYA3_KPI_MLR VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.IS_KPI_BPD_KPI_MLR'';

V_GARYA3_TMP_INFORCE_CLAIMS_PM VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2, ''BDR_FFP_DA_WRK'') || ''.IS_KPI_BPD_TMP_INFORCE_CLAIMS_PM'';

V_GARYA3_TMP_INFORCE_BASE_FINAL VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC_2, ''BDR_FFP_DA_WRK'') || ''.IS_KPI_BPD_TMP_INFORCE_BASE_FINAL'';

--Variables
--First date of last month
V_LATEST_MEMBERSHIP_MONTH date := DATE_TRUNC(''MONTH'', DATEADD(MONTH, -1, :V_CURRENT_DATE)); 

--FIRST DATE OF LAST 3RD MONTH
V_INCURRED_TILL date := DATE_TRUNC(''MONTH'', DATEADD(MONTH, -3, :V_CURRENT_DATE)); 

--NEED TO DISCUSS BELOW LOGIC FROM GAURAV
V_MBR_START_DT date := ''2021-01-01'';
V_MBR_END_DT date := DATE_TRUNC(''MONTH'', DATEADD(MONTH, -1, :V_CURRENT_DATE));

-- -3 MONTH
V_SALES_TILL date := DATE_TRUNC(''MONTH'', DATEADD(MONTH, -3, :V_CURRENT_DATE)); 

V_SALES_TILL_2 date := DATE_TRUNC(''MONTH'', DATEADD(MONTH, -1, :V_CURRENT_DATE));

V_LATEST_LAPSE_MONTH date := DATE_TRUNC(''MONTH'', DATEADD(MONTH, -3, :V_CURRENT_DATE)); 

V_LATEST_MEMBERSHIP_MONTH_1 date := DATE_TRUNC(''MONTH'', DATEADD(MONTH, -3, :V_CURRENT_DATE));

BEGIN

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

--SCRIPT-1 AVG PREM INCREASE

V_STEP := ''STEP1'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_INFORCE_AVG_PREM_INCREASE'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_common_KPI_INFORCE_AVG_PREM_INCREASE) COPY GRANTS as 

select prem_month, d_st_cd, count(pers_id) as membership, sum(ly_prem) as ly_prem, sum(lly_prem) as lly_prem
from
(	select x.prem_due_dt as prem_month, x.d_st_cd, x.pers_id, a.paid_prem as ly_prem, b.paid_prem as lly_prem from
	(
	SELECT prem_due_dt, d_st_cd, pers_id FROM IDENTIFIER(:V_ffp_inforce_lr_P_LVL_CLAIM_INFO) 
	WHERE prem_due_dt=:V_LATEST_MEMBERSHIP_MONTH and tenure_year not in (''<1 Year'', ''1-2 Years'')
	)x
	inner join 
		(select pers_id, sum(COALESCE(paid_prem,0)) as paid_prem from IDENTIFIER(:V_ffp_inforce_lr_P_LVL_CLAIM_INFO) 
		where prem_due_dt between add_months(:V_LATEST_MEMBERSHIP_MONTH,-11) and :V_LATEST_MEMBERSHIP_MONTH
		group by pers_id) a on x.pers_id=a.pers_id
	inner join 
		(select pers_id, sum(COALESCE(paid_prem,0)) as paid_prem from IDENTIFIER(:V_ffp_inforce_lr_P_LVL_CLAIM_INFO)
		where prem_due_dt between add_months(:V_LATEST_MEMBERSHIP_MONTH,-11-12) and add_months(:V_LATEST_MEMBERSHIP_MONTH,-12)
		group by pers_id) b on x.pers_id=b.pers_id
)x group by prem_month, d_st_cd
union all
select prem_month, d_st_cd, count(pers_id) as membership, sum(ly_prem) as ly_prem, sum(lly_prem) as lly_prem
from
(	select x.prem_due_dt as prem_month, x.d_st_cd, x.pers_id, a.paid_prem as ly_prem, b.paid_prem as lly_prem from
	(
	SELECT prem_due_dt, d_st_cd, pers_id FROM IDENTIFIER(:V_ffp_inforce_lr_P_LVL_CLAIM_INFO) 
	WHERE prem_due_dt=add_months(:V_LATEST_MEMBERSHIP_MONTH,-12) and tenure_year not in (''<1 Year'', ''1-2 Years'')
	)x
	inner join 
		(select pers_id, sum(COALESCE(paid_prem,0)) as paid_prem from IDENTIFIER(:V_ffp_inforce_lr_P_LVL_CLAIM_INFO) 
		where prem_due_dt between add_months(:V_LATEST_MEMBERSHIP_MONTH,-12-11) and add_months(:V_LATEST_MEMBERSHIP_MONTH,-12)
		group by pers_id) a on x.pers_id=a.pers_id
	inner join 
		(select pers_id, sum(COALESCE(paid_prem,0)) as paid_prem from IDENTIFIER(:V_ffp_inforce_lr_P_LVL_CLAIM_INFO)
		where prem_due_dt between add_months(:V_LATEST_MEMBERSHIP_MONTH,-12-12-11) and add_months(:V_LATEST_MEMBERSHIP_MONTH,-12-12)
		group by pers_id) b on x.pers_id=b.pers_id
)x group by prem_month, d_st_cd
union all
select prem_month, d_st_cd, count(pers_id) as membership, sum(ly_prem) as ly_prem, sum(lly_prem) as lly_prem
from
(	select x.prem_due_dt as prem_month, x.d_st_cd, x.pers_id, a.paid_prem as ly_prem, b.paid_prem as lly_prem from
	(
	SELECT prem_due_dt, d_st_cd, pers_id FROM IDENTIFIER(:V_ffp_inforce_lr_P_LVL_CLAIM_INFO) 
	WHERE prem_due_dt=add_months(:V_LATEST_MEMBERSHIP_MONTH,-12-12) and tenure_year not in (''<1 Year'', ''1-2 Years'')
	)x
	inner join 
		(select pers_id, sum(COALESCE(paid_prem,0)) as paid_prem from IDENTIFIER(:V_ffp_inforce_lr_P_LVL_CLAIM_INFO) 
		where prem_due_dt between add_months(:V_LATEST_MEMBERSHIP_MONTH,-12-12-11) and add_months(:V_LATEST_MEMBERSHIP_MONTH,-12-12)
		group by pers_id) a on x.pers_id=a.pers_id
	inner join 
		(select pers_id, sum(COALESCE(paid_prem,0)) as paid_prem from IDENTIFIER(:V_ffp_inforce_lr_P_LVL_CLAIM_INFO)
		where prem_due_dt between add_months(:V_LATEST_MEMBERSHIP_MONTH,-12-12-12-11) and add_months(:V_LATEST_MEMBERSHIP_MONTH,-12-12-12)
		group by pers_id) b on x.pers_id=b.pers_id
)x group by prem_month, d_st_cd
union all
select prem_month, d_st_cd, count(pers_id) as membership, sum(ly_prem) as ly_prem, sum(lly_prem) as lly_prem
from
(	select x.prem_due_dt as prem_month, x.d_st_cd, x.pers_id, a.paid_prem as ly_prem, b.paid_prem as lly_prem from
	(
	SELECT prem_due_dt, d_st_cd, pers_id FROM IDENTIFIER(:V_ffp_inforce_lr_P_LVL_CLAIM_INFO) 
	WHERE prem_due_dt=add_months(:V_LATEST_MEMBERSHIP_MONTH,-12-12-12) and tenure_year not in (''<1 Year'', ''1-2 Years'')
	)x
	inner join 
		(select pers_id, sum(COALESCE(paid_prem,0)) as paid_prem from IDENTIFIER(:V_ffp_inforce_lr_P_LVL_CLAIM_INFO) 
		where prem_due_dt between add_months(:V_LATEST_MEMBERSHIP_MONTH,-12-12-12-11) and add_months(:V_LATEST_MEMBERSHIP_MONTH,-12-12-12)
		group by pers_id) a on x.pers_id=a.pers_id
	inner join 
		(select pers_id, sum(COALESCE(paid_prem,0)) as paid_prem from IDENTIFIER(:V_ffp_inforce_lr_P_LVL_CLAIM_INFO)
		where prem_due_dt between add_months(:V_LATEST_MEMBERSHIP_MONTH,-12-12-12-12-11) and add_months(:V_LATEST_MEMBERSHIP_MONTH,-12-12-12-12)
		group by pers_id) b on x.pers_id=b.pers_id
)x group by prem_month, d_st_cd
union all
select prem_month, d_st_cd, count(pers_id) as membership, sum(ly_prem) as ly_prem, sum(lly_prem) as lly_prem
from
(	select x.prem_due_dt as prem_month, x.d_st_cd, x.pers_id, a.paid_prem as ly_prem, b.paid_prem as lly_prem from
	(
	SELECT prem_due_dt, d_st_cd, pers_id FROM IDENTIFIER(:V_ffp_inforce_lr_P_LVL_CLAIM_INFO) 
	WHERE prem_due_dt=add_months(:V_LATEST_MEMBERSHIP_MONTH,-12-12-12-12) and tenure_year not in (''<1 Year'', ''1-2 Years'')
	)x
	inner join 
		(select pers_id, sum(COALESCE(paid_prem,0)) as paid_prem from IDENTIFIER(:V_ffp_inforce_lr_P_LVL_CLAIM_INFO) 
		where prem_due_dt between add_months(:V_LATEST_MEMBERSHIP_MONTH,-12-12-12-12-11) and add_months(:V_LATEST_MEMBERSHIP_MONTH,-12-12-12-12)
		group by pers_id) a on x.pers_id=a.pers_id
	inner join 
		(select pers_id, sum(COALESCE(paid_prem,0)) as paid_prem from IDENTIFIER(:V_ffp_inforce_lr_P_LVL_CLAIM_INFO)
		where prem_due_dt between add_months(:V_LATEST_MEMBERSHIP_MONTH,-12-12-12-12-12-11) and add_months(:V_LATEST_MEMBERSHIP_MONTH,-12-12-12-12-12)
		group by pers_id) b on x.pers_id=b.pers_id
)x group by prem_month, d_st_cd;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_common_KPI_INFORCE_AVG_PREM_INCREASE)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								


--SCRIPT-2 INFORCE LOSS RATIO

V_STEP := ''STEP2'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_TMP_COMPILATION_INFORCE_LR'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_garya3_TMP_KPI_COMPILATION_INFORCE_LR) COPY GRANTS as
SELECT prem_due_mo_id,prem_due_dt,YEAR(prem_due_dt) AS prem_yr
	,age_at_enrollment
	,COUNT(pers_id) AS mbr
	,SUM(paid_prem) AS paid_prem
	,SUM(claim_cf_covid) AS claim_cf_covid
	,SUM(claim) AS claim
FROM IDENTIFIER(:V_ffp_inforce_lr_P_LVL_CLAIM_INFO) WHERE prem_due_dt<= :V_INCURRED_TILL
GROUP BY prem_due_mo_id,prem_due_dt,YEAR(prem_due_dt),age_at_enrollment;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_garya3_TMP_KPI_COMPILATION_INFORCE_LR)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

V_STEP := ''STEP3'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_TMP_AVG_INFORCE'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_garya3_TMP_AVG_INFORCE) COPY GRANTS as
SELECT YEAR(prem_due_dt) as prem_yr, avg(mbr) as mbr
FROM (SELECT prem_due_dt, SUM(mbr) as mbr FROM IDENTIFIER(:V_garya3_TMP_KPI_COMPILATION_INFORCE_LR)
GROUP BY prem_due_dt)x GROUP BY YEAR(prem_due_dt);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_garya3_TMP_AVG_INFORCE)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP4'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_TMP_AVG_INFORCE_YTD'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_garya3_TMP_AVG_INFORCE_YTD) COPY GRANTS as
SELECT YEAR(prem_due_dt) as prem_yr, avg(mbr) as mbr
FROM (SELECT prem_due_dt, SUM(mbr) as mbr FROM IDENTIFIER(:V_garya3_TMP_KPI_COMPILATION_INFORCE_LR)
WHERE MONTH(prem_due_dt)<= MONTH(:V_INCURRED_TILL)
GROUP BY prem_due_dt)x GROUP BY YEAR(prem_due_dt);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_garya3_TMP_AVG_INFORCE_YTD)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP5'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_COMPILATION_INFORCE_LR'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_common_KPI_COMPILATION_INFORCE_LR) COPY GRANTS as
SELECT a.*, b.mbr as cy_avg_membership, c.mbr as ytd_avg_membership,
	CASE WHEN MONTH(prem_due_dt)<= MONTH(:V_INCURRED_TILL) THEN 1 ELSE 0 END AS ytd_fg
FROM IDENTIFIER(:V_garya3_TMP_KPI_COMPILATION_INFORCE_LR) a
LEFT JOIN IDENTIFIER(:V_garya3_TMP_AVG_INFORCE) b on a.prem_yr=b.prem_yr
LEFT JOIN IDENTIFIER(:V_garya3_TMP_AVG_INFORCE_YTD) c on a.prem_yr=c.prem_yr;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_common_KPI_COMPILATION_INFORCE_LR)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								

--SCRIPT-3 Inforce Loss Ratio - Datasets for Book Stability View

V_STEP := ''STEP6'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_TMP_COMPILATION_INFORCE_LR_STATE'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_garya3_TMP_KPI_COMPILATION_INFORCE_LR_STATE) COPY GRANTS as
SELECT prem_due_mo_id,prem_due_dt,YEAR(prem_due_dt) AS prem_yr
	,CASE WHEN MONTH(prem_due_dt)<= MONTH(:V_INCURRED_TILL) THEN 1 ELSE 0 END AS ytd_fg
	,d_st_cd
	,COUNT(pers_id) AS mbr
	,SUM(paid_prem) AS paid_prem
	,SUM(claim_cf_covid) AS claim_cf_covid
	,SUM(claim) AS claim
FROM IDENTIFIER(:V_ffp_inforce_lr_P_LVL_CLAIM_INFO) WHERE prem_due_dt<= :V_INCURRED_TILL
GROUP BY prem_due_mo_id,prem_due_dt,YEAR(prem_due_dt),d_st_cd,(CASE WHEN MONTH(prem_due_dt)<= MONTH(:V_INCURRED_TILL) THEN 1 ELSE 0 END);

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_garya3_TMP_KPI_COMPILATION_INFORCE_LR_STATE)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP7'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_COMPILATION_INFORCE_LR_BY_STATE'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_common_KPI_COMPILATION_INFORCE_LR_BY_STATE) COPY GRANTS as
select coalesce(cy.prem_yr,ytd.prem_yr) AS prem_yr
	,coalesce(cy.state,ytd.state) AS state
	,cy.mbr AS cy_avg_inforce
	,cy.paid_prem AS cy_paid_prem
	,cy.claim_cf_covid AS cy_claim_cf_covid
	,cy.claim AS cy_claim
	,ytd.mbr AS ytd_avg_inforce
	,ytd.paid_prem AS ytd_paid_prem
	,ytd.claim_cf_covid AS ytd_claim_cf_covid
	,ytd.claim AS ytd_claim
FROM
(SELECT prem_yr, d_st_cd as state, avg(mbr) AS mbr
	,SUM(paid_prem) AS paid_prem
	,SUM(claim_cf_covid) AS claim_cf_covid
	,SUM(claim) AS claim
FROM IDENTIFIER(:V_garya3_TMP_KPI_COMPILATION_INFORCE_LR_STATE) group by prem_yr, d_st_cd) cy
FULL JOIN
(SELECT prem_yr, d_st_cd as state, avg(mbr) AS mbr
	,SUM(paid_prem) AS paid_prem
	,SUM(claim_cf_covid) AS claim_cf_covid
	,SUM(claim) AS claim
FROM IDENTIFIER(:V_garya3_TMP_KPI_COMPILATION_INFORCE_LR_STATE) where ytd_fg=1 group by prem_yr, d_st_cd) ytd ON cy.prem_yr=ytd.prem_yr AND cy.state=ytd.state;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_common_KPI_COMPILATION_INFORCE_LR_BY_STATE)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP8'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_TMP_COMPILATION_INFORCE_LR_CHL'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_garya3_TMP_KPI_COMPILATION_INFORCE_LR_CHL) COPY GRANTS as
SELECT prem_due_mo_id,prem_due_dt,YEAR(prem_due_dt) AS prem_yr
	,CASE WHEN MONTH(prem_due_dt)<= MONTH(:V_INCURRED_TILL) THEN 1 ELSE 0 END AS ytd_fg
	,marketing_channel_cat_3 
	,COUNT(pers_id) AS mbr
	,SUM(paid_prem) AS paid_prem
	,SUM(claim_cf_covid) AS claim_cf_covid
	,SUM(claim) AS claim
FROM IDENTIFIER(:V_ffp_inforce_lr_P_LVL_CLAIM_INFO) WHERE prem_due_dt<= :V_INCURRED_TILL
GROUP BY prem_due_mo_id,prem_due_dt,YEAR(prem_due_dt),marketing_channel_cat_3,(CASE WHEN MONTH(prem_due_dt)<= MONTH(:V_INCURRED_TILL) THEN 1 ELSE 0 END);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_garya3_TMP_KPI_COMPILATION_INFORCE_LR_CHL)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP9'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_COMPILATION_INFORCE_LR_BY_CHANNEL'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


CREATE OR REPLACE TABLE IDENTIFIER(:V_common_KPI_COMPILATION_INFORCE_LR_BY_CHANNEL) COPY GRANTS as
select coalesce(cy.prem_yr,ytd.prem_yr) AS prem_yr
	,coalesce(cy.marketing_channel_cat_3,ytd.marketing_channel_cat_3) AS marketing_channel_cat_3
	,cy.mbr AS cy_avg_inforce
	,cy.paid_prem AS cy_paid_prem
	,cy.claim_cf_covid AS cy_claim_cf_covid
	,cy.claim AS cy_claim
	,ytd.mbr AS ytd_avg_inforce
	,ytd.paid_prem AS ytd_paid_prem
	,ytd.claim_cf_covid AS ytd_claim_cf_covid
	,ytd.claim AS ytd_claim
FROM
(SELECT prem_yr, marketing_channel_cat_3, avg(mbr) AS mbr
	,SUM(paid_prem) AS paid_prem
	,SUM(claim_cf_covid) AS claim_cf_covid
	,SUM(claim) AS claim
FROM IDENTIFIER(:V_garya3_TMP_KPI_COMPILATION_INFORCE_LR_CHL) group by prem_yr, marketing_channel_cat_3) cy
FULL JOIN
(SELECT prem_yr, marketing_channel_cat_3, avg(mbr) AS mbr
	,SUM(paid_prem) AS paid_prem
	,SUM(claim_cf_covid) AS claim_cf_covid
	,SUM(claim) AS claim
FROM IDENTIFIER(:V_garya3_TMP_KPI_COMPILATION_INFORCE_LR_CHL) where ytd_fg=1 group by prem_yr, marketing_channel_cat_3) ytd 
ON cy.prem_yr=ytd.prem_yr AND cy.marketing_channel_cat_3=ytd.marketing_channel_cat_3;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_common_KPI_COMPILATION_INFORCE_LR_BY_CHANNEL)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP10'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_TMP_COMPILATION_INFORCE_LR_UW'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


CREATE OR REPLACE TABLE IDENTIFIER(:V_garya3_TMP_KPI_COMPILATION_INFORCE_LR_UW) COPY GRANTS AS
SELECT prem_due_mo_id,prem_due_dt,YEAR(prem_due_dt) AS prem_yr
	,CASE WHEN MONTH(prem_due_dt)<= MONTH(:V_INCURRED_TILL) THEN 1 ELSE 0 END AS ytd_fg
	,uw_prdct_rqr_txt
	,COUNT(pers_id) AS mbr
	,SUM(paid_prem) AS paid_prem
	,SUM(claim_cf_covid) AS claim_cf_covid
	,SUM(claim) AS claim
FROM IDENTIFIER(:V_ffp_inforce_lr_P_LVL_CLAIM_INFO) WHERE prem_due_dt<= :V_INCURRED_TILL
GROUP BY prem_due_mo_id,prem_due_dt,YEAR(prem_due_dt),uw_prdct_rqr_txt,(CASE WHEN MONTH(prem_due_dt)<= MONTH(:V_INCURRED_TILL) THEN 1 ELSE 0 END);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_garya3_TMP_KPI_COMPILATION_INFORCE_LR_UW)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP11'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_COMPILATION_INFORCE_LR_BY_UW'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


CREATE OR REPLACE TABLE IDENTIFIER(:V_common_KPI_COMPILATION_INFORCE_LR_BY_UW) COPY GRANTS AS
select coalesce(cy.prem_yr,ytd.prem_yr) AS prem_yr
	,coalesce(cy.uw_prdct_rqr_txt,ytd.uw_prdct_rqr_txt) AS uw_prdct_rqr_txt
	,cy.mbr AS cy_avg_inforce
	,cy.paid_prem AS cy_paid_prem
	,cy.claim_cf_covid AS cy_claim_cf_covid
	,cy.claim AS cy_claim
	,ytd.mbr AS ytd_avg_inforce
	,ytd.paid_prem AS ytd_paid_prem
	,ytd.claim_cf_covid AS ytd_claim_cf_covid
	,ytd.claim AS ytd_claim
FROM
(SELECT prem_yr, uw_prdct_rqr_txt, avg(mbr) AS mbr
	,SUM(paid_prem) AS paid_prem
	,SUM(claim_cf_covid) AS claim_cf_covid
	,SUM(claim) AS claim
FROM IDENTIFIER(:V_garya3_TMP_KPI_COMPILATION_INFORCE_LR_UW) group by prem_yr, uw_prdct_rqr_txt) cy
FULL JOIN
(SELECT prem_yr, uw_prdct_rqr_txt, avg(mbr) AS mbr
	,SUM(paid_prem) AS paid_prem
	,SUM(claim_cf_covid) AS claim_cf_covid
	,SUM(claim) AS claim
FROM IDENTIFIER(:V_garya3_TMP_KPI_COMPILATION_INFORCE_LR_UW) where ytd_fg=1 group by prem_yr, uw_prdct_rqr_txt) ytd 
ON cy.prem_yr=ytd.prem_yr AND cy.uw_prdct_rqr_txt=ytd.uw_prdct_rqr_txt;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_common_KPI_COMPILATION_INFORCE_LR_BY_UW)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
--SCRIPT-4 INFORCE LTM

V_STEP := ''STEP12'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_COMPILATION_INFORCE_LR_LTM'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


CREATE OR REPLACE table IDENTIFIER(:V_common_KPI_COMPILATION_INFORCE_LR_LTM) COPY GRANTS AS
select * from 
(
	select add_months(:V_INCURRED_TILL,-11) as twelve_months_start, :V_INCURRED_TILL as twelve_months_end,
	age_at_enrollment, avg(mbr) as avg_mbr_count, sum(claim_cf_covid) as claim_cf_covid, sum(paid_prem) as paid_prem
	from IDENTIFIER(:V_common_KPI_COMPILATION_INFORCE_LR)
	where prem_due_dt<=:V_INCURRED_TILL and prem_due_dt>= add_months(:V_INCURRED_TILL,-11) 
	group by age_at_enrollment
	union all
	select add_months(:V_INCURRED_TILL,-11-12)  as twelve_months_start, add_months(:V_INCURRED_TILL,-12) as twelve_months_end,
	age_at_enrollment, avg(mbr) as avg_mbr_count, sum(claim_cf_covid) as claim_cf_covid, sum(paid_prem) as paid_prem
	from IDENTIFIER(:V_common_KPI_COMPILATION_INFORCE_LR)
	where prem_due_dt<=add_months(:V_INCURRED_TILL,-12) and prem_due_dt>= add_months(:V_INCURRED_TILL,-11-12) 
	group by age_at_enrollment
	union all
	
	select add_months(:V_INCURRED_TILL,-11-12-12)  as twelve_months_start, add_months(:V_INCURRED_TILL,-12-12) as twelve_months_end,
	age_at_enrollment, avg(mbr) as avg_mbr_count, sum(claim_cf_covid) as claim_cf_covid, sum(paid_prem) as paid_prem
	from IDENTIFIER(:V_common_KPI_COMPILATION_INFORCE_LR)
	where prem_due_dt<=add_months(:V_INCURRED_TILL,-12-12) and prem_due_dt>= add_months(:V_INCURRED_TILL,-11-12-12) 
	group by age_at_enrollment
	union all
	
	select add_months(:V_INCURRED_TILL,-11-12-12-12) as twelve_months_start, add_months(:V_INCURRED_TILL,-12-12-12) as twelve_months_end,
	age_at_enrollment, avg(mbr) as avg_mbr_count, sum(claim_cf_covid) as claim_cf_covid, sum(paid_prem) as paid_prem
	from IDENTIFIER(:V_common_KPI_COMPILATION_INFORCE_LR)
	where prem_due_dt<=add_months(:V_INCURRED_TILL,-12-12-12) and prem_due_dt>= add_months(:V_INCURRED_TILL,-11-12-12-12)
	group by age_at_enrollment
	union all
	
	select add_months(:V_INCURRED_TILL,-11-12-12-12-12) as twelve_months_start, add_months(:V_INCURRED_TILL,-12-12-12-12) as twelve_months_end,
	age_at_enrollment, avg(mbr) as avg_mbr_count, sum(claim_cf_covid) as claim_cf_covid, sum(paid_prem) as paid_prem
	from IDENTIFIER(:V_common_KPI_COMPILATION_INFORCE_LR)
	where prem_due_dt<=add_months(:V_INCURRED_TILL,-12-12-12-12) and prem_due_dt>= add_months(:V_INCURRED_TILL,-11-12-12-12-12)
	group by age_at_enrollment
)x;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_common_KPI_COMPILATION_INFORCE_LR_LTM)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

--SCRIPT-5 Loss Ratio Summary for Mark

V_STEP := ''STEP13'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_CY_NBLR_STATEWISE'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


CREATE OR REPLACE TABLE IDENTIFIER(:V_garya3_CY_NBLR_STATEWISE) COPY GRANTS AS
select eff_yr,d_st_cd
	,sum(claim_till_december_covid_adj) as sales_claim_till_december_covid_adj
	,sum(claim_till_december) as sales_claim_till_december
	,sum(paid_prem_till_december) as sales_paid_prem_till_december
	,(sum(claim_till_december_covid_adj)/nullif(sum(paid_prem_till_december), 0)) as cov_adj_nblr
	,(sum(claim_till_december)/nullif(sum(paid_prem_till_december), 0)) as nblr
	
	,sum(claim_amt_covid_adj_ytd) as sales_claim_covid_adj_ytd
	,sum(claim_amt_ytd) as sales_claim_ytd
	,sum(paid_prem_ytd) as sales_paid_prem_ytd
	,(sum(claim_amt_covid_adj_ytd)/nullif(sum(paid_prem_ytd), 0)) as cov_adj_nblr_ytd
	,(sum(claim_amt_ytd)/nullif(sum(paid_prem_ytd), 0)) as nblr_ytd
	
	,sum(claim_12months_covid_adj) as sales_claim_12months_covid_adj
	,sum(claim_12months) as sales_claim_12months
	,sum(paid_prem_12months) as sales_paid_prem_12months
	,(sum(claim_12months_covid_adj)/nullif(sum(paid_prem_12months), 0)) as cov_adj_nblr_12months
	,(sum(claim_12months)/nullif(sum(paid_prem_12months), 0)) as nblr_12months
	
from IDENTIFIER(:V_common_ogs_KPI_COMPILATION_SALES_NBLR_SA) where eff_dt<=:V_INCURRED_TILL
group by eff_yr,d_st_cd;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_garya3_CY_NBLR_STATEWISE)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP14'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_CY_MLR_STATEWISE'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


CREATE OR REPLACE TABLE IDENTIFIER(:V_garya3_CY_MLR_STATEWISE) COPY GRANTS AS
select year(prem_due_dt) as prem_yr,d_st_cd
	,sum(claim_cf_covid) as mbr_claim_cf_covid
	,sum(claim) as mbr_claim
	,sum(paid_prem) as mbr_paid_prem
	,(sum(claim_cf_covid)/nullif(sum(paid_prem), 0)) as cov_adj_mlr
	,(sum(claim)/nullif(sum(paid_prem), 0)) as non_cov_adj_mlr
	,sum(case when month(prem_due_dt)<=month(:V_INCURRED_TILL) then claim_cf_covid else 0 end) as mbr_claim_cf_covid_ytd
	,sum(case when month(prem_due_dt)<=month(:V_INCURRED_TILL) then claim else 0 end) as mbr_claim_ytd
	,sum(case when month(prem_due_dt)<=month(:V_INCURRED_TILL) then paid_prem else 0 end) as mbr_paid_prem_ytd
        ,(sum(case when month(prem_due_dt)<=month(:V_INCURRED_TILL) then claim_cf_covid else 0 end)/nullif(sum(case when month(prem_due_dt)<=month(:V_INCURRED_TILL) then paid_prem else 0 end), 0)) as cov_adj_mlr_ytd
	,(sum(case when month(prem_due_dt)<=month(:V_INCURRED_TILL) then claim else 0 end)/nullif(sum(case when month(prem_due_dt)<=month(:V_INCURRED_TILL) then paid_prem else 0 end), 0)) as non_cov_adj_mlr_ytd
from IDENTIFIER(:V_ffp_inforce_lr_P_LVL_CLAIM_INFO) where prem_due_dt <=:V_INCURRED_TILL
group by year(prem_due_dt),d_st_cd;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_garya3_CY_MLR_STATEWISE)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

V_STEP := ''STEP15'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_COMPILATION_NBLR_MLR_STATEWISE_SUMMARY'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_common_KPI_COMPILATION_NBLR_MLR_STATEWISE_SUMMARY) COPY GRANTS AS
select coalesce(a.eff_yr, b.prem_yr) as eff_yr, coalesce(a.d_st_cd, b.d_st_cd) d_st_cd
	,a.sales_claim_till_december_covid_adj
	,a.sales_claim_till_december
	,a.sales_paid_prem_till_december
	,a.cov_adj_nblr,a.nblr
	,a.sales_claim_covid_adj_ytd
	,a.sales_claim_ytd
	,a.sales_paid_prem_ytd
	,a.cov_adj_nblr_ytd
	,a.nblr_ytd
	,a.sales_claim_12months_covid_adj
	,a.sales_claim_12months
	,a.sales_paid_prem_12months
	,a.cov_adj_nblr_12months
	,a.nblr_12months
	,b.mbr_claim_cf_covid
	,b.mbr_claim
	,b.mbr_paid_prem
	,b.cov_adj_mlr,b.non_cov_adj_mlr 
	,b.mbr_claim_cf_covid_ytd
	,b.mbr_claim_ytd
	,b.mbr_paid_prem_ytd
	,b.cov_adj_mlr_ytd
	,b.non_cov_adj_mlr_ytd
from IDENTIFIER(:V_garya3_CY_NBLR_STATEWISE) a
full join (select * from IDENTIFIER(:V_garya3_CY_MLR_STATEWISE) where prem_yr>= 2018) b on a.eff_yr=b.prem_yr and a.d_st_cd = b.d_st_cd;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_common_KPI_COMPILATION_NBLR_MLR_STATEWISE_SUMMARY)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


--SCRIPT-7 Duration 1pmpm

V_STEP := ''STEP16'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_COMPILATION_DURATION1PMPM'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_common_KPI_COMPILATION_DURATION1PMPM) COPY GRANTS AS
select prem_due_dt
	,prem_due_mo_id
	,tenure_year
	,d_st_cd
	,(case when d_st_cd in (''NY'',''WA'',''AR'',''CT'',''MN'',''VT'',''ME'',''VI'',''GU'') then ''Community Rated''
	else ''All Others'' end) as state_category
	,count(pers_id) mbr_cnt, sum(paid_prem) paid_prem 
from IDENTIFIER(:V_ffp_inforce_lr_P_LVL_CLAIM_INFO) where prem_due_dt between (:V_MBR_START_DT) and (:V_MBR_END_DT)
group by prem_due_dt, prem_due_mo_id, tenure_year, d_st_cd, 
	(case when d_st_cd in (''NY'',''WA'',''AR'',''CT'',''MN'',''VT'',''ME'',''VI'',''GU'') then ''Community Rated''
	else ''All Others'' end)
order by prem_due_dt, prem_due_mo_id, tenure_year, d_st_cd, state_category;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_common_KPI_COMPILATION_DURATION1PMPM)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


--SCRIPT-8 NPS SUMMARY

V_STEP := ''STEP17'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_COMPILATION_NPS_SUMMARY'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


CREATE OR REPLACE TABLE IDENTIFIER(:V_common_KPI_COMPILATION_NPS_SUMMARY) COPY GRANTS AS
select survey_month, s_individual_id, 
	s_respondent_id, pers_id, s_dwts,
	s_npsn, s_studytype, tenure
from IDENTIFIER(:V_ffp_nps_dashboard_NPS_DATASET); 


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_common_KPI_COMPILATION_NPS_SUMMARY)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

--SCRIPT-9 NBLR LTM

V_STEP := ''STEP18'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_COMPILATION_NBLR_LTM'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


CREATE OR REPLACE TABLE IDENTIFIER(:V_common_KPI_COMPILATION_NBLR_LTM) COPY GRANTS AS
select a.* from 
(
	select add_months(:V_SALES_TILL,-11) as twelve_months_start, :V_SALES_TILL as twelve_months_end,
	bday_waive_state_period_fg, bday_waive_fg, d_st_cd, age, sum(sales) as sales, sum(claim_12months_covid_adj) as claim_12months_covid_adj, sum(paid_prem_12months) as paid_prem_12months
	from IDENTIFIER(:V_common_ogs_KPI_COMPILATION_SALES_NBLR_SA) 
	where eff_dt<=:V_SALES_TILL and eff_dt>= add_months(:V_SALES_TILL,-11) 
	group by bday_waive_state_period_fg, bday_waive_fg, d_st_cd, age
	union all
	select add_months(:V_SALES_TILL,-11-12)  as twelve_months_start, add_months(:V_SALES_TILL,-12) as twelve_months_end,
	bday_waive_state_period_fg, bday_waive_fg, d_st_cd, age, sum(sales) as sales, sum(claim_12months_covid_adj) as claim_12months_covid_adj, sum(paid_prem_12months) as paid_prem_12months
	from IDENTIFIER(:V_common_ogs_KPI_COMPILATION_SALES_NBLR_SA) 
	where eff_dt<=add_months(:V_SALES_TILL,-12) and eff_dt>= add_months(:V_SALES_TILL,-11-12) 
	group by bday_waive_state_period_fg, bday_waive_fg, d_st_cd, age
	union all
	
	select add_months(:V_SALES_TILL,-11-12-12)  as twelve_months_start, add_months(:V_SALES_TILL,-12-12) as twelve_months_end,
	bday_waive_state_period_fg, bday_waive_fg, d_st_cd, age, sum(sales) as sales, sum(claim_12months_covid_adj) as claim_12months_covid_adj, sum(paid_prem_12months) as paid_prem_12months
	from IDENTIFIER(:V_common_ogs_KPI_COMPILATION_SALES_NBLR_SA) 
	where eff_dt<=add_months(:V_SALES_TILL,-12-12) and eff_dt>= add_months(:V_SALES_TILL,-11-12-12) 
	group by bday_waive_state_period_fg, bday_waive_fg, d_st_cd, age
	union all
	
	select add_months(:V_SALES_TILL,-11-12-12-12) as twelve_months_start, add_months(:V_SALES_TILL,-12-12-12) as twelve_months_end,
	bday_waive_state_period_fg, bday_waive_fg, d_st_cd, age, sum(sales) as sales, sum(claim_12months_covid_adj) as claim_12months_covid_adj, sum(paid_prem_12months) as paid_prem_12months
	from IDENTIFIER(:V_common_ogs_KPI_COMPILATION_SALES_NBLR_SA) 
	where eff_dt<=add_months(:V_SALES_TILL,-12-12-12) and eff_dt>= add_months(:V_SALES_TILL,-11-12-12-12)
	group by bday_waive_state_period_fg, bday_waive_fg, d_st_cd, age
	union all
	
	select add_months(:V_SALES_TILL,-11-12-12-12-12) as twelve_months_start, add_months(:V_SALES_TILL,-12-12-12-12) as twelve_months_end,
	bday_waive_state_period_fg, bday_waive_fg, d_st_cd, age, sum(sales) as sales, sum(claim_12months_covid_adj) as claim_12months_covid_adj, sum(paid_prem_12months) as paid_prem_12months
	from IDENTIFIER(:V_common_ogs_KPI_COMPILATION_SALES_NBLR_SA) 
	where eff_dt<=add_months(:V_SALES_TILL,-12-12-12-12) and eff_dt>= add_months(:V_SALES_TILL,-11-12-12-12-12)
	group by bday_waive_state_period_fg, bday_waive_fg, d_st_cd, age
) as a;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_common_KPI_COMPILATION_NBLR_LTM)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

--SCRIPT-10 UW Sales

V_STEP := ''STEP19'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_COMPILATION_SALES'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE IDENTIFIER(:V_common_KPI_COMPILATION_SALES) COPY GRANTS AS
select a.* from 
(
	select add_months(:V_SALES_TILL_2,-11) as twelve_months_start, :V_SALES_TILL_2 as twelve_months_end,
	marketing_channel_cat_3, underwriting, age, sum(sales) as sales, sum(claim_12months_covid_adj) as claim_12months_covid_adj, sum(paid_prem_12months) as paid_prem_12months
	from IDENTIFIER(:V_common_ogs_KPI_COMPILATION_SALES_NBLR_SA) 
	where eff_dt<=:V_SALES_TILL_2 and eff_dt>= add_months(:V_SALES_TILL_2,-11) 
	group by 1,2,3,4,5
	union all
	select add_months(:V_SALES_TILL_2,-11-12)  as twelve_months_start, add_months(:V_SALES_TILL_2,-12) as twelve_months_end,
	marketing_channel_cat_3, underwriting, age, sum(sales) as sales, sum(claim_12months_covid_adj) as claim_12months_covid_adj, sum(paid_prem_12months) as paid_prem_12months
	from IDENTIFIER(:V_common_ogs_KPI_COMPILATION_SALES_NBLR_SA) 
	where eff_dt<=add_months(:V_SALES_TILL_2,-12) and eff_dt>= add_months(:V_SALES_TILL_2,-11-12) 
	group by 1,2,3,4,5
	union all
	
	select add_months(:V_SALES_TILL_2,-11-12-12)  as twelve_months_start, add_months(:V_SALES_TILL_2,-12-12) as twelve_months_end,
	marketing_channel_cat_3, underwriting, age, sum(sales) as sales, sum(claim_12months_covid_adj) as claim_12months_covid_adj, sum(paid_prem_12months) as paid_prem_12months
	from IDENTIFIER(:V_common_ogs_KPI_COMPILATION_SALES_NBLR_SA) 
	where eff_dt<=add_months(:V_SALES_TILL_2,-12-12) and eff_dt>= add_months(:V_SALES_TILL_2,-11-12-12) 
	group by 1,2,3,4,5
	union all
	
	select add_months(:V_SALES_TILL_2,-11-12-12-12) as twelve_months_start, add_months(:V_SALES_TILL_2,-12-12-12) as twelve_months_end,
	marketing_channel_cat_3, underwriting, age, sum(sales) as sales, sum(claim_12months_covid_adj) as claim_12months_covid_adj, sum(paid_prem_12months) as paid_prem_12months
	from IDENTIFIER(:V_common_ogs_KPI_COMPILATION_SALES_NBLR_SA) 
	where eff_dt<=add_months(:V_SALES_TILL_2,-12-12-12) and eff_dt>= add_months(:V_SALES_TILL_2,-11-12-12-12)
	group by 1,2,3,4,5
	union all
	
	select add_months(:V_SALES_TILL_2,-11-12-12-12-12) as twelve_months_start, add_months(:V_SALES_TILL_2,-12-12-12-12) as twelve_months_end,
	marketing_channel_cat_3, underwriting, age, sum(sales) as sales, sum(claim_12months_covid_adj) as claim_12months_covid_adj, sum(paid_prem_12months) as paid_prem_12months
	from IDENTIFIER(:V_common_ogs_KPI_COMPILATION_SALES_NBLR_SA) 
	where eff_dt<=add_months(:V_SALES_TILL_2,-12-12-12-12) and eff_dt>= add_months(:V_SALES_TILL_2,-11-12-12-12-12)
	group by 1,2,3,4,5
) as a;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_common_KPI_COMPILATION_SALES)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

--SCRIPT-12 New Member Lapse

V_STEP := ''STEP20'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_TMP_NEW_MEMBER_LAPSE_V2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


CREATE OR REPLACE TABLE IDENTIFIER(:V_garya3_TMP_NEW_MEMBER_LAPSE_V2) COPY GRANTS AS
select prem_due_mo_id
	,eff_dt
	,marketing_channel_cat_3
	,term_date1
	,cast(concat(substr(term_date1,1,4), ''-'',substr(term_date1,5,2), ''-'',''01'') as date) as term_date
	,replace(term_cert_actv_lvl_2_txt, ''PLAN TERM (TERM DT GT EFF DT)-'','''') as termination_reason_name
	,mbr 
from IDENTIFIER(:V_ffp_loss_ratio_ISDW_EFF_SALES_DASHBOARD);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_garya3_TMP_NEW_MEMBER_LAPSE_V2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP21'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_TMP_NEW_MEMBER_LAPSE_V3'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


CREATE OR REPLACE TABLE IDENTIFIER(:V_garya3_TMP_NEW_MEMBER_LAPSE_V3) COPY GRANTS AS
select *
	,case when term_date1<>209912 and months_between(term_date, eff_dt) between 0 and 12 then 1 else 0 end as y1_overall_lapse
	,case when term_date1<>209912 and termination_reason_name in (''VOLUNTARY'',''NON_PAYMENT OF PREMIUM'') and months_between(term_date, eff_dt) between 0 and 12 then 1 else 0 end as y1_vol_lapse
	,case when term_date1<>209912 and termination_reason_name in (''DEATH'') and months_between(term_date, eff_dt) between 0 and 12 then 1 else 0 end as y1_invol_lapse
	,case when term_date1<>209912 and months_between(term_date, eff_dt) between 13 and 24 then 1 else 0 end as y2_overall_lapse
	,case when term_date1<>209912 and termination_reason_name in (''VOLUNTARY'',''NON_PAYMENT OF PREMIUM'') and months_between(term_date, eff_dt) between 13 and 24 then 1 else 0 end as y2_vol_lapse
	,case when term_date1<>209912 and termination_reason_name in (''DEATH'') and months_between(term_date, eff_dt) between 13 and 24 then 1 else 0 end as y2_invol_lapse	
	,case when term_date1<>209912 and months_between(term_date, eff_dt)>0 then 1 else 0 end as total_overall_lapse
	,case when term_date1<>209912 and termination_reason_name in (''VOLUNTARY'',''NON_PAYMENT OF PREMIUM'') and months_between(term_date, eff_dt)>0 then 1 else 0 end as total_vol_lapse
	,case when term_date1<>209912 and termination_reason_name in (''DEATH'') and months_between(term_date, eff_dt)>0 then 1 else 0 end as total_invol_lapse
from IDENTIFIER(:V_garya3_TMP_NEW_MEMBER_LAPSE_V2);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_garya3_TMP_NEW_MEMBER_LAPSE_V3)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

V_STEP := ''STEP22'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_COMPILATION_NEW_MEMBER_LAPSE'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


CREATE OR REPLACE TABLE IDENTIFIER(:V_common_KPI_COMPILATION_NEW_MEMBER_LAPSE) COPY GRANTS AS
select eff_dt, marketing_channel_cat_3, sum(mbr) as sales
	,sum(y1_overall_lapse) as y1_overall_lapse
	,sum(y1_vol_lapse) as y1_vol_lapse
	,sum(y1_invol_lapse) as y1_invol_lapse
	,sum(y2_overall_lapse) as y2_overall_lapse
	,sum(y2_vol_lapse) as y2_vol_lapse
	,sum(y2_invol_lapse) as y2_invol_lapse
	,sum(total_overall_lapse) as total_overall_lapse
	,sum(total_vol_lapse) as total_vol_lapse
	,sum(total_invol_lapse) as total_invol_lapse
from IDENTIFIER(:V_garya3_TMP_NEW_MEMBER_LAPSE_V3) group by eff_dt, marketing_channel_cat_3;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_common_KPI_COMPILATION_NEW_MEMBER_LAPSE)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								
								
--SCRIPT-13 New Member Portal Registrations

V_STEP := ''STEP23'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_TMP_KPI_COMPILATION_NEW_SALES_V1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_garya3_TMP_KPI_COMPILATION_NEW_SALES_V1) copy grants as
select a.pers_id
	,a.eff_dt
	,a.appl_receipt_date 
	,a.marketing_channel_cat_3 
	,a.marketing_channel_final
	,b.calculated_web_registration_date
from IDENTIFIER(:V_ffp_loss_ratio_ISDW_EFF_SALES_DASHBOARD) a
left join IDENTIFIER(:V_refined_campaign_V_AC_WEB_REGISTRATION) b on a.pers_id = b.person_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_garya3_TMP_KPI_COMPILATION_NEW_SALES_V1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP24'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_COMPILATION_NEW_MBR_WEB_REGISTRATIONS'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_common_KPI_COMPILATION_NEW_MBR_WEB_REGISTRATIONS) copy grants as
select eff_dt, trunc(appl_receipt_date, ''month'') as app_month, marketing_channel_cat_3 as distribution_channel_category,

	case when calculated_web_registration_date is null then ''Not Registered'' 
	when datediff(''day'',eff_dt, calculated_web_registration_date) <-60 then ''Prior to effective date minus 60 days''
	when datediff(''day'',eff_dt, calculated_web_registration_date)>=-60 and datediff(''day'',eff_dt, calculated_web_registration_date)<0 then ''Within 60 days prior to effective date''
	when datediff(''day'',eff_dt, calculated_web_registration_date)>=0 and datediff(''day'',eff_dt, calculated_web_registration_date)<=30 then ''Within 0-30 days post effective date''
	when datediff(''day'',eff_dt, calculated_web_registration_date)>30 and datediff(''day'',eff_dt, calculated_web_registration_date)<=60 then ''Within 30-60 days post effective date''
	when datediff(''day'',eff_dt, calculated_web_registration_date)>60 and datediff(''day'',eff_dt, calculated_web_registration_date)<=90 then ''Within 60-90 days post effective date''
	when datediff(''day'',eff_dt, calculated_web_registration_date) >90 then ''After 90 days post effective date''
	else ''Check'' end as web_reg_duration_1, 
	
	case when calculated_web_registration_date is null then ''Not Registered'' 
	when datediff(''day'',appl_receipt_date, calculated_web_registration_date) <-60 then ''Prior to app date minus 60 days''
	when datediff(''day'',appl_receipt_date, calculated_web_registration_date)>=-60 and datediff(''day'',appl_receipt_date, calculated_web_registration_date)<0 then ''Within 60 days prior to app date''
	when datediff(''day'',appl_receipt_date, calculated_web_registration_date)>=0 and datediff(''day'',appl_receipt_date, calculated_web_registration_date)<=30 then ''Within 0-30 days post app date''
	when datediff(''day'',appl_receipt_date, calculated_web_registration_date)>30 and datediff(''day'',appl_receipt_date, calculated_web_registration_date)<=60 then ''Within 30-60 days post app date''
	when datediff(''day'',appl_receipt_date, calculated_web_registration_date)>60 and datediff(''day'',appl_receipt_date, calculated_web_registration_date)<=90 then ''Within 60-90 days post app date''
	when datediff(''day'',appl_receipt_date, calculated_web_registration_date) >90 then ''After 90 days post app date''
	else ''Check'' end as web_reg_duration_2,
	count(*) as sales
from IDENTIFIER(:V_garya3_TMP_KPI_COMPILATION_NEW_SALES_V1) where eff_dt>=''2018-01-01''
group by eff_dt, trunc(appl_receipt_date, ''month''), marketing_channel_cat_3,
	(case when calculated_web_registration_date is null then ''Not Registered'' 
	when datediff(''day'',eff_dt, calculated_web_registration_date) <-60 then ''Prior to effective date minus 60 days''
	when datediff(''day'',eff_dt, calculated_web_registration_date)>=-60 and datediff(''day'',eff_dt, calculated_web_registration_date)<0 then ''Within 60 days prior to effective date''
	when datediff(''day'',eff_dt, calculated_web_registration_date)>=0 and datediff(''day'',eff_dt, calculated_web_registration_date)<=30 then ''Within 0-30 days post effective date''
	when datediff(''day'',eff_dt, calculated_web_registration_date)>30 and datediff(''day'',eff_dt, calculated_web_registration_date)<=60 then ''Within 30-60 days post effective date''
	when datediff(''day'',eff_dt, calculated_web_registration_date)>60 and datediff(''day'',eff_dt, calculated_web_registration_date)<=90 then ''Within 60-90 days post effective date''
	when datediff(''day'',eff_dt, calculated_web_registration_date) >90 then ''After 90 days post effective date''
	else ''Check'' end),
	
	(case when calculated_web_registration_date is null then ''Not Registered'' 
	when datediff(''day'',appl_receipt_date, calculated_web_registration_date) <-60 then ''Prior to app date minus 60 days''
	when datediff(''day'',appl_receipt_date, calculated_web_registration_date)>=-60 and datediff(''day'',appl_receipt_date, calculated_web_registration_date)<0 then ''Within 60 days prior to app date''
	when datediff(''day'',appl_receipt_date, calculated_web_registration_date)>=0 and datediff(''day'',appl_receipt_date, calculated_web_registration_date)<=30 then ''Within 0-30 days post app date''
	when datediff(''day'',appl_receipt_date, calculated_web_registration_date)>30 and datediff(''day'',appl_receipt_date, calculated_web_registration_date)<=60 then ''Within 30-60 days post app date''
	when datediff(''day'',appl_receipt_date, calculated_web_registration_date)>60 and datediff(''day'',appl_receipt_date, calculated_web_registration_date)<=90 then ''Within 60-90 days post app date''
	when datediff(''day'',appl_receipt_date, calculated_web_registration_date) >90 then ''After 90 days post app date''
	else ''Check'' end );


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_common_KPI_COMPILATION_NEW_MBR_WEB_REGISTRATIONS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
								

--SCRIPT-19 IS_KPI_CSAT

V_STEP := ''STEP25'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_ENROLLMENT_SCORE'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_ralwani_IS_KPI_ENROLLMENT_SCORE) COPY GRANTS AS
select trunc(to_date(interview_dt), ''month'') as survey_month, slalabel_new, marketing_channel_final,
CASE 
	when slalabel_new= ''Online Enrollment/Fulfillment'' then q510_txt
	when slalabel_new= ''Enrollment/Fulfillment'' then q405_txt
END as sla_score,
count(distinct(person_id)) as mbrs
from IDENTIFIER(:V_ffp_csat_dashboard_CSAT_DATA) 
where slalabel_new in (''Online Enrollment/Fulfillment'', ''Enrollment/Fulfillment'')
group by
trunc(to_date(interview_dt), ''month''), slalabel_new, marketing_channel_final,
CASE 
	when slalabel_new= ''Online Enrollment/Fulfillment'' then q510_txt
	when slalabel_new= ''Enrollment/Fulfillment'' then q405_txt
END;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_ralwani_IS_KPI_ENROLLMENT_SCORE)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP26'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_COMPILATION_EASE_OF_DOING_BUSINESS'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_common_KPI_COMPILATION_EASE_OF_DOING_BUSINESS) COPY GRANTS AS
select trunc(to_date(interview_dt), ''month'') as survey_month, marketing_channel_final,
q805_txt,
count(distinct(person_id)) as mbrs
from IDENTIFIER(:V_ffp_csat_dashboard_CSAT_DATA) 
where q805_txt in (''0'',''1'',''2'', ''3'', ''4'', ''5'', ''6'', ''7'', ''8'', ''9'', ''10'')
group by
trunc(to_date(interview_dt), ''month''), marketing_channel_final,
q805_txt;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_common_KPI_COMPILATION_EASE_OF_DOING_BUSINESS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



--SCRIPT-6 retention by quality of business

V_STEP := ''STEP27'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_TMP_INFORCE_BASE'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_garya3_TMP_INFORCE_BASE) copy grants as
select prem_due_dt, pers_id from IDENTIFIER(:V_ffp_inforce_lr_P_LVL_CLAIM_INFO) 
where prem_due_dt in (:V_LATEST_MEMBERSHIP_MONTH_1
,add_months(:V_LATEST_MEMBERSHIP_MONTH_1,-12)
,add_months(:V_LATEST_MEMBERSHIP_MONTH_1,-12-12)
,add_months(:V_LATEST_MEMBERSHIP_MONTH_1,-12-12-12));


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_garya3_TMP_INFORCE_BASE)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP28'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_TMP_INFORCE_BASE_V2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_garya3_TMP_INFORCE_BASE_V2) copy grants as
select a.pers_id, a.prem_due_dt, b.prem_due_mo_id, 
	COALESCE(b.paid_prem,0) paid_prem, COALESCE(b.claim_cf_covid,0) claim_cf_covid
from IDENTIFIER(:V_garya3_TMP_INFORCE_BASE) a
left join IDENTIFIER(:V_ffp_inforce_lr_P_LVL_CLAIM_INFO) b on a.pers_id = b.pers_id 
and b.prem_due_dt between add_months(a.prem_due_dt,-11) and a.prem_due_dt;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_garya3_TMP_INFORCE_BASE_V2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

V_STEP := ''STEP29'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_TMP_INFORCE_BASE_FINAL'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_garya3_TMP_INFORCE_BASE_FINAL) copy grants as
select prem_due_dt as membership_month, pers_id, (sum(paid_prem)/count(*)) as prem_pm
	,(sum(claim_cf_covid)/count(*)) as claims_pm
	 ,(sum(claim_cf_covid)/nullif(sum(paid_prem), 0)) as mlr
from IDENTIFIER(:V_garya3_TMP_INFORCE_BASE_V2) group by pers_id, prem_due_dt;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_garya3_TMP_INFORCE_BASE_FINAL)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

V_STEP := ''STEP30'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_TMP_INFORCE_PREM_PM'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_garya3_TMP_INFORCE_PREM_PM) copy grants as
select membership_month,
(case when prem_pm<0 then ''Less than zero''
	when prem_pm>=0 and prem_pm <50 then ''$0-$50''
	when prem_pm>=50 and prem_pm <100 then ''$50-$100''
	when prem_pm>=100 and prem_pm <150 then ''$100-$150''
	when prem_pm>=150 and prem_pm <200 then ''$150-$200''
	when prem_pm>=200 and prem_pm <250 then ''$200-$250''
	when prem_pm>=250 and prem_pm <300 then ''$250-$300''
	when prem_pm>=300 then ''$300+'' end) as prem_pm_pm, 
count(pers_id) as mbr_cnt
from IDENTIFIER(:V_garya3_TMP_INFORCE_BASE_FINAL) 
group by membership_month, 
	(case when prem_pm<0 then ''Less than zero''
	when prem_pm>=0 and prem_pm <50 then ''$0-$50''
	when prem_pm>=50 and prem_pm <100 then ''$50-$100''
	when prem_pm>=100 and prem_pm <150 then ''$100-$150''
	when prem_pm>=150 and prem_pm <200 then ''$150-$200''
	when prem_pm>=200 and prem_pm <250 then ''$200-$250''
	when prem_pm>=250 and prem_pm <300 then ''$250-$300''
	when prem_pm>=300 then ''$300+'' end)
order by membership_month, prem_pm_pm;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_garya3_TMP_INFORCE_PREM_PM)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP31'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_TMP_INFORCE_CLAIMS_PM'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_garya3_TMP_INFORCE_CLAIMS_PM) copy grants as
select membership_month,
(case when claims_pm<0 then ''Less than zero''
	when claims_pm>=0 and claims_pm <50 then ''$0-$50''
	when claims_pm>=50 and claims_pm <100 then ''$50-$100''
	when claims_pm>=100 and claims_pm <150 then ''$100-$150''
	when claims_pm>=150 and claims_pm <200 then ''$150-$200''
	when claims_pm>=200 and claims_pm <250 then ''$200-$250''
	when claims_pm>=250 and claims_pm <300 then ''$250-$300''
	when claims_pm>=300 then ''$300+'' end) as claims_pm_pm,
count(pers_id) as mbr_cnt
from IDENTIFIER(:V_garya3_TMP_INFORCE_BASE_FINAL) 
group by membership_month, 
(case when claims_pm<0 then ''Less than zero''
	when claims_pm>=0 and claims_pm <50 then ''$0-$50''
	when claims_pm>=50 and claims_pm <100 then ''$50-$100''
	when claims_pm>=100 and claims_pm <150 then ''$100-$150''
	when claims_pm>=150 and claims_pm <200 then ''$150-$200''
	when claims_pm>=200 and claims_pm <250 then ''$200-$250''
	when claims_pm>=250 and claims_pm <300 then ''$250-$300''
	when claims_pm>=300 then ''$300+'' end)
order by membership_month, claims_pm_pm;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_garya3_TMP_INFORCE_CLAIMS_PM)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

V_STEP := ''STEP32'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_TMP_INFORCE_MLR'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_garya3_TMP_INFORCE_MLR) copy grants as
select membership_month,
(case when mlr<=0 then ''<=0''
	when mlr>0 and mlr <0.5 then ''0-0.5''
	when mlr>=0.5 and mlr <0.8 then ''0.5-0.8''
	when mlr>=0.8 and mlr <1 then ''0.8-1''
	when mlr>=1 and mlr <1.5 then ''1-1.5''
	when mlr>=1.5 then ''>=1.5'' end) as mlr, 
count(pers_id) as mbr_cnt
from IDENTIFIER(:V_garya3_TMP_INFORCE_BASE_FINAL) 
group by membership_month,
(case when mlr<=0 then ''<=0''
	when mlr>0 and mlr <0.5 then ''0-0.5''
	when mlr>=0.5 and mlr <0.8 then ''0.5-0.8''
	when mlr>=0.8 and mlr <1 then ''0.8-1''
	when mlr>=1 and mlr <1.5 then ''1-1.5''
	when mlr>=1.5 then ''>=1.5'' end)
order by membership_month, mlr;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_garya3_TMP_INFORCE_MLR)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP33'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_TMP_KPI_TRANS_DAY'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


CREATE or replace TABLE IDENTIFIER(:V_garya3_TMP_KPI_TRANS_DAY) copy grants as
SELECT d_mbr_info_sk, prdct_eff_dt_id, CERT_EFF_DT_ID, TERM_CERT_QTY,
D_PLN_BEN_MOD_SK, PREM_DUE_DT_ID, PD_CERT_QTY, DELQ_CERT_QTY,prdct_D_ACQN_CHNL_SK, d_cert_actv_sk,RES_D_GEO_XREF_SK
FROM IDENTIFIER(:V_REFINED_ISDW_PREM_V_F_PREM_TRANS_DAY) WHERE PREM_DUE_DT_ID >= 20180101; 


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_garya3_TMP_KPI_TRANS_DAY)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP34'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_TMP_KPI_VOLN_LAPSE_DAILY'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


CREATE OR REPLACE TABLE IDENTIFIER(:V_garya3_TMP_KPI_VOLN_LAPSE_DAILY) COPY GRANTS AS
SELECT PREM_DUE_dt_ID
	,prdct_eff_dt_id
	,CERT_EFF_dt_ID
	,pers_id
	,a16.CERT_ACTV_LVL_2_TXT
	,a16.CERT_ACTV_LVL_1_TXT
	,a11.d_cert_actv_sk
	,SUM(a11.TERM_CERT_QTY) AS term
FROM IDENTIFIER(:V_garya3_TMP_KPI_TRANS_DAY) a11
LEFT OUTER JOIN IDENTIFIER(:V_refined_isdw_ref_V_D_PLN_BEN_MOD) a12
	ON (a11.D_PLN_BEN_MOD_SK = a12.D_PLN_BEN_MOD_SK)
LEFT OUTER JOIN IDENTIFIER(:V_refined_isdw_ref_V_D_GEO_XREF)     a13
	ON (a11.RES_D_GEO_XREF_SK = a13.D_GEO_XREF_SK)
LEFT OUTER JOIN IDENTIFIER(:V_refined_isdw_ref_V_D_ST)     a14
	ON (a13.D_ST_CD = a14.D_ST_CD)
LEFT JOIN IDENTIFIER(:V_refined_isdw_ref_V_D_MBR_INFO) a15
ON a11.d_mbr_info_sk = a15.d_mbr_info_sk
LEFT JOIN IDENTIFIER(:V_refined_isdw_ref_V_D_CERT_ACTV)   a16
	ON (a11.D_CERT_ACTV_SK = a16.D_CERT_ACTV_SK)
WHERE (TRIM(a12.LF_CATGY_NM) IN (''Med Supp-Pre-Standardized'', ''Med Supp-Select'', ''Med Supp-Standardized/Modernized'')
AND (a11.d_cert_actv_sk BETWEEN 19 AND 49 OR a11.d_cert_actv_sk BETWEEN 3 AND 11)) 
GROUP BY PREM_DUE_dt_ID,prdct_eff_dt_id,CERT_EFF_dt_ID,pers_id,a16.CERT_ACTV_LVL_2_TXT,a16.CERT_ACTV_LVL_1_TXT,
a11.d_cert_actv_sk
HAVING term > 0;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_garya3_TMP_KPI_VOLN_LAPSE_DAILY)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP35'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_TMP_KPI_LAPSE_DAILY'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


CREATE OR REPLACE TABLE IDENTIFIER(:V_garya3_TMP_KPI_LAPSE_DAILY) COPY GRANTS AS
SELECT a.* FROM 
(
	SELECT b.*,
		ROW_NUMBER() OVER (PARTITION BY pers_id ORDER BY pers_id, PREM_DUE_dt_ID DESC) rn
	FROM IDENTIFIER(:V_garya3_TMP_KPI_VOLN_LAPSE_DAILY) b
) a
WHERE rn =1;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_garya3_TMP_KPI_LAPSE_DAILY)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP36'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_TMP_KPI_STR_LAPSE_DAILY'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


CREATE OR REPLACE TABLE IDENTIFIER(:V_garya3_TMP_KPI_STR_LAPSE_DAILY) COPY GRANTS AS
SELECT a.*, 
	CAST(CONCAT(SUBSTR(str_date,1,4),''-'', SUBSTR(str_date,5,2),''-'',SUBSTR(str_date,7,2)) AS DATE) AS prem_pm_due_date FROM
	(
	SELECT pers_id, d_cert_actv_sk,CERT_ACTV_LVL_2_TXT,CERT_ACTV_LVL_1_TXT,
	CAST(PREM_DUE_dt_ID AS string) AS str_date, term 
	FROM IDENTIFIER(:V_garya3_TMP_KPI_LAPSE_DAILY) WHERE d_cert_actv_sk BETWEEN 19 AND 49
	)a;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_garya3_TMP_KPI_STR_LAPSE_DAILY)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP37'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_TMP_KPI_LAPSE_MLR '';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


CREATE OR REPLACE TABLE IDENTIFIER(:V_garya3_TMP_KPI_LAPSE_MLR) COPY GRANTS AS
select a.*
,b.prem_due_dt as claim_month
,COALESCE(b.claim_cf_covid,0) as claim_cf_covid,
COALESCE(b.paid_prem,0) as paid_prem from IDENTIFIER(:V_garya3_TMP_KPI_STR_LAPSE_DAILY) a
left join IDENTIFIER(:V_ffp_inforce_lr_P_LVL_CLAIM_INFO) b on a.pers_id = b.pers_id 
and b.prem_due_dt between add_months(a.prem_pm_due_date,-12) and a.prem_pm_due_date
and b.pers_id is not null ;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_garya3_TMP_KPI_LAPSE_MLR)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP38'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_TMP_KPI_LAPSE_MLR_V2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


CREATE OR REPLACE TABLE IDENTIFIER(:V_garya3_TMP_KPI_LAPSE_MLR_V2) COPY GRANTS AS
select 
	case when prem_pm_due_date between add_months(:V_LATEST_LAPSE_MONTH,-11) and :V_LATEST_LAPSE_MONTH then add_months(:V_LATEST_LAPSE_MONTH,-12)
	when prem_pm_due_date between add_months(:V_LATEST_LAPSE_MONTH,-11-12) and add_months(:V_LATEST_LAPSE_MONTH,-12) then add_months(:V_LATEST_LAPSE_MONTH,-24)
	when prem_pm_due_date between add_months(:V_LATEST_LAPSE_MONTH,-11-24) and add_months(:V_LATEST_LAPSE_MONTH,-24) then add_months(:V_LATEST_LAPSE_MONTH,-36)
	when prem_pm_due_date between add_months(:V_LATEST_LAPSE_MONTH,-11-36) and add_months(:V_LATEST_LAPSE_MONTH,-36) then add_months(:V_LATEST_LAPSE_MONTH,-48)
	end as joining_month,
	pers_id, prem_pm_due_date, cert_actv_lvl_1_txt, cert_actv_lvl_2_txt
	,count(*) as row_count
	,sum(claim_cf_covid) as total_claim
	,(sum(claim_cf_covid)/count(*)) as claim_pm
	,sum(paid_prem) as total_prem_pm
	,(sum(paid_prem)/count(*)) as prem_pm
	,(sum(claim_cf_covid)/sum(nullif(paid_prem, 0))) as mlr
from IDENTIFIER(:V_garya3_TMP_KPI_LAPSE_MLR) 
where prem_pm_due_date between add_months(:V_LATEST_LAPSE_MONTH,-11-12-12-12) and :V_LATEST_LAPSE_MONTH
and cert_actv_lvl_2_txt in (''PLAN TERM (TERM DT GT EFF DT)-DEATH'',''PLAN TERM (TERM DT GT EFF DT)-NON_PAYMENT OF PREMIUM'',''PLAN TERM (TERM DT GT EFF DT)-VOLUNTARY'')
group by 
	case when prem_pm_due_date between add_months(:V_LATEST_LAPSE_MONTH,-11) and :V_LATEST_LAPSE_MONTH then add_months(:V_LATEST_LAPSE_MONTH,-12)
	when prem_pm_due_date between add_months(:V_LATEST_LAPSE_MONTH,-11-12) and add_months(:V_LATEST_LAPSE_MONTH,-12) then add_months(:V_LATEST_LAPSE_MONTH,-24)
	when prem_pm_due_date between add_months(:V_LATEST_LAPSE_MONTH,-11-24) and add_months(:V_LATEST_LAPSE_MONTH,-24) then add_months(:V_LATEST_LAPSE_MONTH,-36)
	when prem_pm_due_date between add_months(:V_LATEST_LAPSE_MONTH,-11-36) and add_months(:V_LATEST_LAPSE_MONTH,-36) then add_months(:V_LATEST_LAPSE_MONTH,-48)
	end, pers_id, prem_pm_due_date, cert_actv_lvl_1_txt, cert_actv_lvl_2_txt;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_garya3_TMP_KPI_LAPSE_MLR_V2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP39'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_TMP_KPI_LAPSE_MLR_V3'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


CREATE OR REPLACE TABLE IDENTIFIER(:V_garya3_TMP_KPI_LAPSE_MLR_V3) COPY GRANTS AS
select *, 
--date_format(add_months(joining_month,1),''MMM'')+''-''+substr(cast(year(add_months(joining_month,1)) as string),3,2)+'' to ''+
--date_format(add_months(joining_month,12),''MMM'')+''-''+substr(cast(year(add_months(joining_month,12)) as string),3,2) as lapse_duration
null as lapse_duration
from IDENTIFIER(:V_garya3_TMP_KPI_LAPSE_MLR_V2);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_garya3_TMP_KPI_LAPSE_MLR_V3)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP40'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_TMP_VOL_LAPSE_PREM_PM'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create OR REPLACE table IDENTIFIER(:V_garya3_TMP_VOL_LAPSE_PREM_PM) COPY GRANTS AS
select lapse_duration,joining_month
,(case when prem_pm<0 then ''Less than zero''
	when prem_pm>=0 and prem_pm <50 then ''$0-$50''
	when prem_pm>=50 and prem_pm <100 then ''$50-$100''
	when prem_pm>=100 and prem_pm <150 then ''$100-$150''
	when prem_pm>=150 and prem_pm <200 then ''$150-$200''
	when prem_pm>=200 and prem_pm <250 then ''$200-$250''
	when prem_pm>=250 and prem_pm <300 then ''$250-$300''
	when prem_pm>=300 then ''$300+'' end) as prem_pm_pm
,count(pers_id) as mbr_cnt
from IDENTIFIER(:V_garya3_TMP_KPI_LAPSE_MLR_V3) where cert_actv_lvl_2_txt like ''%NON_PAYMENT OF PREMIUM%'' or cert_actv_lvl_2_txt like ''%VOLUNTARY%''
group by lapse_duration,joining_month
,(case when prem_pm<0 then ''Less than zero''
	when prem_pm>=0 and prem_pm <50 then ''$0-$50''
	when prem_pm>=50 and prem_pm <100 then ''$50-$100''
	when prem_pm>=100 and prem_pm <150 then ''$100-$150''
	when prem_pm>=150 and prem_pm <200 then ''$150-$200''
	when prem_pm>=200 and prem_pm <250 then ''$200-$250''
	when prem_pm>=250 and prem_pm <300 then ''$250-$300''
	when prem_pm>=300 then ''$300+'' end);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_garya3_TMP_VOL_LAPSE_PREM_PM)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



V_STEP := ''STEP41'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_TMP_VOL_LAPSE_CLAIMS_PM'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create OR REPLACE table IDENTIFIER(:V_garya3_TMP_VOL_LAPSE_CLAIMS_PM) COPY GRANTS AS
select lapse_duration,joining_month
,(case when claim_pm<0 then ''Less than zero''
	when claim_pm>=0 and claim_pm <50 then ''$0-$50''
	when claim_pm>=50 and claim_pm <100 then ''$50-$100''
	when claim_pm>=100 and claim_pm <150 then ''$100-$150''
	when claim_pm>=150 and claim_pm <200 then ''$150-$200''
	when claim_pm>=200 and claim_pm <250 then ''$200-$250''
	when claim_pm>=250 and claim_pm <300 then ''$250-$300''
	when claim_pm>=300 then ''$300+'' end) as claim_pm_pm
,count(pers_id) as mbr_cnt
from IDENTIFIER(:V_garya3_TMP_KPI_LAPSE_MLR_V3) where cert_actv_lvl_2_txt like ''%NON_PAYMENT OF PREMIUM%'' or cert_actv_lvl_2_txt like ''%VOLUNTARY%''
group by lapse_duration,joining_month
,(case when claim_pm<0 then ''Less than zero''
	when claim_pm>=0 and claim_pm <50 then ''$0-$50''
	when claim_pm>=50 and claim_pm <100 then ''$50-$100''
	when claim_pm>=100 and claim_pm <150 then ''$100-$150''
	when claim_pm>=150 and claim_pm <200 then ''$150-$200''
	when claim_pm>=200 and claim_pm <250 then ''$200-$250''
	when claim_pm>=250 and claim_pm <300 then ''$250-$300''
	when claim_pm>=300 then ''$300+'' end);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_garya3_TMP_VOL_LAPSE_CLAIMS_PM)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

V_STEP := ''STEP42'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_TMP_VOL_LAPSE_MLR'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create OR REPLACE table IDENTIFIER(:V_garya3_TMP_VOL_LAPSE_MLR) COPY GRANTS AS
select lapse_duration,joining_month
--,cert_actv_lvl_2_txt
,(case when mlr<=0 then ''<=0''
	when mlr>0 and mlr <0.5 then ''0-0.5''
	when mlr>=0.5 and mlr <0.8 then ''0.5-0.8''
	when mlr>=0.8 and mlr <1 then ''0.8-1''
	when mlr>=1 and mlr <1.5 then ''1-1.5''
	when mlr>=1.5 then ''>=1.5'' end) as mlr
,count(pers_id) as mbr_cnt
from IDENTIFIER(:V_garya3_TMP_KPI_LAPSE_MLR_V3) where cert_actv_lvl_2_txt like ''%NON_PAYMENT OF PREMIUM%'' or cert_actv_lvl_2_txt like ''%VOLUNTARY%''
group by lapse_duration,joining_month
--,cert_actv_lvl_2_txt
,(case when mlr<=0 then ''<=0''
	when mlr>0 and mlr <0.5 then ''0-0.5''
	when mlr>=0.5 and mlr <0.8 then ''0.5-0.8''
	when mlr>=0.8 and mlr <1 then ''0.8-1''
	when mlr>=1 and mlr <1.5 then ''1-1.5''
	when mlr>=1.5 then ''>=1.5'' end);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_garya3_TMP_VOL_LAPSE_MLR)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP43'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_TMP_INVOL_LAPSE_PREM_PM'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create OR REPLACE table IDENTIFIER(:V_garya3_TMP_INVOL_LAPSE_PREM_PM) COPY GRANTS AS
select lapse_duration,joining_month
--,cert_actv_lvl_2_txt
,(case when prem_pm<0 then ''Less than zero''
	when prem_pm>=0 and prem_pm <50 then ''$0-$50''
	when prem_pm>=50 and prem_pm <100 then ''$50-$100''
	when prem_pm>=100 and prem_pm <150 then ''$100-$150''
	when prem_pm>=150 and prem_pm <200 then ''$150-$200''
	when prem_pm>=200 and prem_pm <250 then ''$200-$250''
	when prem_pm>=250 and prem_pm <300 then ''$250-$300''
	when prem_pm>=300 then ''$300+'' end) as prem_pm_pm
,count(pers_id) as mbr_cnt
from IDENTIFIER(:V_garya3_TMP_KPI_LAPSE_MLR_V3) where cert_actv_lvl_2_txt like ''%DEATH%''
group by lapse_duration,joining_month
--,cert_actv_lvl_2_txt
,(case when prem_pm<0 then ''Less than zero''
	when prem_pm>=0 and prem_pm <50 then ''$0-$50''
	when prem_pm>=50 and prem_pm <100 then ''$50-$100''
	when prem_pm>=100 and prem_pm <150 then ''$100-$150''
	when prem_pm>=150 and prem_pm <200 then ''$150-$200''
	when prem_pm>=200 and prem_pm <250 then ''$200-$250''
	when prem_pm>=250 and prem_pm <300 then ''$250-$300''
	when prem_pm>=300 then ''$300+'' end);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_garya3_TMP_INVOL_LAPSE_PREM_PM)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP44'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_TMP_INVOL_LAPSE_CLAIMS_PM'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create OR REPLACE table IDENTIFIER(:V_garya3_TMP_INVOL_LAPSE_CLAIMS_PM) COPY grants AS
select lapse_duration,joining_month
--,cert_actv_lvl_2_txt
,(case when claim_pm<0 then ''Less than zero''
	when claim_pm>=0 and claim_pm <50 then ''$0-$50''
	when claim_pm>=50 and claim_pm <100 then ''$50-$100''
	when claim_pm>=100 and claim_pm <150 then ''$100-$150''
	when claim_pm>=150 and claim_pm <200 then ''$150-$200''
	when claim_pm>=200 and claim_pm <250 then ''$200-$250''
	when claim_pm>=250 and claim_pm <300 then ''$250-$300''
	when claim_pm>=300 then ''$300+'' end) as claim_pm_pm
,count(pers_id) as mbr_cnt
from IDENTIFIER(:V_garya3_TMP_KPI_LAPSE_MLR_V3) where cert_actv_lvl_2_txt like ''%DEATH%''
group by lapse_duration,joining_month
--,cert_actv_lvl_2_txt
,(case when claim_pm<0 then ''Less than zero''
	when claim_pm>=0 and claim_pm <50 then ''$0-$50''
	when claim_pm>=50 and claim_pm <100 then ''$50-$100''
	when claim_pm>=100 and claim_pm <150 then ''$100-$150''
	when claim_pm>=150 and claim_pm <200 then ''$150-$200''
	when claim_pm>=200 and claim_pm <250 then ''$200-$250''
	when claim_pm>=250 and claim_pm <300 then ''$250-$300''
	when claim_pm>=300 then ''$300+'' end);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_garya3_TMP_INVOL_LAPSE_CLAIMS_PM)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP45'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_TMP_INVOL_LAPSE_MLR'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create OR REPLACE table IDENTIFIER(:V_garya3_TMP_INVOL_LAPSE_MLR) COPY GRANTS AS
select lapse_duration,joining_month
--,cert_actv_lvl_2_txt
,(case when mlr<=0 then ''<=0''
	when mlr>0 and mlr <0.5 then ''0-0.5''
	when mlr>=0.5 and mlr <0.8 then ''0.5-0.8''
	when mlr>=0.8 and mlr <1 then ''0.8-1''
	when mlr>=1 and mlr <1.5 then ''1-1.5''
	when mlr>=1.5 then ''>=1.5'' end) as mlr
,count(pers_id) as mbr_cnt
from IDENTIFIER(:V_garya3_TMP_KPI_LAPSE_MLR_V3) where cert_actv_lvl_2_txt like ''%DEATH%''
group by lapse_duration,joining_month
--,cert_actv_lvl_2_txt
,(case when mlr<=0 then ''<=0''
	when mlr>0 and mlr <0.5 then ''0-0.5''
	when mlr>=0.5 and mlr <0.8 then ''0.5-0.8''
	when mlr>=0.8 and mlr <1 then ''0.8-1''
	when mlr>=1 and mlr <1.5 then ''1-1.5''
	when mlr>=1.5 then ''>=1.5'' end);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_garya3_TMP_INVOL_LAPSE_MLR)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP46'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_KPI_PREM_PMPM'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create OR REPLACE table IDENTIFIER(:V_garya3_KPI_PREM_PMPM) COPY GRANTS AS
select a.membership_month, coalesce(b.lapse_duration, c.lapse_duration) as lapse_duration,
	coalesce(a.prem_pm_pm, b.prem_pm_pm, c.prem_pm_pm) as prem_pm_pm, 
	a.mbr_cnt as inforce_mbr, 
	b.mbr_cnt as vol_lapsers, 
	c.mbr_cnt as invol_lapsers	
from IDENTIFIER(:V_garya3_TMP_INFORCE_PREM_PM) a
full join IDENTIFIER(:V_garya3_TMP_VOL_LAPSE_PREM_PM) b on a.membership_month = b.joining_month and a.prem_pm_pm = b.prem_pm_pm
full join IDENTIFIER(:V_garya3_TMP_INVOL_LAPSE_PREM_PM) c on a.membership_month = c.joining_month and a.prem_pm_pm = c.prem_pm_pm;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_garya3_KPI_PREM_PMPM)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP47'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_KPI_CLAIMS_PMPM'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create OR REPLACE table IDENTIFIER(:V_garya3_KPI_CLAIMS_PMPM) COPY GRANTS AS
select a.membership_month, coalesce(b.lapse_duration, c.lapse_duration) as lapse_duration,
	coalesce(a.claims_pm_pm, b.claim_pm_pm, c.claim_pm_pm) as claim_pm_pm, 
	a.mbr_cnt as inforce_mbr, 
	b.mbr_cnt as vol_lapsers, 
	c.mbr_cnt as invol_lapsers	
from IDENTIFIER(:V_garya3_TMP_INFORCE_CLAIMS_PM) a
full join IDENTIFIER(:V_garya3_TMP_VOL_LAPSE_CLAIMS_PM) b on a.membership_month = b.joining_month and a.claims_pm_pm = b.claim_pm_pm
full join IDENTIFIER(:V_garya3_TMP_INVOL_LAPSE_CLAIMS_PM) c on a.membership_month = c.joining_month and a.claims_pm_pm = c.claim_pm_pm;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_garya3_KPI_CLAIMS_PMPM)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP48'';

V_STEP_NAME :=  ''create table IS_KPI_BPD_KPI_MLR'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create OR REPLACE table IDENTIFIER(:V_garya3_KPI_MLR) COPY GRANTS AS
select a.membership_month, coalesce(b.lapse_duration, c.lapse_duration) as lapse_duration,
	coalesce(a.mlr, b.mlr, c.mlr) as mlr, 
	a.mbr_cnt as inforce_mbr, 
	b.mbr_cnt as vol_lapsers, 
	c.mbr_cnt as invol_lapsers	
from IDENTIFIER(:V_garya3_TMP_INFORCE_MLR) a
full join IDENTIFIER(:V_garya3_TMP_VOL_LAPSE_MLR) b on a.membership_month = b.joining_month and a.mlr = b.mlr
full join IDENTIFIER(:V_garya3_TMP_INVOL_LAPSE_MLR) c on a.membership_month = c.joining_month and a.mlr = c.mlr;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_garya3_KPI_MLR)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


								




EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);


RAISE;

END;

';