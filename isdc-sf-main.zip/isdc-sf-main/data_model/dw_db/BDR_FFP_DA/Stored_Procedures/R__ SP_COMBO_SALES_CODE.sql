USE SCHEMA BDR_FFP_DA;



CREATE OR REPLACE PROCEDURE BDR_FFP_DA.SP_COMBO_SALES_CODE("PIPELINE_ID" VARCHAR(16777216), "PIPELINE_NAME" VARCHAR(16777216), "DB_NAME" VARCHAR(16777216), "UTIL_SC" VARCHAR(16777216), "TGT_SC" VARCHAR(16777216), "FFP_WRK_SC" VARCHAR(16777216), "SRC_SC_1" VARCHAR(16777216), "SRC_SC_2" VARCHAR(16777216), "SRC_SC_3" VARCHAR(16777216), "SRC_SC_4" VARCHAR(16777216), "SRC_SC_6" VARCHAR(16777216), "SRC_SC_7" VARCHAR(16777216), "SRC_SC_8" VARCHAR(16777216), "WH" VARCHAR(16777216), "CURR_DATE" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

V_CURRENT_DATE   DATE := COALESCE(:CURR_DATE, CURRENT_DATE());

V_CURRENT_DT VARCHAR := COALESCE(TO_CHAR(:V_CURRENT_DATE,''YYYYMMDD''), ''FILL DEFAULT VALUE'');

V_START_DT_YMD VARCHAR := ''''||''2015-01-01''||'''';

V_START_DT_YM VARCHAR := ''''||''201501''||'''';

V_CURR_YM VARCHAR := COALESCE(TO_CHAR(:V_CURRENT_DATE,''YYYYMM''), ''FILL DEFAULT VALUE'');

V_PREV_YMD VARCHAR := COALESCE(DATEADD(DAY,-31,:V_CURRENT_DATE), ''FILL DEFAULT VALUE'');

V_PREV_YMD_1 VARCHAR := ''''||COALESCE(DATEADD(DAY,-31,:V_CURRENT_DATE), ''FILL DEFAULT VALUE'')||'''';


V_CURR_YMD VARCHAR := COALESCE(:V_CURRENT_DATE, ''FILL DEFAULT VALUE'');


V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := :DB_NAME||''.''||COALESCE(:UTIL_SC, ''UTIL'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';

V_PROCESS_NAME   VARCHAR DEFAULT ''MS_PDP_COMBO_SALES'';

V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''MS_PDP_COMBO_SALES'';

V_STEP             VARCHAR;

V_STEP_NAME        VARCHAR;

V_START_TIME       VARCHAR;

V_END_TIME         VARCHAR;

V_ROWS_PARSED       INTEGER;

V_ROWS_LOADED       INTEGER;

V_MESSAGE          VARCHAR;

V_LAST_QUERY_ID    VARCHAR;

V_SQL_QUERY VARCHAR;

V_CMS_HICN_TO_MBI_CROSSWALK VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_1, ''SRC_UCEE'') || ''.CMS_HICN_TO_MBI_CROSSWALK'';

V_PDP_SALES_2018_2021_V4 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.PDP_SALES_2018_2021_V4'';

V_PDP_SALES_2018_2021_V5 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.PDP_SALES_2018_2021_V5'';

V_D_GEO_XREF VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_2, ''BDR_CONF'') || ''.D_GEO_XREF'';

V_SPECIFICATION VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_4, ''db_ffp_wrk'') || ''.SPECIFICATION'';

V_SHIP_PERSON_XREF_SUBSET VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.SHIP_PERSON_XREF_SUBSET'';

V_MS_CROSS_SALES_ALL_YR_2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.MS_CROSS_SALES_ALL_YR_2'';

V_F_PREM_TRANS_DAY VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_3, ''BDR_DM'') || ''.F_PREM_TRANS_DAY'';

V_MS_CROSS_SALES_ALL_YR_2_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.MS_CROSS_SALES_ALL_YR_2_1'';

V_MS_PDP_COMBO_SALES_V3 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.MS_PDP_COMBO_SALES_V3'';

V_MS_SALES_2018_2021_V4 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.MS_SALES_2018_2021_V4'';

V_MSPDP_FINAL_SUMMARY_MS_BACKUP VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.MSPDP_FINAL_SUMMARY_MS_BACKUP'';

V_D_MBR_INFO_SUBSET VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.V_D_MBR_INFO_SUBSET'';

V_CMDB_PERSON_XREF_INTERFACE VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_4, ''BDR_SMART'') || ''.CMDB_PERSON_XREF_INTERFACE'';

V_PERSON_COMPAS_DAILY_SNAPSHOT_DECRYPT VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_4, ''BDR_SMART'') || ''.PERSON_COMPAS_DAILY_SNAPSHOT'';

V_STATE VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_4, ''BDR_SMART'') || ''.STATE'';

V_MS_MBR_ALL_YR_V4 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.MS_MBR_ALL_YR_V4'';

V_MSPDP_FINAL_SUMMARY_MS VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.MSPDP_FINAL_SUMMARY_MS'';

V_MS_SUMMARY_INTMD VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.MS_SUMMARY_INTMD'';

V_D_PLN_BEN_MOD VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_2, ''BDR_CONF'') || ''.D_PLN_BEN_MOD'';

V_MSPDP_FINAL_SUMMARY_PDP_BACKUP VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.COMBOSALES_MSPDP_FINAL_SUMMARY_PDP_BACKUP'';

V_MS_PDP_COMBO_SUMMARY_DASHBOARD VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.MS_PDP_COMBO_SUMMARY_DASHBOARD'';

V_SHIP_PERSON_XREF VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_4, ''BDR_SMART'') || ''.SHIP_PERSON_XREF'';

V_MS_SALES_2018_2021_V3 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.MS_SALES_2018_2021_V3'';

V_PLAN VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_1, ''SRC_UCEE'') || ''.PLAN'';

V_MSPDP_CROSS_SALES_SUMMARY_PDP VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.COMBOSALES_MSPDP_CROSS_SALES_SUMMARY_PDP'';

V_FINAL_SUMMARY_MS VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.FINAL_SUMMARY_MS'';

V_PDP_MBR_CONT VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.PDP_MBR_CONT'';

V_PDP_SALES_2018_2021 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.PDP_SALES_2018_2021'';

V_D_AGT VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_2, ''BDR_CONF'') || ''.D_AGT'';

V_PDP_INDV_MBR_CONT VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_8, ''SRC_FIN360'') || ''.PDP_INDV_MBR_CONT'';

V_F_PREM_TRANS_DAY_SUBSET VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.V_F_PREM_TRANS_DAY_SUBSET'';

V_PDP_MBR_NONCONT_MBI_CRSWLK VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.PDP_MBR_NONCONT_MBI_CRSWLK'';

V_PDP_SALES_2018_2021_V2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.PDP_SALES_2018_2021_V2'';

V_PDP_SALES_MBI_CRSWLK VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.PDP_SALES_MBI_CRSWLK'';

V_MS_SALES_2018_2021_V2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.MS_SALES_2018_2021_V2'';

V_MS_CROSS_SALES_SUMMARY VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.MS_CROSS_SALES_SUMMARY'';

V_MS_PDP_COMBO_SALES_V4 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.MS_PDP_COMBO_SALES_V4'';

V_MS_PDP_COMBO_SALES VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.MS_PDP_COMBO_SALES'';

V_MSPDP_CROSS_SALES_SUMMARY_MS VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.COMBOSALES_MSPDP_CROSS_SALES_SUMMARY_MS'';

V_MS_PDP_COMBO_SALES_V5 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.MS_PDP_COMBO_SALES_V5'';

V_D_CERT_ACTV VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_2, ''BDR_CONF'') || ''.D_CERT_ACTV'';

V_PDP_MBR_NONCONT VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.PDP_MBR_NONCONT'';

V_APPLICATION VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_4, ''BDR_SMART'') || ''.APPLICATION'';

V_ACTV_MBR4_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.ACTV_MBR4_1'';

V_FINAL_SUMMARY_PDP VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.FINAL_SUMMARY_PDP'';

V_D_CNTY VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_2, ''BDR_CONF'') || ''.D_CNTY'';

V_MS_SALES_2018_2021_V10 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.MS_SALES_2018_2021_V10'';

V_COMBO_SALES_FROM_MS_SALES VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.COMBO_SALES_FROM_MS_SALES'';

V_PDP_SALES_2018_2021_V10 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.PDP_SALES_2018_2021_V10'';

V_MSPDP_COMBO_SALES_TRIMMED VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.COMBOSALES_MSPDP_COMBO_SALES_TRIMMED'';

V_NEW_CATEGORIZATION_PSC_ALL VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_1, ''SRC_UCEE'') || ''.NEW_CATEGORIZATION_PSC_ALL'';

V_ACTV_MBR3 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.ACTV_MBR3'';

V_MS_SALES_2018_2021_V6 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.MS_SALES_2018_2021_V6'';

V_D_ACQN_CHNL VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_2, ''BDR_CONF'') || ''.D_ACQN_CHNL'';

V_D_GDR_LOOK VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_2, ''BDR_CONF'') || ''.D_GDR_LOOK'';

V_MS_CROSS_SALES_SUMMARY_MS_LVL VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.MS_CROSS_SALES_SUMMARY_MS_LVL'';

V_MS_MBR_ALL_YR_V3 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.MS_MBR_ALL_YR_V3'';

V_MS_MBR_MBI VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.MS_MBR_MBI'';

V_MS_CROSS_SALES_ALL_YR_V2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.MS_CROSS_SALES_ALL_YR_V2'';

V_D_ST VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_2, ''BDR_CONF'') || ''.D_ST'';

V_PDP_SUMMARY_INTMD VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.PDP_SUMMARY_INTMD'';

V_PDP_MBR_CONT_MBI_CRSWLK VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.PDP_MBR_CONT_MBI_CRSWLK'';

V_PDP_MBR_CONT_V2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.PDP_MBR_CONT_V2'';

V_PDP_SALES_2018_2021_V3 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.PDP_SALES_2018_2021_V3'';

V_EALLIANCE VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_7, ''SRC_MPO'') || ''.EALLIANCE'';

V_ALL_APPS_FEDERAL VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_1, ''SRC_UCEE'') || ''.ALL_APPS_FEDERAL'';

V_PDP_MBR_NONCONT_V2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.PDP_MBR_NONCONT_V2'';

V_MS_SALES_2018_2021 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.MS_SALES_2018_2021'';

V_MS_SUMMARY VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.MS_SUMMARY'';

V_MS_PRDCT_EFF VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.MS_PRDCT_EFF'';

V_MS_MEMBERSHIP_MBI_CRSWLK VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.MS_MEMBERSHIP_MBI_CRSWLK'';

V_PDP_CROSS_SALES_ALL_YR VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.PDP_CROSS_SALES_ALL_YR'';

V_ACTV_MBR4 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.ACTV_MBR4'';

V_MS_SALES_2018_2021_SUBSET VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.MS_SALES_2018_2021_SUBSET'';

V_ACTV_MBR4_2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.ACTV_MBR4_2'';

V_PDP_CROSS_SALES_SUMMARY VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.PDP_CROSS_SALES_SUMMARY'';

V_FED_MEMBERS VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_1, ''SRC_UCEE'') || ''.FED_MEMBERS'';

V_MSPDP_COMBO_SUMMARY VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.COMBOSALES_MSPDP_COMBO_SUMMARY'';

V_APPS_RPTG_DAILY VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_7, ''SRC_MPO'') || ''.APPS_RPTG_DAILY'';

V_MS_MBR_ALL_YR VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.MS_MBR_ALL_YR'';

V_MS_CROSS_SALES_ALL_YR_2_V2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.MS_CROSS_SALES_ALL_YR_2_V2'';

V_MS_CROSS_SALES_ALL_YR VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.MS_CROSS_SALES_ALL_YR'';

V_COMPAS_PLAN_IDS VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.COMPAS_PLAN_IDS'';

V_MSPDP_FINAL_SUMMARY_PDP VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.MSPDP_FINAL_SUMMARY_PDP'';

V_MS_PDP_COMBO_SUMMARY_PDP_LVL VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.MS_PDP_COMBO_SUMMARY_PDP_LVL'';

V_ACTV_MBR4_3 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.ACTV_MBR4_3'';

V_PDP_CROSS_SALES_SUMMARY_PDP_LVL VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.PDP_CROSS_SALES_SUMMARY_PDP_LVL'';

V_MS_MBR_ALL_YR_V5 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.MS_MBR_ALL_YR_V5'';

V_MS_PRDCT_EFF_V2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.MS_PRDCT_EFF_V2'';

V_MS_SALES_2018_2021_V5 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.MS_SALES_2018_2021_V5'';

V_PDP_SUMMARY VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.PDP_SUMMARY'';

V_PDP_SALES_2018_2021_V6 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.PDP_SALES_2018_2021_V6'';

V_MS_PDP_COMBO_SUMMARY_MS_LVL VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.MS_PDP_COMBO_SUMMARY_MS_LVL'';

V_COMBO_SALES_FROM_PDP_SALES VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.COMBO_SALES_FROM_PDP_SALES'';

V_D_MBR_INFO VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_2, ''BDR_CONF'') || ''.D_MBR_INFO'';

V_INSURED_PLAN VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_4, ''BDR_SMART'') || ''.INSURED_PLAN'';

V_BUSINESS_SALES_MARKET_MAPPING VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_6, ''db_ffp_wrk'') || ''.BUSINESS_SALES_MARKET_MAPPING'';

V_F_PREM_TRANS_DAY_SUBSET_A VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.V_F_PREM_TRANS_DAY_SUBSET_A'';

V_MSPDP_FINAL_SUMMARY_PDP_BACKUP_CURRENT_DT VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.MSPDP_FINAL_SUMMARY_PDP_BACKUP_CURRENT_DT'';

V_MS_SALES_QC VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.COMBOSALES_MS_SALES_QC'';

V_CURR_MONTH_SUMM_MS VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.COMBOSALES_CURR_MONTH_SUMM_MS'';

V_PDP_SALES_QC VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.COMBOSALES_PDP_SALES_QC'';

V_MSPDP_FINAL_SUMMARY_MS_BACKUP_CURRENT_DT VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''db_ffp_wrk'') || ''.MSPDP_FINAL_SUMMARY_MS_BACKUP_CURRENT_DT'';

V_CURR_MONTH_SUMM_PDP VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.COMBOSALES_CURR_MONTH_SUMM_PDP'';




BEGIN


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

USE SECONDARY ROLES ALL;

V_STEP := ''STEP1'';

V_STEP_NAME :=   ''create a table F_PREM_TRANS_DAY_SUBSET_A'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());



create or replace  table IDENTIFIER(:V_F_PREM_TRANS_DAY_SUBSET_A) as select
PREM_DUE_DT_ID,acct_nbr,d_mbr_info_sk,COMPAS_INSD_PLN_ID,PD_CERT_QTY,DELQ_CERT_QTY,D_CERT_ACTV_SK,D_PLN_BEN_MOD_SK,PRDCT_D_ACQN_CHNL_SK,RES_D_GEO_XREF_SK,CERT_D_ACQN_CHNL_SK,D_GDR_ID_SK,agt_sel_orig_d_agt_sk,agt_ref_orig_d_agt_sk,prdct_eff_dt_id,prem_due_age_id,floor(PREM_DUE_DT_ID/100) as PREM_DUE_DT_ID_floor,floor(prdct_eff_dt_id/100) as prdct_eff_dt_id_floor
from IDENTIFIER(:V_F_PREM_TRANS_DAY); 


V_STEP := ''STEP2'';

V_STEP_NAME :=  ''create a table F_PREM_TRANS_DAY_SUBSET'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create  or replace table IDENTIFIER(:V_F_PREM_TRANS_DAY_SUBSET) as select
* from IDENTIFIER(:V_F_PREM_TRANS_DAY_SUBSET_A)
where PREM_DUE_DT_ID_floor between :V_START_DT_YM and :V_CURR_YM;



V_STEP := ''STEP3'';

V_STEP_NAME :=  ''create a table SHIP_PERSON_XREF_SUBSET'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_SHIP_PERSON_XREF_SUBSET) as select
person_id,SHIP_PERSON_ID from  IDENTIFIER(:V_SHIP_PERSON_XREF);



V_STEP := ''STEP4'';

V_STEP_NAME :=  ''create a table D_MBR_INFO_SUBSET'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_D_MBR_INFO_SUBSET) as select
pers_id,MEDCR_CLM_NBR as medcr_id,d_mbr_info_sk,INDV_ID,isid
from IDENTIFIER(:V_D_MBR_INFO);



V_STEP := ''STEP5'';

V_STEP_NAME :=  ''create a table MS_SALES_2018_2021_SUBSET'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_MS_SALES_2018_2021_SUBSET) as 
select  PREM_DUE_DT_ID_floor as prem_due_mo_id,
	prdct_eff_dt_id_floor as prdct_eff_mo_id,
	a13.LF_CATGY_NM,a13.PRDCT_SUB_GRP,a13.pln_lvl_desc,a13.pln_typ,pln_grp,smart_prdct_typ_var,a13.PLN_LVL,
	a12.CERT_ACTV_LVL_1_TXT,a12.CERT_ACTV_LVL_2_TXT,a12.CERT_ACTV_LVL_3_TXT,
	(case when floor(prem_due_age_id) <65 then ''<65'' 
	when floor(prem_due_age_id) =65 then ''65'' 
	when (floor(prem_due_age_id) >65 and floor(prem_due_age_id) <=69) then ''66-69'' 
	when (floor(prem_due_age_id) >69 and floor(prem_due_age_id) <=74) then ''70-74''
	when (floor(prem_due_age_id) >74 and floor(prem_due_age_id) <=79) then ''75-79''
	when floor(prem_due_age_id) >79  then ''80+''
	end) as age,
	a11.acct_nbr,a11.d_mbr_info_sk,a11.COMPAS_INSD_PLN_ID,       
	a11.PD_CERT_QTY , a11.DELQ_CERT_QTY,
	a11.PRDCT_D_ACQN_CHNL_SK,
	a11.RES_D_GEO_XREF_SK,
	a11.CERT_D_ACQN_CHNL_SK,
	a11.D_GDR_ID_SK,
	a11.agt_sel_orig_d_agt_sk,
	a11.agt_ref_orig_d_agt_sk
from IDENTIFIER(:V_F_PREM_TRANS_DAY_SUBSET) a11         
	left join IDENTIFIER(:V_D_CERT_ACTV) a12                                      
		on (a11.D_CERT_ACTV_SK = a12.D_CERT_ACTV_SK)                                              
	left  join IDENTIFIER(:V_D_PLN_BEN_MOD) a13                                      
		on (a11.D_PLN_BEN_MOD_SK = a13.D_PLN_BEN_MOD_SK)  
	where PRDCT_SUB_GRP in (''Med Supp Base'') and CERT_ACTV_LVL_1_TXT in (''NEW ENROLL ADD'');



V_STEP := ''STEP6'';

V_STEP_NAME :=  ''create a table MS_SALES_2018_2021'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_MS_SALES_2018_2021) as
select  prem_due_mo_id,
        prdct_eff_mo_id,
        a15.D_ST_CD,a15.zip_cd,a15.cnty_cd,a15.rgn,a15.cty,a15.area_cd,
        a1.LF_CATGY_NM,a1.PRDCT_SUB_GRP,a1.pln_lvl_desc,a1.pln_typ,pln_grp,smart_prdct_typ_var,a1.PLN_LVL,
        a14.ACQN_CHNL_LVL_1 as prdct_ACQN_CHNL_LVL_1,a17.ACQN_CHNL_LVL_1 as cert_ACQN_CHNL_LVL_1,
        a14.ACQN_CHNL_LVL_2 as prdct_ACQN_CHNL_LVL_2,a17.ACQN_CHNL_LVL_2 as cert_ACQN_CHNL_LVL_2,
        a1.CERT_ACTV_LVL_1_TXT,a1.CERT_ACTV_LVL_2_TXT,a1.CERT_ACTV_LVL_3_TXT,
        gdr_desc,a29.ealliance_pref_nm,
        age,
        (case when a31.person_id is null then a27.pers_id else a31.person_id end) as pers_id,
        a27.medcr_id as mbi_1,
        isid,indv_id,a28.cnty_nm,a29.pty_id,a29.pty_typ,a29.agt_id,a29.agt_typ,
        a1.acct_nbr,a1.d_mbr_info_sk,a1.COMPAS_INSD_PLN_ID,
        a52.pty_id as ref_pty_id,a52.pty_typ as ref_pty_typ,a52.agt_id as ref_agt_id,                   
        a52.agt_typ as ref_agt_typ,a52.agt_sub_typ as ref_agt_sub_typ,                                  
        a52.ealliance_pref_nm as ref_ealliance_pref_nm,
        sum(a1.PD_CERT_QTY + a1.DELQ_CERT_QTY) as mbr
from IDENTIFIER(:V_MS_SALES_2018_2021_SUBSET) a1
        left join IDENTIFIER(:V_D_ACQN_CHNL) a14
                on (a1.PRDCT_D_ACQN_CHNL_SK = a14.D_ACQN_CHNL_SK)                                       
        left join IDENTIFIER(:V_D_GEO_XREF) a15
                on (a1.RES_D_GEO_XREF_SK = a15.D_GEO_XREF_SK)                                           
        left join IDENTIFIER(:V_D_ST) a16
                on (a15.D_ST_CD = a16.D_ST_CD)
        left join IDENTIFIER(:V_D_ACQN_CHNL) a17
                on (a1.CERT_D_ACQN_CHNL_SK = a17.D_ACQN_CHNL_SK)
        left join IDENTIFIER(:V_D_GDR_LOOK) a21
                on (a1.D_GDR_ID_SK = a21.D_GDR_ID_SK)
        left join IDENTIFIER(:V_D_MBR_INFO_SUBSET) as a27
                on a1.d_mbr_info_sk = a27.d_mbr_info_sk
        left join IDENTIFIER(:V_D_CNTY) as a28
                on a15.D_ST_CD = a28.D_ST_CD and a15.cnty_cd = a28.cnty_cd
        left join IDENTIFIER(:V_D_AGT) as a29
                on a1.agt_sel_orig_d_agt_sk = a29.d_agt_sk
        left join IDENTIFIER(:V_SHIP_PERSON_XREF_SUBSET) a31
                on a27.INDV_ID = a31.SHIP_PERSON_ID
        left join IDENTIFIER(:V_D_AGT) as a52
                on a1.agt_ref_orig_d_agt_sk = a52.d_agt_sk
        group by
prem_due_mo_id,prdct_eff_mo_id,a15.D_ST_CD,a15.zip_cd,
a15.cnty_cd,a15.rgn,a15.cty,a15.area_cd,a1.LF_CATGY_NM,a1.PRDCT_SUB_GRP,a1.pln_lvl_desc,a1.pln_typ,pln_grp,smart_prdct_typ_var,a1.PLN_LVL,a14.ACQN_CHNL_LVL_1 ,a17.ACQN_CHNL_LVL_1 ,a14.ACQN_CHNL_LVL_2 ,
a17.ACQN_CHNL_LVL_2,a1.CERT_ACTV_LVL_1_TXT,a1.CERT_ACTV_LVL_2_TXT,a1.CERT_ACTV_LVL_3_TXT,
gdr_desc,a29.ealliance_pref_nm,
age,
(case when a31.person_id is null then a27.pers_id else a31.person_id end),
a27.medcr_id,
isid,indv_id,a28.cnty_nm,a29.pty_id,a29.pty_typ,a29.agt_id,a29.agt_typ,a1.acct_nbr,
a1.d_mbr_info_sk,a1.COMPAS_INSD_PLN_ID,
a52.pty_id,a52.pty_typ,a52.agt_id,a52.agt_typ,a52.agt_sub_typ,                                                        
a52.ealliance_pref_nm
having (mbr >0);


V_STEP := ''STEP7'';

V_STEP_NAME :=  ''create a table MS_MEMBERSHIP_MBI_CRSWLK'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_MS_MEMBERSHIP_MBI_CRSWLK)  as 
select a.*, b.mbi as mbi_2,
case when b.mbi is null then a.mbi_1 else b.mbi end as mbi  
from IDENTIFIER(:V_MS_SALES_2018_2021) a
left join IDENTIFIER(:V_CMS_HICN_TO_MBI_CROSSWALK) b
on a.mbi_1 = b.medicare_hicn_cd;



V_STEP := ''STEP8'';

V_STEP_NAME :=  ''create a table MS_SALES_2018_2021_V2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_MS_SALES_2018_2021_V2) as
select *, cast(concat(substr(prem_due_mo_id,1,4), ''-'', substr(prem_due_mo_id,5,2), ''-'',1 ) as date) as eff_dt
from IDENTIFIER(:V_MS_MEMBERSHIP_MBI_CRSWLK);


V_STEP := ''STEP9'';

V_STEP_NAME :=  ''create a table MS_SALES_2018_2021_V3'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_MS_SALES_2018_2021_V3) as 
select distinct a.prem_due_mo_id,
        a.prdct_eff_mo_id,
        a.d_st_cd,
        a.zip_cd,
        a.cnty_cd,
        a.rgn,
        a.cty,
        a.area_cd,
        a.lf_catgy_nm,
        a.prdct_sub_grp,
        a.pln_lvl_desc,
        a.pln_typ,
        a.pln_grp,
        a.smart_prdct_typ_var,
        a.pln_lvl,
        a.prdct_acqn_chnl_lvl_1,
        a.cert_acqn_chnl_lvl_1,
        a.prdct_acqn_chnl_lvl_2,
        a.cert_acqn_chnl_lvl_2,
        a.cert_actv_lvl_1_txt,
        a.cert_actv_lvl_2_txt,
        a.cert_actv_lvl_3_txt,
        a.gdr_desc,
        a.ealliance_pref_nm,
        a.age,
        a.pers_id,
		a.mbi,
        a.isid,
        a.indv_id,
        a.cnty_nm,
        a.pty_id,
        a.pty_typ,
        a.agt_id,
        a.agt_typ,
        a.acct_nbr,
        a.d_mbr_info_sk,
        a.compas_insd_pln_id,
        a.ref_pty_id,
        a.ref_pty_typ,
        a.ref_agt_id,
        a.ref_agt_typ,
        a.ref_agt_sub_typ,
        a.ref_ealliance_pref_nm,
        a.mbr,
        a.eff_dt,
        b.appl_receipt_date,
        b.effective_date,b.adjudication_date,b.adjudication_status,
        enrollment_actor,enrollment_channel,enrollment_mechanism,plan_code
        ,enrollment,mktg_chnl_grp,
        b.response_id as rptg_response_id,
        b.source_code as rptg_source_code,
        b.RELATED_RESPONSE_ID as rptg_RELATED_RESPONSE_ID,
        b.rptg_adv_channel,
        b.application_id,
        b.enrollment_process,
        b.enrollment_call_center_source
from IDENTIFIER(:V_MS_SALES_2018_2021_V2) as a 
left join IDENTIFIER(:V_APPS_RPTG_DAILY) as b 
on a.COMPAS_INSD_PLN_ID = b.source_insured_plan_id;


V_STEP := ''STEP10'';

V_STEP_NAME :=  ''create a table MS_SALES_2018_2021_V4'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_MS_SALES_2018_2021_V4) as 
select * from 
        (
        select *, row_number() over (partition by  pers_id, eff_dt  order by  pers_id, eff_dt desc, appl_receipt_date desc NULLS LAST) as rn
        from IDENTIFIER(:V_MS_SALES_2018_2021_V3) a
        ) a
where rn=1;




V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_MS_SALES_2018_2021_V4)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



V_STEP := ''STEP11'';

V_STEP_NAME :=  ''create a table ACTV_MBR3'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_ACTV_MBR3) as 
select a.*,
        b.response_id as app_response_id,
        b.PROMOTION_CODE as app_PROMOTION_CODE,
        b.RELATED_SOURCE_CODE as app_RELATED_SOURCE_CODE,
        b.RELATED_RESPONSE_ID as app_RELATED_RESPONSE_ID,
        b.RELATED_RESPONSE_SOURCE_ID as app_RELATED_RESPONSE_SOURCE_ID
from IDENTIFIER(:V_MS_SALES_2018_2021_V4) as a 
left join IDENTIFIER(:V_APPLICATION) as b 
on a.APPLICATION_ID = b.APPLICATION_ID 
and a.pers_id = b.person_id;



V_STEP := ''STEP12'';

V_STEP_NAME :=  ''create a table ACTV_MBR4'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_ACTV_MBR4) as 
select *,
        (case when enrollment_process in (''CUSTOMER MAILED APPLICATION'',''CUSTOMER BEGAN WEB ENROLL - MAILED APP'') then ''Cust Mailed''
                when enrollment_process in (''TSR: APP ASSIST PHONE ENROLLMENT'', ''TSR:APP ASSIST DIGITAL ENROLLMENT'') then ''App Assist''
                when enrollment_process in (''TSR: VOICE SIGNATURE PHONE ENROLLMENT'') then ''Voice Sign''
                when enrollment_process in (''CUSTOMER WEB ENROLLMENT'') then ''Cust OLE''
                when enrollment_process in (''TSR: PLAN CHANGE PHONE'',''OPERATIONS - PLAN CHANGE GENERATED VIA UI'',''AGENT FIELDS: PLAN CHANGE'') then ''Plan Change''
                when enrollment_process in (''AGENT ELECTRONIC WEB ENROLLMENT'') then ''Aggr Web''
                when enrollment_process in (''APP ASSIST - AGENT COVERAGE'') then ''Agent App Assist''
                when enrollment_process in (''AGENT: MAILED APP'') then ''Agent Mailed''
                when enrollment_process in (''AGENT: WEB ENROLLMENT'')  then ''Agent OLE''
                when enrollment_process in (''OPERATIONS - UNKNOWN CHANNEL - GENERATED VIA UI'',''AGENT: CHANNEL UNK -  UI'') then ''Other''
                when enrollment_process in (''INVALID'') then ''Other''
        else ''CHECK'' end) as enrollment_type,
        case when rptg_adv_channel in (''Green Bay Portfolio Call Center'',''United Call Center Transfers'') then rptg_adv_channel else ''Others'' end as adv_channel
from IDENTIFIER(:V_ACTV_MBR3);



V_STEP := ''STEP13'';

V_STEP_NAME :=  ''create a table ACTV_MBR4_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_ACTV_MBR4_1) as 
select  *,
        (case when ref_ealliance_pref_nm is not null and ref_ealliance_pref_nm <> ''NotApplicable'' then ''Y'' else ''N'' end) as self_enroll_flag,
        (case when (ref_ealliance_pref_nm is not null and ref_ealliance_pref_nm <> ''NotApplicable'') and pty_id in (''-1'',''-2'') then ref_pty_id else pty_id end) as pty_id_final,
        (case when (ref_ealliance_pref_nm is not null and ref_ealliance_pref_nm <> ''NotApplicable'') and agt_id in (''-1'',''-2'') then ref_agt_id else agt_id end) as agt_id_final,
        (case when (ref_ealliance_pref_nm is not null and ref_ealliance_pref_nm <> ''NotApplicable'') and (ealliance_pref_nm is not null and ealliance_pref_nm = ''NotApplicable'') then ref_ealliance_pref_nm else ealliance_pref_nm end) as ref_ealliance_pref_nm_final
from IDENTIFIER(:V_ACTV_MBR4);


V_STEP := ''STEP14'';


V_STEP_NAME :=  ''create a table ACTV_MBR4_2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_ACTV_MBR4_2) as 
select a.*, 
        (case when b.e_alliance_old_category in (''eAlliance - Retail'') then ''ealliance-Retail''
        else b.e_alliance_old_category end) as e_alliance_old_category
from IDENTIFIER(:V_ACTV_MBR4_1) a
left join IDENTIFIER(:V_EALLIANCE) b 
on a.pty_id_final = b.pty_id and a.agt_id_final = b.agt_id;


V_STEP := ''STEP15'';

V_STEP_NAME :=  ''create a table ACTV_MBR4_3'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_ACTV_MBR4_3) as 
select *,
        (case when agt_id_final in (''SQS3333'',''SQS4444'') then ''DTC''
        when agt_id_final in (''SQS2222'',''GOH2222'',''INS2222'',''EHC2222'',''SQA2222'') then ''DTC''
        when prdct_ACQN_CHNL_LVL_1 =''UNKNOWN'' then ''DTC'' 
        when ref_ealliance_pref_nm is not null and ref_ealliance_pref_nm <> ''NotApplicable'' then ''ealliance-Self-Enroll''
        when e_alliance_old_category <> '''' then e_alliance_old_category
        when prdct_ACQN_CHNL_LVL_1 =''Aggregator'' and coalesce(e_alliance_old_category, '''') = ''''  then ''ealliance-Others'' 						
        else prdct_ACQN_CHNL_LVL_1 end) as marketing_channel_final
from IDENTIFIER(:V_ACTV_MBR4_2);



V_STEP := ''STEP16'';

V_STEP_NAME :=  ''create a table MS_SALES_2018_2021_V5'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_MS_SALES_2018_2021_V5) as 
select *, 
        (case when agt_id in (''SQS3333'',''SQS4444'') then ''SQS_VS'' 
                when agt_id in (''SQS2222'',''GOH2222'',''INS2222'',''EHC2222'',''SQA2222'') then ''MA-Leads_Captives''
                when Enrollment = ''Application Assistance'' and ENROLLMENT_CALL_CENTER_SOURCE = ''CSS'' then ''Optum AS''
                when Enrollment = ''Application Assistance'' and ENROLLMENT_CALL_CENTER_SOURCE = ''UCC'' then ''UCC_AS''
                when Enrollment = ''Voice Signature'' and ENROLLMENT_CALL_CENTER_SOURCE = ''CSS'' then ''Optum VS''
                when Enrollment = ''Voice Signature'' and ENROLLMENT_CALL_CENTER_SOURCE = ''UCC'' then ''UCC_VS''
                when marketing_channel_final = ''Agent'' and enrollment_type in (''Agent Mailed'', ''Agent OLE'') then enrollment_type
                when marketing_channel_final = ''DTC'' and enrollment = (''Customer Mailed App'') then ''Cust Mailed''
                when marketing_channel_final = ''DTC'' and enrollment = (''Customer OLE'') then ''Cust OLE''
                when marketing_channel_final = ''ealliance-Classic'' and  enrollment = (''Agent Aggr'') then ''Aggr Web''
                when marketing_channel_final = ''ealliance-Retail'' and enrollment = (''Agent Aggr'') then ''Aggr Web''
                when marketing_channel_final = ''ealliance-Others'' then ''Others''
                when marketing_channel_final = ''Employer'' and enrollment = (''Customer Mailed App'') then ''Cust Mailed''
                when marketing_channel_final = ''Employer'' and enrollment = (''Customer OLE'') then ''Cust OLE''
        else ''Others'' end) as sub_channel
from IDENTIFIER(:V_ACTV_MBR4_3);




V_STEP := ''STEP17'';

V_STEP_NAME :=  ''create a table MS_SALES_2018_2021_V6'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_MS_SALES_2018_2021_V6) as 
select *, 
        (case when agt_id_final in (''SQS3333'',''SQS4444'') then ''DTC''
        when agt_id_final in (''SQS2222'',''GOH2222'',''INS2222'',''EHC2222'') then ''DTC''
        when prdct_ACQN_CHNL_LVL_1 =''UNKNOWN'' then ''DTC''
        when e_alliance_old_category <> '''' then e_alliance_old_category
        when prdct_ACQN_CHNL_LVL_1 =''Aggregator'' and coalesce(e_alliance_old_category, '''') = '''' then ''ealliance-Others'' 							
        else prdct_ACQN_CHNL_LVL_1 end) as marketing_channel_cat_3
from IDENTIFIER(:V_MS_SALES_2018_2021_V5);



V_STEP := ''STEP18'';

V_STEP_NAME :=  ''create a table MS_SALES_2018_2021_V10'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_MS_SALES_2018_2021_V10) as 
Select a.*,  b.fips_state_code, c.*  from IDENTIFIER(:V_MS_SALES_2018_2021_V6) a 
left join IDENTIFIER(:V_STATE) b 
        on a.d_st_cd = b.state_code
left join IDENTIFIER(:V_BUSINESS_SALES_MARKET_MAPPING) c 
        on coalesce(b.fips_state_code, ''null'') = coalesce(substr(c.fips,1,2), ''null'') and 
        a.cnty_cd = substr(c.fips,3,3) and 
        --a.zip_cd = cast(c.zipcode as varchar)  ;
cast(LTRIM(a.zip_cd,''0'') as varchar) = cast(LTRIM(c.zipcode,''0'') as varchar);

V_STEP := ''STEP19'';

V_STEP_NAME :=  ''create a table PDP_SALES_2018_2021'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_PDP_SALES_2018_2021) as
select * from IDENTIFIER(:V_ALL_APPS_FEDERAL)
where product_segments in (''PDP'') 
and ADJUDICATION_STAT_CD=1 and STATUS in (''NEW'',''WINBACK'') and app_channel <> ''CMS-AUTO''
and (cast(PLAN_EFF_DT as date) between :V_START_DT_YMD  and :V_CURR_YMD); --replaced prev_ymd with curr_ymd


V_STEP := ''STEP20'';


V_STEP_NAME :=  ''create a table PDP_SALES_2018_2021_V2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_PDP_SALES_2018_2021_V2) as 
select * from 
        (
        select *, 
        row_number() over (partition by indvdl_id,PLAN_EFF_DT order by APPL_DT desc NULLS LAST, ADJUDICATION_DT desc NULLS LAST, APPL_ID_CD desc NULLS LAST) as rn
        from IDENTIFIER(:V_PDP_SALES_2018_2021) a
        ) a
where rn=1;




V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_PDP_SALES_2018_2021_V2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



V_STEP := ''STEP21'';

V_STEP_NAME :=  ''create a table PDP_SALES_MBI_CRSWLK'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_PDP_SALES_MBI_CRSWLK) as
select a.*, a.medicare_hicn_cd as mbi_1, b.mbi as mbi_2,
case when b.mbi is null then a.medicare_hicn_cd else b.mbi end as mbi  
from IDENTIFIER(:V_PDP_SALES_2018_2021_V2) a
left join IDENTIFIER(:V_CMS_HICN_TO_MBI_CROSSWALK) b
on a.medicare_hicn_cd = b.medicare_hicn_cd;



V_STEP := ''STEP22'';

V_STEP_NAME :=  ''create a table PDP_SALES_2018_2021_V3'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_PDP_SALES_2018_2021_V3) as
select person_id,
       p.*
from IDENTIFIER(:V_PDP_SALES_MBI_CRSWLK) as p
left join IDENTIFIER(:V_CMDB_PERSON_XREF_INTERFACE) c
on p.indvdl_id = c.cmdb_person_id;


V_STEP := ''STEP23'';

V_STEP_NAME :=  ''create a table PDP_SALES_2018_2021_V4'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_PDP_SALES_2018_2021_V4) as 
select *, case when mbi is not null and r_id=1 then mbi else null end as mbi_match from 
        (
        select *, 
        row_number() over (partition by mbi,PLAN_EFF_DT order by indvdl_id NULLS LAST) as r_id
        from IDENTIFIER(:V_PDP_SALES_2018_2021_V3) a
        ) a;



V_STEP := ''STEP24'';

V_STEP_NAME :=  ''create a table PDP_SALES_2018_2021_V5'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_PDP_SALES_2018_2021_V5) as 
select a.*, b.plan_desc from IDENTIFIER(:V_PDP_SALES_2018_2021_V4) a 
left join IDENTIFIER(:V_PLAN) b on 
a.gps_plan_cd = b.plan_cd and 
a.SRC_SYS_SRCID = b.SRC_SYS_SRCID;


V_STEP := ''STEP25'';

V_STEP_NAME :=  ''create a table PDP_SALES_2018_2021_V6'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_PDP_SALES_2018_2021_V6) as 
select a.person_id,
        a.bus,
        cast(a.appl_dt as date) as appl_dt,
        cast(a.plan_eff_dt as date) as plan_eff_dt,
        cast(a.adjudication_dt as date) as adjudication_dt,
        a.indvdl_id,
        a.plan_lob_id,
        a.gps_plan_cd,
        a.appl_id_cd,
        a.attr_rule_set_cd,
        a.chnl_id,
        a.broker_id_cd,
        a.prod_id,
        a.contract_id_cd,
        a.credited_psc_trtmnt_cd,
        a.zip_cd as zip_cd1,
        a.hh_id,
        a.medicare_hicn_cd,
		a.mbi as pdp_mbi,
		a.mbi_match,
        a.adjudication_stat_cd,
        a.adjudication_stat_desc,
        a.src_sys_srcid,
        a.appl_src_cd,
        a.gps_appl_src_cd,
        a.appl_src_desc,
        a.application_source_desc,
        a.lob,
        a.prod_cd,
        a.chnl_desc,
        a.stfips,
        coalesce(substr(a.stfips,1,2), null) as st_cd,
        coalesce(substr(a.stfips,3,3), null) as cty_cd,
        a.sar_segment,
        a.sar_contract,
        a.sar,
        a.sar_plan_name,
        a.sar_plan_type,
        a.product,
        a.app_channel,
        a.week_end_dt,
        a.attr_cd,
        a.online_app,
        a.plan_change,
        a.dup,
        a.product_segments,
        a.status,
        a.gps_salesinitiative,
        a.plan_cd,
        a.plan_desc,
        b.psc,
        b.value_prop_name,
        b.value_prop_desc,
        b.psc_mkt,
        b.psc_lob,
        b.psc_prod,
        b.medium,
        b.sub_medium,
        b.classification,
        b.initiative,
        b.creative,
        b.audience,
        b.sub_audience,
        b.requestor_nm,
        b.intended_live_date,
        b.psc_month,
        b.tfn,
        b.tfn_eff_dt,
        b.project_cd,
        b.sales_campaign,
        b.objective,
        b.productoffer,
        b.enrollmentoption,
        b.period,
        b.leadsource,
        b.campaign,
        b.channel,
        b.mktgmedium,
        b.version,
        b.geography,
        b.language,
        b.pricing,
        b.brand,
        b.calltoaction,
        b.type,
        b.requester,
        b.budgetmonth,
        b.enddate,
        b.status as psc_status,
        b.site,
        b.issourcecode,
        b.istfn,
        b.reporting,
        b.callexperience,
        b.costperpiece,
        b.bilingual_flag,
        b.responseid,
        b.depot_project_cd,
        b.project_id,
        b.project_nm,
        b.template_nm,
        b.project_rqst_fg,
        b.root_project_id,
        b.parent_project_cd,
        b.parent_project_id,
        b.parent_project_nm,
        b.program_cd,
        b.program_nm,
        b.plan_cd as psc_plan_cd,
        b.plan_nm,
        b.in_home_dt,
        b.project_budget_amt,
        b.circulation_qty,
        b.call_qty,
        b.brc_qty,
        b.lead_qty,
        b.appl_ma_qty,
        b.appl_pdp_qty,
        b.appl_mr_snp_qty,
        b.tgt_universe_qty,
        b.ins_pqid,
        b.ins_rid,
        b.ins_srcid,
        b.ins_tstmp,
        b.pscprojectcode,
        b.pscname,
        b.inhomedate

from IDENTIFIER(:V_PDP_SALES_2018_2021_V5) a 
left join IDENTIFIER(:V_NEW_CATEGORIZATION_PSC_ALL) b on 
a.CREDITED_PSC_TRTMNT_CD = b.PSC;



V_STEP := ''STEP26'';

V_STEP_NAME :=  ''create a table PDP_SALES_2018_2021_V10'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_PDP_SALES_2018_2021_V10) as 
Select a.*, 
        c.region as pdp_region,
        c.sub_region as pdp_sub_region,
        c.sales_market as pdp_sales_market,
        c.business_market as pdp_business_market,
        c.scc as pdp_scc
from IDENTIFIER(:V_PDP_SALES_2018_2021_V6) a 
left join IDENTIFIER(:V_STATE) b 
        on coalesce(a.st_cd, ''null'') = coalesce(b.state_code, ''null'')
left join IDENTIFIER(:V_BUSINESS_SALES_MARKET_MAPPING) c 
        on coalesce(b.fips_state_code, ''null'') = coalesce(substr(c.fips,1,2), ''null'') and 
        a.cty_cd = substr(c.fips,3,3) and 
        cast(a.zip_cd1 as bigint) = c.zipcode  ;


V_STEP := ''STEP27'';

V_STEP_NAME :=  ''create a table COMBO_SALES_FROM_MS_SALES'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_COMBO_SALES_FROM_MS_SALES) as 
select a.*,(case when b.mbi_match is not null then 1 else 0 end) as combo_fg from IDENTIFIER(:V_MS_SALES_2018_2021_V10) as a 
left join (select * from IDENTIFIER(:V_PDP_SALES_2018_2021_V10) where mbi_match is not null and mbi_match<>'''') as b 
on a.mbi = b.mbi_match
and 
        (
        to_date(PLAN_EFF_DT) = to_date(eff_dt) 
        or 
        (
        (to_date(APPL_DT) = to_date(appl_receipt_date)) 
        and 
                (
                datediff(''day'',to_date(PLAN_EFF_DT), to_date(eff_dt)) >= -62 
                and 
                datediff(''day'',to_date(PLAN_EFF_DT),to_date(eff_dt)) <=62
                and 
                to_date(PLAN_EFF_DT) <> to_date(eff_dt) 
                ) 
        )
        );



V_STEP := ''STEP28'';

V_STEP_NAME :=  ''create a table COMBO_SALES_FROM_PDP_SALES'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_COMBO_SALES_FROM_PDP_SALES) as 
select a.*,(case when b.mbi is not null then 1 else 0 end) as combo_fg from IDENTIFIER(:V_PDP_SALES_2018_2021_V10) as a 
left join (select * from IDENTIFIER(:V_MS_SALES_2018_2021_V10) where mbi is not null and mbi<>'''') as b 
on a.mbi_match = b.mbi
and 
        (
        to_date(PLAN_EFF_DT) = to_date(eff_dt) 
        or 
        (
        (to_date(APPL_DT) = to_date(appl_receipt_date)) 
        and 
                (
                datediff(''day'',to_date(PLAN_EFF_DT), to_date(eff_dt)) >= -62 
                and 
                datediff(''day'',to_date(PLAN_EFF_DT),to_date(eff_dt)) <=62
                and 
                to_date(PLAN_EFF_DT) <> to_date(eff_dt) 
                ) 
        )
        );



V_STEP := ''STEP29'';

V_STEP_NAME :=  ''create a table MS_PDP_COMBO_SALES'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_MS_PDP_COMBO_SALES) as 
select a.*,b.* from IDENTIFIER(:V_MS_SALES_2018_2021_V10) as a 
inner join (select * from IDENTIFIER(:V_PDP_SALES_2018_2021_V10) where mbi_match is not null and mbi_match<>'''') as b 
on a.mbi = b.mbi_match

-- Need to enable the code
   and 
     (
       to_date(PLAN_EFF_DT) = to_date(eff_dt) 
     or 
      (
     (to_date(APPL_DT) = to_date(appl_receipt_date)) 
      and 
              (
             datediff(''day'',to_date(PLAN_EFF_DT), to_date(eff_dt)) >= -62 
              and 
              datediff(''day'',to_date(PLAN_EFF_DT),to_date(eff_dt)) <=62
               and 
              to_date(PLAN_EFF_DT) <> to_date(eff_dt) 
                ) 
     )
       );




V_STEP := ''STEP30'';

V_STEP_NAME :=  ''create a table MS_PDP_COMBO_SALES_V3'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_MS_PDP_COMBO_SALES_V3) as
select *,
        case when (to_date(APPL_DT) = to_date(appl_receipt_date)) then ''Same App Date''
        when (datediff(''day'',to_date(APPL_DT), to_date(appl_receipt_date)) >= -62 and datediff(''day'',to_date(APPL_DT), to_date(appl_receipt_date)) <=62) then ''Within 60''
        end as app_diff_fg,
        case when (to_date(PLAN_EFF_DT) = to_date(eff_dt)) then ''Same Eff Date''
        when (datediff(''day'',to_date(PLAN_EFF_DT), to_date(eff_dt)) >= -62 and datediff(''day'',to_date(PLAN_EFF_DT),to_date(eff_dt)) <=62) then ''Within 60''
        end as eff_diff_fg,
        datediff(''day'',to_date(APPL_DT), to_date(appl_receipt_date)) as app_diff,
        datediff(''day'',to_date(PLAN_EFF_DT), to_date(eff_dt)) as eff_diff,
        case when APP_CHANNEL in (''FMO'', ''ICA'',''ISR'') then 1 else 0 end as PDP_Agent_Sale,
        case when  prdct_ACQN_CHNL_LVL_1 =''Agent'' then 1 else 0 end as MS_Agent_Sale,
        month(appl_receipt_date) as ms_app_month, 
        year(appl_receipt_date) as ms_app_year,
        month(eff_dt) as ms_eff_month,
        year(eff_dt) as ms_eff_year
from IDENTIFIER(:V_MS_PDP_COMBO_SALES);




V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_MS_PDP_COMBO_SALES_V3)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



V_STEP := ''STEP31'';

V_STEP_NAME :=  ''create a table MS_PDP_COMBO_SALES_V4'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_MS_PDP_COMBO_SALES_V4) as 
select *,
        case when eff_diff_fg = ''Same Eff Date'' then ''Same Eff Date''
        when app_diff_fg = ''Same App Date''  and eff_diff_fg = ''Within 60'' then ''Same_App_Eff_within_60d'' end as Combo_Category,
        case when AGT_ID=BROKER_ID_CD and PDP_Agent_Sale=1 and MS_Agent_Sale=1 then 1 else 0 end as Same_agent_sale
from IDENTIFIER(:V_MS_PDP_COMBO_SALES_V3);



V_STEP := ''STEP32'';

V_STEP_NAME :=  ''create a table MS_PDP_COMBO_SALES_V5'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_MS_PDP_COMBO_SALES_V5) as 
select * from IDENTIFIER(:V_MS_PDP_COMBO_SALES_V4)
where year(eff_dt)>=2018 and year(plan_eff_dt)>=2018 and eff_dt<=:V_PREV_YMD and plan_eff_dt<=:V_PREV_YMD;


V_STEP := ''STEP33'';

V_STEP_NAME :=  ''create a table MSPDP_COMBO_SALES_TRIMMED'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace  table IDENTIFIER(:V_MSPDP_COMBO_SALES_TRIMMED) as 
select distinct pers_id, 
        prem_due_mo_id, 
        prdct_eff_mo_id, 
        eff_dt, 
        pty_id_final,
        agt_id_final,
        broker_id_cd,
	mbi,
	plan_desc
from IDENTIFIER(:V_MS_PDP_COMBO_SALES_V4);   



V_STEP := ''STEP34'';

V_STEP_NAME :=  ''create a table MS_SUMMARY'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_MS_SUMMARY) as 
select 
        AREA_CD,
        CNTY_CD,
        CNTY_NM,
        CTY,
        D_ST_CD,
        EALLIANCE_PREF_NM,
        ENROLLMENT_ACTOR,
        ENROLLMENT_CHANNEL,
        ENROLLMENT_MECHANISM,
        ENROLLMENT_PROCESS,
        Enrollment,
        GDR_DESC,
        PLN_LVL,
        PRDCT_SUB_GRP,
        PTY_ID,
        PTY_TYP,
        RGN,
        Rptg_Adv_Channel,
        SMART_PRDCT_TYP_VAR,
        ZIP_CD,
        adv_channel,
        age,
        eff_dt,
        enrollment_type,
        marketing_channel_final,
        prdct_ACQN_CHNL_LVL_1,
        prdct_ACQN_CHNL_LVL_2,
        prdct_eff_mo_id,
        prem_due_mo_id,
        sub_channel,
        marketing_channel_cat_3,
        region,
        sub_region,
        sales_market,
        business_market,
        
        count(pers_id) as n_sales
from IDENTIFIER(:V_MS_SALES_2018_2021_V10) where year(eff_dt)>=2018 and eff_dt<=:V_PREV_YMD
group by 
        AREA_CD,
        CNTY_CD,
        CNTY_NM,
        CTY,
        D_ST_CD,
        EALLIANCE_PREF_NM,
        ENROLLMENT_ACTOR,
        ENROLLMENT_CHANNEL,
        ENROLLMENT_MECHANISM,
        ENROLLMENT_PROCESS,
        Enrollment,
        GDR_DESC,
        PLN_LVL,
        PRDCT_SUB_GRP,
        PTY_ID,
        PTY_TYP,
        RGN,
        Rptg_Adv_Channel,
        SMART_PRDCT_TYP_VAR,
        ZIP_CD,
        adv_channel,
        age,
        eff_dt,
        enrollment_type,
        marketing_channel_final,
        prdct_ACQN_CHNL_LVL_1,
        prdct_ACQN_CHNL_LVL_2,
        prdct_eff_mo_id,
        prem_due_mo_id,
        sub_channel,
        marketing_channel_cat_3,
        region,
        sub_region,
        sales_market,
        business_market;



V_STEP := ''STEP35'';

V_STEP_NAME :=  ''create a table MS_PDP_COMBO_SUMMARY_MS_LVL'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_MS_PDP_COMBO_SUMMARY_MS_LVL) as 
select AREA_CD,
        CNTY_CD,
        CNTY_NM,
        CTY,
        D_ST_CD,
        EALLIANCE_PREF_NM,
        ENROLLMENT_ACTOR,
        ENROLLMENT_CHANNEL,
        ENROLLMENT_MECHANISM,
        ENROLLMENT_PROCESS,
        Enrollment,
        GDR_DESC,
        PLN_LVL,
        PRDCT_SUB_GRP,
        PTY_ID,
        PTY_TYP,
        RGN,
        Rptg_Adv_Channel,
        SMART_PRDCT_TYP_VAR,
        ZIP_CD,
        adv_channel,
        age,
        eff_dt,
        enrollment_type,
        marketing_channel_final,
        prdct_ACQN_CHNL_LVL_1,
        prdct_ACQN_CHNL_LVL_2,
        prdct_eff_mo_id,
        prem_due_mo_id,
        sub_channel,
        marketing_channel_cat_3,
        region,
        sub_region,
        sales_market,
        business_market,
        
        count(pers_id) as n_sales,
        count(case when plan_desc = ''AARP MEDICARERX PREFERRED (PDP)'' then pers_id end) as n_sales_Preferred,
        count(case when plan_desc = ''AARP MEDICARERX SAVER PLUS (PDP)'' then pers_id end) as n_sales_Saver_Plus,
        count(case when plan_desc = ''AARP MEDICARERX WALGREENS (PDP)'' then pers_id end) as n_sales_Walgreens,
        count(case when plan_desc = ''SYMPHONIX VALUE RX (PDP)'' then pers_id end) as n_sales_Symphonics,
        count(case when plan_desc = ''AARP MEDICARE RX BASIC FROM UHC (PDP)'' then pers_id end) as n_sales_basic,
        
        count(case when plan_desc = ''AARP MEDICARERX PREFERRED (PDP)'' and Combo_Category= ''Same_App_Eff_within_60d'' then pers_id end) as n_sales_Preferred_Same_App_Eff,
        count(case when plan_desc = ''AARP MEDICARERX SAVER PLUS (PDP)'' and Combo_Category= ''Same_App_Eff_within_60d'' then pers_id end) as n_sales_Saver_Plus_Same_App_Eff,
        count(case when plan_desc = ''AARP MEDICARERX WALGREENS (PDP)'' and Combo_Category= ''Same_App_Eff_within_60d'' then pers_id end) as n_sales_Walgreens_Same_App_Eff,
        count(case when plan_desc = ''SYMPHONIX VALUE RX (PDP)'' and Combo_Category= ''Same_App_Eff_within_60d'' then pers_id end) as n_sales_Symphonics_Same_App_Eff,
        count(case when plan_desc = ''AARP MEDICARE RX BASIC FROM UHC (PDP)'' and Combo_Category= ''Same_App_Eff_within_60d'' then pers_id end) as n_sales_basic_Same_App_Eff,

        count(case when plan_desc = ''AARP MEDICARERX PREFERRED (PDP)'' and Combo_Category= ''Same Eff Date'' then pers_id end) as n_sales_Preferred_same_eff_dt,
        count(case when plan_desc = ''AARP MEDICARERX SAVER PLUS (PDP)'' and Combo_Category= ''Same Eff Date'' then pers_id end) as n_sales_Saver_Plus_same_eff_dt,
        count(case when plan_desc = ''AARP MEDICARERX WALGREENS (PDP)'' and Combo_Category= ''Same Eff Date'' then pers_id end) as n_sales_Walgreens_same_eff_dt,
        count(case when plan_desc = ''SYMPHONIX VALUE RX (PDP)'' and Combo_Category= ''Same Eff Date'' then pers_id end) as n_sales_Symphonics_same_eff_dt,
        count(case when plan_desc = ''AARP MEDICARE RX BASIC FROM UHC (PDP)'' and Combo_Category= ''Same Eff Date'' then pers_id end) as n_sales_basic_same_eff_dt

from IDENTIFIER(:V_MS_PDP_COMBO_SALES_V5)
group by AREA_CD,
        CNTY_CD,
        CNTY_NM,
        CTY,
        D_ST_CD,
        EALLIANCE_PREF_NM,
        ENROLLMENT_ACTOR,
        ENROLLMENT_CHANNEL,
        ENROLLMENT_MECHANISM,
        ENROLLMENT_PROCESS,
        Enrollment,
        GDR_DESC,
        PLN_LVL,
        PRDCT_SUB_GRP,
        PTY_ID,
        PTY_TYP,
        RGN,
        Rptg_Adv_Channel,
        SMART_PRDCT_TYP_VAR,
        ZIP_CD,
        adv_channel,
        age,
        eff_dt,
        enrollment_type,
        marketing_channel_final,
        prdct_ACQN_CHNL_LVL_1,
        prdct_ACQN_CHNL_LVL_2,
        prdct_eff_mo_id,
        prem_due_mo_id,
        sub_channel,
        marketing_channel_cat_3,
        region,
        sub_region,
        sales_market,
        business_market;




V_STEP := ''STEP36'';

V_STEP_NAME :=  ''create a table MS_SUMMARY_INTMD'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_MS_SUMMARY_INTMD) as 
select a.*, a.n_sales as MS_Sales, coalesce(b.n_sales,0) as MS_PDP_Combo_Sales, 
        coalesce(b.n_sales_Preferred,0) as n_sales_Preferred, 
        coalesce(b.n_sales_Saver_Plus,0) as n_sales_Saver_Plus, 
        coalesce(b.n_sales_Walgreens,0) as n_sales_Walgreens, 
        coalesce(b.n_sales_Symphonics,0) as n_sales_Symphonics,
        coalesce(b.n_sales_basic,0) as n_sales_basic,
        
        coalesce(b.n_sales_Preferred_Same_App_Eff,0) as n_sales_Preferred_Same_App_Eff,
        coalesce(b.n_sales_Saver_Plus_Same_App_Eff,0) as n_sales_Saver_Plus_Same_App_Eff,
        coalesce(b.n_sales_Walgreens_Same_App_Eff,0) as n_sales_Walgreens_Same_App_Eff,
        coalesce(b.n_sales_Symphonics_Same_App_Eff,0) as n_sales_Symphonics_Same_App_Eff,
        coalesce(b.n_sales_basic_Same_App_Eff,0) as n_sales_basic_Same_App_Eff,
        
        coalesce(b.n_sales_Preferred_same_eff_dt,0) as n_sales_Preferred_same_eff_dt,
        coalesce(b.n_sales_Saver_Plus_same_eff_dt,0) as n_sales_Saver_Plus_same_eff_dt,
        coalesce(b.n_sales_Walgreens_same_eff_dt,0) as n_sales_Walgreens_same_eff_dt,
        coalesce(b.n_sales_Symphonics_same_eff_dt,0) as n_sales_Symphonics_same_eff_dt,
        coalesce(b.n_sales_basic_same_eff_dt,0) as n_sales_basic_same_eff_dt

from IDENTIFIER(:V_MS_SUMMARY) a 
left join IDENTIFIER(:V_MS_PDP_COMBO_SUMMARY_MS_LVL) b on 
        coalesce(a.AREA_CD, ''null'') = coalesce(b.AREA_CD, ''null'') and
        coalesce(a.CNTY_CD, ''null'') = coalesce(b.CNTY_CD, ''null'') and
        coalesce(a.CNTY_NM, ''null'') = coalesce(b.CNTY_NM, ''null'') and
        coalesce(a.CTY, ''null'') = coalesce(b.CTY, ''null'') and
        coalesce(a.D_ST_CD, ''null'') = coalesce(b.D_ST_CD, ''null'') and
        coalesce(a.EALLIANCE_PREF_NM, ''null'') = coalesce(b.EALLIANCE_PREF_NM, ''null'') and
        coalesce(a.ENROLLMENT_ACTOR, ''null'') = coalesce(b.ENROLLMENT_ACTOR, ''null'') and
        coalesce(a.ENROLLMENT_CHANNEL, ''null'') = coalesce(b.ENROLLMENT_CHANNEL, ''null'') and
        coalesce(a.ENROLLMENT_MECHANISM, ''null'') = coalesce(b.ENROLLMENT_MECHANISM, ''null'') and
        coalesce(a.ENROLLMENT_PROCESS, ''null'') = coalesce(b.ENROLLMENT_PROCESS, ''null'') and
        coalesce(a.Enrollment, ''null'') = coalesce(b.Enrollment, ''null'') and
        coalesce(a.GDR_DESC, ''null'') = coalesce(b.GDR_DESC, ''null'') and
        coalesce(a.PLN_LVL, ''null'') = coalesce(b.PLN_LVL, ''null'') and
        coalesce(a.PRDCT_SUB_GRP, ''null'') = coalesce(b.PRDCT_SUB_GRP, ''null'') and
        coalesce(a.PTY_ID, ''null'') = coalesce(b.PTY_ID, ''null'') and
        coalesce(a.PTY_TYP, ''null'') = coalesce(b.PTY_TYP, ''null'') and
        coalesce(a.RGN, ''null'') = coalesce(b.RGN, ''null'') and
        coalesce(a.Rptg_Adv_Channel, ''null'') = coalesce(b.Rptg_Adv_Channel, ''null'') and
        coalesce(a.SMART_PRDCT_TYP_VAR, ''null'') = coalesce(b.SMART_PRDCT_TYP_VAR, ''null'') and
        coalesce(a.ZIP_CD, ''null'') = coalesce(b.ZIP_CD, ''null'') and
        coalesce(a.adv_channel, ''null'') = coalesce(b.adv_channel, ''null'') and
        coalesce(a.age, ''null'') = coalesce(b.age, ''null'') and
        --coalesce(a.eff_dt, ''null'') = coalesce(b.eff_dt, ''null'') and
        TO_DATE(IFNULL(a.eff_dt, NULL)) = TO_DATE(IFNULL(b.eff_dt, NULL)) and
        coalesce(a.enrollment_type, ''null'') = coalesce(b.enrollment_type, ''null'') and
        coalesce(a.marketing_channel_final, ''null'') = coalesce(b.marketing_channel_final, ''null'') and
        coalesce(a.prdct_ACQN_CHNL_LVL_1, ''null'') = coalesce(b.prdct_ACQN_CHNL_LVL_1, ''null'') and
        coalesce(a.prdct_ACQN_CHNL_LVL_2, ''null'') = coalesce(b.prdct_ACQN_CHNL_LVL_2, ''null'') and
        --coalesce(a.prdct_eff_mo_id, ''null'') = coalesce(b.prdct_eff_mo_id, ''null'') and
        (IFNULL(a.prdct_eff_mo_id, NULL)) = (IFNULL(b.prdct_eff_mo_id, NULL)) and
        --coalesce(a.prem_due_mo_id, ''null'') = coalesce(b.prem_due_mo_id, ''null'') and
        (IFNULL(a.prem_due_mo_id, NULL)) = (IFNULL(b.prem_due_mo_id, NULL)) and
        coalesce(a.sub_channel, ''null'') = coalesce(b.sub_channel, ''null'') and 
        coalesce(a.marketing_channel_cat_3, ''null'') = coalesce(b.marketing_channel_cat_3, ''null'') and
        coalesce(a.region, ''null'') = coalesce(b.region, ''null'') and 
        coalesce(a.sub_region, ''null'') = coalesce(b.sub_region, ''null'') and 
        coalesce(a.sales_market, ''null'') = coalesce(b.sales_market, ''null'') and 
        coalesce(a.business_market, ''null'') = coalesce(b.business_market, ''null'');


V_STEP := ''STEP37'';

V_STEP_NAME :=  ''create a table PDP_SUMMARY'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_PDP_SUMMARY) as 
select 
        ADJUDICATION_STAT_DESC,
        APP_CHANNEL,
        ATTR_CD,
        BROKER_ID_CD,
        CHNL_DESC,
        CONTRACT_ID_CD,
        CREDITED_PSC_TRTMNT_CD,
        PLAN_EFF_DT,
        PRODUCT_SEGMENTS,
        PROD_ID,
        STFIPS,
        st_cd,
        cty_cd,
        plan_cd,
        Plan_desc,
        PSC,
        VALUE_PROP_DESC,
        MEDIUM,
        TFN,
        Objective,
        ProductOffer,
        Channel,
        MktgMedium,
        pdp_region,
        pdp_sub_region,
        pdp_sales_market,
        pdp_business_market,
        count(*) as n_sales
from IDENTIFIER(:V_PDP_SALES_2018_2021_V10) where year(PLAN_EFF_DT)>=2018 and PLAN_EFF_DT<=:V_PREV_YMD
group by 
        ADJUDICATION_STAT_DESC,
        APP_CHANNEL,
        ATTR_CD,
        BROKER_ID_CD,
        CHNL_DESC,
        CONTRACT_ID_CD,
        CREDITED_PSC_TRTMNT_CD,
        PLAN_EFF_DT,
        PRODUCT_SEGMENTS,
        PROD_ID,
        STFIPS,
        st_cd,
        cty_cd,
        plan_cd,
        Plan_desc,
        PSC,
        VALUE_PROP_DESC,
        MEDIUM,
        TFN,
        Objective,
        ProductOffer,
        Channel,
        MktgMedium,
        pdp_region,
        pdp_sub_region,
        pdp_sales_market,
        pdp_business_market;


V_STEP := ''STEP38'';

V_STEP_NAME :=  ''create a table MS_PDP_COMBO_SUMMARY_PDP_LVL'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_MS_PDP_COMBO_SUMMARY_PDP_LVL) as 
select 
        ADJUDICATION_STAT_DESC,
        APP_CHANNEL,
        ATTR_CD,
        BROKER_ID_CD,
        CHNL_DESC,
        CONTRACT_ID_CD,
        CREDITED_PSC_TRTMNT_CD,
        PLAN_EFF_DT,
        PRODUCT_SEGMENTS,
        PROD_ID,
        STFIPS,
        st_cd,
        cty_cd,
        plan_cd,
        Plan_desc,
        PSC,
        VALUE_PROP_DESC,
        MEDIUM,
        TFN,
        Objective,
        ProductOffer,
        Channel,
        MktgMedium,
        pdp_region,
        pdp_sub_region,
        pdp_sales_market,
        pdp_business_market,
        count(pers_id) as n_sales
from IDENTIFIER(:V_MS_PDP_COMBO_SALES_V5)
group by 
        ADJUDICATION_STAT_DESC,
        APP_CHANNEL,
        ATTR_CD,
        BROKER_ID_CD,
        CHNL_DESC,
        CONTRACT_ID_CD,
        CREDITED_PSC_TRTMNT_CD,
        PLAN_EFF_DT,
        PRODUCT_SEGMENTS,
        PROD_ID,
        STFIPS,
        st_cd,
        cty_cd,
        plan_cd,
        Plan_desc,
        PSC,
        VALUE_PROP_DESC,
        MEDIUM,
        TFN,
        Objective,
        ProductOffer,
        Channel,
        MktgMedium,
        pdp_region,
        pdp_sub_region,
        pdp_sales_market,
        pdp_business_market;



V_STEP := ''STEP39'';

V_STEP_NAME :=  ''create a table PDP_SUMMARY_INTMD'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_PDP_SUMMARY_INTMD) as 
select a.*, a.n_sales as PDP_Sales, coalesce(b.n_sales,0) as MS_PDP_Combo_Sales
from IDENTIFIER(:V_PDP_SUMMARY) a 
left join IDENTIFIER(:V_MS_PDP_COMBO_SUMMARY_PDP_LVL) b on 
        coalesce(a.ADJUDICATION_STAT_DESC, ''null'') = coalesce(b.ADJUDICATION_STAT_DESC, ''null'') and 
        coalesce(a.APP_CHANNEL, ''null'') = coalesce(b.APP_CHANNEL, ''null'') and 
        coalesce(a.ATTR_CD, ''null'') = coalesce(b.ATTR_CD, ''null'') and 
        coalesce(a.BROKER_ID_CD, ''null'') = coalesce(b.BROKER_ID_CD, ''null'') and 
        coalesce(a.CHNL_DESC, ''null'') = coalesce(b.CHNL_DESC, ''null'') and 
        coalesce(a.CONTRACT_ID_CD, ''null'') = coalesce(b.CONTRACT_ID_CD, ''null'') and 
        coalesce(a.CREDITED_PSC_TRTMNT_CD, ''null'') = coalesce(b.CREDITED_PSC_TRTMNT_CD, ''null'') and 
        --coalesce(a.PLAN_EFF_DT, ''null'') = coalesce(b.PLAN_EFF_DT, ''null'') and 
        TO_DATE(IFNULL(a.PLAN_EFF_DT, NULL)) = TO_DATE(IFNULL(b.PLAN_EFF_DT, NULL)) and 
        coalesce(a.PRODUCT_SEGMENTS, ''null'') = coalesce(b.PRODUCT_SEGMENTS, ''null'') and 
        --coalesce(a.PROD_ID, ''null'') = coalesce(b.PROD_ID, ''null'') and 
        (IFNULL(a.PROD_ID, NULL)) = (IFNULL(b.PROD_ID, NULL)) and
        coalesce(a.STFIPS, ''null'') = coalesce(b.STFIPS, ''null'') and 
        coalesce(a.st_cd, ''null'') = coalesce(b.st_cd, ''null'') and
        coalesce(a.cty_cd , ''null'') = coalesce(b.cty_cd , ''null'') and
        coalesce(a.plan_cd, ''null'') = coalesce(b.plan_cd, ''null'') and 
        coalesce(a.Plan_desc, ''null'') = coalesce(b.Plan_desc, ''null'') and 
        coalesce(a.PSC, ''null'') = coalesce(b.PSC, ''null'') and
        coalesce(a.VALUE_PROP_DESC, ''null'') = coalesce(b.VALUE_PROP_DESC, ''null'') and
        coalesce(a.MEDIUM, ''null'') = coalesce(b.MEDIUM, ''null'') and
        coalesce(a.TFN::VARCHAR, ''null'') = coalesce(b.TFN::VARCHAR, ''null'') and
        coalesce(a.Objective, ''null'') = coalesce(b.Objective, ''null'') and
        coalesce(a.ProductOffer, ''null'') = coalesce(b.ProductOffer, ''null'') and
        coalesce(a.Channel, ''null'') = coalesce(b.Channel, ''null'') and
        coalesce(a.MktgMedium, ''null'') = coalesce(b.MktgMedium, ''null'') and 
        coalesce(a.pdp_region, ''null'') = coalesce(b.pdp_region, ''null'') and 
        coalesce(a.pdp_sub_region, ''null'') = coalesce(b.pdp_sub_region, ''null'') and
        coalesce(a.pdp_sales_market, ''null'') = coalesce(b.pdp_sales_market, ''null'') and
        coalesce(a.pdp_business_market, ''null'') = coalesce(b.pdp_business_market, ''null'');


V_STEP := ''STEP40'';

V_STEP_NAME :=  ''create a table MS_PDP_COMBO_SUMMARY_DASHBOARD'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_MS_PDP_COMBO_SUMMARY_DASHBOARD) as 
select AREA_CD,
        CNTY_CD,
        CNTY_NM,
        CTY,
        D_ST_CD,
        EALLIANCE_PREF_NM,
        ENROLLMENT_ACTOR,
        ENROLLMENT_CHANNEL,
        ENROLLMENT_MECHANISM,
        ENROLLMENT_PROCESS,
        Enrollment,
        GDR_DESC,
        PLN_LVL,
        PRDCT_SUB_GRP,
        PTY_ID,
        PTY_TYP,
        RGN,
        Rptg_Adv_Channel,
        SMART_PRDCT_TYP_VAR,
        ZIP_CD,
        adv_channel,
        age,
        eff_dt,
        enrollment_type,
        marketing_channel_final,
        prdct_ACQN_CHNL_LVL_1,
        prdct_ACQN_CHNL_LVL_2,
        prdct_eff_mo_id,
        prem_due_mo_id,
        sub_channel,
        ADJUDICATION_STAT_DESC,
        APP_CHANNEL,
        BROKER_ID_CD,
        CHNL_DESC,
        CONTRACT_ID_CD,
        PLAN_EFF_DT,
        PRODUCT_SEGMENTS,
        PROD_ID,
        STFIPS,
        plan_cd,
        Plan_desc,
        marketing_channel_cat_3,
        region,
        sub_region,
        sales_market,
        business_market,
        pdp_region,
        pdp_sub_region,
        pdp_sales_market,
        pdp_business_market,
        count(pers_id) as n_sales
from IDENTIFIER(:V_MS_PDP_COMBO_SALES_V5) 
group by AREA_CD,
        CNTY_CD,
        CNTY_NM,
        CTY,
        D_ST_CD,
        EALLIANCE_PREF_NM,
        ENROLLMENT_ACTOR,
        ENROLLMENT_CHANNEL,
        ENROLLMENT_MECHANISM,
        ENROLLMENT_PROCESS,
        Enrollment,
        GDR_DESC,
        PLN_LVL,
        PRDCT_SUB_GRP,
        PTY_ID,
        PTY_TYP,
        RGN,
        Rptg_Adv_Channel,
        SMART_PRDCT_TYP_VAR,
        ZIP_CD,
        adv_channel,
        age,
        eff_dt,
        enrollment_type,
        marketing_channel_final,
        prdct_ACQN_CHNL_LVL_1,
        prdct_ACQN_CHNL_LVL_2,
        prdct_eff_mo_id,
        prem_due_mo_id,
        sub_channel,
        ADJUDICATION_STAT_DESC,
        APP_CHANNEL,
        BROKER_ID_CD,
        CHNL_DESC,
        CONTRACT_ID_CD,
        PLAN_EFF_DT,
        PRODUCT_SEGMENTS,
        PROD_ID,
        STFIPS,
        plan_cd,
        Plan_desc,
        marketing_channel_cat_3,
        region,
        sub_region,
        sales_market,
        business_market,
        pdp_region,
        pdp_sub_region,
        pdp_sales_market,
        pdp_business_market;




V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_MS_PDP_COMBO_SUMMARY_DASHBOARD)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID,:V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP41'';

V_STEP_NAME :=  ''create a table MS_MBR_ALL_YR'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_MS_MBR_ALL_YR) as 
select a.*,
        case when termination_date is null then ''9999-12-01'' else termination_date end as term_dt,
        b.product_type_code, b.spec_type_code, b.display_plan_code from IDENTIFIER(:V_INSURED_PLAN) a
left join (select distinct specification_id, product_type_code, spec_type_code, display_plan_code from IDENTIFIER(:V_SPECIFICATION)) b on a.specification_id=b.specification_id
where effective_date<=:V_PREV_YMD
and (termination_date>''2017-10-01'' or termination_date is null)
and (effective_date<>coalesce(termination_date, ''9999-12-01''))
and TRIM(product_type_code) = ''M'' and TRIM(spec_type_code)=''B'';


V_STEP := ''STEP42'';

V_STEP_NAME :=  ''create a table MS_MBR_MBI'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_MS_MBR_MBI) as
select a.*, psds.medicare_claim_number as MBI from IDENTIFIER(:V_MS_MBR_ALL_YR) a
left join IDENTIFIER(:V_SHIP_PERSON_XREF_SUBSET) spx on a.person_id = spx.person_id
left outer join IDENTIFIER(:V_PERSON_COMPAS_DAILY_SNAPSHOT_DECRYPT) psds on a.person_id = psds.person_id 
         and spx.ship_person_id = psds.ship_person_id;


V_STEP := ''STEP43'';

V_STEP_NAME :=  ''create a table COMPAS_PLAN_IDS'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_COMPAS_PLAN_IDS) as 
select distinct source_insured_plan_id from IDENTIFIER(:V_MS_MBR_MBI);


V_STEP := ''STEP44'';

V_STEP_NAME :=  ''create a table MS_PRDCT_EFF'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_MS_PRDCT_EFF) as 
select distinct 
	compas_insd_pln_id, 
	prdct_eff_dt_id
from IDENTIFIER(:V_F_PREM_TRANS_DAY_SUBSET) prem
inner join IDENTIFIER(:V_COMPAS_PLAN_IDS) on prem.compas_insd_pln_id = source_insured_plan_id;



V_STEP := ''STEP45'';

V_STEP_NAME :=  ''create a table MS_PRDCT_EFF_V2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_MS_PRDCT_EFF_V2) as 
select * from 
        (
        select *, 
        row_number() over (partition by compas_insd_pln_id order by prdct_eff_dt_id desc NULLS LAST) as rn
        from IDENTIFIER(:V_MS_PRDCT_EFF) a
        ) a
where rn=1
and prdct_eff_dt_id<>-1;



          
V_STEP := ''STEP46'';

V_STEP_NAME :=  ''create a table MS_MBR_ALL_YR_V3'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_MS_MBR_ALL_YR_V3) as
select a.*, b.prdct_eff_dt_id from IDENTIFIER(:V_MS_MBR_MBI) a 
left join IDENTIFIER(:V_MS_PRDCT_EFF_V2) b on source_insured_plan_id=compas_insd_pln_id;


V_STEP := ''STEP47'';

V_STEP_NAME :=  ''create a table MS_MBR_ALL_YR_V4'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_MS_MBR_ALL_YR_V4) as
select *, 
        case when prdct_eff_dt_id is null then effective_date        
        else cast(concat(substr(prdct_eff_dt_id,1,4), ''-'', substr(prdct_eff_dt_id,5,2), ''-'',1 ) as date) end as eff_dt,
        case when prdct_eff_dt_id is null then 0 else 1 end as eff_dt_fg
from IDENTIFIER(:V_MS_MBR_ALL_YR_V3);


V_STEP := ''STEP48'';

V_STEP_NAME :=  ''create a table MS_MBR_ALL_YR_V5'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_MS_MBR_ALL_YR_V5) as 
select * from 
        (
        select *, 
        row_number() over (partition by person_id, eff_dt order by person_id NULLS LAST, eff_dt desc NULLS LAST, term_dt desc NULLS LAST) as rn
        from IDENTIFIER(:V_MS_MBR_ALL_YR_V4) a
        ) a
where rn=1;


V_STEP := ''STEP49'';

V_STEP_NAME :=  ''create a table PDP_MBR_CONT'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace  table IDENTIFIER(:V_PDP_MBR_CONT) as
select * from IDENTIFIER(:V_PDP_INDV_MBR_CONT)
where mbr_plan_eff_dt <= :V_PREV_YMD
and ((dsenrl_dt) > ''2017-10-01'' 
and (mbr_plan_eff_dt)<>(dsenrl_dt));


V_STEP := ''STEP50'';

V_STEP_NAME :=  ''create a table PDP_MBR_CONT_V2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_PDP_MBR_CONT_V2) as
select person_id,
       p.*
from IDENTIFIER(:V_PDP_MBR_CONT) p
left join IDENTIFIER(:V_CMDB_PERSON_XREF_INTERFACE) c
on p.indvdl_id = c.cmdb_person_id;




V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_PDP_MBR_CONT_V2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



V_STEP := ''STEP51'';

V_STEP_NAME :=  ''create a table PDP_MBR_CONT_MBI_CRSWLK'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_PDP_MBR_CONT_MBI_CRSWLK) as
select a.*, a.medicare_hicn_cd as mbi_1, b.mbi as mbi_2,
case when b.mbi is null then a.medicare_hicn_cd else b.mbi end as mbi  
from IDENTIFIER(:V_PDP_MBR_CONT_V2) a
left join IDENTIFIER(:V_CMS_HICN_TO_MBI_CROSSWALK) b
on a.medicare_hicn_cd = b.medicare_hicn_cd;



V_STEP := ''STEP52'';

V_STEP_NAME :=  ''create a table PDP_MBR_NONCONT'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_PDP_MBR_NONCONT) as
select * from IDENTIFIER(:V_FED_MEMBERS)
where cast(mbr_plan_eff_dt as date) <= :V_PREV_YMD_1
and (cast(dsenrl_dt as date) > ''2017-10-01'' or dsenrl_dt is null)
and cast(mbr_plan_eff_dt as date)<>coalesce(cast(dsenrl_dt as date), ''9999-12-01'')
and (pdp_mbr_fg = ''Y'')
and substr(contract_id_cd,7,1) <> ''8'';



V_STEP := ''STEP53'';

V_STEP_NAME :=  ''create a table PDP_MBR_NONCONT_V2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_PDP_MBR_NONCONT_V2) as
select person_id,
       p.*
from IDENTIFIER(:V_PDP_MBR_NONCONT) p
left join IDENTIFIER(:V_CMDB_PERSON_XREF_INTERFACE) c
on p.indvdl_id = c.cmdb_person_id;



V_STEP := ''STEP54'';

V_STEP_NAME :=  ''create a table PDP_MBR_NONCONT_MBI_CRSWLK'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_PDP_MBR_NONCONT_MBI_CRSWLK) as
select a.*, a.medicare_hicn_cd as mbi_1, b.mbi as mbi_2,
case when b.mbi is null then a.medicare_hicn_cd else b.mbi end as mbi  
from IDENTIFIER(:V_PDP_MBR_NONCONT_V2) a
left join IDENTIFIER(:V_CMS_HICN_TO_MBI_CROSSWALK) b
on a.medicare_hicn_cd = b.medicare_hicn_cd;


V_STEP := ''STEP55'';

V_STEP_NAME :=  ''create a table MS_CROSS_SALES_ALL_YR'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_MS_CROSS_SALES_ALL_YR) as
select a.*, 
        b.medicare_hicn_cd,
        b.mbr_plan_eff_dt,
        b.dsenrl_dt,
        b.contract_id_cd,
        b.plan_desc,
        b.plan_cat_nm,
        b.brand_nm
from IDENTIFIER(:V_COMBO_SALES_FROM_MS_SALES) a
inner join IDENTIFIER(:V_PDP_MBR_CONT_MBI_CRSWLK) b 
on a.mbi=b.mbi  
--NEED TO ENABLE
and mbr_plan_eff_dt<=appl_receipt_date
and dsenrl_dt>appl_receipt_date 
and appl_receipt_date is not null
and mbr_plan_eff_dt<>eff_dt
and combo_fg<>1
where year(eff_dt)>=2018 and eff_dt<=:V_PREV_YMD;


V_STEP := ''STEP56'';

V_STEP_NAME :=  ''create a table MS_CROSS_SALES_ALL_YR_V2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_MS_CROSS_SALES_ALL_YR_V2) as
select * from 
        (
        select *, 
        row_number() over (partition by pers_id, eff_dt order by mbr_plan_eff_dt desc NULLS LAST) as r_id
        from IDENTIFIER(:V_MS_CROSS_SALES_ALL_YR)
        ) a
where r_id=1;



V_STEP := ''STEP57'';

V_STEP_NAME :=  ''create a table MS_CROSS_SALES_ALL_YR_2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_MS_CROSS_SALES_ALL_YR_2) as
select a.*, 
        medicare_hicn_cd,
        cast(b.orig_mbr_eff_dt as date) as orig_mbr_eff_dt,
        cast(b.mbr_plan_eff_dt as date) as mbr_plan_eff_dt,
        coalesce(cast(b.dsenrl_dt as date), ''9999-12-01'') as dsenrl_dt,
        b.contract_id_cd,
        b.plan_desc,
        b.plan_cat_nm,
        b.brand_nm
from IDENTIFIER(:V_COMBO_SALES_FROM_MS_SALES) a
inner join IDENTIFIER(:V_PDP_MBR_NONCONT_MBI_CRSWLK) b 
on a.mbi=b.mbi 
and cast(mbr_plan_eff_dt as date)<=appl_receipt_date
and coalesce(cast(dsenrl_dt as date), ''9999-12-01'')>appl_receipt_date 
and appl_receipt_date is not null
and cast(mbr_plan_eff_dt as date)<>eff_dt
and combo_fg<>1
where year(eff_dt)>=2018 and eff_dt<=:V_PREV_YMD;



V_STEP := ''STEP58'';

V_STEP_NAME :=  ''create a table MS_CROSS_SALES_ALL_YR_2_V2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_MS_CROSS_SALES_ALL_YR_2_V2) as
select * from 
        (
        select *, 
        row_number() over (partition by pers_id, eff_dt, appl_receipt_date order by mbr_plan_eff_dt desc NULLS LAST, dsenrl_dt desc NULLS LAST) as r_id
        from IDENTIFIER(:V_MS_CROSS_SALES_ALL_YR_2)
        ) a
where r_id=1;



V_STEP := ''STEP59'';

V_STEP_NAME :=  ''create a table MS_CROSS_SALES_ALL_YR_2_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_MS_CROSS_SALES_ALL_YR_2_1) as
select a.*, b.mbr_plan_eff_dt as mbr_plan_eff_dt_final from IDENTIFIER(:V_MS_CROSS_SALES_ALL_YR_2_V2) a
left join IDENTIFIER(:V_MS_CROSS_SALES_ALL_YR_V2) b 
on a.pers_id = b.pers_id and a.eff_dt = b.eff_dt;



V_STEP := ''STEP60'';

V_STEP_NAME :=  ''create a table MS_CROSS_SALES_SUMMARY_MS_LVL'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_MS_CROSS_SALES_SUMMARY_MS_LVL) as 
select 
        AREA_CD,
        CNTY_CD,
        CNTY_NM,
        CTY,
        D_ST_CD,
        EALLIANCE_PREF_NM,
        ENROLLMENT_ACTOR,
        ENROLLMENT_CHANNEL,
        ENROLLMENT_MECHANISM,
        ENROLLMENT_PROCESS,
        Enrollment,
        GDR_DESC,
        PLN_LVL,
        PRDCT_SUB_GRP,
        PTY_ID,
        PTY_TYP,
        RGN,
        Rptg_Adv_Channel,
        SMART_PRDCT_TYP_VAR,
        ZIP_CD,
        adv_channel,
        age,
        eff_dt,
        enrollment_type,
        marketing_channel_final,
        prdct_ACQN_CHNL_LVL_1,
        prdct_ACQN_CHNL_LVL_2,
        prdct_eff_mo_id,
        prem_due_mo_id,
        sub_channel,
        marketing_channel_cat_3,
        region,
        sub_region,
        sales_market,
        business_market,
        count(pers_id) as n_sales
from IDENTIFIER(:V_MS_CROSS_SALES_ALL_YR_2_1)
group by AREA_CD,
        CNTY_CD,
        CNTY_NM,
        CTY,
        D_ST_CD,
        EALLIANCE_PREF_NM,
        ENROLLMENT_ACTOR,
        ENROLLMENT_CHANNEL,
        ENROLLMENT_MECHANISM,
        ENROLLMENT_PROCESS,
        Enrollment,
        GDR_DESC,
        PLN_LVL,
        PRDCT_SUB_GRP,
        PTY_ID,
        PTY_TYP,
        RGN,
        Rptg_Adv_Channel,
        SMART_PRDCT_TYP_VAR,
        ZIP_CD,
        adv_channel,
        age,
        eff_dt,
        enrollment_type,
        marketing_channel_final,
        prdct_ACQN_CHNL_LVL_1,
        prdct_ACQN_CHNL_LVL_2,
        prdct_eff_mo_id,
        prem_due_mo_id,
        sub_channel,
        marketing_channel_cat_3,
        region,
        sub_region,
        sales_market,
        business_market;




V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_MS_CROSS_SALES_SUMMARY_MS_LVL)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



V_STEP := ''STEP61'';

V_STEP_NAME :=  ''create a table FINAL_SUMMARY_MS'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_FINAL_SUMMARY_MS) as 
select a.*, coalesce(b.n_sales,0) as Cross_Sales

from IDENTIFIER(:V_MS_SUMMARY_INTMD) a 
left join IDENTIFIER(:V_MS_CROSS_SALES_SUMMARY_MS_LVL) b on 
        coalesce(a.AREA_CD, ''null'') = coalesce(b.AREA_CD, ''null'') and
        coalesce(a.CNTY_CD, ''null'') = coalesce(b.CNTY_CD, ''null'') and
        coalesce(a.CNTY_NM, ''null'') = coalesce(b.CNTY_NM, ''null'') and
        coalesce(a.CTY, ''null'') = coalesce(b.CTY, ''null'') and
        coalesce(a.D_ST_CD, ''null'') = coalesce(b.D_ST_CD, ''null'') and
        coalesce(a.EALLIANCE_PREF_NM, ''null'') = coalesce(b.EALLIANCE_PREF_NM, ''null'') and
        coalesce(a.ENROLLMENT_ACTOR, ''null'') = coalesce(b.ENROLLMENT_ACTOR, ''null'') and
        coalesce(a.ENROLLMENT_CHANNEL, ''null'') = coalesce(b.ENROLLMENT_CHANNEL, ''null'') and
        coalesce(a.ENROLLMENT_MECHANISM, ''null'') = coalesce(b.ENROLLMENT_MECHANISM, ''null'') and
        coalesce(a.ENROLLMENT_PROCESS, ''null'') = coalesce(b.ENROLLMENT_PROCESS, ''null'') and
        coalesce(a.Enrollment, ''null'') = coalesce(b.Enrollment, ''null'') and
        coalesce(a.GDR_DESC, ''null'') = coalesce(b.GDR_DESC, ''null'') and
        coalesce(a.PLN_LVL, ''null'') = coalesce(b.PLN_LVL, ''null'') and
        coalesce(a.PRDCT_SUB_GRP, ''null'') = coalesce(b.PRDCT_SUB_GRP, ''null'') and
        coalesce(a.PTY_ID, ''null'') = coalesce(b.PTY_ID, ''null'') and
        coalesce(a.PTY_TYP, ''null'') = coalesce(b.PTY_TYP, ''null'') and
        coalesce(a.RGN, ''null'') = coalesce(b.RGN, ''null'') and
        coalesce(a.Rptg_Adv_Channel, ''null'') = coalesce(b.Rptg_Adv_Channel, ''null'') and
        coalesce(a.SMART_PRDCT_TYP_VAR, ''null'') = coalesce(b.SMART_PRDCT_TYP_VAR, ''null'') and
        coalesce(a.ZIP_CD, ''null'') = coalesce(b.ZIP_CD, ''null'') and
        coalesce(a.adv_channel, ''null'') = coalesce(b.adv_channel, ''null'') and
        coalesce(a.age, ''null'') = coalesce(b.age, ''null'') and
        --coalesce(a.eff_dt, ''null'') = coalesce(b.eff_dt, ''null'') and
        TO_DATE(IFNULL(a.eff_dt, NULL)) = TO_DATE(IFNULL(b.eff_dt, NULL)) and
        coalesce(a.enrollment_type, ''null'') = coalesce(b.enrollment_type, ''null'') and
        coalesce(a.marketing_channel_final, ''null'') = coalesce(b.marketing_channel_final, ''null'') and
        coalesce(a.prdct_ACQN_CHNL_LVL_1, ''null'') = coalesce(b.prdct_ACQN_CHNL_LVL_1, ''null'') and
        coalesce(a.prdct_ACQN_CHNL_LVL_2, ''null'') = coalesce(b.prdct_ACQN_CHNL_LVL_2, ''null'') and
        --coalesce(a.prdct_eff_mo_id, ''null'') = coalesce(b.prdct_eff_mo_id, ''null'') and
        --coalesce(a.prem_due_mo_id, ''null'') = coalesce(b.prem_due_mo_id, ''null'') and
        (IFNULL(a.prdct_eff_mo_id, NULL)) = (IFNULL(b.prdct_eff_mo_id, NULL)) and
        (IFNULL(a.prem_due_mo_id, NULL)) = (IFNULL(b.prem_due_mo_id, NULL)) and
        coalesce(a.sub_channel, ''null'') = coalesce(b.sub_channel, ''null'') and 
        coalesce(a.marketing_channel_cat_3, ''null'') = coalesce(b.marketing_channel_cat_3, ''null'') and
        coalesce(a.region, ''null'') = coalesce(b.region, ''null'') and 
        coalesce(a.sub_region, ''null'') = coalesce(b.sub_region, ''null'') and 
        coalesce(a.sales_market, ''null'') = coalesce(b.sales_market, ''null'') and 
        coalesce(a.business_market, ''null'') = coalesce(b.business_market, ''null'');



V_STEP := ''STEP62'';

V_STEP_NAME :=  ''create a table PDP_CROSS_SALES_ALL_YR'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_PDP_CROSS_SALES_ALL_YR) as
select a.*, 
        b.eff_dt,
        b.term_dt,
        b.display_plan_code
        ,b.eff_dt_fg
from IDENTIFIER(:V_COMBO_SALES_FROM_PDP_SALES) a
inner join IDENTIFIER(:V_MS_MBR_ALL_YR_V5) b 
on a.mbi_match=b.mbi 
and eff_dt<=appl_dt
and term_dt>appl_dt 
and appl_dt is not null
and eff_dt<>PLAN_EFF_DT
and combo_fg<>1
and mbi_match is not null and mbi_match<>''''
where year(PLAN_EFF_DT)>=2018 and plan_eff_dt<=:V_PREV_YMD;



V_STEP := ''STEP63'';

V_STEP_NAME :=  ''create a table PDP_CROSS_SALES_SUMMARY_PDP_LVL'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_PDP_CROSS_SALES_SUMMARY_PDP_LVL) as 
select 
        ADJUDICATION_STAT_DESC,
        APP_CHANNEL,
        ATTR_CD,
        BROKER_ID_CD,
        CHNL_DESC,
        CONTRACT_ID_CD,
        CREDITED_PSC_TRTMNT_CD,
        PLAN_EFF_DT,
        PRODUCT_SEGMENTS,
        PROD_ID,
        STFIPS,
        plan_cd,
        Plan_desc,
        PSC,
        VALUE_PROP_DESC,
        MEDIUM,
        TFN,
        Objective,
        ProductOffer,
        Channel,
        MktgMedium,
        pdp_region,
        pdp_sub_region,
        pdp_sales_market,
        pdp_business_market,
        count(distinct mbi_match) as n_sales
from IDENTIFIER(:V_PDP_CROSS_SALES_ALL_YR)
group by ADJUDICATION_STAT_DESC,
        APP_CHANNEL,
        ATTR_CD,
        BROKER_ID_CD,
        CHNL_DESC,
        CONTRACT_ID_CD,
        CREDITED_PSC_TRTMNT_CD,
        PLAN_EFF_DT,
        PRODUCT_SEGMENTS,
        PROD_ID,
        STFIPS,
        plan_cd,
        Plan_desc,
        PSC,
        VALUE_PROP_DESC,
        MEDIUM,
        TFN,
        Objective,
        ProductOffer,
        Channel,
        MktgMedium,
        pdp_region,
        pdp_sub_region,
        pdp_sales_market,
        pdp_business_market;



V_STEP := ''STEP64'';

V_STEP_NAME :=  ''create a table FINAL_SUMMARY_PDP'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_FINAL_SUMMARY_PDP) as 
select a.*, coalesce(b.n_sales,0) as Cross_Sales
from IDENTIFIER(:V_PDP_SUMMARY_INTMD) a 
left join IDENTIFIER(:V_PDP_CROSS_SALES_SUMMARY_PDP_LVL) b on 
        coalesce(a.ADJUDICATION_STAT_DESC, ''null'') = coalesce(b.ADJUDICATION_STAT_DESC, ''null'') and 
        coalesce(a.APP_CHANNEL, ''null'') = coalesce(b.APP_CHANNEL, ''null'') and 
        coalesce(a.ATTR_CD, ''null'') = coalesce(b.ATTR_CD, ''null'') and 
        coalesce(a.BROKER_ID_CD, ''null'') = coalesce(b.BROKER_ID_CD, ''null'') and 
        coalesce(a.CHNL_DESC, ''null'') = coalesce(b.CHNL_DESC, ''null'') and 
        coalesce(a.CONTRACT_ID_CD, ''null'') = coalesce(b.CONTRACT_ID_CD, ''null'') and 
        coalesce(a.CREDITED_PSC_TRTMNT_CD, ''null'') = coalesce(b.CREDITED_PSC_TRTMNT_CD, ''null'') and 
        --coalesce(a.PLAN_EFF_DT, ''null'') = coalesce(b.PLAN_EFF_DT, ''null'') and 
        TO_DATE(IFNULL(a.PLAN_EFF_DT, NULL)) = TO_DATE(IFNULL(b.PLAN_EFF_DT, NULL)) and
        coalesce(a.PRODUCT_SEGMENTS, ''null'') = coalesce(b.PRODUCT_SEGMENTS, ''null'') and 
        --coalesce(a.PROD_ID, ''null'') = coalesce(b.PROD_ID, ''null'') and 
        (IFNULL(a.PROD_ID, NULL)) = (IFNULL(b.PROD_ID, NULL)) and 
        coalesce(a.STFIPS, ''null'') = coalesce(b.STFIPS, ''null'') and 
        coalesce(a.plan_cd, ''null'') = coalesce(b.plan_cd, ''null'') and 
        coalesce(a.Plan_desc, ''null'') = coalesce(b.Plan_desc, ''null'') and 
        coalesce(a.PSC, ''null'') = coalesce(b.PSC, ''null'') and
        coalesce(a.VALUE_PROP_DESC, ''null'') = coalesce(b.VALUE_PROP_DESC, ''null'') and
        coalesce(a.MEDIUM, ''null'') = coalesce(b.MEDIUM, ''null'') and
        coalesce(a.TFN::VARCHAR, ''null'') = coalesce(b.TFN::VARCHAR, ''null'') and
        coalesce(a.Objective, ''null'') = coalesce(b.Objective, ''null'') and
        coalesce(a.ProductOffer, ''null'') = coalesce(b.ProductOffer, ''null'') and
        coalesce(a.Channel, ''null'') = coalesce(b.Channel, ''null'') and
        coalesce(a.MktgMedium, ''null'') = coalesce(b.MktgMedium, ''null'') and
        coalesce(a.pdp_region, ''null'') = coalesce(b.pdp_region, ''null'') and 
        coalesce(a.pdp_sub_region, ''null'') = coalesce(b.pdp_sub_region, ''null'') and
        coalesce(a.pdp_sales_market, ''null'') = coalesce(b.pdp_sales_market, ''null'') and
        coalesce(a.pdp_business_market, ''null'') = coalesce(b.pdp_business_market, ''null'');



V_STEP := ''STEP65'';

V_STEP_NAME :=  ''create a table MS_CROSS_SALES_SUMMARY'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_MS_CROSS_SALES_SUMMARY) as 
select 
        AREA_CD,
        CNTY_CD,
        CNTY_NM,
        CTY,
        D_ST_CD,
        EALLIANCE_PREF_NM,
        ENROLLMENT_ACTOR,
        ENROLLMENT_CHANNEL,
        ENROLLMENT_MECHANISM,
        ENROLLMENT_PROCESS,
        Enrollment,
        GDR_DESC,
        PLN_LVL,
        PRDCT_SUB_GRP,
        PTY_ID,
        PTY_TYP,
        RGN,
        Rptg_Adv_Channel,
        SMART_PRDCT_TYP_VAR,
        ZIP_CD,
        adv_channel,
        age,
        eff_dt,
        enrollment_type,
        marketing_channel_final,
        prdct_ACQN_CHNL_LVL_1,
        prdct_ACQN_CHNL_LVL_2,
        prdct_eff_mo_id,
        prem_due_mo_id,
        sub_channel,
        marketing_channel_cat_3,
        region,
        sub_region,
        sales_market,
        business_market,
        mbr_plan_eff_dt_final as mbr_plan_eff_dt,
        dsenrl_dt,
        contract_id_cd,
        plan_desc,
        plan_cat_nm,
        brand_nm,
        appl_receipt_date,
        count(pers_id) as n_sales
from IDENTIFIER(:V_MS_CROSS_SALES_ALL_YR_2_1)
group by AREA_CD,
        CNTY_CD,
        CNTY_NM,
        CTY,
        D_ST_CD,
        EALLIANCE_PREF_NM,
        ENROLLMENT_ACTOR,
        ENROLLMENT_CHANNEL,
        ENROLLMENT_MECHANISM,
        ENROLLMENT_PROCESS,
        Enrollment,
        GDR_DESC,
        PLN_LVL,
        PRDCT_SUB_GRP,
        PTY_ID,
        PTY_TYP,
        RGN,
        Rptg_Adv_Channel,
        SMART_PRDCT_TYP_VAR,
        ZIP_CD,
        adv_channel,
        age,
        eff_dt,
        enrollment_type,
        marketing_channel_final,
        prdct_ACQN_CHNL_LVL_1,
        prdct_ACQN_CHNL_LVL_2,
        prdct_eff_mo_id,
        prem_due_mo_id,
        sub_channel,
        marketing_channel_cat_3,
        region,
        sub_region,
        sales_market,
        business_market,
        
        mbr_plan_eff_dt_final,
        dsenrl_dt,
        contract_id_cd,
        plan_desc,
        plan_cat_nm,
        brand_nm,
        appl_receipt_date;



V_STEP := ''STEP66'';

V_STEP_NAME :=  ''create a table PDP_CROSS_SALES_SUMMARY'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_PDP_CROSS_SALES_SUMMARY) as 
select 
        ADJUDICATION_STAT_DESC,
        APP_CHANNEL,
        ATTR_CD,
        BROKER_ID_CD,
        CHNL_DESC,
        CONTRACT_ID_CD,
        CREDITED_PSC_TRTMNT_CD,
        PLAN_EFF_DT,
        PRODUCT_SEGMENTS,
        PROD_ID,
        STFIPS,
        plan_cd,
        Plan_desc,
        PSC,
        VALUE_PROP_DESC,
        MEDIUM,
        TFN,
        Objective,
        ProductOffer,
        Channel,
        MktgMedium,
        pdp_region,
        pdp_sub_region,
        pdp_sales_market,
        pdp_business_market,
        eff_dt,
        term_dt,
        appl_dt,
        display_plan_code,
        count(distinct mbi_match) as n_sales
from IDENTIFIER(:V_PDP_CROSS_SALES_ALL_YR)
group by ADJUDICATION_STAT_DESC,
        APP_CHANNEL,
        ATTR_CD,
        BROKER_ID_CD,
        CHNL_DESC,
        CONTRACT_ID_CD,
        CREDITED_PSC_TRTMNT_CD,
        PLAN_EFF_DT,
        PRODUCT_SEGMENTS,
        PROD_ID,
        STFIPS,
        plan_cd,
        Plan_desc,
        PSC,
        VALUE_PROP_DESC,
        MEDIUM,
        TFN,
        Objective,
        ProductOffer,
        Channel,
        MktgMedium,
        pdp_region,
        pdp_sub_region,
        pdp_sales_market,
        pdp_business_market,
        eff_dt,
        term_dt,
        appl_dt,
        display_plan_code;



V_STEP := ''STEP67'';

V_STEP_NAME :=  ''create a table MSPDP_FINAL_SUMMARY_MS_BACKUP'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace  table IDENTIFIER(:V_MSPDP_FINAL_SUMMARY_MS_BACKUP) as select * from IDENTIFIER(:V_MSPDP_FINAL_SUMMARY_MS);




V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_MSPDP_FINAL_SUMMARY_MS_BACKUP)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);





V_STEP := ''STEP68'';

V_STEP_NAME :=  ''create a table MSPDP_FINAL_SUMMARY_PDP_BACKUP'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_MSPDP_FINAL_SUMMARY_PDP_BACKUP) as select * from IDENTIFIER(:V_MSPDP_FINAL_SUMMARY_PDP);




V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_MSPDP_FINAL_SUMMARY_PDP_BACKUP)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




V_STEP := ''STEP69'';

V_STEP_NAME :=  ''create a table MSPDP_FINAL_SUMMARY_MS'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_MSPDP_FINAL_SUMMARY_MS) COPY GRANTS as select * from IDENTIFIER(:V_FINAL_SUMMARY_MS);




V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_MSPDP_FINAL_SUMMARY_MS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);





V_STEP := ''STEP70'';

V_STEP_NAME :=  ''create a table MSPDP_FINAL_SUMMARY_PDP'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace  table IDENTIFIER(:V_MSPDP_FINAL_SUMMARY_PDP) COPY GRANTS as select * from IDENTIFIER(:V_FINAL_SUMMARY_PDP);




V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_MSPDP_FINAL_SUMMARY_PDP)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



V_STEP := ''STEP71'';

V_STEP_NAME :=  ''create a table MSPDP_COMBO_SUMMARY'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace  table IDENTIFIER(:V_MSPDP_COMBO_SUMMARY) as select * from IDENTIFIER(:V_MS_PDP_COMBO_SUMMARY_DASHBOARD);




V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_MSPDP_COMBO_SUMMARY)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

          


V_STEP := ''STEP72'';

V_STEP_NAME :=  ''create a table MSPDP_CROSS_SALES_SUMMARY_MS'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_MSPDP_CROSS_SALES_SUMMARY_MS) as select * from IDENTIFIER(:V_MS_CROSS_SALES_SUMMARY);




V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_MSPDP_CROSS_SALES_SUMMARY_MS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



V_STEP := ''STEP73'';

V_STEP_NAME :=  ''create a table MSPDP_CROSS_SALES_SUMMARY_PDP'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace  table IDENTIFIER(:V_MSPDP_CROSS_SALES_SUMMARY_PDP) as select * from IDENTIFIER(:V_PDP_CROSS_SALES_SUMMARY);




V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_MSPDP_CROSS_SALES_SUMMARY_PDP)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP74'';

V_STEP_NAME :=  ''create a table CURR_MONTH_SUMM_MS'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace  table IDENTIFIER(:V_CURR_MONTH_SUMM_MS) copy grants as
select a.eff_dt, a.ms_sales, a.ms_pdp_combo_sales, a.cross_sales, b.ms_pdp_combo_sales as ms_pdp_combo_sales_ck, c.ms_cross_sales as cross_sales_ck
from 
(
select eff_dt, 
        sum(ms_sales) as ms_sales,
        sum(ms_pdp_combo_sales) as ms_pdp_combo_sales,
        sum(cross_sales) as cross_sales
from IDENTIFIER(:V_MSPDP_FINAL_SUMMARY_MS)
group by eff_dt) a
left join 
        (
        select eff_dt, sum(n_sales) as ms_pdp_combo_sales
        from IDENTIFIER(:V_MSPDP_COMBO_SUMMARY) group by eff_dt
        ) b on a.eff_dt=b.eff_dt
left join 
        (
        select eff_dt, sum(n_sales) as ms_cross_sales 
        from IDENTIFIER(:V_MSPDP_CROSS_SALES_SUMMARY_MS) group by eff_dt
        ) c on a.eff_dt=c.eff_dt;





V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_CURR_MONTH_SUMM_MS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP75'';

V_STEP_NAME :=  ''create a table CURR_MONTH_SUMM_PDP'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace   table IDENTIFIER(:V_CURR_MONTH_SUMM_PDP) copy grants as
select a.plan_eff_dt, a.pdp_sales, a.ms_pdp_combo_sales, a.cross_sales, b.pdp_cross_sales as cross_sales_ck 
from
(
select plan_eff_dt, 
        sum(pdp_sales) as pdp_sales, 
        sum(ms_pdp_combo_sales) as ms_pdp_combo_sales, 
        sum(cross_sales) as cross_sales 
from IDENTIFIER(:V_MSPDP_FINAL_SUMMARY_PDP)
group by plan_eff_dt
) a
left join 
        (
        select plan_eff_dt, sum(n_sales) as pdp_cross_sales 
        from IDENTIFIER(:V_MSPDP_CROSS_SALES_SUMMARY_PDP) 
        group by plan_eff_dt
        ) b on a.plan_eff_dt = b.plan_eff_dt;




V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_CURR_MONTH_SUMM_PDP)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP76'';

V_STEP_NAME :=  ''create a table MS_SALES_QC'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_MS_SALES_QC) as
select a.eff_dt, ms_sales, ms_pdp_combo_sales, n_sales_preferred, n_sales_saver_plus, n_sales_walgreens, n_sales_symphonics, cross_sales, 
ms_sales_prev, ms_pdp_combo_sales_prev, n_sales_preferred_prev, n_sales_saver_plus_prev, n_sales_walgreens_prev, n_sales_symphonics_prev, cross_sales_prev
from 
(
select eff_dt, 
        sum(ms_sales) as ms_sales,
        sum(ms_pdp_combo_sales) as ms_pdp_combo_sales, 
        sum(n_sales_preferred) as n_sales_preferred, 
        sum(n_sales_saver_plus) as n_sales_saver_plus, 
        sum(n_sales_walgreens) as n_sales_walgreens, 
        sum(n_sales_symphonics) as n_sales_symphonics,
        sum(cross_sales) as cross_sales
from IDENTIFIER(:V_MSPDP_FINAL_SUMMARY_MS)
group by eff_dt
) a
left join 
(
select eff_dt, 
        sum(ms_sales) as ms_sales_prev,
        sum(ms_pdp_combo_sales) as ms_pdp_combo_sales_prev, 
        sum(n_sales_preferred) as n_sales_preferred_prev, 
        sum(n_sales_saver_plus) as n_sales_saver_plus_prev, 
        sum(n_sales_walgreens) as n_sales_walgreens_prev, 
        sum(n_sales_symphonics) as n_sales_symphonics_prev,
        sum(cross_sales) as cross_sales_prev
from IDENTIFIER(:V_MSPDP_FINAL_SUMMARY_MS_BACKUP)
group by eff_dt
) b on a.eff_dt=b.eff_dt;





V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_MS_SALES_QC)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




V_STEP := ''STEP77'';

V_STEP_NAME :=  ''create a table PDP_SALES_QC'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_PDP_SALES_QC) as
select a.plan_eff_dt,  pdp_sales, ms_pdp_combo_sales, cross_sales, pdp_sales_prev, ms_pdp_combo_sales_prev, cross_sales_prev
from 
(
select plan_eff_dt, 
        sum(pdp_sales) as pdp_sales, 
        sum(ms_pdp_combo_sales) as ms_pdp_combo_sales, 
        sum(cross_sales) as cross_sales 
from IDENTIFIER(:V_MSPDP_FINAL_SUMMARY_PDP)
group by plan_eff_dt
) a
left join 
(
select plan_eff_dt, 
        sum(pdp_sales) as pdp_sales_prev, 
        sum(ms_pdp_combo_sales) as ms_pdp_combo_sales_prev, 
        sum(cross_sales) as cross_sales_prev
from IDENTIFIER(:V_MSPDP_FINAL_SUMMARY_PDP_BACKUP)
group by plan_eff_dt
) b on a.plan_eff_dt=b.plan_eff_dt;




V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_PDP_SALES_QC)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



V_STEP := ''STEP78'';

V_STEP_NAME :=  ''drop a table MSPDP_FINAL_SUMMARY_MS_BACKUP_CURRENT_DT'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


drop table if exists IDENTIFIER(:V_MSPDP_FINAL_SUMMARY_MS_BACKUP_CURRENT_DT);


V_STEP := ''STEP79'';

V_STEP_NAME :=  ''create a table MSPDP_FINAL_SUMMARY_MS_BACKUP_CURRENT_DT'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace  table IDENTIFIER(:V_MSPDP_FINAL_SUMMARY_MS_BACKUP_CURRENT_DT) as
select * from IDENTIFIER(:V_MSPDP_FINAL_SUMMARY_MS);





V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_MSPDP_FINAL_SUMMARY_MS_BACKUP_CURRENT_DT)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




V_STEP := ''STEP80'';

V_STEP_NAME :=  ''drop a table MSPDP_FINAL_SUMMARY_PDP_BACKUP_CURRENT_DT'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());



drop table if exists IDENTIFIER(:V_MSPDP_FINAL_SUMMARY_PDP_BACKUP_CURRENT_DT);





V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP81'';

V_STEP_NAME :=  ''create a table MSPDP_FINAL_SUMMARY_PDP_BACKUP_CURRENT_DT'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace  table IDENTIFIER(:V_MSPDP_FINAL_SUMMARY_PDP_BACKUP_CURRENT_DT) as
select * from IDENTIFIER(:V_MSPDP_FINAL_SUMMARY_PDP);




V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_MSPDP_FINAL_SUMMARY_PDP_BACKUP_CURRENT_DT)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);


RAISE;

END;

';