
USE SCHEMA BDR_FFP_DA;




CREATE OR REPLACE PROCEDURE BDR_FFP_DA.SP_OLE_FORECAST("PIPELINE_ID" VARCHAR(16777216), "PIPELINE_NAME" VARCHAR(16777216), "DB_NAME" VARCHAR(16777216), "UTIL_SC" VARCHAR(16777216), "TGT_SC" VARCHAR(16777216), "FFP_WRK_SC" VARCHAR(16777216), "SRC_SC" VARCHAR(16777216), "ONE_SC" VARCHAR(16777216), "WH" VARCHAR(16777216), "CURR_DATE" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

V_CURRENT_DATE   DATE := COALESCE(TO_DATE(:CURR_DATE), CURRENT_DATE());

V_REPORT_DATE DATE := COALESCE(TO_DATE(:CURR_DATE), CURRENT_DATE());

V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := :DB_NAME||''.''||COALESCE(:UTIL_SC, ''UTIL'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';

V_PROCESS_NAME   VARCHAR DEFAULT ''OLE_FORECAST'';

V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''OLE_FORECAST'';

V_STEP             VARCHAR;

V_STEP_NAME        VARCHAR;

V_START_TIME       VARCHAR;

V_END_TIME         VARCHAR;

V_ROWS_PARSED       INTEGER;

V_ROWS_LOADED       INTEGER;

V_MESSAGE          VARCHAR;

V_LAST_QUERY_ID    VARCHAR;

V_SQL_QUERY VARCHAR;


V_APP_ENROLL_STORE VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''ACESX'') || ''.APP_ENROLL_STORE'';
V_CHANNEL_TYPE VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''ACESX'') || ''.CHANNEL_TYPE'';
V_ENROLL_PRODUCT VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''ACESX'') || ''.ENROLL_PRODUCT'';
V_OLE_APPLICATION VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''SRC_COMPAS'') || ''.OLE_APPLICATION'';
V_APPLICATION VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''SRC_COMPAS'') || ''.APPLICATION'';
V_APPLICATION_REASON VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''SRC_COMPAS'') || ''.APPLICATION_REASON'';
V_REASON VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''SRC_COMPAS'') || ''.REASON'';


V_ACESX_DATA VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.ACESX_DATA'';
V_OLE_APPS_STATUS VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.OLE_APPS_STATUS'';
V_FORECAST_OLE_APPS  VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.OLE_FORECAST_OLE_APPS '';

V_DOMO_FORECAST_MS_DTC_OLE_START_AND_APPS VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''.BDR_FFP_DA'') || ''.DOMO_FORECAST_MS_DTC_OLE_START_AND_APPS'';
V_SUB_APPS_ADJUC_STAT  VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.OLE_SUB_APPS_ADJUC_STAT '';
V_APPS_ADJUD_REASON VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.OLE_APPS_ADJUD_REASON'';
V_SUB_APPS_SUMM VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.OLE_SUB_APPS_SUMM'';
V_SUB_APPS_SUMM_FORECAST VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.OLE_SUB_APPS_SUMM_FORECAST'';


BEGIN

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

/****    ACESX DATA (BASE DATA)   ****/

V_STEP := ''STEP1'';

V_STEP_NAME :=  ''create a ACESX_DATA'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table  IDENTIFIER(:V_ACESX_DATA) COPY GRANTS as
SELECT
	CHANNEL,
	CHANNEL_Split,
	ACES_APP_ID,
	ADJUDICATION_STATUS,
	SHOV_STATUS,
	SUBMITTED_TIME,
	submitted_timestamp,
	ERROR_DESCRIPTION,
	CREATED_DATE,
        CREATION_DATE,
	DCN,
	OLE_REFERENCE_ID,
	ACES_APPLICATION_STATUS, 
	(case
		when APPLICATION_STATUS = ''COMPLETED_ADJUDICATION'' then ''Successful Submissions''
		when APPLICATION_STATUS = ''COMPLETED_EMAIL'' then ''Completed Email''
		when APPLICATION_STATUS = ''TRANSFER_DTC'' then ''Transfer to DTC''
		when APPLICATION_STATUS = ''SUBMITTED'' then ''Submitted''
		when APPLICATION_STATUS = ''SAVED'' then ''Saved''
		when APPLICATION_STATUS = ''UNDER_QR'' then ''Under QR''
		when APPLICATION_STATUS = ''DELETED'' then ''Deleted''
		when APPLICATION_STATUS = ''SENT_TO_PRINT'' then ''Sent to Print''
		when APPLICATION_STATUS = ''RESENT_MAIL'' then ''Resent Email''
		when APPLICATION_STATUS = ''SUBMITTED_TO_PRINT_BATCH'' then ''Print Batch''
		when APPLICATION_STATUS = ''NOT IN COMPAS'' then ''Insufficient Information''
		else ''OTHERS''
	end) as APPLICATION_STATUS,
	(case
		when APPLICATION_STATUS = ''COMPLETED_ADJUDICATION'' then 2
		when APPLICATION_STATUS = ''COMPLETED_EMAIL'' then 3
		when APPLICATION_STATUS = ''TRANSFER_DTC'' then 4
		when APPLICATION_STATUS = ''SUBMITTED'' then 5
		when APPLICATION_STATUS = ''SAVED'' then 6
		when APPLICATION_STATUS = ''UNDER_QR'' then 7
		when APPLICATION_STATUS = ''DELETED'' then 8
		when APPLICATION_STATUS = ''SENT_TO_PRINT'' then 9
		when APPLICATION_STATUS = ''RESENT_MAIL'' then 10
		when APPLICATION_STATUS = ''SUBMITTED_TO_PRINT_BATCH'' then 11
		when APPLICATION_STATUS = ''NOT IN COMPAS'' then 12 
		else 13
	end) as APPLICATION_STATUS_sort,
	ACES_OLE_REFERENCE_ID,
	THIRD_PARTY_ID,
	AGING_DAYS,
	(case
		when AGING_DAYS between 0 and 2 then ''0-2 days (48 hours)''
		when AGING_DAYS between 3 and 5 then ''3-5 days''
		when AGING_DAYS between 6 and 10 then ''6-10 days''
		when AGING_DAYS between 11 and 20 then ''11-20 days''
		when AGING_DAYS between 21 and 30 then ''21-30 days''
		when AGING_DAYS between 31 and 60 then ''31-60 days''
		when AGING_DAYS between 61 and 90 then ''61-90 days''
		when AGING_DAYS > 90 then ''91+ days ''
	end) as no_of_days,
	(case
		when AGING_DAYS between 0 and 2 then 1
		when AGING_DAYS between 3 and 5 then 2
		when AGING_DAYS between 6 and 10 then 3
		when AGING_DAYS between 11 and 20 then 4
		when AGING_DAYS between 21 and 30 then 5
		when AGING_DAYS between 31 and 60 then 6
		when AGING_DAYS between 61 and 90 then 7
		when AGING_DAYS > 90 then 8
	end) as no_of_days_sort
	,versn
FROM
	(
	SELECT
		(CASE WHEN (ACES_APPLICATION_STATUS =''TRANSFER_DTC'') THEN ''DTC'' ELSE aes.CHANNEL_TYPE_NAME END) AS CHANNEL,
		(case
			when (aes.origin_channel_type_id  is not null) then ''DTC - Digital App Assist'' 
			when (aces_application_status =''TRANSFER_DTC'' or aes.channel_type_name=''DTC'') and Third_party_id != '''' then ''DTC - 3rd Party Integration into DTC''
			when (aces_application_status =''TRANSFER_DTC'' or aes.channel_type_name=''DTC'') then ''DTC - OLE''
			when (aes.channel_type_name=''AGGREGATOR'' and expiry_date is not null) then ''AGGREGATOR - eAlliance OLE UI''
			when (aes.channel_type_name=''AGGREGATOR'') then ''AGGREGATOR - eAlliance Batch''
			when (aes.channel_type_name=''AGENT'' and vendor_code != '''') then ''AGENT - Field Agent Partner/Batch OLE (CSG)''
			when (aes.channel_type_name=''AGENT'') then ''AGENT - Field Agent OLE''
			else aes.channel_type_name end) as CHANNEL_Split,
		AES.ACES_APP_ID,
		AES.ADJUDICATION_STATUS,
		AES.SHOV_STATUS,
		AES.SUBMITTED_TIME,
		EP.submitted_timestamp,
		AES.ERROR_DESCRIPTION,
		AES.CREATED_DATE,
		ep.CREATION_DATE,
		AES.DCN,
		AES.OLE_REFERENCE_ID,
		AES.ACES_APPLICATION_STATUS,
		(CASE
			WHEN AES.OLE_REFERENCE_ID IS NULL THEN ''NOT IN COMPAS''
            ELSE AES.ACES_APPLICATION_STATUS END) APPLICATION_STATUS,
		AES.ACES_OLE_REFERENCE_ID,
		AES.THIRD_PARTY_ID,
		ABS(DATEDIFF(DAY,current_date(),case when APP_DATA_VERSION = ''v2'' then to_date(AES.CREATED_DATE) else to_date(ep.CREATION_DATE) end)) as AGING_DAYS,
		AES.APP_DATA_VERSION as VERSN
	FROM
		(select
			aes2.*
			,ct.channel_type_name
FROM
	IDENTIFIER(:V_APP_ENROLL_STORE) AES2
inner join
	IDENTIFIER(:V_CHANNEL_TYPE) CT
ON	CT.CHANNEL_TYPE_ID = AES2.CHANNEL_TYPE_ID
		)aes
	full join
		IDENTIFIER(:V_ENROLL_PRODUCT) ep
	on	aes.aces_app_id = ep.aces_app_id
	and	ep.product_id = 1
	WHERE
		case
			when aes.APP_DATA_VERSION = ''v2'' then to_date(AES.CREATED_DATE) BETWEEN TRUNC(add_months(current_date(),-24),''YY'')
			and (case
					when DAYOFWEEK(CURRENT_DATE()) = 1 and TO_CHAR(CURRENT_TIMESTAMP(),''HH:MI:SS'') >= ''00:00:00'' and TO_CHAR(CURRENT_TIMESTAMP(),''HH:MI:SS'') <= ''07:00:00'' then DATEADD(DAY,-3,CURRENT_DATE())
					when TO_CHAR(CURRENT_TIMESTAMP(),''HH:MI:SS'') >= ''00:00:00'' and TO_CHAR(CURRENT_TIMESTAMP(),''HH:MI:SS'') <= ''07:00:00'' then DATEADD(DAY,-2,CURRENT_DATE())
					else DATEADD(DAY,-1,CURRENT_DATE()) end
				)
			when APP_DATA_VERSION = ''v4'' then to_date(ep.CREATION_DATE) BETWEEN TRUNC(add_months(current_date(),-24),''YY'')
			and (case
					when DAYOFWEEK(CURRENT_DATE()) = 1 and TO_CHAR(CURRENT_TIMESTAMP(),''HH:MI:SS'') >= ''00:00:00'' and TO_CHAR(CURRENT_TIMESTAMP(),''HH:MI:SS'') <= ''07:00:00'' then DATEADD(DAY,-3,CURRENT_DATE())
					when TO_CHAR(CURRENT_TIMESTAMP(),''HH:MI:SS'') >= ''00:00:00'' and TO_CHAR(CURRENT_TIMESTAMP(),''HH:MI:SS'') <= ''07:00:00'' then DATEADD(DAY,-2,CURRENT_DATE())
		 else DATEADD(DAY,-1,CURRENT_DATE()) end
				)
		end
	)as t1;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_ACESX_DATA)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

/****    Requirement 1 - OLE STARTED BUT NOT SUBMITTED    ****/

V_STEP := ''STEP2'';

V_STEP_NAME :=  ''create a OLE_APPS_STATUS'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


Create or replace table  IDENTIFIER(:V_OLE_APPS_STATUS) COPY GRANTS as
SELECT
	a.*
	,case
		when (a.submitted_time is not null or a.submitted_timestamp is not null) and a.ole_reference_id is not null then ''Y''
		else ''N''
	end as OLE_SUBMITTED_FLG
from
	 IDENTIFIER(:V_ACESX_DATA) a;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_OLE_APPS_STATUS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP3'';

V_STEP_NAME :=  ''create a SUB_APPS_ADJUC_STAT'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


Create or replace table  IDENTIFIER(:V_OLE_APPS_STATUS) COPY GRANTS as
SELECT
	a.*
	,case
		when (a.submitted_time is not null or a.submitted_timestamp is not null) and a.ole_reference_id is not null then ''Y''
		else ''N''
	end as OLE_SUBMITTED_FLG
from
	 IDENTIFIER(:V_ACESX_DATA) a;

/****    Requirement 2 - FOR SUBMITTED APPS in 1 - ADJUDICATION_STATUS IN COMPAS APPLICATION TABLE    ****/

create or replace table  IDENTIFIER(:V_SUB_APPS_ADJUC_STAT) COPY GRANTS as
select
	a.*
	,case
		when (a.submitted_time is not null or a.submitted_timestamp is not null) and a.ole_reference_id is not null and c.application_id is not null then ''Y''
		else ''N''
	 end as OLE_SUBMITTED_FLG_new
	,b.ole_reference_identifier
	,case when b.ole_reference_identifier is null then ''N''
	 else ''Y''
	 end as In_OLE_APP_Flg
	,b.date_of_birth
	,ROUND(extract(year from a.submitted_time)-extract(year from b.DATE_OF_BIRTH)) as age_at_Submit
	,ROUND(extract(year from a.created_date)-extract(year from b.DATE_OF_BIRTH)) as age_at_App
	,CASE
		WHEN ROUND(extract(year from coalesce(a.submitted_time,a.submitted_timestamp))-extract(year from b.DATE_OF_BIRTH)) BETWEEN 0 AND 49 THEN ''<50''
		WHEN ROUND(extract(year from coalesce(a.submitted_time,a.submitted_timestamp))-extract(year from b.DATE_OF_BIRTH)) BETWEEN 50 AND 64 THEN ''50-64''
		WHEN ROUND(extract(year from coalesce(a.submitted_time,a.submitted_timestamp))-extract(year from b.DATE_OF_BIRTH)) BETWEEN 65 AND 69 THEN ''65-69''
		WHEN ROUND(extract(year from coalesce(a.submitted_time,a.submitted_timestamp))-extract(year from b.DATE_OF_BIRTH)) BETWEEN 70 AND 79 THEN ''70-79''
		WHEN ROUND(extract(year from coalesce(a.submitted_time,a.submitted_timestamp))-extract(year from b.DATE_OF_BIRTH)) BETWEEN 80 AND 89 THEN ''80-89''
		WHEN ROUND(extract(year from coalesce(a.submitted_time,a.submitted_timestamp))-extract(year from b.DATE_OF_BIRTH)) BETWEEN 90 AND 99 THEN ''90-99''
		WHEN ROUND(extract(year from coalesce(a.submitted_time,a.submitted_timestamp))-extract(year from b.DATE_OF_BIRTH)) >= 100 THEN ''100+''
	 END AS age_group_submit
	 ,CASE
		WHEN ROUND(extract(year from (case when versn = ''v2'' then a.created_date else a.creation_date end))-extract(year from b.DATE_OF_BIRTH)) BETWEEN 0 AND 49 THEN ''<50''
		WHEN ROUND(extract(year from (case when versn = ''v2'' then a.created_date else a.creation_date end))-extract(year from b.DATE_OF_BIRTH)) BETWEEN 50 AND 64 THEN ''50-64''
		WHEN ROUND(extract(year from (case when versn = ''v2'' then a.created_date else a.creation_date end))-extract(year from b.DATE_OF_BIRTH)) BETWEEN 65 AND 69 THEN ''65-69''
		WHEN ROUND(extract(year from (case when versn = ''v2'' then a.created_date else a.creation_date end))-extract(year from b.DATE_OF_BIRTH)) BETWEEN 70 AND 79 THEN ''70-79''
		WHEN ROUND(extract(year from (case when versn = ''v2'' then a.created_date else a.creation_date end))-extract(year from b.DATE_OF_BIRTH)) BETWEEN 80 AND 89 THEN ''80-89''
		WHEN ROUND(extract(year from (case when versn = ''v2'' then a.created_date else a.creation_date end))-extract(year from b.DATE_OF_BIRTH)) BETWEEN 90 AND 99 THEN ''90-99''
		WHEN ROUND(extract(year from (case when versn = ''v2'' then a.created_date else a.creation_date end))-extract(year from b.DATE_OF_BIRTH)) >= 100 THEN ''100+''
	 END AS age_group_App
	,c.application_id
	,case when c.application_id is null then ''N''
	 else ''Y''
	 end as In_Compas_Flg
	,c.adjudication_cd
	,case
		when c.adjudication_cd = ''P'' then ''PENDING''
		when c.adjudication_cd = ''W'' then ''WITHDRAWN''
		when c.adjudication_cd = ''A'' then ''ACCEPTED''
		when c.adjudication_cd = ''D'' then ''DENIED''
	 end as adjudication_status_desc
	,case
		when c.plan_request_1 is NULL then ''N/A''
		when trim(c.plan_request_1) in (''GH1'',''GH2'') then ''GH''
		when trim(c.plan_request_1) in (''G01'',''G'',''G0'',''GS1'', ''G02'', ''GS2'') then ''G''
		when trim(c.plan_request_1) in (''F01'',''F0'',''F'',''FS1'', ''F02'', ''FS2'') then ''F'' 
		when trim(c.plan_request_1) in (''K01'',''K'') then ''K''
		when trim(c.plan_request_1) in (''N01'',''NS1'', ''N02'', ''NS2'') then ''N''
	 else ''Other'' end as Product
	,b.state_cd as b_State
	,c.state_cd as State
	,case 
	when DAYOFWEEK(CURRENT_DATE()) = 1 and TO_CHAR(CURRENT_TIMESTAMP(),''HH:MI:SS'') >= ''00:00:00'' and TO_CHAR(CURRENT_TIMESTAMP(),''HH:MI:SS'') <= ''07:00:00'' then DATEADD(DAY,-3,CURRENT_DATE())
	when TO_CHAR(CURRENT_TIMESTAMP(),''HH:MI:SS'') >= ''00:00:00'' and TO_CHAR(CURRENT_TIMESTAMP(),''HH:MI:SS'') <= ''07:00:00'' then DATEADD(DAY,-1,CURRENT_DATE())
 else current_date end as today
,DATEADD(DAY,-1,(case 
	when DAYOFWEEK(CURRENT_DATE()) = 1 and TO_CHAR(CURRENT_TIMESTAMP(),''HH:MI:SS'') >= ''00:00:00'' and TO_CHAR(CURRENT_TIMESTAMP(),''HH:MI:SS'') <= ''07:00:00'' then DATEADD(DAY,-3,CURRENT_DATE())
	when TO_CHAR(CURRENT_TIMESTAMP(),''HH:MI:SS'') >= ''00:00:00'' and TO_CHAR(CURRENT_TIMESTAMP(),''HH:MI:SS'') <= ''07:00:00'' then DATEADD(DAY,-1,CURRENT_DATE())
  else current_date end)) as today_minus1
from
	 IDENTIFIER(:V_OLE_APPS_STATUS) a
left join
	IDENTIFIER(:V_OLE_APPLICATION) b
on	a.ole_reference_id = b.ole_reference_identifier
left join
	IDENTIFIER(:V_APPLICATION) c
on	b.application_id = c.application_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_SUB_APPS_ADJUC_STAT)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

V_STEP := ''STEP4'';

V_STEP_NAME :=  ''create a APPS_ADJUD_REASON'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE or replace TABLE  IDENTIFIER(:V_APPS_ADJUD_REASON) COPY GRANTS as
SELECT
	a.channel
	,a.channel_split
	,a.aces_app_id
	,a.adjudication_status
	,a.shov_status
	,a.submitted_time
	,a.submitted_timestamp
	,a.error_description
	,a.created_date
	,a.creation_date
	,a.dcn
	,a.ole_reference_id
	,a.aces_application_status
	,a.application_status
	,a.application_status_sort
	,a.aces_ole_reference_id
	,a.third_party_id
	,a.aging_days
	,a.no_of_days
	,a.no_of_days_sort
	,a.versn
	,a.ole_submitted_flg
	,a.ole_submitted_flg_new
	,a.ole_reference_identifier
	,a.in_ole_app_flg
	,a.date_of_birth
	,a.age_at_submit
	,a.age_at_app
	,a.age_group_submit
	,a.age_group_app
	,a.application_id
	,a.in_compas_flg
	,a.adjudication_cd
	,case
		when adjudication_status_desc is null then ''NULL''
		else a.adjudication_status_desc
	 end as adjudication_status_desc
	,a.product
	,a.b_state
	,a.state
	,b.reason_id
	,c.reason_text
	,case 
	when DAYOFWEEK(CURRENT_DATE()) = 1 and TO_CHAR(CURRENT_TIMESTAMP(),''HH:MI:SS'') >= ''00:00:00'' and TO_CHAR(CURRENT_TIMESTAMP(),''HH:MI:SS'') <= ''07:00:00'' then DATEADD(DAY,-3,CURRENT_DATE())
	when TO_CHAR(CURRENT_TIMESTAMP(),''HH:MI:SS'') >= ''00:00:00'' and TO_CHAR(CURRENT_TIMESTAMP(),''HH:MI:SS'') <= ''07:00:00'' then DATEADD(DAY,-1,CURRENT_DATE())
 else current_date end as today
,dateadd(DAY,-1,(case 
	when DAYOFWEEK(CURRENT_DATE()) = 1 and TO_CHAR(CURRENT_TIMESTAMP(),''HH:MI:SS'') >= ''00:00:00'' and TO_CHAR(CURRENT_TIMESTAMP(),''HH:MI:SS'') <= ''07:00:00'' then DATEADD(DAY,-3,CURRENT_DATE())
	when TO_CHAR(CURRENT_TIMESTAMP(),''HH:MI:SS'') >= ''00:00:00'' and TO_CHAR(CURRENT_TIMESTAMP(),''HH:MI:SS'') <= ''07:00:00'' then DATEADD(DAY,-1,CURRENT_DATE())
	else current_date end)) as today_minus1
FROM
	 IDENTIFIER(:V_SUB_APPS_ADJUC_STAT) a
LEFT JOIN
	IDENTIFIER(:V_APPLICATION_REASON) b
ON	a.application_id = b.application_id
AND a.adjudication_cd != ''A''
LEFT JOIN
	IDENTIFIER(:V_REASON) c
ON	b.reason_id = c.reason_id;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_APPS_ADJUD_REASON)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


/****    FORECAST DATA    ****/

V_STEP := ''STEP5'';

V_STEP_NAME :=  ''create a SUB_APPS_SUMM'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table  IDENTIFIER(:V_SUB_APPS_SUMM) COPY GRANTS as
select
	to_date((case when versn = ''v2'' then created_date else creation_date end)) as created_date
	,count(1) as ole_sub_apps
from
	 IDENTIFIER(:V_SUB_APPS_ADJUC_STAT ) a
where
	channel_split = ''DTC - OLE''
and ole_submitted_flg_new = ''Y''
and year(to_date((case when versn = ''v2'' then a.created_date else a.creation_date end))) in (year(current_date),year(current_date)-1)
group by
	to_date((case when versn = ''v2'' then created_date else creation_date end))
;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_SUB_APPS_SUMM)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

V_STEP := ''STEP6'';

V_STEP_NAME :=  ''create a FORECAST_OLE_APPS'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table  IDENTIFIER(:V_FORECAST_OLE_APPS) COPY GRANTS as
select
	a.customer_metric_name
	,a.date
	,sum(a.forecast) as forecast
from
	IDENTIFIER(:V_DOMO_FORECAST_MS_DTC_OLE_START_AND_APPS) a
inner join
	(select
		customer_metric_name
		,channels
		,date
		,max(partition_date) as max_prtn_dt
	 from
		IDENTIFIER(:V_DOMO_FORECAST_MS_DTC_OLE_START_AND_APPS)
	 where
		customer_metric_name = ''MS OLE Apps''
	 group by
		customer_metric_name
		,channels
		,date	
	)b
on
	a.customer_metric_name = a.customer_metric_name
and a.channels = b.channels
and a.date = b.date
and a.partition_date = b.max_prtn_dt
where
	a.customer_metric_name = ''MS OLE Apps''
and year(a.date) in (select distinct year(date) as yr from IDENTIFIER(:V_DOMO_FORECAST_MS_DTC_OLE_START_AND_APPS) order by yr desc limit 2)
group by
	a.customer_metric_name
	,a.date
;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_FORECAST_OLE_APPS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP7'';

V_STEP_NAME :=  ''create a SUB_APPS_SUMM_FORECAST'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table  IDENTIFIER(:V_SUB_APPS_SUMM_FORECAST) COPY GRANTS as
select
	a.*
	,b.ole_sub_apps
from
	 IDENTIFIER(:V_FORECAST_OLE_APPS) a
left join
	 IDENTIFIER(:V_SUB_APPS_SUMM) b
on	a.date = b.created_date
;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_SUB_APPS_SUMM_FORECAST)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);


RAISE;

END;

';