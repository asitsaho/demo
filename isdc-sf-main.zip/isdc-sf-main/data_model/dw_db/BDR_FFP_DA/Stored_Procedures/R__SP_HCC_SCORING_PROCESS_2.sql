USE SCHEMA BDR_FFP_DA;






CREATE OR REPLACE PROCEDURE BDR_FFP_DA.SP_HCC_SCORING_PROCESS_2("PIPELINE_ID" VARCHAR(16777216), "PIPELINE_NAME" VARCHAR(16777216), "DB_NAME" VARCHAR(16777216), "UTIL_SC" VARCHAR(16777216), "TGT_SC" VARCHAR(16777216), "WH" VARCHAR(16777216), "CURR_DATE" DATE)
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

V_CURRENT_DATE DATE := COALESCE(:CURR_DATE, CURRENT_DATE());
V_PART_DEL_DATE VARCHAR := COALESCE(CONCAT(MONTHNAME(ADD_MONTHS(:V_CURRENT_DATE,-3)),substring(to_varchar(year(:V_CURRENT_DATE)),3,2)), ''FILL DEFAULT VALUE'');
V_DATE_ASOF DATE := COALESCE(:V_CURRENT_DATE, CURRENT_DATE());
V_PARTITION_COL VARCHAR := COALESCE(concat(MONTHNAME(:V_CURRENT_DATE),substring(to_varchar(year(:V_CURRENT_DATE)),3,2)), ''FILL DEFAULT VALUE'');
V_EDIT_DATE_ASOF DATE := COALESCE(:V_CURRENT_DATE, CURRENT_DATE());

V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := :DB_NAME||''.''||COALESCE(:UTIL_SC, ''UTIL'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';

V_PROCESS_NAME   VARCHAR DEFAULT ''HCC_SCORING'';

V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''HCC_SCORING_PROCESS_2'';

V_STEP             VARCHAR;

V_STEP_NAME        VARCHAR;

V_START_TIME       VARCHAR;

V_END_TIME         VARCHAR;

V_ROWS_PARSED       INTEGER;

V_ROWS_LOADED       INTEGER;

V_MESSAGE          VARCHAR;

V_LAST_QUERY_ID    VARCHAR;



V_CC_DATA_HICN_WISE VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA_WRK'') || ''.CC_DATA_HICN_WISE'';

V_PERSON_NUPD_V7 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA_WRK'') || ''.PERSON_NUPD_V7'';

V_PERSON_NUPD_V9 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA_WRK'') || ''.PERSON_NUPD_V9'';

V_PERSON_NUPD_V4 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA_WRK'') || ''.PERSON_NUPD_V4'';

V_PERSON_NUPD_V10 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA_WRK'') || ''.PERSON_NUPD_V10'';

V_PERSON_NUPD_V6 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA_WRK'') || ''.PERSON_NUPD_V6'';

V_HCC_ICD1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA_WRK'') || ''.HCC_ICD1'';

V_DIAG_V2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA_WRK'') || ''.DIAG_V2'';

V_DATAFOR_HCC_TEMP VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA_WRK'') || ''.DATAFOR_HCC_TEMP'';

V_PERSON_NUPD_V11 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA_WRK'') || ''.PERSON_NUPD_V11'';

V_PERSON_NUPD_V12 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA_WRK'') || ''.PERSON_NUPD_V12'';

V_DATAFOR_HCC_TEMP_PART VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA_WRK'') || ''.DATAFOR_HCC_TEMP_PART'';

V_INPUT_PERSON_V2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA_WRK'') || ''.INPUT_PERSON_V2'';

V_PERSON_NUPD_AGE VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA_WRK'') || ''.PERSON_NUPD_AGE'';

V_PERSON_NUPD_V3 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA_WRK'') || ''.PERSON_NUPD_V3'';

V_FORMAT_FILE_V2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA_WRK'') || ''.FORMAT_FILE_V2'';

V_PERSON_NUPD_V8 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA_WRK'') || ''.PERSON_NUPD_V8'';

V_PERSON_NUPD_V5 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA_WRK'') || ''.PERSON_NUPD_V5'';

V_DATAFOR_HCC VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA_WRK'') || ''.DATAFOR_HCC'';


BEGIN


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP1'';

V_STEP_NAME :=  ''create a table person_nupd_age'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_PERSON_NUPD_AGE) COPY GRANTS as 
select hicno,dob,
FLOOR(months_between(:V_DATE_ASOF,dob)/12) as agef,
FLOOR(months_between(:V_EDIT_DATE_ASOF,dob)/12) as agef_edit,
sex,mcaid,nemcaid,orec from IDENTIFIER(:V_INPUT_PERSON_V2);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_PERSON_NUPD_AGE)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP2'';

V_STEP_NAME :=  ''create a table diag_v2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());




create or replace table IDENTIFIER(:V_DIAG_V2) COPY GRANTS as
select hicno, diag from IDENTIFIER(:V_HCC_ICD1);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DIAG_V2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP3'';

V_STEP_NAME :=  ''create a table person_nupd_v3'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());




create or replace table IDENTIFIER(:V_PERSON_NUPD_V3) COPY GRANTS as 
select a.hicno,a.dob,a.agef,a.agef_edit,a.sex,a.mcaid,a.nemcaid,a.orec,''AGEL'' as f_agel,''AGEU'' as f_ageu,''IAGEHYBCY19MCE'' as t_agemce,''ISEXHYBCY19MCE'' as t_sexmce,''IAS1012024Y19Y20MC'' as t_ias1012,''IAS2012024Y19Y20MC'' as t_ias2012,''IAS3012024Y19Y20MC'' as t_ias3012,
b.diag,case when b.hicno is not null then 1 else 0 end as per_notin_diag_fg 
from IDENTIFIER(:V_PERSON_NUPD_AGE) a
left join IDENTIFIER(:V_DIAG_V2) b
on a.hicno=b.hicno;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_PERSON_NUPD_V3)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP4'';

V_STEP_NAME :=  ''create a table person_nupd_v4'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


 
 
create or replace table IDENTIFIER(:V_PERSON_NUPD_V4) COPY GRANTS as 
select a.hicno,a.dob,a.agef,a.agef_edit,a.sex,a.mcaid,a.nemcaid,a.orec,a.f_agel,a.f_ageu,a.t_agemce,a.t_sexmce,t_ias1012,a.t_ias2012,a.t_ias3012,a.diag,a.per_notin_diag_fg,
b.label as TAGE,c.label as TSEX
from IDENTIFIER(:V_PERSON_NUPD_V3) a
left join IDENTIFIER(:V_FORMAT_FILE_V2) b
on a.t_agemce=b.fmtname and a.diag=b.`start`
left join IDENTIFIER(:V_FORMAT_FILE_V2) c
on a.t_sexmce=c.fmtname and a.diag=c.`start`;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_PERSON_NUPD_V4)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP5'';

V_STEP_NAME :=  ''create a table person_nupd_v5'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());




create or replace table IDENTIFIER(:V_PERSON_NUPD_V5) COPY GRANTS as 
select a.hicno,a.dob,a.agef,a.agef_edit,a.sex,a.mcaid,a.nemcaid,a.orec,a.f_agel,a.f_ageu,a.t_agemce,a.t_sexmce,t_ias1012,a.t_ias2012,a.t_ias3012,a.diag,a.per_notin_diag_fg,
a.TAGE,a.TSEX,b.label as tnageu,c.label as tnagel
from IDENTIFIER(:V_PERSON_NUPD_V4) a
left join IDENTIFIER(:V_FORMAT_FILE_V2) b
on a.f_ageu=b.fmtname and a.TAGE=b.`start`
left join IDENTIFIER(:V_FORMAT_FILE_V2) c
on a.f_agel=c.fmtname and a.TAGE=c.`start`;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_PERSON_NUPD_V5)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP6'';

V_STEP_NAME :=  ''create a table person_nupd_v6'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());




create or replace table IDENTIFIER(:V_PERSON_NUPD_V6) COPY GRANTS as
select a.hicno,a.dob,a.agef,a.agef_edit,a.sex,a.mcaid,a.nemcaid,a.orec,a.f_agel,a.f_ageu,a.t_agemce,a.t_sexmce,t_ias1012,a.t_ias2012,a.t_ias3012,a.diag,a.per_notin_diag_fg,
a.TAGE,a.TSEX,
case when a.sex=''2'' and a.diag IN (''D66'', ''D67'') then ''48''
when a.agef_edit < 18 and a.diag in (''J410'', ''J411'', ''J418'', ''J42'', ''J430'', ''J431'', ''J432'', ''J438'', ''J439'', ''J440'', ''J441'', ''J449'', ''J982'', ''J983'') then ''112''
when (a.agef_edit < 6 or a.agef_edit > 18) and a.diag=''F3481'' then ''-1.0'' 
when a.TAGE != ''-1'' and (a.agef_edit < CAST(a.tnagel AS INT) or agef_edit > CAST(a.tnageu AS INT)) then ''-1.0''
when a.TSEX != ''-1'' and CAST(a.TSEX AS INT) != sex then ''-1.0''
end as c1c,b.label as c2c,c.label as c3c,d.label as c4c
from IDENTIFIER(:V_PERSON_NUPD_V5) a 
left join IDENTIFIER(:V_FORMAT_FILE_V2) b
on a.t_ias1012=b.fmtname and a.diag=b.`start`
left join IDENTIFIER(:V_FORMAT_FILE_V2) c
on a.t_ias2012=c.fmtname and a.diag=c.`start`
left join IDENTIFIER(:V_FORMAT_FILE_V2) d
on a.t_ias3012=d.fmtname and a.diag=d.`start`;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_PERSON_NUPD_V6)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP7'';

V_STEP_NAME :=  ''create a table person_nupd_v7'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());




create or replace table IDENTIFIER(:V_PERSON_NUPD_V7) COPY GRANTS as 
select hicno,dob,agef,agef_edit,sex,mcaid,nemcaid,orec,f_agel,f_ageu,t_agemce,t_sexmce,t_ias1012,t_ias2012,t_ias3012,diag,per_notin_diag_fg,
TAGE,TSEX,c1c,c2c,c3c,c4c,
case when CAST(c1c AS INT)= 1 or CAST(c2c AS INT)=1 or CAST(c3c AS INT)=1 or CAST(c4c AS INT)=1 then 1 else 0 end as CC1,
case when CAST(c1c AS INT)= 2 or CAST(c2c AS INT)=2 or CAST(c3c AS INT)=2 or CAST(c4c AS INT)=2 then 1 else 0 end as CC2,
case when CAST(c1c AS INT)= 3 or CAST(c2c AS INT)=3 or CAST(c3c AS INT)=3 or CAST(c4c AS INT)=3 then 1 else 0 end as CC3,
case when CAST(c1c AS INT)= 4 or CAST(c2c AS INT)=4 or CAST(c3c AS INT)=4 or CAST(c4c AS INT)=4 then 1 else 0 end as CC4,
case when CAST(c1c AS INT)= 5 or CAST(c2c AS INT)=5 or CAST(c3c AS INT)=5 or CAST(c4c AS INT)=5 then 1 else 0 end as CC5,
case when CAST(c1c AS INT)= 6 or CAST(c2c AS INT)=6 or CAST(c3c AS INT)=6 or CAST(c4c AS INT)=6 then 1 else 0 end as CC6,
case when CAST(c1c AS INT)= 7 or CAST(c2c AS INT)=7 or CAST(c3c AS INT)=7 or CAST(c4c AS INT)=7 then 1 else 0 end as CC7,
case when CAST(c1c AS INT)= 8 or CAST(c2c AS INT)=8 or CAST(c3c AS INT)=8 or CAST(c4c AS INT)=8 then 1 else 0 end as CC8,
case when CAST(c1c AS INT)= 9 or CAST(c2c AS INT)=9 or CAST(c3c AS INT)=9 or CAST(c4c AS INT)=9 then 1 else 0 end as CC9,
case when CAST(c1c AS INT)= 10 or CAST(c2c AS INT)=10 or CAST(c3c AS INT)=10 or CAST(c4c AS INT)=10 then 1 else 0 end as CC10,
case when CAST(c1c AS INT)= 11 or CAST(c2c AS INT)=11 or CAST(c3c AS INT)=11 or CAST(c4c AS INT)=11 then 1 else 0 end as CC11,
case when CAST(c1c AS INT)= 12 or CAST(c2c AS INT)=12 or CAST(c3c AS INT)=12 or CAST(c4c AS INT)=12 then 1 else 0 end as CC12,
case when CAST(c1c AS INT)= 13 or CAST(c2c AS INT)=13 or CAST(c3c AS INT)=13 or CAST(c4c AS INT)=13 then 1 else 0 end as CC13,
case when CAST(c1c AS INT)= 14 or CAST(c2c AS INT)=14 or CAST(c3c AS INT)=14 or CAST(c4c AS INT)=14 then 1 else 0 end as CC14,
case when CAST(c1c AS INT)= 15 or CAST(c2c AS INT)=15 or CAST(c3c AS INT)=15 or CAST(c4c AS INT)=15 then 1 else 0 end as CC15,
case when CAST(c1c AS INT)= 16 or CAST(c2c AS INT)=16 or CAST(c3c AS INT)=16 or CAST(c4c AS INT)=16 then 1 else 0 end as CC16,
case when CAST(c1c AS INT)= 17 or CAST(c2c AS INT)=17 or CAST(c3c AS INT)=17 or CAST(c4c AS INT)=17 then 1 else 0 end as CC17,
case when CAST(c1c AS INT)= 18 or CAST(c2c AS INT)=18 or CAST(c3c AS INT)=18 or CAST(c4c AS INT)=18 then 1 else 0 end as CC18,
case when CAST(c1c AS INT)= 19 or CAST(c2c AS INT)=19 or CAST(c3c AS INT)=19 or CAST(c4c AS INT)=19 then 1 else 0 end as CC19,
case when CAST(c1c AS INT)= 20 or CAST(c2c AS INT)=20 or CAST(c3c AS INT)=20 or CAST(c4c AS INT)=20 then 1 else 0 end as CC20,
case when CAST(c1c AS INT)= 21 or CAST(c2c AS INT)=21 or CAST(c3c AS INT)=21 or CAST(c4c AS INT)=21 then 1 else 0 end as CC21,
case when CAST(c1c AS INT)= 22 or CAST(c2c AS INT)=22 or CAST(c3c AS INT)=22 or CAST(c4c AS INT)=22 then 1 else 0 end as CC22,
case when CAST(c1c AS INT)= 23 or CAST(c2c AS INT)=23 or CAST(c3c AS INT)=23 or CAST(c4c AS INT)=23 then 1 else 0 end as CC23,
case when CAST(c1c AS INT)= 24 or CAST(c2c AS INT)=24 or CAST(c3c AS INT)=24 or CAST(c4c AS INT)=24 then 1 else 0 end as CC24,
case when CAST(c1c AS INT)= 25 or CAST(c2c AS INT)=25 or CAST(c3c AS INT)=25 or CAST(c4c AS INT)=25 then 1 else 0 end as CC25,
case when CAST(c1c AS INT)= 26 or CAST(c2c AS INT)=26 or CAST(c3c AS INT)=26 or CAST(c4c AS INT)=26 then 1 else 0 end as CC26,
case when CAST(c1c AS INT)= 27 or CAST(c2c AS INT)=27 or CAST(c3c AS INT)=27 or CAST(c4c AS INT)=27 then 1 else 0 end as CC27,
case when CAST(c1c AS INT)= 28 or CAST(c2c AS INT)=28 or CAST(c3c AS INT)=28 or CAST(c4c AS INT)=28 then 1 else 0 end as CC28,
case when CAST(c1c AS INT)= 29 or CAST(c2c AS INT)=29 or CAST(c3c AS INT)=29 or CAST(c4c AS INT)=29 then 1 else 0 end as CC29,
case when CAST(c1c AS INT)= 30 or CAST(c2c AS INT)=30 or CAST(c3c AS INT)=30 or CAST(c4c AS INT)=30 then 1 else 0 end as CC30,
case when CAST(c1c AS INT)= 31 or CAST(c2c AS INT)=31 or CAST(c3c AS INT)=31 or CAST(c4c AS INT)=31 then 1 else 0 end as CC31,
case when CAST(c1c AS INT)= 32 or CAST(c2c AS INT)=32 or CAST(c3c AS INT)=32 or CAST(c4c AS INT)=32 then 1 else 0 end as CC32,
case when CAST(c1c AS INT)= 33 or CAST(c2c AS INT)=33 or CAST(c3c AS INT)=33 or CAST(c4c AS INT)=33 then 1 else 0 end as CC33,
case when CAST(c1c AS INT)= 34 or CAST(c2c AS INT)=34 or CAST(c3c AS INT)=34 or CAST(c4c AS INT)=34 then 1 else 0 end as CC34,
case when CAST(c1c AS INT)= 35 or CAST(c2c AS INT)=35 or CAST(c3c AS INT)=35 or CAST(c4c AS INT)=35 then 1 else 0 end as CC35,
case when CAST(c1c AS INT)= 36 or CAST(c2c AS INT)=36 or CAST(c3c AS INT)=36 or CAST(c4c AS INT)=36 then 1 else 0 end as CC36,
case when CAST(c1c AS INT)= 37 or CAST(c2c AS INT)=37 or CAST(c3c AS INT)=37 or CAST(c4c AS INT)=37 then 1 else 0 end as CC37,
case when CAST(c1c AS INT)= 38 or CAST(c2c AS INT)=38 or CAST(c3c AS INT)=38 or CAST(c4c AS INT)=38 then 1 else 0 end as CC38,
case when CAST(c1c AS INT)= 39 or CAST(c2c AS INT)=39 or CAST(c3c AS INT)=39 or CAST(c4c AS INT)=39 then 1 else 0 end as CC39,
case when CAST(c1c AS INT)= 40 or CAST(c2c AS INT)=40 or CAST(c3c AS INT)=40 or CAST(c4c AS INT)=40 then 1 else 0 end as CC40,
case when CAST(c1c AS INT)= 41 or CAST(c2c AS INT)=41 or CAST(c3c AS INT)=41 or CAST(c4c AS INT)=41 then 1 else 0 end as CC41,
case when CAST(c1c AS INT)= 42 or CAST(c2c AS INT)=42 or CAST(c3c AS INT)=42 or CAST(c4c AS INT)=42 then 1 else 0 end as CC42,
case when CAST(c1c AS INT)= 43 or CAST(c2c AS INT)=43 or CAST(c3c AS INT)=43 or CAST(c4c AS INT)=43 then 1 else 0 end as CC43,
case when CAST(c1c AS INT)= 44 or CAST(c2c AS INT)=44 or CAST(c3c AS INT)=44 or CAST(c4c AS INT)=44 then 1 else 0 end as CC44,
case when CAST(c1c AS INT)= 45 or CAST(c2c AS INT)=45 or CAST(c3c AS INT)=45 or CAST(c4c AS INT)=45 then 1 else 0 end as CC45,
case when CAST(c1c AS INT)= 46 or CAST(c2c AS INT)=46 or CAST(c3c AS INT)=46 or CAST(c4c AS INT)=46 then 1 else 0 end as CC46,
case when CAST(c1c AS INT)= 47 or CAST(c2c AS INT)=47 or CAST(c3c AS INT)=47 or CAST(c4c AS INT)=47 then 1 else 0 end as CC47,
case when CAST(c1c AS INT)= 48 or CAST(c2c AS INT)=48 or CAST(c3c AS INT)=48 or CAST(c4c AS INT)=48 then 1 else 0 end as CC48,
case when CAST(c1c AS INT)= 49 or CAST(c2c AS INT)=49 or CAST(c3c AS INT)=49 or CAST(c4c AS INT)=49 then 1 else 0 end as CC49,
case when CAST(c1c AS INT)= 50 or CAST(c2c AS INT)=50 or CAST(c3c AS INT)=50 or CAST(c4c AS INT)=50 then 1 else 0 end as CC50,
case when CAST(c1c AS INT)= 51 or CAST(c2c AS INT)=51 or CAST(c3c AS INT)=51 or CAST(c4c AS INT)=51 then 1 else 0 end as CC51,
case when CAST(c1c AS INT)= 52 or CAST(c2c AS INT)=52 or CAST(c3c AS INT)=52 or CAST(c4c AS INT)=52 then 1 else 0 end as CC52,
case when CAST(c1c AS INT)= 53 or CAST(c2c AS INT)=53 or CAST(c3c AS INT)=53 or CAST(c4c AS INT)=53 then 1 else 0 end as CC53,
case when CAST(c1c AS INT)= 54 or CAST(c2c AS INT)=54 or CAST(c3c AS INT)=54 or CAST(c4c AS INT)=54 then 1 else 0 end as CC54,
case when CAST(c1c AS INT)= 55 or CAST(c2c AS INT)=55 or CAST(c3c AS INT)=55 or CAST(c4c AS INT)=55 then 1 else 0 end as CC55,
case when CAST(c1c AS INT)= 56 or CAST(c2c AS INT)=56 or CAST(c3c AS INT)=56 or CAST(c4c AS INT)=56 then 1 else 0 end as CC56,
case when CAST(c1c AS INT)= 57 or CAST(c2c AS INT)=57 or CAST(c3c AS INT)=57 or CAST(c4c AS INT)=57 then 1 else 0 end as CC57,
case when CAST(c1c AS INT)= 58 or CAST(c2c AS INT)=58 or CAST(c3c AS INT)=58 or CAST(c4c AS INT)=58 then 1 else 0 end as CC58,
case when CAST(c1c AS INT)= 59 or CAST(c2c AS INT)=59 or CAST(c3c AS INT)=59 or CAST(c4c AS INT)=59 then 1 else 0 end as CC59,
case when CAST(c1c AS INT)= 60 or CAST(c2c AS INT)=60 or CAST(c3c AS INT)=60 or CAST(c4c AS INT)=60 then 1 else 0 end as CC60,
case when CAST(c1c AS INT)= 61 or CAST(c2c AS INT)=61 or CAST(c3c AS INT)=61 or CAST(c4c AS INT)=61 then 1 else 0 end as CC61,
case when CAST(c1c AS INT)= 62 or CAST(c2c AS INT)=62 or CAST(c3c AS INT)=62 or CAST(c4c AS INT)=62 then 1 else 0 end as CC62,
case when CAST(c1c AS INT)= 63 or CAST(c2c AS INT)=63 or CAST(c3c AS INT)=63 or CAST(c4c AS INT)=63 then 1 else 0 end as CC63,
case when CAST(c1c AS INT)= 64 or CAST(c2c AS INT)=64 or CAST(c3c AS INT)=64 or CAST(c4c AS INT)=64 then 1 else 0 end as CC64,
case when CAST(c1c AS INT)= 65 or CAST(c2c AS INT)=65 or CAST(c3c AS INT)=65 or CAST(c4c AS INT)=65 then 1 else 0 end as CC65,
case when CAST(c1c AS INT)= 66 or CAST(c2c AS INT)=66 or CAST(c3c AS INT)=66 or CAST(c4c AS INT)=66 then 1 else 0 end as CC66,
case when CAST(c1c AS INT)= 67 or CAST(c2c AS INT)=67 or CAST(c3c AS INT)=67 or CAST(c4c AS INT)=67 then 1 else 0 end as CC67,
case when CAST(c1c AS INT)= 68 or CAST(c2c AS INT)=68 or CAST(c3c AS INT)=68 or CAST(c4c AS INT)=68 then 1 else 0 end as CC68,
case when CAST(c1c AS INT)= 69 or CAST(c2c AS INT)=69 or CAST(c3c AS INT)=69 or CAST(c4c AS INT)=69 then 1 else 0 end as CC69,
case when CAST(c1c AS INT)= 70 or CAST(c2c AS INT)=70 or CAST(c3c AS INT)=70 or CAST(c4c AS INT)=70 then 1 else 0 end as CC70,
case when CAST(c1c AS INT)= 71 or CAST(c2c AS INT)=71 or CAST(c3c AS INT)=71 or CAST(c4c AS INT)=71 then 1 else 0 end as CC71,
case when CAST(c1c AS INT)= 72 or CAST(c2c AS INT)=72 or CAST(c3c AS INT)=72 or CAST(c4c AS INT)=72 then 1 else 0 end as CC72,
case when CAST(c1c AS INT)= 73 or CAST(c2c AS INT)=73 or CAST(c3c AS INT)=73 or CAST(c4c AS INT)=73 then 1 else 0 end as CC73,
case when CAST(c1c AS INT)= 74 or CAST(c2c AS INT)=74 or CAST(c3c AS INT)=74 or CAST(c4c AS INT)=74 then 1 else 0 end as CC74,
case when CAST(c1c AS INT)= 75 or CAST(c2c AS INT)=75 or CAST(c3c AS INT)=75 or CAST(c4c AS INT)=75 then 1 else 0 end as CC75,
case when CAST(c1c AS INT)= 76 or CAST(c2c AS INT)=76 or CAST(c3c AS INT)=76 or CAST(c4c AS INT)=76 then 1 else 0 end as CC76,
case when CAST(c1c AS INT)= 77 or CAST(c2c AS INT)=77 or CAST(c3c AS INT)=77 or CAST(c4c AS INT)=77 then 1 else 0 end as CC77,
case when CAST(c1c AS INT)= 78 or CAST(c2c AS INT)=78 or CAST(c3c AS INT)=78 or CAST(c4c AS INT)=78 then 1 else 0 end as CC78,
case when CAST(c1c AS INT)= 79 or CAST(c2c AS INT)=79 or CAST(c3c AS INT)=79 or CAST(c4c AS INT)=79 then 1 else 0 end as CC79,
case when CAST(c1c AS INT)= 80 or CAST(c2c AS INT)=80 or CAST(c3c AS INT)=80 or CAST(c4c AS INT)=80 then 1 else 0 end as CC80,
case when CAST(c1c AS INT)= 81 or CAST(c2c AS INT)=81 or CAST(c3c AS INT)=81 or CAST(c4c AS INT)=81 then 1 else 0 end as CC81,
case when CAST(c1c AS INT)= 82 or CAST(c2c AS INT)=82 or CAST(c3c AS INT)=82 or CAST(c4c AS INT)=82 then 1 else 0 end as CC82,
case when CAST(c1c AS INT)= 83 or CAST(c2c AS INT)=83 or CAST(c3c AS INT)=83 or CAST(c4c AS INT)=83 then 1 else 0 end as CC83,
case when CAST(c1c AS INT)= 84 or CAST(c2c AS INT)=84 or CAST(c3c AS INT)=84 or CAST(c4c AS INT)=84 then 1 else 0 end as CC84,
case when CAST(c1c AS INT)= 85 or CAST(c2c AS INT)=85 or CAST(c3c AS INT)=85 or CAST(c4c AS INT)=85 then 1 else 0 end as CC85,
case when CAST(c1c AS INT)= 86 or CAST(c2c AS INT)=86 or CAST(c3c AS INT)=86 or CAST(c4c AS INT)=86 then 1 else 0 end as CC86,
case when CAST(c1c AS INT)= 87 or CAST(c2c AS INT)=87 or CAST(c3c AS INT)=87 or CAST(c4c AS INT)=87 then 1 else 0 end as CC87,
case when CAST(c1c AS INT)= 88 or CAST(c2c AS INT)=88 or CAST(c3c AS INT)=88 or CAST(c4c AS INT)=88 then 1 else 0 end as CC88,
case when CAST(c1c AS INT)= 89 or CAST(c2c AS INT)=89 or CAST(c3c AS INT)=89 or CAST(c4c AS INT)=89 then 1 else 0 end as CC89,
case when CAST(c1c AS INT)= 90 or CAST(c2c AS INT)=90 or CAST(c3c AS INT)=90 or CAST(c4c AS INT)=90 then 1 else 0 end as CC90,
case when CAST(c1c AS INT)= 91 or CAST(c2c AS INT)=91 or CAST(c3c AS INT)=91 or CAST(c4c AS INT)=91 then 1 else 0 end as CC91,
case when CAST(c1c AS INT)= 92 or CAST(c2c AS INT)=92 or CAST(c3c AS INT)=92 or CAST(c4c AS INT)=92 then 1 else 0 end as CC92,
case when CAST(c1c AS INT)= 93 or CAST(c2c AS INT)=93 or CAST(c3c AS INT)=93 or CAST(c4c AS INT)=93 then 1 else 0 end as CC93,
case when CAST(c1c AS INT)= 94 or CAST(c2c AS INT)=94 or CAST(c3c AS INT)=94 or CAST(c4c AS INT)=94 then 1 else 0 end as CC94,
case when CAST(c1c AS INT)= 95 or CAST(c2c AS INT)=95 or CAST(c3c AS INT)=95 or CAST(c4c AS INT)=95 then 1 else 0 end as CC95,
case when CAST(c1c AS INT)= 96 or CAST(c2c AS INT)=96 or CAST(c3c AS INT)=96 or CAST(c4c AS INT)=96 then 1 else 0 end as CC96,
case when CAST(c1c AS INT)= 97 or CAST(c2c AS INT)=97 or CAST(c3c AS INT)=97 or CAST(c4c AS INT)=97 then 1 else 0 end as CC97,
case when CAST(c1c AS INT)= 98 or CAST(c2c AS INT)=98 or CAST(c3c AS INT)=98 or CAST(c4c AS INT)=98 then 1 else 0 end as CC98,
case when CAST(c1c AS INT)= 99 or CAST(c2c AS INT)=99 or CAST(c3c AS INT)=99 or CAST(c4c AS INT)=99 then 1 else 0 end as CC99,
case when CAST(c1c AS INT)= 100 or CAST(c2c AS INT)=100 or CAST(c3c AS INT)=100 or CAST(c4c AS INT)=100 then 1 else 0 end as CC100,
case when CAST(c1c AS INT)= 101 or CAST(c2c AS INT)=101 or CAST(c3c AS INT)=101 or CAST(c4c AS INT)=101 then 1 else 0 end as CC101,
case when CAST(c1c AS INT)= 102 or CAST(c2c AS INT)=102 or CAST(c3c AS INT)=102 or CAST(c4c AS INT)=102 then 1 else 0 end as CC102,
case when CAST(c1c AS INT)= 103 or CAST(c2c AS INT)=103 or CAST(c3c AS INT)=103 or CAST(c4c AS INT)=103 then 1 else 0 end as CC103,
case when CAST(c1c AS INT)= 104 or CAST(c2c AS INT)=104 or CAST(c3c AS INT)=104 or CAST(c4c AS INT)=104 then 1 else 0 end as CC104,
case when CAST(c1c AS INT)= 105 or CAST(c2c AS INT)=105 or CAST(c3c AS INT)=105 or CAST(c4c AS INT)=105 then 1 else 0 end as CC105,
case when CAST(c1c AS INT)= 106 or CAST(c2c AS INT)=106 or CAST(c3c AS INT)=106 or CAST(c4c AS INT)=106 then 1 else 0 end as CC106,
case when CAST(c1c AS INT)= 107 or CAST(c2c AS INT)=107 or CAST(c3c AS INT)=107 or CAST(c4c AS INT)=107 then 1 else 0 end as CC107,
case when CAST(c1c AS INT)= 108 or CAST(c2c AS INT)=108 or CAST(c3c AS INT)=108 or CAST(c4c AS INT)=108 then 1 else 0 end as CC108,
case when CAST(c1c AS INT)= 109 or CAST(c2c AS INT)=109 or CAST(c3c AS INT)=109 or CAST(c4c AS INT)=109 then 1 else 0 end as CC109,
case when CAST(c1c AS INT)= 110 or CAST(c2c AS INT)=110 or CAST(c3c AS INT)=110 or CAST(c4c AS INT)=110 then 1 else 0 end as CC110,
case when CAST(c1c AS INT)= 111 or CAST(c2c AS INT)=111 or CAST(c3c AS INT)=111 or CAST(c4c AS INT)=111 then 1 else 0 end as CC111,
case when CAST(c1c AS INT)= 112 or CAST(c2c AS INT)=112 or CAST(c3c AS INT)=112 or CAST(c4c AS INT)=112 then 1 else 0 end as CC112,
case when CAST(c1c AS INT)= 113 or CAST(c2c AS INT)=113 or CAST(c3c AS INT)=113 or CAST(c4c AS INT)=113 then 1 else 0 end as CC113,
case when CAST(c1c AS INT)= 114 or CAST(c2c AS INT)=114 or CAST(c3c AS INT)=114 or CAST(c4c AS INT)=114 then 1 else 0 end as CC114,
case when CAST(c1c AS INT)= 115 or CAST(c2c AS INT)=115 or CAST(c3c AS INT)=115 or CAST(c4c AS INT)=115 then 1 else 0 end as CC115,
case when CAST(c1c AS INT)= 116 or CAST(c2c AS INT)=116 or CAST(c3c AS INT)=116 or CAST(c4c AS INT)=116 then 1 else 0 end as CC116,
case when CAST(c1c AS INT)= 117 or CAST(c2c AS INT)=117 or CAST(c3c AS INT)=117 or CAST(c4c AS INT)=117 then 1 else 0 end as CC117,
case when CAST(c1c AS INT)= 118 or CAST(c2c AS INT)=118 or CAST(c3c AS INT)=118 or CAST(c4c AS INT)=118 then 1 else 0 end as CC118,
case when CAST(c1c AS INT)= 119 or CAST(c2c AS INT)=119 or CAST(c3c AS INT)=119 or CAST(c4c AS INT)=119 then 1 else 0 end as CC119,
case when CAST(c1c AS INT)= 120 or CAST(c2c AS INT)=120 or CAST(c3c AS INT)=120 or CAST(c4c AS INT)=120 then 1 else 0 end as CC120,
case when CAST(c1c AS INT)= 121 or CAST(c2c AS INT)=121 or CAST(c3c AS INT)=121 or CAST(c4c AS INT)=121 then 1 else 0 end as CC121,
case when CAST(c1c AS INT)= 122 or CAST(c2c AS INT)=122 or CAST(c3c AS INT)=122 or CAST(c4c AS INT)=122 then 1 else 0 end as CC122,
case when CAST(c1c AS INT)= 123 or CAST(c2c AS INT)=123 or CAST(c3c AS INT)=123 or CAST(c4c AS INT)=123 then 1 else 0 end as CC123,
case when CAST(c1c AS INT)= 124 or CAST(c2c AS INT)=124 or CAST(c3c AS INT)=124 or CAST(c4c AS INT)=124 then 1 else 0 end as CC124,
case when CAST(c1c AS INT)= 125 or CAST(c2c AS INT)=125 or CAST(c3c AS INT)=125 or CAST(c4c AS INT)=125 then 1 else 0 end as CC125,
case when CAST(c1c AS INT)= 126 or CAST(c2c AS INT)=126 or CAST(c3c AS INT)=126 or CAST(c4c AS INT)=126 then 1 else 0 end as CC126,
case when CAST(c1c AS INT)= 127 or CAST(c2c AS INT)=127 or CAST(c3c AS INT)=127 or CAST(c4c AS INT)=127 then 1 else 0 end as CC127,
case when CAST(c1c AS INT)= 128 or CAST(c2c AS INT)=128 or CAST(c3c AS INT)=128 or CAST(c4c AS INT)=128 then 1 else 0 end as CC128,
case when CAST(c1c AS INT)= 129 or CAST(c2c AS INT)=129 or CAST(c3c AS INT)=129 or CAST(c4c AS INT)=129 then 1 else 0 end as CC129,
case when CAST(c1c AS INT)= 130 or CAST(c2c AS INT)=130 or CAST(c3c AS INT)=130 or CAST(c4c AS INT)=130 then 1 else 0 end as CC130,
case when CAST(c1c AS INT)= 131 or CAST(c2c AS INT)=131 or CAST(c3c AS INT)=131 or CAST(c4c AS INT)=131 then 1 else 0 end as CC131,
case when CAST(c1c AS INT)= 132 or CAST(c2c AS INT)=132 or CAST(c3c AS INT)=132 or CAST(c4c AS INT)=132 then 1 else 0 end as CC132,
case when CAST(c1c AS INT)= 133 or CAST(c2c AS INT)=133 or CAST(c3c AS INT)=133 or CAST(c4c AS INT)=133 then 1 else 0 end as CC133,
case when CAST(c1c AS INT)= 134 or CAST(c2c AS INT)=134 or CAST(c3c AS INT)=134 or CAST(c4c AS INT)=134 then 1 else 0 end as CC134,
case when CAST(c1c AS INT)= 135 or CAST(c2c AS INT)=135 or CAST(c3c AS INT)=135 or CAST(c4c AS INT)=135 then 1 else 0 end as CC135,
case when CAST(c1c AS INT)= 136 or CAST(c2c AS INT)=136 or CAST(c3c AS INT)=136 or CAST(c4c AS INT)=136 then 1 else 0 end as CC136,
case when CAST(c1c AS INT)= 137 or CAST(c2c AS INT)=137 or CAST(c3c AS INT)=137 or CAST(c4c AS INT)=137 then 1 else 0 end as CC137,
case when CAST(c1c AS INT)= 138 or CAST(c2c AS INT)=138 or CAST(c3c AS INT)=138 or CAST(c4c AS INT)=138 then 1 else 0 end as CC138,
case when CAST(c1c AS INT)= 139 or CAST(c2c AS INT)=139 or CAST(c3c AS INT)=139 or CAST(c4c AS INT)=139 then 1 else 0 end as CC139,
case when CAST(c1c AS INT)= 140 or CAST(c2c AS INT)=140 or CAST(c3c AS INT)=140 or CAST(c4c AS INT)=140 then 1 else 0 end as CC140,
case when CAST(c1c AS INT)= 141 or CAST(c2c AS INT)=141 or CAST(c3c AS INT)=141 or CAST(c4c AS INT)=141 then 1 else 0 end as CC141,
case when CAST(c1c AS INT)= 142 or CAST(c2c AS INT)=142 or CAST(c3c AS INT)=142 or CAST(c4c AS INT)=142 then 1 else 0 end as CC142,
case when CAST(c1c AS INT)= 143 or CAST(c2c AS INT)=143 or CAST(c3c AS INT)=143 or CAST(c4c AS INT)=143 then 1 else 0 end as CC143,
case when CAST(c1c AS INT)= 144 or CAST(c2c AS INT)=144 or CAST(c3c AS INT)=144 or CAST(c4c AS INT)=144 then 1 else 0 end as CC144,
case when CAST(c1c AS INT)= 145 or CAST(c2c AS INT)=145 or CAST(c3c AS INT)=145 or CAST(c4c AS INT)=145 then 1 else 0 end as CC145,
case when CAST(c1c AS INT)= 146 or CAST(c2c AS INT)=146 or CAST(c3c AS INT)=146 or CAST(c4c AS INT)=146 then 1 else 0 end as CC146,
case when CAST(c1c AS INT)= 147 or CAST(c2c AS INT)=147 or CAST(c3c AS INT)=147 or CAST(c4c AS INT)=147 then 1 else 0 end as CC147,
case when CAST(c1c AS INT)= 148 or CAST(c2c AS INT)=148 or CAST(c3c AS INT)=148 or CAST(c4c AS INT)=148 then 1 else 0 end as CC148,
case when CAST(c1c AS INT)= 149 or CAST(c2c AS INT)=149 or CAST(c3c AS INT)=149 or CAST(c4c AS INT)=149 then 1 else 0 end as CC149,
case when CAST(c1c AS INT)= 150 or CAST(c2c AS INT)=150 or CAST(c3c AS INT)=150 or CAST(c4c AS INT)=150 then 1 else 0 end as CC150,
case when CAST(c1c AS INT)= 151 or CAST(c2c AS INT)=151 or CAST(c3c AS INT)=151 or CAST(c4c AS INT)=151 then 1 else 0 end as CC151,
case when CAST(c1c AS INT)= 152 or CAST(c2c AS INT)=152 or CAST(c3c AS INT)=152 or CAST(c4c AS INT)=152 then 1 else 0 end as CC152,
case when CAST(c1c AS INT)= 153 or CAST(c2c AS INT)=153 or CAST(c3c AS INT)=153 or CAST(c4c AS INT)=153 then 1 else 0 end as CC153,
case when CAST(c1c AS INT)= 154 or CAST(c2c AS INT)=154 or CAST(c3c AS INT)=154 or CAST(c4c AS INT)=154 then 1 else 0 end as CC154,
case when CAST(c1c AS INT)= 155 or CAST(c2c AS INT)=155 or CAST(c3c AS INT)=155 or CAST(c4c AS INT)=155 then 1 else 0 end as CC155,
case when CAST(c1c AS INT)= 156 or CAST(c2c AS INT)=156 or CAST(c3c AS INT)=156 or CAST(c4c AS INT)=156 then 1 else 0 end as CC156,
case when CAST(c1c AS INT)= 157 or CAST(c2c AS INT)=157 or CAST(c3c AS INT)=157 or CAST(c4c AS INT)=157 then 1 else 0 end as CC157,
case when CAST(c1c AS INT)= 158 or CAST(c2c AS INT)=158 or CAST(c3c AS INT)=158 or CAST(c4c AS INT)=158 then 1 else 0 end as CC158,
case when CAST(c1c AS INT)= 159 or CAST(c2c AS INT)=159 or CAST(c3c AS INT)=159 or CAST(c4c AS INT)=159 then 1 else 0 end as CC159,
case when CAST(c1c AS INT)= 160 or CAST(c2c AS INT)=160 or CAST(c3c AS INT)=160 or CAST(c4c AS INT)=160 then 1 else 0 end as CC160,
case when CAST(c1c AS INT)= 161 or CAST(c2c AS INT)=161 or CAST(c3c AS INT)=161 or CAST(c4c AS INT)=161 then 1 else 0 end as CC161,
case when CAST(c1c AS INT)= 162 or CAST(c2c AS INT)=162 or CAST(c3c AS INT)=162 or CAST(c4c AS INT)=162 then 1 else 0 end as CC162,
case when CAST(c1c AS INT)= 163 or CAST(c2c AS INT)=163 or CAST(c3c AS INT)=163 or CAST(c4c AS INT)=163 then 1 else 0 end as CC163,
case when CAST(c1c AS INT)= 164 or CAST(c2c AS INT)=164 or CAST(c3c AS INT)=164 or CAST(c4c AS INT)=164 then 1 else 0 end as CC164,
case when CAST(c1c AS INT)= 165 or CAST(c2c AS INT)=165 or CAST(c3c AS INT)=165 or CAST(c4c AS INT)=165 then 1 else 0 end as CC165,
case when CAST(c1c AS INT)= 166 or CAST(c2c AS INT)=166 or CAST(c3c AS INT)=166 or CAST(c4c AS INT)=166 then 1 else 0 end as CC166,
case when CAST(c1c AS INT)= 167 or CAST(c2c AS INT)=167 or CAST(c3c AS INT)=167 or CAST(c4c AS INT)=167 then 1 else 0 end as CC167,
case when CAST(c1c AS INT)= 168 or CAST(c2c AS INT)=168 or CAST(c3c AS INT)=168 or CAST(c4c AS INT)=168 then 1 else 0 end as CC168,
case when CAST(c1c AS INT)= 169 or CAST(c2c AS INT)=169 or CAST(c3c AS INT)=169 or CAST(c4c AS INT)=169 then 1 else 0 end as CC169,
case when CAST(c1c AS INT)= 170 or CAST(c2c AS INT)=170 or CAST(c3c AS INT)=170 or CAST(c4c AS INT)=170 then 1 else 0 end as CC170,
case when CAST(c1c AS INT)= 171 or CAST(c2c AS INT)=171 or CAST(c3c AS INT)=171 or CAST(c4c AS INT)=171 then 1 else 0 end as CC171,
case when CAST(c1c AS INT)= 172 or CAST(c2c AS INT)=172 or CAST(c3c AS INT)=172 or CAST(c4c AS INT)=172 then 1 else 0 end as CC172,
case when CAST(c1c AS INT)= 173 or CAST(c2c AS INT)=173 or CAST(c3c AS INT)=173 or CAST(c4c AS INT)=173 then 1 else 0 end as CC173,
case when CAST(c1c AS INT)= 174 or CAST(c2c AS INT)=174 or CAST(c3c AS INT)=174 or CAST(c4c AS INT)=174 then 1 else 0 end as CC174,
case when CAST(c1c AS INT)= 175 or CAST(c2c AS INT)=175 or CAST(c3c AS INT)=175 or CAST(c4c AS INT)=175 then 1 else 0 end as CC175,
case when CAST(c1c AS INT)= 176 or CAST(c2c AS INT)=176 or CAST(c3c AS INT)=176 or CAST(c4c AS INT)=176 then 1 else 0 end as CC176,
case when CAST(c1c AS INT)= 177 or CAST(c2c AS INT)=177 or CAST(c3c AS INT)=177 or CAST(c4c AS INT)=177 then 1 else 0 end as CC177,
case when CAST(c1c AS INT)= 178 or CAST(c2c AS INT)=178 or CAST(c3c AS INT)=178 or CAST(c4c AS INT)=178 then 1 else 0 end as CC178,
case when CAST(c1c AS INT)= 179 or CAST(c2c AS INT)=179 or CAST(c3c AS INT)=179 or CAST(c4c AS INT)=179 then 1 else 0 end as CC179,
case when CAST(c1c AS INT)= 180 or CAST(c2c AS INT)=180 or CAST(c3c AS INT)=180 or CAST(c4c AS INT)=180 then 1 else 0 end as CC180,
case when CAST(c1c AS INT)= 181 or CAST(c2c AS INT)=181 or CAST(c3c AS INT)=181 or CAST(c4c AS INT)=181 then 1 else 0 end as CC181,
case when CAST(c1c AS INT)= 182 or CAST(c2c AS INT)=182 or CAST(c3c AS INT)=182 or CAST(c4c AS INT)=182 then 1 else 0 end as CC182,
case when CAST(c1c AS INT)= 183 or CAST(c2c AS INT)=183 or CAST(c3c AS INT)=183 or CAST(c4c AS INT)=183 then 1 else 0 end as CC183,
case when CAST(c1c AS INT)= 184 or CAST(c2c AS INT)=184 or CAST(c3c AS INT)=184 or CAST(c4c AS INT)=184 then 1 else 0 end as CC184,
case when CAST(c1c AS INT)= 185 or CAST(c2c AS INT)=185 or CAST(c3c AS INT)=185 or CAST(c4c AS INT)=185 then 1 else 0 end as CC185,
case when CAST(c1c AS INT)= 186 or CAST(c2c AS INT)=186 or CAST(c3c AS INT)=186 or CAST(c4c AS INT)=186 then 1 else 0 end as CC186,
case when CAST(c1c AS INT)= 187 or CAST(c2c AS INT)=187 or CAST(c3c AS INT)=187 or CAST(c4c AS INT)=187 then 1 else 0 end as CC187,
case when CAST(c1c AS INT)= 188 or CAST(c2c AS INT)=188 or CAST(c3c AS INT)=188 or CAST(c4c AS INT)=188 then 1 else 0 end as CC188,
case when CAST(c1c AS INT)= 189 or CAST(c2c AS INT)=189 or CAST(c3c AS INT)=189 or CAST(c4c AS INT)=189 then 1 else 0 end as CC189,
case when CAST(c1c AS INT)= 190 or CAST(c2c AS INT)=190 or CAST(c3c AS INT)=190 or CAST(c4c AS INT)=190 then 1 else 0 end as CC190,
case when CAST(c1c AS INT)= 191 or CAST(c2c AS INT)=191 or CAST(c3c AS INT)=191 or CAST(c4c AS INT)=191 then 1 else 0 end as CC191,
case when CAST(c1c AS INT)= 192 or CAST(c2c AS INT)=192 or CAST(c3c AS INT)=192 or CAST(c4c AS INT)=192 then 1 else 0 end as CC192,
case when CAST(c1c AS INT)= 193 or CAST(c2c AS INT)=193 or CAST(c3c AS INT)=193 or CAST(c4c AS INT)=193 then 1 else 0 end as CC193,
case when CAST(c1c AS INT)= 194 or CAST(c2c AS INT)=194 or CAST(c3c AS INT)=194 or CAST(c4c AS INT)=194 then 1 else 0 end as CC194,
case when CAST(c1c AS INT)= 195 or CAST(c2c AS INT)=195 or CAST(c3c AS INT)=195 or CAST(c4c AS INT)=195 then 1 else 0 end as CC195,
case when CAST(c1c AS INT)= 196 or CAST(c2c AS INT)=196 or CAST(c3c AS INT)=196 or CAST(c4c AS INT)=196 then 1 else 0 end as CC196,
case when CAST(c1c AS INT)= 197 or CAST(c2c AS INT)=197 or CAST(c3c AS INT)=197 or CAST(c4c AS INT)=197 then 1 else 0 end as CC197,
case when CAST(c1c AS INT)= 198 or CAST(c2c AS INT)=198 or CAST(c3c AS INT)=198 or CAST(c4c AS INT)=198 then 1 else 0 end as CC198,
case when CAST(c1c AS INT)= 199 or CAST(c2c AS INT)=199 or CAST(c3c AS INT)=199 or CAST(c4c AS INT)=199 then 1 else 0 end as CC199,
case when CAST(c1c AS INT)= 200 or CAST(c2c AS INT)=200 or CAST(c3c AS INT)=200 or CAST(c4c AS INT)=200 then 1 else 0 end as CC200,
case when CAST(c1c AS INT)= 201 or CAST(c2c AS INT)=201 or CAST(c3c AS INT)=201 or CAST(c4c AS INT)=201 then 1 else 0 end as CC201,
case when CAST(c1c AS INT)= 202 or CAST(c2c AS INT)=202 or CAST(c3c AS INT)=202 or CAST(c4c AS INT)=202 then 1 else 0 end as CC202,
case when CAST(c1c AS INT)= 203 or CAST(c2c AS INT)=203 or CAST(c3c AS INT)=203 or CAST(c4c AS INT)=203 then 1 else 0 end as CC203,
case when CAST(c1c AS INT)= 204 or CAST(c2c AS INT)=204 or CAST(c3c AS INT)=204 or CAST(c4c AS INT)=204 then 1 else 0 end as CC204
from IDENTIFIER(:V_PERSON_NUPD_V6);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_PERSON_NUPD_V7)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP8'';

V_STEP_NAME :=  ''create a table cc_data_hicn_wise'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());



create or replace table IDENTIFIER(:V_CC_DATA_HICN_WISE) COPY GRANTS as 
select hicno,max(per_notin_diag_fg) as per_notin_diag_fg,max(CC1) as CC1,max(CC2) as CC2,max(CC3) as CC3,max(CC4) as CC4,max(CC5) as CC5,max(CC6) as CC6,max(CC7) as CC7,max(CC8) as CC8,max(CC9) as CC9,max(CC10) as CC10,max(CC11) as CC11,max(CC12) as CC12,max(CC13) as CC13,max(CC14) as CC14,max(CC15) as CC15,max(CC16) as CC16,max(CC17) as CC17,max(CC18) as CC18,max(CC19) as CC19,max(CC20) as CC20,max(CC21) as CC21,max(CC22) as CC22,max(CC23) as CC23,max(CC24) as CC24,max(CC25) as CC25,max(CC26) as CC26,max(CC27) as CC27,max(CC28) as CC28,max(CC29) as CC29,max(CC30) as CC30,max(CC31) as CC31,max(CC32) as CC32,max(CC33) as CC33,max(CC34) as CC34,max(CC35) as CC35,max(CC36) as CC36,max(CC37) as CC37,max(CC38) as CC38,max(CC39) as CC39,max(CC40) as CC40,max(CC41) as CC41,max(CC42) as CC42,max(CC43) as CC43,max(CC44) as CC44,max(CC45) as CC45,max(CC46) as CC46,max(CC47) as CC47,max(CC48) as CC48,max(CC49) as CC49,max(CC50) as CC50,max(CC51) as CC51,max(CC52) as CC52,max(CC53) as CC53,max(CC54) as CC54,max(CC55) as CC55,max(CC56) as CC56,max(CC57) as CC57,max(CC58) as CC58,max(CC59) as CC59,max(CC60) as CC60,max(CC61) as CC61,max(CC62) as CC62,max(CC63) as CC63,max(CC64) as CC64,max(CC65) as CC65,max(CC66) as CC66,max(CC67) as CC67,max(CC68) as CC68,max(CC69) as CC69,max(CC70) as CC70,max(CC71) as CC71,max(CC72) as CC72,max(CC73) as CC73,max(CC74) as CC74,max(CC75) as CC75,max(CC76) as CC76,max(CC77) as CC77,max(CC78) as CC78,max(CC79) as CC79,max(CC80) as CC80,max(CC81) as CC81,max(CC82) as CC82,max(CC83) as CC83,max(CC84) as CC84,max(CC85) as CC85,max(CC86) as CC86,max(CC87) as CC87,max(CC88) as CC88,max(CC89) as CC89,max(CC90) as CC90,max(CC91) as CC91,max(CC92) as CC92,max(CC93) as CC93,max(CC94) as CC94,max(CC95) as CC95,max(CC96) as CC96,max(CC97) as CC97,max(CC98) as CC98,max(CC99) as CC99,max(CC100) as CC100,max(CC101) as CC101,max(CC102) as CC102,max(CC103) as CC103,max(CC104) as CC104,max(CC105) as CC105,max(CC106) as CC106,max(CC107) as CC107,max(CC108) as CC108,max(CC109) as CC109,max(CC110) as CC110,max(CC111) as CC111,max(CC112) as CC112,max(CC113) as CC113,max(CC114) as CC114,max(CC115) as CC115,max(CC116) as CC116,max(CC117) as CC117,max(CC118) as CC118,max(CC119) as CC119,max(CC120) as CC120,max(CC121) as CC121,max(CC122) as CC122,max(CC123) as CC123,max(CC124) as CC124,max(CC125) as CC125,max(CC126) as CC126,max(CC127) as CC127,max(CC128) as CC128,max(CC129) as CC129,max(CC130) as CC130,max(CC131) as CC131,max(CC132) as CC132,max(CC133) as CC133,max(CC134) as CC134,max(CC135) as CC135,max(CC136) as CC136,max(CC137) as CC137,max(CC138) as CC138,max(CC139) as CC139,max(CC140) as CC140,max(CC141) as CC141,max(CC142) as CC142,max(CC143) as CC143,max(CC144) as CC144,max(CC145) as CC145,max(CC146) as CC146,max(CC147) as CC147,max(CC148) as CC148,max(CC149) as CC149,max(CC150) as CC150,max(CC151) as CC151,max(CC152) as CC152,max(CC153) as CC153,max(CC154) as CC154,max(CC155) as CC155,max(CC156) as CC156,max(CC157) as CC157,max(CC158) as CC158,max(CC159) as CC159,max(CC160) as CC160,max(CC161) as CC161,max(CC162) as CC162,max(CC163) as CC163,max(CC164) as CC164,max(CC165) as CC165,max(CC166) as CC166,max(CC167) as CC167,max(CC168) as CC168,max(CC169) as CC169,max(CC170) as CC170,max(CC171) as CC171,max(CC172) as CC172,max(CC173) as CC173,max(CC174) as CC174,max(CC175) as CC175,max(CC176) as CC176,max(CC177) as CC177,max(CC178) as CC178,max(CC179) as CC179,max(CC180) as CC180,max(CC181) as CC181,max(CC182) as CC182,max(CC183) as CC183,max(CC184) as CC184,max(CC185) as CC185,max(CC186) as CC186,max(CC187) as CC187,max(CC188) as CC188,max(CC189) as CC189,max(CC190) as CC190,max(CC191) as CC191,max(CC192) as CC192,max(CC193) as CC193,max(CC194) as CC194,max(CC195) as CC195,max(CC196) as CC196,max(CC197) as CC197,max(CC198) as CC198,max(CC199) as CC199,max(CC200) as CC200,max(CC201) as CC201,max(CC202) as CC202,max(CC203) as CC203,max(CC204) as CC204
from IDENTIFIER(:V_PERSON_NUPD_V7) group by hicno;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_CC_DATA_HICN_WISE)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP9'';

V_STEP_NAME :=  ''create a table person_nupd_v8'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());




create or replace table IDENTIFIER(:V_PERSON_NUPD_V8) COPY GRANTS as 
select a.hicno,a.dob,a.agef,a.agef_edit,a.sex,a.mcaid,a.nemcaid,a.orec,b.CC1,b.CC2,b.CC3,b.CC4,b.CC5,b.CC6,b.CC7,b.CC8,b.CC9,b.CC10,b.CC11,b.CC12,b.CC13,b.CC14,b.CC15,b.CC16,b.CC17,b.CC18,b.CC19,b.CC20,b.CC21,b.CC22,b.CC23,b.CC24,b.CC25,b.CC26,b.CC27,b.CC28,b.CC29,b.CC30,b.CC31,b.CC32,b.CC33,b.CC34,b.CC35,b.CC36,b.CC37,b.CC38,b.CC39,b.CC40,b.CC41,b.CC42,b.CC43,b.CC44,b.CC45,b.CC46,b.CC47,b.CC48,b.CC49,b.CC50,b.CC51,b.CC52,b.CC53,b.CC54,b.CC55,b.CC56,b.CC57,b.CC58,b.CC59,b.CC60,b.CC61,b.CC62,b.CC63,b.CC64,b.CC65,b.CC66,b.CC67,b.CC68,b.CC69,b.CC70,b.CC71,b.CC72,b.CC73,b.CC74,b.CC75,b.CC76,b.CC77,b.CC78,b.CC79,b.CC80,b.CC81,b.CC82,b.CC83,b.CC84,b.CC85,b.CC86,b.CC87,b.CC88,b.CC89,b.CC90,b.CC91,b.CC92,b.CC93,b.CC94,b.CC95,b.CC96,b.CC97,b.CC98,b.CC99,b.CC100,b.CC101,b.CC102,b.CC103,b.CC104,b.CC105,b.CC106,b.CC107,b.CC108,b.CC109,b.CC110,b.CC111,b.CC112,b.CC113,b.CC114,b.CC115,b.CC116,b.CC117,b.CC118,b.CC119,b.CC120,b.CC121,b.CC122,b.CC123,b.CC124,b.CC125,b.CC126,b.CC127,b.CC128,b.CC129,b.CC130,b.CC131,b.CC132,b.CC133,b.CC134,b.CC135,b.CC136,b.CC137,b.CC138,b.CC139,b.CC140,b.CC141,b.CC142,b.CC143,b.CC144,b.CC145,b.CC146,b.CC147,b.CC148,b.CC149,b.CC150,b.CC151,b.CC152,b.CC153,b.CC154,b.CC155,b.CC156,b.CC157,b.CC158,b.CC159,b.CC160,b.CC161,b.CC162,b.CC163,b.CC164,b.CC165,b.CC166,b.CC167,b.CC168,b.CC169,b.CC170,b.CC171,b.CC172,b.CC173,b.CC174,b.CC175,b.CC176,b.CC177,b.CC178,b.CC179,b.CC180,b.CC181,b.CC182,b.CC183,b.CC184,b.CC185,b.CC186,b.CC187,b.CC188,b.CC189,b.CC190,b.CC191,b.CC192,b.CC193,b.CC194,b.CC195,b.CC196,b.CC197,b.CC198,b.CC199,b.CC200,b.CC201,b.CC202,b.CC203,b.CC204,b.per_notin_diag_fg,
case when a.agef < 65 and a.orec !=0 then 1 else 0 end as disabl
from IDENTIFIER(:V_PERSON_NUPD_AGE) a
left join IDENTIFIER(:V_CC_DATA_HICN_WISE) b
on a.hicno=b.hicno;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_PERSON_NUPD_V8)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP10'';

V_STEP_NAME :=  ''create a table person_nupd_v9'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());




create or replace table IDENTIFIER(:V_PERSON_NUPD_V9) COPY GRANTS as
select hicno,per_notin_diag_fg,dob,sex,mcaid,nemcaid,orec,cc1,cc2,cc3,cc4,cc5,cc6,cc7,cc8,cc9,cc10,cc11,cc12,cc13,cc14,cc15,cc16,cc17,cc18,cc19,cc20,cc21,cc22,cc23,cc24,cc25,cc26,cc27,cc28,cc29,cc30,cc31,cc32,cc33,cc34,cc35,cc36,cc37,cc38,cc39,cc40,cc41,cc42,cc43,cc44,cc45,cc46,cc47,cc48,cc49,cc50,cc51,cc52,cc53,cc54,cc55,cc56,cc57,cc58,cc59,cc60,cc61,cc62,cc63,cc64,cc65,cc66,cc67,cc68,cc69,cc70,cc71,cc72,cc73,cc74,cc75,cc76,cc77,cc78,cc79,cc80,cc81,cc82,cc83,cc84,cc85,cc86,cc87,cc88,cc89,cc90,cc91,cc92,cc93,cc94,cc95,cc96,cc97,cc98,cc99,cc100,cc101,cc102,cc103,cc104,cc105,cc106,cc107,cc108,cc109,cc110,cc111,cc112,cc113,cc114,cc115,cc116,cc117,cc118,cc119,cc120,cc121,cc122,cc123,cc124,cc125,cc126,cc127,cc128,cc129,cc130,cc131,cc132,cc133,cc134,cc135,cc136,cc137,cc138,cc139,cc140,cc141,cc142,cc143,cc144,cc145,cc146,cc147,cc148,cc149,cc150,cc151,cc152,cc153,cc154,cc155,cc156,cc157,cc158,cc159,cc160,cc161,cc162,cc163,cc164,cc165,cc166,cc167,cc168,cc169,cc170,cc171,cc172,cc173,cc174,cc175,cc176,cc177,cc178,cc179,cc180,cc181,cc182,cc183,cc184,cc185,cc186,cc187,cc188,cc189,cc190,cc191,cc192,cc193,cc194,cc195,cc196,cc197,cc198,cc199,cc200,cc201,cc202,cc203,cc204,agef,agef_edit,disabl,
case when orec=1 and disabl=0 then 1 else 0 end as origds,
case 
when sex=2 and (0 <= agef and agef <= 34) then 1
else 0 end as F0_34,
case 
when sex=2 and (34 < agef and agef <= 44) then 1
else 0 end as F35_44,
case 
when sex=2 and (44 < agef and agef <= 54) then 1
else 0 end as F45_54,
case 
when sex=2 and (54 < agef and agef <= 59) then 1
else 0 end as F55_59,
case 
when sex=2 and (59 < agef and agef <= 64) then 1
else 0 end as F60_64,
case 
when sex=2 and (64 < agef and agef <= 69) then 1
else 0 end as F65_69,
case 
when sex=2 and (69 < agef and agef <= 74) then 1
else 0 end as F70_74,
case 
when sex=2 and (74 < agef and agef <= 79) then 1
else 0 end as F75_79,
case 
when sex=2 and (79 < agef and agef <= 84) then 1
else 0 end as F80_84, 
case 
when sex=2 and (84 < agef and agef <= 89) then 1
else 0 end as F85_89,
case 
when sex=2 and (89 < agef and agef <= 94) then 1
else 0 end as F90_94,
case 
when sex=2 and (94 < agef) then 1
else 0 end as F95_GT,
case 
when sex=1 and (0 <= agef and agef <= 34) then 1
else 0 end as M0_34,
case 
when sex=1 and (34 < agef and agef <= 44) then 1
else 0 end as M35_44,
case 
when sex=1 and (44 < agef and agef <= 54) then 1
else 0 end as M45_54,
case 
when sex=1 and (54 < agef and agef <= 59) then 1
else 0 end as M55_59,
case 
when sex=1 and (59 < agef and agef <= 64) then 1
else 0 end as M60_64,
case 
when sex=1 and (64 < agef and agef <= 69) then 1
else 0 end as M65_69,
case 
when sex=1 and (69 < agef and agef <= 74) then 1
else 0 end as M70_74,
case 
when sex=1 and (74 < agef and agef <= 79) then 1
else 0 end as M75_79,
case 
when sex=1 and (79 < agef and agef <= 84) then 1
else 0 end as M80_84, 
case 
when sex=1 and (84 < agef and agef <= 89) then 1
else 0 end as M85_89,
case 
when sex=1 and (89 < agef and agef <= 94) then 1
else 0 end as M90_94,
case 
when sex=1 and (94 < agef) then 1
else 0 end as M95_GT,
case 
when sex=2 and (0 <= agef and agef <= 34) then 1
else 0 end as NEF0_34,
case 
when sex=2 and (34 < agef and agef <= 44) then 1    
else 0 end as NEF35_44,
case 
when sex=2 and (44 < agef and agef <= 54) then 1
else 0 end as NEF45_54,
case 
when sex=2 and (54 < agef and agef <= 59) then 1
else 0 end as NEF55_59,
case 
when (sex=2 and (59 < agef and agef <= 63)) or (sex=2 and (agef=64 and orec!=0)) then 1
else 0 end as NEF60_64,
case 
when (sex=2 and (agef=64 and orec=0)) or (sex=2 and agef=65) then 1
else 0 end as NEF65,
case when SEX=2 and agef=66 then 1 else 0 end as NEF66, 
case when SEX=2 and agef=67 then 1 else 0 end as NEF67, 
case when SEX=2 and agef=68 then 1 else 0 end as NEF68, 
case when SEX=2 and agef=69 then 1 else 0 end as NEF69, 
case
when sex=2 and (69 < agef and agef <= 74) then 1
else 0 end as NEF70_74,
case 
when sex=2 and (74 < agef and agef <= 79) then 1
else 0 end as NEF75_79,
case 
when sex=2 and (79 < agef and agef <= 84) then 1
else 0 end as NEF80_84, 
case 
when sex=2 and (84 < agef and agef <= 89) then 1
else 0 end as NEF85_89,
case 
when sex=2 and (89 < agef and agef <= 94) then 1
else 0 end as NEF90_94,
case 
when sex=2 and (94 < agef) then 1
else 0 end as NEF95_GT,
case 
when sex=1 and (0 <= agef and agef <= 34) then 1
else 0 end as NEM0_34,
case 
when sex=1 and (34 < agef and agef <= 44) then 1    
else 0 end as NEM35_44,
case 
when sex=1 and (44 < agef and agef <= 54) then 1
else 0 end as NEM45_54,
case 
when sex=1 and (54 < agef and agef <= 59) then 1
else 0 end as NEM55_59,
case 
when (sex=1 and (59 < agef and agef <= 63)) or (sex=1 and (agef=64 and orec!=0)) then 1
else 0 end as NEM60_64,
case 
when (sex=1 and (agef=64 and orec=0)) or (sex=1 and agef=65) then 1
else 0 end as NEM65,
case when sex=1 and agef=66 then 1 else 0 end as NEM66, 
case when sex=1 and agef=67 then 1 else 0 end as NEM67, 
case when sex=1 and agef=68 then 1 else 0 end as NEM68, 
case when sex=1 and agef=69 then 1 else 0 end as NEM69, 
case
when sex=1 and (69 < agef and agef <= 74) then 1
else 0 end as NEM70_74,
case 
when sex=1 and (74 < agef and agef <= 79) then 1
else 0 end as NEM75_79,
case 
when sex=1 and (79 < agef and agef <= 84) then 1
else 0 end as NEM80_84, 
case 
when sex=1 and (84 < agef and agef <= 89) then 1
else 0 end as NEM85_89,
case 
when sex=1 and (89 < agef and agef <= 94) then 1
else 0 end as NEM90_94,
case 
when sex=1 and (94 < agef) then 1
else 0 end as NEM95_GT
from IDENTIFIER(:V_PERSON_NUPD_V8);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_PERSON_NUPD_V9)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP11'';

V_STEP_NAME :=  ''create a table person_nupd_v10'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());




create or replace table IDENTIFIER(:V_PERSON_NUPD_V10) COPY GRANTS as 
select a.*, 
case when origds=1 and sex=2 then 1 else 0 end as OriginallyDisabled_Female,
case when origds=1 and sex=1 then 1 else 0 end as OriginallyDisabled_Male,
case when agef >= 65 and orec=1 then 1 else 0 end as NE_ORIGDS
from IDENTIFIER(:V_PERSON_NUPD_V9) a;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_PERSON_NUPD_V10)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP12'';

V_STEP_NAME :=  ''create a table person_nupd_v11'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());




create or replace table IDENTIFIER(:V_PERSON_NUPD_V11) COPY GRANTS as 
select a.*, 
case when NEMCAID <=0 and NE_ORIGDS <=0 then 1 else 0 end as NMCAID_NORIGDIS, 
case when NEMCAID > 0 and NE_ORIGDS <=0 then 1 else 0 end as MCAID_NORIGDIS,
case when NEMCAID <=0 and NE_ORIGDS > 0 then 1 else 0 end as NMCAID_ORIGDIS,
case when NEMCAID > 0 and NE_ORIGDS > 0 then 1 else 0 end as MCAID_ORIGDIS
from IDENTIFIER(:V_PERSON_NUPD_V10) a;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_PERSON_NUPD_V11)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP13'';

V_STEP_NAME :=  ''create a table person_nupd_v12'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());




create or replace table IDENTIFIER(:V_PERSON_NUPD_V12) COPY GRANTS as 
select a.*, 
NMCAID_NORIGDIS * NEF0_34 as NMCAID_NORIGDIS_NEF0_34 ,
NMCAID_NORIGDIS * NEF35_44 as NMCAID_NORIGDIS_NEF35_44,
NMCAID_NORIGDIS * NEF45_54 as NMCAID_NORIGDIS_NEF45_54,
NMCAID_NORIGDIS * NEF55_59 as NMCAID_NORIGDIS_NEF55_59,
NMCAID_NORIGDIS * NEF60_64 as NMCAID_NORIGDIS_NEF60_64,
NMCAID_NORIGDIS * NEF65 as NMCAID_NORIGDIS_NEF65,
NMCAID_NORIGDIS * NEF66 as NMCAID_NORIGDIS_NEF66,
NMCAID_NORIGDIS * NEF67 as NMCAID_NORIGDIS_NEF67 ,
NMCAID_NORIGDIS * NEF68 as NMCAID_NORIGDIS_NEF68,
NMCAID_NORIGDIS * NEF69 as NMCAID_NORIGDIS_NEF69 ,
NMCAID_NORIGDIS * NEF70_74 as NMCAID_NORIGDIS_NEF70_74,
NMCAID_NORIGDIS * NEF75_79 as NMCAID_NORIGDIS_NEF75_79,
NMCAID_NORIGDIS * NEF80_84 as NMCAID_NORIGDIS_NEF80_84 ,
NMCAID_NORIGDIS * NEF85_89 as NMCAID_NORIGDIS_NEF85_89,
NMCAID_NORIGDIS * NEF90_94 as NMCAID_NORIGDIS_NEF90_94,
NMCAID_NORIGDIS * NEF95_GT as NMCAID_NORIGDIS_NEF95_GT,
NMCAID_NORIGDIS * NEM0_34 as NMCAID_NORIGDIS_NEM0_34,
NMCAID_NORIGDIS * NEM35_44 as NMCAID_NORIGDIS_NEM35_44,
NMCAID_NORIGDIS * NEM45_54 as NMCAID_NORIGDIS_NEM45_54,
NMCAID_NORIGDIS * NEM55_59 as NMCAID_NORIGDIS_NEM55_59 ,
NMCAID_NORIGDIS * NEM60_64 as NMCAID_NORIGDIS_NEM60_64,
NMCAID_NORIGDIS * NEM65 as NMCAID_NORIGDIS_NEM65,
NMCAID_NORIGDIS * NEM66 as NMCAID_NORIGDIS_NEM66 ,
NMCAID_NORIGDIS * NEM67 as NMCAID_NORIGDIS_NEM67,
NMCAID_NORIGDIS * NEM68 as NMCAID_NORIGDIS_NEM68,
NMCAID_NORIGDIS * NEM69 as NMCAID_NORIGDIS_NEM69,
NMCAID_NORIGDIS * NEM70_74 as NMCAID_NORIGDIS_NEM70_74,
NMCAID_NORIGDIS * NEM75_79 as NMCAID_NORIGDIS_NEM75_79,
NMCAID_NORIGDIS * NEM80_84 as NMCAID_NORIGDIS_NEM80_84,
NMCAID_NORIGDIS * NEM85_89 as NMCAID_NORIGDIS_NEM85_89,
NMCAID_NORIGDIS * NEM90_94 as NMCAID_NORIGDIS_NEM90_94,
NMCAID_NORIGDIS * NEM95_GT as NMCAID_NORIGDIS_NEM95_GT,
MCAID_NORIGDIS * NEF0_34 as MCAID_NORIGDIS_NEF0_34,
MCAID_NORIGDIS * NEF35_44 as MCAID_NORIGDIS_NEF35_44,
MCAID_NORIGDIS * NEF45_54 as MCAID_NORIGDIS_NEF45_54,
MCAID_NORIGDIS * NEF55_59 as MCAID_NORIGDIS_NEF55_59,
MCAID_NORIGDIS * NEF60_64 as MCAID_NORIGDIS_NEF60_64,
MCAID_NORIGDIS * NEF65 as MCAID_NORIGDIS_NEF65,
MCAID_NORIGDIS * NEF66 as MCAID_NORIGDIS_NEF66,
MCAID_NORIGDIS * NEF67 as MCAID_NORIGDIS_NEF67,
MCAID_NORIGDIS * NEF68 as MCAID_NORIGDIS_NEF68,
MCAID_NORIGDIS * NEF69 as MCAID_NORIGDIS_NEF69,
MCAID_NORIGDIS * NEF70_74 as MCAID_NORIGDIS_NEF70_74,
MCAID_NORIGDIS * NEF75_79 as MCAID_NORIGDIS_NEF75_79,
MCAID_NORIGDIS * NEF80_84 as MCAID_NORIGDIS_NEF80_84,
MCAID_NORIGDIS * NEF85_89 as MCAID_NORIGDIS_NEF85_89,
MCAID_NORIGDIS * NEF90_94 as MCAID_NORIGDIS_NEF90_94,
MCAID_NORIGDIS * NEF95_GT as MCAID_NORIGDIS_NEF95_GT,
MCAID_NORIGDIS * NEM0_34 as MCAID_NORIGDIS_NEM0_34,
MCAID_NORIGDIS * NEM35_44 as MCAID_NORIGDIS_NEM35_44,
MCAID_NORIGDIS * NEM45_54 as MCAID_NORIGDIS_NEM45_54,
MCAID_NORIGDIS * NEM55_59 as MCAID_NORIGDIS_NEM55_59,
MCAID_NORIGDIS * NEM60_64 as MCAID_NORIGDIS_NEM60_64,
MCAID_NORIGDIS * NEM65 as MCAID_NORIGDIS_NEM65,
MCAID_NORIGDIS * NEM66 as MCAID_NORIGDIS_NEM66,
MCAID_NORIGDIS * NEM67 as MCAID_NORIGDIS_NEM67,
MCAID_NORIGDIS * NEM68 as MCAID_NORIGDIS_NEM68,
MCAID_NORIGDIS * NEM69 as MCAID_NORIGDIS_NEM69,
MCAID_NORIGDIS * NEM70_74 as MCAID_NORIGDIS_NEM70_74,
MCAID_NORIGDIS * NEM75_79 as MCAID_NORIGDIS_NEM75_79,
MCAID_NORIGDIS * NEM80_84 as MCAID_NORIGDIS_NEM80_84,
MCAID_NORIGDIS * NEM85_89 as MCAID_NORIGDIS_NEM85_89,
MCAID_NORIGDIS * NEM90_94 as MCAID_NORIGDIS_NEM90_94,
MCAID_NORIGDIS * NEM95_GT as MCAID_NORIGDIS_NEM95_GT,
NMCAID_ORIGDIS * NEF65 as NMCAID_ORIGDIS_NEF65,
NMCAID_ORIGDIS * NEF66 as NMCAID_ORIGDIS_NEF66,
NMCAID_ORIGDIS * NEF67 as NMCAID_ORIGDIS_NEF67,
NMCAID_ORIGDIS * NEF68 as NMCAID_ORIGDIS_NEF68,
NMCAID_ORIGDIS * NEF69 as NMCAID_ORIGDIS_NEF69,
NMCAID_ORIGDIS * NEF70_74 as NMCAID_ORIGDIS_NEF70_74,
NMCAID_ORIGDIS * NEF75_79 as NMCAID_ORIGDIS_NEF75_79,
NMCAID_ORIGDIS * NEF80_84 as NMCAID_ORIGDIS_NEF80_84,
NMCAID_ORIGDIS * NEF85_89 as NMCAID_ORIGDIS_NEF85_89,
NMCAID_ORIGDIS * NEF90_94 as NMCAID_ORIGDIS_NEF90_94,
NMCAID_ORIGDIS * NEF95_GT as NMCAID_ORIGDIS_NEF95_GT,
NMCAID_ORIGDIS * NEM65 as NMCAID_ORIGDIS_NEM65,
NMCAID_ORIGDIS * NEM66 as NMCAID_ORIGDIS_NEM66,
NMCAID_ORIGDIS * NEM67 as NMCAID_ORIGDIS_NEM67,
NMCAID_ORIGDIS * NEM68 as NMCAID_ORIGDIS_NEM68,
NMCAID_ORIGDIS * NEM69 as NMCAID_ORIGDIS_NEM69,
NMCAID_ORIGDIS * NEM70_74 as NMCAID_ORIGDIS_NEM70_74,
NMCAID_ORIGDIS * NEM75_79 as NMCAID_ORIGDIS_NEM75_79,
NMCAID_ORIGDIS * NEM80_84 as NMCAID_ORIGDIS_NEM80_84,
NMCAID_ORIGDIS * NEM85_89 as NMCAID_ORIGDIS_NEM85_89 ,
NMCAID_ORIGDIS * NEM90_94 as NMCAID_ORIGDIS_NEM90_94,
NMCAID_ORIGDIS * NEM95_GT as NMCAID_ORIGDIS_NEM95_GT,
MCAID_ORIGDIS * NEF65 as MCAID_ORIGDIS_NEF65,
MCAID_ORIGDIS * NEF66 as MCAID_ORIGDIS_NEF66,
MCAID_ORIGDIS * NEF67 as MCAID_ORIGDIS_NEF67,
MCAID_ORIGDIS * NEF68 as MCAID_ORIGDIS_NEF68,
MCAID_ORIGDIS * NEF69 as MCAID_ORIGDIS_NEF69,
MCAID_ORIGDIS * NEF70_74 as MCAID_ORIGDIS_NEF70_74,
MCAID_ORIGDIS * NEF75_79 as MCAID_ORIGDIS_NEF75_79 ,
MCAID_ORIGDIS * NEF80_84 as MCAID_ORIGDIS_NEF80_84,
MCAID_ORIGDIS * NEF85_89 as MCAID_ORIGDIS_NEF85_89,
MCAID_ORIGDIS * NEF90_94 as MCAID_ORIGDIS_NEF90_94,
MCAID_ORIGDIS * NEF95_GT as MCAID_ORIGDIS_NEF95_GT,
MCAID_ORIGDIS * NEM65 as MCAID_ORIGDIS_NEM65 ,
MCAID_ORIGDIS * NEM66 as MCAID_ORIGDIS_NEM66,
MCAID_ORIGDIS * NEM67 as MCAID_ORIGDIS_NEM67 ,
MCAID_ORIGDIS * NEM68 as MCAID_ORIGDIS_NEM68 ,
MCAID_ORIGDIS * NEM69 as MCAID_ORIGDIS_NEM69,
MCAID_ORIGDIS * NEM70_74 as MCAID_ORIGDIS_NEM70_74,
MCAID_ORIGDIS * NEM75_79 as MCAID_ORIGDIS_NEM75_79,
MCAID_ORIGDIS * NEM80_84 as MCAID_ORIGDIS_NEM80_84,
MCAID_ORIGDIS * NEM85_89 as MCAID_ORIGDIS_NEM85_89,
MCAID_ORIGDIS * NEM90_94 as MCAID_ORIGDIS_NEM90_94,
MCAID_ORIGDIS * NEM95_GT as MCAID_ORIGDIS_NEM95_GT
from IDENTIFIER(:V_PERSON_NUPD_V11) a;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_PERSON_NUPD_V12)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP14'';

V_STEP_NAME :=  ''create a table datafor_hcc_temp'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_DATAFOR_HCC_TEMP) COPY GRANTS as 
select hicno,per_notin_diag_fg,disabl,cc1,cc2,cc3,cc4,cc5,cc6,cc7,cc8,cc9,cc10,cc11,cc12,cc13,cc14,cc15,cc16,cc17,cc18,cc19,cc20,cc21,cc22,cc23,cc24,cc25,cc26,cc27,cc28,cc29,cc30,cc31,cc32,cc33,cc34,cc35,cc36,cc37,cc38,cc39,cc40,cc41,cc42,cc43,cc44,cc45,cc46,cc47,cc48,cc49,cc50,cc51,cc52,cc53,cc54,cc55,cc56,cc57,cc58,cc59,cc60,cc61,cc62,cc63,cc64,cc65,cc66,cc67,cc68,cc69,cc70,cc71,cc72,cc73,cc74,cc75,cc76,cc77,cc78,cc79,cc80,cc81,cc82,cc83,cc84,cc85,cc86,cc87,cc88,cc89,cc90,cc91,cc92,cc93,cc94,cc95,cc96,cc97,cc98,cc99,cc100,cc101,cc102,cc103,cc104,cc105,cc106,cc107,cc108,cc109,cc110,cc111,cc112,cc113,cc114,cc115,cc116,cc117,cc118,cc119,cc120,cc121,cc122,cc123,cc124,cc125,cc126,cc127,cc128,cc129,cc130,cc131,cc132,cc133,cc134,cc135,cc136,cc137,cc138,cc139,cc140,cc141,cc142,cc143,cc144,cc145,cc146,cc147,cc148,cc149,cc150,cc151,cc152,cc153,cc154,cc155,cc156,cc157,cc158,cc159,cc160,cc161,cc162,cc163,cc164,cc165,cc166,cc167,cc168,cc169,cc170,cc171,cc172,cc173,cc174,cc175,cc176,cc177,cc178,cc179,cc180,cc181,cc182,cc183,cc184,cc185,cc186,cc187,cc188,cc189,cc190,cc191,cc192,cc193,cc194,cc195,cc196,cc197,cc198,cc199,cc200,cc201,cc202,cc203,cc204,:V_PARTITION_COL as p_date
from IDENTIFIER(:V_PERSON_NUPD_V12);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DATAFOR_HCC_TEMP)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP15'';

V_STEP_NAME :=  ''create a table datafor_hcc_temp_part'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create table if not exists IDENTIFIER(:V_DATAFOR_HCC_TEMP_PART)(hicno string,per_notin_diag_fg int,disabl int,cc1 int,cc2 int,cc3 int,cc4 int,cc5 int,cc6 int,cc7 int,cc8 int,cc9 int,cc10 int,cc11 int,cc12 int,cc13 int,cc14 int,cc15 int,cc16 int,cc17 int,cc18 int,cc19 int,cc20 int,cc21 int,cc22 int,cc23 int,cc24 int,cc25 int,cc26 int,cc27 int,cc28 int,cc29 int,cc30 int,cc31 int,cc32 int,cc33 int,cc34 int,cc35 int,cc36 int,cc37 int,cc38 int,cc39 int,cc40 int,cc41 int,cc42 int,cc43 int,cc44 int,cc45 int,cc46 int,cc47 int,cc48 int,cc49 int,cc50 int,cc51 int,cc52 int,cc53 int,cc54 int,cc55 int,cc56 int,cc57 int,cc58 int,cc59 int,cc60 int,cc61 int,cc62 int,cc63 int,cc64 int,cc65 int,cc66 int,cc67 int,cc68 int,cc69 int,cc70 int,cc71 int,cc72 int,cc73 int,cc74 int,cc75 int,cc76 int,cc77 int,cc78 int,cc79 int,cc80 int,cc81 int,cc82 int,cc83 int,cc84 int,cc85 int,cc86 int,cc87 int,cc88 int,cc89 int,cc90 int,cc91 int,cc92 int,cc93 int,cc94 int,cc95 int,cc96 int,cc97 int,cc98 int,cc99 int,cc100 int,cc101 int,cc102 int,cc103 int,cc104 int,cc105 int,cc106 int,cc107 int,cc108 int,cc109 int,cc110 int,cc111 int,cc112 int,cc113 int,cc114 int,cc115 int,cc116 int,cc117 int,cc118 int,cc119 int,cc120 int,cc121 int,cc122 int,cc123 int,cc124 int,cc125 int,cc126 int,cc127 int,cc128 int,cc129 int,cc130 int,cc131 int,cc132 int,cc133 int,cc134 int,cc135 int,cc136 int,cc137 int,cc138 int,cc139 int,cc140 int,cc141 int,cc142 int,cc143 int,cc144 int,cc145 int,cc146 int,cc147 int,cc148 int,cc149 int,cc150 int,cc151 int,cc152 int,cc153 int,cc154 int,cc155 int,cc156 int,cc157 int,cc158 int,cc159 int,cc160 int,cc161 int,cc162 int,cc163 int,cc164 int,cc165 int,cc166 int,cc167 int,cc168 int,cc169 int,cc170 int,cc171 int,cc172 int,cc173 int,cc174 int,cc175 int,cc176 int,cc177 int,cc178 int,cc179 int,cc180 int,cc181 int,cc182 int,cc183 int,cc184 int,cc185 int,cc186 int,cc187 int,cc188 int,cc189 int,cc190 int,cc191 int,cc192 int,cc193 int,cc194 int,cc195 int,cc196 int,cc197 int,cc198 int,cc199 int,cc200 int,cc201 int,cc202 int,cc203 int,cc204 int,p_date varchar);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DATAFOR_HCC_TEMP_PART)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP16'';

V_STEP_NAME :=  ''insert the data into target table datafor_hcc_temp_part'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

delete from IDENTIFIER(:V_DATAFOR_HCC_TEMP_PART)  where p_date=:V_PARTITION_COL;
insert into IDENTIFIER(:V_DATAFOR_HCC_TEMP_PART) 
SELECT hicno,per_notin_diag_fg,disabl,cc1,cc2,cc3,cc4,cc5,cc6,cc7,cc8,cc9,cc10,cc11,cc12,cc13,cc14,cc15,cc16,cc17,cc18,cc19,cc20,cc21,cc22,cc23,cc24,cc25,cc26,cc27,cc28,cc29,cc30,cc31,cc32,cc33,cc34,cc35,cc36,cc37,cc38,cc39,cc40,cc41,cc42,cc43,cc44,cc45,cc46,cc47,cc48,cc49,cc50,cc51,cc52,cc53,cc54,cc55,cc56,cc57,cc58,cc59,cc60,cc61,cc62,cc63,cc64,cc65,cc66,cc67,cc68,cc69,cc70,cc71,cc72,cc73,cc74,cc75,cc76,cc77,cc78,cc79,cc80,cc81,cc82,cc83,cc84,cc85,cc86,cc87,cc88,cc89,cc90,cc91,cc92,cc93,cc94,cc95,cc96,cc97,cc98,cc99,cc100,cc101,cc102,cc103,cc104,cc105,cc106,cc107,cc108,cc109,cc110,cc111,cc112,cc113,cc114,cc115,cc116,cc117,cc118,cc119,cc120,cc121,cc122,cc123,cc124,cc125,cc126,cc127,cc128,cc129,cc130,cc131,cc132,cc133,cc134,cc135,cc136,cc137,cc138,cc139,cc140,cc141,cc142,cc143,cc144,cc145,cc146,cc147,cc148,cc149,cc150,cc151,cc152,cc153,cc154,cc155,cc156,cc157,cc158,cc159,cc160,cc161,cc162,cc163,cc164,cc165,cc166,cc167,cc168,cc169,cc170,cc171,cc172,cc173,cc174,cc175,cc176,cc177,cc178,cc179,cc180,cc181,cc182,cc183,cc184,cc185,cc186,cc187,cc188,cc189,cc190,cc191,cc192,cc193,cc194,cc195,cc196,cc197,cc198,cc199,cc200,cc201,cc202,cc203,cc204,p_date from  IDENTIFIER(:V_DATAFOR_HCC_TEMP);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DATAFOR_HCC_TEMP_PART)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP17'';

V_STEP_NAME :=  ''create a table datafor_hcc'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_DATAFOR_HCC) COPY GRANTS as select  
hicno,per_notin_diag_fg,disabl,cc1,cc2,cc3,cc4,cc5,cc6,cc7,cc8,cc9,cc10,cc11,cc12,cc13,cc14,cc15,cc16,cc17,cc18,cc19,cc20,cc21,cc22,cc23,cc24,cc25,cc26,cc27,cc28,cc29,cc30,cc31,cc32,cc33,cc34,cc35,cc36,cc37,cc38,cc39,cc40,cc41,cc42,cc43,cc44,cc45,cc46,cc47,cc48,cc49,cc50,cc51,cc52,cc53,cc54,cc55,cc56,cc57,cc58,cc59,cc60,cc61,cc62,cc63,cc64,cc65,cc66,cc67,cc68,cc69,cc70,cc71,cc72,cc73,cc74,cc75,cc76,cc77,cc78,cc79,cc80,cc81,cc82,cc83,cc84,cc85,cc86,cc87,cc88,cc89,cc90,cc91,cc92,cc93,cc94,cc95,cc96,cc97,cc98,cc99,cc100,cc101,cc102,cc103,cc104,cc105,cc106,cc107,cc108,cc109,cc110,cc111,cc112,cc113,cc114,cc115,cc116,cc117,cc118,cc119,cc120,cc121,cc122,cc123,cc124,cc125,cc126,cc127,cc128,cc129,cc130,cc131,cc132,cc133,cc134,cc135,cc136,cc137,cc138,cc139,cc140,cc141,cc142,cc143,cc144,cc145,cc146,cc147,cc148,cc149,cc150,cc151,cc152,cc153,cc154,cc155,cc156,cc157,cc158,cc159,cc160,cc161,cc162,cc163,cc164,cc165,cc166,cc167,cc168,cc169,cc170,cc171,cc172,cc173,cc174,cc175,cc176,cc177,cc178,cc179,cc180,cc181,cc182,cc183,cc184,cc185,cc186,cc187,cc188,cc189,cc190,cc191,cc192,cc193,cc194,cc195,cc196,cc197,cc198,cc199,cc200,cc201,cc202,cc203,cc204
from IDENTIFIER(:V_DATAFOR_HCC_TEMP_PART) where 
p_date = :V_PARTITION_COL;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DATAFOR_HCC)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP18'';

V_STEP_NAME :=  ''delete data from DATAFOR_HCC_TEMP_PART with condition'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


delete from IDENTIFIER(:V_DATAFOR_HCC_TEMP_PART) where p_date = :V_PART_DEL_DATE;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_DATAFOR_HCC_TEMP_PART)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);


RAISE;

END;

';