USE SCHEMA BDR_FFP_DA;


CREATE OR REPLACE PROCEDURE BDR_FFP_DA.SP_GENDER_AGE_CPT("PIPELINE_ID" VARCHAR(16777216), "PIPELINE_NAME" VARCHAR(16777216), "DB_NAME" VARCHAR(16777216), "UTIL_SC" VARCHAR(16777216), "TGT_SC" VARCHAR(16777216), "INTRM_SC" VARCHAR(16777216), "BDR_CONF_SC" VARCHAR(16777216), "BDR_DM_SC" VARCHAR(16777216), "WH" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := :DB_NAME||''.''||COALESCE(:UTIL_SC, ''UTIL'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';

V_PROCESS_NAME   VARCHAR DEFAULT ''GENDER_AGE_CPT'';

V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''gender_age_cpt'';

V_STEP             VARCHAR;

V_STEP_NAME        VARCHAR;

V_START_TIME       VARCHAR;

V_END_TIME         VARCHAR;

V_ROWS_PARSED       INTEGER;

V_ROWS_LOADED       INTEGER;

V_MESSAGE          VARCHAR;

V_LAST_QUERY_ID    VARCHAR;



V_GENDER_AGE_CPT_AGE_CY           VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.GENDER_AGE_CPT_AGE_CY'';
V_GENDER_AGE_CPT_AGE_RESTRICTED   VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.GENDER_AGE_CPT_AGE_RESTRICTED'';

V_GENDER_AGE_CPT_AGE_RESTRICTED_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.GENDER_AGE_CPT_AGE_RESTRICTED_1'';
V_GENDER_AGE_CPT_AGE_CPT          VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.GENDER_AGE_CPT_AGE_CPT'';
V_D_CPT_LOOK                        VARCHAR := :DB_NAME || ''.'' || COALESCE(:BDR_DM_SC, ''BDR_DM'') || ''.D_CPT_LOOK'';

V_D_GDR_LOOK                       VARCHAR := :DB_NAME || ''.'' || COALESCE(:BDR_CONF_SC, ''BDR_CONF'') || ''.D_GDR_LOOK'';
V_F_CLM_BIL_LN_HIST                 VARCHAR := :DB_NAME || ''.'' || COALESCE(:BDR_DM_SC, ''BDR_DM'') || ''.F_CLM_BIL_LN_HIST'';
V_GENDER_AGE_CPT_GENDER_CY   VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.GENDER_AGE_CPT_GENDER_CY'';
V_GENDER_AGE_CPT_GENDER_RESTRICTED   VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.GENDER_AGE_CPT_GENDER_RESTRICTED'';
V_GENDER_AGE_CPT_GENDER_CPT_2   VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.GENDER_AGE_CPT_GENDER_CPT_2'';
V_GENDER_AGE_CPT_GENDER_CPT_3   VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.GENDER_AGE_CPT_GENDER_CPT_3'';
V_GENDER_AGE_CPT_AGE_CPT_3_SK   VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.GENDER_AGE_CPT_AGE_CPT_3_SK'';

V_GENDER_AGE_CPT_GENDER_CPT_3_SK   VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.GENDER_AGE_CPT_GENDER_CPT_3_SK'';

V_GENDER_AGE_CPT_AGE_CPT_3_FIN    VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.GENDER_AGE_CPT_AGE_CPT_3_FIN'';
V_Q32023_CPT_CODES_REF  VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.Q32023_CPT_CODES_REF'';
V_GENDER_AGE_CPT_GENDER_CPT_3_FIN VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.GENDER_AGE_CPT_GENDER_CPT_3_FIN'';
V_GENDER_AGE_CPT_SUMMARY_AGE_CPT VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.GENDER_AGE_CPT_SUMMARY_AGE_CPT'';
V_GENDER_AGE_CPT_SUMMARY_GENDER_CPT VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.GENDER_AGE_CPT_SUMMARY_GENDER_CPT'';
V_GENDER_AGE_CPT_SUMMARY_GENDER_CPT_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.GENDER_AGE_CPT_SUMMARY_GENDER_CPT_1'';

BEGIN

-- data backup for previous month
--------UNCOMMENT THIS LATER----------
-----Comment with below run---

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP1'';

V_STEP_NAME :=  ''create a table GENDER_AGE_CPT_AGE_RESTRICTED'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_GENDER_AGE_CPT_AGE_RESTRICTED) as
select LPAD(procedure_code,5,''0'') as procedure_code,
low_age,high_age,start_of_age_restriction,end_of_age_restriction
from IDENTIFIER(:V_GENDER_AGE_CPT_AGE_CY); -- ingested table  give generic name so it can be downloaded for every quarter


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_GENDER_AGE_CPT_AGE_RESTRICTED)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP2'';

V_STEP_NAME :=  ''create a table GENDER_AGE_CPT_AGE_RESTRICTED_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());



create or replace table IDENTIFIER(:V_GENDER_AGE_CPT_AGE_RESTRICTED_1) as
select * 
from (select *, 
ROW_NUMBER() over (PARTITION by procedure_code 
order by end_of_age_restriction) as RowNum
from IDENTIFIER(:V_GENDER_AGE_CPT_AGE_RESTRICTED)) as RankedRows where RowNum = 1;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_GENDER_AGE_CPT_AGE_RESTRICTED_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP3'';

V_STEP_NAME :=  ''create a table GENDER_AGE_CPT_AGE_CPT'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());




create or replace table IDENTIFIER(:V_GENDER_AGE_CPT_AGE_CPT) as
select a.procedure_code,a.low_age,a.high_age,a.start_of_age_restriction,a.end_of_age_restriction,
b.proc_full_desc,b.proc_lng_desc,b.srvc_catgy_desc,b.d_cpt_look_sk 
from IDENTIFIER(:V_GENDER_AGE_CPT_AGE_RESTRICTED_1) a 
left join IDENTIFIER(:V_D_CPT_LOOK) b 
on a.procedure_code = b.cpt_cd
where a.low_age + a.high_age > 0;



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_GENDER_AGE_CPT_AGE_CPT)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP4'';

V_STEP_NAME :=  ''create a table GENDER_AGE_CPT_GENDER_RESTRICTED'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());



-----------------Gender Part--------------------------------




create or replace table IDENTIFIER(:V_GENDER_AGE_CPT_GENDER_RESTRICTED) as
select LPAD(procedure_code,5,''0'') as procedure_code,
gender,restriction_effective_date ,restriction_termination_date 
from IDENTIFIER(:V_GENDER_AGE_CPT_GENDER_CY); --ingested table  give generic name so it can be downloaded for every quarter



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_GENDER_AGE_CPT_GENDER_RESTRICTED)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP5'';

V_STEP_NAME :=  ''create a table GENDER_AGE_CPT_GENDER_CPT_2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());



create or replace table IDENTIFIER(:V_GENDER_AGE_CPT_GENDER_CPT_2) as
select b.d_cpt_look_sk,c.procedure_code,
c.gender, 
c.restriction_effective_date,c.restriction_termination_date,
b.proc_full_desc,b.proc_lng_desc,b.srvc_catgy_desc 
from IDENTIFIER(:V_GENDER_AGE_CPT_GENDER_RESTRICTED) c
left join IDENTIFIER(:V_D_CPT_LOOK) b on c.procedure_code = b.cpt_cd;



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_GENDER_AGE_CPT_GENDER_CPT_2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP6'';

V_STEP_NAME :=  ''create a table GENDER_AGE_CPT_GENDER_CPT_3'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_GENDER_AGE_CPT_GENDER_CPT_3) as
select *,
case when procedure_code = ''56000'' then ''M'' 
	when procedure_code  = ''58551'' then ''F'' 
	else gender end as gender_fin
from  IDENTIFIER(:V_GENDER_AGE_CPT_GENDER_CPT_2);



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_GENDER_AGE_CPT_GENDER_CPT_3)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP7'';

V_STEP_NAME :=  ''create a table GENDER_AGE_CPT_AGE_CPT_3_SK'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_GENDER_AGE_CPT_AGE_CPT_3_SK) as
select x.*,
case when srvc_from_dat between (year(start_of_age_restriction_frmtd)*10000+month(start_of_age_restriction_frmtd)*100+DAY(start_of_age_restriction_frmtd)) and year(end_of_age_restriction_frmtd)*10000+month(end_of_age_restriction_frmtd)*100+DAY(end_of_age_restriction_frmtd) 
and srvc_to_dat between (year(start_of_age_restriction_frmtd)*10000+month(start_of_age_restriction_frmtd)*100+DAY(start_of_age_restriction_frmtd)) and year(end_of_age_restriction_frmtd)*10000+month(end_of_age_restriction_frmtd)*100+DAY(end_of_age_restriction_frmtd) then 1 else 0 end as restrictions_inforce,
case when start_of_age_restriction is null then ''ISDW'' else ''MH'' end as source_fg
FROM
(select 
b.f_clm_hist_sk,
b.d_mbr_info_sk,
b.clm_nbr,
b.incur_dt_id,
b.incur_dt_yymm,
b.rndr_prov_npi,
b.prem_due_age_id, 
b.srvc_from_dt_id as srvc_from_dat,
substr(b.srvc_from_dt_id,1,6) as srvc_from_month,
b.srvc_to_dt_id as srvc_to_dat,
substr(b.srvc_to_dt_id,1,6) as srvc_to_month,
b.bil_d_prov_sk,
a.procedure_code,
a.low_age,
high_age,
a.start_of_age_restriction,
case when start_of_age_restriction = ''0001-01-01'' then cast(''1900-01-01'' as date)
else to_date(start_of_age_restriction) end as start_of_age_restriction_frmtd,
a.end_of_age_restriction,
to_date(end_of_age_restriction) as end_of_age_restriction_frmtd,
a.proc_full_desc,
a.proc_lng_desc,
a.srvc_catgy_desc,
a.d_cpt_look_sk,
d.gdr_cd,
case when b.prem_due_age_id between a.low_age and a.high_age then 1 else 0 end as age_fg,
SUM(b.adj_ben_amt_1) as adj_ben_amt
from (select distinct f_clm_bil_ln_hist_sk,f_clm_hist_sk,d_mbr_info_sk,clm_nbr,incur_dt_id,substr(incur_dt_id,1,6) as incur_dt_yymm,rndr_prov_npi,
adj_ben_amt as adj_ben_amt_1,prem_due_age_id, srvc_from_dt_id,srvc_to_dt_id,bil_d_prov_sk,d_gdr_id_sk,d_cpt_look_sk
from IDENTIFIER(:V_F_CLM_BIL_LN_HIST)
where (srvc_from_dt_id/100)::number(10,0) between year(add_months(current_date,-12))*100+month(add_months(current_date,-12)) and year(add_months(current_date,-1))*100+month(add_months(current_date,-1)) and (srvc_to_dt_id/100)::number(10,0) between year(add_months(current_date,-12))*100+month(add_months(current_date,-12)) and year(add_months(current_date,-1))*100+month(add_months(current_date,-1)) and incur_dt_id not in (-1)) b
inner join IDENTIFIER(:V_GENDER_AGE_CPT_AGE_CPT) a 
on a.d_cpt_look_sk = b.d_cpt_look_sk
left join IDENTIFIER(:V_D_GDR_LOOK) d on d.d_gdr_id_sk = b.d_gdr_id_sk
group by b.f_clm_hist_sk,
b.d_mbr_info_sk,
b.clm_nbr,
b.incur_dt_id,
b.incur_dt_yymm,
b.rndr_prov_npi,
b.prem_due_age_id, 
b.srvc_from_dt_id,
substr(b.srvc_from_dt_id,1,6),
b.srvc_to_dt_id,
substr(b.srvc_to_dt_id,1,6),
b.bil_d_prov_sk,
a.procedure_code,
a.low_age,
high_age,
a.start_of_age_restriction,
case when start_of_age_restriction = ''0001-01-01'' then cast(''1900-01-01'' as date)
else to_date(start_of_age_restriction) end,
a.end_of_age_restriction,
to_date(end_of_age_restriction),
a.proc_full_desc,
a.proc_lng_desc,
a.srvc_catgy_desc,
a.d_cpt_look_sk,
d.gdr_cd,
case when b.prem_due_age_id between a.low_age and a.high_age then 1 else 0 end
having adj_ben_amt > 0) x;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_GENDER_AGE_CPT_AGE_CPT_3_SK)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP8'';

V_STEP_NAME :=  ''create a table GENDER_AGE_CPT_GENDER_CPT_3_SK'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());



create or replace table IDENTIFIER(:V_GENDER_AGE_CPT_GENDER_CPT_3_SK) as
select x.*,
case when srvc_from_dat between 
(year(restriction_effective_date_frmtd)*10000+month(restriction_effective_date_frmtd)*100+DAY(restriction_effective_date_frmtd)) and 
year(restriction_termination_date_frmtd)*10000+month(restriction_termination_date_frmtd)*100+DAY(restriction_termination_date_frmtd) 
and srvc_to_dat between 
(year(restriction_effective_date_frmtd)*10000+month(restriction_effective_date_frmtd)*100+DAY(restriction_effective_date_frmtd)) and 
year(restriction_termination_date_frmtd)*10000+month(restriction_termination_date_frmtd)*100+DAY(restriction_termination_date_frmtd) then 1 
when restriction_effective_date_frmtd is null and restriction_termination_date_frmtd is null then ''No restriction end date available'' else 0 end as restrictions_inforce,
case when restriction_effective_date is null then ''ISDW'' else ''MH'' end as source_fg

FROM
(select 
b.f_clm_hist_sk,
b.d_mbr_info_sk,
b.clm_nbr,
b.incur_dt_id,
b.incur_dt_yymm,
b.rndr_prov_npi,
b.prem_due_age_id, 
b.srvc_from_dt_id as srvc_from_dat,
substr(b.srvc_from_dt_id,1,6) as srvc_from_month,
b.srvc_to_dt_id as srvc_to_dat,
substr(b.srvc_to_dt_id,1,6) as srvc_to_month,
b.bil_d_prov_sk,
a.procedure_code,
a.restriction_effective_date,
case when restriction_effective_date = ''0001-01-01'' then cast(''1900-01-01'' as date)
else to_date(restriction_effective_date) end as restriction_effective_date_frmtd,
a.restriction_termination_date,
to_date(restriction_termination_date) as restriction_termination_date_frmtd,
a.proc_full_desc,
a.proc_lng_desc,
a.srvc_catgy_desc,
a.d_cpt_look_sk,
d.gdr_cd,
case when d.gdr_cd =a.gender_fin  then 1 else 0 end as gender_fg,
SUM(b.adj_ben_amt_1) as adj_ben_amt
from (select distinct f_clm_bil_ln_hist_sk,f_clm_hist_sk,d_mbr_info_sk,clm_nbr,incur_dt_id,substr(incur_dt_id,1,6) as incur_dt_yymm,rndr_prov_npi,
adj_ben_amt as adj_ben_amt_1,prem_due_age_id, srvc_from_dt_id,srvc_to_dt_id,bil_d_prov_sk,d_gdr_id_sk,d_cpt_look_sk
from IDENTIFIER(:V_F_CLM_BIL_LN_HIST)
where (srvc_from_dt_id/100)::number(10,0) between year(add_months(current_date,-12))*100+month(add_months(current_date,-12)) and year(add_months(current_date,-1))*100+month(add_months(current_date,-1)) and (srvc_to_dt_id/100)::number(10,0) between year(add_months(current_date,-12))*100+month(add_months(current_date,-12)) and year(add_months(current_date,-1))*100+month(add_months(current_date,-1)) and incur_dt_id not in (-1)) b
inner join IDENTIFIER(:V_GENDER_AGE_CPT_GENDER_CPT_3) a 
on a.d_cpt_look_sk = b.d_cpt_look_sk
left join IDENTIFIER(:V_D_GDR_LOOK) d on d.d_gdr_id_sk = b.d_gdr_id_sk
group by b.f_clm_hist_sk,
b.d_mbr_info_sk,
b.clm_nbr,
b.incur_dt_id,
b.incur_dt_yymm,
b.rndr_prov_npi,
b.prem_due_age_id, 
b.srvc_from_dt_id,
substr(b.srvc_from_dt_id,1,6),
b.srvc_to_dt_id,
substr(b.srvc_to_dt_id,1,6),
b.bil_d_prov_sk,
a.procedure_code,
a.restriction_effective_date,
case when restriction_effective_date = ''0001-01-01'' then cast(''1900-01-01'' as date)
else to_date(restriction_effective_date) end,
a.restriction_termination_date,
to_date(restriction_termination_date),
a.proc_full_desc,
a.proc_lng_desc,
a.srvc_catgy_desc,
a.d_cpt_look_sk,
d.gdr_cd,
case when d.gdr_cd =a.gender_fin  then 1 else 0 end
having adj_ben_amt > 0) x;




V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_GENDER_AGE_CPT_GENDER_CPT_3_SK)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP9'';

V_STEP_NAME :=  ''create a table GENDER_AGE_CPT_AGE_CPT_3_FIN'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());



create or replace table IDENTIFIER(:V_GENDER_AGE_CPT_AGE_CPT_3_FIN) as
select a.*, 
b.active_or_not,b.yyyymm_exp,
case when a.srvc_to_month > b.yyyymm_exp then ''concern'' when a.srvc_to_month <= b.yyyymm_exp then ''good to go'' else ''check'' end as srvc_vs_exp_flag
from IDENTIFIER(:V_GENDER_AGE_CPT_AGE_CPT_3_SK) a
left join 
	(select cpt_cd,active_or_not,month_exp,year_exp, 
	case when month_exp = 0 and  year_exp = 0 then 999912 else  year_exp*100+month_exp end as yyyymm_exp 
	from IDENTIFIER(:V_Q32023_CPT_CODES_REF)) b
on b.cpt_cd = a.procedure_code;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_GENDER_AGE_CPT_AGE_CPT_3_FIN)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP10'';

V_STEP_NAME :=  ''create a table GENDER_AGE_CPT_GENDER_CPT_3_FIN'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());




create or replace table IDENTIFIER(:V_GENDER_AGE_CPT_GENDER_CPT_3_FIN) as
select a.*, 
b.active_or_not,b.yyyymm_exp,
case when a.srvc_to_month > b.yyyymm_exp then ''concern'' when a.srvc_to_month <= b.yyyymm_exp then ''good to go'' else ''check'' end as srvc_vs_exp_flag
from IDENTIFIER(:V_GENDER_AGE_CPT_GENDER_CPT_3_SK) a
left join 
	(select cpt_cd,active_or_not,month_exp,year_exp, 
	case when month_exp = 0 and  year_exp = 0 then 999912 else  year_exp*100+month_exp end as yyyymm_exp 
	from IDENTIFIER(:V_Q32023_CPT_CODES_REF)) b
on b.cpt_cd = a.procedure_code;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_GENDER_AGE_CPT_GENDER_CPT_3_FIN)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP11'';

V_STEP_NAME :=  ''create a table GENDER_AGE_CPT_SUMMARY_AGE_CPT'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_GENDER_AGE_CPT_SUMMARY_AGE_CPT) as
select age_fg, restrictions_inforce,srvc_vs_exp_flag,incur_dt_yymm ,start_of_age_restriction_frmtd,end_of_age_restriction_frmtd, srvc_from_month,srvc_to_month ,count(*) as a, count(distinct clm_nbr) as clm_nbr, sum(adj_ben_amt) as amt
from IDENTIFIER(:V_GENDER_AGE_CPT_AGE_CPT_3_FIN)
group by age_fg, restrictions_inforce,srvc_vs_exp_flag,incur_dt_yymm ,start_of_age_restriction_frmtd,end_of_age_restriction_frmtd, srvc_from_month,srvc_to_month ;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_GENDER_AGE_CPT_SUMMARY_AGE_CPT)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP12'';

V_STEP_NAME :=  ''create a table GENDER_AGE_CPT_SUMMARY_GENDER_CPT'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_GENDER_AGE_CPT_SUMMARY_GENDER_CPT) as
select gender_fg, restrictions_inforce,srvc_vs_exp_flag,incur_dt_yymm ,restriction_effective_date_frmtd,restriction_termination_date_frmtd, srvc_from_month,srvc_to_month ,count(*) as a, count(distinct clm_nbr) as clm_nbr, sum(adj_ben_amt) as amt
from IDENTIFIER(:V_GENDER_AGE_CPT_GENDER_CPT_3_FIN)
group by gender_fg, restrictions_inforce,srvc_vs_exp_flag,incur_dt_yymm ,restriction_effective_date_frmtd,restriction_termination_date_frmtd, srvc_from_month,srvc_to_month ;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_GENDER_AGE_CPT_SUMMARY_GENDER_CPT)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP13'';

V_STEP_NAME :=  ''create a table IDENTIFIER(:V_GENDER_AGE_CPT_SUMMARY_GENDER_CPT_1)'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_GENDER_AGE_CPT_SUMMARY_GENDER_CPT_1) as
select procedure_code,proc_full_desc, count(*) as Count_of_flg_zero , sum(adj_ben_amt) as sum_of_ben_amt from IDENTIFIER(:V_GENDER_AGE_CPT_GENDER_CPT_3_FIN) where gender_fg=0 and restrictions_inforce =1 
group by procedure_code,proc_full_desc;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_GENDER_AGE_CPT_SUMMARY_GENDER_CPT_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);


RAISE;

END;

';