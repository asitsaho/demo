USE SCHEMA BDR_FFP_DA;


CREATE OR REPLACE PROCEDURE BDR_FFP_DA.SP_AGENT_QUALITY_03_PRINCIPAL_ORG("PIPELINE_ID" VARCHAR(16777216), "PIPELINE_NAME" VARCHAR(16777216), "DB_NAME" VARCHAR(16777216), "UTIL_SC" VARCHAR(16777216), "TGT_SC" VARCHAR(16777216), "INTRM_SC" VARCHAR(16777216), "ONE_SC" VARCHAR(16777216), "WH" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := :DB_NAME||''.''||COALESCE(:UTIL_SC, ''UTIL'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';

V_PROCESS_NAME   VARCHAR DEFAULT ''PROCESS_NAME'';

V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''01_TNA_RDC'';

V_STEP             VARCHAR;

V_STEP_NAME        VARCHAR;

V_START_TIME       VARCHAR;

V_END_TIME         VARCHAR;

V_ROWS_PARSED       INTEGER;

V_ROWS_LOADED       INTEGER;

V_MESSAGE          VARCHAR;

V_LAST_QUERY_ID    VARCHAR;



V_AGENT_QUALITY_PRINCIPAL_ORG_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_PRINCIPAL_ORG_1'';

V_PRINCIPAL_ORG VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''SRC_SRA'') || ''.PRINCIPAL_ORG'';

V_AGENT_QUALITY_PRINCIPAL_ORG_2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:INTRM_SC, ''BDR_FFP_DA_WRK'') || ''.AGENT_QUALITY_PRINCIPAL_ORG_2'';


BEGIN


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP1'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_PRINCIPAL_ORG_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_AGENT_QUALITY_PRINCIPAL_ORG_1) COPY GRANTS AS  
select a.*, b.startdate_dt as startdate_dt_b,c.enddate_dt as enddate_dt_b
from (select principalparty_id, 
org_party_id,
to_date(startdate) as startdate_dt,
to_date(enddate) as enddate_dt,
row_number() over (partition by org_party_id order by to_date(startdate)) as rowNum1
from IDENTIFIER(:V_PRINCIPAL_ORG)
order by org_party_id,startdate_dt) a 
left join (select principalparty_id, 
org_party_id,
to_date(startdate) as startdate_dt,
to_date(enddate) as enddate_dt,
row_number() over (partition by org_party_id order by to_date(startdate)) as rowNum1
from IDENTIFIER(:V_PRINCIPAL_ORG)
order by org_party_id,startdate_dt) b 
on a.org_party_id = b.org_party_id and a.rowNum1+1 = b.rowNum1
left join (select principalparty_id, 
org_party_id,
to_date(startdate) as startdate_dt,
to_date(enddate) as enddate_dt,
row_number() over (partition by org_party_id order by to_date(startdate)) as rowNum1
from IDENTIFIER(:V_PRINCIPAL_ORG)
order by org_party_id,startdate_dt) c 
on a.org_party_id = c.org_party_id and c.rowNum1+1 = a.rowNum1;



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_PRINCIPAL_ORG_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP2'';

V_STEP_NAME :=  ''create a table AGENT_QUALITY_PRINCIPAL_ORG_2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

										   


create or replace table IDENTIFIER(:V_AGENT_QUALITY_PRINCIPAL_ORG_2) COPY GRANTS AS  
select a.*,
(case 
when ((year(startdate_dt)*100 +month(startdate_dt)) = (year(enddate_dt_b)*100 +month(enddate_dt_b)) and day(enddate_dt_b) <= 15) then (year(add_months(enddate_dt_b,0))*100)+month(add_months(enddate_dt_b,0))
when ((year(startdate_dt)*100 +month(startdate_dt)) = (year(enddate_dt_b)*100 +month(enddate_dt_b)) and day(enddate_dt_b) > 15) then (year(add_months(enddate_dt_b,1))*100)+month(add_months(enddate_dt_b,1))
else (year(startdate_dt)*100)+month(startdate_dt) end) as startdate_yearmon,
(case 
when ((year(startdate_dt_b)*100 +month(startdate_dt_b)) = (year(enddate_dt)*100 +month(enddate_dt)) and day(enddate_dt) <= 15) then (year(add_months(enddate_dt,-1))*100)+month(add_months(enddate_dt,-1))
when ((year(startdate_dt_b)*100 +month(startdate_dt_b)) = (year(enddate_dt)*100 +month(enddate_dt)) and day(enddate_dt) > 15) then (year(add_months(enddate_dt,0))*100)+month(add_months(enddate_dt,0))
else (year(enddate_dt)*100)+month(enddate_dt) end) as enddate_yearmon
from IDENTIFIER(:V_AGENT_QUALITY_PRINCIPAL_ORG_1) a;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_AGENT_QUALITY_PRINCIPAL_ORG_2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''PRE_CLM'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);


RAISE;

END;

';