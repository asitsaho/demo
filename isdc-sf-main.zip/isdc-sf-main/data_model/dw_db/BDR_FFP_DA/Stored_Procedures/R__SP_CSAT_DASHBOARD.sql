USE SCHEMA BDR_FFP_DA;




CREATE OR REPLACE PROCEDURE SP_CSAT_DASHBOARD("PIPELINE_ID" VARCHAR(16777216), "PIPELINE_NAME" VARCHAR(16777216), "DB_NAME" VARCHAR(16777216), "UTIL_SC" VARCHAR(16777216), "SRC_SC_1" VARCHAR(16777216), "SRC_SC_2" VARCHAR(16777216), "SRC_SC_3" VARCHAR(16777216), "SRC_SC_4" VARCHAR(16777216), "SRC_SC_5" VARCHAR(16777216), "WRK_SC" VARCHAR(16777216), "TGT_SC" VARCHAR(16777216), "WH" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

V_CURRENT_DATE   DATE := CURRENT_DATE();

V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := :DB_NAME||''.''||COALESCE(:UTIL_SC, ''UTIL'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';

V_PROCESS_NAME   VARCHAR DEFAULT ''CSAT_DASHBOARD'';

V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''CSAT_DASHBOARD'';

V_STEP             VARCHAR;

V_STEP_NAME        VARCHAR;

V_START_TIME       VARCHAR;

V_END_TIME         VARCHAR;

V_ROWS_PARSED       INTEGER;

V_ROWS_LOADED       INTEGER;

V_MESSAGE          VARCHAR;

V_LAST_QUERY_ID    VARCHAR;

V_CSAT_T1_TMP VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.CSAT_T1_TMP'';

V_FF_CSAT_SURVEY VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_1, ''SRC_FILES'') || ''.FF_CSAT_SURVEY'';

V_P_LVL_CLAIM_INFO VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.INFORCELR_P_LVL_CLAIM_INFO'';

V_CSAT_T1_TMP_2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.CSAT_T1_TMP_2'';

V_CSAT_0_TMP VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.CSAT_0_TMP'';

V_CSAT_0_TMP_DEL VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.CSAT_0_TMP_DEL'';

V_CSAT_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.CSAT_1'';

V_CSAT_2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.CSAT_2'';

V_CSAT_3 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.CSAT_3'';

V_CSAT_4 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.CSAT_4'';

V_EZCLAIM_ENROLLED_FOR_LAPSE_SA VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.EZCLAIM_EZCLAIM_ENROLLED_FOR_LAPSE_SA''; 

V_CSAT_TRANS_MO VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.CSAT_TRANS_MO'';

V_F_PREM_TRANS_MO VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_2, ''BDR_DM'') || ''.F_PREM_TRANS_MO'';

V_CSAT_VOLN_LAPSE_MO VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.CSAT_VOLN_LAPSE_MO'';

V_D_PLN_BEN_MOD VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_3, ''BDR_CONF'') || ''.D_PLN_BEN_MOD'';

V_D_GEO_XREF VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_3, ''BDR_CONF'') || ''.D_GEO_XREF'';

V_D_ST VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_3, ''BDR_CONF'') || ''.D_ST'';

V_D_MBR_INFO VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_3, ''BDR_CONF'') || ''.D_MBR_INFO'';

V_D_CERT_ACTV VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_3, ''BDR_CONF'') || ''.D_CERT_ACTV'';

V_CSAT_LAPSE_MO VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.CSAT_LAPSE_MO'';

V_CSAT_STR_LAPSE_MO VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.CSAT_STR_LAPSE_MO'';

V_CSAT_LAPSE VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.CSAT_LAPSE'';

V_CSAT_8 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.CSAT_8'';

V_CSAT_VAS_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.CSAT_VAS_1'';

V_CSAT_VAS_2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.CSAT_VAS_2'';

V_CSAT_VAS_3 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.CSAT_VAS_3'';

V_CSAT_HCO_CALLS VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.CSAT_HCO_CALLS'';

v_PERSON_HCO_CONTACT_REQUEST VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_4, ''BDR_SMART'') || ''.PERSON_HCO_CONTACT_REQUEST'';

V_HCO_CONTACT_REASON_TYPE VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_4, ''BDR_SMART'') || ''.HCO_CONTACT_REASON_TYPE'';

V_HCO_CONTACT_REASON_SUB_TYPE VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_4, ''BDR_SMART'') || ''.HCO_CONTACT_REASON_SUB_TYPE'';

V_CSAT_HCO_CALLS_02 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.CSAT_HCO_CALLS_02'';

V_VAS_HNW_MASTER VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.VAS_HNW_MASTER'';

V_CSAT_INBOUND VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.CSAT_INBOUND'';

V_CSAT_REBILL VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.CSAT_REBILL'';

V_STATE_STRATEGIES_2023 VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_5, ''SRC_MPO'') || ''.STATE_STRATEGIES_2023'';

V_CSAT_AARP_TMP VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.CSAT_AARP_TMP'';

V_PERSON_MEMBERSHIP VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC_4, ''BDR_SMART'') || ''.PERSON_MEMBERSHIP'';

v_CSAT_AARP_TMP_V2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.CSAT_AARP_TMP_V2'';

V_CSAT_AARP VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.CSAT_AARP'';

V_CSAT_BASE VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.CSAT_BASE'';

V_CSAT_PREV_DATA_QC VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.CSAT_PREV_DATA_QC'';

V_CSAT_DATA VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.CSAT_DATA'';

V_QC1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.CSAT_QC1'';

V_QC2 VARCHAR := :DB_NAME || ''.'' || COALESCE(:WRK_SC, ''BDR_FFP_DA_WRK'') || ''.CSAT_QC2'';

BEGIN

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP1'';

V_STEP_NAME :=  ''Create table CSAT_T1_TMP'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


CREATE OR REPLACE TABLE IDENTIFIER(:V_CSAT_T1_TMP) COPY GRANTS AS SELECT a.*,
	b.age,
	b.gdr_desc,
	b.d_mbr_info_sk,
	b.lgl_enty_nm,
	b.lgl_enty_shrt_desc,
	b.marketing_channel_final,
	b.sub_channel,
	b.pdp_fg,
	b.plan,
	b.pln_grp,
	b.pln_lvl,
	cast(b.prem_due_age_id as NUMBER(38,2)) as prem_due_age_id,
	b.prdct_eff_dt,
	b.prdct_eff_mo_id,
	b.prem_due_dt,
	b.prem_due_mo_id,
	b.undwr_pln_rqr_txt,
	b.undwr_prdct_rqr_txt,
	b.uw_pln_rqr_txt,
	b.uw_prdct_rqr_txt,
	b.rtng_area_nm,
	b.cnty_nm,
	b.dscnt_multi_insd_flg,
	b.dscnt_eft_desc,
	b.dscnt_erly_enrl_desc,
	b.dscnt_erly_enrl_flg,
	b.ealliance_pref_nm,
	b.rt_dtrm_cd_desc,
	b.acct_nbr,
	b.eft_info, 
	b.web_reg ,
	b.agt_id,
	b.pty_id,
	b.compas_insd_pln_id,
	CAST(CONCAT(SUBSTR(dob_id,1,4),''-'', SUBSTR(dob_id,5,2),''-'',SUBSTR(dob_id,7,2)) AS DATE) AS date_id2,
	row_number() over(partition by respno order by abs(months_between(cast (concat(a.yearnumber,''-'',lpad(a.monthnumber,2,''0''),''-01'') as date),prem_due_dt)) nulls last) as mo_gap
FROM IDENTIFIER(:V_FF_CSAT_SURVEY) AS a
left JOIN  IDENTIFIER(:V_P_LVL_CLAIM_INFO) b 
ON a.person_id = b.PERS_ID AND 
cast (concat(replace(a.yearnumber,''null'',''0''),''-'',lpad(replace(a.monthnumber,''null'',''0''),2,''0''),''-01'') as date) <= b.prem_due_dt 
and cast(concat(replace(a.yearnumber,''null'',''0''),''-'',lpad(replace(a.monthnumber,''null'',''0''),2,''0''),''-01'') as date) >= add_months(b.prem_due_dt,-3);



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_CSAT_T1_TMP)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP2'';

V_STEP_NAME :=  ''Create CSAT_T1_TMP_2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE  IDENTIFIER(:V_CSAT_T1_TMP_2) COPY GRANTS AS SELECT * from IDENTIFIER(:V_CSAT_T1_TMP)
where mo_gap=1;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_CSAT_T1_TMP_2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP3'';

V_STEP_NAME :=  ''Create CSAT_0_TMP'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE  IDENTIFIER(:V_CSAT_0_TMP_DEL) as select *,
case when interview_date like ''__%:%:%'' then  TO_CHAR(TO_TIMESTAMP(TRIM(interview_date), ''DDMONYY:HH24:MI:SS''), ''MM/DD/YYYY HH24:MI'') else interview_date end as interview_dat from IDENTIFIER(:V_CSAT_T1_TMP_2);
 
CREATE OR REPLACE TABLE  IDENTIFIER(:V_CSAT_0_TMP) COPY GRANTS AS 
select * EXCLUDE(INTERVIEW_DAT) FROM (SELECT *,
CASE WHEN ((yearnumber=2023 and monthnumber>=4) or yearnumber>=2024) then to_char(to_timestamp(interview_dat,''MM/DD/YYYY HH24:MI''),''yyyy-MM-dd'')
else to_char(to_timestamp(interview_dat,''MM/DD/YYYY HH24:MI''),''yyyy-MM-dd'') end as interview_dt
from IDENTIFIER(:V_CSAT_0_TMP_DEL));

drop table IDENTIFIER(:V_CSAT_0_TMP_DEL);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_CSAT_0_TMP)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP4'';

V_STEP_NAME :=  ''Create CSAT_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE  IDENTIFIER(:V_CSAT_1) COPY GRANTS AS SELECT a.*,
	CASE WHEN prdct_eff_dt is null then ''N/A'' 
		WHEN datediff(day,prdct_eff_dt,interview_dt)/365.25 >0 AND datediff(day,prdct_eff_dt,interview_dt)/365.25 <= 1 THEN ''Less than 1yr''
		WHEN datediff(day,prdct_eff_dt,interview_dt)/365.25 >1 AND datediff(day,prdct_eff_dt,interview_dt)/365.25 <=2 THEN ''1-2yrs''
		WHEN datediff(day,prdct_eff_dt,interview_dt)/365.25 >3 AND datediff(day,prdct_eff_dt,interview_dt)/365.25 <=5 THEN ''3-5yrs''
		WHEN datediff(day,prdct_eff_dt,interview_dt)/365.25 >2 AND datediff(day,prdct_eff_dt,interview_dt)/365.25 <=3 THEN ''2-3yrs''
		WHEN datediff(day,prdct_eff_dt,interview_dt)/365.25 >5 AND datediff(day,prdct_eff_dt,interview_dt)/365.25 <=10 THEN ''5-10yrs''
		WHEN datediff(day,prdct_eff_dt,interview_dt)/365.25 >10 THEN ''10+yrs''
		ELSE ''Interviewed prior to effective date'' 
	END AS tenure
FROM IDENTIFIER(:V_CSAT_0_TMP) AS a; 


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_CSAT_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP5'';

V_STEP_NAME :=  ''Create CSAT_2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE  IDENTIFIER(:V_CSAT_2) COPY GRANTS AS 
SELECT a.person_id, a.interview_dt
,SUM(b.paid_prem) AS paid_prem
,SUM(b.claim) AS claim
FROM IDENTIFIER(:V_CSAT_1) a
LEFT JOIN IDENTIFIER(:V_P_LVL_CLAIM_INFO) b
  ON  a.person_id = b.pers_id
  AND ADD_MONTHS(interview_dt,-12) <= b.prem_due_dt
  AND b.prem_due_dt < interview_dt
GROUP BY a.person_id, a.interview_dt;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_CSAT_2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP6'';

V_STEP_NAME :=  ''Create CSAT_3'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE  IDENTIFIER(:V_CSAT_3) COPY GRANTS AS 
SELECT a.*, b.paid_prem, b.claim
FROM IDENTIFIER(:V_CSAT_1) a
LEFT JOIN IDENTIFIER(:V_CSAT_2) b 
ON  a.person_id = b.person_id AND a.interview_dt = b.interview_dt;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_CSAT_3)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP7'';

V_STEP_NAME :=  ''Create CSAT_4'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


DROP TABLE if exists  IDENTIFIER(:V_CSAT_4);
CREATE OR REPLACE TABLE  IDENTIFIER(:V_CSAT_4) COPY GRANTS AS SELECT a.*, 
CASE WHEN b.acct_nbr IS NOT NULL THEN 1 ELSE 0 END AS EZ_Claim_fg, 
b.start_date as EZ_Claim_Start_Date, 
b.end_date_min as EZ_Claim_End_Date
FROM IDENTIFIER(:V_CSAT_3) a 
LEFT JOIN IDENTIFIER(:V_EZCLAIM_ENROLLED_FOR_LAPSE_SA) b
ON a.acct_nbr = b.acct_nbr
AND cast(to_char(start_date,''yyyyMM'') as int) <= a.prem_due_mo_id  AND (cast(to_char(start_date,''yyyyMM'') as int) >= a.prem_due_mo_id  OR b.end_date_min IS NULL) 
AND a.acct_nbr IS NOT NULL;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_CSAT_4)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP8'';

V_STEP_NAME :=  ''Create CSAT_TRANS_MO'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE  IDENTIFIER(:V_CSAT_TRANS_MO) COPY GRANTS AS 
SELECT d_mbr_info_sk, prdct_eff_mo_id, CERT_EFF_MO_ID, TERM_CERT_QTY,
D_PLN_BEN_MOD_SK, PREM_DUE_MO_ID, PD_CERT_QTY, DELQ_CERT_QTY,prdct_D_ACQN_CHNL_SK, d_cert_actv_sk,RES_D_GEO_XREF_SK
FROM IDENTIFIER(:V_F_PREM_TRANS_MO) WHERE PREM_DUE_MO_ID >= 202201;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_CSAT_TRANS_MO)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP9'';

V_STEP_NAME :=  ''Create CSAT_VOLN_LAPSE_MO'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


CREATE OR REPLACE TABLE  IDENTIFIER(:V_CSAT_VOLN_LAPSE_MO) COPY GRANTS AS  
SELECT PREM_DUE_mo_ID
	,prdct_eff_mo_id
	,CERT_EFF_mo_ID
	,pers_id
	,a16.CERT_ACTV_LVL_2_TXT
	,a16.CERT_ACTV_LVL_1_TXT
	,a11.d_cert_actv_sk
	,SUM(a11.TERM_CERT_QTY) AS term
FROM IDENTIFIER(:V_CSAT_TRANS_MO) a11
LEFT OUTER JOIN IDENTIFIER(:V_D_PLN_BEN_MOD) a12
	ON (a11.D_PLN_BEN_MOD_SK = a12.D_PLN_BEN_MOD_SK)
LEFT OUTER JOIN IDENTIFIER(:V_D_GEO_XREF) a13
	ON (a11.RES_D_GEO_XREF_SK = a13.D_GEO_XREF_SK)
LEFT OUTER JOIN IDENTIFIER(:V_D_ST) a14
	ON (a13.D_ST_CD = a14.D_ST_CD)
LEFT JOIN IDENTIFIER(:V_D_MBR_INFO) a15
ON a11.d_mbr_info_sk = a15.d_mbr_info_sk
LEFT JOIN IDENTIFIER(:V_D_CERT_ACTV)   a16
	ON (a11.D_CERT_ACTV_SK = a16.D_CERT_ACTV_SK)
WHERE (TRIM(a12.LF_CATGY_NM) IN (''Med Supp-Pre-Standardized'', ''Med Supp-Select'', ''Med Supp-Standardized/Modernized'')
AND (a11.d_cert_actv_sk BETWEEN 19 AND 49 OR a11.d_cert_actv_sk BETWEEN 3 AND 11)) 
GROUP BY PREM_DUE_mo_ID,prdct_eff_mo_id,CERT_EFF_mo_ID,pers_id,a16.CERT_ACTV_LVL_2_TXT,a16.CERT_ACTV_LVL_1_TXT,
a11.d_cert_actv_sk
HAVING term > 0;

    

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_CSAT_VOLN_LAPSE_MO)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP10'';

V_STEP_NAME :=  ''Create csat_lapse_mo'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE  IDENTIFIER(:V_CSAT_LAPSE_MO) COPY GRANTS AS 
SELECT a.* FROM 
(
	SELECT b.*,
		ROW_NUMBER() OVER (PARTITION BY pers_id ORDER BY pers_id, PREM_DUE_mo_ID DESC) rn
	FROM IDENTIFIER(:V_CSAT_VOLN_LAPSE_MO) b
) a
WHERE rn =1;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_CSAT_LAPSE_MO)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP11'';

V_STEP_NAME :=  ''Create CSAT_STR_LAPSE_MO'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


CREATE OR REPLACE TABLE  IDENTIFIER(:V_CSAT_STR_LAPSE_MO) COPY GRANTS AS 
SELECT a.*, 
	CAST(CONCAT(SUBSTR(str_date,1,4),''-'', SUBSTR(str_date,5,2),''-01'') AS DATE) AS prem_due_date FROM
	(
	SELECT pers_id, d_cert_actv_sk,CERT_ACTV_LVL_2_TXT,CERT_ACTV_LVL_1_TXT,
	CAST(PREM_DUE_mo_ID AS string) AS str_date, term 
	FROM IDENTIFIER(:V_CSAT_LAPSE_MO) WHERE d_cert_actv_sk BETWEEN 19 AND 49
	)a;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_CSAT_STR_LAPSE_MO)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP12'';

V_STEP_NAME :=  ''Create CSAT_LAPSE'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE  IDENTIFIER(:V_CSAT_LAPSE) COPY GRANTS AS SELECT a.*,
	b.prem_due_date,
	CASE WHEN b.term >=1 AND datediff(day,a.interview_dt,b.prem_due_date)>=0 AND datediff(day,a.interview_dt,b.prem_due_date)<=31 THEN ''Yes'' ELSE ''No'' END AS lapser_1mo,
	CASE WHEN b.term >=1 AND datediff(day,a.interview_dt,b.prem_due_date)>=0 AND datediff(day,a.interview_dt,b.prem_due_date)<=62 THEN ''Yes'' ELSE ''No'' END AS lapser_2mo,
	CASE WHEN b.term >=1 AND datediff(day,a.interview_dt,b.prem_due_date)>=0 AND datediff(day,a.interview_dt,b.prem_due_date)<=186 THEN ''Yes'' ELSE ''No'' END AS lapser_6mo,
	CASE WHEN b.term >=1 AND datediff(day,a.interview_dt,b.prem_due_date)>=0 AND datediff(day,a.interview_dt,b.prem_due_date)<=365 THEN ''Yes'' ELSE ''No'' END AS lapser_12mo,
	CASE WHEN b.term >=1 AND datediff(day,a.interview_dt,b.prem_due_date)>=0 THEN ''Yes'' ELSE ''No'' END AS Lifetime_lapser,
	CASE WHEN b.pers_id IS NULL THEN ''Non-lapser''
	ELSE ''Lapser'' END AS Lapse_flg,CERT_ACTV_LVL_2_TXT,CERT_ACTV_LVL_1_TXT
FROM IDENTIFIER(:V_CSAT_4) AS a 
LEFT JOIN IDENTIFIER(:V_CSAT_STR_LAPSE_MO) AS b
ON a.person_id = b.pers_id AND b.prem_due_date > a.interview_dt;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_CSAT_LAPSE)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP13'';

V_STEP_NAME :=  ''Create CSAT_8'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


CREATE OR REPLACE TABLE  IDENTIFIER(:V_CSAT_8) COPY GRANTS AS SELECT a.*
,b.fst_nm
,b.lst_nm
from IDENTIFIER(:V_CSAT_LAPSE) a
left join IDENTIFIER(:V_D_MBR_INFO) b 
on a.d_mbr_info_sk = b.d_mbr_info_sk;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_CSAT_8)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP14'';

V_STEP_NAME :=  ''Create CSAT_VAS_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE  IDENTIFIER(:V_CSAT_VAS_1) COPY GRANTS AS SELECT cast(concat(substr(visit_month,1,4),SUBSTR(visit_month,6,2)) as int) as visit_mo_id, *
from IDENTIFIER(:V_VAS_HNW_MASTER)  
where visit_month >=''2021-08-01'';

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_CSAT_VAS_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP15'';

V_STEP_NAME :=  ''Create csat_vas_2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE  IDENTIFIER(:V_CSAT_VAS_2) COPY GRANTS AS SELECT a.person_id, a.interview_dt,
case when (sum(case when upper(gym_fg) = ''YES'' then 1 else 0 end)>0) then ''Yes'' else ''No'' end as VAS_Gym,
case when (sum(case when upper(social_fg) = ''YES'' then 1 else 0 end)>0) then ''Yes'' else ''No'' end as VAS_Social,
case when (sum(case when upper(digital_fg) = ''YES'' then 1 else 0 end)> 0) then ''Yes'' else ''No'' end as VAS_Digital,
case when (sum(case when upper(delivery_fg) = ''YES'' then 1 else 0 end)>0) then ''Yes'' else ''No'' end  as VAS_Delivery,
case when (sum(case when upper(cognitive_fg) = ''YES'' then 1 else 0 end)>0) then ''Yes'' else ''No'' end as VAS_Cognitive,
case when (sum(case when upper(nurseline_inbound_fg) = ''YES'' then 1 else 0 end)>0) then ''Yes'' else ''No'' end as VAS_Nurseline,
case when (sum(case when upper(hci_fg) = ''YES'' then 1 else 0 end)>0) then ''Yes'' else ''No'' end as HNW_HCI,
case when (sum(case when upper(ons_fg) = ''YES'' then 1 else 0 end)>0) then ''Yes'' else ''No'' end as HNW_ONS
from IDENTIFIER(:V_CSAT_8) a
left join IDENTIFIER(:V_CSAT_VAS_1) b 
on  substr(lpad(a.acct_nbr,11,''0''),1,9)=b.member_id
and upper(a.fst_nm)=b.member_name_first
and upper(a.lst_nm)=b.member_name_last
and ADD_MONTHS(a.interview_dt,-5) <= b.visit_month
and b.visit_month < a.interview_dt
GROUP BY a.person_id, a.interview_dt;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_CSAT_VAS_2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP16'';

V_STEP_NAME :=  ''Create csat_vas_3'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE  IDENTIFIER(:V_CSAT_VAS_3) COPY GRANTS AS  
SELECT a.*, COALESCE(vas_gym,''No'') as vas_gym, COALESCE(vas_social,''No'') as vas_social, COALESCE(vas_cognitive,''No'') as vas_cognitive, COALESCE(vas_delivery,''No'') as vas_delivery, COALESCE(vas_digital,''No'') as vas_digital, COALESCE(vas_nurseline,''No'') as vas_nurseline, COALESCE (hnw_hci,''No'') as hnw_hci, COALESCE(hnw_ons,''No'') as hnw_ons
FROM IDENTIFIER(:V_CSAT_8) a 
LEFT JOIN IDENTIFIER(:V_CSAT_VAS_2) b 
ON a.person_id = b.person_id AND a.interview_dt = b.interview_dt;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_CSAT_VAS_3)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP17'';

V_STEP_NAME :=  ''Create CSAT_HCO_CALLS'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


CREATE OR REPLACE TABLE  IDENTIFIER(:V_CSAT_HCO_CALLS) COPY GRANTS AS SELECT hco.*
        ,rsn.hco_contact_rsn_type_name
        ,rsn_typ.hco_contact_rsn_sub_type_name
FROM IDENTIFIER(:V_PERSON_HCO_CONTACT_REQUEST) hco
LEFT JOIN IDENTIFIER(:V_HCO_CONTACT_REASON_TYPE) AS rsn 
        ON hco.hco_contact_rsn_type_code = rsn.hco_contact_rsn_type_code
LEFT JOIN IDENTIFIER(:V_HCO_CONTACT_REASON_SUB_TYPE) AS rsn_typ 
        ON hco.hco_contact_rsn_sub_type_code = rsn_typ.hco_contact_rsn_sub_type_code
WHERE inquiry_type = ''T'' 
AND contact_date>= ''2021-10-01'' 
;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_CSAT_HCO_CALLS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP18'';

V_STEP_NAME :=  ''Create CSAT_HCO_CALLS_02'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE  IDENTIFIER(:V_CSAT_HCO_CALLS_02) COPY GRANTS AS 
SELECT a.person_id, a.interview_dt,
        sum(case when b.person_id is not null then 1 else 0 end) as total_calls, 
        sum(case when trim(hco_contact_rsn_type_name) = ''BILLING/PAYMENT INQUIRY'' then 1 else 0 end) as bill_inq_calls, 
        sum(case when trim(hco_contact_rsn_type_name) = ''CLAIM INQUIRY'' then 1 else 0 end) as claim_inq_calls, 
        sum(case when trim(hco_contact_rsn_type_name) = ''PLAN INQUIRY'' then 1 else 0 end) as plan_inq_calls, 
        sum(case when trim(hco_contact_rsn_type_name) = ''PROGRAM INQUIRY'' then 1 else 0 end) as program_inq_calls,
        sum(case when trim(hco_contact_rsn_sub_type_name) = ''24-7 NURSE SERVICES-REFERRED'' then 1 else 0 end) as nurse_healthline_calls
FROM IDENTIFIER(:V_CSAT_VAS_3) a
LEFT JOIN IDENTIFIER(:V_CSAT_HCO_CALLS) b
  ON  a.person_id = b.person_id
  AND ADD_MONTHS(interview_dt,-3) <= contact_date
  AND contact_date < interview_dt
GROUP BY a.person_id, a.interview_dt;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_CSAT_HCO_CALLS_02)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP19'';

V_STEP_NAME :=  ''Create CSAT_INBOUND'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());



CREATE OR REPLACE TABLE  IDENTIFIER(:V_CSAT_INBOUND) COPY GRANTS AS  
SELECT a.*, total_calls, bill_inq_calls, claim_inq_calls, plan_inq_calls, program_inq_calls, nurse_healthline_calls,
CASE WHEN b.total_calls>0 THEN ''Y'' ELSE ''N'' END AS recent_inbound_call
FROM IDENTIFIER(:V_CSAT_VAS_3) a 
LEFT JOIN IDENTIFIER(:V_CSAT_HCO_CALLS_02) b 
ON a.person_id = b.person_id AND a.interview_dt = b.interview_dt;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_CSAT_INBOUND)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP20'';

V_STEP_NAME :=  ''Create csat_rebill'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE  IDENTIFIER(:V_CSAT_REBILL) COPY GRANTS AS SELECT a.*,b.* FROM IDENTIFIER(:V_CSAT_INBOUND) a 
LEFT JOIN IDENTIFIER(:V_STATE_STRATEGIES_2023) b ON a.state=b.state_cd;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_CSAT_REBILL)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP21'';

V_STEP_NAME :=  ''Create CSAT_AARP_TMP'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


CREATE OR REPLACE TABLE  IDENTIFIER(:V_CSAT_AARP_TMP) COPY GRANTS AS SELECT a.*, b.begin_date AS aarp_begin_date, b.end_date AS aarp_end_date,
CASE WHEN b.person_id IS NOT NULL THEN ''Y'' ELSE ''N'' END AS aarp_mbr_fg
FROM IDENTIFIER(:V_CSAT_REBILL) a
LEFT JOIN IDENTIFIER(:V_PERSON_MEMBERSHIP) b 
ON a.person_id = b.person_id 
AND (b.begin_date <= a.interview_dt AND (b.end_date > a.interview_dt OR b.end_date IS NULL));


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_CSAT_AARP_TMP)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP22'';

V_STEP_NAME :=  ''Create CSAT_AARP_TMP_V2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE  IDENTIFIER(:V_CSAT_AARP_TMP_V2) COPY GRANTS AS SELECT * FROM
(SELECT *,ROW_NUMBER() OVER (PARTITION BY person_id, interview_dt ORDER BY aarp_begin_date ASC) as rn1 FROM IDENTIFIER(:V_CSAT_AARP_TMP)) as a
where a.rn1=1;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_CSAT_AARP_TMP_V2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP23'';

V_STEP_NAME :=  ''Create csat_aarp,'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


CREATE OR REPLACE TABLE  IDENTIFIER(:V_CSAT_AARP) COPY GRANTS AS SELECT *, CASE WHEN aarp_mbr_fg = ''N'' THEN ''Not in AARP''
	WHEN datediff(day,aarp_begin_date,interview_dt)/365.25 <= 1 THEN ''Less than 1yr''
	WHEN datediff(day,aarp_begin_date,interview_dt)/365.25 >1 AND datediff(day,aarp_begin_date,interview_dt)/365.25 <=2 THEN ''1-2yrs''
	WHEN datediff(day,aarp_begin_date,interview_dt)/365.25 >3 AND datediff(day,aarp_begin_date,interview_dt)/365.25 <=5 THEN ''3-5yrs''
	WHEN datediff(day,aarp_begin_date,interview_dt)/365.25 >2 AND datediff(day,aarp_begin_date,interview_dt)/365.25 <=3 THEN ''2-3yrs''
	WHEN datediff(day,aarp_begin_date,interview_dt)/365.25 >5 AND datediff(day,aarp_begin_date,interview_dt)/365.25 <=10 THEN ''5-10yrs''
	WHEN datediff(day,aarp_begin_date,interview_dt)/365.25 >10 THEN ''10+yrs''
	ELSE ''Check'' END AS tenure_in_aarp
FROM IDENTIFIER(:V_CSAT_AARP_TMP_V2);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_CSAT_AARP)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP24'';

V_STEP_NAME :=  ''Create CSAT_BASE'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


CREATE OR REPLACE TABLE  IDENTIFIER(:V_CSAT_BASE) COPY GRANTS AS SELECT *, 
case 
	when slalabel in (''Enrollment/Fulfillment - Cell Phone'',''Enrollment/Fulfillment - Landline'') then ''Enrollment/Fulfillment''
	when slalabel in (''Agent Distribution - Cell Phone'', ''Agent Distribution - Landline'') then ''Agent Distribution''
	when slalabel in (''Aggregator Distribution - Cell Phone'', ''Aggregator Distribution - Landline'') then ''Aggregator Distribution''
	when slalabel in (''Claims/Billing - Cell Phone'', ''Claims/Billing - Landline'') then ''Claims/Billing''
	when slalabel in (''Customer Service - Cell Phone'', ''Customer Service - Landline'') then ''Customer Service''
	when slalabel in (''Online Enrollment/Fulfillment - Cell Phone'', ''Online Enrollment/Fulfillment - Landline'', ''Online Enrollment/Fulfillment - Cell Pho'') then ''Online Enrollment/Fulfillment''
end as slalabel_new
from IDENTIFIER(:V_CSAT_AARP);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_CSAT_BASE)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP25'';

V_STEP_NAME :=  ''Create csat_prev_data_qc'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


CREATE OR REPLACE TABLE  IDENTIFIER(:V_CSAT_PREV_DATA_QC) COPY GRANTS as
select * from IDENTIFIER(:V_CSAT_DATA);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_CSAT_PREV_DATA_QC)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP26'';

V_STEP_NAME :=  ''Create CSAT_DATA'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


CREATE OR REPLACE TABLE  IDENTIFIER(:V_CSAT_DATA) COPY GRANTS AS SELECT * from IDENTIFIER(:V_CSAT_BASE) 
where interview_dt is not null;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_CSAT_DATA)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP27'';

V_STEP_NAME :=  ''Create QC1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE  IDENTIFIER(:V_QC1) COPY GRANTS as
with t1 as(
select yearnumber, monthnumber, slalabel, count(*) as raw_num_records, count(distinct person_id) as raw_mbrs
from IDENTIFIER(:V_FF_CSAT_SURVEY)
group by yearnumber, monthnumber, slalabel),
t2 as (
select yearnumber, monthnumber, slalabel, count(*) as final_num_records, count(distinct person_id) as final_mbrs 
from IDENTIFIER(:V_CSAT_DATA)
group by yearnumber, monthnumber, slalabel
)
select a.yearnumber, a.monthnumber, a.slalabel, raw_num_records, raw_mbrs, final_num_records, final_mbrs
from t1 as a
left join t2 as b
on a.yearnumber=b.yearnumber
and a.monthnumber=b.monthnumber
and a.slalabel=b.slalabel;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_QC1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP28'';

V_STEP_NAME :=  ''Create QC2'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE  IDENTIFIER(:V_QC2) COPY GRANTS as
with t1 as(
select yearnumber, monthnumber, slalabel, count(*) as n_num_records, count(distinct person_id) as n_mbrs
from IDENTIFIER(:V_CSAT_DATA)
group by yearnumber, monthnumber, slalabel),
t2 as (
select yearnumber, monthnumber, slalabel, count(*) as p_num_records, count(distinct person_id) as p_mbrs 
from IDENTIFIER(:V_CSAT_PREV_DATA_QC)
group by yearnumber, monthnumber, slalabel
)
select a.yearnumber, a.monthnumber, a.slalabel, n_num_records, n_mbrs, p_num_records, p_mbrs
from t1 as a
left join t2 as b
on a.yearnumber=b.yearnumber
and a.monthnumber=b.monthnumber
and a.slalabel=b.slalabel;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_QC2)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);


RAISE;

END;

';