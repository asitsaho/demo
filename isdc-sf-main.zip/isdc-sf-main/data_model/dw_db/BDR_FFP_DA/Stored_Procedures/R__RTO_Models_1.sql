--call SP_RTO_MODELS_1('1234','RTO_MODELS','UBLIA_TST_ISDC_DEV_DB','UTIL','BDR_FFP_DA','BDR_FFP_DA_WRK','BDR_SMART','BDR_DM','UBLIA_TST_WORK_XS_WH',CURRENT_DATE())
--call SP_RTO_MODELS_1('1234','RTO_MODELS','UBLIA_TST_ISDC_DEV_DB','UTIL','BDR_FFP_DA','BDR_FFP_DA_WRK','BDR_SMART','BDR_DM','UBLIA_TST_WORK_XS_WH',CURRENT_DATE())

USE SCHEMA BDR_FFP_DA;

CREATE OR REPLACE PROCEDURE SP_RTO_MODELS_1("PIPELINE_ID" VARCHAR(16777216), "PIPELINE_NAME" VARCHAR(16777216), "DB_NAME" VARCHAR(16777216), "UTIL_SC" VARCHAR(16777216), "TGT_SC" VARCHAR(16777216), "FFP_WRK_SC" VARCHAR(16777216), "SRC_SC" VARCHAR(16777216), "ONE_SC" VARCHAR(16777216), "WH" VARCHAR(16777216), "CURR_DATE" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

V_CURRENT_DATE   DATE := COALESCE(TO_DATE(:CURR_DATE), CURRENT_DATE());

V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := :DB_NAME||''.''||COALESCE(:UTIL_SC, ''UTIL'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';

V_PROCESS_NAME   VARCHAR DEFAULT ''RTO MODELS'';

V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''CODE6-CODE10'';

V_STEP             VARCHAR;

V_STEP_NAME        VARCHAR;

V_START_TIME       VARCHAR;

V_END_TIME         VARCHAR;

V_ROWS_PARSED       INTEGER;

V_ROWS_LOADED       INTEGER;

V_MESSAGE          VARCHAR;

V_LAST_QUERY_ID    VARCHAR;



V_INSURED_PLAN_PROFILE VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.INSURED_PLAN_PROFILE'';

V_PERSON_CUSTOMER_TREATMENT  VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.PERSON_CUSTOMER_TREATMENT'';

V_TREATMENT_REFERENCE  VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.TREATMENT_REFERENCE'';
V_TREATMENT_DISPOSITION_REASON  VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.TREATMENT_DISPOSITION_REASON'';

V_PERSON_HCO_CONTACT_REQUEST  VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.PERSON_HCO_CONTACT_REQUEST'';

V_HCO_CONTACT_REASON_TYPE  VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.HCO_CONTACT_REASON_TYPE'';
V_HCO_CONTACT_REASON_SUB_TYPE  VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC, ''BDR_SMART'') || ''.HCO_CONTACT_REASON_SUB_TYPE'';


V_V_F_CLM_BIL_LN_HIST  VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''BDR_DM'') || ''.F_CLM_BIL_LN_HIST'';
V_F_PREM_TRANS_MO  VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''BDR_DM'') || ''.F_PREM_TRANS_MO'';

--Intermediate Tables

V_FFP_EFT_BASE_POP_SYS VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_BASE_POP_PRIV_SS'';

V_EFT_PULL_INSPLAN_PROFILE VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PULL_INSPLAN_PROFILE'';

V_EFT_PULL_INSPLAN_PROFILE_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PULL_INSPLAN_PROFILE_1'';

V_EFT_PULL_INSPLAN_PROFILE_2_SYS VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PULL_INSPLAN_PROFILE_2_PRIV_SS'';
 
V_EFT_TREATMENT_BASE_POP_01 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_TREATMENT_BASE_POP_01'';

V_EFT_TREATMENT_BASE_POP_02 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_TREATMENT_BASE_POP_02'';

V_EFT_TREATMENT_BASE_POP VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_TREATMENT_BASE_POP'';

V_EFT_TREATMENT_BASE_POP_1_SYS VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_TREATMENT_BASE_POP_1_PRIV_SS'';

V_EFT_PULL_CALL_DATA VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PULL_CALL_DATA'';

V_EFT_PULL_CALL_DATA_BASE_POP VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PULL_CALL_DATA_BASE_POP'';

V_EFT_PULL_CALL_DATA_BASE_POP_SYS VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PULL_CALL_DATA_BASE_POP_PRIV_SS'';

V_EFT_PULL_MEDICAL_CLAIMS VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PULL_MEDICAL_CLAIMS'';

V_EFT_CLAIM_BASE_POP_1 VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_CLAIM_BASE_POP_1'';

V_EFT_CLAIM_BASE_POP_2_SYS VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_CLAIM_BASE_POP_2_PRIV_SS'';



V_EFT_PULL_PREM_HIST VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PULL_PREM_HIST'';

V_EFT_PREMIUM_BASE_POP_1_SYS VARCHAR := :DB_NAME || ''.'' || COALESCE(:FFP_WRK_SC, ''BDR_FFP_DA_WRK'') || ''.RTO_MODELS_EFT_PREMIUM_BASE_POP_1_PRIV_SS'';



BEGIN

--insured_plan_profile--

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP1'';

V_STEP_NAME :=  ''create a table EFT_PULL_INSPLAN_PROFILE'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EFT_PULL_INSPLAN_PROFILE) as
select distinct a.PERSON_ID,a.individual_id,a.actual_drop_date,b.DISABLED_IND,b.SMOKER_IND,b.ADJUSTED_BASE_TYPE_CODE,b.BEGIN_DATE,b.END_DATE,b.GROUP_PLAN_ID,b.GROUP_PLAN_TYPE_ID,b.INSURED_PLAN_ID,b.INSURED_PLAN_PROFILE_ID,
b.LOYALTY_PROGRAM_CODE,b.RATE_DETERMINATION_CODE
from IDENTIFIER(:V_FFP_EFT_BASE_POP_SYS) a inner join IDENTIFIER(:V_INSURED_PLAN_PROFILE) b
on a.person_id=b.person_id
where (b.BEGIN_DATE <= a.actual_drop_date) and ( b.END_DATE is null or b.END_DATE is null or b.END_DATE >= a.actual_drop_date);



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EFT_PULL_INSPLAN_PROFILE)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP2'';

V_STEP_NAME :=  ''create a table EFT_PULL_INSPLAN_PROFILE_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EFT_PULL_INSPLAN_PROFILE_1) as
select * from IDENTIFIER(:V_EFT_PULL_INSPLAN_PROFILE)
order by person_id, actual_drop_date, begin_date,INSURED_PLAN_ID;



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EFT_PULL_INSPLAN_PROFILE_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP3'';

V_STEP_NAME :=  ''create a table EFT_PULL_INSPLAN_PROFILE_2_SYS'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EFT_PULL_INSPLAN_PROFILE_2_SYS) as
select * EXCLUDE ROW_NUM FROM (select *
from
(select *,ROW_NUMBER() OVER (PARTITION BY PERSON_ID order by actual_drop_date desc , begin_date desc , INSURED_PLAN_ID desc ) AS ROW_NUM from IDENTIFIER(:V_EFT_PULL_INSPLAN_PROFILE_1)) as a where a.row_num=1);



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EFT_PULL_INSPLAN_PROFILE_2_SYS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


--Treatment----

V_STEP := ''STEP4'';

V_STEP_NAME :=  ''create a table EFT_TREATMENT_BASE_POP_01'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EFT_TREATMENT_BASE_POP_01) as
select distinct a.person_id,
a.individual_id,
a.actual_drop_date, 
pct.person_customer_treatment_id,
pct.treatment_reference_id,
pct.treatment_action,
pct.treatment_disposition_reason_id,
pct.date_treatment_offered,
pct.account_number,
pct.first_name,
pct.last_name,
pct.address_line_1,
pct.address_line_2,
pct.city_name,
pct.state_code,
pct.zip_code,
pct.zip_code_plus_4,
pct.country,
pct.email_address,
pct.phone_number_home,
pct.birth_date,
pct.tfn,
pct.row_ins_timestamp,
tr.treatment_name,
tr.treatment_code,
tdr.treatment_disposition_reason_name
from IDENTIFIER(:V_FFP_EFT_BASE_POP_SYS) a inner join IDENTIFIER(:V_PERSON_CUSTOMER_TREATMENT) pct
on a.person_id=pct.person_id
left join IDENTIFIER(:V_TREATMENT_REFERENCE) tr
on pct.TREATMENT_REFERENCE_ID = tr.TREATMENT_REFERENCE_ID
left join IDENTIFIER(:V_TREATMENT_DISPOSITION_REASON) tdr
on pct.TREATMENT_DISPOSITION_REASON_ID = tdr.TREATMENT_DISPOSITION_REASON_ID
where a.actual_drop_date  > pct.date_treatment_offered and a.actual_drop_date  < dateadd(''DAY'',365,pct.date_treatment_offered) AND 
trim(pct.treatment_action) = ''PRESENTED''
order by INDIVIDUAL_ID, ACTUAL_DROP_DATE ,person_customer_treatment_id ;



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EFT_TREATMENT_BASE_POP_01)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP5'';

V_STEP_NAME :=  ''create a table EFT_TREATMENT_BASE_POP_02'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EFT_TREATMENT_BASE_POP_02) as
select * EXCLUDE ROW_NUM  from (
select * 
from
(select *,ROW_NUMBER() OVER (PARTITION BY INDIVIDUAL_ID, ACTUAL_DROP_DATE,person_customer_treatment_id order by ACTUAL_DROP_DATE desc ) AS ROW_NUM from IDENTIFIER(:V_EFT_TREATMENT_BASE_POP_01)) as a where a.row_num=1);




V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EFT_TREATMENT_BASE_POP_02)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

V_STEP := ''STEP6'';

V_STEP_NAME :=  ''create a table EFT_TREATMENT_BASE_POP'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EFT_TREATMENT_BASE_POP) as
select * , 
case when ( trim(TREATMENT_CODE) = ''AT YOUR BEST'' and TREATMENT_DISPOSITION_REASON_NAME in (''NOT INTERESTED'')) THEN 1
else 0 end as At_Your_Best_Negative,
case when (trim(TREATMENT_CODE) = ''AT YOUR BEST'' and TREATMENT_DISPOSITION_REASON_NAME in (''PROGRAM OVERVIEW'', ''PROGRAM OVERVIEW-INTEREST'', ''PROGRAM OVERVIEW-NO INTEREST'', 
''PROVIDED TOLL FREE NUMBER'', ''TRANSFER TO TRAINED REP'')) THEN 1
else 0 end as At_Your_Best_Positive,
case when (trim(TREATMENT_CODE) = ''EFT WEB PROMOTION'' and TREATMENT_DISPOSITION_REASON_NAME in (''NEVER PROMPT AGAIN'', ''NOT INTERESTED'')) THEN 1
else 0 end as EFT_WEB_PROMO_Negative,
case when( trim(TREATMENT_CODE) = ''EFT WEB PROMOTION'' and TREATMENT_DISPOSITION_REASON_NAME in (''EFT BROCHURE SENT'', ''MAILED EFT SET UP'', ''PROVIDED WEB URL'')) THEN 1
else 0 end as  EFT_WEB_PROMO_Positive,
case when (trim(TREATMENT_CODE) = ''HEALTH AND WELLNESS RESOURCES IM'' and TREATMENT_DISPOSITION_REASON_NAME in (''NEVER PROMPT AGAIN'')) THEN 1 
else 0 end as Heal_Well_res_Negative,
case when ( trim(TREATMENT_CODE) = ''HEALTH AND WELLNESS RESOURCES IM'' and TREATMENT_DISPOSITION_REASON_NAME in (''ACTIVATE FITNESS MEMBERSHIP'',
''LOCAL PROGRAMS/EVENTS'',
''LOCATING A FITNESS CENTER'',
''PROGRAM OVERVIEW'',
''WELLNESS COACH TRANSFER'',
''WELLNESS WEBSITE OVERVIEW''
))
THEN 1 
else 0 end as Heal_Well_res_Positive,
case when (trim(TREATMENT_CODE) = ''MEDICARE EDUCATION'' and TREATMENT_DISPOSITION_REASON_NAME in (''NOT AT THIS TIME'')) THEN 1 else 0 end as MED_ED_Negative,
case when (trim(TREATMENT_CODE) = ''MEDICARE EDUCATION'' and TREATMENT_DISPOSITION_REASON_NAME in (''PROVIDED EDUCATION'')) THEN 1 else 0 end as MED_ED_Positive,
case when( trim(TREATMENT_CODE) = ''MEDICARE EDUCATION'' and TREATMENT_DISPOSITION_REASON_NAME in (''UNDERSTANDS MEDICARE'')) THEN 1 else 0 end as MED_ED_Neutral
from
IDENTIFIER(:V_EFT_TREATMENT_BASE_POP_02);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EFT_TREATMENT_BASE_POP)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP7'';

V_STEP_NAME :=  ''create a table EFT_TREATMENT_BASE_POP_1_SYS'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EFT_TREATMENT_BASE_POP_1_SYS) as
select
INDIVIDUAL_ID, PERSON_ID, actual_drop_date,
count(distinct case when UTIL.DATE_DIFF_UDF(actual_drop_date,date_treatment_offered) < 90 THEN person_customer_treatment_id  end ) as no_treatment_3_mnths,
count(distinct case when UTIL.DATE_DIFF_UDF(actual_drop_date,date_treatment_offered) < 180 THEN person_customer_treatment_id  end ) as no_treatment_6_mnths,
count(distinct person_customer_treatment_id) as no_treatment,



--/*eDUCATION TO MEDICARE*/
count(distinct case when UTIL.DATE_DIFF_UDF(actual_drop_date,date_treatment_offered) < 90 and trim(treatment_code) = ''EDUCATION OF MEDICARE'' and trim(treatment_action) = ''PRESENTED'' THEN person_customer_treatment_id  end ) 
as no_pres_MCARE_EDU_3_mnths,
count(distinct case when UTIL.DATE_DIFF_UDF(actual_drop_date,date_treatment_offered) < 180 and trim(treatment_code) = ''EDUCATION OF MEDICARE'' and trim(treatment_action) = ''PRESENTED'' THEN person_customer_treatment_id  end ) 
as no_pres_MCARE_EDU_6_mnths,
count(distinct case when trim(treatment_code) = ''EDUCATION OF MEDICARE'' and trim(treatment_action) = ''PRESENTED'' THEN person_customer_treatment_id  end ) 
as no_pres_MCARE_EDU,


--/*PRIVACY AUTHORIZATION*/
count(distinct case when UTIL.DATE_DIFF_UDF(actual_drop_date,date_treatment_offered) < 90 and trim(treatment_code) = ''PRIVACY AUTHORIZATION'' and trim(treatment_action) = ''PRESENTED'' THEN person_customer_treatment_id  end ) 
as no_pres_PRIV_AUTH_3_mnths,
count(distinct case when UTIL.DATE_DIFF_UDF(actual_drop_date,date_treatment_offered) < 180 and trim(treatment_code) = ''PRIVACY AUTHORIZATION'' and trim(treatment_action) = ''PRESENTED'' THEN person_customer_treatment_id  end ) 
as no_pres_PRIV_AUTH_6_mnths,
count(distinct case when trim(treatment_code) = ''PRIVACY AUTHORIZATION'' and trim(treatment_action) = ''PRESENTED'' THEN person_customer_treatment_id  end ) 
as no_pres_PRIV_AUTH,

--/*PRIVACY CAREGIVER TREATMENT*/
count(distinct case when UTIL.DATE_DIFF_UDF(actual_drop_date,date_treatment_offered) < 90 and trim(treatment_code) = ''PRIVACY CAREGIVER TREATMENT'' and trim(treatment_action) = ''PRESENTED'' THEN person_customer_treatment_id end ) 
as no_pres_PRIV_CRGIVER_3_mnths,
count(distinct case when UTIL.DATE_DIFF_UDF(actual_drop_date,date_treatment_offered) < 180 and trim(treatment_code) = ''PRIVACY CAREGIVER TREATMENT'' and trim(treatment_action) = ''PRESENTED'' THEN person_customer_treatment_id end ) 
as no_pres_PRIV_CRGIVER_6_mnths,
count(distinct case when trim(treatment_code) = ''PRIVACY CAREGIVER TREATMENT'' and trim(treatment_action) = ''PRESENTED'' THEN person_customer_treatment_id  end ) 
as no_pres_PRIV_CRGIVER,

--/*WEB REGISTRATION*/
count(distinct case when UTIL.DATE_DIFF_UDF(actual_drop_date,date_treatment_offered) < 90 and trim(treatment_code) = ''WEB REGISTRATION'' and trim(treatment_action) = ''PRESENTED'' THEN person_customer_treatment_id  end ) 
as no_pres_WEB_REG_3_mnths,
count(distinct case when UTIL.DATE_DIFF_UDF(actual_drop_date,date_treatment_offered) < 180 and trim(treatment_code) = ''WEB REGISTRATION'' and trim(treatment_action) = ''PRESENTED'' THEN person_customer_treatment_id  end ) 
as no_pres_WEB_REG_6_mnths,
count(distinct case when trim(treatment_code) = ''WEB REGISTRATION'' and trim(treatment_action) = ''PRESENTED'' THEN person_customer_treatment_id  end ) 
as no_pres_WEB_REG,

--/*Presented positive*/
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,date_treatment_offered) < 90 THEN At_Your_Best_Positive  end) as At_Your_Best_Pos_3_months,
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,date_treatment_offered) < 180 THEN At_Your_Best_Positive  end) as At_Your_Best_Pos_6_months,
sum(At_Your_Best_Positive) as At_Your_Best_Positive,

sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,date_treatment_offered) < 90 THEN At_Your_Best_Negative  end) as At_Your_Best_Neg_3_months,
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,date_treatment_offered) < 180 THEN At_Your_Best_Negative  end) as At_Your_Best_Neg_6_months,
sum(At_Your_Best_Negative) as At_Your_Best_Negative,

sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,date_treatment_offered) < 90 THEN EFT_WEB_PROMO_Negative  end) as EFT_WEB_PROMO_Neg_3_months,
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,date_treatment_offered) < 180 THEN EFT_WEB_PROMO_Negative  end) as EFT_WEB_PROMO_Neg_6_months,
sum(EFT_WEB_PROMO_Negative) as EFT_WEB_PROMO_Negative,

sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,date_treatment_offered) < 90 THEN EFT_WEB_PROMO_Positive  end) as EFT_WEB_PROMO_Pos_3_months,
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,date_treatment_offered) < 180 THEN EFT_WEB_PROMO_Positive  end) as EFT_WEB_PROMO_Pos_6_months,
sum(EFT_WEB_PROMO_Positive) as EFT_WEB_PROMO_Positive,

sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,date_treatment_offered) < 90 THEN Heal_Well_res_Negative  end) as Heal_Well_res_Neg_3_months,
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,date_treatment_offered) < 180 THEN Heal_Well_res_Negative  end) as Heal_Well_res_Neg_6_months,
sum(Heal_Well_res_Negative) as Heal_Well_res_Negative,

sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,date_treatment_offered) < 90 THEN Heal_Well_res_Positive  end) as Heal_Well_res_Pos_3_months,
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,date_treatment_offered) < 180 THEN Heal_Well_res_Positive  end) as Heal_Well_res_Pos_6_months,
sum(Heal_Well_res_Positive) as Heal_Well_res_Positive,

sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,date_treatment_offered) < 90 THEN MED_ED_Negative  end) as MED_ED_Neg_3_months,
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,date_treatment_offered) < 180 THEN MED_ED_Negative  end) as MED_ED_Neg_6_months,
sum(MED_ED_Negative) as MED_ED_Negative,

sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,date_treatment_offered) < 90 THEN MED_ED_Positive  end) as MED_ED_Pos_3_months,
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,date_treatment_offered) < 180 THEN MED_ED_Positive  end) as MED_ED_Pos_6_months,
sum(MED_ED_Positive) as MED_ED_Positive,

sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,date_treatment_offered) < 90 THEN MED_ED_Neutral  end) as MED_ED_Neut_3_months,
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,date_treatment_offered) < 180 THEN MED_ED_Neutral  end) as MED_ED_Neut_6_months,
sum(MED_ED_Neutral) as MED_ED_Neutral

from IDENTIFIER(:V_EFT_TREATMENT_BASE_POP) group by INDIVIDUAL_ID, PERSON_ID, actual_drop_date;



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EFT_TREATMENT_BASE_POP_1_SYS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

--/*--------------------------CALL_Data--------------------*/
V_STEP := ''STEP8'';

V_STEP_NAME :=  ''create a table EFT_PULL_CALL_DATA'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EFT_PULL_CALL_DATA) as
select distinct d.person_id, d.individual_id, d.actual_drop_date, 
a.hco_contact_request_id,
a.lob_code,
a.hco_contact_rsn_type_code,
a.hco_contact_rsn_sub_type_code,
a.contact_date,
a.contact_time,
a.inquiry_type,
a.source_opportunity_id,
a.account,
a.source_code,
a.sales_method,
a.channel_code,
a.hco_contact_desc,
a.op_disposition_id,
a.op_disposition_reason_id,
a.title_prefix,
a.first_name,
a.middle_name,
a.last_name,
a.birth_date,
a.gender_code,
a.account_number,
a.address_line_1,
a.address_line_2,
a.city_name,
a.state_code,
a.zip_code,
a.zip_code_plus_4,
a.phone_number_work,
a.phone_number_home,
a.email_address,
a.hco_contact_status,
a.hco_contact_update_date,
a.hco_contact_update_time,
a.hco_contact_source,
a.hco_contact_source_in_out,
a.hco_contact_source_type,
a.sales_stage,
a.tfn,
a.current_coverage_id,
a.medb_date,
a.desired_effective_date,
a.fulfillment_channel_code,
a.row_ins_timestamp,
a.initiating_vendor_id,
a.transfer_source_code,
a.meda_date,
a.source_response_id,
a.optum_unique_call_id,
a.vendor_code,
a.interaction_date,
a.interaction_time,
a.ani,
a.dcb_flag,
a.opportunity_record_type,
b.hco_contact_rsn_type_name,
b.row_updt_timestamp,
c.hco_contact_rsn_sub_type_name	
from IDENTIFIER(:V_FFP_EFT_BASE_POP_SYS) d inner join IDENTIFIER(:V_PERSON_HCO_CONTACT_REQUEST) a
on d.person_id=a.person_id
left join IDENTIFIER(:V_HCO_CONTACT_REASON_TYPE) b
on a.HCO_CONTACT_RSN_TYPE_CODE=b.HCO_CONTACT_RSN_TYPE_CODE
left join IDENTIFIER(:V_HCO_CONTACT_REASON_SUB_TYPE) c
on a.HCO_CONTACT_RSN_SUB_TYPE_CODE=c.HCO_CONTACT_RSN_SUB_TYPE_CODE
where d.actual_drop_date> a.contact_date and d.actual_drop_date< dateadd(''day'',365,a.contact_date);



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EFT_PULL_CALL_DATA)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP9'';

V_STEP_NAME :=  ''create a table EFT_PULL_CALL_DATA_BASE_POP'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EFT_PULL_CALL_DATA_BASE_POP) as
select *, 
case when trim(upper(HCO_CONTACT_RSN_TYPE_NAME)) = ''PLAN INQUIRY'' then 1 ELSE 0 end as PLAN_INQ,
case when trim(upper(HCO_CONTACT_RSN_TYPE_NAME)) = ''BILLING/PAYMENT INQUIRY'' then 1 ELSE 0 end as BILL_PAY_INQ,
case when trim(upper(HCO_CONTACT_RSN_TYPE_NAME)) = ''CLAIM INQUIRY'' then 1 ELSE 0 end as CLAIM_INQ,
case when trim(upper(HCO_CONTACT_RSN_TYPE_NAME)) = ''TELEMARKETING'' then 1 ELSE 0 end as TELEMARKETING_INQ,
case when trim(upper(HCO_CONTACT_RSN_TYPE_NAME)) = ''OPPORTUNITY'' then 1 ELSE 0 end as OPPRTNTY_INQ
from IDENTIFIER(:V_EFT_PULL_CALL_DATA);




V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EFT_PULL_CALL_DATA_BASE_POP)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



V_STEP := ''STEP10'';

V_STEP_NAME :=  ''create a table EFT_PULL_CALL_DATA_BASE_POP_SYS'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EFT_PULL_CALL_DATA_BASE_POP_SYS) as
select
INDIVIDUAL_ID, PERSON_ID, actual_drop_date,
count(distinct case when UTIL.DATE_DIFF_UDF(actual_drop_date,contact_date) < 90 THEN HCO_CONTACT_REQUEST_ID  end ) as no_calls_3_mnths,
count(distinct case when UTIL.DATE_DIFF_UDF(actual_drop_date,contact_date) < 180 THEN HCO_CONTACT_REQUEST_ID  end ) as no_calls_6_mnths,
count(distinct HCO_CONTACT_REQUEST_ID) as no_calls,

sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,contact_date) < 90 THEN BILL_PAY_INQ  end ) as BILL_PAY_INQ_call_3_mnths,
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,contact_date) < 180 THEN BILL_PAY_INQ  end ) as BILL_PAY_INQ_call_6_mnths,
sum(BILL_PAY_INQ) as BILL_PAY_INQ_call,

sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,contact_date) < 90 THEN CLAIM_INQ  end ) as CLAIM_INQ_call_3_mnths,
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,contact_date) < 180 THEN CLAIM_INQ  end ) as CLAIM_INQ_call_6_mnths,
sum(CLAIM_INQ) as CLAIM_INQ_call,

sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,contact_date) < 90 THEN TELEMARKETING_INQ  end ) as TELEMARKETING_INQ_call_3_mnths,
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,contact_date) < 180 THEN TELEMARKETING_INQ  end ) as TELEMARKETING_INQ_call_6_mnths,
sum(TELEMARKETING_INQ) as TELEMARKETING_INQ_call,

sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,contact_date) < 90 THEN OPPRTNTY_INQ  end ) as OPPRTNTY_INQ_call_3_mnths,
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,contact_date) < 180 THEN OPPRTNTY_INQ  end ) as OPPRTNTY_INQ_call_6_mnths,
sum(OPPRTNTY_INQ) as OPPRTNTY_INQ_call,

sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,contact_date) < 90 THEN PLAN_INQ  end ) as PLAN_INQ_call_3_mnths,
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,contact_date) < 180 THEN PLAN_INQ  end ) as PLAN_INQ_call_6_mnths,
sum(PLAN_INQ) as PLAN_INQ_call
from IDENTIFIER(:V_EFT_PULL_CALL_DATA_BASE_POP) group by INDIVIDUAL_ID, PERSON_ID, actual_drop_date;



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EFT_PULL_CALL_DATA_BASE_POP_SYS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


--/*----------------------f_oprec_bill_line,d_cpt,zip_key,d_plan,B_ICD/D_ICD,D_DISCOUNT/D_SMOKER_DISCOUNT/D_SPOUSAL_DISCOUNT/D_LOYALTY_DISCOUNT-------------------------*/


V_STEP := ''STEP11'';

V_STEP_NAME :=  ''create a table EFT_PULL_MEDICAL_CLAIMS'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EFT_PULL_MEDICAL_CLAIMS) as
select distinct 
b.person_id,
b.actual_drop_date,
b.account_number,
a01.CLM_PD_DT_ID, 
a01.CLM_PD_DT_ID as Extract_key,
cast(a01.CLM_PD_DT_ID as string)  as Extract_key_1,
substr(cast(a01.CLM_PD_DT_ID as string),7,2) as Extract_key_1_day,
substr(cast(a01.CLM_PD_DT_ID as string),5,2) as Extract_key_1_month,
substr(cast(a01.CLM_PD_DT_ID as string),1,4) as Extract_key_1_year, 
concat(trim(substr(cast(a01.CLM_PD_DT_ID as string),5,2)),
trim(substr(cast(a01.CLM_PD_DT_ID as string),7,2)),
trim(substr(cast(a01.CLM_PD_DT_ID as string),1,4))) as Extract_key_2,
cast(concat(trim(substr(cast(a01.CLM_PD_DT_ID as string),1,4)),''-'',trim(substr(cast(a01.CLM_PD_DT_ID as string),5,2)),''-'',trim(substr(cast(a01.CLM_PD_DT_ID as string),7,2))) as date) as Extract_key_3 ,
a01.CLM_NBR,
a01.BEN_AMT,
a01.ADJ_BEN_AMT,
a01.CHRG_AMT,
a01.PART_B_DED_AMT,
a01.INCUR_DT_ID,
a01.COV_EXPN_AMT,
a01.MEDCR_PD_AMT,
a01.SRVC_FROM_DT_ID,
a01.TEMP_INCUR_DT_ID,
a01.MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
a01.SRVC_TO_DT_ID,
a01.AARP_DED_AMT,
a01.BIL_LN_NBR,
a01.MEDCR_APRV_AMT,
a01.OOP_AMT,
a01.BEN_PRD_DAY
from IDENTIFIER(:V_FFP_EFT_BASE_POP_SYS) b 
inner join IDENTIFIER(:V_V_F_CLM_BIL_LN_HIST) a01
--inner join rrani13.v_f_clm_bil_ln_hist a01
on a01.ACCT_NBR = b.account_number 
where b.actual_drop_date > TRY_TO_DATE(concat(trim(substr(cast(a01.CLM_PD_DT_ID as string),1,4)),''-'',trim(substr(cast(a01.CLM_PD_DT_ID as string),5,2)),''-'',trim(substr(cast(a01.CLM_PD_DT_ID as string),7,2)))) and b.actual_drop_date < dateadd(''day'',365,TRY_TO_DATE(concat(trim(substr(cast(a01.CLM_PD_DT_ID as string),1,4)),''-'',trim(substr(cast(a01.CLM_PD_DT_ID as string),5,2)),''-'',trim(substr(cast(a01.CLM_PD_DT_ID as string),7,2)))));



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EFT_PULL_MEDICAL_CLAIMS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP12'';

V_STEP_NAME :=  ''create a table EFT_CLAIM_BASE_POP_1'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EFT_CLAIM_BASE_POP_1) as
select 
PERSON_ID, actual_drop_date, Extract_key_3, CLM_NBR,
count(distinct CLM_NBR) as no_claims,
sum(OOP_AMT) as OUT_OF_POCKET_AMT,
sum(PART_B_DED_AMT) as PART_B_DEDUCT,
sum(BEN_AMT) as BENEFIT_AMT,
sum(CHRG_AMT) as CHARGE_AMT,
sum(AARP_DED_AMT) as DEDUCTIBLE_AMT,
sum(MEDCR_APRV_AMT) as MEDICARE_APPROVED_AMT,
sum(MEDCR_PD_AMT) as MEDICARE_PAYMENT_AMT,
sum(BEN_PRD_DAY) as benefit_period_days,
sum(ADJ_BEN_AMT) as ADJUST_BENEFIT_AMOUNT,
sum(COV_EXPN_AMT) as COVERED_EXPENSE
from IDENTIFIER(:V_EFT_PULL_MEDICAL_CLAIMS) group by  PERSON_ID, actual_drop_date, Extract_key_3,CLM_NBR;



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EFT_CLAIM_BASE_POP_1)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP13'';

V_STEP_NAME :=  ''create a table EFT_CLAIM_BASE_POP_2_SYS'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EFT_CLAIM_BASE_POP_2_SYS) as
select
PERSON_ID, actual_drop_date,
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 90 THEN no_claims::number(38,14) end ) as no_claims_3_mnths,
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 180 THEN no_claims::number(38,14) end ) as no_claims_6_mnths,
sum(no_claims::number(38,14)) as no_claims,

sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 90 THEN PART_B_DEDUCT::number(38,14) end ) as PART_B_DEDUCT_3_mnths,
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 180 THEN PART_B_DEDUCT::number(38,14) end ) as PART_B_DEDUCT_6_mnths,
sum(PART_B_DEDUCT::number(38,14)) as PART_B_DEDUCT,
avg(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 90 THEN PART_B_DEDUCT::number(38,14)  end ) as avg_PART_B_DEDUCT_3_mnths,
avg(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 180 THEN PART_B_DEDUCT::number(38,14)  end ) as avg_PART_B_DEDUCT_6_mnths,
avg(PART_B_DEDUCT::number(38,14)) as avg_PART_B_DEDUCT,

sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 90 THEN OUT_OF_POCKET_AMT::number(38,14) end ) as OOP_amount_3_mnths,
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 180 THEN OUT_OF_POCKET_AMT::number(38,14) end ) as OOP_amount_6_mnths,
sum(OUT_OF_POCKET_AMT::number(38,14)) as OOP_amount,
avg(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 90 THEN OUT_OF_POCKET_AMT::number(38,14) end ) as avg_OOP_amount_3_mnths,
avg(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 180 THEN OUT_OF_POCKET_AMT::number(38,14) end ) as avg_OOP_amount_6_mnths,
avg(OUT_OF_POCKET_AMT::number(38,14)) as avg_OOP_amount,

sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 90 THEN ADJUST_BENEFIT_AMOUNT::number(38,14)  end ) as ADJUST_BENEFIT_AMOUNT_3_mnths,
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 180 THEN ADJUST_BENEFIT_AMOUNT::number(38,14) end ) as ADJUST_BENEFIT_AMOUNT_6_mnths,
sum(ADJUST_BENEFIT_AMOUNT::number(38,14)) as ADJUST_BENEFIT_AMOUNT,
avg(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 90 THEN ADJUST_BENEFIT_AMOUNT::number(38,14) end ) as avg_ADJUST_BENEFIT_AMT_3_mnths,
avg(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 180 THEN ADJUST_BENEFIT_AMOUNT::number(38,14) end ) as avg_ADJUST_BENEFIT_AMT_6_mnths,
avg(ADJUST_BENEFIT_AMOUNT::number(38,14)) as avg_ADJUST_BENEFIT_AMOUNT,

sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 90 THEN BENEFIT_AMT::number(38,14)  end ) as Benefit_amount_3_mnths,/*not required*/
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 180 THEN BENEFIT_AMT::number(38,14) end ) as Benefit_amount_6_mnths,
sum(BENEFIT_AMT::number(38,14)) as Benefit_amount_12_mnths,
avg(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 90 THEN BENEFIT_AMT::number(38,14)  end ) as avg_Benefit_amount_3_mnths,
avg(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 180 THEN BENEFIT_AMT::number(38,14)  end ) as avg_Benefit_amount_6_mnths,
avg(BENEFIT_AMT::number(38,14)) as avg_Benefit_amount,

sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 90 THEN COVERED_EXPENSE::number(38,14)  end ) as COVERED_EXPENSE_3_mnths,
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 180 THEN COVERED_EXPENSE::number(38,14)  end ) as COVERED_EXPENSE_6_mnths,
sum(COVERED_EXPENSE::number(38,14)) as tot_COVERED_EXPENSE,
avg(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3) < 90 THEN COVERED_EXPENSE::number(38,14)  end ) as avg_COVERED_EXPENSE_3_mnths,
avg(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3) < 180 THEN COVERED_EXPENSE::number(38,14)  end ) as avg_COVERED_EXPENSE_6_mnths,
avg(COVERED_EXPENSE::number(38,14)) as avg_tot_COVERED_EXPENSE,

sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 90 THEN CHARGE_AMT::number(38,14)  end ) as CHARGE_amount_3_mnths,
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 180 THEN CHARGE_AMT::number(38,14)  end ) as CHARGE_amount_6_mnths,
sum(CHARGE_AMT::number(38,14)) as CHARGE_amount,
avg(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 90 THEN CHARGE_AMT::number(38,14)  end ) as avg_CHARGE_amount_3_mnths,
avg(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 180 THEN CHARGE_AMT::number(38,14)  end ) as avg_CHARGE_amount_6_mnths,
avg(CHARGE_AMT::number(38,14)) as avg_CHARGE_amount,


sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 90 THEN DEDUCTIBLE_AMT::number(38,14)  end ) as DEDUCTIBLE_amount_3_mnths,
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 180 THEN DEDUCTIBLE_AMT::number(38,14)  end ) as DEDUCTIBLE_amount_6_mnths,
sum(DEDUCTIBLE_AMT::number(38,14)) as DEDUCTIBLE_amount,
avg(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 90 THEN DEDUCTIBLE_AMT::number(38,14)  end ) as avg_DEDUCTIBLE_amount_3_mnths,
avg(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 180 THEN DEDUCTIBLE_AMT::number(38,14)  end ) as avg_DEDUCTIBLE_amount_6_mnths,
avg(DEDUCTIBLE_AMT::number(38,14)) as avg_DEDUCTIBLE_amount,

sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 90 THEN MEDICARE_APPROVED_AMT::number(38,14)  end ) as MEDICARE_APP_amount_3_mnths,
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 180 THEN MEDICARE_APPROVED_AMT::number(38,14)  end ) as MEDICARE_APP_amount_6_mnths,
sum(MEDICARE_APPROVED_AMT::number(38,14)) as MEDICARE_APP_amount,
avg(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 90 THEN MEDICARE_APPROVED_AMT::number(38,14)  end ) as avg_MEDICARE_APP_amount_3_mnths,
avg(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 180 THEN MEDICARE_APPROVED_AMT::number(38,14)  end ) as avg_MEDICARE_APP_amount_6_mnths,
avg(MEDICARE_APPROVED_AMT::number(38,14)) as avg_MEDICARE_APP_amount,

sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 90 THEN MEDICARE_PAYMENT_AMT::number(38,14)  end ) as MEDICARE_PAY_amount_3_mnths,
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 180 THEN MEDICARE_PAYMENT_AMT::number(38,14)  end ) as MEDICARE_PAY_amount_6_mnths,
sum(MEDICARE_PAYMENT_AMT::number(38,14)) as MEDICARE_PAY_amount_12_mnths,
avg(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 90 THEN MEDICARE_PAYMENT_AMT::number(38,14)  end ) as avg_MEDICARE_PAY_amount_3_mnths,
avg(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 180 THEN MEDICARE_PAYMENT_AMT::number(38,14)  end ) as avg_MEDICARE_PAY_amount_6_mnths,
avg(MEDICARE_PAYMENT_AMT::number(38,14)) as avg_MEDICARE_PAY_amount,

sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 90 THEN benefit_period_days::number(38,14)  end ) as benefit_period_days_3_mnths,
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,Extract_key_3)::number(38,14) < 180 THEN benefit_period_days::number(38,14)  end ) as benefit_period_days_6_mnths,
sum(benefit_period_days::number(38,14)) as benefit_period_days_12_mnths  
from IDENTIFIER(:V_EFT_CLAIM_BASE_POP_1) group by PERSON_ID, actual_drop_date;



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EFT_CLAIM_BASE_POP_2_SYS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


--/*------------------------------------ Premium ------------------------------------*/

V_STEP := ''STEP14'';

V_STEP_NAME :=  ''create a table EFT_PULL_PREM_HIST'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EFT_PULL_PREM_HIST) as
select distinct b.person_id,b.actual_drop_date,
a.PREM_DUE_MO_ID,
a.PREM_DUE_MO_ID as premium_due_month,
cast(a.PREM_DUE_MO_ID as string) prem_due_date,
substr(cast(PREM_DUE_MO_ID as string),5,2) as prem_due_month,
substr(cast(PREM_DUE_MO_ID as string),1,4) as prem_due_year,
concat(trim(substr(cast(PREM_DUE_MO_ID as string),5,2)),''15'', trim(substr(cast(PREM_DUE_MO_ID as string),1,4))) as premium_date,
cast(concat(trim(substr(cast(PREM_DUE_MO_ID as string),1,4)),''-'',trim(substr(cast(PREM_DUE_MO_ID as string),5,2)),''-'',''15'') as date) as prem_due_date_1,
a.DSCNT_PD_ANNL_PAYR_AMT,
a.D_MBR_INFO_SK,
a.D_DSCNT_ANNL_PAYR_SK,
a.DSCNT_PD_EFT_AMT,
a.DSCNT_PD_LNGVTY_AMT,
a.MBR_PD_PREM_AMT,
a.D_PLN_BEN_MOD_SK,
a.CERT_EFF_MO_ID,
a.PLN_ISS_D_GEO_XREF_SK,
a.CERT_TRM_MO_ID,
a.DSCNT_PD_MULTI_INSD_AMT,
a.TERM_CERT_QTY,
a.EMP_PD_PREM_AMT,
a.MBR_DELQ_PREM_AMT,
a.PD_PREM_AMT,
a.D_CERT_ACTV_SK,
a.D_UNDWR_TAG_SK,
a.PD_CERT_QTY,
a.ACTV_MO_ID
from IDENTIFIER(:V_FFP_EFT_BASE_POP_SYS) b
 inner join IDENTIFIER(:V_F_PREM_TRANS_MO) a
-- inner join rrani13.v_f_prem_trans_mo a

on a.ACCT_NBR = b.account_number
where b.actual_drop_date > cast(concat(trim(substr(cast(PREM_DUE_MO_ID as string),1,4)),''-'',trim(substr(cast(PREM_DUE_MO_ID as string),5,2)),''-'',''15'') as date) and b.actual_drop_date < dateadd(''day'',365,cast(concat(trim(substr(cast(PREM_DUE_MO_ID as string),1,4)),''-'',trim(substr(cast(PREM_DUE_MO_ID as string),5,2)),''-'',''15'') as date));



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EFT_PULL_PREM_HIST)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);



V_STEP := ''STEP15'';

V_STEP_NAME :=  ''create a table EFT_PREMIUM_BASE_POP_1_SYS'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_EFT_PREMIUM_BASE_POP_1_SYS) as
select
PERSON_ID, actual_drop_date,
count(distinct case when UTIL.DATE_DIFF_UDF(actual_drop_date,prem_due_date_1) < 90 THEN PREM_DUE_MO_ID end ) as no_premium_3_mnths,
count(distinct case when UTIL.DATE_DIFF_UDF(actual_drop_date,prem_due_date_1) < 180 THEN PREM_DUE_MO_ID end ) as no_premium_6_mnths,
count(distinct PREM_DUE_MO_ID) as no_premium,
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,prem_due_date_1)::number(38,14) < 90 THEN DSCNT_PD_ANNL_PAYR_AMT::number(38,14)  end ) as Annual_payor_disc_amt_3_mnths,
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,prem_due_date_1)::number(38,14) < 180 THEN DSCNT_PD_ANNL_PAYR_AMT::number(38,14)  end ) as Annual_payor_disc_amt_6_mnths,
sum(DSCNT_PD_ANNL_PAYR_AMT::number(38,14)) as tot_Annual_payor_disc_amt,

sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,prem_due_date_1)::number(38,14) < 90 THEN DSCNT_PD_EFT_AMT::number(38,14)  end ) as tot_EFT_disc_amount_3_mnths,
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,prem_due_date_1)::number(38,14) < 180 THEN DSCNT_PD_EFT_AMT::number(38,14)  end ) as tot_EFT_disc_amount_6_mnths,
sum(DSCNT_PD_EFT_AMT::number(38,14)) as tot_EFT_disc_amount,

sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,prem_due_date_1)::number(38,14) < 90 THEN DSCNT_PD_LNGVTY_AMT::number(38,14)  end ) as tot_loyalty_disc_amount_3_mnths,
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,prem_due_date_1)::number(38,14) < 180 THEN DSCNT_PD_LNGVTY_AMT::number(38,14)  end ) as tot_loyalty_disc_amount_6_mnths,
sum(DSCNT_PD_LNGVTY_AMT::number(38,14)) as tot_loyalty_disc_amount,

sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,prem_due_date_1)::number(38,14) < 90 THEN PD_PREM_AMT::number(38,14)  end ) as tot_premium_amt_3_mnths,
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,prem_due_date_1)::number(38,14) < 180 THEN PD_PREM_AMT::number(38,14)  end ) as tot_premium_amt_6_mnths,
sum(PD_PREM_AMT::number(38,14)) as tot_premium_amt,

sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,prem_due_date_1)::number(38,14) < 90 THEN PD_PREM_AMT::number(38,14)  end ) as paid_net_memb_cont_amt_3_mnths,
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,prem_due_date_1)::number(38,14) < 180 THEN PD_PREM_AMT::number(38,14)  end ) as paid_net_memb_cont_amt_6_mnths,
sum(PD_PREM_AMT::number(38,14)) as paid_net_memb_cont_amt,

sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,prem_due_date_1)::number(38,14) < 90 THEN DSCNT_PD_MULTI_INSD_AMT::number(38,14)  end ) as tot_Spouse_disc_amt_3_mnths,
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,prem_due_date_1)::number(38,14) < 180 THEN DSCNT_PD_MULTI_INSD_AMT::number(38,14)  end ) as tot_Spouse_disc_amt_6_mnths,
sum(DSCNT_PD_MULTI_INSD_AMT::number(38,14)) as tot_Spouse_disc_amt,

sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,prem_due_date_1)::number(38,14) < 90 THEN EMP_PD_PREM_AMT::number(38,14)  end ) as tot_EB_subsidy_paid_amt_3_mnths,
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,prem_due_date_1)::number(38,14) < 180 THEN EMP_PD_PREM_AMT::number(38,14)  end ) as tot_EB_subsidy_paid_amt_6_mnths,
sum(EMP_PD_PREM_AMT::number(38,14)) as tot_EB_subsidy_paid_amt,

sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,prem_due_date_1)::number(38,14) < 90 THEN PD_CERT_QTY::number(38,14)  end ) as PAID_CERT_QNTY_3_mnths,
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,prem_due_date_1)::number(38,14) < 180 THEN PD_CERT_QTY::number(38,14)  end ) as PAID_CERT_QNTY_6_mnths,
sum(PD_CERT_QTY::number(38,14)) as PAID_CERT_QNTY,

sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,prem_due_date_1)::number(38,14) < 90 THEN TERM_CERT_QTY::number(38,14)  end ) as TERMED_CERT_QNTY_3_mnths,
sum(case when UTIL.DATE_DIFF_UDF(actual_drop_date,prem_due_date_1)::number(38,14) < 180 THEN TERM_CERT_QTY::number(38,14)  end ) as TERMED_CERT_QNTY_6_mnths,
sum(TERM_CERT_QTY::number(38,14)) as TERMED_CERT_QNTY

from IDENTIFIER(:V_EFT_PULL_PREM_HIST) group by PERSON_ID, actual_drop_date;



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_EFT_PREMIUM_BASE_POP_1_SYS)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);


RAISE;

END;

';