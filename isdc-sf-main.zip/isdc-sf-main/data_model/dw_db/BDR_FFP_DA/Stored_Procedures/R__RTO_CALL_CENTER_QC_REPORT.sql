USE SCHEMA BDR_FFP_DA;

CREATE OR REPLACE PROCEDURE BDR_FFP_DA.SP_RTO_CALL_CENTER_QC_REPORT
 ("PIPELINE_ID" VARCHAR(16777216),
 "PIPELINE_NAME" VARCHAR(16777216),
 "DB_NAME" VARCHAR(16777216), 
 "UTIL_SC" VARCHAR(16777216), 
 "TGT_SC" VARCHAR(16777216),
 "INTRM_SC" VARCHAR(16777216),
 "STAGE_NAME" VARCHAR(16777216),
 "WH" VARCHAR(16777216)) 
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '

DECLARE


V_CURRENT_DATE   DATE := COALESCE(CURRENT_DATE(), CURRENT_DATE());

V_SP_PROCESS_RUN_LOGS_DTL VARCHAR := :DB_NAME||''.''||COALESCE(:UTIL_SC, ''UTIL'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';

V_PROCESS_NAME   VARCHAR DEFAULT ''RTO_CALL_CENTER'';

V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''QC REPORT'';

V_STEP             VARCHAR;

V_STEP_NAME        VARCHAR;

V_START_TIME       VARCHAR;

V_END_TIME         VARCHAR;

V_ROWS_PARSED       INTEGER;

V_ROWS_LOADED       INTEGER;

V_MESSAGE          VARCHAR;

V_LAST_QUERY_ID    VARCHAR;

V_FILE_QUERY VARCHAR;

V_FILE_QUERY1 VARCHAR;

V_FILE_QUERY2 VARCHAR;


--QC Tables

BEGIN

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP1'';

V_STEP_NAME :=  ''Blob summ_data_ocss_qc1 File Creation'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


V_FILE_QUERY := ''COPY INTO ''||''@UTIL.STAGE_AZURE_ISDC/analytics/outbox/rto_call_center/summ_data_ocss_qc1_'' ||(:V_CURRENT_DATE)||''.csv''||'' FROM (
           select * from BDR_FFP_DA_WRK.RTO_CC_SUMM_DATA_OCSS_QC1
               )
file_format = (type = ''''CSV'''' 
               field_delimiter = '''',''''
               record_delimiter = ''''\\n''''
               compression = None 
               FIELD_OPTIONALLY_ENCLOSED_BY=''''"''''
              )
HEADER = True
OVERWRITE = True
MAX_FILE_SIZE = 4900000000
SINGLE = True''
;

execute immediate  :V_FILE_QUERY;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED,NULL, NULL, NULL, NULL);




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP2'';

V_STEP_NAME :=  ''Blob summ_data_ocss_qc2 File Creation'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


V_FILE_QUERY1 := ''COPY INTO ''||''@UTIL.STAGE_AZURE_ISDC/analytics/outbox/rto_call_center/summ_data_ocss_qc2_'' ||(:V_CURRENT_DATE)||''.csv''||'' FROM (
           select * from BDR_FFP_DA_WRK.RTO_CC_SUMM_DATA_OCSS_QC2
               )
file_format = (type = ''''CSV'''' 
               field_delimiter = '''',''''
               record_delimiter = ''''\\n''''
               compression = None 
               FIELD_OPTIONALLY_ENCLOSED_BY=''''"''''
              )
HEADER = True
OVERWRITE = True
MAX_FILE_SIZE = 4900000000
SINGLE = True''
;

execute immediate  :V_FILE_QUERY1;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED,NULL, NULL, NULL, NULL);



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP3'';

V_STEP_NAME :=  ''Blob ocss_ytd_base_qc File Creation'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


V_FILE_QUERY2 := ''COPY INTO ''||''@UTIL.STAGE_AZURE_ISDC/analytics/outbox/rto_call_center/ocss_ytd_base_qc_'' ||(:V_CURRENT_DATE)||''.csv''||'' FROM (
           select * from BDR_FFP_DA_WRK.RTO_CC_OCSS_YTD_BASE_QC
               )
file_format = (type = ''''CSV'''' 
               field_delimiter = '''',''''
               record_delimiter = ''''\\n''''
               compression = None 
               FIELD_OPTIONALLY_ENCLOSED_BY=''''"''''
              )
HEADER = True
OVERWRITE = True
MAX_FILE_SIZE = 4900000000
SINGLE = True''
;

execute immediate  :V_FILE_QUERY2;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED,NULL, NULL, NULL, NULL);




EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);





RAISE;

END;

';