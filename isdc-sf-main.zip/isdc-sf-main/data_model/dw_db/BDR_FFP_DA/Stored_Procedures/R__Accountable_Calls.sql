USE SCHEMA BDR_FFP_DA;

CREATE OR REPLACE PROCEDURE SP_ACCOUNTABLE_CALLS("PIPELINE_ID" VARCHAR(16777216), "PIPELINE_NAME" VARCHAR(16777216), "DB_NAME" VARCHAR(16777216), "UTIL_SC" VARCHAR(16777216), "TGT_SC" VARCHAR(16777216), "FFP_WRK_SC" VARCHAR(16777216), "SRC_SC" VARCHAR(16777216), "ONE_SC" VARCHAR(16777216), "WH" VARCHAR(16777216), "CURR_DATE" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

V_CURRENT_DATE   DATE := COALESCE(TO_DATE(:CURR_DATE), CURRENT_DATE());

V_REPORT_DATE DATE := COALESCE(TO_DATE(:CURR_DATE), CURRENT_DATE());

V_SP_PROCESS_RUN_LOGS_DTL  VARCHAR := :DB_NAME||''.''||COALESCE(:UTIL_SC, ''UTIL'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';

V_PROCESS_NAME   VARCHAR DEFAULT ''ACCOUNTABLE_CALLS'';

V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''ACCOUNTABLE_CALLS'';

V_STEP             VARCHAR;

V_STEP_NAME        VARCHAR;

V_START_TIME       VARCHAR;

V_END_TIME         VARCHAR;

V_ROWS_PARSED       INTEGER;

V_ROWS_LOADED       INTEGER;

V_MESSAGE          VARCHAR;

V_LAST_QUERY_ID    VARCHAR;

V_UHCACCOUNTABLECALLS VARCHAR := :DB_NAME || ''.'' || COALESCE(:ONE_SC, ''SRC_FIN360'') || ''.UHCACCOUNTABLECALLS_DATA'';
V_ACCOUNTABLE_CALLS_OPTUM_DASHBOARD_AGGREGATED VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.ACCOUNTABLE_CALLS_OPTUM_DASHBOARD_AGGREGATED'';
V_ACCOUNTABLE_CALLS_AGGREGATED_NEW VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.ACCOUNTABLE_CALLS_AGGREGATED_NEW'';
V_ACCOUNTABLE_CALLS_DATA_FINAL VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC, ''BDR_FFP_DA'') || ''.ACCOUNTABLE_CALLS_DATA_FINAL'';



BEGIN

--Aggregated data from optum''s dashboard (at date,partner, tfn, function, subfunction, language level) 
--max date currently in this data is 2022-05-28 . We can change the date to the starting date which we are getting in new accountable calls file

--Commenting table as one time load was needed

--drop table if exists raw_telemarketing.accountable_calls_optum_dashboard_aggregated;
--create table raw_telemarketing.accountable_calls_optum_dashboard_aggregated stored as orc as select `date`, partner, tfn, `function`, ent_subfunction,ent_language, sum(calls_accountable) as calls_accountable, sum(TRY_TO_NUMBER(direct_accountable)) as direct_accountable, sum(transfers_accountable) as transfers_accountable, sum(calls_answered) as calls_answered from refined_telemarketing.accountable_calls_dashboard where `date` <= to_date(''2022-05-28'') group by `date`, partner, tfn, `function`, ent_subfunction,ent_language;
--grant select on table raw_telemarketing.accountable_calls_optum_dashboard_aggregated to role deep_dg;
--grant select on table raw_telemarketing.accountable_calls_optum_dashboard_aggregated to role deep_de;

--aggregated data from the new file and calldate should be greater tha or equal to 2022-05-29 

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP1'';

V_STEP_NAME :=  ''create a table ACCOUNTABLE_CALLS_AGGREGATED_NEW'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());


create or replace table IDENTIFIER(:V_ACCOUNTABLE_CALLS_AGGREGATED_NEW) as
select calldate, partner, tfn, function, subfunction,language, sum(calls_accountable) as calls_accountable, sum(TRY_TO_NUMBER(direct_accountable)) as direct_accountable, sum(transfers_accountable) as transfers_accountable,sum(calls_answered) as calls_answered
from IDENTIFIER(:V_UHCACCOUNTABLECALLS)
where calldate >= to_date(''2022-05-29'')
group by calldate, partner, tfn, function, subfunction,language;

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_ACCOUNTABLE_CALLS_AGGREGATED_NEW)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);


V_STEP := ''STEP2'';

V_STEP_NAME :=  ''create a RTUW_MASTER'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

create or replace table IDENTIFIER(:V_ACCOUNTABLE_CALLS_DATA_FINAL) as
select date as calldate, partner, tfn, function, ent_subfunction, ent_language, calls_accountable, direct_accountable, transfers_accountable, calls_answered from IDENTIFIER(:V_ACCOUNTABLE_CALLS_OPTUM_DASHBOARD_AGGREGATED)
union all
select TO_DATE(CALLDATE) as calldate , partner, try_cast(tfn as numeric) as tfn, function, subfunction as ent_subfunction, language as ent_language, calls_accountable, direct_accountable, transfers_accountable, calls_answered from IDENTIFIER(:V_ACCOUNTABLE_CALLS_AGGREGATED_NEW);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_ACCOUNTABLE_CALLS_DATA_FINAL)) ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESS'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);


RAISE;

END;

';