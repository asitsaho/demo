USE SCHEMA BDR_FFP_DA;


CREATE OR REPLACE PROCEDURE BDR_FFP_DA.SP_FINAL_CODES("PIPELINE_ID" VARCHAR(16777216), "PIPELINE_NAME" VARCHAR(16777216), "DB_NAME" VARCHAR(16777216), "UTIL_SC" VARCHAR(16777216), "TGT_SC" VARCHAR(16777216), "SRC_SC" VARCHAR(16777216), "WH" VARCHAR(16777216), "CURR_DATE" DATE)
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE

V_CURRENT_DATE DATE := COALESCE(:CURR_DATE, CURRENT_DATE());

V_YEAR_MONTH VARCHAR := TO_CHAR(:V_CURRENT_DATE,''yyyy-MM'');

V_DATEVARIABLE VARCHAR :=TO_CHAR(DATEADD(day,-150,:V_CURRENT_DATE),''yyyy-MM'');

V_SP_PROCESS_RUN_LOGS_DTL VARCHAR := :DB_NAME||''.''||COALESCE(:UTIL_SC, ''UTIL'')||''.SP_PROCESS_RUN_LOGS_DTL_ANALYTICS'';

V_PROCESS_NAME   VARCHAR DEFAULT ''MEMBERSHIP_TRACKING'';

V_SUB_PROCESS_NAME  VARCHAR DEFAULT ''FINAL_CODES'';

V_STEP             VARCHAR;

V_STEP_NAME        VARCHAR;

V_START_TIME       VARCHAR;

V_END_TIME         VARCHAR;

V_ROWS_PARSED       INTEGER;

V_ROWS_LOADED       INTEGER;

V_MESSAGE          VARCHAR;

V_LAST_QUERY_ID    VARCHAR;

V_MASTER_DEMOG VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC,''BDR_FFP_DA_WRK'') || ''.MEM_TRACKING_MASTER_DEMOG'';  

V_MASTER_DEMOG_FN VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC,''BDR_FFP_DA'') || ''.MEM_TRACKING_MASTER_DEMOG''; 

V_MASTER_PLAN VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC,''BDR_FFP_DA_WRK'') || ''.MEM_TRACKING_MASTER_PLAN''; 

V_MASTER_PLAN_FN VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC,''BDR_FFP_DA'') || ''.MEM_TRACKING_MASTER_PLAN'';

V_MASTER_STATE VARCHAR := :DB_NAME || ''.'' || COALESCE(:SRC_SC,''BDR_FFP_DA_WRK'') || ''.MEM_TRACKING_MASTER_STATE '';

V_MASTER_STATE_FN VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC,''BDR_FFP_DA'') || ''.MEM_TRACKING_MASTER_STATE '';

V_MASTER_LOB_SUMMARY VARCHAR :=:DB_NAME || ''.'' || COALESCE(:SRC_SC,''BDR_FFP_DA_WRK'') || ''.MEM_TRACKING_MASTER_LOB_SUMMARY'';

V_MASTER_LOB_SUMMARY_FN VARCHAR :=:DB_NAME || ''.'' || COALESCE(:TGT_SC,''BDR_FFP_DA'') || ''.MEM_TRACKING_MASTER_LOB_SUMMARY'';

V_MASTER_LOB_SUMMARY_TABLEAU VARCHAR :=:DB_NAME || ''.'' || COALESCE(:SRC_SC,''BDR_FFP_DA_WRK'') || ''.MEM_TRACKING_MASTER_LOB_SUMMARY_TABLEAU'';

V_MASTER_LOB_SUMMARY_TABLEAU_FN VARCHAR :=:DB_NAME || ''.'' || COALESCE(:TGT_SC,''BDR_FFP_DA'') || ''.MEM_TRACKING_MASTER_LOB_SUMMARY_TABLEAU'';

V_MASTER_PRODUCT_SUMMARY VARCHAR :=:DB_NAME || ''.'' || COALESCE(:SRC_SC,''BDR_FFP_DA_WRK'') || ''.MEM_TRACKING_MASTER_PRODUCT_SUMMARY'';

V_MASTER_PRODUCT_SUMMARY_FN VARCHAR :=:DB_NAME || ''.'' || COALESCE(:TGT_SC,''BDR_FFP_DA'') || ''.MEM_TRACKING_MASTER_PRODUCT_SUMMARY'';

V_MASTER_PRODUCT_SUMMARY_TABLEAU VARCHAR:=:DB_NAME || ''.'' || COALESCE(:SRC_SC,''BDR_FFP_DA_WRK'') || ''.MEM_TRACKING_MASTER_PRODUCT_SUMMARY_TABLEAU'';

V_MASTER_PRODUCT_SUMMARY_TABLEAU_FN VARCHAR:=:DB_NAME || ''.'' || COALESCE(:TGT_SC,''BDR_FFP_DA'') || ''.MEM_TRACKING_MASTER_PRODUCT_SUMMARY_TABLEAU'';

V_MASTER_BOP_EOP VARCHAR :=:DB_NAME || ''.'' || COALESCE(:SRC_SC,''BDR_FFP_DA_WRK'') || ''.MEM_TRACKING_MASTER_BOP_EOP'';

V_MASTER_BOP_EOP_FN VARCHAR :=:DB_NAME || ''.'' || COALESCE(:TGT_SC,''BDR_FFP_DA'') || ''.MEM_TRACKING_MASTER_BOP_EOP'';

V_MASTER_BOPEOP_SWITCHERS VARCHAR :=:DB_NAME || ''.'' || COALESCE(:SRC_SC,''BDR_FFP_DA_WRK'') || ''.MEM_TRACKING_MASTER_BOPEOP_SWITCHERS'';

V_MASTER_BOPEOP_SWITCHERS_FN VARCHAR :=:DB_NAME || ''.'' || COALESCE(:TGT_SC,''BDR_FFP_DA'') || ''.MEM_TRACKING_MASTER_BOPEOP_SWITCHERS'';

V_MASTER_BOP_EOP_TABLEAU VARCHAR :=:DB_NAME || ''.'' || COALESCE(:SRC_SC,''BDR_FFP_DA_WRK'') || ''.MEM_TRACKING_MASTER_BOP_EOP_TABLEAU'';

V_MASTER_BOP_EOP_TABLEAU_FN VARCHAR :=:DB_NAME || ''.'' || COALESCE(:TGT_SC,''BDR_FFP_DA'') || ''.MEM_TRACKING_MASTER_BOP_EOP_TABLEAU'';

V_MASTER_BOPEOP_SWITCHERS_TABLEAU VARCHAR :=:DB_NAME || ''.'' || COALESCE(:SRC_SC,''BDR_FFP_DA_WRK'') || ''.MEM_TRACKING_MASTER_BOPEOP_SWITCHERS_TABLEAU'';

V_MASTER_BOPEOP_SWITCHERS_TABLEAU_FN VARCHAR :=:DB_NAME || ''.'' || COALESCE(:TGT_SC,''BDR_FFP_DA'') || ''.MEM_TRACKING_MASTER_BOPEOP_SWITCHERS_TABLEAU'';

V_UPD_YTD_FED_2I_HISTORICAL VARCHAR := :DB_NAME || ''.'' || COALESCE(:TGT_SC,''BDR_FFP_DA'') || ''.MEM_TRACKING_UPD_YTD_FED_2I_HISTORICAL'';

V_UPD_YTD_FED_2I VARCHAR :=:DB_NAME || ''.'' || COALESCE(:SRC_SC,''BDR_FFP_DA_WRK'') || ''.UPD_YTD_FED_2I'';



BEGIN
 
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP1'';
   
V_STEP_NAME :=  ''drop and create master_plan'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   

create or replace table IDENTIFIER(:V_MASTER_PLAN_FN) COPY GRANTS as select * from IDENTIFIER(:V_MASTER_PLAN);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_MASTER_PLAN_FN )) ;
   
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
   

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP2'';
   
V_STEP_NAME :=  ''Create and drop master_state'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   

create or replace table IDENTIFIER(:V_MASTER_STATE_FN) COPY GRANTS as select * from IDENTIFIER(:V_MASTER_STATE);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_MASTER_STATE_FN)) ;
   
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
   

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP3'';
   
V_STEP_NAME :=  ''Create and drop master_demog'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   

create or replace table IDENTIFIER(:V_MASTER_DEMOG_FN) COPY GRANTS as select * from IDENTIFIER(:V_MASTER_DEMOG);



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_MASTER_DEMOG_FN)) ;
   
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
   

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP4'';
   
V_STEP_NAME :=  ''drop and create master_lob_summary'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
create or replace table IDENTIFIER(:V_MASTER_LOB_SUMMARY_FN) COPY GRANTS as select * from IDENTIFIER(:V_MASTER_LOB_SUMMARY);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_MASTER_LOB_SUMMARY_FN)) ;
   
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
   
   
   
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP5'';
   
V_STEP_NAME :=  '' drop and create table master_lob_summary_tableau'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
create or replace table IDENTIFIER(:V_MASTER_LOB_SUMMARY_TABLEAU_FN) COPY GRANTS as select * from IDENTIFIER(:V_MASTER_LOB_SUMMARY_TABLEAU);

V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_MASTER_LOB_SUMMARY_TABLEAU_FN)) ;
   
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
   

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP6'';
   
V_STEP_NAME :=  ''drop and create table master_product_summary'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
create or replace table IDENTIFIER(:V_MASTER_PRODUCT_SUMMARY_FN) COPY GRANTS as select * from IDENTIFIER(:V_MASTER_PRODUCT_SUMMARY);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_MASTER_PRODUCT_SUMMARY_FN)) ;
   
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
   
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP7'';
   
V_STEP_NAME :=  ''drop and create table master_product_summary_tableau'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
create or replace table IDENTIFIER(:V_MASTER_PRODUCT_SUMMARY_TABLEAU_FN) COPY GRANTS as select * from IDENTIFIER(:V_MASTER_PRODUCT_SUMMARY_TABLEAU);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_MASTER_PRODUCT_SUMMARY_TABLEAU_FN)) ;
   
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
  
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP8'';
   
V_STEP_NAME :=  ''drop and create  table master_bop_eop'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
create or replace table IDENTIFIER(:V_MASTER_BOP_EOP_FN) COPY GRANTS as select * from IDENTIFIER(:V_MASTER_BOP_EOP);;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_MASTER_BOP_EOP_FN)) ;
   
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
  
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP9'';
   
V_STEP_NAME :=  ''drop and create table master_bopeop_switchers'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
create or replace table IDENTIFIER(:V_MASTER_BOPEOP_SWITCHERS_FN) COPY GRANTS as select * from IDENTIFIER(:V_MASTER_BOPEOP_SWITCHERS);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_MASTER_BOPEOP_SWITCHERS_FN)) ;
   
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
    
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP10'';
   
V_STEP_NAME :=  ''create table master_bop_eop_tableau'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
create or replace table IDENTIFIER(:V_MASTER_BOP_EOP_TABLEAU_FN) COPY GRANTS as 
select
plan,
to_date(to_timestamp(bop,''Mon-yyyy'')) as bop,
to_date(to_timestamp(eop,''Mon-yyyy'')) as eop,
bopcount,
eopcount,
lapsers,
newenrolls,
ins,
outs,
sameplans
from IDENTIFIER(:V_MASTER_BOP_EOP_FN) ;



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_MASTER_BOP_EOP_TABLEAU_FN)) ;
   
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
    
  
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP11'';
   
V_STEP_NAME :=  ''create table master_bopeop_switchers_tableau'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   
create or replace table IDENTIFIER(:V_MASTER_BOPEOP_SWITCHERS_TABLEAU_FN) COPY GRANTS as 
select
plan1,
plan2,
c1,
to_date(to_timestamp(bop,''Mon-yyyy'')) as bop,
to_date(to_timestamp(eop,''Mon-yyyy'')) as eop
from IDENTIFIER(:V_MASTER_BOPEOP_SWITCHERS_FN) ;



V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_MASTER_BOPEOP_SWITCHERS_TABLEAU_FN)) ;
   
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
    

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP12'';
   
V_STEP_NAME :=  ''create upd_ytd_fed_2i_historical'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

CREATE TABLE if not exists IDENTIFIER(:V_UPD_YTD_FED_2I_HISTORICAL)( mbi_1 string, indvdl_id bigint, mbr_plan_eff_dt timestamp, dsenrl_dt timestamp, orig_mbr_eff_dt timestamp, prod_id int, subsidy_lvl_id int, plan_cd string, group_ind_cd string, lob_id int, assigned_medicaid_fg string, sh_mbr_fg string, pdp_mbr_fg string, evc_mbr_fg string, amc_mbr_fg string, dob timestamp, state_fed string, contract_id_cd string, plan_cat_id int, plan_cat_nm string, elgblty_group_type_cd string, gender_fd string, amlk_id_fd bigint, hh_id bigint, mbi_2 string, mbi string, plan_category string, contrct string, pbp string, ma_ind int, sh_ms_ind int, pdp_ind int, snp int, pdp_indv_ind int, pdp_grp_ind int, ma_indv_split string, ovrl_ma string, ma_only_ind int, mapd_ind int, mnr_snp_ind int, ma_grp_ind int, age_fed double, state_fed1 string, year_month string);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_UPD_YTD_FED_2I_HISTORICAL)) ;
   
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP13'';
   
V_STEP_NAME :=  ''delete upd_ytd_fed_2i_historical'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   

delete from IDENTIFIER(:V_UPD_YTD_FED_2I_HISTORICAL) where year_month=:V_YEAR_MONTH;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_UPD_YTD_FED_2I_HISTORICAL)) ;
   
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
      
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP14'';
   
V_STEP_NAME :=  ''Insert data into upd_ytd_fed_2i_historical'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());

INSERT INTO IDENTIFIER(:V_UPD_YTD_FED_2I_HISTORICAL)
SELECT
case when trim(mbi_1) ='''' then null else trim(mbi_1) end as mbi_1,
cast(indvdl_id as bigint ) as indvdl_id,
mbr_plan_eff_dt,
dsenrl_dt,
orig_mbr_eff_dt,
cast(prod_id as int ) as prod_id,
cast(subsidy_lvl_id as int ) as subsidy_lvl_id,
case when trim(plan_cd) ='''' then null else trim(plan_cd) end as plan_cd,
case when trim(group_ind_cd) ='''' then null else trim(group_ind_cd) end as group_ind_cd,
cast(lob_id as int ) as lob_id,
case when trim(assigned_medicaid_fg) ='''' then null else trim(assigned_medicaid_fg) end as assigned_medicaid_fg,
case when trim(sh_mbr_fg) ='''' then null else trim(sh_mbr_fg) end as sh_mbr_fg,
case when trim(pdp_mbr_fg) ='''' then null else trim(pdp_mbr_fg) end as pdp_mbr_fg,
case when trim(evc_mbr_fg) ='''' then null else trim(evc_mbr_fg) end as evc_mbr_fg,
case when trim(amc_mbr_fg) ='''' then null else trim(amc_mbr_fg) end as amc_mbr_fg,
dob,
case when trim(state_fed) ='''' then null else trim(state_fed) end as state_fed,
case when trim(contract_id_cd) ='''' then null else trim(contract_id_cd) end as contract_id_cd,
cast(plan_cat_id as int ) as plan_cat_id,
case when trim(plan_cat_nm) ='''' then null else trim(plan_cat_nm) end as plan_cat_nm,
null as elgblty_group_type_cd,
case when trim(gender_fd) ='''' then null else trim(gender_fd) end as gender_fd,
cast(amlk_id_fd as bigint ) as amlk_id_fd,
cast(hh_id as bigint ) as hh_id,
case when trim(mbi_2) ='''' then null else trim(mbi_2) end as mbi_2,
case when trim(mbi) ='''' then null else trim(mbi) end as mbi,
case when trim(plan_category) ='''' then null else trim(plan_category) end as plan_category,
case when trim(contrct) ='''' then null else trim(contrct) end as contrct,
case when trim(pbp) ='''' then null else trim(pbp) end as pbp,
cast(ma_ind as int ) as ma_ind,
cast(sh_ms_ind as int ) as sh_ms_ind,
cast(pdp_ind as int ) as pdp_ind,
cast(snp as int ) as snp,
cast(pdp_indv_ind as int ) as pdp_indv_ind,
cast(pdp_grp_ind as int ) as pdp_grp_ind,
case when trim(ma_indv_split) ='''' then null else trim(ma_indv_split) end as ma_indv_split,
case when trim(ovrl_ma) ='''' then null else trim(ovrl_ma) end as ovrl_ma,
cast(ma_only_ind as int ) as ma_only_ind,
cast(mapd_ind as int ) as mapd_ind,
cast(mnr_snp_ind as int ) as mnr_snp_ind,
cast(ma_grp_ind as int ) as ma_grp_ind,
cast(age_fed as double ) as age_fed,
case when trim(state_fed1) ='''' then null else trim(state_fed1) end as state_fed1,
to_char(:V_CURRENT_DATE,''yyyy-MM'') as year_month
from IDENTIFIER(:V_UPD_YTD_FED_2I);


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_UPD_YTD_FED_2I_HISTORICAL)) ;
   
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
    
EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:WH;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_STEP := ''STEP15'';
   
V_STEP_NAME :=  ''Dropping partitions older than 5 months from historical table'';
   
V_START_TIME := CONVERT_TIMEZONE(''America/Chicago'', CURRENT_TIMESTAMP());
   

DELETE FROM IDENTIFIER(:V_UPD_YTD_FED_2I_HISTORICAL) WHERE year_month=:V_DATEVARIABLE;


V_ROWS_LOADED := (select count(1) from IDENTIFIER(:V_UPD_YTD_FED_2I_HISTORICAL)) ;
   
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID(-1)) ;
   
CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME, :V_PROCESS_NAME, :V_SUB_PROCESS_NAME, 
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''SUCCESS'', :V_LAST_QUERY_ID, :V_ROWS_PARSED, :V_ROWS_LOADED, NULL, NULL, NULL);
    

	
EXCEPTION

WHEN OTHER THEN

CALL IDENTIFIER(:V_SP_PROCESS_RUN_LOGS_DTL) (:DB_NAME, :UTIL_SC, ''DEEP_PROCESSES'', :PIPELINE_ID, :PIPELINE_NAME,  :V_PROCESS_NAME, :V_SUB_PROCESS_NAME,
                                 :V_STEP, :V_STEP_NAME, :V_START_TIME, CURRENT_TIMESTAMP(), ''FAILED'', :V_LAST_QUERY_ID, NULL, NULL, :SQLERRM, :SQLCODE, :SQLSTATE);


RAISE;

END;

';