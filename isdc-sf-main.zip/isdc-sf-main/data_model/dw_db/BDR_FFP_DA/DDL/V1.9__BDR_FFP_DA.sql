USE SCHEMA UTIL;

ALTER SESSION SET TIMEZONE = 'America/Chicago';

set adfenv = CASE current_database() 
                  WHEN 'UBLIA_TST_ISDC_DEV_DB'      THEN 'adf-isdc-analytics-nonprod-dev'
                  WHEN 'UBLIA_TST_ISDC_TST_DB'      THEN 'adf-isdc-analytics-nonprod-tst'
                  WHEN 'UBLIA_PRD_ISDC_PRD_DB'      THEN 'adf-isdc-analytics-prod-prd'
             END;
set db     = current_database();
set wh     = CASE current_database() 
                  WHEN 'UBLIA_TST_ISDC_DEV_DB'      THEN 'UBLIA_TST_ETL_XS_WH'
                  WHEN 'UBLIA_TST_ISDC_TST_DB'      THEN 'UBLIA_TST_ETL_XS_WH'
                  WHEN 'UBLIA_PRD_ISDC_PRD_DB'      THEN 'UBLIA_PRD_ETL_XS_WH'
             END;


 INSERT INTO util.PROCESS_LIST_ANALYTICS 
    (
       APP_NAME
      ,PROCESS_NAME
      ,DATA_FACTORY_NAME
      ,ACTIVE_INDC
      ,ISDC_CREATED_DT
      ,ISDC_UPDATED_DT
    )
 VALUES
    (
      'DEEP'
      ,'EZCLAIM_WEEKLY'
      ,$adfenv
      ,'Y'
      ,current_timestamp()
      ,current_timestamp()
    );

INSERT INTO UTIL.PROGRAM_LIST_ANALYTICS 
    (
      CODE_SEQUENCE,
      APP_NAME,
      PROCESS_NAME,
      SUB_PROCESS_NAME,
      DATA_FACTORY_NAME,
      OBJECT_DB,
      OBJECT_SCHEMA,
      OBJECT_NAME,
      OBJECT_SIGNATURE,
      LAST_SUCCESSFUL_LOAD,
      ISDC_CREATED_DT,
      ISDC_UPDATED_DT
    )
  SELECT 
         '1',
         'DEEP',
         'EZCLAIM_WEEKLY',
         'EZCLAIM_WEEKLY',
         $adfenv,
         $db,
         'BDR_FFP_DA',
         'SP_EZCLAIM_WEEKLY',
         '''' || $db || ''', ''UTIL'', ''BDR_FFP_DA'', ''BDR_FFP_DA_WRK'', ''BDR_CONF'',''SRC_MPO'',''SRC_APEX'', ''' || $wh || ''', current_date',
         null,
         CURRENT_TIMESTAMP(),
         CURRENT_TIMESTAMP(); 
