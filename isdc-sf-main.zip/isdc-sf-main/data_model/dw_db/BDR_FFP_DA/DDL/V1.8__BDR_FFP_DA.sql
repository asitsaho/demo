USE SCHEMA UTIL;

ALTER SESSION SET TIMEZONE = 'America/Chicago';

set adfenv = CASE current_database() 
                  WHEN 'UBLIA_TST_ISDC_DEV_DB'      THEN 'adf-isdc-analytics-nonprod-dev'
                  WHEN 'UBLIA_TST_ISDC_TST_DB'      THEN 'adf-isdc-analytics-nonprod-tst'
                  WHEN 'UBLIA_PRD_ISDC_PRD_DB'      THEN 'adf-isdc-analytics-prod-prd'
             END;
set db     = current_database();
set wh     = CASE current_database() 
                  WHEN 'UBLIA_TST_ISDC_DEV_DB'      THEN 'UBLIA_TST_ETL_XS_WH'
                  WHEN 'UBLIA_TST_ISDC_TST_DB'      THEN 'UBLIA_TST_ETL_XS_WH'
                  WHEN 'UBLIA_PRD_ISDC_PRD_DB'      THEN 'UBLIA_PRD_ETL_XS_WH'
             END;
set rg     = CASE current_database() 
                  WHEN 'UBLIA_TST_ISDC_DEV_DB'      THEN 'rg-isdc-nonprod'
                  WHEN 'UBLIA_TST_ISDC_TST_DB'      THEN 'rg-isdc-nonprod'
                  WHEN 'UBLIA_PRD_ISDC_PRD_DB'      THEN 'rg-isdc-prod'
             END;  
set sub_id     = CASE current_database() 
                  WHEN 'UBLIA_TST_ISDC_DEV_DB'      THEN 'df55fbe1-ac66-4549-a170-1a3bbb27a6bf'
                  WHEN 'UBLIA_TST_ISDC_TST_DB'      THEN 'df55fbe1-ac66-4549-a170-1a3bbb27a6bf'
                  WHEN 'UBLIA_PRD_ISDC_PRD_DB'      THEN '3d58a242-5793-4087-947a-0ca97fbe8fb6'
             END;  
             

        
 
 INSERT INTO util.PROCESS_LIST_ANALYTICS 
    (
       APP_NAME
      ,PROCESS_NAME
      ,DATA_FACTORY_NAME
      ,ACTIVE_INDC
      ,ISDC_CREATED_DT
      ,ISDC_UPDATED_DT
    )
 VALUES
    (
      'DEEP'
      ,'FWA_AM'
      ,$adfenv
      ,'Y'
      ,current_timestamp()
      ,current_timestamp()
    );


INSERT INTO UTIL.PROGRAM_LIST_ANALYTICS 
    (
      CODE_SEQUENCE,
      APP_NAME,
      PROCESS_NAME,
      SUB_PROCESS_NAME,
      DATA_FACTORY_NAME,
      OBJECT_DB,
      OBJECT_SCHEMA,
      OBJECT_NAME,
      OBJECT_SIGNATURE,
      LAST_SUCCESSFUL_LOAD,
      ISDC_CREATED_DT,
      ISDC_UPDATED_DT
    )
  SELECT 
         '1',
         'DEEP',
         'FWA_AM',
         'FWA_AM_Script1',
         $adfenv,
         $db,
         'BDR_FFP_DA',
         'SP_FWA_AM_Script1',
         '''' || $db || ''', ''UTIL'', ''BDR_FFP_DA'', ''BDR_FFP_DA_WRK'', ''' || $wh || ''', ''@UTIL.STAGE_AZURE_ISDC'', null, null, null',
         null,
         CURRENT_TIMESTAMP(),
         CURRENT_TIMESTAMP(); 



INSERT INTO UTIL.PROGRAM_LIST_ANALYTICS 
    (
      CODE_SEQUENCE
	  ,APP_NAME
      ,PROCESS_NAME
      ,SUB_PROCESS_NAME
      ,DATA_FACTORY_NAME
      ,OBJECT_DB
      ,OBJECT_SCHEMA
      ,OBJECT_NAME
      ,OBJECT_SIGNATURE
      ,LAST_SUCCESSFUL_LOAD
      ,ISDC_CREATED_DT
      ,ISDC_UPDATED_DT
    )
  select 
         '2'
		 ,'DEEP'
         ,'FWA_AM'
         ,'FWA_AM_Script3'
         ,$adfenv
         ,$db
         ,'BDR_FFP_DA'
         ,'SP_FWA_AM_Script3' ,
         '''' || $db || ''', ''UTIL'', ''BDR_FFP_DA'', ''BDR_FFP_DA_WRK'', ''' || $wh || ''', ''@UTIL.STAGE_AZURE_ISDC'', null, null, null',
         null
         ,current_timestamp()
         ,current_timestamp(); 



USE SCHEMA BDR_FFP_DA_WRK;

create or replace TABLE BDR_FFP_DA_WRK.FWA_AM_NPI_FLAGGED_NEWMO_RAW_DEEP (
	TIN VARCHAR(16777216),
	NPI VARCHAR(16777216),
	BUSINESS_NAME VARCHAR(16777216),
	PROVIDER_LAST_NAME VARCHAR(16777216),
	PROVIDER_FIRST_NAME VARCHAR(16777216),
	ADDRESS VARCHAR(16777216),
	ADDRESS_2 VARCHAR(16777216),
	CITY VARCHAR(16777216),
	PROVIDER_STATE VARCHAR(16777216),
	ZIP VARCHAR(16777216)
);



create or replace TABLE BDR_FFP_DA_WRK.FWA_AM_NPI_FINAL_RAW_DEEP (
	NPI_FWA VARCHAR(16777216),
	KEY2_FWA VARCHAR(16777216),
	L_BUSINESS_NAME_FWA VARCHAR(16777216),
	PROVIDER_FULL_NAME_FWA VARCHAR(16777216),
	NPI VARCHAR(16777216),
	KEY1_NPI VARCHAR(16777216),
	L_PROVIDER_BUSINESS_NAME_NPI VARCHAR(16777216),
	PROVIDER_FULLNAME_NPI VARCHAR(16777216),
	JS_ADDRESS FLOAT,
	SIM_BUSINESSNAME FLOAT,
	SIM_FULL_NAME FLOAT
);