USE  SCHEMA BDR_FFP_DA;

create or replace TABLE NPS_DASH_DURATION_MAPPING (
	DLTIMEMBR NUMBER(38,0),
	DURATION VARCHAR(16777216),
	F_TIME_AS_MBR VARCHAR(16777216)
);

INSERT INTO NPS_DASH_DURATION_MAPPING
select 1,'6 Months or Less','<= 6 months' UNION ALL
select 2,'7 to 12 Months','7-12 months' UNION ALL
select 3,'1 to 2 Years','13-24 months' UNION ALL
select 4,'2 to 3 Years','25-36 months' UNION ALL
select 5,'3 to 4 Years','37-48 months' UNION ALL
select 6,'4 to 5 years','49-60 months' UNION ALL
select 7,'Greater than 5 Years','>= 61 months' UNION ALL
select 8,'Unknown','Unknown';


create or replace TABLE NPS_DASH_AGE_MAPPING (
	DAGE NUMBER(38,0),
	AGE_GROUP VARCHAR(16777216),
	S_AGE NUMBER(38,0)
);

INSERT INTO NPS_DASH_AGE_MAPPING
select 0,'Under 65','0' UNION ALL
select 1,'Under 65','1' UNION ALL
select 2,'Under 65','2' UNION ALL
select 3,'Under 65','3' UNION ALL
select 4,'Under 65','4' UNION ALL
select 5,'Under 65','5' UNION ALL
select 6,'Under 65','6' UNION ALL
select 7,'Under 65','7' UNION ALL
select 8,'Under 65','8' UNION ALL
select 9,'Under 65','9' UNION ALL
select 10,'Under 65','10' UNION ALL
select 11,'Under 65','11' UNION ALL
select 12,'Under 65','12' UNION ALL
select 13,'Under 65','13' UNION ALL
select 14,'Under 65','14' UNION ALL
select 15,'Under 65','15' UNION ALL
select 16,'Under 65','16' UNION ALL
select 17,'Under 65','17' UNION ALL
select 18,'Under 65','18' UNION ALL
select 19,'Under 65','19' UNION ALL
select 20,'Under 65','20' UNION ALL
select 21,'Under 65','21' UNION ALL
select 22,'Under 65','22' UNION ALL
select 23,'Under 65','23' UNION ALL
select 24,'Under 65','24' UNION ALL
select 25,'Under 65','25' UNION ALL
select 26,'Under 65','26' UNION ALL
select 27,'Under 65','27' UNION ALL
select 28,'Under 65','28' UNION ALL
select 29,'Under 65','29' UNION ALL
select 30,'Under 65','30' UNION ALL
select 31,'Under 65','31' UNION ALL
select 32,'Under 65','32' UNION ALL
select 33,'Under 65','33' UNION ALL
select 34,'Under 65','34' UNION ALL
select 35,'Under 65','35' UNION ALL
select 36,'Under 65','36' UNION ALL
select 37,'Under 65','37' UNION ALL
select 38,'Under 65','38' UNION ALL
select 39,'Under 65','39' UNION ALL
select 40,'Under 65','40' UNION ALL
select 41,'Under 65','41' UNION ALL
select 42,'Under 65','42' UNION ALL
select 43,'Under 65','43' UNION ALL
select 44,'Under 65','44' UNION ALL
select 45,'Under 65','45' UNION ALL
select 46,'Under 65','46' UNION ALL
select 47,'Under 65','47' UNION ALL
select 48,'Under 65','48' UNION ALL
select 49,'Under 65','49' UNION ALL
select 50,'Under 65','50' UNION ALL
select 51,'Under 65','51' UNION ALL
select 52,'Under 65','52' UNION ALL
select 53,'Under 65','53' UNION ALL
select 54,'Under 65','54' UNION ALL
select 55,'Under 65','55' UNION ALL
select 56,'Under 65','56' UNION ALL
select 57,'Under 65','57' UNION ALL
select 58,'Under 65','58' UNION ALL
select 59,'Under 65','59' UNION ALL
select 60,'Under 65','60' UNION ALL
select 61,'Under 65','61' UNION ALL
select 62,'Under 65','62' UNION ALL
select 63,'Under 65','63' UNION ALL
select 64,'Under 65','64' UNION ALL
select 65,'65','65' UNION ALL
select 66,'66-70','66' UNION ALL
select 67,'66-70','67' UNION ALL
select 68,'66-70','68' UNION ALL
select 69,'66-70','69' UNION ALL
select 70,'66-70','70' UNION ALL
select 71,'71-75','71' UNION ALL
select 72,'71-75','72' UNION ALL
select 73,'71-75','73' UNION ALL
select 74,'71-75','74' UNION ALL
select 75,'71-75','75' UNION ALL
select 76,'76-80','76' UNION ALL
select 77,'76-80','77' UNION ALL
select 78,'76-80','78' UNION ALL
select 79,'76-80','79' UNION ALL
select 80,'76-80','80' UNION ALL
select 81,'81 and Over','81' UNION ALL
select 82,'81 and Over','82' UNION ALL
select 83,'81 and Over','83' UNION ALL
select 84,'81 and Over','84' UNION ALL
select 85,'81 and Over','85' UNION ALL
select 86,'81 and Over','86' UNION ALL
select 87,'81 and Over','87' UNION ALL
select 88,'81 and Over','88' UNION ALL
select 89,'81 and Over','89' UNION ALL
select 90,'81 and Over','90' UNION ALL
select 91,'81 and Over','91' UNION ALL
select 92,'81 and Over','92' UNION ALL
select 93,'81 and Over','93' UNION ALL
select 94,'81 and Over','94' UNION ALL
select 95,'81 and Over','95' UNION ALL
select 96,'81 and Over','96' UNION ALL
select 97,'81 and Over','97' UNION ALL
select 98,'81 and Over','98' UNION ALL
select 99,'81 and Over','99' UNION ALL
select 100,'81 and Over','100' UNION ALL
select 101,'81 and Over','101' UNION ALL
select 102,'81 and Over','102' UNION ALL
select 103,'81 and Over','103' UNION ALL
select 104,'81 and Over','104' UNION ALL
select 105,'81 and Over','105' UNION ALL
select 106,'81 and Over','106' UNION ALL
select 107,'81 and Over','107' UNION ALL
select 108,'81 and Over','108' UNION ALL
select 109,'81 and Over','109' UNION ALL
select 110,'81 and Over','110' UNION ALL
select 111,'81 and Over','111' UNION ALL
select 112,'81 and Over','112' UNION ALL
select 113,'81 and Over','113' UNION ALL
select 114,'81 and Over','114' UNION ALL
select 115,'81 and Over','115' UNION ALL
select 116,'81 and Over','116' UNION ALL
select 117,'81 and Over','117' UNION ALL
select 118,'81 and Over','118' UNION ALL
select 119,'81 and Over','119' UNION ALL
select 120,'81 and Over','120' UNION ALL
select 121,'81 and Over','121' UNION ALL
select 122,'81 and Over','122' UNION ALL
select 123,'81 and Over','123' UNION ALL
select 124,'81 and Over','124' UNION ALL
select 125,'81 and Over','125' UNION ALL
select 126,'81 and Over','126' UNION ALL
select 127,'81 and Over','127' UNION ALL
select 128,'81 and Over','128' UNION ALL
select 129,'81 and Over','129' UNION ALL
select 130,'81 and Over','130' UNION ALL
select 131,'81 and Over','131' UNION ALL
select 132,'81 and Over','132' UNION ALL
select 133,'81 and Over','133' UNION ALL
select 134,'81 and Over','134' UNION ALL
select 135,'81 and Over','135' UNION ALL
select 136,'81 and Over','136' UNION ALL
select 137,'81 and Over','137' UNION ALL
select 138,'81 and Over','138' UNION ALL
select 139,'81 and Over','139' UNION ALL
select 140,'81 and Over','140' UNION ALL
select 141,'81 and Over','141' UNION ALL
select 142,'81 and Over','142' UNION ALL
select 143,'81 and Over','143' UNION ALL
select 144,'81 and Over','144' UNION ALL
select 145,'81 and Over','145' UNION ALL
select 146,'81 and Over','146' UNION ALL
select 147,'81 and Over','147' UNION ALL
select 148,'81 and Over','148' UNION ALL
select 149,'81 and Over','149' UNION ALL
select 150,'81 and Over','150' UNION ALL
select 151,'81 and Over','151' UNION ALL
select 152,'81 and Over','152' UNION ALL
select 153,'81 and Over','153' UNION ALL
select 154,'81 and Over','154' UNION ALL
select 155,'81 and Over','155' UNION ALL
select 156,'81 and Over','156' UNION ALL
select 157,'81 and Over','157' UNION ALL
select 158,'81 and Over','158' UNION ALL
select 159,'81 and Over','159' UNION ALL
select 160,'81 and Over','160' UNION ALL
select 161,'81 and Over','161' UNION ALL
select 162,'81 and Over','162' UNION ALL
select 163,'81 and Over','163' UNION ALL
select 164,'81 and Over','164' UNION ALL
select 165,'81 and Over','165' UNION ALL
select 166,'81 and Over','166' UNION ALL
select 167,'81 and Over','167' UNION ALL
select 168,'81 and Over','168' UNION ALL
select 169,'81 and Over','169' UNION ALL
select 170,'81 and Over','170' UNION ALL
select 171,'81 and Over','171' UNION ALL
select 172,'81 and Over','172' UNION ALL
select 173,'81 and Over','173' UNION ALL
select 174,'81 and Over','174' UNION ALL
select 175,'81 and Over','175' UNION ALL
select 176,'81 and Over','176' UNION ALL
select 177,'81 and Over','177' UNION ALL
select 178,'81 and Over','178' UNION ALL
select 179,'81 and Over','179' UNION ALL
select 180,'81 and Over','180' UNION ALL
select 181,'81 and Over','181' UNION ALL
select 182,'81 and Over','182' UNION ALL
select 183,'81 and Over','183' UNION ALL
select 184,'81 and Over','184' UNION ALL
select 185,'81 and Over','185' UNION ALL
select 186,'81 and Over','186' UNION ALL
select 187,'81 and Over','187' UNION ALL
select 188,'81 and Over','188' UNION ALL
select 189,'81 and Over','189' UNION ALL
select 190,'81 and Over','190' UNION ALL
select 191,'81 and Over','191' UNION ALL
select 192,'81 and Over','192' UNION ALL
select 193,'81 and Over','193' UNION ALL
select 194,'81 and Over','194' UNION ALL
select 195,'81 and Over','195' UNION ALL
select 196,'81 and Over','196' UNION ALL
select 197,'81 and Over','197' UNION ALL
select 198,'81 and Over','198' UNION ALL
select 199,'81 and Over','199' UNION ALL
select 200,'81 and Over','200';

create or replace TABLE NPS_DASH_SURVEY_MONTH_MAPPING (
	DMONTHYEAR NUMBER(38,0),
	SURVEY_MONTH DATE,
	SURVEYMONTHISDW NUMBER(38,0),
	F_MONTH_YEAR VARCHAR(16777216)
);

INSERT INTO NPS_DASH_SURVEY_MONTH_MAPPING
select 139,'2023-02-01','202302','February-2023' UNION ALL
select 159,'2024-10-01','202410','October-2024' UNION ALL
select 173,'2025-12-01','202512','December-2025' UNION ALL
select 166,'2025-05-01','202505','May-2025' UNION ALL
select 155,'2024-06-01','202406','June-2024' UNION ALL
select 151,'2024-02-01','202402','February-2024' UNION ALL
select 143,'2023-06-01','202306','June-2023' UNION ALL
select 158,'2024-09-01','202409','September-2024' UNION ALL
select 156,'2024-07-01','202407','July-2024' UNION ALL
select 152,'2024-03-01','202403','March-2024' UNION ALL
select 145,'2023-08-01','202308','August-2023' UNION ALL
select 157,'2024-08-01','202408','August-2024' UNION ALL
select 148,'2023-11-01','202311','November-2023' UNION ALL
select 144,'2023-07-01','202307','July-2023' UNION ALL
select 154,'2024-05-01','202405','May-2024' UNION ALL
select 1,'2011-08-01','201108','August-2011' UNION ALL
select 2,'2011-09-01','201109','September-2011' UNION ALL
select 3,'2011-10-01','201110','October-2011' UNION ALL
select 4,'2011-11-01','201111','November-2011' UNION ALL
select 5,'2011-12-01','201112','December-2011' UNION ALL
select 6,'2012-01-01','201201','January-2012' UNION ALL
select 7,'2012-02-01','201202','February-2012' UNION ALL
select 8,'2012-03-01','201203','March-2012' UNION ALL
select 9,'2012-04-01','201204','April-2012' UNION ALL
select 10,'2012-05-01','201205','May-2012' UNION ALL
select 11,'2012-06-01','201206','June-2012' UNION ALL
select 12,'2012-07-01','201207','July-2012' UNION ALL
select 13,'2012-08-01','201208','August-2012' UNION ALL
select 14,'2012-09-01','201209','September-2012' UNION ALL
select 15,'2012-10-01','201210','October-2012' UNION ALL
select 16,'2012-11-01','201211','November-2012' UNION ALL
select 17,'2012-12-01','201212','December-2012' UNION ALL
select 18,'2013-01-01','201301','January-2013' UNION ALL
select 19,'2013-02-01','201302','February-2013' UNION ALL
select 20,'2013-03-01','201303','March-2013' UNION ALL
select 21,'2013-04-01','201304','April-2013' UNION ALL
select 22,'2013-05-01','201305','May-2013' UNION ALL
select 23,'2013-06-01','201306','June-2013' UNION ALL
select 24,'2013-07-01','201307','July-2013' UNION ALL
select 25,'2013-08-01','201308','August-2013' UNION ALL
select 26,'2013-09-01','201309','September-2013' UNION ALL
select 27,'2013-10-01','201310','October-2013' UNION ALL
select 28,'2013-11-01','201311','November-2013' UNION ALL
select 29,'2013-12-01','201312','December-2013' UNION ALL
select 30,'2014-01-01','201401','January-2014' UNION ALL
select 31,'2014-02-01','201402','February-2014' UNION ALL
select 32,'2014-03-01','201403','March-2014' UNION ALL
select 33,'2014-04-01','201404','April-2014' UNION ALL
select 34,'2014-05-01','201405','May-2014' UNION ALL
select 35,'2014-06-01','201406','June-2014' UNION ALL
select 36,'2014-07-01','201407','July-2014' UNION ALL
select 37,'2014-08-01','201408','August-2014' UNION ALL
select 38,'2014-09-01','201409','September-2014' UNION ALL
select 39,'2014-10-01','201410','October-2014' UNION ALL
select 40,'2014-11-01','201411','November-2014' UNION ALL
select 41,'2014-12-01','201412','December-2014' UNION ALL
select 42,'2015-01-01','201501','January-2015' UNION ALL
select 43,'2015-02-01','201502','February-2015' UNION ALL
select 44,'2015-03-01','201503','March-2015' UNION ALL
select 45,'2015-04-01','201504','April-2015' UNION ALL
select 46,'2015-05-01','201505','May-2015' UNION ALL
select 47,'2015-06-01','201506','June-2015' UNION ALL
select 48,'2015-07-01','201507','July-2015' UNION ALL
select 49,'2015-08-01','201508','August-2015' UNION ALL
select 50,'2015-09-01','201509','September-2015' UNION ALL
select 51,'2015-10-01','201510','October-2015' UNION ALL
select 52,'2015-11-01','201511','November-2015' UNION ALL
select 53,'2015-12-01','201512','December-2015' UNION ALL
select 54,'2016-01-01','201601','January-2016' UNION ALL
select 55,'2016-02-01','201602','February-2016' UNION ALL
select 56,'2016-03-01','201603','March-2016' UNION ALL
select 57,'2016-04-01','201604','April-2016' UNION ALL
select 58,'2016-05-01','201605','May-2016' UNION ALL
select 59,'2016-06-01','201606','June-2016' UNION ALL
select 60,'2016-07-01','201607','July-2016' UNION ALL
select 61,'2016-08-01','201608','August-2016' UNION ALL
select 62,'2016-09-01','201609','September-2016' UNION ALL
select 63,'2016-10-01','201610','October-2016' UNION ALL
select 64,'2016-11-01','201611','November-2016' UNION ALL
select 65,'2016-12-01','201612','December-2016' UNION ALL
select 66,'2017-01-01','201701','January-2017' UNION ALL
select 67,'2017-02-01','201702','February-2017' UNION ALL
select 68,'2017-03-01','201703','March-2017' UNION ALL
select 69,'2017-04-01','201704','April-2017' UNION ALL
select 70,'2017-05-01','201705','May-2017' UNION ALL
select 71,'2017-06-01','201706','June-2017' UNION ALL
select 72,'2017-07-01','201707','July-2017' UNION ALL
select 73,'2017-08-01','201708','August-2017' UNION ALL
select 74,'2017-09-01','201709','September-2017' UNION ALL
select 75,'2017-10-01','201710','October-2017' UNION ALL
select 76,'2017-11-01','201711','November-2017' UNION ALL
select 77,'2017-12-01','201712','December-2017' UNION ALL
select 78,'2018-01-01','201801','January-2018' UNION ALL
select 79,'2018-02-01','201802','February-2018' UNION ALL
select 80,'2018-03-01','201803','March-2018' UNION ALL
select 81,'2018-04-01','201804','April-2018' UNION ALL
select 82,'2018-05-01','201805','May-2018' UNION ALL
select 83,'2018-06-01','201806','June-2018' UNION ALL
select 84,'2018-07-01','201807','July-2018' UNION ALL
select 85,'2018-08-01','201808','August-2018' UNION ALL
select 86,'2018-09-01','201809','September-2018' UNION ALL
select 87,'2018-10-01','201810','October-2018' UNION ALL
select 88,'2018-11-01','201811','November-2018' UNION ALL
select 89,'2018-12-01','201812','December-2018' UNION ALL
select 90,'2019-01-01','201901','January-2019' UNION ALL
select 91,'2019-02-01','201902','February-2019' UNION ALL
select 92,'2019-03-01','201903','March-2019' UNION ALL
select 93,'2019-04-01','201904','April-2019' UNION ALL
select 94,'2019-05-01','201905','May-2019' UNION ALL
select 95,'2019-06-01','201906','June-2019' UNION ALL
select 96,'2019-07-01','201907','July-2019' UNION ALL
select 97,'2019-08-01','201908','August-2019' UNION ALL
select 98,'2019-09-01','201909','September-2019' UNION ALL
select 99,'2019-10-01','201910','October-2019' UNION ALL
select 100,'2019-11-01','201911','November-2019' UNION ALL
select 101,'2019-12-01','201912','December-2019' UNION ALL
select 102,'2020-01-01','202001','January-2020' UNION ALL
select 103,'2020-02-01','202002','February-2020' UNION ALL
select 104,'2020-03-01','202003','March-2020' UNION ALL
select 105,'2020-04-01','202004','April-2020' UNION ALL
select 106,'2020-05-01','202005','May-2020' UNION ALL
select 107,'2020-06-01','202006','June-2020' UNION ALL
select 108,'2020-07-01','202007','July-2020' UNION ALL
select 109,'2020-08-01','202008','August-2020' UNION ALL
select 110,'2020-09-01','202009','September-2020' UNION ALL
select 111,'2020-10-01','202010','October-2020' UNION ALL
select 112,'2020-11-01','202011','November-2020' UNION ALL
select 113,'2020-12-01','202012','December-2020' UNION ALL
select 114,'2021-01-01','202101','January-2021' UNION ALL
select 115,'2021-02-01','202102','February-2021' UNION ALL
select 116,'2021-03-01','202103','March-2021' UNION ALL
select 117,'2021-04-01','202104','April-2021' UNION ALL
select 118,'2021-05-01','202105','May-2021' UNION ALL
select 119,'2021-06-01','202106','June-2021' UNION ALL
select 120,'2021-07-01','202107','July-2021' UNION ALL
select 121,'2021-08-01','202108','August-2021' UNION ALL
select 122,'2021-09-01','202109','September-2021' UNION ALL
select 123,'2021-10-01','202110','October-2021' UNION ALL
select 124,'2021-11-01','202111','November-2021' UNION ALL
select 125,'2021-12-01','202112','December-2021' UNION ALL
select 126,'2022-01-01','202201','January-2022' UNION ALL
select 127,'2022-02-01','202202','February-2022' UNION ALL
select 128,'2022-03-01','202203','March-2022' UNION ALL
select 129,'2022-04-01','202204','April-2022' UNION ALL
select 130,'2022-05-01','202205','May-2022' UNION ALL
select 131,'2022-06-01','202206','June-2022' UNION ALL
select 132,'2022-07-01','202207','July-2022' UNION ALL
select 133,'2022-08-01','202208','August-2022' UNION ALL
select 134,'2022-09-01','202209','September-2022' UNION ALL
select 135,'2022-10-01','202210','October-2022' UNION ALL
select 136,'2022-11-01','202211','November-2022' UNION ALL
select 137,'2022-12-01','202212','December-2022' UNION ALL
select 170,'2025-09-01','202509','September-2025' UNION ALL
select 164,'2025-03-01','202503','March-2025' UNION ALL
select 165,'2025-04-01','202504','April-2025' UNION ALL
select 140,'2023-03-01','202303','March-2023' UNION ALL
select 163,'2025-02-01','202502','February-2025' UNION ALL
select 138,'2023-01-01','202301','January-2023' UNION ALL
select 160,'2024-11-01','202411','November-2024' UNION ALL
select 153,'2024-04-01','202404','April-2024' UNION ALL
select 162,'2025-01-01','202501','January-2025' UNION ALL
select 142,'2023-05-01','202305','May-2023' UNION ALL
select 147,'2023-10-01','202310','October-2023' UNION ALL
select 149,'2023-12-01','202312','December-2023' UNION ALL
select 167,'2025-06-01','202506','June-2025' UNION ALL
select 141,'2023-04-01','202304','April-2023' UNION ALL
select 146,'2023-09-01','202309','September-2023' UNION ALL
select 171,'2025-10-01','202510','October-2025' UNION ALL
select 150,'2024-01-01','202401','January-2024' UNION ALL
select 168,'2025-07-01','202507','July-2025' UNION ALL
select 172,'2025-11-01','202511','November-2025' UNION ALL
select 169,'2025-08-01','202508','August-2025' UNION ALL
select 161,'2024-12-01','202412','December-2024';

create or replace TABLE NPS_DASH_MR_CODE_DICTIONARY (
	CODE VARCHAR(16777216),
	CODE1 VARCHAR(16777216),
	CODE2 VARCHAR(16777216),
	CODE3S VARCHAR(16777216),
	VERBATIMCODE VARCHAR(16777216)
);
INSERT INTO NPS_DASH_MR_CODE_DICTIONARY
select 's_QO2MR_Codes078','Member Material','Provider Directory','Provider Directory','All Other Provider Directory Comments' UNION ALL
select 's_QO2MR_Codes118','Miscellaneous','Miscellaneous','Miscellaneous','All Other Miscellaneous Comments' UNION ALL
select 's_QO2MR_Codes126','Unused/Duplicate','Unused/Duplicate','Unused/Duplicate','Cover more: dental/vision/hearing' UNION ALL
select 's_QO2MR_Codes137','Unused/Duplicate','Unused/Duplicate','Unused/Duplicate','Friendlier/more helpful reps' UNION ALL
select 's_QO2MR_Codes003','High Cost','High Cost','High Cost','Premiums' UNION ALL
select 's_QO2MR_Codes103','Satisfied','Satisfied with Plan','Cost','Satisfied with Cost General' UNION ALL
select 's_QO2MR_Codes023','Improve Coverage','Doctor Access Challenges','Doctor Access Challenges','Quality of Doctors' UNION ALL
select 's_QO2MR_Codes062','Improve Coverage','Improve Prescription Coverage','Access to RX','All Other Prescription Coverage Comments' UNION ALL
select 's_QO2MR_Codes037','Improve Coverage','Ancillary Coverage','Dental','Expand dental network/cant find dentist' UNION ALL
select 's_QO2MR_Codes085','Member Material','Customer Service Challenges','Customer Service Challenges','Consistent answer from customer service' UNION ALL
select 's_QO2MR_Codes067','Member Material','Communication Challenges','Communication Challenges','Help me better understand my plan/coverage' UNION ALL
select 's_QO2MR_Codes099','Satisfied','Satisfied','Satisfied','Satisfied with Customer Service' UNION ALL
select 's_QO2MR_Codes112','Miscellaneous','Miscellaneous','Miscellaneous','Provider-related issues' UNION ALL
select 's_QO2MR_Codes061','Improve Coverage','Improve Prescription Coverage','Access to RX','Issues/concerns with mail order pharmacy' UNION ALL
select 's_QO2MR_Codes030','Improve Coverage','Specialist Challenges','Specialist Challenges','Add chiropractic services' UNION ALL
select 's_QO2MR_Codes019','Improve Coverage','Improve Coverage','Improve Coverage','All Other Coverage Comments' UNION ALL
select 's_QO2MR_Codes100','Satisfied','Satisfied','Satisfied','Satisfied with Communications Received' UNION ALL
select 's_QO2MR_Codes088','Member Material','Customer Service Challenges','Customer Service Challenges','Resolve coverage issues/accurate or more timely addressing of coverage issues' UNION ALL
select 's_QO2MR_Codes080','Member Material','Member Card Issues','Member Card Issues','Send out faster' UNION ALL
select 's_QO2MR_Codes015','Improve Coverage','Improve Coverage','Improve Coverage','Include more hospitals/clinics/healthcare facilities in network' UNION ALL
select 's_QO2MR_Codes007','High Cost','High Cost','High Cost','Cost increases/keep costs low or lower' UNION ALL
select 's_QO2MR_Codes130','Unused/Duplicate','Unused/Duplicate','Unused/Duplicate','Satisfied with customer service' UNION ALL
select 's_QO2MR_Codes022','Improve Coverage','Doctor Access Challenges','Doctor Access Challenges','Doctors are too far away' UNION ALL
select 's_QO2MR_Codes070','Member Material','Communication Challenges','Communication Challenges','Improve communications/more contact/call/email me' UNION ALL
select 's_QO2MR_Codes139','Unused/Duplicate','Unused/Duplicate','Unused/Duplicate','Declined to answer' UNION ALL
select 's_QO2MR_Codes115','Miscellaneous','Miscellaneous','Miscellaneous','Want to change/thinking about a change of plans of company/may or will not renew' UNION ALL
select 's_QO2MR_Codes020','Improve Coverage','Doctor Access Challenges','Doctor Access Challenges','Need more doctors in network/my doctor not in network' UNION ALL
select 's_QO2MR_Codes016','Improve Coverage','Improve Coverage','Improve Coverage','Not want/need home visits/counseling' UNION ALL
select 's_QO2MR_Codes125','Unused/Duplicate','Unused/Duplicate','Unused/Duplicate','Cost (other)' UNION ALL
select 's_QO2MR_Codes039','Improve Coverage','Ancillary Coverage','Dental','Add dental coverage' UNION ALL
select 's_QO2MR_Codes087','Member Material','Customer Service Challenges','Customer Service Challenges','Improve customer service (n.s.)' UNION ALL
select 's_QO2MR_Codes063','Improve Coverage','Improve Prescription Coverage','Prior Authorization','Faster turnaround time' UNION ALL
select 's_QO2MR_Codes108','Satisfied','Satisfied with Plan','Coverage','Satisfied with medical coverage' UNION ALL
select 's_QO2MR_Codes095','Member Material','Customer Service Challenges','Customer Service Challenges','All Other Customer Service Comments' UNION ALL
select 's_QO2MR_Codes009','Improve Coverage','Improve Coverage','Improve Coverage','Cover more test/procedures/surgeries' UNION ALL
select 's_QO2MR_Codes064','Improve Coverage','Improve Prescription Coverage','Prior Authorization','Dont require prior authorization' UNION ALL
select 's_QO2MR_Codes045','Improve Coverage','Ancillary Coverage','Hearing','Expand hearing benefit coverage' UNION ALL
select 's_QO2MR_Codes089','Member Material','Customer Service Challenges','Customer Service Challenges','Pay bills more quickly/receiving bills' UNION ALL
select 's_QO2MR_Codes074','Member Material','Communication Challenges','Communication Challenges','All Other Communication Comments' UNION ALL
select 's_QO2MR_Codes021','Improve Coverage','Doctor Access Challenges','Doctor Access Challenges','Doctors not accepting Medicaid' UNION ALL
select 's_QO2MR_Codes124','Unused/Duplicate','Unused/Duplicate','Unused/Duplicate','Issues/Concerns with bills and claims' UNION ALL
select 's_QO2MR_Codes092','Member Material','Customer Service Challenges','Customer Service Challenges','Issues/concerns with bills and claims' UNION ALL
select 's_QO2MR_Codes012','Improve Coverage','Improve Coverage','Improve Coverage','Include natural/holistic remedies' UNION ALL
select 's_QO2MR_Codes127','Unused/Duplicate','Unused/Duplicate','Unused/Duplicate','Satisfied with cost' UNION ALL
select 's_QO2MR_Codes128','Unused/Duplicate','Unused/Duplicate','Unused/Duplicate','Satisfied with coverage' UNION ALL
select 's_QO2MR_Codes058','Improve Coverage','Improve Prescription Coverage','Access to RX','Cover what doctors prescribe' UNION ALL
select 's_QO2MR_Codes055','Improve Coverage','Improve Prescription Coverage','Access to RX','Longer than 30-day/90-day prescription supply' UNION ALL
select 's_QO2MR_Codes102','Satisfied','Satisfied','Satisfied','Satisfied with doctor/provider' UNION ALL
select 's_QO2MR_Codes041','Improve Coverage','Ancillary Coverage','Vision','Expand Vision network' UNION ALL
select 's_QO2MR_Codes068','Member Material','Communication Challenges','Communication Challenges','Better communication of re-application/re-certification' UNION ALL
select 's_QO2MR_Codes129','Unused/Duplicate','Unused/Duplicate','Unused/Duplicate','Satisfied with communication received' UNION ALL
select 's_QO2MR_Codes069','Member Material','Communication Challenges','Communication Challenges','Make materials easier to understand' UNION ALL
select 's_QO2MR_Codes008','High Cost','High Cost','High Cost','All Other High Cost Comments' UNION ALL
select 's_QO2MR_Codes065','Improve Coverage','Improve Prescription Coverage','Prior Authorization','All Other Prior Authorization Comments' UNION ALL
select 's_QO2MR_Codes101','Satisfied','Satisfied','Satisfied','Satisfied/happy general comments' UNION ALL
select 's_QO2MR_Codes071','Member Material','Communication Challenges','Communication Challenges','Less communication' UNION ALL
select 's_QO2MR_Codes105','Satisfied','Satisfied with Plan','Cost','Satisfied with Rx Cost' UNION ALL
select 's_QO2MR_Codes135','Unused/Duplicate','Unused/Duplicate','Unused/Duplicate','Little/no use or no interaction/recently started' UNION ALL
select 's_QO2MR_Codes072','Member Material','Communication Challenges','Communication Challenges','Provide bilingual communications/customer service/printed materials etc.' UNION ALL
select 's_QO2MR_Codes086','Member Material','Customer Service Challenges','Customer Service Challenges','Need more follow-up from customer service' UNION ALL
select 's_QO2MR_Codes049','Improve Coverage','Improve Prescription Coverage','RX Costs','Donut hole dissatisfaction' UNION ALL
select 's_QO2MR_Codes018','Improve Coverage','Improve Coverage','Improve Coverage','Better/more coverage/different plans' UNION ALL
select 's_QO2MR_Codes113','Miscellaneous','Miscellaneous','Miscellaneous','Little/no use or no interaction/recently started' UNION ALL
select 's_QO2MR_Codes109','Satisfied','Satisfied with Plan','Coverage','Satisfied with ancillary coverage/mental health coverage' UNION ALL
select 's_QO2MR_Codes079','Member Material','Member Card Issues','Member Card Issues','Wrong information on card' UNION ALL
select 's_QO2MR_Codes001','High Cost','High Cost','High Cost','Lower Cost of Plan/Reduce cost' UNION ALL
select 's_QO2MR_Codes034','Improve Coverage','Mental Health','Mental Health','More mental health providers in network' UNION ALL
select 's_QO2MR_Codes028','Improve Coverage','Doctor Access Challenges','Doctor Access Challenges','All Other Doctor Access Comments' UNION ALL
select 's_QO2MR_Codes084','Member Material','Customer Service Challenges','Customer Service Challenges','Quality of customer service (attitude)' UNION ALL
select 's_QO2MR_Codes029','Improve Coverage','Specialist Challenges','Specialist Challenges','Distance to specialist' UNION ALL
select 's_QO2MR_Codes004','High Cost','High Cost','High Cost','Eliminate deductible/spend down' UNION ALL
select 's_QO2MR_Codes104','Satisfied','Satisfied with Plan','Cost','Satisfied with Medical Cost' UNION ALL
select 's_QO2MR_Codes027','Improve Coverage','Doctor Access Challenges','Doctor Access Challenges','Doctors not accepting UHC' UNION ALL
select 's_QO2MR_Codes002','High Cost','High Cost','High Cost','Cost of Copay/coinsurance' UNION ALL
select 's_QO2MR_Codes024','Improve Coverage','Doctor Access Challenges','Doctor Access Challenges','Too long to get an appointment' UNION ALL
select 's_QO2MR_Codes094','Member Material','Customer Service Challenges','Customer Service Challenges','More/better web-based cusomter service' UNION ALL
select 's_QO2MR_Codes114','Miscellaneous','Miscellaneous','Miscellaneous','Governmental/political/ObamaCare/health reform concerns or comments' UNION ALL
select 's_QO2MR_Codes056','Improve Coverage','Improve Prescription Coverage','Access to RX','Cover more prescriptions/wider formulary' UNION ALL
select 's_QO2MR_Codes044','Improve Coverage','Ancillary Coverage','Vision','All Other Vision Comments' UNION ALL
select 's_QO2MR_Codes048','Improve Coverage','Improve Prescription Coverage','RX Costs','High Prescription costs' UNION ALL
select 's_QO2MR_Codes017','Improve Coverage','Improve Coverage','Improve Coverage','Cover/need personal in-home care' UNION ALL
select 's_QO2MR_Codes134','Unused/Duplicate','Unused/Duplicate','Unused/Duplicate','Provider-related issues' UNION ALL
select 's_QO2MR_Codes116','Miscellaneous','Miscellaneous','Miscellaneous','Not something I would discuss/bring up' UNION ALL
select 's_QO2MR_Codes026','Improve Coverage','Doctor Access Challenges','Doctor Access Challenges','Slow approval/referral process' UNION ALL
select 's_QO2MR_Codes046','Improve Coverage','Ancillary Coverage','Hearing','Add hearing benefit coverage' UNION ALL
select 's_QO2MR_Codes097','Member Material','Availability of Customer Service','Availability of Customer Service','Easier to access/not being put on hold' UNION ALL
select 's_QO2MR_Codes006','High Cost','High Cost','High Cost','Out of pocket/Unexpected costs' UNION ALL
select 's_QO2MR_Codes054','Improve Coverage','Improve Prescription Coverage','Access to RX','Script no longer covered/script used to be covered' UNION ALL
select 's_QO2MR_Codes075','Member Material','Provider Directory','Provider Directory','Update/correct provider directory/Verify Dr. still in network' UNION ALL
select 's_QO2MR_Codes073','Member Material','Communication Challenges','Communication Challenges','Better communication/accurate communication around my prescription coverage/changes to prescription coverage' UNION ALL
select 's_QO2MR_Codes098','Member Material','Availability of Customer Service','Availability of Customer Service','All Other Availability of Customer Service Comments' UNION ALL
select 's_QO2MR_Codes111','Miscellaneous','Miscellaneous','Miscellaneous','Improve website' UNION ALL
select 's_QO2MR_Codes138','Unused/Duplicate','Unused/Duplicate','Unused/Duplicate','Issues with receiving ID card/errors/problems' UNION ALL
select 's_QO2MR_Codes011','Improve Coverage','Improve Coverage','Improve Coverage','Expand medical supplies/equipment' UNION ALL
select 's_QO2MR_Codes120','Other','Other','Other','None' UNION ALL
select 's_QO2MR_Codes043','Improve Coverage','Ancillary Coverage','Vision','Add vision coverage' UNION ALL
select 's_QO2MR_Codes081','Member Material','Member Card Issues','Member Card Issues','Not received card' UNION ALL
select 's_QO2MR_Codes106','Satisfied','Satisfied with Plan','Coverage','Satisfied with Coverage General' UNION ALL
select 's_QO2MR_Codes077','Member Material','Provider Directory','Provider Directory','Need easier access' UNION ALL
select 's_QO2MR_Codes066','Member Material','Communication Challenges','Communication Challenges','Better Communication around changes' UNION ALL
select 's_QO2MR_Codes013','Improve Coverage','Improve Coverage','Improve Coverage','More wellness coverage/Silver Sneakers/YMCA/gym memberships' UNION ALL
select 's_QO2MR_Codes031','Improve Coverage','Specialist Challenges','Specialist Challenges','Add more specialists to network' UNION ALL
select 's_QO2MR_Codes005','High Cost','High Cost','High Cost','General too high medical costs' UNION ALL
select 's_QO2MR_Codes107','Satisfied','Satisfied with Plan','Coverage','Satisfied with network (access to Rx, pharmacies, dr/provider, specialists)' UNION ALL
select 's_QO2MR_Codes096','Member Material','Availability of Customer Service','Availability of Customer Service','Faster resolution' UNION ALL
select 's_QO2MR_Codes010','Improve Coverage','Improve Coverage','Improve Coverage','Transportation coverage/issues' UNION ALL
select 's_QO2MR_Codes050','Improve Coverage','Improve Prescription Coverage','RX Costs','Increased price of script/script suddenly changed price/tier' UNION ALL
select 's_QO2MR_Codes082','Member Material','Member Card Issues','Member Card Issues','All Other Member Card Comments' UNION ALL
select 's_QO2MR_Codes091','Member Material','Customer Service Challenges','Customer Service Challenges','More upfront/honest about plans/cost' UNION ALL
select 's_QO2MR_Codes131','Unused/Duplicate','Unused/Duplicate','Unused/Duplicate','Satisfied/happy general comments' UNION ALL
select 's_QO2MR_Codes090','Member Material','Customer Service Challenges','Customer Service Challenges','Need one representative/one person to contact' UNION ALL
select 's_QO2MR_Codes040','Improve Coverage','Ancillary Coverage','Dental','All Other Dental Comments' UNION ALL
select 's_QO2MR_Codes119','Other','Other','Other','Other' UNION ALL
select 's_QO2MR_Codes042','Improve Coverage','Ancillary Coverage','Vision','Expand vision benefit coverage' UNION ALL
select 's_QO2MR_Codes035','Improve Coverage','Mental Health','Mental Health','Accessibility of mental health providers' UNION ALL
select 's_QO2MR_Codes059','Improve Coverage','Improve Prescription Coverage','Access to RX','Cover name brand drugs' UNION ALL
select 's_QO2MR_Codes047','Improve Coverage','Ancillary Coverage','Hearing','All Other Hearing Comments' UNION ALL
select 's_QO2MR_Codes052','Improve Coverage','Improve Prescription Coverage','RX Costs','All Other Rx Cost Comments' UNION ALL
select 's_QO2MR_Codes136','Unused/Duplicate','Unused/Duplicate','Unused/Duplicate','Governmental/political/Obamacare/health reform concerns or comm' UNION ALL
select 's_QO2MR_Codes076','Member Material','Provider Directory','Provider Directory','Send physical directory' UNION ALL
select 's_QO2MR_Codes014','Improve Coverage','Improve Coverage','Improve Coverage','Wider medical benefit coverage/dont deny treatment' UNION ALL
select 's_QO2MR_Codes032','Improve Coverage','Specialist Challenges','Specialist Challenges','Add pediatric services' UNION ALL
select 's_QO2MR_Codes133','Unused/Duplicate','Unused/Duplicate','Unused/Duplicate','Issues/Concerns with mail order pharmacy' UNION ALL
select 's_QO2MR_Codes083','Member Material','Customer Service Challenges','Customer Service Challenges','More trained/knowledgeable customer service reps' UNION ALL
select 's_QO2MR_Codes036','Improve Coverage','Mental Health','Mental Health','All Other Mental Health Comments' UNION ALL
select 's_QO2MR_Codes123','Unused/Duplicate','Unused/Duplicate','Unused/Duplicate','Out-of pocket/Unexpected costs' UNION ALL
select 's_QO2MR_Codes038','Improve Coverage','Ancillary Coverage','Dental','Expand dental benefits coverage' UNION ALL
select 's_QO2MR_Codes057','Improve Coverage','Improve Prescription Coverage','Access to RX','Covers only x prescriptions/monthly amount covered' UNION ALL
select 's_QO2MR_Codes110','Satisfied','Satisfied with Plan','Coverage','Satisfied with Rx Coverage' UNION ALL
select 's_QO2MR_Codes121','Other','Other','Other','Dont know' UNION ALL
select 's_QO2MR_Codes060','Improve Coverage','Improve Prescription Coverage','Access to RX','Had to switch pharmacies/keep pharmacy in network/add more pharmacies' UNION ALL
select 's_QO2MR_Codes132','Unused/Duplicate','Unused/Duplicate','Unused/Duplicate','Better communication/accurate communication around my coverage' UNION ALL
select 's_QO2MR_Codes053','Improve Coverage','Improve Prescription Coverage','Access to RX','Generic vs. brand coverage/authorization' UNION ALL
select 's_QO2MR_Codes093','Member Material','Customer Service Challenges','Customer Service Challenges','Issues with automated customer service phone system' UNION ALL
select 's_QO2MR_Codes033','Improve Coverage','Specialist Challenges','Specialist Challenges','All Other Specialist Comments' UNION ALL
select 's_QO2MR_Codes051','Improve Coverage','Improve Prescription Coverage','RX Costs','No co-pays/cover more of the cost' UNION ALL
select 's_QO2MR_Codes117','Miscellaneous','Miscellaneous','Miscellaneous','Not recommend/not satisfied' UNION ALL
select 's_QO2MR_Codes122','Other','Other','Other','Declined to answer' UNION ALL
select 's_QO2MR_Codes025','Improve Coverage','Doctor Access Challenges','Doctor Access Challenges','Had to change providers/provider dropped';
create or replace TABLE NPS_DASH_STATE_STRATEGIES_2022
 (
	STATE_CD VARCHAR(16777216),
	"2020_rate_start_date" VARCHAR(16777216),
	"2021_rate_start_date" VARCHAR(16777216),
	"2022_rate_start_date" VARCHAR(16777216),
	"2021_rate_deferral" VARCHAR(16777216),
	"2022_rate_deferral" VARCHAR(16777216),
	"2022_commission_change" VARCHAR(16777216),
	"2022_uw_incentive" VARCHAR(16777216),
	MID_CHANGE VARCHAR(16777216),
	MID_CHANGE_DATE VARCHAR(16777216),
	MID_CHANGE_DESC VARCHAR(16777216),
	NLE_START_DATE VARCHAR(16777216),
	NLE_WAVE VARCHAR(16777216),
	NLE_WAVE1 VARCHAR(16777216)
);

select * from NPS_DASH_STATE_STRATEGIES_2022;
INSERT INTO NPS_DASH_STATE_STRATEGIES_2022
select 'AK','2020-01-01','2021-01-01','2022-06-01','N','Y','N','N','N',NULL,'None',NULL,NULL,NULL
UNION ALL
select 'AL','2020-01-01','2021-01-01','2022-06-01','N','Y','N','Y','Y','2021-01-01','from 5% to 7%',NULL,NULL,NULL
UNION ALL
select 'AR','2020-01-01','2021-01-01','2022-06-01','N','Y','N','Y','Y','2022-06-01','from 5% to 7%','2022-10-01','Wave 3.3','Wave 3.3 (9/30/22)'
UNION ALL
select 'AZ','2020-04-01','2021-06-01','2022-06-01','Y','N','Y','Y','Y','2021-06-01','from 5% to 7%','2022-06-01','Wave 3.1','Wave 3.1 (5/13/22)'
UNION ALL
select 'CA','2020-04-01','2021-06-01','2022-06-01','Y','N','N','N','Y','2021-06-01','from 5% to 7%',NULL,NULL,NULL
UNION ALL
select 'CO','2020-01-01','2021-06-01','2022-06-01','Y','N','N','N','Y','2021-06-01','add on multi-ins 5%',NULL,NULL,NULL
UNION ALL
select 'CT','2020-01-01','2021-01-01','2022-06-01','N','Y','N','N','Y','2021-01-01','from 5% to 7%',NULL,NULL,NULL
UNION ALL
select 'DC','2020-01-01','2021-01-01','2022-06-01','N','Y','N','N','N',NULL,'None',NULL,NULL,NULL
UNION ALL
select 'DE','2020-01-01','2021-01-01','2022-06-01','N','Y','N','N','Y','2022-06-01','from 5% to 7%',NULL,NULL,NULL
UNION ALL
select 'FL','2020-01-01','2021-06-01','2022-06-01','Y','N','Y','N','N',NULL,'None',NULL,NULL,NULL
UNION ALL
select 'GA','2020-01-01','2021-01-01','2022-06-01','N','Y','Y','Y','Y','2021-01-01','from 5% to 7%',NULL,NULL,NULL
UNION ALL
select 'HI','2020-01-01','2021-01-01','2022-06-01','N','Y','N','N','Y','2021-01-01','from 5% to 7%',NULL,NULL,NULL
UNION ALL
select 'IA','2020-01-01','2021-01-01','2022-06-01','N','Y','N','N','Y','2022-06-01','from 5% to 7%',NULL,NULL,NULL
UNION ALL
select 'ID','2020-01-01','2021-01-01','2022-06-01','N','Y','N','Y','N',NULL,'None',NULL,NULL,NULL
UNION ALL
select 'IL','2020-04-01','2021-06-01','2022-06-01','Y','N','Y','N','Y','2021-06-01','from 5% to 7%','2022-06-01','Wave 3.1','Wave 3.1 (5/13/22)'
UNION ALL
select 'IN','2020-01-01','2021-06-01','2022-06-01','Y','N','N','N','Y','2021-06-01','from 5% to 7%','2022-06-01','Wave 3.1','Wave 3.1 (5/13/22)'
UNION ALL
select 'KS','2020-01-01','2021-01-01','2022-06-01','N','Y','N','N','Y','2022-06-01','from 5% to 7%','2022-09-01','Wave 3.2','Wave 3.2 (8/26/22)'
UNION ALL
select 'KY','2020-01-01','2021-06-01','2022-06-01','Y','N','N','N','Y','2022-06-01','add on multi-ins 5%',NULL,NULL,NULL
UNION ALL
select 'LA','2020-01-01','2021-06-01','2022-06-01','Y','N','N','Y','Y','2021-06-01','from 5% to 7%',NULL,NULL,NULL
UNION ALL
select 'MA','2020-06-01','2021-06-01','2022-06-01','N','N','N','N','N',NULL,'None',NULL,NULL,NULL
UNION ALL
select 'MD','2020-01-01','2021-01-01','2022-06-01','N','Y','N','N','Y','2022-06-01','from 5% to 7%',NULL,NULL,NULL
UNION ALL
select 'ME','2020-01-01','2021-01-01','2022-06-01','N','Y','N','N','Y','2021-01-01','from 5% to 7%',NULL,NULL,NULL
UNION ALL
select 'MI','2020-01-01','2021-06-01','2022-06-01','Y','N','Y','Y','Y','2021-06-01','add on multi-ins 5%',NULL,NULL,NULL
UNION ALL
select 'MN','2020-01-01','2021-01-01','2022-06-01','N','Y','N','N','N',NULL,'None',NULL,NULL,NULL
UNION ALL
select 'MO','2020-01-01','2021-06-01','2022-06-01','Y','N','N','N','Y','2021-06-01','from 5% to 7%',NULL,NULL,NULL
UNION ALL
select 'MS','2020-01-01','2021-01-01','2022-06-01','N','Y','N','N','N',NULL,'None',NULL,NULL,NULL
UNION ALL
select 'MT','2020-06-01','2021-01-01','2022-06-01','N','Y','N','N','Y','2022-06-01','add on multi-ins 7%',NULL,NULL,NULL
UNION ALL
select 'NC','2020-01-01','2021-06-01','2022-06-01','Y','N','Y','Y','Y','2021-06-01','from 5% to 7%','2021-10-01','Wave 2','Wave 2 (2021)'
UNION ALL
select 'ND','2020-01-01','2021-01-01','2022-06-01','N','Y','N','N','N',NULL,'None','2020-11-01','Wave 1','Wave 1 (2020)'
UNION ALL
select 'NE','2020-01-01','2021-01-01','2022-06-01','N','Y','N','N','N',NULL,'None',NULL,NULL,NULL
UNION ALL
select 'NH','2020-01-01','2021-01-01','2022-01-01','N','N','N','Y','Y','2021-01-01','from 5% to 7%',NULL,NULL,NULL
UNION ALL
select 'NJ','2020-01-01','2021-08-01','2022-08-01','Y','N','N','Y','Y','2021-06-01','add on multi-ins 5%',NULL,NULL,NULL
UNION ALL
select 'NM','2020-01-01','2021-06-01','2022-06-01','Y','N','N','N','Y','2021-06-01','from 5% to 7%',NULL,NULL,NULL
UNION ALL
select 'NV','2020-01-01','2021-01-01','2022-06-01','N','Y','N','N','Y','2021-01-01','from 5% to 7%',NULL,NULL,NULL
UNION ALL
select 'NY','2020-01-01','2021-09-01','2022-09-01','Y','N','N','N','N',NULL,'None',NULL,NULL,NULL
UNION ALL
select 'OH','2020-04-01','2021-06-01','2022-06-01','Y','N','Y','Y','Y','2021-06-01','from 5% to 7%','2021-10-01','Wave 2','Wave 2 (2021)'
UNION ALL
select 'OK','2020-01-01','2021-01-01','2022-01-01','N','N','N','N','Y','2022-01-01','from 5% to 7%',NULL,NULL,NULL
UNION ALL
select 'OR','2020-01-01','2021-01-01','2022-01-01','N','N','N','N','Y','2021-01-01','from 5% to 7%',NULL,NULL,NULL
UNION ALL
select 'PA','2020-01-01','2021-06-01','2022-06-01','Y','N','Y','Y','Y','2021-06-01','from 5% to 7%','2022-06-01','Wave 3.1','Wave 3.1 (5/13/22)'
UNION ALL
select 'PR','2020-01-01','2021-01-01','2022-06-01','N','Y','N','N','Y','2022-06-01','from 5% to 7%',NULL,NULL,NULL
UNION ALL
select 'RI','2020-04-01','2021-01-01','2022-06-01','N','Y','N','N','Y','2021-01-01','from 5% to 7%',NULL,NULL,NULL
UNION ALL
select 'SC','2020-04-01','2021-06-01','2022-06-01','Y','N','Y','Y','Y','2021-06-01','from 5% to 7%','2021-10-01','Wave 2','Wave 2 (2021)'
UNION ALL
select 'SD','2020-01-01','2021-01-01','2022-06-01','N','Y','N','N','Y','2022-06-01','add on multi-ins 5%',NULL,NULL,NULL
UNION ALL
select 'TN','2020-01-01','2021-01-01','2022-06-01','N','Y','N','N','Y','2021-01-01','from 5% to 7%',NULL,NULL,NULL
UNION ALL
select 'TX','2020-07-01','2021-07-01','2022-07-01','N','N','Y','Y','Y','2021-07-01','from 5% to 7%','2021-10-01','Wave 2','Wave 2 (2021)'
UNION ALL
select 'UT','2020-01-01','2021-01-01','2022-06-01','N','Y','N','N','Y','2021-01-01','from 5% to 7%',NULL,NULL,NULL
UNION ALL
select 'VA','2020-01-01','2021-06-01','2022-06-01','Y','N','Y','Y','Y','2021-06-01','from 5% to 7%',NULL,NULL,NULL
UNION ALL
select 'VI','2020-01-01','2021-01-01','2022-06-01','N','Y','N','N','Y','2021-01-01','from 5% to 7%',NULL,NULL,NULL
UNION ALL
select 'VT','2020-01-01','2021-01-01','2022-06-01','N','Y','N','N','N',NULL,'None',NULL,NULL,NULL
UNION ALL
select 'WA','2020-04-01','2021-01-01','2022-06-01','N','Y','N','N','Y','2021-01-01','from 5% to 7%',NULL,NULL,NULL
UNION ALL
select 'WI','2020-01-01','2021-01-01','2022-06-01','N','Y','N','N','Y','2022-06-01','from 5% to 7%',NULL,NULL,NULL
UNION ALL
select 'WV','2020-01-01','2021-06-01','2022-06-01','Y','N','N','Y','Y','2021-06-01','from 5% to 7%',NULL,NULL,NULL
UNION ALL
select 'WY','2020-01-01','2021-01-01','2022-06-01','N','Y','N','N','N',NULL,'None',NULL,NULL,NULL
UNION ALL
select 'XX','2020-01-01','2021-01-01','2022-01-01','N','N','N','N','N',NULL,'None',NULL,NULL,NULL
UNION ALL
select 'GU','2020-01-01','2021-01-01','2022-06-01','N','Y','N','N','Y','2022-06-01','from 5% to 7%',NULL,NULL,NULL
UNION ALL
select 'AS','2020-01-01','2021-01-01','2022-01-01','N','N','N','N','N',NULL,'None',NULL,NULL,NULL
UNION ALL
select 'MP','2020-01-01','2021-01-01','2022-06-01','N','Y','N','N','Y','2022-06-01','from 5% to 7%',NULL,NULL,NULL;