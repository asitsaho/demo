USE SCHEMA BDR_CONF; CREATE OR REPLACE PROCEDURE "SP_AGENT_IXL_RPTAGTAPPL_D"("DB_NAME" VARCHAR(16777216), "APPLICATION" VARCHAR(16777216), "WORKFLOW_NAME" VARCHAR(16777216), "OBJECT_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '

-- Original workflow: wkf_ConformedDimensions_IU_TargetLoad_D
-- Original mapping: m_Agent_IXL_RptAgtAppl_D
-- Original folder: Conformed_Dimensions
-- Original filename: wkf_ConformedDimensions_IU_TargetLoad_D.XML

DECLARE


V_ROWS_INSERTED  INTEGER;
V_ROWS_UPDATED INTEGER;
V_ROWS_DELETED INTEGER;
V_LAST_QUERY_ID VARCHAR;

V_WH VARCHAR;
V_BATCH_ID INTEGER;


V_BATCH_OBJECT_START_TIME        VARCHAR;
V_STEP_START_TIME    VARCHAR;
V_STEP_NAME VARCHAR;
V_STEP_SEQ INTEGER DEFAULT 0;
V_ETL_LST_BTCH_ID INTEGER;

BEGIN

EXECUTE IMMEDIATE ''USE DATABASE ''||:DB_NAME; 

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_BATCH_OBJECT_START_TIME := (SELECT CURRENT_TIMESTAMP());



LET res1 RESULTSET := 
(

SELECT 

WH ,
BATCH_ID
  
FROM UTIL.ETL_BATCH_OBJECT_CONTROL
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
FETCH FIRST 1 ROW ONLY

)
;


LET C1 CURSOR FOR res1;
open C1;
FETCH C1 into  V_WH,V_BATCH_ID ;
close C1;





EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:V_WH;
USE SCHEMA BDR_CONF;


INSERT INTO UTIL.ETL_BATCH_OBJECT_INCR_VALU (APPLICATION, WORKFLOW_NAME, OBJECT_NAME, INCR_COLUMN, INCR_COLUMN_VALUE )
SELECT * FROM 
(select :APPLICATION AS APPLICATION, :WORKFLOW_NAME AS WORKFLOW_NAME, :OBJECT_NAME AS OBJECT_NAME, ''ETL_LST_BTCH_ID'' AS INCR_COLUMN, -1 AS INCR_COLUMN_VALUE) A
WHERE NOT EXISTS (SELECT 1 FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU B WHERE B.APPLICATION = A.APPLICATION AND B.WORKFLOW_NAME = A.WORKFLOW_NAME AND B.OBJECT_NAME = A.OBJECT_NAME AND B.INCR_COLUMN = A.INCR_COLUMN)
;
V_ETL_LST_BTCH_ID := (SELECT INCR_COLUMN_VALUE FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID'');  


-- Component SQ_sc_RPT_AGT_APPL, Type SOURCE 
CREATE OR REPLACE TEMPORARY TABLE SQ_sc_RPT_AGT_APPL AS
(
SELECT SRC.*, row_number() over (order by 1) AS source_record_id FROM (
with RPT_AGT_APPL_SRC AS 
(
SELECT  DISTINCT
        agt.MEMBERSHIP_NUMBER,
        agt.insured_cd,
        agt.application_id,
        agt.appl_receipt_date,
        agt.creation_date,
        agt.first_name,
        agt.middle_name,
        agt.last_name,
        agt.date_of_birth,
        agt.state_cd,
        agt.plan_cd,
        agt.requested_effective_date,
        agt.adjudication_cd,
        agt.adjudication_date,
        agt.writing_agent_id,
        agt.writing_agent_signature_ind,
        agt.selling_agent_id,
        agt.selling_agent_signature_ind,
        agt.servicing_agent_id,
        agt.hra_admin_id,
        agt.disabled_ind,
        agt.actual_effective_date,
        agt.hhold_paid_through_date,
        agt.contact_day_time_phone_no,
        agt.appl_signature_date,
        agt.hash_cd,
        agt.dcn,
        agt.wq_type,
        agt.agent_submission_type,
        agt.phone_enrollment_type_id,
        agt.submission_method,
        agt.medicare_claim_num,
        agt.agent_commission_oe_ind,
        agt.agent_commission_gi_ind,
        agt.appl_actor_id,
        CASE
          WHEN agt.appl_actor_id = 1 and aag.AGENT_TYPE_ID = 5 and aag.agent_id is not null
            THEN aag.AGENT_ID
          ELSE ''''
          END as  Referral_Agent_ID
,agt.vendor_code /* new added in May 2021 release */
        ,DECODE(agt.underwriting_waiver_ind,''Y'',''N'',''N'',''Y'') underwriting_waiver_ind
        , agt.APPL_AGENT_UPDATE
              ,agt.INDIVIDUAL_UPDATE
              ,agt.APPL_INDICATOR_UPDATE
              ,agt.APPL_INDIVIDUAL_UPDATE
              ,agt.HOUSEHOLD_UPDATE
              ,agt.INSURED_PLAN_UPDATE
      FROM
        (
          SELECT /*+parallel(8)*/ DISTINCT
           nvl( LPAD (nvl(to_char(a.membership_number), ''''), 9, 0)||''-''||nvl(to_char(a.ASSOCIATION_ID), '''') ,
            (LPAD (nvl(to_char(HP.membership_number), ''''), 9, 0)||''-''||nvl(to_char(HP.ASSOCIATION_ID), ''''))) AS MEMBERSHIP_NUMBER,
			
			

			
			
			
            a.insured_cd,
            a.application_id,
            a.appl_receipt_date,
            TRUNC(a.creation_date, ''DD'') creation_date,
            ai.first_name,
SUBSTR (ai.middle_name, 1, 5) AS middle_name, /* - keeping maximum 5chanracter */
            ai.last_name,
            NVL (i.date_of_birth,ai.date_of_birth) AS date_of_birth,
            a.state_cd,
            a.plan_request_1 as plan_cd,
            a.requested_effective_date,
            a.adjudication_cd,
            a.adjudication_date,
/*  new added in sep 2012 release */
            aa.writing_agent_id,
            ain.writing_agent_signature_ind,
            aa.selling_agent_id,
            ain.selling_agent_signature_ind,
            ip_data.servicing_agent_id,
            ip_data.hra_admin_id,
            ip_data.disabled_ind,
            ip_data.insured_plan_effective_date AS actual_effective_date,
            h.hhold_paid_through_date,
			
			
			
			
/*             CASE NVL(LENGTH (RTRIM (a.day_phone_num)),0)  
			
			WHEN 0  THEN '''' 
			WHEN 10 THEN    ''(''|| SUBSTR (a.day_phone_num, 1, 3)|| '') ''|| SUBSTR (a.day_phone_num, 4, 3)|| ''-''|| SUBSTR (a.day_phone_num, 7, 4)
            WHEN 7  THEN    SUBSTR (a.day_phone_num, 4, 3)|| ''-''|| SUBSTR (a.day_phone_num, 7, 4) ELSE a.day_phone_num END||
			
			
            CASE 
			NVL (LENGTH (RTRIM (a.day_phone_num_extn)), 0)
			
            WHEN 0 THEN '''' 
			ELSE '' EXT '' || a.day_phone_num_extn END 
			
			
			AS contact_day_time_phone_no, */
			  
			           CASE 
			
			NVL(LENGTH (RTRIM (a.day_phone_num)),0) WHEN 0 THEN '''' WHEN 10
              THEN    ''(''|| nvl(to_char(SUBSTR (a.day_phone_num, 1, 3) ), '''') || '') ''|| 
			                nvl(to_char(SUBSTR (a.day_phone_num, 4, 3)), '''') || ''-''|| 
							nvl(to_char(SUBSTR (a.day_phone_num, 7, 4)), '''')
										
										
										
             WHEN 7 THEN 
			 
			 nvl(to_char(SUBSTR (a.day_phone_num, 4, 3)), '''')   || ''-''|| nvl(to_char(SUBSTR (a.day_phone_num, 7, 4)), '''')  ELSE a.day_phone_num END
														
														||
														
														
            CASE NVL (LENGTH (RTRIM (a.day_phone_num_extn)), 0)
              WHEN 0 THEN '''' ELSE '' EXT '' || nvl(to_char(a.day_phone_num_extn), '''') END AS contact_day_time_phone_no,  
			  
			  
			  
            a.appl_signature_date,
            a.hash_cd,
            a.appl_image_num_orig AS dcn,
            case when a.adjudication_cd=''P'' then wq_type.type_desc else '' '' end AS wq_type,
            (SELECT  ANY_VALUE ( nvl(to_char(st.agent_submission_type_id), '''') || ''-''|| nvl(to_char(st.agent_submission_type_desc), '''')  )
             FROM SRC_COMPAS_D.agent_submission_type st
             WHERE ip_data.agent_submission_type_id =st.agent_submission_type_id) AS agent_submission_type,  
      /*        ip_data.agent_submission_type as agent_submission_type, ----OAS ADD */
            a.phone_enrollment_type_id,
CASE
                        WHEN a.submission_method_id=''1'' THEN ''1-PAPER''
                        WHEN a.submission_method_id=''2'' THEN ''2-FAX''
                        WHEN a.submission_method_id=''3'' THEN ''3-ELECTRONIC IMAGE''
                        WHEN a.submission_method_id=''4'' THEN ''4-ELECTRONIC DATA''
                        WHEN a.submission_method_id=''5'' THEN ''5-PAPER-WEB''
                        WHEN a.submission_method_id=''6'' THEN ''6-FAX-WEB''
                        WHEN a.submission_method_id=''7'' THEN ''7-ELECTRONIC_IMAGE_WET''
                        WHEN a.submission_method_id=''8'' THEN ''8-ELECTRONIC DATA WET''
                        WHEN a.submission_method_id=''9'' THEN ''9-ELECTRONIC REMOTE SIGNATURE''
                        ELSE ''''
                    END as submission_method,
            ai.medicare_claim_num,
            ip_data.agent_commission_oe_ind,
            ip_data.agent_commission_gi_ind
,ip_data.underwriting_waiver_ind		/* SCR80223 */
,a.appl_actor_id                                /*  */
              ,a.vendor_code
              ,aa.APPL_AGENT_UPDATE
              ,i.INDIVIDUAL_UPDATE
              ,ain.APPL_INDICATOR_UPDATE
              ,ai.APPL_INDIVIDUAL_UPDATE
              ,h.HOUSEHOLD_UPDATE
,ip_data.INSURED_PLAN_UPDATE/* new added in May 2021 release */
          FROM SRC_COMPAS_D.application a,
                  (select ci.*,''U'' AS INDIVIDUAL_UPDATE from  SRC_COMPAS_D.individual ci where ETL_LST_BTCH_ID >= :V_ETL_LST_BTCH_ID
				  -------Commented by OAS - JNIKAM--------
				  /*where ETL_LST_BTCH_ID > (
												SELECT
											NVL(MAX(METADATA_VALUE),-1) METADATA_VALUE
											FROM
											UTIL.ETL_APPLICATION_METADATA
											WHERE
											METADATA_TYPE   = ''ETLLASTBATCHID''
											AND APPLICATION   = ''$MP_CONFDIM_APPLICATION''
											AND METADATA_DESC = ''RPT_AGT_APPL'' )
                                            */
				-------Commented by OAS - JNIKAM--------							
										) i,											
                (SELECT * FROM SRC_COMPAS_D.HOUSEHOLD_PROFILE WHERE  DELETE_IND   =  ''N'' AND CURRENT_DATE BETWEEN  HHOLD_PROFILE_START_DATE AND HHOLD_PROFILE_STOP_DATE) HP,
/* -SRC_COMPAS_D.application_agent aa, */
			   (SELECT a.application_id , 
			   MAX ( CASE  WHEN a.agent_type_id = 1 THEN a.agent_id  END) AS writing_agent_id ,
			   MAX ( CASE WHEN a.agent_type_id = 2 THEN a.agent_id  END) AS SELLING_AGENT_ID,
               ''U'' AS APPL_AGENT_UPDATE
				FROM SRC_COMPAS_D.application_agent a where ETL_LST_BTCH_ID >= :V_ETL_LST_BTCH_ID and  
				-------Commented by OAS - JNIKAM--------
				  /*ETL_LST_BTCH_ID > (
												SELECT
											NVL(MAX(METADATA_VALUE),-1) METADATA_VALUE
											FROM
											UTIL.ETL_APPLICATION_METADATA
											WHERE
											METADATA_TYPE   = ''ETLLASTBATCHID''
											AND APPLICATION   = ''$MP_CONFDIM_APPLICATION''
											AND METADATA_DESC = ''RPT_AGT_APPL'' ) AND */
				-------Commented by OAS - JNIKAM--------
				 				a.agent_type_id IN (1, 2, 3, 4)
				GROUP BY A.APPLICATION_ID) aa,
                (select cai.*,''U'' AS APPL_INDICATOR_UPDATE from  SRC_COMPAS_D.application_indicator cai 
				where 
				-------Commented by OAS - JNIKAM--------
				/*ETL_LST_BTCH_ID > (
												SELECT
											NVL(MAX(METADATA_VALUE),-1) METADATA_VALUE
											FROM
											UTIL.ETL_APPLICATION_METADATA
											WHERE
											METADATA_TYPE   = ''ETLLASTBATCHID''
											AND APPLICATION   = ''$MP_CONFDIM_APPLICATION''
											AND METADATA_DESC = ''RPT_AGT_APPL'' )
                                            and */
				-------Commented by OAS - JNIKAM--------	
				 cai.ETL_LST_BTCH_ID >= :V_ETL_LST_BTCH_ID AND	 ----OAS ADD
											phone_enrollment_ind <> ''Y'' ) ain,
               (select cain.*,''U'' AS APPL_INDIVIDUAL_UPDATE from SRC_COMPAS_D.application_individual cain
			    			   -------Commented by OAS - JNIKAM--------
			   /* where ETL_LST_BTCH_ID > (
												SELECT
											NVL(MAX(METADATA_VALUE),-1) METADATA_VALUE
											FROM
											UTIL.ETL_APPLICATION_METADATA
											WHERE
											METADATA_TYPE   = ''ETLLASTBATCHID''
											AND APPLICATION   = ''$MP_CONFDIM_APPLICATION''
											AND METADATA_DESC = ''RPT_AGT_APPL'' ) */
				-------Commented by OAS - JNIKAM--------
				where cain.ETL_LST_BTCH_ID >= :V_ETL_LST_BTCH_ID	 ----OAS ADD
											) ai,
               (select * from SRC_COMPAS_D.household_member hhm 
			   -------Commented by OAS - JNIKAM--------
			   /*where hhm.ETL_LST_BTCH_ID > (
												SELECT
											NVL(MAX(METADATA_VALUE),-1) METADATA_VALUE
											FROM
											UTIL.ETL_APPLICATION_METADATA
											WHERE
											METADATA_TYPE   = ''ETLLASTBATCHID''
											AND APPLICATION   = ''$MP_CONFDIM_APPLICATION''
											AND METADATA_DESC = ''RPT_AGT_APPL'' ) */
				-------Commented by OAS - JNIKAM--------
				where hhm.ETL_LST_BTCH_ID >= :V_ETL_LST_BTCH_ID	 ----OAS ADD							
											) hm,
               (select hh.*,''U'' AS HOUSEHOLD_UPDATE from SRC_COMPAS_D.household hh 
			   -------Commented by OAS - JNIKAM--------
			   /*where hh.ETL_LST_BTCH_ID > (
												SELECT
											NVL(MAX(METADATA_VALUE),-1) METADATA_VALUE
											FROM
											UTIL.ETL_APPLICATION_METADATA
											WHERE
											METADATA_TYPE   = ''ETLLASTBATCHID''
											AND APPLICATION   = ''$MP_CONFDIM_APPLICATION''
											AND METADATA_DESC = ''RPT_AGT_APPL'' )*/
				-------Commented by OAS - JNIKAM--------
				where hh.ETL_LST_BTCH_ID >= :V_ETL_LST_BTCH_ID	 ----OAS ADD							
											) h,
               (SELECT wr.identifier_value, wqt.type_desc
FROM SRC_COMPAS_D.work_queue_rec_id wr,  /* - No batchid */
SRC_COMPAS_D.work_queue_item wi,  /*  No Batchid */
                     SRC_COMPAS_D.work_queue_type wqt
                WHERE wi.tracking_number = wr.tracking_number
AND wi.status_id <> 5   /* completed */
AND wr.identifier_type_id = 2011  /* application */
                  AND wqt.type_id = wi.type_id									  
               ) wq_type,
               (SELECT DISTINCT a.application_id,
                                ip.insured_plan_effective_date,
                                ip.agent_submission_type_id,
                                insured_plan_termination_date,
servicing_agent_id,      /*  added in sep release */
                                hra_admin_id, disabled_ind,
                                ip.agent_commission_oe_ind,
                                ip.agent_commission_gi_ind
								,ip.underwriting_waiver_ind
,INSURED_PLAN_UPDATE/* SCR80223 */, ip.agent_submission_type
                FROM (select ip.*,  nvl(to_char(ip.agent_submission_type_id), '''') || ''-''|| nvl(to_char(st.agent_submission_type_desc), '''') as agent_submission_type
                from SRC_COMPAS_D.insured_plan ip, /*where ETL_LST_BTCH_ID > (
												SELECT
											NVL(MAX(METADATA_VALUE),-1) METADATA_VALUE
											FROM
											UTIL.ETL_APPLICATION_METADATA
											WHERE
											METADATA_TYPE   = ''ETLLASTBATCHID''
											AND APPLICATION   = ''$MP_CONFDIM_APPLICATION''
											AND METADATA_DESC = ''RPT_AGT_APPL'')*/
                                           SRC_COMPAS_D.agent_submission_type st
             WHERE ip.agent_submission_type_id =st.agent_submission_type_id) ip,
/* --SRC_COMPAS_D.insured_plan_agent ipa, */
					 (SELECT ipa.insured_plan_id ,
								MAX ( CASE WHEN ipa.agent_type_id = 1 THEN ipa.agent_id END) AS writing_agent_id ,
								MAX ( CASE WHEN ipa.agent_type_id = 2 THEN ipa.agent_id END) AS selling_agent_id ,
								MAX ( CASE WHEN ipa.agent_type_id = 3 THEN ipa.agent_id END) AS servicing_agent_id ,
								MAX ( CASE WHEN ipa.agent_type_id = 4 THEN ipa.agent_id END) AS hra_admin_id,
                                ''U'' AS INSURED_PLAN_UPDATE
							FROM SRC_COMPAS_D.insured_plan_agent ipa
							WHERE ipa.agent_type_id IN (1, 2, 3, 4)
							-------Commented by OAS - JNIKAM--------
                       /* AND ipa.ETL_LST_BTCH_ID > (
												SELECT
											NVL(MAX(METADATA_VALUE),-1) METADATA_VALUE
											FROM
											UTIL.ETL_APPLICATION_METADATA
											WHERE
											METADATA_TYPE   = ''ETLLASTBATCHID''
											AND APPLICATION   = ''$MP_CONFDIM_APPLICATION''
											AND METADATA_DESC = ''RPT_AGT_APPL'') */
                                           -------Commented by OAS - JNIKAM-------- 
							                      	
							AND ipa.ETL_LST_BTCH_ID >= :V_ETL_LST_BTCH_ID	 ----OAS ADD	
                            GROUP BY ipa.INSURED_PLAN_ID
							) ipa,
                    (select * from SRC_COMPAS_D.insured_plan_profile /*where ETL_LST_BTCH_ID > (
												SELECT
											NVL(MAX(METADATA_VALUE),-1) METADATA_VALUE
											FROM
											UTIL.ETL_APPLICATION_METADATA
											WHERE
											METADATA_TYPE   = ''ETLLASTBATCHID''
											AND APPLICATION   = ''$MP_CONFDIM_APPLICATION''
											AND METADATA_DESC = ''RPT_AGT_APPL'')*/) ipp,
                     SRC_COMPAS_D.application a,
                     SRC_COMPAS_D.PLAN p1,
                     SRC_COMPAS_D.plan_type pt1
                  WHERE a.application_id = ip.application_id(+)
				  AND TRUNC(a.APPL_RECEIPT_DATE, ''DD'') >= ''2017-01-01''  --OAS ADD
				  
				  
				-------Commented by OAS - JNIKAM--------
				/*AND TRUNC(a.APPL_RECEIPT_DATE, ''DD'') > = TO_TIMESTAMP((SELECT
NVL(MAX(METADATA_VALUE),-1) METADATA_VALUE
FROM
ETL.ETL_APPLICATION_METADATA
WHERE
METADATA_TYPE   = ''EXTRACT_START_DATE''
AND APPLICATION   = ''CONFORMEDDIMENSIONS''
AND METADATA_DESC = ''RPT_AGT_APPL''), ''DD-MON-YYYY'') */
-------Commented by OAS - JNIKAM--------
  /*  as part of historical data only taking data from 2017 */
                  AND a.plan_request_1=ip.plan_cd
AND a.appl_actor_id IN (3,1)                                 /* to include actor as customer */
                  AND  ip.insured_plan_effective_date BETWEEN ins_plan_profile_start_date AND ins_plan_profile_stop_date
and  ip.insured_plan_effective_date < NVL(ip.insured_plan_termination_date,TO_TIMESTAMP(''12/31/9999'', ''MM/DD/YYYY''))         /* exclude Never Active to eliminate duplicate */
AND ip.insured_plan_id = ipa.insured_plan_id (+) /* the insured_plan_agent tables will NOT contain records for insured plans which do not have agent ID on them so do outer join to get all */
                  AND ipp.insured_plan_id(+) = ip.insured_plan_id
                  AND ip.plan_cd = p1.plan_cd
                  AND p1.plan_type_id = pt1.plan_type_id
                  AND pt1.plan_category_id <> 3
				   ) ip_data
                  WHERE
a.appl_actor_id in (3,1)   /* to include actor as customer */
AND TRUNC(a.APPL_RECEIPT_DATE, ''DD'') >= ''2017-01-01'' --OAS ADD
-------Commented by OAS - JNIKAM--------			
/*
			AND TRUNC(a.APPL_RECEIPT_DATE, ''DD'') > = TO_TIMESTAMP((SELECT
NVL(MAX(METADATA_VALUE),-1) METADATA_VALUE
FROM
ETL.ETL_APPLICATION_METADATA
WHERE
METADATA_TYPE   = ''EXTRACT_START_DATE''
AND APPLICATION   = ''CONFORMEDDIMENSIONS''
AND METADATA_DESC = ''RPT_AGT_APPL''), ''DD-MON-YYYY'') */
-------Commented by OAS - JNIKAM--------
  /*  as part of historical data only taking data from 2017 */
AND a.application_id = aa.application_id(+) /* the application_agent table will NOT contain records for applications which do not have agent ID on them. so outer join to get all from application */
            AND a.application_id = ain.application_id(+)
/* and phone_enrollment_ind <> ''Y''            --exclude phone enrollments */
            AND a.application_id = ai.application_id(+)
            AND a.individual_id = i.individual_id(+)
            AND A.HOUSEHOLD_ID=HP.HOUSEHOLD_ID(+)
            AND a.household_id = h.household_id(+)
            AND a.individual_id = hm.individual_id(+)
            AND TRUNC(CURRENT_DATE, ''DD'') BETWEEN hm.hhold_member_start_date(+) AND hm.hhold_member_stop_date(+)
            AND  a.application_id = wq_type.identifier_value(+)
AND a.application_id = ip_data.application_id(+)/* to get all from application */
) agt,
      ( select /*+parallel(8)*/ T.* from SRC_COMPAS_D.application_agent T /*where T.ETL_LST_BTCH_ID > (
												SELECT
											NVL(MAX(METADATA_VALUE),-1) METADATA_VALUE
											FROM
											UTIL.ETL_APPLICATION_METADATA
											WHERE
											METADATA_TYPE   = ''ETLLASTBATCHID''
											AND APPLICATION   = ''$MP_CONFDIM_APPLICATION''
											AND METADATA_DESC = ''RPT_AGT_APPL'')*/ ) aag
      where agt.application_id = aag.application_id(+)
    and (agt.appl_actor_id=3 or (agt.appl_actor_id = 1 and  aag.AGENT_TYPE_ID = 5 and aag.agent_id is not null))
order by agt.creation_date
)
SELECT 
/*+parallel(8)*/
TGT.RPT_AGT_APPL_SK,
SRC.MEMBERSHIP_NUMBER as MBRSHP_NBR,
SRC.insured_cd as INSD_CD,
SRC.application_id as APPL_ID,
TO_CHAR(SRC.appl_receipt_date,''YYYYMMDD'') as APPL_RECPT_DT,
TO_CHAR(SRC.creation_date,''YYYYMMDD'') as APPL_CREAT_DT,
CASE WHEN SRC.first_name IS NULL AND NVL(SRC.APPL_INDIVIDUAL_UPDATE,''NA'')<>''U'' THEN TGT.FST_NM
ELSE
SRC.first_name END as FST_NM,
CASE WHEN SRC.middle_name IS NULL AND NVL(SRC.APPL_INDIVIDUAL_UPDATE,''NA'')<>''U'' THEN TGT.MIDL_NM
ELSE
SRC.middle_name END AS MIDL_NM,
CASE WHEN SRC.last_name IS NULL AND NVL(SRC.APPL_INDIVIDUAL_UPDATE,''NA'')<>''U'' THEN TGT.LST_NM
ELSE
SRC.last_name END AS  LST_NM,
CASE WHEN NVL(TO_CHAR(SRC.date_of_birth,''YYYYMMDD''),''29991231'')=''29991231'' AND NVL(SRC.APPL_INDIVIDUAL_UPDATE,''NA'')<>''U'' AND NVL(SRC.INDIVIDUAL_UPDATE,''NA'')<>''U'' THEN TO_CHAR(TGT.DOB_DT)
ELSE
TO_CHAR(SRC.date_of_birth,''YYYYMMDD'') END AS  DOB_DT,
SRC.state_cd as ST_CD,
SRC.plan_cd as PLN_CD,
TO_CHAR(SRC.requested_effective_date,''YYYYMMDD'') as APPL_REQ_EFF_DT,
SRC.adjudication_cd as ADJD_CD,
TO_CHAR(SRC.adjudication_date,''YYYYMMDD'') as ADJD_DT,
CASE WHEN SRC.writing_agent_id IS NULL AND NVL(SRC.APPL_AGENT_UPDATE,''NA'')<>''U'' THEN TGT.WRT_AGT_ID
ELSE
SRC.writing_agent_id END AS WRT_AGT_ID,
CASE WHEN SRC.writing_agent_signature_ind IS NULL AND NVL(SRC.APPL_INDICATOR_UPDATE,''NA'')<>''U'' THEN TGT.WRT_AGT_SGN_IND
ELSE
SRC.writing_agent_signature_ind END AS WRT_AGT_SGN_IND,
CASE WHEN SRC.selling_agent_id IS NULL AND NVL(SRC.APPL_AGENT_UPDATE,''NA'')<>''U'' THEN TGT.SELL_AGT_ID
ELSE
SRC.selling_agent_id END AS SELL_AGT_ID,
CASE WHEN SRC.selling_agent_signature_ind IS NULL AND NVL(SRC.APPL_INDICATOR_UPDATE,''NA'')<>''U'' THEN TGT.SELL_AGT_SGN_IND
ELSE
SRC.selling_agent_signature_ind END AS SELL_AGT_SGN_IND,
CASE WHEN NVL(SRC.servicing_agent_id,''NA'')=''NA'' AND NVL(SRC.INSURED_PLAN_UPDATE,''NA'')<>''U'' THEN TGT.SRVC_AGT_ID
ELSE
SRC.servicing_agent_id END AS SRVC_AGT_ID,
CASE WHEN SRC.hra_admin_id IS NULL AND NVL(SRC.INSURED_PLAN_UPDATE,''NA'')<>''U'' THEN TGT.HRA_ADMIN_ID
ELSE
SRC.hra_admin_id END AS HRA_ADMIN_ID,
CASE WHEN SRC.disabled_ind IS NULL AND NVL(SRC.INSURED_PLAN_UPDATE,''NA'')<>''U'' THEN TGT.DSBL_IND
ELSE
SRC.disabled_ind END AS DSBL_IND,
TO_CHAR(SRC.actual_effective_date,''YYYYMMDD'') as ACTUL_EFF_DT,
CASE WHEN NVL(TO_CHAR(SRC.hhold_paid_through_date,''YYYYMMDD''),''29991231'')=''29991231'' AND NVL(SRC.HOUSEHOLD_UPDATE,''NA'')<>''U'' THEN TO_CHAR(TGT.HSEHLD_PD_THRU_DT) 
ELSE
TO_CHAR(SRC.hhold_paid_through_date,''YYYYMMDD'') END AS  HSEHLD_PD_THRU_DT,
SRC.contact_day_time_phone_no as CNTC_DAY_TM_TEL_NBR,
TO_CHAR(SRC.appl_signature_date,''YYYYMMDD'') as APPL_SGN_DT,
SRC.hash_cd as HSH_CD,
SRC.dcn as APPL_IMAG_ORIG_NBR,
SRC.wq_type as WQ_TYP_DESC,
SRC.agent_submission_type as AGT_SBMT_TYP_ID,
SRC.phone_enrollment_type_id as TEL_ENRL_TYP_ID,
SRC.submission_method as SBMT_METH_ID,
CASE WHEN SRC.medicare_claim_num IS NULL AND NVL(SRC.APPL_INDIVIDUAL_UPDATE,''NA'')<>''U'' THEN TGT.MEDCR_CLM_NBR
ELSE
SRC.medicare_claim_num END AS MEDCR_CLM_NBR,
SRC.agent_commission_oe_ind as AGT_COMM_OE_IND,
SRC.agent_commission_gi_ind as AGT_COMM_GI_IND,
SRC.appl_actor_id as APPL_ACTOR_ID,
SRC.Referral_Agent_ID as REF_AGT_ID,
SRC.vendor_code as VEND_CD,
SRC.underwriting_waiver_ind as UNDWR_WAIV_IND,
--BLOG.BATCH_ID, ---OAS DELETE
:V_BATCH_ID AS BATCH_ID, --OAS ADD
		CASE
		WHEN TGT.RPT_AGT_APPL_SK IS NULL  THEN ''INSERT''
		WHEN NVL(SRC.MEMBERSHIP_NUMBER,''NA'')<> NVL(TGT.MBRSHP_NBR,''NA'') OR
			 NVL(SRC.insured_cd,0)<> NVL(TGT.INSD_CD,0) OR
			 NVL(TO_CHAR(SRC.appl_receipt_date,''YYYYMMDD''),''29991231'')<> NVL(TGT.APPL_RECPT_DT,''29991231'') OR
			 NVL(TO_CHAR(SRC.creation_date,''YYYYMMDD''),''29991231'')<> NVL(TGT.APPL_CREAT_DT,''29991231'') OR
			 (NVL(SRC.first_name,''NA'')<> NVL(TGT.FST_NM,''NA'') AND NVL(SRC.APPL_INDIVIDUAL_UPDATE,''NA'')=''U'') OR
			 (NVL(SRC.middle_name,''NA'')<> NVL(TGT.MIDL_NM,''NA'') AND NVL(SRC.APPL_INDIVIDUAL_UPDATE,''NA'')=''U'') OR
			 (NVL(SRC.last_name,''NA'')<> NVL(TGT.LST_NM,''NA'') AND NVL(SRC.APPL_INDIVIDUAL_UPDATE,''NA'')=''U'') OR
             (NVL(TO_CHAR(SRC.date_of_birth,''YYYYMMDD''),''29991231'')<> NVL(TGT.DOB_DT,''29991231'') AND (NVL(SRC.APPL_INDIVIDUAL_UPDATE,''NA'')=''U'' OR NVL(SRC.INDIVIDUAL_UPDATE,''NA'')=''U'')) OR
			 NVL(SRC.state_cd,''NA'')<> NVL(TGT.ST_CD,''NA'') OR
			 NVL(SRC.plan_cd,''NA'')<> NVL(TGT.PLN_CD,''NA'') OR
			 NVL(TO_CHAR(SRC.requested_effective_date,''YYYYMMDD''),''29991231'')<> NVL(TGT.APPL_REQ_EFF_DT,''29991231'') OR
			 NVL(SRC.adjudication_cd,''NA'')<> NVL(TGT.ADJD_CD,''NA'') OR
			 NVL(TO_CHAR(SRC.adjudication_date,''YYYYMMDD''),''29991231'')<> NVL(TGT.ADJD_DT,''29991231'') OR
			 (NVL(SRC.writing_agent_id,''NA'')<> NVL(TGT.WRT_AGT_ID,''NA'') AND NVL(SRC.APPL_AGENT_UPDATE,''NA'')=''U'') OR
			 (NVL(SRC.writing_agent_signature_ind,''NA'')<> NVL(TGT.WRT_AGT_SGN_IND,''NA'')  AND NVL(SRC.APPL_INDICATOR_UPDATE,''NA'')=''U'') OR
			 (NVL(SRC.selling_agent_id,''NA'')<> NVL(TGT.SELL_AGT_ID,''NA'') AND NVL(SRC.APPL_AGENT_UPDATE,''NA'')=''U'') OR
			 (NVL(SRC.selling_agent_signature_ind,''NA'')<> NVL(TGT.SELL_AGT_SGN_IND,''NA'') AND NVL(SRC.APPL_INDICATOR_UPDATE,''NA'')=''U'') OR
			 (NVL(SRC.servicing_agent_id,''NA'')<> NVL(TGT.SRVC_AGT_ID,''NA'') AND NVL(SRC.INSURED_PLAN_UPDATE,''NA'')=''U'') OR
			 (NVL(SRC.hra_admin_id,''NA'')<> NVL(TGT.HRA_ADMIN_ID,''NA'') AND NVL(SRC.INSURED_PLAN_UPDATE,''NA'')=''U'') OR
			 (NVL(SRC.disabled_ind,''NA'')<> NVL(TGT.DSBL_IND,''NA'') AND NVL(SRC.INSURED_PLAN_UPDATE,''NA'')=''U'') OR
			 NVL(TO_CHAR(SRC.actual_effective_date,''YYYYMMDD''),''29991231'')<> NVL(TGT.ACTUL_EFF_DT,''29991231'') OR
			 (NVL(TO_CHAR(SRC.hhold_paid_through_date,''YYYYMMDD''),''29991231'')<> NVL(TGT.HSEHLD_PD_THRU_DT,''29991231'') AND  NVL(SRC.HOUSEHOLD_UPDATE,''NA'')=''U'')OR
			 NVL(SRC.contact_day_time_phone_no,''NA'')<> NVL(TGT.CNTC_DAY_TM_TEL_NBR,''NA'') OR
			 NVL(TO_CHAR(SRC.appl_signature_date,''YYYYMMDD''),''29991231'')<> NVL(TGT.APPL_SGN_DT,''29991231'') OR
			 NVL(SRC.hash_cd,''NA'')<> NVL(TGT.HSH_CD,''NA'') OR
			 NVL(SRC.dcn,''NA'')<> NVL(TGT.APPL_IMAG_ORIG_NBR,''NA'') OR
			 NVL(SRC.wq_type,''NA'')<> NVL(TGT.WQ_TYP_DESC,''NA'') OR
			 NVL(SRC.agent_submission_type,''NA'')<> NVL(TGT.AGT_SBMT_TYP_ID,''NA'') OR
			 NVL(SRC.phone_enrollment_type_id,0)<> NVL(TGT.TEL_ENRL_TYP_ID,0) OR
			 NVL(SRC.submission_method,''NA'')<> NVL(TGT.SBMT_METH_ID,''NA'') OR
			 (NVL(SRC.medicare_claim_num,''NA'')<> NVL(TGT.MEDCR_CLM_NBR,''NA'') AND NVL(APPL_INDIVIDUAL_UPDATE,''NA'')=''U'') OR
			 NVL(SRC.agent_commission_oe_ind,''NA'')<> NVL(TGT.AGT_COMM_OE_IND,''NA'') OR
			 NVL(SRC.agent_commission_gi_ind,''NA'')<> NVL(TGT.AGT_COMM_GI_IND,''NA'') OR
			 NVL(SRC.appl_actor_id,0)<> NVL(TGT.APPL_ACTOR_ID,0) OR
			 NVL(SRC.Referral_Agent_ID,''NA'')<> NVL(TGT.REF_AGT_ID,''NA'') OR
			 NVL(SRC.vendor_code,''NA'')<> NVL(TGT.VEND_CD,''NA'') OR
			 NVL(SRC.underwriting_waiver_ind,''NA'')<> NVL(TGT.UNDWR_WAIV_IND,''NA'')
			 THEN ''UPDATE'' ELSE ''SKIP'' END AS INS_UPD_FLAG 

FROM 
RPT_AGT_APPL_SRC SRC
LEFT JOIN BDR_CONF.RPT_AGT_APPL  tgt ON SRC.application_id=tgt.APPL_ID  AND tgt.CURR_ROW_FLG=''Y'' 
-------Commented by OAS - JNIKAM--------
/*LEFT OUTER JOIN
  (SELECT MAX(BATCH_ID) AS BATCH_ID
  FROM UTIL.ETL_BATCH_LOG
  WHERE APPLICATION =''$MP_ISID_APPLICATION''
  AND BATCH_STATUS != ''COMPLETE''
  ) BLOG
ON 1 = 1 */
-------Commented by OAS - JNIKAM--------
) SRC
);


-- Component EXP_RPT_AGT_APPL, Type EXPRESSION 
CREATE OR REPLACE TEMPORARY TABLE EXP_RPT_AGT_APPL AS
(
SELECT
SQ_sc_RPT_AGT_APPL.RPT_AGT_APPL_SK as RPT_AGT_APPL_SK,
SQ_sc_RPT_AGT_APPL.MBRSHP_NBR as MBRSHP_NBR,
SQ_sc_RPT_AGT_APPL.INSD_CD as INSD_CD,
SQ_sc_RPT_AGT_APPL.APPL_ID as APPL_ID,
SQ_sc_RPT_AGT_APPL.APPL_RECPT_DT as APPL_RECPT_DT,
SQ_sc_RPT_AGT_APPL.APPL_CREAT_DT as APPL_CREAT_DT,
SQ_sc_RPT_AGT_APPL.FST_NM as FST_NM,
SQ_sc_RPT_AGT_APPL.MIDL_NM as MIDL_NM,
SQ_sc_RPT_AGT_APPL.LST_NM as LST_NM,
SQ_sc_RPT_AGT_APPL.DOB_DT as DOB_DT,
SQ_sc_RPT_AGT_APPL.ST_CD as ST_CD,
SQ_sc_RPT_AGT_APPL.PLN_CD as PLN_CD,
SQ_sc_RPT_AGT_APPL.APPL_REQ_EFF_DT as APPL_REQ_EFF_DT,
SQ_sc_RPT_AGT_APPL.ADJD_CD as ADJD_CD,
SQ_sc_RPT_AGT_APPL.ADJD_DT as ADJD_DT,
SQ_sc_RPT_AGT_APPL.WRT_AGT_ID as WRT_AGT_ID,
SQ_sc_RPT_AGT_APPL.WRT_AGT_SGN_IND as WRT_AGT_SGN_IND,
SQ_sc_RPT_AGT_APPL.SELL_AGT_ID as SELL_AGT_ID,
SQ_sc_RPT_AGT_APPL.SELL_AGT_SGN_IND as SELL_AGT_SGN_IND,
SQ_sc_RPT_AGT_APPL.SRVC_AGT_ID as SRVC_AGT_ID,
SQ_sc_RPT_AGT_APPL.HRA_ADMIN_ID as HRA_ADMIN_ID,
SQ_sc_RPT_AGT_APPL.DSBL_IND as DSBL_IND,
SQ_sc_RPT_AGT_APPL.ACTUL_EFF_DT as ACTUL_EFF_DT,
SQ_sc_RPT_AGT_APPL.HSEHLD_PD_THRU_DT as HSEHLD_PD_THRU_DT,
SQ_sc_RPT_AGT_APPL.CNTC_DAY_TM_TEL_NBR as CNTC_DAY_TM_TEL_NBR,
SQ_sc_RPT_AGT_APPL.APPL_SGN_DT as APPL_SGN_DT,
SQ_sc_RPT_AGT_APPL.HSH_CD as HSH_CD,
SQ_sc_RPT_AGT_APPL.APPL_IMAG_ORIG_NBR as APPL_IMAG_ORIG_NBR,
SQ_sc_RPT_AGT_APPL.WQ_TYP_DESC as WQ_TYP_DESC,
SQ_sc_RPT_AGT_APPL.AGT_SBMT_TYP_ID as AGT_SBMT_TYP_ID,
SQ_sc_RPT_AGT_APPL.TEL_ENRL_TYP_ID as TEL_ENRL_TYP_ID,
SQ_sc_RPT_AGT_APPL.SBMT_METH_ID as SBMT_METH_ID,
SQ_sc_RPT_AGT_APPL.MEDCR_CLM_NBR as MEDCR_CLM_NBR,
SQ_sc_RPT_AGT_APPL.AGT_COMM_OE_IND as AGT_COMM_OE_IND,
SQ_sc_RPT_AGT_APPL.AGT_COMM_GI_IND as AGT_COMM_GI_IND,
SQ_sc_RPT_AGT_APPL.APPL_ACTOR_ID as APPL_ACTOR_ID,
SQ_sc_RPT_AGT_APPL.REF_AGT_ID as REF_AGT_ID,
SQ_sc_RPT_AGT_APPL.VEND_CD as VEND_CD,
SQ_sc_RPT_AGT_APPL.UNDWR_WAIV_IND as UNDWR_WAIV_IND,
SQ_sc_RPT_AGT_APPL.BATCH_ID as BATCH_ID,
SQ_sc_RPT_AGT_APPL.INS_UPD_FLAG as INS_UPD_FLAG,
SQ_sc_RPT_AGT_APPL.source_record_id
FROM
SQ_sc_RPT_AGT_APPL
);


-- Component RTRTRANS_insert, Type ROUTER Output Group insert
CREATE OR REPLACE TEMPORARY TABLE RTRTRANS_insert AS
(
SELECT
EXP_RPT_AGT_APPL.RPT_AGT_APPL_SK as RPT_AGT_APPL_SK,
EXP_RPT_AGT_APPL.MBRSHP_NBR as MBRSHP_NBR,
EXP_RPT_AGT_APPL.INSD_CD as INSD_CD,
EXP_RPT_AGT_APPL.APPL_ID as APPL_ID,
EXP_RPT_AGT_APPL.APPL_RECPT_DT as APPL_RECPT_DT,
EXP_RPT_AGT_APPL.APPL_CREAT_DT as APPL_CREAT_DT,
EXP_RPT_AGT_APPL.FST_NM as FST_NM,
EXP_RPT_AGT_APPL.MIDL_NM as MIDL_NM,
EXP_RPT_AGT_APPL.LST_NM as LST_NM,
EXP_RPT_AGT_APPL.DOB_DT as DOB_DT,
EXP_RPT_AGT_APPL.ST_CD as ST_CD,
EXP_RPT_AGT_APPL.PLN_CD as PLN_CD,
EXP_RPT_AGT_APPL.APPL_REQ_EFF_DT as APPL_REQ_EFF_DT,
EXP_RPT_AGT_APPL.ADJD_CD as ADJD_CD,
EXP_RPT_AGT_APPL.ADJD_DT as ADJD_DT,
EXP_RPT_AGT_APPL.WRT_AGT_ID as WRT_AGT_ID,
EXP_RPT_AGT_APPL.WRT_AGT_SGN_IND as WRT_AGT_SGN_IND,
EXP_RPT_AGT_APPL.SELL_AGT_ID as SELL_AGT_ID,
EXP_RPT_AGT_APPL.SELL_AGT_SGN_IND as SELL_AGT_SGN_IND,
EXP_RPT_AGT_APPL.SRVC_AGT_ID as SRVC_AGT_ID,
EXP_RPT_AGT_APPL.HRA_ADMIN_ID as HRA_ADMIN_ID,
EXP_RPT_AGT_APPL.DSBL_IND as DSBL_IND,
EXP_RPT_AGT_APPL.ACTUL_EFF_DT as ACTUL_EFF_DT,
EXP_RPT_AGT_APPL.HSEHLD_PD_THRU_DT as HSEHLD_PD_THRU_DT,
EXP_RPT_AGT_APPL.CNTC_DAY_TM_TEL_NBR as CNTC_DAY_TM_TEL_NBR,
EXP_RPT_AGT_APPL.APPL_SGN_DT as APPL_SGN_DT,
EXP_RPT_AGT_APPL.HSH_CD as HSH_CD,
EXP_RPT_AGT_APPL.APPL_IMAG_ORIG_NBR as APPL_IMAG_ORIG_NBR,
EXP_RPT_AGT_APPL.WQ_TYP_DESC as WQ_TYP_DESC,
EXP_RPT_AGT_APPL.AGT_SBMT_TYP_ID as AGT_SBMT_TYP_ID,
EXP_RPT_AGT_APPL.TEL_ENRL_TYP_ID as TEL_ENRL_TYP_ID,
EXP_RPT_AGT_APPL.SBMT_METH_ID as SBMT_METH_ID,
EXP_RPT_AGT_APPL.MEDCR_CLM_NBR as MEDCR_CLM_NBR,
EXP_RPT_AGT_APPL.AGT_COMM_OE_IND as AGT_COMM_OE_IND,
EXP_RPT_AGT_APPL.AGT_COMM_GI_IND as AGT_COMM_GE_IND,
EXP_RPT_AGT_APPL.APPL_ACTOR_ID as APPL_ACTOR_ID,
EXP_RPT_AGT_APPL.REF_AGT_ID as REF_AGT_ID,
EXP_RPT_AGT_APPL.VEND_CD as VEND_CD,
EXP_RPT_AGT_APPL.UNDWR_WAIV_IND as UNDWR_WAIV_IND,
EXP_RPT_AGT_APPL.BATCH_ID as BATCH_ID,
EXP_RPT_AGT_APPL.INS_UPD_FLAG as INS_UPD_FLAG,
EXP_RPT_AGT_APPL.source_record_id
FROM
EXP_RPT_AGT_APPL
WHERE EXP_RPT_AGT_APPL.INS_UPD_FLAG = ''INSERT''
);


-- Component RTRTRANS_update, Type ROUTER Output Group update
CREATE OR REPLACE TEMPORARY TABLE RTRTRANS_update AS
(
SELECT
EXP_RPT_AGT_APPL.RPT_AGT_APPL_SK as RPT_AGT_APPL_SK,
EXP_RPT_AGT_APPL.MBRSHP_NBR as MBRSHP_NBR,
EXP_RPT_AGT_APPL.INSD_CD as INSD_CD,
EXP_RPT_AGT_APPL.APPL_ID as APPL_ID,
EXP_RPT_AGT_APPL.APPL_RECPT_DT as APPL_RECPT_DT,
EXP_RPT_AGT_APPL.APPL_CREAT_DT as APPL_CREAT_DT,
EXP_RPT_AGT_APPL.FST_NM as FST_NM,
EXP_RPT_AGT_APPL.MIDL_NM as MIDL_NM,
EXP_RPT_AGT_APPL.LST_NM as LST_NM,
EXP_RPT_AGT_APPL.DOB_DT as DOB_DT,
EXP_RPT_AGT_APPL.ST_CD as ST_CD,
EXP_RPT_AGT_APPL.PLN_CD as PLN_CD,
EXP_RPT_AGT_APPL.APPL_REQ_EFF_DT as APPL_REQ_EFF_DT,
EXP_RPT_AGT_APPL.ADJD_CD as ADJD_CD,
EXP_RPT_AGT_APPL.ADJD_DT as ADJD_DT,
EXP_RPT_AGT_APPL.WRT_AGT_ID as WRT_AGT_ID,
EXP_RPT_AGT_APPL.WRT_AGT_SGN_IND as WRT_AGT_SGN_IND,
EXP_RPT_AGT_APPL.SELL_AGT_ID as SELL_AGT_ID,
EXP_RPT_AGT_APPL.SELL_AGT_SGN_IND as SELL_AGT_SGN_IND,
EXP_RPT_AGT_APPL.SRVC_AGT_ID as SRVC_AGT_ID,
EXP_RPT_AGT_APPL.HRA_ADMIN_ID as HRA_ADMIN_ID,
EXP_RPT_AGT_APPL.DSBL_IND as DSBL_IND,
EXP_RPT_AGT_APPL.ACTUL_EFF_DT as ACTUL_EFF_DT,
EXP_RPT_AGT_APPL.HSEHLD_PD_THRU_DT as HSEHLD_PD_THRU_DT,
EXP_RPT_AGT_APPL.CNTC_DAY_TM_TEL_NBR as CNTC_DAY_TM_TEL_NBR,
EXP_RPT_AGT_APPL.APPL_SGN_DT as APPL_SGN_DT,
EXP_RPT_AGT_APPL.HSH_CD as HSH_CD,
EXP_RPT_AGT_APPL.APPL_IMAG_ORIG_NBR as APPL_IMAG_ORIG_NBR,
EXP_RPT_AGT_APPL.WQ_TYP_DESC as WQ_TYP_DESC,
EXP_RPT_AGT_APPL.AGT_SBMT_TYP_ID as AGT_SBMT_TYP_ID,
EXP_RPT_AGT_APPL.TEL_ENRL_TYP_ID as TEL_ENRL_TYP_ID,
EXP_RPT_AGT_APPL.SBMT_METH_ID as SBMT_METH_ID,
EXP_RPT_AGT_APPL.MEDCR_CLM_NBR as MEDCR_CLM_NBR,
EXP_RPT_AGT_APPL.AGT_COMM_OE_IND as AGT_COMM_OE_IND,
EXP_RPT_AGT_APPL.AGT_COMM_GI_IND as AGT_COMM_GE_IND,
EXP_RPT_AGT_APPL.APPL_ACTOR_ID as APPL_ACTOR_ID,
EXP_RPT_AGT_APPL.REF_AGT_ID as REF_AGT_ID,
EXP_RPT_AGT_APPL.VEND_CD as VEND_CD,
EXP_RPT_AGT_APPL.UNDWR_WAIV_IND as UNDWR_WAIV_IND,
EXP_RPT_AGT_APPL.BATCH_ID as BATCH_ID,
EXP_RPT_AGT_APPL.INS_UPD_FLAG as INS_UPD_FLAG,
EXP_RPT_AGT_APPL.source_record_id
FROM
EXP_RPT_AGT_APPL
WHERE EXP_RPT_AGT_APPL.INS_UPD_FLAG = ''UPDATE''
);


-- Component EXP_UPD_UPDATE, Type EXPRESSION 
CREATE OR REPLACE TEMPORARY TABLE EXP_UPD_UPDATE AS
(
SELECT
RTRTRANS_update.RPT_AGT_APPL_SK as RPT_AGT_APPL_SK3,
RTRTRANS_update.BATCH_ID as BATCH_ID3,
DATEADD(''DD'', - 1, TO_DATE(CURRENT_TIMESTAMP)) as ETL_EFF_END_DATE,
''N'' as CURR_ROW_FLG,
RTRTRANS_update.source_record_id
FROM
RTRTRANS_update
);


-- Component EXP_UPD_INSERT, Type EXPRESSION 
CREATE OR REPLACE TEMPORARY TABLE EXP_UPD_INSERT AS
(
SELECT
RTRTRANS_update.MBRSHP_NBR as MBRSHP_NBR3,
RTRTRANS_update.INSD_CD as INSD_CD3,
RTRTRANS_update.APPL_ID as APPL_ID3,
RTRTRANS_update.APPL_RECPT_DT as APPL_RECPT_DT3,
RTRTRANS_update.APPL_CREAT_DT as APPL_CREAT_DT3,
RTRTRANS_update.FST_NM as FST_NM3,
RTRTRANS_update.MIDL_NM as MIDL_NM3,
RTRTRANS_update.LST_NM as LST_NM3,
RTRTRANS_update.DOB_DT as DOB_DT3,
RTRTRANS_update.ST_CD as ST_CD3,
RTRTRANS_update.PLN_CD as PLN_CD3,
RTRTRANS_update.APPL_REQ_EFF_DT as APPL_REQ_EFF_DT3,
RTRTRANS_update.ADJD_CD as ADJD_CD3,
RTRTRANS_update.ADJD_DT as ADJD_DT3,
RTRTRANS_update.WRT_AGT_ID as WRT_AGT_ID3,
RTRTRANS_update.WRT_AGT_SGN_IND as WRT_AGT_SGN_IND3,
RTRTRANS_update.SELL_AGT_ID as SELL_AGT_ID3,
RTRTRANS_update.SELL_AGT_SGN_IND as SELL_AGT_SGN_IND3,
RTRTRANS_update.SRVC_AGT_ID as SRVC_AGT_ID3,
RTRTRANS_update.HRA_ADMIN_ID as HRA_ADMIN_ID3,
RTRTRANS_update.DSBL_IND as DSBL_IND3,
RTRTRANS_update.ACTUL_EFF_DT as ACTUL_EFF_DT3,
RTRTRANS_update.HSEHLD_PD_THRU_DT as HSEHLD_PD_THRU_DT3,
RTRTRANS_update.CNTC_DAY_TM_TEL_NBR as CNTC_DAY_TM_TEL_NBR3,
RTRTRANS_update.APPL_SGN_DT as APPL_SGN_DT3,
RTRTRANS_update.HSH_CD as HSH_CD3,
RTRTRANS_update.APPL_IMAG_ORIG_NBR as APPL_IMAG_ORIG_NBR3,
RTRTRANS_update.WQ_TYP_DESC as WQ_TYP_DESC3,
RTRTRANS_update.AGT_SBMT_TYP_ID as AGT_SBMT_TYP_ID3,
RTRTRANS_update.TEL_ENRL_TYP_ID as TEL_ENRL_TYP_ID3,
RTRTRANS_update.SBMT_METH_ID as SBMT_METH_ID3,
RTRTRANS_update.MEDCR_CLM_NBR as MEDCR_CLM_NBR3,
RTRTRANS_update.AGT_COMM_OE_IND as AGT_COMM_OE_IND3,
RTRTRANS_update.AGT_COMM_GE_IND as AGT_COMM_GI_IND3,
RTRTRANS_update.APPL_ACTOR_ID as APPL_ACTOR_ID3,
RTRTRANS_update.REF_AGT_ID as REF_AGT_ID3,
RTRTRANS_update.VEND_CD as VEND_CD3,
RTRTRANS_update.UNDWR_WAIV_IND as UNDWR_WAIV_IND3,
RTRTRANS_update.BATCH_ID as BATCH_ID3,
TO_DATE(CURRENT_TIMESTAMP) as ROW_EFF_START_DATE,
TO_TIMESTAMP(''12/31/9999'', ''MM/DD/YYYY'') as ROW_EFF_END_DATE,
''Y'' as CURR_ROW_FLG,
RTRTRANS_update.source_record_id
FROM
RTRTRANS_update
);


-- Component EXP_INS, Type EXPRESSION 
CREATE OR REPLACE TEMPORARY TABLE EXP_INS AS
(
SELECT
RTRTRANS_insert.MBRSHP_NBR as MBRSHP_NBR1,
RTRTRANS_insert.INSD_CD as INSD_CD1,
RTRTRANS_insert.APPL_ID as APPL_ID1,
RTRTRANS_insert.APPL_RECPT_DT as APPL_RECPT_DT1,
RTRTRANS_insert.APPL_CREAT_DT as APPL_CREAT_DT1,
RTRTRANS_insert.FST_NM as FST_NM1,
RTRTRANS_insert.MIDL_NM as MIDL_NM1,
RTRTRANS_insert.LST_NM as LST_NM1,
RTRTRANS_insert.DOB_DT as DOB_DT1,
RTRTRANS_insert.ST_CD as ST_CD1,
RTRTRANS_insert.PLN_CD as PLN_CD1,
RTRTRANS_insert.APPL_REQ_EFF_DT as APPL_REQ_EFF_DT1,
RTRTRANS_insert.ADJD_CD as ADJD_CD1,
RTRTRANS_insert.ADJD_DT as ADJD_DT1,
RTRTRANS_insert.WRT_AGT_ID as WRT_AGT_ID1,
RTRTRANS_insert.WRT_AGT_SGN_IND as WRT_AGT_SGN_IND1,
RTRTRANS_insert.SELL_AGT_ID as SELL_AGT_ID1,
RTRTRANS_insert.SELL_AGT_SGN_IND as SELL_AGT_SGN_IND1,
RTRTRANS_insert.SRVC_AGT_ID as SRVC_AGT_ID1,
RTRTRANS_insert.HRA_ADMIN_ID as HRA_ADMIN_ID1,
RTRTRANS_insert.DSBL_IND as DSBL_IND1,
RTRTRANS_insert.ACTUL_EFF_DT as ACTUL_EFF_DT1,
RTRTRANS_insert.HSEHLD_PD_THRU_DT as HSEHLD_PD_THRU_DT1,
RTRTRANS_insert.CNTC_DAY_TM_TEL_NBR as CNTC_DAY_TM_TEL_NBR1,
RTRTRANS_insert.APPL_SGN_DT as APPL_SGN_DT1,
RTRTRANS_insert.HSH_CD as HSH_CD1,
RTRTRANS_insert.APPL_IMAG_ORIG_NBR as APPL_IMAG_ORIG_NBR1,
RTRTRANS_insert.WQ_TYP_DESC as WQ_TYP_DESC1,
RTRTRANS_insert.AGT_SBMT_TYP_ID as AGT_SBMT_TYP_ID1,
RTRTRANS_insert.TEL_ENRL_TYP_ID as TEL_ENRL_TYP_ID1,
RTRTRANS_insert.SBMT_METH_ID as SBMT_METH_ID1,
RTRTRANS_insert.MEDCR_CLM_NBR as MEDCR_CLM_NBR1,
RTRTRANS_insert.AGT_COMM_OE_IND as AGT_COMM_OE_IND1,
RTRTRANS_insert.AGT_COMM_GE_IND as AGT_COMM_GI_IND1,
RTRTRANS_insert.APPL_ACTOR_ID as APPL_ACTOR_ID1,
RTRTRANS_insert.REF_AGT_ID as REF_AGT_ID1,
RTRTRANS_insert.VEND_CD as VEND_CD1,
RTRTRANS_insert.UNDWR_WAIV_IND as UNDWR_WAIV_IND1,
RTRTRANS_insert.BATCH_ID as BATCH_ID1,
TO_DATE(CURRENT_TIMESTAMP) as ROW_EFF_START_DATE,
TO_TIMESTAMP(''12/31/9999'', ''MM/DD/YYYY'') as ROW_EFF_END_DATE,
''Y'' as CURR_ROW_FLG,
RTRTRANS_insert.source_record_id
FROM
RTRTRANS_insert
);



--pre node line TARGET for RPT_AGT_APPL_INS
V_STEP_NAME    := ''TARGET - INSERT RPT_AGT_APPL'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

-- Component RPT_AGT_APPL_INS, Type TARGET 
INSERT INTO BDR_CONF.RPT_AGT_APPL
(
MBRSHP_NBR,
INSD_CD,
APPL_ID,
APPL_RECPT_DT,
APPL_CREAT_DT,
FST_NM,
MIDL_NM,
LST_NM,
DOB_DT,
ST_CD,
PLN_CD,
APPL_REQ_EFF_DT,
ADJD_CD,
ADJD_DT,
WRT_AGT_ID,
WRT_AGT_SGN_IND,
SELL_AGT_ID,
SELL_AGT_SGN_IND,
SRVC_AGT_ID,
HRA_ADMIN_ID,
DSBL_IND,
ACTUL_EFF_DT,
HSEHLD_PD_THRU_DT,
CNTC_DAY_TM_TEL_NBR,
APPL_SGN_DT,
HSH_CD,
APPL_IMAG_ORIG_NBR,
WQ_TYP_DESC,
AGT_SBMT_TYP_ID,
TEL_ENRL_TYP_ID,
SBMT_METH_ID,
MEDCR_CLM_NBR,
AGT_COMM_OE_IND,
AGT_COMM_GI_IND,
APPL_ACTOR_ID,
REF_AGT_ID,
VEND_CD,
UNDWR_WAIV_IND,
ROW_EFF_STRT_DT,
ROW_EFF_END_DT,
CURR_ROW_FLG,
ETL_LST_BTCH_ID
)
SELECT
EXP_INS.MBRSHP_NBR1 /* MBRSHP_NBR */,
EXP_INS.INSD_CD1 /* INSD_CD */,
EXP_INS.APPL_ID1 /* APPL_ID */,
EXP_INS.APPL_RECPT_DT1 /* APPL_RECPT_DT */,
EXP_INS.APPL_CREAT_DT1 /* APPL_CREAT_DT */,
EXP_INS.FST_NM1 /* FST_NM */,
EXP_INS.MIDL_NM1 /* MIDL_NM */,
EXP_INS.LST_NM1 /* LST_NM */,
EXP_INS.DOB_DT1 /* DOB_DT */,
EXP_INS.ST_CD1 /* ST_CD */,
EXP_INS.PLN_CD1 /* PLN_CD */,
EXP_INS.APPL_REQ_EFF_DT1 /* APPL_REQ_EFF_DT */,
EXP_INS.ADJD_CD1 /* ADJD_CD */,
EXP_INS.ADJD_DT1 /* ADJD_DT */,
EXP_INS.WRT_AGT_ID1 /* WRT_AGT_ID */,
EXP_INS.WRT_AGT_SGN_IND1 /* WRT_AGT_SGN_IND */,
EXP_INS.SELL_AGT_ID1 /* SELL_AGT_ID */,
EXP_INS.SELL_AGT_SGN_IND1 /* SELL_AGT_SGN_IND */,
EXP_INS.SRVC_AGT_ID1 /* SRVC_AGT_ID */,
EXP_INS.HRA_ADMIN_ID1 /* HRA_ADMIN_ID */,
EXP_INS.DSBL_IND1 /* DSBL_IND */,
EXP_INS.ACTUL_EFF_DT1 /* ACTUL_EFF_DT */,
EXP_INS.HSEHLD_PD_THRU_DT1 /* HSEHLD_PD_THRU_DT */,
EXP_INS.CNTC_DAY_TM_TEL_NBR1 /* CNTC_DAY_TM_TEL_NBR */,
EXP_INS.APPL_SGN_DT1 /* APPL_SGN_DT */,
EXP_INS.HSH_CD1 /* HSH_CD */,
EXP_INS.APPL_IMAG_ORIG_NBR1 /* APPL_IMAG_ORIG_NBR */,
EXP_INS.WQ_TYP_DESC1 /* WQ_TYP_DESC */,
EXP_INS.AGT_SBMT_TYP_ID1 /* AGT_SBMT_TYP_ID */,
EXP_INS.TEL_ENRL_TYP_ID1 /* TEL_ENRL_TYP_ID */,
EXP_INS.SBMT_METH_ID1 /* SBMT_METH_ID */,
EXP_INS.MEDCR_CLM_NBR1 /* MEDCR_CLM_NBR */,
EXP_INS.AGT_COMM_OE_IND1 /* AGT_COMM_OE_IND */,
EXP_INS.AGT_COMM_GI_IND1 /* AGT_COMM_GI_IND */,
EXP_INS.APPL_ACTOR_ID1 /* APPL_ACTOR_ID */,
EXP_INS.REF_AGT_ID1 /* REF_AGT_ID */,
EXP_INS.VEND_CD1 /* VEND_CD */,
EXP_INS.UNDWR_WAIV_IND1 /* UNDWR_WAIV_IND */,
EXP_INS.ROW_EFF_START_DATE /* ROW_EFF_STRT_DT */,
EXP_INS.ROW_EFF_END_DATE /* ROW_EFF_END_DT */,
EXP_INS.CURR_ROW_FLG /* CURR_ROW_FLG */,
EXP_INS.BATCH_ID1 /* ETL_LST_BTCH_ID */
FROM
EXP_INS
WHERE MBRSHP_NBR1 IS NOT NULL ;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );


INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );



--pre node line TARGET for RPT_AGT_APPL_UPD_INS
V_STEP_NAME    := ''TARGET - INSERT RPT_AGT_APPL'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

-- Component RPT_AGT_APPL_UPD_INS, Type TARGET 
INSERT INTO BDR_CONF.RPT_AGT_APPL
(
MBRSHP_NBR,
INSD_CD,
APPL_ID,
APPL_RECPT_DT,
APPL_CREAT_DT,
FST_NM,
MIDL_NM,
LST_NM,
DOB_DT,
ST_CD,
PLN_CD,
APPL_REQ_EFF_DT,
ADJD_CD,
ADJD_DT,
WRT_AGT_ID,
WRT_AGT_SGN_IND,
SELL_AGT_ID,
SELL_AGT_SGN_IND,
SRVC_AGT_ID,
HRA_ADMIN_ID,
DSBL_IND,
ACTUL_EFF_DT,
HSEHLD_PD_THRU_DT,
CNTC_DAY_TM_TEL_NBR,
APPL_SGN_DT,
HSH_CD,
APPL_IMAG_ORIG_NBR,
WQ_TYP_DESC,
AGT_SBMT_TYP_ID,
TEL_ENRL_TYP_ID,
SBMT_METH_ID,
MEDCR_CLM_NBR,
AGT_COMM_OE_IND,
AGT_COMM_GI_IND,
APPL_ACTOR_ID,
REF_AGT_ID,
VEND_CD,
UNDWR_WAIV_IND,
ROW_EFF_STRT_DT,
ROW_EFF_END_DT,
CURR_ROW_FLG,
ETL_LST_BTCH_ID
)
SELECT
EXP_UPD_INSERT.MBRSHP_NBR3 /* MBRSHP_NBR */,
EXP_UPD_INSERT.INSD_CD3 /* INSD_CD */,
EXP_UPD_INSERT.APPL_ID3 /* APPL_ID */,
EXP_UPD_INSERT.APPL_RECPT_DT3 /* APPL_RECPT_DT */,
EXP_UPD_INSERT.APPL_CREAT_DT3 /* APPL_CREAT_DT */,
EXP_UPD_INSERT.FST_NM3 /* FST_NM */,
EXP_UPD_INSERT.MIDL_NM3 /* MIDL_NM */,
EXP_UPD_INSERT.LST_NM3 /* LST_NM */,
EXP_UPD_INSERT.DOB_DT3 /* DOB_DT */,
EXP_UPD_INSERT.ST_CD3 /* ST_CD */,
EXP_UPD_INSERT.PLN_CD3 /* PLN_CD */,
EXP_UPD_INSERT.APPL_REQ_EFF_DT3 /* APPL_REQ_EFF_DT */,
EXP_UPD_INSERT.ADJD_CD3 /* ADJD_CD */,
EXP_UPD_INSERT.ADJD_DT3 /* ADJD_DT */,
EXP_UPD_INSERT.WRT_AGT_ID3 /* WRT_AGT_ID */,
EXP_UPD_INSERT.WRT_AGT_SGN_IND3 /* WRT_AGT_SGN_IND */,
EXP_UPD_INSERT.SELL_AGT_ID3 /* SELL_AGT_ID */,
EXP_UPD_INSERT.SELL_AGT_SGN_IND3 /* SELL_AGT_SGN_IND */,
EXP_UPD_INSERT.SRVC_AGT_ID3 /* SRVC_AGT_ID */,
EXP_UPD_INSERT.HRA_ADMIN_ID3 /* HRA_ADMIN_ID */,
EXP_UPD_INSERT.DSBL_IND3 /* DSBL_IND */,
EXP_UPD_INSERT.ACTUL_EFF_DT3 /* ACTUL_EFF_DT */,
EXP_UPD_INSERT.HSEHLD_PD_THRU_DT3 /* HSEHLD_PD_THRU_DT */,
EXP_UPD_INSERT.CNTC_DAY_TM_TEL_NBR3 /* CNTC_DAY_TM_TEL_NBR */,
EXP_UPD_INSERT.APPL_SGN_DT3 /* APPL_SGN_DT */,
EXP_UPD_INSERT.HSH_CD3 /* HSH_CD */,
EXP_UPD_INSERT.APPL_IMAG_ORIG_NBR3 /* APPL_IMAG_ORIG_NBR */,
EXP_UPD_INSERT.WQ_TYP_DESC3 /* WQ_TYP_DESC */,
EXP_UPD_INSERT.AGT_SBMT_TYP_ID3 /* AGT_SBMT_TYP_ID */,
EXP_UPD_INSERT.TEL_ENRL_TYP_ID3 /* TEL_ENRL_TYP_ID */,
EXP_UPD_INSERT.SBMT_METH_ID3 /* SBMT_METH_ID */,
EXP_UPD_INSERT.MEDCR_CLM_NBR3 /* MEDCR_CLM_NBR */,
EXP_UPD_INSERT.AGT_COMM_OE_IND3 /* AGT_COMM_OE_IND */,
EXP_UPD_INSERT.AGT_COMM_GI_IND3 /* AGT_COMM_GI_IND */,
EXP_UPD_INSERT.APPL_ACTOR_ID3 /* APPL_ACTOR_ID */,
EXP_UPD_INSERT.REF_AGT_ID3 /* REF_AGT_ID */,
EXP_UPD_INSERT.VEND_CD3 /* VEND_CD */,
EXP_UPD_INSERT.UNDWR_WAIV_IND3 /* UNDWR_WAIV_IND */,
EXP_UPD_INSERT.ROW_EFF_START_DATE /* ROW_EFF_STRT_DT */,
EXP_UPD_INSERT.ROW_EFF_END_DATE /* ROW_EFF_END_DT */,
EXP_UPD_INSERT.CURR_ROW_FLG /* CURR_ROW_FLG */,
EXP_UPD_INSERT.BATCH_ID3 /* ETL_LST_BTCH_ID */
FROM
EXP_UPD_INSERT;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );


INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );


-- Component UPD_UPDATE, Type UPDATE 
CREATE OR REPLACE TEMPORARY TABLE UPD_UPDATE AS
(
/* UPDATE_STRATEGY_ACTION = 0 FOR INSERT / UPDATE_STRATEGY_ACTION = 1 FOR UPDATE / UPDATE_STRATEGY_ACTION = 2 FOR DELETE / UPDATE_STRATEGY_ACTION = 3 FOR REJECT */
SELECT
EXP_UPD_UPDATE.RPT_AGT_APPL_SK3 as RPT_AGT_APPL_SK3,
EXP_UPD_UPDATE.BATCH_ID3 as BATCH_ID3,
EXP_UPD_UPDATE.ETL_EFF_END_DATE as ROW_EFF_END_DATE,
EXP_UPD_UPDATE.CURR_ROW_FLG as CURR_ROW_FLG,
1 as UPDATE_STRATEGY_ACTION
FROM
EXP_UPD_UPDATE
);



--pre node line TARGET for RPT_AGT_APPL_UPD_UPDATE
V_STEP_NAME    := ''TARGET - UPDATE RPT_AGT_APPL'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

-- Component RPT_AGT_APPL_UPD_UPDATE, Type TARGET 
/* Perform Updates */
UPDATE BDR_CONF.RPT_AGT_APPL
SET
ROW_EFF_END_DT = UPD_UPDATE.ROW_EFF_END_DATE,
CURR_ROW_FLG = UPD_UPDATE.CURR_ROW_FLG,
ETL_LST_BTCH_ID = UPD_UPDATE.BATCH_ID3
FROM UPD_UPDATE
WHERE UPD_UPDATE.UPDATE_STRATEGY_ACTION = 1 AND RPT_AGT_APPL.RPT_AGT_APPL_SK = UPD_UPDATE.RPT_AGT_APPL_SK3
;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );


INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

CALL UTIL.SP_ETL_CHECK_CONSTRAINTS(:DB_NAME , :APPLICATION , :WORKFLOW_NAME , :OBJECT_NAME , :V_BATCH_ID );


UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''COMPLETE'', ERROR_MSG = null, BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
; 

UPDATE  UTIL.ETL_BATCH_OBJECT_INCR_VALU SET INCR_COLUMN_VALUE = :V_BATCH_ID, LST_MOD_DT = CURRENT_TIMESTAMP() WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID''; 

EXCEPTION

WHEN OTHER THEN



UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''ERROR'', ERROR_MSG = :SQLERRM,  BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
;

INSERT INTO  UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ERROR_MSG, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''ERROR'', :V_STEP_NAME, :V_STEP_SEQ, :SQLERRM, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() )
;



RAISE;

END;

';