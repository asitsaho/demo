USE SCHEMA BDR_CONF; CREATE OR REPLACE PROCEDURE "SP_CONFORMEDDIMENSIONS_IXL_APPLICATIONSALECHANNEL_D"("DB_NAME" VARCHAR(16777216), "APPLICATION" VARCHAR(16777216), "WORKFLOW_NAME" VARCHAR(16777216), "OBJECT_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE


V_ROWS_INSERTED  INTEGER;
V_ROWS_UPDATED INTEGER;
V_ROWS_DELETED INTEGER;
V_LAST_QUERY_ID VARCHAR;

V_WH VARCHAR;
V_BATCH_ID INTEGER;
V_ETL_LST_BTCH_ID INTEGER;

V_BATCH_OBJECT_START_TIME        VARCHAR;
V_STEP_START_TIME    VARCHAR;
V_STEP_NAME VARCHAR;
V_STEP_SEQ INTEGER DEFAULT 0;
v_cuttofdate TIMESTAMP; ---OAS ADD


BEGIN

EXECUTE IMMEDIATE ''USE DATABASE ''||:DB_NAME; 

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_BATCH_OBJECT_START_TIME := (SELECT CURRENT_TIMESTAMP());


LET res1 RESULTSET := 
(

SELECT 

WH ,
BATCH_ID
  
FROM UTIL.ETL_BATCH_OBJECT_CONTROL
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
FETCH FIRST 1 ROW ONLY

)
;


LET C1 CURSOR FOR res1;
open C1;
FETCH C1 into  V_WH,V_BATCH_ID ;
close C1;





EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:V_WH;
USE SCHEMA BDR_CONF;	------OAS ADD

INSERT INTO UTIL.ETL_BATCH_OBJECT_INCR_VALU (APPLICATION, WORKFLOW_NAME, OBJECT_NAME, INCR_COLUMN, INCR_COLUMN_VALUE )
SELECT * FROM 
(select :APPLICATION AS APPLICATION, :WORKFLOW_NAME AS WORKFLOW_NAME, :OBJECT_NAME AS OBJECT_NAME, ''ETL_LST_BTCH_ID'' AS INCR_COLUMN, -1 AS INCR_COLUMN_VALUE) A
WHERE NOT EXISTS (SELECT 1 FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU B WHERE B.APPLICATION = A.APPLICATION AND B.WORKFLOW_NAME = A.WORKFLOW_NAME AND B.OBJECT_NAME = A.OBJECT_NAME AND B.INCR_COLUMN = A.INCR_COLUMN)
;
V_ETL_LST_BTCH_ID := (SELECT INCR_COLUMN_VALUE FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID'');  

---Commented by OAS JNIKAM--------------
/*
CREATE OR REPLACE PROCEDURE DM.sp_confdim_salechnl_d (
    iv_cutoffdate        IN DATE,
    p_tocontinuestatus   OUT VARCHAR2,
    p_errorynflg         OUT VARCHAR2,
    p_errorstr           OUT VARCHAR2
) AS

    v_proc_name    VARCHAR(50) := ''SP_CONFDIM_SALECHNL_D'';
    v_rows_afftd   NUMBER(20) := 0;
    v_btch_id      NUMBER(10);
    v_cuttofdate   DATE;
BEGIN
*/
---Commented by OAS JNIKAM
    --v_cuttofdate := iv_cutoffdate;	--OAS DELETE
	v_cuttofdate := (SELECT DATEADD(YEAR,-9, trunc(CURRENT_DATE, ''year'')));		-----------OAS ADD
	
---Commented by OAS JNIKAM
/*
    SELECT
        MAX(batch_id)
    INTO v_btch_id
    FROM
        etl.etl_batch_log
    WHERE
        application = ''CDC''
        AND batch_status = ''COMPLETE'';

    INSERT INTO etl.etl_detail_load_info (
        application,
        etl_batch_id,
        etl_proc_name,
        action,
        step_info,
        rows_affected,
        etl_datetime
    ) VALUES (
        ''CONFORMED_DIMENSIONS'',
        v_btch_id,
        v_proc_name,
        ''START'',
        ''PROCEDURE STARTS'',
        v_rows_afftd,
        systimestamp
    );
*/

---Commented by OAS JNIKAM


V_STEP_NAME    := ''TARGET - INSERT WRK_SALE_CHANNEL'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

 --US86770 Acquisition Channel Redesign Agent
CREATE OR REPLACE TRANSIENT TABLE BDR_DM.WRK_SALE_CHANNEL (
        applicationid NUMBER,
        sale_channel_level_1 VARCHAR,
        sale_channel_level_2 VARCHAR,
        sale_channel_level_3 VARCHAR
		
		) AS  
	
	select source.application_id, ''Agent'' , source.level2, source.level3 from 
	
	(
        SELECT DISTINCT
            wa.agent,
            wa.application_id,
            a.appl_actor_id,
            am.application_mechanism_id,
            ac.contact_type_id,
            a.vendor_code,
            oad.phone_enrollment_type_id,
            upper(oad.signature_submission),
            CASE
                    WHEN wa.agent = ''Y''
                         AND ac.contact_type_id = 1
                         AND am.application_mechanism_id = 2 THEN ''Electronic''
                    WHEN wa.agent = ''Y''
                         AND ac.contact_type_id = 3
                         AND am.application_mechanism_id = 1 THEN ''Mail''
                    WHEN wa.agent = ''Y''
                         AND ac.contact_type_id = 10
                         AND am.application_mechanism_id = 2 THEN ''OLE''
                    WHEN wa.agent = ''Y''
                         AND ac.contact_type_id = 1
                         AND oad.phone_enrollment_type_id != ''Y''
                         AND am.application_mechanism_id = 2 THEN ''Phone''
                    ELSE ''Other''
                END
            level2,
            CASE
                    WHEN wa.agent = ''Y''
                         AND ac.contact_type_id = 1
                         AND am.application_mechanism_id = 2
                         AND nvl(upper(oad.signature_submission),'' '') != ''SECURITYQUESTION'' THEN ''Electronic''
                    WHEN wa.agent = ''Y''
                         AND ac.contact_type_id = 1
                         AND am.application_mechanism_id = 2
                         AND nvl(upper(oad.signature_submission),'' '') = ''SECURITYQUESTION'' THEN ''Security Question''
                    WHEN wa.agent = ''Y''
                         AND ac.contact_type_id = 3
                         AND am.application_mechanism_id = 1 THEN ''Traditional - Mail''
                    WHEN wa.agent = ''Y''
                         AND ac.contact_type_id = 10
                         AND am.application_mechanism_id = 2
                         AND nvl(upper(oad.signature_submission),'' '') = ''SECURITYQUESTION'' THEN ''Security Question''
                    WHEN wa.agent = ''Y''
                         AND ac.contact_type_id = 10
                         AND am.application_mechanism_id = 2
                         AND nvl(upper(oad.signature_submission),'' '') != ''SECURITYQUESTION''
                         AND a.vendor_code IS NOT NULL THEN ''External Partners''
                    WHEN wa.agent = ''Y''
                         AND ac.contact_type_id = 10
                         AND am.application_mechanism_id = 2
                         AND nvl(upper(oad.signature_submission),'' '') != ''SECURITYQUESTION''
                         AND a.vendor_code IS NULL THEN ''Traditional - OLE''
                    WHEN wa.agent = ''Y''
                         AND ac.contact_type_id = 1
                         AND oad.phone_enrollment_type_id != ''Y''
                         AND am.application_mechanism_id = 2 THEN ''Optum CSS''
                    ELSE ''Other''
                END
            level3
        FROM
            (
                SELECT DISTINCT
                    application_id,
                    ''Y'' AS agent
                FROM
                    (
                        SELECT
                            a.application_id
                        FROM
                            SRC_COMPAS_D.application a
                        WHERE
                            a.appl_actor_id = 3
                            AND a.appl_receipt_date >= :v_cuttofdate          -- 1.3mi
                        UNION

              --   2.And/or the Application has an associated Agent ID
                        SELECT
                            aa.application_id
                        FROM
                            SRC_COMPAS_D.application_agent aa,
                            SRC_COMPAS_D.application a
                        WHERE
                            aa.application_id = a.application_id
                            AND a.appl_receipt_date >= :v_cuttofdate    -- 2.24 mi
                        UNION

              -- 3. And/or the Hash Code on the Application is  2460720307
                        SELECT
                            a.application_id
                        FROM
                            SRC_COMPAS_D.application a
                        WHERE
                            a.hash_cd = ''2460720307''
                            AND a.appl_receipt_date >= :v_cuttofdate           -- 1.31
                        UNION

              --4.  And/or the Application has the Signature of the Selling Agent (Selling Agent Signature Indicator is Y)
                        SELECT
                            a.application_id
                        FROM
                            SRC_COMPAS_D.application_indicator ai,
                            SRC_COMPAS_D.application a
                        WHERE
                            ai.application_id = a.application_id
                            AND ai.selling_agent_signature_ind = ''Y''
                            AND a.appl_receipt_date >= :v_cuttofdate
                    )
            ) wa
            INNER JOIN SRC_COMPAS_D.application a ON wa.application_id = a.application_id
            INNER JOIN SRC_COMPAS_D.application_actor aa ON a.appl_actor_id = aa.application_actor_id
            INNER JOIN SRC_COMPAS_D.application_mechanism am ON a.appl_mechanism_id = am.application_mechanism_id
            INNER JOIN SRC_COMPAS_D.contact_hist_contact_type ac ON a.appl_channel_id = ac.contact_type_id
            LEFT OUTER JOIN (
                SELECT
                    app.application_id,
                    MAX(dtl.phone_enrollment_type_id) phone_enrollment_type_id,
                    MAX(dtl.signature_submission) signature_submission
                FROM
                    SRC_COMPAS_D.OLE_APPLICATION_DETAIL_ATTR dtl,
                    SRC_COMPAS_D.ole_application app
                WHERE
                    dtl.ole_application_id = app.ole_application_id
                GROUP BY
                    app.application_id
            ) oad ON wa.application_id = oad.application_id
        WHERE
            ( wa.agent = ''Y'' )
    ) source
	
	
;


V_ROWS_INSERTED := (SELECT count(1) FROM BDR_DM.WRK_SALE_CHANNEL );

	

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );	
	
	
---Commented by OAS JNIKAM	 
/*	
    v_rows_afftd := SQL%rowcount;
    INSERT INTO etl.etl_detail_load_info (
        application,
        etl_batch_id,
        etl_proc_name,
        action,
        step_info,
        rows_affected,
        etl_datetime
    ) VALUES (
        ''CONFORMED_DIMENSIONS'',
        v_btch_id,
        v_proc_name,
        ''INSERT'',
        ''MERGE/INSERT AGENT INTO WRK_SALE_CHANNEL '',
        v_rows_afftd,
        systimestamp
    );

    dm.pkg_db_util.sp_gather_table_stats(''DM'',''WRK_SALE_CHANNEL'');
*/
---Commented by OAS JNIKAM	 
------eAllianceRetail------

V_STEP_NAME    := ''TARGET - MERGE wrk_sale_channel'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

----AGENT_TYPE_DESC = ''Referral Agent'' and  agent_char_type_id = 4(aggregator)
    MERGE INTO BDR_DM.wrk_sale_channel target USING (
        SELECT DISTINCT
            s1.application_id,
            s1.source_acqn_chnl_lvl_1,
            s1.source_acqn_chnl_lvl_2,
            CASE
                    WHEN s1.source_acqn_chnl_lvl_2 = ''Electronic''   THEN (
                        CASE
                            WHEN nvl(upper(s1.signature_submission),'' '') = ''SECURITYQUESTION'' THEN ''Security Question''
                            ELSE ''Electronic''
                        END
                    )
                    WHEN s1.source_acqn_chnl_lvl_2 = ''Mail''         THEN ''Traditional - Mail''
                    WHEN s1.source_acqn_chnl_lvl_2 = ''OLE''          THEN (
                        CASE
                            WHEN s1.vendor_code IS NOT NULL THEN ''External Partners''
                            WHEN (
                                s1.appl_actor_id = ''3''
                                AND s1.contact_type_desc = ''WEB''
                                AND s1.appl_mechanism_description = ''WEB''
                                AND nvl(upper(s1.signature_submission),'' '') = ''SECURITYQUESTION''
                                AND s1.vendor_code IS NULL
                            ) THEN ''Security Question''
                            ELSE ''Traditional - OLE''
                        END
                    )
                    WHEN s1.source_acqn_chnl_lvl_2 = ''Phone''        THEN ''Optum CSS''
                    ELSE ''Other''
                END
            AS source_acqn_chnl_lvl_3
        FROM
            (
                SELECT DISTINCT
                    aa.application_id,
                    a.appl_actor_id,
                    aa.agent_id,
                    am.appl_mechanism_description,
                    ct.contact_type_desc,
                    oad.phone_enrollment_type_id,
                    oad.signature_submission,
                    a.vendor_code,
                    CASE
                            WHEN a.appl_actor_id = ''2''
                                 AND ct.contact_type_desc = ''PHONE (IN)''
                                 AND am.appl_mechanism_description = ''WEB''
                                 AND nvl(oad.phone_enrollment_type_id,'' '') <> ''Y'' THEN ''Phone''
                            WHEN a.appl_actor_id = ''3''
                                 AND ct.contact_type_desc = ''PHONE (IN)''
                                 AND am.appl_mechanism_description = ''WEB'' THEN ''Electronic''
                            WHEN ct.contact_type_desc = ''WRITTEN MAIL''
                                 AND am.appl_mechanism_description = ''MAIL'' THEN ''Mail''
                            WHEN (
                                (
                                    a.appl_actor_id = ''1''
                                    AND ct.contact_type_desc = ''WEB''
                                    AND am.appl_mechanism_description = ''WEB''
                                    AND a.vendor_code IS NULL
                                    AND nvl(upper(oad.signature_submission),'' '') <> ''SECURITYQUESTION''
                                )
                                OR (
                                    a.appl_actor_id = ''3''
                                    AND ct.contact_type_desc = ''WEB''
                                    AND am.appl_mechanism_description = ''WEB''
                                )
                            ) THEN ''OLE''
                            ELSE ''Other''
                        END
                    AS source_acqn_chnl_lvl_2,
                    ''eAlliance Retail'' AS source_acqn_chnl_lvl_1
                FROM
                    SRC_COMPAS_D.application_agent aa
                    INNER JOIN SRC_COMPAS_D.agent_char ac ON aa.agent_id = ac.agent_id
                    INNER JOIN SRC_COMPAS_D.agent_type atp ON aa.agent_type_id = atp.agent_type_id
                    INNER JOIN SRC_COMPAS_D.application a ON a.application_id = aa.application_id
                    INNER JOIN SRC_COMPAS_D.application_mechanism am ON am.application_mechanism_id = a.appl_mechanism_id
                    INNER JOIN SRC_COMPAS_D.contact_hist_contact_type ct ON ct.contact_type_id = a.appl_channel_id
                    LEFT OUTER JOIN (
                        SELECT
                            app.application_id,
                            MAX(dtl.phone_enrollment_type_id) phone_enrollment_type_id,
                            MAX(dtl.signature_submission) signature_submission
                        FROM
                            SRC_COMPAS_D.OLE_APPLICATION_DETAIL_ATTR dtl,
                            SRC_COMPAS_D.ole_application app
                        WHERE
                            dtl.ole_application_id = app.ole_application_id
                        GROUP BY
                            app.application_id
                    ) oad ON a.application_id = oad.application_id
                WHERE
                   -- atp.agent_type_desc = ''Referral Agent'' AND
                    ac.agent_char_type_id = 4
                    AND (
                        ( aa.agent_id NOT IN (
                            SELECT
                                agent_id
                            FROM
                                bdr_dm.acqn_chnl_agt_lst
                            WHERE
                                agent_type = ''Referral Agent''
                                AND channel_type = ''eAlliance Retail''
                        ) )---Instead of hardcode values take it from static  table for selling agent
                        OR ( aa.agent_id NOT IN (
                            SELECT
                                agent_id
                            FROM
                                bdr_dm.acqn_chnl_agt_lst
                            WHERE
                                agent_type = ''Selling Agent''
                                AND channel_type = ''eAlliance Retail''
                        ) )
                    )
            ) s1
    )
    source ON ( target.applicationid = source.application_id )
    WHEN MATCHED THEN UPDATE SET sale_channel_level_1 = source_acqn_chnl_lvl_1,
                                 sale_channel_level_2 = source_acqn_chnl_lvl_2,
                                 sale_channel_level_3 = source_acqn_chnl_lvl_3
    WHEN NOT MATCHED THEN INSERT (
        applicationid,
        sale_channel_level_1,
        sale_channel_level_2,
        sale_channel_level_3 ) VALUES (
        source.application_id,
        source.source_acqn_chnl_lvl_1,
        source.source_acqn_chnl_lvl_2,
        source.source_acqn_chnl_lvl_3 );


	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

V_ROWS_UPDATED := (SELECT $2 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );	

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );	
	
	
	---Commented by OAS JNIKAM	 
	/*
    v_rows_afftd := SQL%rowcount;
    INSERT INTO etl.etl_detail_load_info (
        application,
        etl_batch_id,
        etl_proc_name,
        action,
        step_info,
        rows_affected,
        etl_datetime
    ) VALUES (
        ''CONFORMED_DIMENSIONS'',
        v_btch_id,
        v_proc_name,
        ''MERGE'',
        ''MERGE/INSERT EALLIANCE RETAIL INTO WRK_SALE_CHANNEL '',
        v_rows_afftd,
        systimestamp
    );

    COMMIT;
    dm.pkg_db_util.sp_gather_table_stats(''DM'',''WRK_SALE_CHANNEL'');
*/
---Commented by OAS JNIKAM	 
-----eAllianceClassic----

V_STEP_NAME    := ''TARGET - MERGE wrk_sale_channel'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

--AGENT_TYPE_DESC = ''Referral Agent'' and  agent_char_type_id = 4(aggregator)---
    MERGE INTO bdr_dm.wrk_sale_channel target --where ACQN_CHNL_LVL_1=''Agent''
     USING (
        SELECT DISTINCT
            application_id,
            source_acqn_chnl_lvl_1,
            source_acqn_chnl_lvl_2,
            CASE
                    WHEN s1.source_acqn_chnl_lvl_2 = ''Electronic''   THEN (
                        CASE
                            WHEN nvl(upper(s1.signature_submission),'' '') = ''SECURITYQUESTION'' THEN ''Security Question''
                            ELSE ''Electronic''
                        END
                    )
                    WHEN s1.source_acqn_chnl_lvl_2 = ''Mail''         THEN ''Traditional - Mail''
                    WHEN s1.source_acqn_chnl_lvl_2 = ''OLE''          THEN (
                        CASE
                            WHEN s1.vendor_code IS NOT NULL THEN ''External Partners''
                            WHEN (
                                s1.appl_actor_id = ''3''
                                AND s1.contact_type_desc = ''WEB''
                                AND s1.appl_mechanism_description = ''WEB''
                                AND nvl(upper(s1.signature_submission),'' '') = ''SECURITYQUESTION''
                                AND s1.vendor_code IS NULL
                            ) THEN ''Security Question''
                            ELSE ''Traditional - OLE''
                        END
                    )
                    WHEN s1.source_acqn_chnl_lvl_2 = ''Phone''        THEN ''Optum CSS''
                    ELSE ''Other''
                END
            AS source_acqn_chnl_lvl_3
        FROM
            (
                SELECT DISTINCT
                    aa.application_id,
                    a.appl_actor_id,
                    aa.agent_id,
                    am.appl_mechanism_description,
                    ct.contact_type_desc,
                    oad.phone_enrollment_type_id,
                    oad.signature_submission,
                    a.vendor_code,
                    CASE
                            WHEN a.appl_actor_id = ''2''
                                 AND ct.contact_type_desc = ''PHONE (IN)''
                                 AND am.appl_mechanism_description = ''WEB''
                                 AND nvl(oad.phone_enrollment_type_id,'' '') <> ''Y'' THEN ''Phone''
                            WHEN a.appl_actor_id = ''3''
                                 AND ct.contact_type_desc = ''PHONE (IN)''
                                 AND am.appl_mechanism_description = ''WEB'' THEN ''Electronic''
                            WHEN ct.contact_type_desc = ''WRITTEN MAIL''
                                 AND am.appl_mechanism_description = ''MAIL'' THEN ''Mail''
                            WHEN (
                                (
                                    a.appl_actor_id = ''1''
                                    AND ct.contact_type_desc = ''WEB''
                                    AND am.appl_mechanism_description = ''WEB''
                                    AND a.vendor_code IS NULL
                                    AND nvl(upper(oad.signature_submission),'' '') <> ''SECURITYQUESTION''
                                )
                                OR (
                                    a.appl_actor_id = ''3''
                                    AND ct.contact_type_desc = ''WEB''
                                    AND am.appl_mechanism_description = ''WEB''
                                )
                            ) THEN ''OLE''
                            ELSE ''Other''
                        END
                    AS source_acqn_chnl_lvl_2,
                    ''eAlliance Classic'' AS source_acqn_chnl_lvl_1
                FROM
                    SRC_COMPAS_D.application_agent aa
                    INNER JOIN SRC_COMPAS_D.agent_char ac ON aa.agent_id = ac.agent_id
                    INNER JOIN SRC_COMPAS_D.agent_type atp ON aa.agent_type_id = atp.agent_type_id
                    INNER JOIN SRC_COMPAS_D.application a ON a.application_id = aa.application_id
                    INNER JOIN SRC_COMPAS_D.application_mechanism am ON am.application_mechanism_id = a.appl_mechanism_id
                    INNER JOIN SRC_COMPAS_D.contact_hist_contact_type ct ON ct.contact_type_id = a.appl_channel_id
                    LEFT OUTER JOIN (
                        SELECT
                            app.application_id,
                            MAX(dtl.phone_enrollment_type_id) phone_enrollment_type_id,
                            MAX(dtl.signature_submission) signature_submission
                        FROM
                            SRC_COMPAS_D.OLE_APPLICATION_DETAIL_ATTR dtl,
                            SRC_COMPAS_D.ole_application app
                        WHERE
                            dtl.ole_application_id = app.ole_application_id
                        GROUP BY
                            app.application_id
                    ) oad ON a.application_id = oad.application_id
                WHERE
                   -- atp.agent_type_desc = ''Referral Agent'' AND
                    ac.agent_char_type_id = 4
                    AND (
                        ( aa.agent_id IN (
                            SELECT
                                agent_id
                            FROM
                                BDR_DM.acqn_chnl_agt_lst
                            WHERE
                                agent_type = ''Selling Agent''
                                AND channel_type = ''eAlliance Classic''
                        ) )
                        OR ( aa.agent_id IN (
                            SELECT
                                agent_id
                            FROM
                                bdr_dm.acqn_chnl_agt_lst
                            WHERE
                                agent_type = ''Referral Agent''
                                AND channel_type = ''eAlliance Classic''
                        ) )
                    )
            ) s1
    )
    source ON ( target.applicationid = source.application_id )
    WHEN MATCHED THEN UPDATE SET sale_channel_level_1 = source.source_acqn_chnl_lvl_1,
                                 sale_channel_level_2 = source.source_acqn_chnl_lvl_2,
                                 sale_channel_level_3 = source.source_acqn_chnl_lvl_3
    WHEN NOT MATCHED THEN INSERT (
        applicationid,
        sale_channel_level_1,
        sale_channel_level_2,
        sale_channel_level_3 ) VALUES (
        source.application_id,
        source.source_acqn_chnl_lvl_1,
        source.source_acqn_chnl_lvl_2,
        source.source_acqn_chnl_lvl_3 );


	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

V_ROWS_UPDATED := (SELECT $2 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );		

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );	
	
	
---Commented by OAS JNIKAM	 
/*	
    v_rows_afftd := SQL%rowcount;
    INSERT INTO etl.etl_detail_load_info (
        application,
        etl_batch_id,
        etl_proc_name,
        action,
        step_info,
        rows_affected,
        etl_datetime
    ) VALUES (
        ''CONFORMED_DIMENSIONS'',
        v_btch_id,
        v_proc_name,
        ''MERGE'',
        ''MERGE/INSERT EALLIANCE CLASSIC-1 INTO WRK_SALE_CHANNEL '',
        v_rows_afftd,
        systimestamp
    );

    dm.pkg_db_util.sp_gather_table_stats(''DM'',''WRK_SALE_CHANNEL'');
*/
---Commented by OAS JNIKAM	 
 --eAllianceClassic


V_STEP_NAME    := ''TARGET - MERGE wrk_sale_channel'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;
 --AGENT_TYPE_DESC = ''Referral Agent'' and  agent_char_type_id <> 4(aggregator) and agent_char_type_id IN (1,2,3) AND agent_id<>''SOFTASI1''
    MERGE INTO bdr_dm.wrk_sale_channel target USING (
        SELECT DISTINCT
            application_id,
            source_acqn_chnl_lvl_1,
            source_acqn_chnl_lvl_2,
            CASE
                    WHEN s1.source_acqn_chnl_lvl_2 = ''Electronic''   THEN (
                        CASE
                            WHEN nvl(upper(s1.signature_submission),'' '') = ''SECURITYQUESTION'' THEN ''Security Question''
                            ELSE ''Electronic''
                        END
                    )
                    WHEN s1.source_acqn_chnl_lvl_2 = ''Mail''         THEN ''Traditional - Mail''
                    WHEN s1.source_acqn_chnl_lvl_2 = ''OLE''          THEN (
                        CASE
                            WHEN s1.vendor_code IS NOT NULL THEN ''External Partners''
                            WHEN (
                                s1.appl_actor_id = ''3''
                                AND s1.contact_type_desc = ''WEB''
                                AND s1.appl_mechanism_description = ''WEB''
                                AND nvl(upper(s1.signature_submission),'' '') = ''SECURITYQUESTION''
                                AND s1.vendor_code IS NULL
                            ) THEN ''Security Question''
                            ELSE ''Traditional - OLE''
                        END
                    )
                    WHEN s1.source_acqn_chnl_lvl_2 = ''Phone''        THEN ''Optum CSS''
                    ELSE ''Other''
                END
            AS source_acqn_chnl_lvl_3
        FROM
            (
                SELECT DISTINCT
                    aa.application_id,
                    a.appl_actor_id,
                    aa.agent_id,
                    am.appl_mechanism_description,
                    ct.contact_type_desc,
                    oad.phone_enrollment_type_id,
                    oad.signature_submission,
                    a.vendor_code,
                    CASE
                            WHEN a.appl_actor_id = ''2''
                                 AND ct.contact_type_desc = ''PHONE (IN)''
                                 AND am.appl_mechanism_description = ''WEB''
                                 AND nvl(oad.phone_enrollment_type_id,'' '') <> ''Y'' THEN ''Phone''
                            WHEN a.appl_actor_id = ''3''
                                 AND ct.contact_type_desc = ''PHONE (IN)''
                                 AND am.appl_mechanism_description = ''WEB'' THEN ''Electronic''
                            WHEN ct.contact_type_desc = ''WRITTEN MAIL''
                                 AND am.appl_mechanism_description = ''MAIL'' THEN ''Mail''
                            WHEN (
                                (
                                    a.appl_actor_id = ''1''
                                    AND ct.contact_type_desc = ''WEB''
                                    AND am.appl_mechanism_description = ''WEB''
                                    AND a.vendor_code IS NULL
                                    AND nvl(upper(oad.signature_submission),'' '') <> ''SECURITYQUESTION''
                                )
                                OR (
                                    a.appl_actor_id = ''3''
                                    AND ct.contact_type_desc = ''WEB''
                                    AND am.appl_mechanism_description = ''WEB''
                                )
                            ) THEN ''OLE''
                            ELSE ''Other''
                        END
                    AS source_acqn_chnl_lvl_2,
                    ''eAlliance Classic'' AS source_acqn_chnl_lvl_1
                FROM
                    SRC_COMPAS_D.application_agent aa
                    INNER JOIN SRC_COMPAS_D.agent_char ac ON aa.agent_id = ac.agent_id
                    INNER JOIN SRC_COMPAS_D.agent_type atp ON aa.agent_type_id = atp.agent_type_id
                    INNER JOIN SRC_COMPAS_D.application a ON a.application_id = aa.application_id
                    INNER JOIN SRC_COMPAS_D.application_mechanism am ON am.application_mechanism_id = a.appl_mechanism_id
                    INNER JOIN SRC_COMPAS_D.contact_hist_contact_type ct ON ct.contact_type_id = a.appl_channel_id
                    LEFT OUTER JOIN (
                        SELECT
                            app.application_id,
                            MAX(dtl.phone_enrollment_type_id) phone_enrollment_type_id,
                            MAX(dtl.signature_submission) signature_submission
                        FROM
                            SRC_COMPAS_D.OLE_APPLICATION_DETAIL_ATTR dtl,
                            SRC_COMPAS_D.ole_application app
                        WHERE
                            dtl.ole_application_id = app.ole_application_id
                        GROUP BY
                            app.application_id
                    ) oad ON a.application_id = oad.application_id
                WHERE
                    -- atp.agent_type_desc = ''Referral Agent'' AND
                       aa.application_id NOT IN (
                        SELECT DISTINCT
                            aa.application_id
                        FROM
                            SRC_COMPAS_D.application_agent aa
                            INNER JOIN SRC_COMPAS_D.agent_char ac ON aa.agent_id = ac.agent_id
                            INNER JOIN SRC_COMPAS_D.agent_type atp ON aa.agent_type_id = atp.agent_type_id
                        WHERE
                            atp.agent_type_desc = ''Referral Agent''
                            AND ac.agent_char_type_id = ''4''
                    )
                    AND nvl(aa.agent_id,''123'') <> ''SOFTASI1''
                    AND (
                        ( aa.agent_id IN (
                            SELECT
                                agent_id
                            FROM
                                BDR_DM.acqn_chnl_agt_lst
                            WHERE
                                agent_type = ''Referral Agent''
                                AND channel_type = ''eAlliance Classic''
                        ) )
                        OR ( aa.agent_id IN (
                            SELECT
                                agent_id
                            FROM
                                BDR_DM.acqn_chnl_agt_lst
                            WHERE
                                agent_type = ''Selling Agent''
                                AND channel_type = ''eAlliance Classic''
                        ) )
                    )
            ) s1
    )
    source ON ( target.applicationid = source.application_id )
    WHEN MATCHED THEN UPDATE SET sale_channel_level_1 = source.source_acqn_chnl_lvl_1,
                                 sale_channel_level_2 = source.source_acqn_chnl_lvl_2,
                                 sale_channel_level_3 = source.source_acqn_chnl_lvl_3
    WHEN NOT MATCHED THEN INSERT (
        applicationid,
        sale_channel_level_1,
        sale_channel_level_2,
        sale_channel_level_3 ) VALUES (
        source.application_id,
        source.source_acqn_chnl_lvl_1,
        source.source_acqn_chnl_lvl_2,
        source.source_acqn_chnl_lvl_3 );


	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

V_ROWS_UPDATED := (SELECT $2 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );		

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );	
	
---Commented by OAS JNIKAM	 
/*	
    v_rows_afftd := SQL%rowcount;
    INSERT INTO etl.etl_detail_load_info (
        application,
        etl_batch_id,
        etl_proc_name,
        action,
        step_info,
        rows_affected,
        etl_datetime
    ) VALUES (
        ''CONFORMED_DIMENSIONS'',
        v_btch_id,
        v_proc_name,
        ''MERGE'',
        ''MERGE/INSERT EALLIANCE CLASSIC-2 INTO WRK_SALE_CHANNEL'',
        v_rows_afftd,
        systimestamp
    );

    COMMIT;
    dm.pkg_db_util.sp_gather_table_stats(''DM'',''WRK_SALE_CHANNEL'');
*/
---Commented by OAS JNIKAM	 
	---GRS----
V_STEP_NAME    := ''TARGET - MERGE wrk_sale_channel'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

    MERGE INTO bdr_dm.wrk_sale_channel target USING (
        SELECT distinct
            s1.application_id,
            ''GRS'' AS source_acqn_chnl_lvl_1,
            s2.source_acqn_chnl_lvl_2,
            s2.source_acqn_chnl_lvl_3
        FROM
            (
                SELECT DISTINCT
                    a.application_id
                FROM
                    SRC_COMPAS_D.application a
                    LEFT OUTER JOIN SRC_COMPAS_D.insured_plan cip ON a.application_id = cip.application_id
                    LEFT OUTER JOIN SRC_COMPAS_D.household_member chhm ON cip.individual_id = chhm.individual_id
                    LEFT OUTER JOIN SRC_COMPAS_D.employer_household cehh ON chhm.household_id = cehh.household_id
                WHERE
                    cip.insured_plan_effective_date BETWEEN cehh.emp_hhold_start_date AND cehh.emp_hhold_stop_date
                    AND a.appl_receipt_date >= :v_cuttofdate
            ) s1
            INNER JOIN (
                SELECT
                    s3.application_id,
                    s3.phone_enrollment_type_id,
                    s3.source_acqn_chnl_lvl_2,
                    s3.signature_submission,
                    s3.vendor_code,
                    CASE
                            WHEN s3.source_acqn_chnl_lvl_2 = ''Electronic''   THEN (
                                CASE
                                    WHEN nvl(upper(s3.signature_submission),'' '') = ''SECURITYQUESTION'' THEN ''Security Question''
                                    ELSE ''Electronic''
                                END
                            )
                            WHEN s3.source_acqn_chnl_lvl_2 = ''Mail''         THEN ''Traditional - Mail''
                            WHEN s3.source_acqn_chnl_lvl_2 = ''OLE''          THEN (
                                CASE
                                    WHEN s3.vendor_code IS NOT NULL THEN ''External Partners''
                                    WHEN (
                                        s3.appl_actor_id = ''3''
                                        AND s3.contact_type_desc = ''WEB''
                                        AND s3.appl_mechanism_description = ''WEB''
                                        AND nvl(upper(s3.signature_submission),'' '') = ''SECURITYQUESTION''
                                    ) THEN ''Security Question''
                                    ELSE ''Traditional - OLE''
                                END
                            )
                            WHEN s3.source_acqn_chnl_lvl_2 = ''Phone''        THEN ''Optum CSS''
                            ELSE ''Other''
                        END
                    AS source_acqn_chnl_lvl_3
                FROM
                    (
                        SELECT DISTINCT
                            a.application_id,
                            a.appl_actor_id,
                            --aa.agent_id,
                            am.appl_mechanism_description,
                            ct.contact_type_desc,
                            oad.phone_enrollment_type_id,
                            oad.signature_submission,
                            a.vendor_code,
                            CASE
                                    WHEN a.appl_actor_id = ''2''
                                         AND ct.contact_type_desc = ''PHONE (IN)''
                                         AND am.appl_mechanism_description = ''WEB''
                                         AND nvl(oad.phone_enrollment_type_id,'' '') <> ''Y'' THEN ''Phone''
                                    WHEN a.appl_actor_id = ''3''
                                         AND ct.contact_type_desc = ''PHONE (IN)''
                                         AND am.appl_mechanism_description = ''WEB'' THEN ''Electronic''
                                    WHEN ct.contact_type_desc = ''WRITTEN MAIL''
                                         AND am.appl_mechanism_description = ''MAIL'' THEN ''Mail''
                                    WHEN (
                                        (
                                            a.appl_actor_id = ''1''
                                            AND ct.contact_type_desc = ''WEB''
                                            AND am.appl_mechanism_description = ''WEB''
                                            AND a.vendor_code IS NULL
                                        )
                                        OR (
                                            a.appl_actor_id = ''3''
                                            AND ct.contact_type_desc = ''WEB''
                                            AND am.appl_mechanism_description = ''WEB''
                                        )
                                    ) THEN ''OLE''
                                    ELSE ''Other''
                                END
                            AS source_acqn_chnl_lvl_2
                        FROM
                           -- SRC_COMPAS_D.application_agent aa
 --               INNER JOIN	SRC_COMPAS_D.agent_char ac
 --               ON aa.agent_id = ac.agent_id
                         --   INNER JOIN SRC_COMPAS_D.agent_type atp ON aa.agent_type_id = atp.agent_type_id
                           -- INNER JOIN
                            SRC_COMPAS_D.application a -- ON a.application_id = aa.application_id
                            INNER JOIN SRC_COMPAS_D.application_mechanism am ON am.application_mechanism_id = a.appl_mechanism_id
                            INNER JOIN SRC_COMPAS_D.contact_hist_contact_type ct ON ct.contact_type_id = a.appl_channel_id
                            LEFT OUTER JOIN (
                                SELECT
                                    app.application_id,
                                    MAX(dtl.phone_enrollment_type_id) phone_enrollment_type_id,
                                    MAX(dtl.signature_submission) signature_submission
                                FROM
                                    SRC_COMPAS_D.OLE_APPLICATION_DETAIL_ATTR dtl,
                                    SRC_COMPAS_D.ole_application app
                                WHERE
                                    dtl.ole_application_id = app.ole_application_id
                                GROUP BY
                                    app.application_id
                            ) oad ON a.application_id = oad.application_id
                    ) s3
            ) s2 ON s1.application_id = s2.application_id  WHERE s1.application_id  NOT IN
                       (SELECT APPLICATIONID FROM BDR_DM.WRK_SALE_CHANNEL)
    )
    source ON ( target.applicationid = source.application_id )
    WHEN MATCHED THEN UPDATE SET sale_channel_level_1 = source_acqn_chnl_lvl_1,
                                 sale_channel_level_2 = source_acqn_chnl_lvl_2,
                                 sale_channel_level_3 = source_acqn_chnl_lvl_3
    WHEN NOT MATCHED THEN INSERT (
        applicationid,
        sale_channel_level_1,
        sale_channel_level_2,
        sale_channel_level_3 ) VALUES (
        source.application_id,
        source.source_acqn_chnl_lvl_1,
        source.source_acqn_chnl_lvl_2,
        source.source_acqn_chnl_lvl_3 );

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

V_ROWS_UPDATED := (SELECT $2 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );		

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );	


---Commented by OAS JNIKAM
/*	 	
    v_rows_afftd := SQL%rowcount;
    INSERT INTO etl.etl_detail_load_info (
        application,
        etl_batch_id,
        etl_proc_name,
        action,
        step_info,
        rows_affected,
        etl_datetime
    ) VALUES (
        ''CONFORMED_DIMENSIONS'',
        v_btch_id,
        v_proc_name,
        ''MERGE'',
        ''MERGE/INSERT GRS INTO WRK_SALE_CHANNEL '',
        v_rows_afftd,
        systimestamp
    );
*/
---Commented by OAS JNIKAM	 
---DTC

V_STEP_NAME    := ''TARGET - MERGE wrk_sale_channel'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

    MERGE INTO bdr_dm.wrk_sale_channel target USING ( SELECT DISTINCT
        sd1.application_id,
        sd1.source_acqn_chnl_lvl_1,
        sd1.source_acqn_chnl_lvl_2,
        CASE
                WHEN sd1.source_acqn_chnl_lvl_2 = ''Electronic''   THEN (
                    CASE
                        WHEN nvl(upper(sd1.signature_submission),'' '') = ''SECURITYQUESTION'' THEN ''Security Question''
                        ELSE ''Electronic''
                    END
                )
                WHEN sd1.source_acqn_chnl_lvl_2 = ''Mail''         THEN ''Traditional - Mail''
                WHEN sd1.source_acqn_chnl_lvl_2 = ''OLE''          THEN (
                    CASE
                        WHEN sd1.vendor_code IS NOT NULL THEN ''External Partners''
                        WHEN (
                            sd1.appl_actor_id = ''3''
                            AND sd1.contact_type_desc = ''WEB''
                            AND sd1.appl_mechanism_description = ''WEB''
                            AND nvl(upper(sd1.signature_submission),'' '') = ''SECURITYQUESTION''
                            AND sd1.vendor_code IS NULL
                        ) THEN ''Security Question''
                        ELSE ''Traditional - OLE''
                    END
                )
                WHEN sd1.source_acqn_chnl_lvl_2 = ''Phone''        THEN ''Optum CSS''
                ELSE ''Other''
            END
        AS source_acqn_chnl_lvl_3
                                                  FROM
        (
            SELECT DISTINCT
                d2.application_id,
                d2.appl_actor_id,
                --aa.agent_id,
                am.appl_mechanism_description,
                ct.contact_type_desc,
                oad.phone_enrollment_type_id,
                oad.signature_submission,
                d2.vendor_code,
                CASE
                        WHEN d2.appl_actor_id = ''2''
                             AND ct.contact_type_desc = ''PHONE (IN)''
                             AND am.appl_mechanism_description = ''WEB''
                             AND nvl(oad.phone_enrollment_type_id,'' '') <> ''Y'' THEN ''Phone''
                        WHEN d2.appl_actor_id = ''3''
                             AND ct.contact_type_desc = ''PHONE (IN)''
                             AND am.appl_mechanism_description = ''WEB'' THEN ''Electronic''
                        WHEN ct.contact_type_desc = ''WRITTEN MAIL''
                             AND am.appl_mechanism_description = ''MAIL'' THEN ''Mail''
                        WHEN (
                            (
                                d2.appl_actor_id = ''1''
                                AND ct.contact_type_desc = ''WEB''
                                AND am.appl_mechanism_description = ''WEB''
                                AND d2.vendor_code IS NULL
                                AND nvl(upper(oad.signature_submission),'' '') <> ''SECURITYQUESTION''
                            )
                            OR (
                                d2.appl_actor_id = ''3''
                                AND ct.contact_type_desc = ''WEB''
                                AND am.appl_mechanism_description = ''WEB''
                            )
                        ) THEN ''OLE''
                        ELSE ''Other''
                    END
                AS source_acqn_chnl_lvl_2,
                ''DTC'' AS source_acqn_chnl_lvl_1
            FROM
                (
                    SELECT
                        d1.application_id,
                        d1.appl_mechanism_id,
                        d1.appl_channel_id,
                        d1.appl_actor_id,
                        d1.vendor_code
                    FROM
                        (
                            SELECT
                                ca.application_id,
                                sar.marketing_channel,
                                sar.campaign_type,
                                ca.appl_mechanism_id,
                                ca.appl_channel_id,
                                ca.appl_actor_id,
                                ca.vendor_code
                            FROM
                                SRC_COMPAS_D.application ca,
                                bdr_smart.application sa,
                                bdr_smart.application_reporting sar
                            WHERE
                                ca.application_id = sa.source_application_id
                                AND sa.application_id = sar.application_id
                            UNION
                            SELECT
                                ca.application_id,
                                sar.marketing_channel,
                                sar.campaign_type,
                                ca.appl_mechanism_id,
                                ca.appl_channel_id,
                                ca.appl_actor_id,
                                ca.vendor_code
                            FROM
                                SRC_COMPAS_D.application ca,
                                SRC_COMPAS_D.insured_plan cip,
                                bdr_smart.insured_plan sip,
                                bdr_smart.application_reporting sar
                            WHERE
                                ca.application_id = cip.application_id
                                AND cip.insured_plan_id = sip.source_insured_plan_id
                                AND sip.application_id = sar.application_id
                        ) d1
                    WHERE
                        (d1.marketing_channel IN (''UNKNOWN - PHONE ENROLLMENT KEYCODE'',
                            ''UNKNOWN - WEB ENROLLMENT KEYCODE'',
                            ''UNKNOWN - INVALID KEYCODE'',
                            ''UNKNOWN - SYSTEM GENERATED KEYCODE'',
                            ''UNKNOWN - AGENT ENROLLMENT KEYCODE'',
                            ''UNKNOWN OTHER'')
                        OR ( d1.marketing_channel = ''DIRECT-TO-CONSUMER''
                             AND ( campaign_type in ( ''DIRECT'',''ADVERTISING/INQUIRY'') or TRIM(campaign_type) is null or TRIM(campaign_type) = '''')
                           )
                        )

                ) d2
                --INNER JOIN SRC_COMPAS_D.application_agent aa ON d2.application_id = aa.application_id
 --   INNER JOIN	SRC_COMPAS_D.agent_char ac
 --   ON aa.agent_id = ac.agent_id
                --INNER JOIN SRC_COMPAS_D.agent_type atp ON aa.agent_type_id = atp.agent_type_id
                INNER JOIN SRC_COMPAS_D.application_mechanism am ON am.application_mechanism_id = d2.appl_mechanism_id
                INNER JOIN SRC_COMPAS_D.contact_hist_contact_type ct ON ct.contact_type_id = d2.appl_channel_id
                LEFT OUTER JOIN (
                    SELECT
                        app.application_id,
                        MAX(dtl.phone_enrollment_type_id) phone_enrollment_type_id,
                        MAX(dtl.signature_submission) signature_submission
                    FROM
                        SRC_COMPAS_D.OLE_APPLICATION_DETAIL_ATTR dtl,
                        SRC_COMPAS_D.ole_application app
                    WHERE
                        dtl.ole_application_id = app.ole_application_id
                    GROUP BY
                        app.application_id
                ) oad ON d2.application_id = oad.application_id
        ) sd1 where sd1.application_id not in ( select applicationid from BDR_DM.wrk_sale_channel)
    UNION
    SELECT DISTINCT
        sd2.application_id,
        sd2.source_acqn_chnl_lvl_1,
        sd2.source_acqn_chnl_lvl_2,
        CASE
                WHEN sd2.source_acqn_chnl_lvl_2 = ''Electronic''   THEN (
                    CASE
                        WHEN nvl(upper(sd2.signature_submission),'' '') = ''SECURITYQUESTION'' THEN ''Security Question''
                        ELSE ''Electronic''
                    END
                )
                WHEN sd2.source_acqn_chnl_lvl_2 = ''Mail''         THEN ''Traditional - Mail''
                WHEN sd2.source_acqn_chnl_lvl_2 = ''OLE''          THEN (
                    CASE
                        WHEN sd2.vendor_code IS NOT NULL THEN ''External Partners''
                        WHEN (
                            sd2.appl_actor_id = ''3''
                            AND sd2.contact_type_desc = ''WEB''
                            AND sd2.appl_mechanism_description = ''WEB''
                            AND nvl(upper(sd2.signature_submission),'' '') = ''SECURITYQUESTION''
                            AND sd2.vendor_code IS NULL
                        ) THEN ''Security Question''
                        ELSE ''Traditional - OLE''
                    END
                )
                WHEN sd2.source_acqn_chnl_lvl_2 = ''Phone''        THEN ''Optum CSS''
                ELSE ''Other''
            END
        AS source_acqn_chnl_lvl_3
    FROM
        (
            SELECT DISTINCT
                aa.application_id,
                a.appl_actor_id,
                aa.agent_id,
                am.appl_mechanism_description,
                ct.contact_type_desc,
                oad.phone_enrollment_type_id,
                oad.signature_submission,
                a.vendor_code,
                CASE
                        WHEN a.appl_actor_id = ''2''
                             AND ct.contact_type_desc = ''PHONE (IN)''
                             AND am.appl_mechanism_description = ''WEB''
                             AND nvl(oad.phone_enrollment_type_id,'' '') <> ''Y'' THEN ''Phone''
                        WHEN a.appl_actor_id = ''3''
                             AND ct.contact_type_desc = ''PHONE (IN)''
                             AND am.appl_mechanism_description = ''WEB'' THEN ''Electronic''
                        WHEN ct.contact_type_desc = ''WRITTEN MAIL''
                             AND am.appl_mechanism_description = ''MAIL'' THEN ''Mail''
                        WHEN (
                            (
                                a.appl_actor_id = ''1''
                                AND ct.contact_type_desc = ''WEB''
                                AND am.appl_mechanism_description = ''WEB''
                                AND a.vendor_code IS NULL
                                AND nvl(upper(oad.signature_submission),'' '') <> ''SECURITYQUESTION''
                            )
                            OR (
                                a.appl_actor_id = ''3''
                                AND ct.contact_type_desc = ''WEB''
                                AND am.appl_mechanism_description = ''WEB''
                            )
                        ) THEN ''OLE''
                        ELSE ''Other''
                    END
                AS source_acqn_chnl_lvl_2,
                ''DTC'' AS source_acqn_chnl_lvl_1
            FROM
                SRC_COMPAS_D.application_agent aa
 --               INNER JOIN	SRC_COMPAS_D.agent_char ac
--                ON aa.agent_id = ac.agent_id
                INNER JOIN SRC_COMPAS_D.agent_type atp ON aa.agent_type_id = atp.agent_type_id
                INNER JOIN SRC_COMPAS_D.application a ON a.application_id = aa.application_id
                INNER JOIN SRC_COMPAS_D.application_mechanism am ON am.application_mechanism_id = a.appl_mechanism_id
                INNER JOIN SRC_COMPAS_D.contact_hist_contact_type ct ON ct.contact_type_id = a.appl_channel_id
                LEFT OUTER JOIN (
                    SELECT
                        app.application_id,
                        MAX(dtl.phone_enrollment_type_id) phone_enrollment_type_id,
                        MAX(dtl.signature_submission) signature_submission
                    FROM
                        SRC_COMPAS_D.OLE_APPLICATION_DETAIL_ATTR dtl,
                        SRC_COMPAS_D.ole_application app
                    WHERE
                        dtl.ole_application_id = app.ole_application_id
                    GROUP BY
                        app.application_id
                ) oad ON a.application_id = oad.application_id
            WHERE
                atp.agent_type_desc = ''Referral Agent''
                AND aa.application_id NOT IN (
                    SELECT DISTINCT
                        aa.application_id
                    FROM
                        SRC_COMPAS_D.application_agent aa
                        INNER JOIN SRC_COMPAS_D.agent_char ac ON aa.agent_id = ac.agent_id
                        INNER JOIN SRC_COMPAS_D.agent_type atp ON aa.agent_type_id = atp.agent_type_id
                    WHERE
                        atp.agent_type_desc = ''Referral Agent''
                        AND ac.agent_char_type_id = ''4''
                )
                AND nvl(aa.agent_id,''NA'') = ''SOFTASI1''
        ) sd2 where sd2.application_id not in ( select applicationid from BDR_DM.wrk_sale_channel)
    UNION
    SELECT DISTINCT
        sd3.application_id,
        sd3.source_acqn_chnl_lvl_1,
        sd3.source_acqn_chnl_lvl_2,
        CASE
                WHEN sd3.source_acqn_chnl_lvl_2 = ''Electronic''   THEN (
                    CASE
                        WHEN nvl(upper(sd3.signature_submission),'' '') = ''SECURITYQUESTION'' THEN ''Security Question''
                        ELSE ''Electronic''
                    END
                )
                WHEN sd3.source_acqn_chnl_lvl_2 = ''Mail''         THEN ''Traditional - Mail''
                WHEN sd3.source_acqn_chnl_lvl_2 = ''OLE''          THEN (
                    CASE
                        WHEN sd3.vendor_code IS NOT NULL THEN ''External Partners''
                        WHEN (
                            sd3.appl_actor_id = ''3''
                            AND sd3.contact_type_desc = ''WEB''
                            AND sd3.appl_mechanism_description = ''WEB''
                            AND nvl(upper(sd3.signature_submission),'' '') = ''SECURITYQUESTION''
                            AND sd3.vendor_code IS NULL
                        ) THEN ''Security Question''
                        ELSE ''Traditional - OLE''
                    END
                )
                WHEN sd3.source_acqn_chnl_lvl_2 = ''Phone''        THEN ''Optum CSS''
                ELSE ''Other''
            END
        AS source_acqn_chnl_lvl_3
    FROM
        (
            SELECT DISTINCT
                ai.application_id,
                a.appl_actor_id,
                aa.agent_id,
                am.appl_mechanism_description,
                ct.contact_type_desc,
                oad.phone_enrollment_type_id,
                oad.signature_submission,
                a.vendor_code,
                CASE
                        WHEN a.appl_actor_id = ''2''
                             AND ct.contact_type_desc = ''PHONE (IN)''
                             AND am.appl_mechanism_description = ''WEB''
                             AND nvl(oad.phone_enrollment_type_id,'' '') <> ''Y'' THEN ''Phone''
                        WHEN a.appl_actor_id = ''3''
                             AND ct.contact_type_desc = ''PHONE (IN)''
                             AND am.appl_mechanism_description = ''WEB'' THEN ''Electronic''
                        WHEN ct.contact_type_desc = ''WRITTEN MAIL''
                             AND am.appl_mechanism_description = ''MAIL'' THEN ''Mail''
                        WHEN (
                            (
                                a.appl_actor_id = ''1''
                                AND ct.contact_type_desc = ''WEB''
                                AND am.appl_mechanism_description = ''WEB''
                                AND a.vendor_code IS NULL
                                AND nvl(upper(oad.signature_submission),'' '') <> ''SECURITYQUESTION''
                            )
                            OR (
                                a.appl_actor_id = ''3''
                                AND ct.contact_type_desc = ''WEB''
                                AND am.appl_mechanism_description = ''WEB''
                            )
                        ) THEN ''OLE''
                        ELSE ''Other''
                    END
                AS source_acqn_chnl_lvl_2,
                ''DTC'' AS source_acqn_chnl_lvl_1
            FROM
                SRC_COMPAS_D.application_indicator ai
                LEFT JOIN SRC_COMPAS_D.application a ON ai.application_id = a.application_id
                LEFT JOIN SRC_COMPAS_D.application_agent aa ON aa.application_id = a.application_id
                LEFT JOIN SRC_COMPAS_D.application_mechanism am ON am.application_mechanism_id = a.appl_mechanism_id
                LEFT JOIN SRC_COMPAS_D.contact_hist_contact_type ct ON ct.contact_type_id = a.appl_channel_id
                LEFT OUTER JOIN (
                    SELECT
                        app.application_id,
                        MAX(dtl.phone_enrollment_type_id) phone_enrollment_type_id,
                        MAX(dtl.signature_submission) signature_submission
                    FROM
                        SRC_COMPAS_D.OLE_APPLICATION_DETAIL_ATTR dtl,
                        SRC_COMPAS_D.ole_application app
                    WHERE
                        dtl.ole_application_id = app.ole_application_id
                    GROUP BY
                        app.application_id
                ) oad ON a.application_id = oad.application_id
            WHERE
                ai.signature_ind = ''Y''
                AND aa.agent_id IS NULL
        ) sd3 where sd3.application_id not in ( select applicationid from BDR_DM.wrk_sale_channel)
     UNION
     SELECT DISTINCT

                   SD4.APPLICATION_ID,
                   SD4.SOURCE_ACQN_CHNL_LVL_1,
                   SD4.SOURCE_ACQN_CHNL_LVL_2,
                   CASE
                       WHEN SD4.SOURCE_ACQN_CHNL_LVL_2 = ''Electronic''
                       THEN
                           (CASE
                                WHEN NVL (UPPER (SD4.SIGNATURE_SUBMISSION),
                                          '' '') =
                                     ''SECURITYQUESTION''
                                THEN
                                    ''Security Question''
                                ELSE
                                    ''Electronic''
                            END)
                       WHEN SD4.SOURCE_ACQN_CHNL_LVL_2 = ''Mail''
                       THEN
                           ''Traditional - Mail''
                       WHEN SD4.SOURCE_ACQN_CHNL_LVL_2 = ''OLE''
                       THEN
                           (CASE
                                WHEN SD4.VENDOR_CODE IS NOT NULL
                                THEN
                                    ''External Partners''
                                WHEN (    SD4.APPL_ACTOR_ID = ''3''
                                      AND SD4.CONTACT_TYPE_DESC = ''WEB''
                                      AND SD4.APPL_MECHANISM_DESCRIPTION =
                                          ''WEB''
                                      AND NVL (
                                              UPPER (
                                                  SD4.SIGNATURE_SUBMISSION),
                                              '' '') =
                                          ''SECURITYQUESTION''
                                      AND SD4.VENDOR_CODE IS NULL)
                                THEN
                                    ''Security Question''
                                ELSE
                                    ''Traditional - OLE''
                            END)
                       WHEN SD4.SOURCE_ACQN_CHNL_LVL_2 = ''Phone''
                       THEN
                           ''Optum CSS''
                       ELSE
                           ''Other''
                   END    AS SOURCE_ACQN_CHNL_LVL_3
              FROM (SELECT DISTINCT
                           ai.application_id,
                           a.appl_actor_id,
                           aa.agent_id,
                           am.APPL_MECHANISM_DESCRIPTION,
                           ct.CONTACT_TYPE_DESC,
                           OAD.PHONE_ENROLLMENT_TYPE_ID,
                           OAD.SIGNATURE_SUBMISSION,
                           a.VENDOR_CODE,
                           CASE
                               WHEN     a.APPL_ACTOR_ID = ''2''
                                    AND ct.CONTACT_TYPE_DESC = ''PHONE (IN)''
                                    AND am.APPL_MECHANISM_DESCRIPTION = ''WEB''
                                    AND NVL (OAD.PHONE_ENROLLMENT_TYPE_ID,
                                             '' '') <>
                                        ''Y''
                               THEN
                                   ''Phone''
                               WHEN     a.APPL_ACTOR_ID = ''3''
                                    AND ct.CONTACT_TYPE_DESC = ''PHONE (IN)''
                                    AND am.APPL_MECHANISM_DESCRIPTION = ''WEB''
                               THEN
                                   ''Electronic''
                               WHEN     ct.CONTACT_TYPE_DESC = ''WRITTEN MAIL''
                                    AND am.APPL_MECHANISM_DESCRIPTION =
                                        ''MAIL''
                               THEN
                                   ''Mail''
                               WHEN (   (    a.APPL_ACTOR_ID = ''1''
                                         AND ct.CONTACT_TYPE_DESC = ''WEB''
                                         AND am.APPL_MECHANISM_DESCRIPTION =
                                             ''WEB''
                                         AND a.VENDOR_CODE IS NULL
                                         AND NVL (
                                                 UPPER (
                                                     OAD.SIGNATURE_SUBMISSION),
                                                 '' '') <>
                                             ''SECURITYQUESTION'')
                                     OR (    a.APPL_ACTOR_ID = ''3''
                                         AND ct.CONTACT_TYPE_DESC = ''WEB''
                                         AND am.APPL_MECHANISM_DESCRIPTION =
                                             ''WEB''))
                               THEN
                                   ''OLE''
                               ELSE
                                   ''Other''
                           END      AS SOURCE_ACQN_CHNL_LVL_2,
                           ''DTC''    AS SOURCE_ACQN_CHNL_LVL_1
                      FROM SRC_COMPAS_D.Application_Indicator  AI
                           INNER JOIN SRC_COMPAS_D.application a
                               ON ai.application_id = a.application_id
                            LEFT JOIN SRC_COMPAS_D.application_agent aa
                               ON aa.application_id = a.application_id
                           LEFT JOIN SRC_COMPAS_D.APPLICATION_MECHANISM am
                               ON am.APPLICATION_MECHANISM_ID =
                                  a.APPL_MECHANISM_ID
                           LEFT JOIN SRC_COMPAS_D.CONTACT_HIST_CONTACT_TYPE ct
                               ON ct.CONTACT_TYPE_ID = a.APPL_CHANNEL_ID
                           LEFT OUTER JOIN
                           (  SELECT app.APPLICATION_ID,
                                     MAX (dtl.PHONE_ENROLLMENT_TYPE_ID)
                                         PHONE_ENROLLMENT_TYPE_ID,
                                     MAX (dtl.SIGNATURE_SUBMISSION)
                                         SIGNATURE_SUBMISSION
                                FROM SRC_COMPAS_D.OLE_APPLICATION_DETAIL_ATTR dtl,
                                     SRC_COMPAS_D.OLE_APPLICATION       app
                               WHERE dtl.OLE_APPLICATION_ID =
                                     app.OLE_APPLICATION_ID
                            GROUP BY app.APPLICATION_ID) OAD
                               ON A.APPLICATION_ID = OAD.APPLICATION_ID
                     WHERE (   (aa.agent_id IN
                                    (SELECT agent_id
                                       FROM BDR_DM.acqn_chnl_agt_lst
                                      WHERE     AGENT_TYPE = ''Referral Agent''
                                            AND channel_type =
                                                ''DTC''))
                            OR (aa.agent_id IN
                                    (SELECT agent_id
                                       FROM BDR_DM.acqn_chnl_agt_lst
                                      WHERE     AGENT_TYPE = ''Selling Agent''
                                            AND channel_type =
                                                ''DTC'')))) SD4
    )
    source ON ( target.applicationid = source.application_id )
    WHEN MATCHED THEN UPDATE SET sale_channel_level_1 = source_acqn_chnl_lvl_1,
                                 sale_channel_level_2 = source_acqn_chnl_lvl_2,
                                 sale_channel_level_3 = source_acqn_chnl_lvl_3
    WHEN NOT MATCHED THEN INSERT (
        applicationid,
        sale_channel_level_1,
        sale_channel_level_2,
        sale_channel_level_3 ) VALUES (
        source.application_id,
        source.source_acqn_chnl_lvl_1,
        source.source_acqn_chnl_lvl_2,
        source.source_acqn_chnl_lvl_3 );


V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

V_ROWS_UPDATED := (SELECT $2 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );	

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );	
	
---Commented by OAS JNIKAM	 
/*	
    v_rows_afftd := SQL%rowcount;
    INSERT INTO etl.etl_detail_load_info (
        application,
        etl_batch_id,
        etl_proc_name,
        action,
        step_info,
        rows_affected,
        etl_datetime
    ) VALUES (
        ''CONFORMED_DIMENSIONS'',
        v_btch_id,
        v_proc_name,
        ''MERGE'',
        ''MERGE/INSERT DTC INTO WRK_SALE_CHANNEL '',
        v_rows_afftd,
        systimestamp
    );
   --Returns the result set
*/
---Commented by OAS JNIKAM


   ------smart dtc------
	
V_STEP_NAME    := ''TARGET - MERGE wrk_sale_channel'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

    MERGE INTO BDR_DM.wrk_sale_channel target
         USING (SELECT DISTINCT SIP.Application_ID,
                                ''DTC''       SOURCE_ACQN_CHNL_LVL_1,
                                ''Other''     SOURCE_ACQN_CHNL_LVL_2,
                                ''Other''     SOURCE_ACQN_CHNL_LVL_3
                  FROM SRC_COMPAS_D.INSURED_PLAN  IP
                       LEFT JOIN SRC_COMPAS_D.APPLICATION A
                           ON A.APPLICATION_ID = IP.Application_ID
                       INNER JOIN BDR_SMART.INSURED_PLAN SIP
                           ON IP.INSURED_PLAN_ID = SIP.Source_INSURED_PLAN_ID
                       JOIN BDR_Smart.APPLICATION_REPORTING SAR
                           ON SIP.Application_ID = SAR.Application_ID
                 WHERE     A.APPLICATION_ID IS NULL
                       AND (   (    marketing_channel = ''DIRECT-TO-CONSUMER''
                                AND campaign_type = ''DIRECT'')
                            OR (    marketing_channel = ''DIRECT-TO-CONSUMER''
                                AND campaign_type = ''ADVERTISING/INQUIRY'')
                            OR (    marketing_channel = ''DIRECT-TO-CONSUMER''
                                AND (TRIM (campaign_type) = '''' OR TRIM (campaign_type) IS NULL )      )
                            OR marketing_channel IN
                                   (''UNKNOWN - PHONE ENROLLMENT KEYCODE'',
                                    ''UNKNOWN - WEB ENROLLMENT KEYCODE'',
                                    ''UNKNOWN - INVALID KEYCODE'',
                                    ''UNKNOWN - SYSTEM GENERATED KEYCODE'',
                                    ''UNKNOWN - AGENT ENROLLMENT KEYCODE'',
                                    ''UNKNOWN OTHER'',
                                    ''AGENT - NON AGGREGATOR'',
                                    ''AGENT'',
                                    ''AGENT/EMPLOYER'',
                                    ''AGENT - DESTINATIONRX'',
                                    ''AGENT - EHEALTH'',
                                    ''AGENT - EXTEND_HEALTH'',
                                    ''AGENT - INSURACTIVE'',
                                    ''AGENT - MERCER'',
                                    ''AGENT - MYCUSTOM_HEALTH'',
                                    ''AGENT - SELECTQUOTE_SENIOR'',
                                    ''AGENT - SENIOR_EDUCATORS'',
                                    ''AGENT - SENIOR_MARKET_SALES_(SMS)'',
                                    ''AGENT - TRANZACT'',
                                    ''AGENT/EMPLOYER'',
                                    ''EMPLOYER'',
                                    ''AGENT - DESTINATIONRX'',
                                    ''AGENT - EHEALTH'',
                                    ''AGENT - EXTEND_HEALTH'',
                                    ''AGENT - INSURACTIVE'',
                                    ''AGENT - MERCER'',
                                    ''AGENT - MYCUSTOM_HEALTH'',
                                    ''AGENT - SELECTQUOTE_SENIOR'',
                                    ''AGENT - SENIOR_EDUCATORS'',
                                    ''AGENT - SENIOR_MARKET_SALES_(SMS)'',
                                    ''AGENT - TRANZACT''))) source
            ON (target.applicationid = source.application_id)
    WHEN MATCHED
    THEN
        UPDATE SET
            sale_channel_level_1 = source_acqn_chnl_lvl_1,
            sale_channel_level_2 = source_acqn_chnl_lvl_2,
            sale_channel_level_3 = source_acqn_chnl_lvl_3
    WHEN NOT MATCHED
    THEN
        INSERT     (applicationid,
                    sale_channel_level_1,
                    sale_channel_level_2,
                    sale_channel_level_3)
            VALUES (source.application_id,
                    source.source_acqn_chnl_lvl_1,
                    source.source_acqn_chnl_lvl_2,
                    source.source_acqn_chnl_lvl_3);
    	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

V_ROWS_UPDATED := (SELECT $2 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );	

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );	

---------------COMMENTED BY OAS-----------------
/*
    COMMIT;
    v_rows_afftd := SQL%ROWCOUNT;

    INSERT INTO etl.etl_detail_load_info (application,
                                          etl_batch_id,
                                          etl_proc_name,
                                          action,
                                          step_info,
                                          rows_affected,
                                          etl_datetime)
         VALUES (''CONFORMED_DIMENSIONS'',
                 v_btch_id,
                 v_proc_name,
                 ''MERGE'',
                 ''MERGE/INSERT SMART DTC INTO WRK_SALE_CHANNEL '',
                 v_rows_afftd,
                 SYSTIMESTAMP);

    COMMIT;
    BDR_DM.pkg_db_util.sp_gather_table_stats (''DM'', ''WRK_SALE_CHANNEL'');

    p_tocontinuestatus := ''Y'';
    p_errorynflg := ''N'';
    p_errorstr := '';
    INSERT INTO etl.etl_detail_load_info (
        application,
        etl_batch_id,
        etl_proc_name,
        action,
        step_info,
        rows_affected,
        etl_datetime
    ) VALUES (
        ''CONFORMED_DIMENSIONS'',
        v_btch_id,
        v_proc_name,
        ''END'',
        ''PROCEDURE ENDS '',
        v_rows_afftd,
        systimestamp
    );


EXCEPTION
    WHEN OTHERS THEN
        p_errorstr := ''ERROR: ''
                      || sqlcode
                      || ''-''
                      || sqlerrm
                      || ''-''
                      || dbms_utility.format_error_backtrace ()
                      || chr(10)
                      || dbms_utility.format_error_stack ();

        p_tocontinuestatus := ''N'';
        p_errorynflg := ''Y'';
        ROLLBACK;
END;
/
*/
---Commented by OAS JNIKAM	


CALL UTIL.SP_ETL_CHECK_CONSTRAINTS(:DB_NAME , :APPLICATION , :WORKFLOW_NAME , :OBJECT_NAME , :V_BATCH_ID );
		
UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''COMPLETE'', ERROR_MSG = null, BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
; 


UPDATE  UTIL.ETL_BATCH_OBJECT_INCR_VALU SET INCR_COLUMN_VALUE = :V_BATCH_ID, LST_MOD_DT = CURRENT_TIMESTAMP() WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID''; 

EXCEPTION

WHEN OTHER THEN


UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''ERROR'', ERROR_MSG = :SQLERRM,  BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
;



INSERT INTO  UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ERROR_MSG, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''ERROR'', :V_STEP_NAME, :V_STEP_SEQ, :SQLERRM, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() )
;



RAISE;
    
		
		
END;

';