
USE SCHEMA BDR_CONF;

CREATE OR REPLACE PROCEDURE SP_OPERATIONALREPORTING_LOAD_HOLIDAYCALENDAR_A("DB_NAME" VARCHAR(16777216), "APPLICATION" VARCHAR(16777216), "WORKFLOW_NAME" VARCHAR(16777216), "OBJECT_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '

-- Original workflow: wkf_OperationalReporting_IU_UHGHolidayCalendar_A
-- Original mapping: m_OperationalReporting_Load_HolidayCalendar_A
-- Original folder: Operational_Reporting
-- Original filename: wkf_OperationalReporting_IU_UHGHolidayCalendar_A.XML

DECLARE


V_ROWS_INSERTED  INTEGER;
V_ROWS_UPDATED INTEGER;
V_ROWS_DELETED INTEGER;
V_LAST_QUERY_ID VARCHAR;

V_WH VARCHAR;
V_BATCH_ID INTEGER;


V_BATCH_OBJECT_START_TIME        VARCHAR;
V_STEP_START_TIME    VARCHAR;
V_STEP_NAME VARCHAR;
V_STEP_SEQ INTEGER DEFAULT 0;
V_ETL_LST_BTCH_ID INTEGER;


BEGIN

EXECUTE IMMEDIATE ''USE DATABASE ''||:DB_NAME; 

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_BATCH_OBJECT_START_TIME := (SELECT CURRENT_TIMESTAMP());



LET res1 RESULTSET := 
(

SELECT 

WH ,
BATCH_ID
  
FROM UTIL.ETL_BATCH_OBJECT_CONTROL
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
FETCH FIRST 1 ROW ONLY

)
;


LET C1 CURSOR FOR res1;
open C1;
FETCH C1 into  V_WH,V_BATCH_ID ;
close C1;





EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:V_WH;
USE SCHEMA BDR_CONF;


INSERT INTO UTIL.ETL_BATCH_OBJECT_INCR_VALU (APPLICATION, WORKFLOW_NAME, OBJECT_NAME, INCR_COLUMN, INCR_COLUMN_VALUE )
SELECT * FROM (select :APPLICATION AS APPLICATION, :WORKFLOW_NAME AS WORKFLOW_NAME, :OBJECT_NAME AS OBJECT_NAME, ''ETL_LST_BTCH_ID'' AS INCR_COLUMN, -1 AS INCR_COLUMN_VALUE) A
WHERE NOT EXISTS (SELECT 1 FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU B WHERE B.APPLICATION = A.APPLICATION AND B.WORKFLOW_NAME = A.WORKFLOW_NAME AND B.OBJECT_NAME = A.OBJECT_NAME AND B.INCR_COLUMN = A.INCR_COLUMN)
;

V_ETL_LST_BTCH_ID :=(SELECT INCR_COLUMN_VALUE FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID'');


-- Component LKP_D_CAL_DT, Type Prerequisite Lookup Object 
CREATE OR REPLACE TEMPORARY TABLE LKP_D_CAL_DT AS
(
SELECT D_CAL_DT_ID AS D_CAL_DT_ID,TO_CHAR(TRUNC(DT_VAL, ''DD''),''YYYY-MM-DD'') as DT_VAL FROM BDR_CONF.D_CAL_DT
);


--pre node line TARGET for sc_D_CAL_DT
V_STEP_NAME    := ''TARGET - UPDATE D_CAL_DT'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

------------OAS ADD------------
-- Component sq_sc_UHG_Holidays_SRC, Type IMPORT_DATA Importing Data
CREATE OR REPLACE TEMPORARY TABLE sq_sc_UHG_Holidays AS
(
SELECT SRC.*, row_number() over (order by 1) AS source_record_id FROM (
	SELECT $1 AS HOLIDAY_DATE, $2 AS HOLIDAY_DESC
	FROM ''@UTIL.STAGE_AZURE_ISDC/data_ingestion/files/fileetl/'' (file_format => ''UTIL.FF_ISDC_FILE_LOAD_COMMA_CSV_HEADERLESS'', 
	pattern=>''(?i).*/UHG_Holidays([_0-9]+)?\\.csv'') t
) SRC
); 
------------OAS ADD------------


-- Component fil_incomingData, Type FILTER 
CREATE OR REPLACE TEMPORARY TABLE fil_incomingData AS
(
SELECT
sq_sc_UHG_Holidays.HOLIDAY_DATE as HOLIDAY_DATE,
sq_sc_UHG_Holidays.HOLIDAY_DESC as HOLIDAY_DESC,
sq_sc_UHG_Holidays.source_record_id	
FROM
sq_sc_UHG_Holidays
WHERE sq_sc_UHG_Holidays.HOLIDAY_DATE IS NOT NULL AND (TRY_TO_DATE ( sq_sc_UHG_Holidays.HOLIDAY_DATE , ''MM/DD/YYYY'' ) IS NOT NULL)
);


-- Component exp_passthrough, Type EXPRESSION 
CREATE OR REPLACE TEMPORARY TABLE exp_passthrough AS
(
SELECT
TO_CHAR ( TO_TIMESTAMP(fil_incomingData.HOLIDAY_DATE, ''MM/DD/YYYY'') , ''YYYY-MM-DD'' ) as HOLIDAY_DATE,
fil_incomingData.HOLIDAY_DESC as HOLIDAY_DESC,
fil_incomingData.source_record_id	
FROM
fil_incomingData
);


-- Component LKP_D_UHG_HOL_CAL_DT, Type LOOKUP 
CREATE OR REPLACE TEMPORARY TABLE LKP_D_UHG_HOL_CAL_DT AS
(
SELECT
LKP.UHG_HOL_DT_VAL,
exp_passthrough.HOLIDAY_DATE as HOLIDAY_DATE,
exp_passthrough.HOLIDAY_DESC as HOLIDAY_DESC,
exp_passthrough.source_record_id,
ROW_NUMBER() OVER(PARTITION BY exp_passthrough.source_record_id ORDER BY LKP.UHG_HOL_DT_VAL asc) RNK
FROM
exp_passthrough
LEFT JOIN (
SELECT TO_CHAR(UHG_HOL_DT_VAL,''YYYY-MM-DD'') as UHG_HOL_DT_VAL FROM BDR_CONF.D_UHG_HOL_CAL_DT
) LKP ON LKP.UHG_HOL_DT_VAL = exp_passthrough.HOLIDAY_DATE
QUALIFY ROW_NUMBER() OVER(PARTITION BY exp_passthrough.source_record_id ORDER BY LKP.UHG_HOL_DT_VAL asc) = 1
);


-- Component exp_date_calc, Type EXPRESSION 
CREATE OR REPLACE TEMPORARY TABLE exp_date_calc AS
(
SELECT
TO_TIMESTAMP(LKP_D_UHG_HOL_CAL_DT.HOLIDAY_DATE, ''YYYY-MM-DD'') as HOLIDAY_DATE,
LKP_D_UHG_HOL_CAL_DT.HOLIDAY_DESC as HOLIDAY_DESC,
LKP_1.D_CAL_DT_ID /* replaced lookup LKP_D_CAL_DT */ as v_D_CAL_DT_ID,
IFF(v_D_CAL_DT_ID IS NULL, - 1, v_D_CAL_DT_ID) as D_CAL_DT_ID,
''N'' as BUS_DAY_FLG,
IFF(LKP_D_UHG_HOL_CAL_DT.UHG_HOL_DT_VAL IS NULL OR LKP_D_UHG_HOL_CAL_DT.UHG_HOL_DT_VAL <> LKP_D_UHG_HOL_CAL_DT.HOLIDAY_DATE, ''I'', ''S'') as TGT_ACTION,
LKP_D_UHG_HOL_CAL_DT.source_record_id,
row_number() over (partition by LKP_D_UHG_HOL_CAL_DT.source_record_id order by LKP_D_UHG_HOL_CAL_DT.source_record_id) as RNK
FROM
LKP_D_UHG_HOL_CAL_DT
LEFT JOIN LKP_D_CAL_DT LKP_1 ON LKP_1.DT_VAL = LKP_D_UHG_HOL_CAL_DT.HOLIDAY_DATE
QUALIFY row_number() over (partition by LKP_D_UHG_HOL_CAL_DT.source_record_id order by LKP_D_UHG_HOL_CAL_DT.source_record_id) = 1
);


-- Component updt_bus_flg, Type UPDATE 
CREATE OR REPLACE TEMPORARY TABLE updt_bus_flg AS
(
/* UPDATE_STRATEGY_ACTION = 0 FOR INSERT / UPDATE_STRATEGY_ACTION = 1 FOR UPDATE / UPDATE_STRATEGY_ACTION = 2 FOR DELETE / UPDATE_STRATEGY_ACTION = 3 FOR REJECT */
SELECT
exp_date_calc.D_CAL_DT_ID as D_CAL_DT_ID,
exp_date_calc.BUS_DAY_FLG as BUS_DAY_FLG,
1 as UPDATE_STRATEGY_ACTION
FROM
exp_date_calc
);


-- Component sc_D_CAL_DT, Type TARGET 
/* Perform Updates */
UPDATE BDR_CONF.D_CAL_DT
SET
BUS_DAY_FLG = updt_bus_flg.BUS_DAY_FLG
FROM updt_bus_flg
WHERE updt_bus_flg.UPDATE_STRATEGY_ACTION = 1 AND D_CAL_DT.D_CAL_DT_ID = updt_bus_flg.D_CAL_DT_ID
;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );


--pre node line TARGET for D_UHG_HOL_CAL_DT_insert
V_STEP_NAME    := ''TARGET - INSERT D_UHG_HOL_CAL_DT'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

-- Component fil_Target, Type FILTER 
CREATE OR REPLACE TEMPORARY TABLE fil_Target AS
(
SELECT
exp_date_calc.HOLIDAY_DATE as HOLIDAY_DATE,
exp_date_calc.HOLIDAY_DESC as HOLIDAY_DESC,
exp_date_calc.D_CAL_DT_ID as D_CAL_DT_ID,
exp_date_calc.TGT_ACTION as TGT_ACTION,
exp_date_calc.source_record_id
FROM
exp_date_calc
WHERE exp_date_calc.TGT_ACTION = ''I''
);


-- Component D_UHG_HOL_CAL_DT_insert, Type TARGET 
INSERT INTO BDR_CONF.D_UHG_HOL_CAL_DT
(
UHG_HOL_DT_VAL,
HOL_DESC,
D_CAL_DT_ID
)
SELECT
fil_Target.HOLIDAY_DATE /* UHG_HOL_DT_VAL */,
fil_Target.HOLIDAY_DESC /* HOL_DESC */,
fil_Target.D_CAL_DT_ID /* D_CAL_DT_ID */
FROM
fil_Target;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );



--post node line Post SQL for D_UHG_HOL_CAL_DT_insert
V_STEP_NAME    := ''Post_SQL - MERGE ETL_CLM_PD_DT_XREF'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

-- Component D_UHG_HOL_CAL_DT_insert, Type Post SQL 
MERGE INTO BDR_DM.ETL_CLM_PD_DT_XREF TGT
USING
(
WITH corp_holidays
     AS (SELECT UHG_HOL_DT_VAL,
                DAYOFWEEK(UHG_HOL_DT_VAL)+1 AS day_num_of_week,
                DECODE(TO_CHAR (UHG_HOL_DT_VAL, ''Dy''), ''Mon'', ''Monday'', ''Tue'', ''Tuesday'', ''Wed'', ''Wednesday'', ''Thu'', ''Thursday'', ''Fri'', ''Friday'', ''Sat'', ''Saturday'', ''Sun'', ''Sunday'') AS day_of_week,
                CASE
                   WHEN DAYOFWEEK(UHG_HOL_DT_VAL)+1 IN (''2'', ''3'', ''4'')
                   THEN
                      1
                   WHEN DAYOFWEEK(UHG_HOL_DT_VAL)+1 = ''5''
                   THEN
                      3
                   ELSE
                      0
                END
                   AS days_to_add_to_pd_dt,
                HOL_DESC,
                D_CAL_DT_ID
           FROM BDR_CONF.D_UHG_HOL_CAL_DT),
     INIT_CMPL_DT_TO_CLM_PD_DT_MAP
     AS (SELECT A.D_CAL_DT_ID AS cmpl_dt_id,
                A.DT_VAL AS CMPL_DT,
                DAYOFWEEK(A.DT_VAL)+1 AS day_num_of_week,
                DECODE(TO_CHAR (A.DT_VAL, ''Dy''), ''Mon'', ''Monday'', ''Tue'', ''Tuesday'', ''Wed'', ''Wednesday'', ''Thu'', ''Thursday'', ''Fri'', ''Friday'', ''Sat'', ''Saturday'', ''Sun'', ''Sunday'') AS day_of_week,
                TO_NUMBER (
                   CASE
                      WHEN DAYOFWEEK(A.DT_VAL)+1 IN (''2'',
                                                       ''3'',
                                                       ''4'',
                                                       ''5'')
                      THEN
                         TO_CHAR (
                            DATEADD(''DD'', (1 + NVL (q1.days_to_add_to_pd_dt, 0)), A.DT_VAL), 
                            ''YYYYMMDD'')
                      WHEN DAYOFWEEK(A.DT_VAL)+1 IN (''1'', ''7'')
                      THEN
                         TO_CHAR (
                            DATEADD(''DD'', (2 + NVL (q1.days_to_add_to_pd_dt, 0)), A.DT_VAL),
                            ''YYYYMMDD'')
                      WHEN DAYOFWEEK(A.DT_VAL)+1 = ''6''
                      THEN
                         TO_CHAR (
                           DATEADD(''DD'', (3 + NVL (q1.days_to_add_to_pd_dt, 0)), A.DT_VAL),
                            ''YYYYMMDD'')
                      ELSE
                         ''-1''
                   END)
                   AS CLM_PD_DT_ID,
                TO_TIMESTAMP(CASE
WHEN DAYOFWEEK(A.DT_VAL)+1 IN (''2'',
''3'',
''4'',
''5'')
THEN
TO_CHAR (
DATEADD(''DD'', (1 + NVL (q1.days_to_add_to_pd_dt, 0)), A.DT_VAL) ,
''YYYYMMDD'')
WHEN DAYOFWEEK(A.DT_VAL)+1 IN (''1'', ''7'')
THEN
TO_CHAR (
DATEADD(''DD'', (2 + NVL (q1.days_to_add_to_pd_dt, 0)), A.DT_VAL) ,
''YYYYMMDD'')
WHEN DAYOFWEEK(A.DT_VAL)+1 = ''6''
THEN
TO_CHAR (
DATEADD(''DD'', (3 + NVL (q1.days_to_add_to_pd_dt, 0)), A.DT_VAL),
''YYYYMMDD'')
ELSE
''-1''
END, ''YYYYMMDD'')
                   AS CLM_PD_DT,
                DAYOFWEEK(
                   TO_TIMESTAMP(CASE
WHEN DAYOFWEEK(A.DT_VAL)+1 IN (''2'',
''3'',
''4'',
''5'')
THEN
TO_CHAR (
DATEADD(''DD'', (1 + NVL (q1.days_to_add_to_pd_dt, 0)), A.DT_VAL) ,
''YYYYMMDD'')
WHEN DAYOFWEEK(A.DT_VAL)+1 IN (''1'', ''7'')
THEN
TO_CHAR (
DATEADD(''DD'', (2 + NVL (q1.days_to_add_to_pd_dt, 0)), A.DT_VAL) ,
''YYYYMMDD'')
WHEN DAYOFWEEK(A.DT_VAL)+1 = ''6''
THEN
TO_CHAR (
DATEADD(''DD'', (3 + NVL (q1.days_to_add_to_pd_dt, 0)), A.DT_VAL) ,
''YYYYMMDD'')
ELSE
''-1''
END, ''YYYYMMDD''))+1
                   AS DAY_NUM_OF_WEEK2,
                DECODE(TO_CHAR (
                   TO_TIMESTAMP(CASE
WHEN DAYOFWEEK(A.DT_VAL)+1 IN (''2'',
''3'',
''4'',
''5'')
THEN
TO_CHAR (
DATEADD(''DD'', (1 + NVL (q1.days_to_add_to_pd_dt, 0)), A.DT_VAL) ,
''YYYYMMDD'')
WHEN DAYOFWEEK(A.DT_VAL)+1 IN (''1'', ''7'')
THEN
TO_CHAR (
DATEADD(''DD'', (2 + NVL (q1.days_to_add_to_pd_dt, 0)), A.DT_VAL) ,
''YYYYMMDD'')
WHEN DAYOFWEEK(A.DT_VAL)+1 = ''6''
THEN
TO_CHAR (
DATEADD(''DD'', (3 + NVL (q1.days_to_add_to_pd_dt, 0)), A.DT_VAL) ,
''YYYYMMDD'')
ELSE
''-1''
END, ''YYYYMMDD''),
                   ''Dy''), ''Mon'', ''Monday'', ''Tue'', ''Tuesday'', ''Wed'', ''Wednesday'', ''Thu'', ''Thursday'', ''Fri'', ''Friday'', ''Sat'', ''Saturday'', ''Sun'', ''Sunday'')
                   AS DAY_OF_WEEK2,
                q1.days_to_add_to_pd_dt
           FROM BDR_CONF.D_CAL_DT a
                LEFT OUTER JOIN corp_holidays q1
                   ON A.DT_VAL = Q1.UHG_HOL_DT_VAL
          WHERE A.DT_VAL BETWEEN (select MIN(UHG_HOL_DT_VAL) from BDR_CONF.D_UHG_HOL_CAL_DT) AND (select MAX(UHG_HOL_DT_VAL) from BDR_CONF.D_UHG_HOL_CAL_DT))
  SELECT distinct a.cmpl_dt_id,
         --a.CMPL_DT,
         --a.day_num_of_week,
         a.day_of_week,
         CASE
            WHEN     day_num_of_week2 = ''3''
                 AND a.day_num_of_week = ''1''
                 AND b.UHG_HOL_DT_VAL IS NOT NULL
            THEN
               TO_NUMBER (TO_CHAR (DATEADD(''DD'', 1, A.CLM_PD_DT ), ''YYYYMMDD''))
            ELSE
               a.clm_pd_dt_id
         END
            AS clm_pd_dt_id,
--         CASE
--            WHEN     day_num_of_week2 = ''3''
--                 AND a.day_num_of_week = ''1''
--                 AND b.UHG_HOL_DT_VAL IS NOT NULL
--            THEN
--               A.CLM_PD_DT + 1
--            ELSE
--               a.clm_pd_dt
--         END
--            AS clm_pd_dt,
--         CASE
--            WHEN     day_num_of_week2 = ''3''
--                 AND a.day_num_of_week = ''1''
--                 AND b.UHG_HOL_DT_VAL IS NOT NULL
--            THEN
--               TO_CHAR (A.CLM_PD_DT + 1, ''D'')
--            ELSE
--               a.DAY_NUM_OF_WEEK2
--         END
--            AS DAY_NUM_OF_WEEK2,
         CASE
            WHEN     day_num_of_week2 = ''3''
                 AND a.day_num_of_week = ''1''
                 AND b.UHG_HOL_DT_VAL IS NOT NULL
            THEN
               DECODE(TO_CHAR (DATEADD(''DD'', 1, A.CLM_PD_DT), ''Dy''), ''Mon'', ''Monday'', ''Tue'', ''Tuesday'', ''Wed'', ''Wednesday'', ''Thu'', ''Thursday'', ''Fri'', ''Friday'', ''Sat'', ''Saturday'', ''Sun'', ''Sunday'')
            ELSE
               a.DAY_OF_WEEK2
         END
            AS DAY_OF_WEEK2
--         NVL (a.days_to_add_to_pd_dt, 0) AS days_to_add_to_pd_dt,
--         b.UHG_HOL_DT_VAL
    FROM INIT_CMPL_DT_TO_CLM_PD_DT_MAP a
         LEFT OUTER JOIN corp_holidays b
            ON     DATEADD(''DD'', -1, A.CLM_PD_DT) = b.UHG_HOL_DT_VAL
               AND a.day_num_of_week2 = ''3''
               AND a.day_num_of_week = ''1''
        ORDER BY 1
) SRC
ON (SRC.CMPL_DT_ID = TGT.CMPL_DT_ID)
WHEN NOT MATCHED THEN INSERT (CMPL_DT_ID, CMPL_DAY_OF_WK_TXT,CLM_PD_DT_ID,PD_DAY_OF_WK_TXT) VALUES (SRC.CMPL_DT_ID,SRC.DAY_OF_WEEK,SRC.CLM_PD_DT_ID,SRC.DAY_OF_WEEK2);
--commit;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );


CALL UTIL.SP_ETL_CHECK_CONSTRAINTS(:DB_NAME , :APPLICATION , :WORKFLOW_NAME , :OBJECT_NAME , :V_BATCH_ID );		---------OAS ADD


UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''COMPLETE'', ERROR_MSG = null, BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
;
UPDATE  UTIL.ETL_BATCH_OBJECT_INCR_VALU SET INCR_COLUMN_VALUE = :V_BATCH_ID, LST_MOD_DT = CURRENT_TIMESTAMP() 
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID''
;

EXCEPTION

WHEN OTHER THEN

UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''ERROR'', ERROR_MSG = :SQLERRM,  BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
;

INSERT INTO  UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ERROR_MSG, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''ERROR'', :V_STEP_NAME, :V_STEP_SEQ, :SQLERRM, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() )
;



RAISE;

END;

';