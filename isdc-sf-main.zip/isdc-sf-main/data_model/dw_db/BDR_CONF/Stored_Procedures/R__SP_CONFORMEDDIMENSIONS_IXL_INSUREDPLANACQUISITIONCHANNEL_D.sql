USE SCHEMA BDR_CONF; CREATE OR REPLACE PROCEDURE "SP_CONFORMEDDIMENSIONS_IXL_INSUREDPLANACQUISITIONCHANNEL_D"("DB_NAME" VARCHAR(16777216), "APPLICATION" VARCHAR(16777216), "WORKFLOW_NAME" VARCHAR(16777216), "OBJECT_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '

-- Original workflow: wkf_ConformedDimensions_IU_TargetLoad_D
-- Original mapping: m_ConformedDimensions_IXL_InsuredPlanAcquisitionChannel_D


DECLARE
---Commented by OAS JNIKAM
/*


CREATE OR REPLACE PROCEDURE BDR_DM.SP_CONFDIM_INSPLANAQSTNCHNL_D (
   p_RecordExists   IN NUMBER,
   P_ToContinueStatus  OUT VARCHAR2,
   P_ErrorYNFlg OUT VARCHAR2,
   P_ErrorStr   OUT VARCHAR2)
AS
V_PROC_NAME         VARCHAR(50):=''''''''SP_CONFDIM_INSPLANAQSTNCHNL_D'''''''';
V_ROWS_AFFTD        NUMBER(20) :=0;
V_BTCH_ID           NUMBER(10);
BEGIN

SELECT MAX(BATCH_ID) INTO V_BTCH_ID FROM ETL.ETL_BATCH_LOG WHERE APPLICATION=''''''''CDC'''''''' AND BATCH_STATUS=''''''''COMPLETE'''''''';

 INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''''''''CONFORMED_DIMENSIONS'''''''',
      V_BTCH_ID,
      V_PROC_NAME,
      ''''''''START'''''''',
      ''''''''PROCEDURE STARTS'''''''',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );
*/

---Commented by OAS JNIKAM	 
	

V_ROWS_INSERTED  INTEGER;
V_ROWS_UPDATED INTEGER;
V_ROWS_DELETED INTEGER;
V_LAST_QUERY_ID VARCHAR;

V_WH VARCHAR;
V_BATCH_ID INTEGER;

V_ETL_LST_BTCH_ID INTEGER;


V_BATCH_OBJECT_START_TIME        VARCHAR;
V_STEP_START_TIME    VARCHAR;
V_STEP_NAME VARCHAR;
V_STEP_SEQ INTEGER DEFAULT 0;



BEGIN

EXECUTE IMMEDIATE ''USE DATABASE ''||:DB_NAME; 

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_BATCH_OBJECT_START_TIME := (SELECT CURRENT_TIMESTAMP());


LET res1 RESULTSET := 
(

SELECT 

WH ,
BATCH_ID
  
FROM UTIL.ETL_BATCH_OBJECT_CONTROL
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
FETCH FIRST 1 ROW ONLY

)
;


LET C1 CURSOR FOR res1;
open C1;
FETCH C1 into  V_WH,V_BATCH_ID ;
close C1;





EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:V_WH;
USE SCHEMA BDR_CONF;

INSERT INTO UTIL.ETL_BATCH_OBJECT_INCR_VALU (APPLICATION, WORKFLOW_NAME, OBJECT_NAME, INCR_COLUMN, INCR_COLUMN_VALUE )
SELECT * FROM 
(select :APPLICATION AS APPLICATION, :WORKFLOW_NAME AS WORKFLOW_NAME, :OBJECT_NAME AS OBJECT_NAME, ''ETL_LST_BTCH_ID'' AS INCR_COLUMN, -1 AS INCR_COLUMN_VALUE) A
WHERE NOT EXISTS (SELECT 1 FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU B WHERE B.APPLICATION = A.APPLICATION AND B.WORKFLOW_NAME = A.WORKFLOW_NAME AND B.OBJECT_NAME = A.OBJECT_NAME AND B.INCR_COLUMN = A.INCR_COLUMN)
;
V_ETL_LST_BTCH_ID := (SELECT INCR_COLUMN_VALUE FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID'');  



V_STEP_NAME    := ''TARGET - INSERT WRK_IPACQCHANNEL_BKP'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

CREATE OR REPLACE TRANSIENT TABLE  BDR_DM.WRK_IPACQCHANNEL_BKP
AS SELECT * FROM BDR_DM.WRK_IPACQUISITIONCHANNEL;


V_ROWS_INSERTED := (SELECT count(1) FROM BDR_DM.WRK_IPACQCHANNEL_BKP );	

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );	
                     

---Commented by OAS JNIKAM	 
/*	


 V_ROWS_AFFTD:=SQL%ROWCOUNT;
  INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''CONFORMED_DIMENSIONS'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''INSERT'',
      ''INSERT INTO WRK_IPACQCHANNEL_BKP '',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );


BDR_DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''BDR_DM.,''WRK_IPACQCHANNEL_BKP'');
--DBMS_STATS.GATHER_TABLE_STATS (ownname => ''BDR_DM.,tabname => ''WRK_IPACQCHANNEL_BKP'',partname => NULL,estimate_percent => 10, DEGREE => 4, granularity => ''ALL'', method_opt => ''FOR ALL COLUMNS SIZE 1'',CASCADE => TRUE);
*/
---Commented by OAS JNIKAM	

   --TRUNCATE TARGET Table

 V_STEP_NAME    := ''TARGET - TRUNCATE WRK_IPACQUISITIONCHANNEL'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;


EXECUTE IMMEDIATE ''TRUNCATE TABLE BDR_DM.WRK_IPACQUISITIONCHANNEL'';
   
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;


INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );	  
     
   

V_STEP_NAME    := ''TARGET - INSERT WRK_IPACQUISITIONCHANNEL'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;
   -- Agent
 --  BEGIN
 
 
  INSERT  INTO BDR_DM.WRK_IPACQUISITIONCHANNEL (INSUREDPLANID, Agent,AcquisitionChannel)  
     SELECT INSURED_PLAN_ID, ''Y'',''Agent''
FROM (SELECT A.Application_ID, IP.INSURED_PLAN_ID
    FROM SRC_COMPAS_D.INSURED_PLAN IP
  INNER JOIN SRC_COMPAS_D.APPLICATION A
ON IP.Application_ID = A.Application_ID
   WHERE A.Appl_Actor_ID = 3
  UNION
  SELECT A.Application_ID, IP.INSURED_PLAN_ID
    FROM SRC_COMPAS_D.APPLICATION_AGENT AA
  INNER JOIN SRC_COMPAS_D.INSURED_PLAN IP
ON IP.Application_ID = AA.Application_ID
  INNER JOIN SRC_COMPAS_D.APPLICATION A
ON IP.Application_ID = A.Application_ID
  UNION
  SELECT A.Application_ID, IP.INSURED_PLAN_ID
    FROM SRC_COMPAS_D.INSURED_PLAN IP
  INNER JOIN SRC_COMPAS_D.APPLICATION A
ON IP.Application_ID = A.Application_ID
   WHERE A.Hash_CD = ''2460720307''
  UNION
  SELECT A.Application_ID, IP.INSURED_PLAN_ID
    FROM SRC_COMPAS_D.APPLICATION_INDICATOR AI
  INNER JOIN SRC_COMPAS_D.INSURED_PLAN IP
ON IP.Application_ID = AI.Application_ID
  INNER JOIN SRC_COMPAS_D.APPLICATION A
ON IP.Application_ID = A.Application_ID
   WHERE AI.Selling_Agent_Signature_Ind = ''Y'');



V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );	

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );	
                     

---Commented by OAS JNIKAM	 
/*	


    V_ROWS_AFFTD:=SQL%ROWCOUNT;
  commit;
  INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''CONFORMED_DIMENSIONS'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''INSERT'',
      ''INSERT INTO WRK_IPACQUISITIONCHANNEL '',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );
   EXCEPTION
  WHEN NO_DATA_FOUND
  THEN
     DBMS_OUTPUT.PUT_LINE (''No Data Inserted'');
     NULL;
  WHEN OTHERS
  THEN
     RAISE;
   END;
   commit;
   BDR_DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''BDR_DM.,''WRK_IPACQUISITIONCHANNEL'');
--DBMS_STATS.GATHER_TABLE_STATS (ownname => ''BDR_DM.,tabname => ''WRK_IPACQUISITIONCHANNEL'',partname => NULL,estimate_percent => 10, DEGREE => 4, granularity => ''ALL'', method_opt => ''FOR ALL COLUMNS SIZE 1'',CASCADE => TRUE);
*/
---Commented by OAS JNIKAM	


V_STEP_NAME    := ''TARGET - MERGE WRK_IPACQUISITIONCHANNEL'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

-- Update  Agent Referral
 MERGE  INTO BDR_DM.WRK_IPACQUISITIONCHANNEL target
        USING (SELECT   DISTINCT ip.INSURED_PLAN_id
                FROM BDR_DM.WRK_IPACQUISITIONCHANNEL iac
                 INNER JOIN SRC_COMPAS_D.INSURED_PLAN ip
                 ON iac.INSUREDPLANID = ip.INSURED_PLAN_ID
                 INNER JOIN SRC_COMPAS_D.APPLICATION_AGENT aa
                 ON ip.Application_ID = aa.Application_ID
                 INNER JOIN SRC_COMPAS_D.AGENT_TYPE atp
              ON aa.AGENT_TYPE_ID = atp.AGENT_TYPE_ID
           WHERE atp.AGENT_TYPE_DESC = ''Referral Agent'')
              source
           ON (target.InsuredPlanID = source.INSURED_PLAN_ID)
   WHEN MATCHED
   THEN
      UPDATE SET Agent = ''R'', AcquisitionChannel = ''Agent Referral'';

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_UPDATED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );	

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );	
                     

---Commented by OAS JNIKAM	 
/*	

       V_ROWS_AFFTD:=SQL%ROWCOUNT;
    commit;

  INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''CONFORMED_DIMENSIONS'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''MERGE'',
      ''MERGE Referral Agent INTO WRK_IPACQUISITIONCHANNEL '',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );
commit;

 BDR_DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''BDR_DM.,''WRK_IPACQUISITIONCHANNEL'');
*/
---Commented by OAS JNIKAM	


V_STEP_NAME    := ''TARGET - MERGE WRK_IPACQUISITIONCHANNEL'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

   --Aggregator
   MERGE  INTO BDR_DM.WRK_IPACQUISITIONCHANNEL TARGET
    USING (SELECT  DISTINCT ip.INSURED_PLAN_id
  FROM SRC_COMPAS_D.APPLICATION_AGENT AA
INNER JOIN SRC_COMPAS_D.AGENT_CHAR AC
   ON AA.Agent_ID = AC.Agent_ID
 AND AC.Agent_Char_Type_ID = 4
INNER JOIN SRC_COMPAS_D.INSURED_PLAN IP
   ON IP.application_id = AA.application_id) SOURCE
ON (TARGET.InsuredPlanID = SOURCE.INSURED_PLAN_ID)
   WHEN MATCHED
   THEN
  UPDATE SET Aggregator = ''Y'', AcquisitionChannel=''Aggregator'';

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_UPDATED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );	

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );	
                     

---Commented by OAS JNIKAM	 
/*	

    V_ROWS_AFFTD:=SQL%ROWCOUNT;
    commit;
  INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''CONFORMED_DIMENSIONS'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''MERGE'',
      ''MERGE1 INTO WRK_IPACQUISITIONCHANNEL '',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );
commit;

 BDR_DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''BDR_DM.,''WRK_IPACQUISITIONCHANNEL'');
 
*/ 
---Commented by OAS JNIKAM	

V_STEP_NAME    := ''TARGET - MERGE WRK_IPACQUISITIONCHANNEL'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

--Update Aggregator referral
MERGE  INTO BDR_DM.WRK_IPACQUISITIONCHANNEL TARGET
        USING (SELECT DISTINCT ip.INSURED_PLAN_ID
                FROM BDR_DM.WRK_IPACQUISITIONCHANNEL iac
                 INNER JOIN SRC_COMPAS_D.INSURED_PLAN ip
                 ON iac.INSUREDPLANID = ip.INSURED_PLAN_ID
                 INNER JOIN SRC_COMPAS_D.APPLICATION_AGENT aa
                 ON ip.Application_ID = aa.Application_ID
                 INNER JOIN SRC_COMPAS_D.AGENT_TYPE atp
              ON aa.AGENT_TYPE_ID = atp.AGENT_TYPE_ID
              WHERE iac.AGGREGATOR =''Y'' AND atp.AGENT_TYPE_DESC = ''Referral Agent'')
              SOURCE
           ON (TARGET.InsuredPlanID = SOURCE.INSURED_PLAN_ID)
   WHEN MATCHED
   THEN
      UPDATE SET Aggregator = ''R'', AcquisitionChannel = ''Aggregator Referral'';

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_UPDATED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );	

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );	
                     

---Commented by OAS JNIKAM	 
/*	

      V_ROWS_AFFTD:=SQL%ROWCOUNT;
    commit;
  INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''CONFORMED_DIMENSIONS'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''MERGE'',
      ''MERGE Aggregator Referral INTO WRK_IPACQUISITIONCHANNEL '',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );
commit;

 BDR_DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''BDR_DM.,''WRK_IPACQUISITIONCHANNEL'');
*/
---Commented by OAS JNIKAM	
   ------------------------------------------------------
V_STEP_NAME    := ''TARGET - MERGE WRK_IPACQUISITIONCHANNEL'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

   ----Employer
   MERGE  INTO BDR_DM.WRK_IPACQUISITIONCHANNEL TARGET
    USING (SELECT DISTINCT INSURED_PLAN_ID
  FROM (SELECT CIP.INSURED_PLAN_ID,
 CIP.INSURED_PLAN_Effective_Date,
 CEHH.Emp_HHOLD_Start_Date,
 CEHH.Emp_HHOLD_Stop_Date,
 CE.Employer_Effective_Date,
 CE.Employer_Close_Date,
 CASE
    WHEN CKR.Individual_ID IS NOT NULL
     AND CIP.INSURED_PLAN_Effective_Date >=
 CKR.Subsidy_Start_Date
    THEN
   ''Employer''
    WHEN CIP.Application_ID IS NOT NULL
     AND (    (   CKR.Individual_ID IS NULL
    OR (    CKR.Individual_ID
   IS NOT NULL
 AND CIP.INSURED_PLAN_Effective_Date <
   CKR.Subsidy_Start_Date))
   AND CAW.Application_ID IS NOT NULL
   AND CAW.EA_Application_Waiver_Ind =
  ''Y'')
    THEN
   ''Employer''
    WHEN CIP.Application_ID IS NOT NULL
     AND (   CKR.Individual_ID IS NULL
   OR (    CKR.Individual_ID
   IS NOT NULL
   AND CIP.INSURED_PLAN_Effective_Date <
   CKR.Subsidy_Start_Date))
     AND (   CAW.Application_ID IS NULL
   OR (    CAW.Application_ID
   IS NOT NULL
   AND CAW.EA_Application_Waiver_Ind <>
   ''Y''))
     AND CSIP.INSURED_PLAN_ID IS NOT NULL
    THEN
   ''Employer''
    ELSE
   ''NOT Employer''
 END
    Decision
   FROM SRC_COMPAS_D.APPLICATION A
 INNER JOIN SRC_COMPAS_D.INSURED_PLAN CIP
    ON A.Application_ID = CIP.Application_ID
 INNER JOIN SRC_COMPAS_D.HOUSEHOLD_MEMBER CHHM
    ON CIP.Individual_ID = CHHM.Individual_ID
 INNER JOIN SRC_COMPAS_D.EMPLOYER_HOUSEHOLD CEHH
    ON CHHM.Household_ID = CEHH.Household_ID
 INNER JOIN SRC_COMPAS_D.EMPLOYER CE
    ON CEHH.Employer_ID = CE.Employer_ID
 LEFT OUTER JOIN SRC_COMPAS_D.KIT_REQUEST CKR
    ON CIP.Individual_ID = CKR.Individual_ID
 LEFT OUTER JOIN SRC_COMPAS_D.APPLICATION_WAIVERS CAW
    ON A.Application_ID = CAW.Application_ID
 LEFT OUTER JOIN
 SRC_COMPAS_D.SUBSIDIZED_INSURED_PLAN CSIP
    ON CIP.INSURED_PLAN_ID =
   CSIP.INSURED_PLAN_ID
   AND CIP.INSURED_PLAN_Effective_Date BETWEEN CSIP.Subsidized_Ins_Plan_Start_Date
   AND CSIP.Subsidized_Ins_Plan_Stop_Date-- WHERE A.Appl_Receipt_Date >= to_date(''2008-01-01'',''YYYY-MM-DD'')
)
 WHERE Decision = ''Employer''
AND INSURED_PLAN_Effective_Date BETWEEN Emp_HHOLD_Start_Date
  AND Emp_HHOLD_Stop_Date
AND INSURED_PLAN_Effective_Date BETWEEN Employer_Effective_Date
  AND NVL (
   Employer_Close_Date,
   TO_DATE (
  ''9999-12-31'',
  ''YYYY-MM-DD'')))
   SOURCE
ON (TARGET.InsuredplanID = SOURCE.INSURED_PLAN_ID)
   WHEN MATCHED
   THEN
  UPDATE SET Employer = ''Y'', AcquisitionChannel= CASE WHEN target.Agent = ''Y'' AND target.Aggregator = ''Y'' THEN ''Aggregator/Employer''
                                                      WHEN target.Agent = ''R'' AND target.Aggregator = ''R'' THEN ''Aggregator Referral/Employer''
										  WHEN Agent = ''Y'' AND (Aggregator IS NULL OR Aggregator <> ''Y'')  THEN ''Agent/Employer''
										  WHEN Agent = ''R'' AND (Aggregator IS NULL OR Aggregator <> ''R'') THEN ''Agent Referral/Employer''
										  END
   WHEN NOT MATCHED
   THEN
  INSERT (InsuredplanID, Employer, AcquisitionChannel)
  VALUES (source.INSURED_PLAN_ID, ''Y'', ''Employer'');


V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );
V_ROWS_UPDATED := (SELECT $2 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );	
                     

---Commented by OAS JNIKAM	 
/*	

    V_ROWS_AFFTD:=SQL%ROWCOUNT;
    commit;
  INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''CONFORMED_DIMENSIONS'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''MERGE'',
      ''MERGE2 INTO WRK_IPACQUISITIONCHANNEL '',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );
--DBMS_STATS.GATHER_TABLE_STATS (ownname => ''BDR_DM.,tabname => ''WRK_IPACQUISITIONCHANNEL'',partname => NULL,estimate_percent => 10, DEGREE => 4, granularity => ''ALL'', method_opt => ''FOR ALL COLUMNS SIZE 1'',CASCADE => TRUE);
*/
---Commented by OAS JNIKAM	

V_STEP_NAME    := ''TARGET - MERGE WRK_IPACQUISITIONCHANNEL'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

   MERGE  INTO BDR_DM.WRK_IPACQUISITIONCHANNEL target
    USING (  SELECT INSURED_PLAN_ID,
  MAX (CASE WHEN Marketing_Channel = ''DIRECT-TO-CONSUMER''  AND Campaign_Type = ''DIRECT'' THEN    ''Y'' END)directmarketing,
  MAX (CASE WHEN Marketing_Channel = ''DIRECT-TO-CONSUMER''  AND Campaign_Type = ''ADVERTISING/INQUIRY'' THEN    ''Y'' END)    inquiry,
  MAX (CASE WHEN Marketing_Channel = ''DIRECT-TO-CONSUMER''  AND (   trim(Campaign_Type) = '''' OR trim(Campaign_Type) IS NULL) THEN    ''Y''    END)unattributed,
  MAX (CASE WHEN marketing_channel =     ''UNKNOWN - PHONE ENROLLMENT KEYCODE'' THEN    ''Y'' END)unknownphoneenrollmentkeycode,
  MAX (CASE WHEN marketing_channel =     ''UNKNOWN - WEB ENROLLMENT KEYCODE'' THEN    ''Y'' END)    unknownwebenrollmentkeycode,
  MAX (CASE WHEN marketing_channel =     ''UNKNOWN - INVALID KEYCODE'' THEN    ''Y'' END)    unknowninvalidkeycode,
  MAX (CASE WHEN marketing_channel =  ''UNKNOWN - SYSTEM GENERATED KEYCODE''   THEN   ''Y'' END)unknownsystemgeneratedkeycode,
  MAX (    CASE WHEN marketing_channel =     ''UNKNOWN - AGENT ENROLLMENT KEYCODE'' THEN    ''Y'' END)unknownagentenrollmentkeycode,
  MAX (CASE WHEN marketing_channel = ''UNKNOWN OTHER'' THEN ''Y'' END)unknownother
    FROM (SELECT IP.INSURED_PLAN_ID,
   SAR.Marketing_Channel,
   SAR.Campaign_Type
FROM SRC_COMPAS_D.APPLICATION A
   JOIN SRC_COMPAS_D.INSURED_PLAN IP
  ON A.Application_ID = IP.Application_ID
   JOIN BDR_SMART.Application SA
  ON A.Application_ID =
 SA.Source_Application_ID
   JOIN BDR_SMART.APPLICATION_REPORTING SAR
  ON SA.Application_ID = SAR.Application_ID
   UNION
   SELECT IP.INSURED_PLAN_ID,
   SAR.Marketing_Channel,
   SAR.Campaign_Type
FROM SRC_COMPAS_D.APPLICATION A
   JOIN SRC_COMPAS_D.INSURED_PLAN IP
  ON A.Application_ID = IP.Application_ID
   INNER JOIN BDR_SMART.INSURED_PLAN SIP
  ON IP.INSURED_PLAN_ID =
 SIP.Source_INSURED_PLAN_ID
   INNER JOIN BDR_SMART.APPLICATION_REPORTING SAR
  ON SIP.Application_ID = SAR.Application_ID)
   WHERE    (    marketing_channel = ''DIRECT-TO-CONSUMER''  AND campaign_type = ''DIRECT'')
  OR (    marketing_channel = ''DIRECT-TO-CONSUMER''  AND campaign_type = ''ADVERTISING/INQUIRY'')
  OR (    marketing_channel = ''DIRECT-TO-CONSUMER''  AND ( TRIM (campaign_type) IS NULL OR TRIM (campaign_type) = '''' )             )
  OR marketing_channel IN (''UNKNOWN - PHONE ENROLLMENT KEYCODE'',      ''UNKNOWN - WEB ENROLLMENT KEYCODE'',      ''UNKNOWN - INVALID KEYCODE'',      ''UNKNOWN - SYSTEM GENERATED KEYCODE'',      ''UNKNOWN - AGENT ENROLLMENT KEYCODE'',
     ''UNKNOWN OTHER'')
    GROUP BY INSURED_PLAN_ID) source
ON (target.InsuredPlanID = source.INSURED_PLAN_ID)
   WHEN MATCHED
   THEN
  UPDATE SET
     target.directmarketing  = source.directmarketing,
     target.inquiry   = source.inquiry,
     target.unattributed     = source.unattributed,
     target.unknownphoneenrollmentkeycode   = source.unknownphoneenrollmentkeycode,
     target.unknownwebenrollmentkeycode = source.unknownwebenrollmentkeycode,
     target.unknowninvalidkeycode= source.unknowninvalidkeycode,
     target.unknownsystemgeneratedkeycode   = source.unknownsystemgeneratedkeycode,
     target.unknownagentenrollmentkeycode   = source.unknownagentenrollmentkeycode,
     target.unknownother     = source.unknownother,
     target.AcquisitionChannel   = case WHEN target.AcquisitionChannel is null and source.DirectMarketing = ''Y'' THEN ''Direct Marketing''
										  WHEN target.AcquisitionChannel is null and source.Inquiry = ''Y'' THEN ''Inquiry''
										  WHEN target.AcquisitionChannel is null and source.Unattributed = ''Y'' THEN ''Unattributed''
										  WHEN target.AcquisitionChannel is null and source.UnknownPhoneEnrollmentKeyCode = ''Y'' THEN ''Unknown - Phone Enrollment Key Code''
										  WHEN target.AcquisitionChannel is null and source.UnknownWebEnrollmentKeyCode = ''Y'' THEN ''Unknown - Web Enrollment Key Code''
										  WHEN target.AcquisitionChannel is null and source.UnknownInvalidKeyCode = ''Y'' THEN ''Unknown - Invalid Key Code''
										  WHEN target.AcquisitionChannel is null and source.UnknownSystemGeneratedKeyCode = ''Y'' THEN ''Unknown - System Generated Key Code''
										  WHEN target.AcquisitionChannel is null and source.UnknownAgentEnrollmentKeyCode = ''Y'' THEN ''Unknown - Agent Enrollment Key Code''
										  WHEN target.AcquisitionChannel is null and source.UnknownOther = ''Y'' THEN ''Unknown Other''
            WHEN target.AcquisitionChannel is null THEN ''UNKNOWN''
            ELSE target.AcquisitionChannel
  END
   WHEN NOT MATCHED
   THEN
  INSERT (InsuredPlanID,
   directmarketing,
   inquiry,
   unattributed,
   unknownphoneenrollmentkeycode,
   unknownwebenrollmentkeycode,
   unknowninvalidkeycode,
   unknownsystemgeneratedkeycode,
   unknownagentenrollmentkeycode,
   unknownother,
   AcquisitionChannel)
  VALUES (source.INSURED_PLAN_ID,
   source.directmarketing,
   source.inquiry,
   source.unattributed,
   source.unknownphoneenrollmentkeycode,
   source.unknownwebenrollmentkeycode,
   source.unknowninvalidkeycode,
   source.unknownsystemgeneratedkeycode,
   source.unknownagentenrollmentkeycode,
   source.unknownother,
   case WHEN source.DirectMarketing = ''Y'' THEN ''Direct Marketing''
										  WHEN source.Inquiry = ''Y'' THEN ''Inquiry''
										  WHEN source.Unattributed = ''Y'' THEN ''Unattributed''
										  WHEN source.UnknownPhoneEnrollmentKeyCode = ''Y'' THEN ''Unknown - Phone Enrollment Key Code''
										  WHEN source.UnknownWebEnrollmentKeyCode = ''Y'' THEN ''Unknown - Web Enrollment Key Code''
										  WHEN source.UnknownInvalidKeyCode = ''Y'' THEN ''Unknown - Invalid Key Code''
										  WHEN source.UnknownSystemGeneratedKeyCode = ''Y'' THEN ''Unknown - System Generated Key Code''
										  WHEN source.UnknownAgentEnrollmentKeyCode = ''Y'' THEN ''Unknown - Agent Enrollment Key Code''
										  WHEN source.UnknownOther = ''Y'' THEN ''Unknown Other''
  ELSE ''UNKNOWN''
  END);
 
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );
V_ROWS_UPDATED := (SELECT $2 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );	

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );	
                     

---Commented by OAS JNIKAM	 
/*	

 V_ROWS_AFFTD:=SQL%ROWCOUNT;
        commit;
  INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''CONFORMED_DIMENSIONS'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''MERGE'',
      ''MERGE3 INTO WRK_IPACQUISITIONCHANNEL '',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );
--DBMS_STATS.GATHER_TABLE_STATS (ownname => ''BDR_DM.,tabname => ''WRK_IPACQUISITIONCHANNEL'',partname => NULL,estimate_percent => 10, DEGREE => 4, granularity => ''ALL'', method_opt => ''FOR ALL COLUMNS SIZE 1'',CASCADE => TRUE);
   ------------------------------------------------------
*/
---Commented by OAS JNIKAM	

V_STEP_NAME    := ''TARGET - MERGE WRK_IPACQUISITIONCHANNEL'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;


   MERGE  INTO BDR_DM.WRK_IPACQUISITIONCHANNEL target
    USING (  SELECT INSURED_PLAN_ID,
  MAX (CASE
 WHEN Marketing_Channel IN (''AGENT - NON AGGREGATOR'',
 ''AGENT'',
 ''AGENT/EMPLOYER'',
 ''AGENT - DESTINATIONRX'',
 ''AGENT - EHEALTH'',
 ''AGENT - EXTEND_HEALTH'',
 ''AGENT - INSURACTIVE'',
 ''AGENT - MERCER'',
 ''AGENT - MYCUSTOM_HEALTH'',
 ''AGENT - SELECTQUOTE_SENIOR'',
 ''AGENT - SENIOR_EDUCATORS'',
 ''AGENT - SENIOR_MARKET_SALES_(SMS)'',
 ''AGENT - TRANZACT'')
 THEN    ''Y''END) Agent,
  MAX (CASE WHEN Marketing_Channel IN (''AGENT/EMPLOYER'', ''EMPLOYER'') THEN    ''Y''END)Employer,
  MAX (CASE WHEN Marketing_Channel IN (''AGENT - DESTINATIONRX'',
 ''AGENT - EHEALTH'',
 ''AGENT - EXTEND_HEALTH'',
 ''AGENT - INSURACTIVE'',
 ''AGENT - MERCER'',
 ''AGENT - MYCUSTOM_HEALTH'',
 ''AGENT - SELECTQUOTE_SENIOR'',
 ''AGENT - SENIOR_EDUCATORS'',
 ''AGENT - SENIOR_MARKET_SALES_(SMS)'',
 ''AGENT - TRANZACT'')
 THEN    ''Y''END) Aggregator,
  MAX (CASE WHEN Marketing_Channel IN (''DIRECT-TO-CONSUMER'')  AND Campaign_Type = ''DIRECT''  THEN    ''Y''END) directmarketing,
  MAX (CASE WHEN Marketing_Channel IN (''DIRECT-TO-CONSUMER'')  AND Campaign_Type IN (''ADVERTISING/INQUIRY'', ''GROUP RETIREE SERVICES'') THEN    ''Y''END) inquiry,
  MAX (CASE WHEN Marketing_Channel IN (''DIRECT-TO-CONSUMER'')  AND (   trim(Campaign_Type) = '''' OR trim(Campaign_Type) IS NULL ) THEN    ''Y''END) unattributed,
  MAX (CASE WHEN marketing_channel IN (''UNKNOWN - PHONE ENROLLMENT KEYCODE'') THEN    ''Y'' END) unknownphoneenrollmentkeycode,
  MAX (CASE WHEN marketing_channel IN (''UNKNOWN - WEB ENROLLMENT KEYCODE'') THEN    ''Y'' END) unknownwebenrollmentkeycode,
  MAX (CASE WHEN marketing_channel IN (''UNKNOWN - INVALID KEYCODE'') THEN    ''Y'' END) unknowninvalidkeycode,
  MAX (CASE WHEN marketing_channel IN (''UNKNOWN - SYSTEM GENERATED KEYCODE'')  THEN    ''Y'' END) unknownsystemgeneratedkeycode,
  MAX (CASE WHEN marketing_channel IN (''UNKNOWN - AGENT ENROLLMENT KEYCODE'') THEN    ''Y'' END) unknownagentenrollmentkeycode,
  MAX (CASE WHEN marketing_channel IN (''UNKNOWN OTHER'') THEN    ''Y'' END) unknownother,
  ''N'' AS AppIDFlag
    FROM (SELECT IP.INSURED_PLAN_ID,
   SAR.Marketing_Channel,
   SAR.Campaign_Type
FROM SRC_COMPAS_D.INSURED_PLAN IP
   LEFT JOIN SRC_COMPAS_D.APPLICATION A
  ON A.APPLICATION_ID = IP.Application_ID
   INNER JOIN BDR_SMART.INSURED_PLAN SIP
  ON IP.INSURED_PLAN_ID =
 SIP.Source_INSURED_PLAN_ID
   JOIN BDR_SMART.APPLICATION_REPORTING SAR
  ON SIP.Application_ID = SAR.Application_ID
    WHERE A.APPLICATION_ID IS NULL)
   WHERE    (    marketing_channel = ''DIRECT-TO-CONSUMER''
 AND campaign_type = ''DIRECT'')
  OR (    marketing_channel = ''DIRECT-TO-CONSUMER''
 AND campaign_type = ''ADVERTISING/INQUIRY'')
  OR (    marketing_channel = ''DIRECT-TO-CONSUMER''
 AND (TRIM (campaign_type) IS NULL OR TRIM (campaign_type) = ''''   )          )
  OR marketing_channel IN (''UNKNOWN - PHONE ENROLLMENT KEYCODE'',
     ''UNKNOWN - WEB ENROLLMENT KEYCODE'',
     ''UNKNOWN - INVALID KEYCODE'',
     ''UNKNOWN - SYSTEM GENERATED KEYCODE'',
     ''UNKNOWN - AGENT ENROLLMENT KEYCODE'',
     ''UNKNOWN OTHER'',
     ''AGENT - NON AGGREGATOR'',
     ''AGENT'',
     ''AGENT/EMPLOYER'',
     ''AGENT - DESTINATIONRX'',
     ''AGENT - EHEALTH'',
     ''AGENT - EXTEND_HEALTH'',
     ''AGENT - INSURACTIVE'',
     ''AGENT - MERCER'',
     ''AGENT - MYCUSTOM_HEALTH'',
     ''AGENT - SELECTQUOTE_SENIOR'',
     ''AGENT - SENIOR_EDUCATORS'',
     ''AGENT - SENIOR_MARKET_SALES_(SMS)'',
     ''AGENT - TRANZACT'',
     ''AGENT/EMPLOYER'',
     ''EMPLOYER'',
     ''AGENT - DESTINATIONRX'',
     ''AGENT - EHEALTH'',
     ''AGENT - EXTEND_HEALTH'',
     ''AGENT - INSURACTIVE'',
     ''AGENT - MERCER'',
     ''AGENT - MYCUSTOM_HEALTH'',
     ''AGENT - SELECTQUOTE_SENIOR'',
     ''AGENT - SENIOR_EDUCATORS'',
     ''AGENT - SENIOR_MARKET_SALES_(SMS)'',
     ''AGENT - TRANZACT'')
    GROUP BY INSURED_PLAN_ID) source
ON (target.InsuredPlanID = source.INSURED_PLAN_ID)
   WHEN MATCHED
   THEN
  UPDATE SET
     target.Agent                           = source.Agent,
     target.Employer                        = source.Employer,
     target.Aggregator                      = source.Aggregator,
     target.directmarketing                 = source.directmarketing,
     target.inquiry                         = source.inquiry,
     target.unattributed                    = source.unattributed,
     target.unknownphoneenrollmentkeycode   = source.unknownphoneenrollmentkeycode,
     target.unknownwebenrollmentkeycode     = source.unknownwebenrollmentkeycode,
     target.unknowninvalidkeycode           = source.unknowninvalidkeycode,
     target.unknownsystemgeneratedkeycode   = source.unknownsystemgeneratedkeycode,
     target.unknownagentenrollmentkeycode   = source.unknownagentenrollmentkeycode,
     target.unknownother                    = source.unknownother,
     target.AppIDFlag                       = source.AppIDFlag,
     target.AcquisitionChannel              =  CASE
 WHEN source.Agent = ''Y'' AND source.Aggregator = ''Y'' AND source.Employer = ''Y'' THEN    ''Aggregator/Employer''
 WHEN source.Agent = ''Y'' AND source.Aggregator = ''Y'' AND source.Employer IS NULL THEN    ''Aggregator''
 WHEN source.Agent = ''Y'' AND source.Aggregator IS NULL AND source.Employer = ''Y'' THEN    ''Agent/Employer''
 WHEN source.Agent = ''Y'' AND source.Aggregator IS NULL AND source.Employer IS NULL THEN    ''Agent''
 WHEN source.Agent IS NULL AND source.Aggregator IS NULL AND source.Employer = ''Y'' THEN    ''Employer''
 WHEN source.DirectMarketing = ''Y'' THEN    ''Direct Marketing''
 WHEN source.Inquiry = ''Y'' THEN    ''Inquiry''
 WHEN source.Unattributed = ''Y'' THEN    ''Unattributed''
 WHEN source.UnknownPhoneEnrollmentKeyCode = ''Y'' THEN    ''Unknown - Phone Enrollment Key Code''
 WHEN source.UnknownWebEnrollmentKeyCode = ''Y'' THEN    ''Unknown - Web Enrollment Key Code''
 WHEN source.UnknownInvalidKeyCode = ''Y'' THEN    ''Unknown - Invalid Key Code''
 WHEN source.UnknownSystemGeneratedKeyCode = ''Y'' THEN    ''Unknown - System Generated Key Code''
 WHEN source.UnknownAgentEnrollmentKeyCode = ''Y'' THEN    ''Unknown - Agent Enrollment Key Code''
 WHEN source.UnknownOther = ''Y'' THEN    ''Unknown Other''
 ELSE
    ''UNKNOWN''
  END
   WHEN NOT MATCHED
   THEN
  INSERT (InsuredPlanID,
   Agent,
   Employer,
   Aggregator,
   directmarketing,
   inquiry,
   unattributed,
   unknownphoneenrollmentkeycode,
   unknownwebenrollmentkeycode,
   unknowninvalidkeycode,
   unknownsystemgeneratedkeycode,
   unknownagentenrollmentkeycode,
   unknownother,
   AppIDFlag, AcquisitionChannel)
  VALUES (source.INSURED_PLAN_ID,
   source.Agent,
   source.Employer,
   source.Aggregator,
   source.directmarketing,
   source.inquiry,
   source.unattributed,
   source.unknownphoneenrollmentkeycode,
   source.unknownwebenrollmentkeycode,
   source.unknowninvalidkeycode,
   source.unknownsystemgeneratedkeycode,
   source.unknownagentenrollmentkeycode,
   source.unknownother,
   source.AppIDFlag, CASE
 WHEN Source.Agent = ''Y'' AND Source.Aggregator = ''Y'' AND Source.Employer = ''Y'' THEN    ''Aggregator/Employer''
 WHEN Source.Agent = ''Y'' AND Source.Aggregator = ''Y'' AND Source.Employer IS NULL THEN    ''Aggregator''
 WHEN Source.Agent = ''Y'' AND Source.Aggregator IS NULL AND Source.Employer = ''Y'' THEN    ''Agent/Employer''
 WHEN Source.Agent = ''Y'' AND Source.Aggregator IS NULL AND Source.Employer IS NULL THEN    ''Agent''
 WHEN Source.Agent IS NULL AND Source.Aggregator IS NULL AND Source.Employer = ''Y'' THEN    ''Employer''
 WHEN Source.DirectMarketing = ''Y'' THEN    ''Direct Marketing''
 WHEN Source.Inquiry = ''Y'' THEN    ''Inquiry''
 WHEN Source.Unattributed = ''Y'' THEN    ''Unattributed''
 WHEN Source.UnknownPhoneEnrollmentKeyCode = ''Y'' THEN    ''Unknown - Phone Enrollment Key Code''
 WHEN Source.UnknownWebEnrollmentKeyCode = ''Y'' THEN    ''Unknown - Web Enrollment Key Code''
 WHEN Source.UnknownInvalidKeyCode = ''Y'' THEN    ''Unknown - Invalid Key Code''
 WHEN Source.UnknownSystemGeneratedKeyCode = ''Y'' THEN    ''Unknown - System Generated Key Code''
 WHEN Source.UnknownAgentEnrollmentKeyCode = ''Y'' THEN    ''Unknown - Agent Enrollment Key Code''
 WHEN Source.UnknownOther = ''Y'' THEN    ''Unknown Other''
 ELSE
    ''UNKNOWN''
  END  );

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );
V_ROWS_UPDATED := (SELECT $2 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );	
                     

---Commented by OAS JNIKAM	 
/*	

 
 V_ROWS_AFFTD:=SQL%ROWCOUNT;
     commit;
  INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''CONFORMED_DIMENSIONS'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''MERGE'',
      ''MERGE4 INTO WRK_IPACQUISITIONCHANNEL '',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );
*/
---Commented by OAS JNIKAM	
--DBMS_STATS.GATHER_TABLE_STATS (ownname => ''BDR_DM.,tabname => ''WRK_IPACQUISITIONCHANNEL'',partname => NULL,estimate_percent => 10, DEGREE => 4, granularity => ''ALL'', method_opt => ''FOR ALL COLUMNS SIZE 1'',CASCADE => TRUE);
   --AcquisitionChannel
   /*
   UPDATE BDR_DM.WRK_IPACQUISITIONCHANNEL
  SET AcquisitionChannel =
  CASE
 WHEN Agent = ''Y'' AND Aggregator = ''Y'' AND Employer = ''Y''
 THEN
    ''Aggregator/Employer''
 WHEN Agent = ''Y'' AND Aggregator = ''Y'' AND Employer IS NULL
 THEN
    ''Aggregator''
 WHEN Agent = ''Y'' AND Aggregator IS NULL AND Employer = ''Y''
 THEN
    ''Agent/Employer''
 WHEN Agent = ''Y'' AND Aggregator IS NULL AND Employer IS NULL
 THEN
    ''Agent''
 WHEN Agent IS NULL AND Aggregator IS NULL AND Employer = ''Y''
 THEN
    ''Employer''
 WHEN DirectMarketing = ''Y''
 THEN
    ''Direct Marketing''
 WHEN Inquiry = ''Y''
 THEN
    ''Inquiry''
 WHEN Unattributed = ''Y''
 THEN
    ''Unattributed''
 WHEN UnknownPhoneEnrollmentKeyCode = ''Y''
 THEN
    ''Unknown ? Phone Enrollment Key Code''
 WHEN UnknownWebEnrollmentKeyCode = ''Y''
 THEN
    ''Unknown ? Web Enrollment Key Code''
 WHEN UnknownInvalidKeyCode = ''Y''
 THEN
    ''Unknown ? Invalid Key Code''
 WHEN UnknownSystemGeneratedKeyCode = ''Y''
 THEN
    ''Unknown ? System Generated Key Code''
 WHEN UnknownAgentEnrollmentKeyCode = ''Y''
 THEN
    ''Unknown ? Agent Enrollment Key Code''
 WHEN UnknownOther = ''Y''
 THEN
    ''Unknown Other''
 ELSE
    ''UNKNOWN''
  END;
    */
    /*
   MERGE INTO BDR_DM.WRK_IPACQUISITIONCHANNEL
   USING (SELECT 1 FROM DUAL) D
   ON (1=1)
   WHEN MATCHED THEN
   UPDATE
  SET AcquisitionChannel =
  CASE
 WHEN Agent = ''Y'' AND Aggregator = ''Y'' AND Employer = ''Y'' THEN    ''Aggregator/Employer''
 WHEN Agent = ''Y'' AND Aggregator = ''Y'' AND Employer IS NULL THEN    ''Aggregator''
 WHEN Agent = ''Y'' AND Aggregator IS NULL AND Employer = ''Y'' THEN    ''Agent/Employer''
 WHEN Agent = ''Y'' AND Aggregator IS NULL AND Employer IS NULL THEN    ''Agent''
 WHEN Agent IS NULL AND Aggregator IS NULL AND Employer = ''Y'' THEN    ''Employer''
 WHEN DirectMarketing = ''Y'' THEN    ''Direct Marketing''
 WHEN Inquiry = ''Y'' THEN    ''Inquiry''
 WHEN Unattributed = ''Y'' THEN    ''Unattributed''
 WHEN UnknownPhoneEnrollmentKeyCode = ''Y'' THEN    ''Unknown ? Phone Enrollment Key Code''
 WHEN UnknownWebEnrollmentKeyCode = ''Y'' THEN    ''Unknown ? Web Enrollment Key Code''
 WHEN UnknownInvalidKeyCode = ''Y'' THEN    ''Unknown ? Invalid Key Code''
 WHEN UnknownSystemGeneratedKeyCode = ''Y'' THEN    ''Unknown ? System Generated Key Code''
 WHEN UnknownAgentEnrollmentKeyCode = ''Y'' THEN    ''Unknown ? Agent Enrollment Key Code''
 WHEN UnknownOther = ''Y'' THEN    ''Unknown Other''
 ELSE
    ''UNKNOWN''
  END;
   COMMIT;
*/
   -- Insert changed records to the change capturing table

                 

 
   
V_STEP_NAME    := ''TARGET - INSERT WRK_IPACQCHANNEL_CHG'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

  
CREATE OR REPLACE TRANSIENT TABLE BDR_DM.WRK_IPACQCHANNEL_CHG AS 
  SELECT IPAC.*
    FROM BDR_DM.WRK_IPACQUISITIONCHANNEL IPAC
  INNER JOIN BDR_DM.WRK_IPACQCHANNEL_BKP IPACB
 ON IPAC.INSUREDPLANID = IPACB.INSUREDPLANID
    AND IPAC.ACQUISITIONCHANNEL <> IPACB.ACQUISITIONCHANNEL;
	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT count(1) FROM BDR_DM.WRK_IPACQCHANNEL_CHG );	

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );	
                     

---Commented by OAS JNIKAM	 
/*	
	

    V_ROWS_AFFTD:=SQL%ROWCOUNT;
  INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''CONFORMED_DIMENSIONS'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''INSERT'',
      ''INSERT INTO WRK_IPACQCHANNEL_CHG '',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );

BDR_DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''BDR_DM.,''WRK_IPACQCHANNEL_CHG'');

*/

---Commented by OAS JNIKAM	 
/*
--DBMS_STATS.GATHER_TABLE_STATS (ownname => ''BDR_DM.,tabname => ''WRK_IPACQCHANNEL_CHG'',partname => NULL,estimate_percent => 10, DEGREE => 4, granularity => ''ALL'', method_opt => ''FOR ALL COLUMNS SIZE 1'',CASCADE => TRUE);
   --Returns the result set
   P_ToContinueStatus := ''Y'';
   P_ErrorYNFlg := ''N'';
   P_ErrorStr := '';
   INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''CONFORMED_DIMENSIONS'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''END'',
      ''PROCEDURE ENDS'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );
	COMMIT;
EXCEPTION
   WHEN OTHERS
   THEN
    P_ErrorStr := ''ERROR: '' || SQLCODE || ''-'' || SQLERRM || ''-'' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE()|| Chr(10)||DBMS_UTILITY.FORMAT_ERROR_STACK();
      P_ToContinueStatus := ''N'';
      P_ErrorYNFlg := ''Y'';
      ROLLBACK;
  END;
/
*/

---Commented by OAS JNIKAM	 

CALL UTIL.SP_ETL_CHECK_CONSTRAINTS(:DB_NAME , :APPLICATION , :WORKFLOW_NAME , :OBJECT_NAME , :V_BATCH_ID );


UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''COMPLETE'', ERROR_MSG = null, BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
; 


UPDATE  UTIL.ETL_BATCH_OBJECT_INCR_VALU SET INCR_COLUMN_VALUE = :V_BATCH_ID, LST_MOD_DT = CURRENT_TIMESTAMP() WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID''; 

EXCEPTION

WHEN OTHER THEN


UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''ERROR'', ERROR_MSG = :SQLERRM,  BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
;



INSERT INTO  UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ERROR_MSG, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''ERROR'', :V_STEP_NAME, :V_STEP_SEQ, :SQLERRM, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() )
;



RAISE;
    
		
		
END;

';