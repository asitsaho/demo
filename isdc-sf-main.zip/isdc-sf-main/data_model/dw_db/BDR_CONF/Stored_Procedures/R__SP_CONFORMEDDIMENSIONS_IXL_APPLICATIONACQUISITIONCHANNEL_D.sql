USE SCHEMA BDR_CONF; CREATE OR REPLACE PROCEDURE "SP_CONFORMEDDIMENSIONS_IXL_APPLICATIONACQUISITIONCHANNEL_D"("DB_NAME" VARCHAR(16777216), "APPLICATION" VARCHAR(16777216), "WORKFLOW_NAME" VARCHAR(16777216), "OBJECT_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '

-- Original workflow: wkf_ConformedDimensions_IU_TargetLoad_D
-- Original mapping: m_ConformedDimensions_IXL_ApplicationAcquisitionChannel_D



DECLARE

V_ROWS_INSERTED  INTEGER;
V_ROWS_UPDATED INTEGER;
V_ROWS_DELETED INTEGER;
V_LAST_QUERY_ID VARCHAR;

V_WH VARCHAR;
V_BATCH_ID INTEGER;

V_ETL_LST_BTCH_ID INTEGER;
V_BATCH_OBJECT_START_TIME        VARCHAR;
V_STEP_START_TIME    VARCHAR;
V_STEP_NAME VARCHAR;
V_STEP_SEQ INTEGER DEFAULT 0;
V_CUTTOFDATE date; ---OAS ADD
  
      



BEGIN

EXECUTE IMMEDIATE ''USE DATABASE ''||:DB_NAME; 

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_BATCH_OBJECT_START_TIME := (SELECT CURRENT_TIMESTAMP());



LET res1 RESULTSET := 
(

SELECT 

WH ,
BATCH_ID
  
FROM UTIL.ETL_BATCH_OBJECT_CONTROL
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
FETCH FIRST 1 ROW ONLY

)
;


LET C1 CURSOR FOR res1;
open C1;
FETCH C1 into  V_WH,V_BATCH_ID ;
close C1;





EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:V_WH;
USE SCHEMA BDR_DM;

INSERT INTO UTIL.ETL_BATCH_OBJECT_INCR_VALU (APPLICATION, WORKFLOW_NAME, OBJECT_NAME, INCR_COLUMN, INCR_COLUMN_VALUE )
SELECT * FROM 
(select :APPLICATION AS APPLICATION, :WORKFLOW_NAME AS WORKFLOW_NAME, :OBJECT_NAME AS OBJECT_NAME, ''ETL_LST_BTCH_ID'' AS INCR_COLUMN, -1 AS INCR_COLUMN_VALUE) A
WHERE NOT EXISTS (SELECT 1 FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU B WHERE B.APPLICATION = A.APPLICATION AND B.WORKFLOW_NAME = A.WORKFLOW_NAME AND B.OBJECT_NAME = A.OBJECT_NAME AND B.INCR_COLUMN = A.INCR_COLUMN)
;
V_ETL_LST_BTCH_ID := (SELECT INCR_COLUMN_VALUE FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID'');  




TRUNCATE TABLE BDR_DM.WRK_ACQUISITIONCHANNEL;

   INSERT INTO BDR_DM.WRK_ACQUISITIONCHANNEL (ApplicationID, Agent)
      SELECT Application_ID, ''Y''
        FROM (SELECT A.Application_ID
                FROM SRC_COMPAS_D.Application A
               WHERE     A.Appl_Actor_ID = 3
                     AND A.Appl_Receipt_Date >= ''2016-01-01''        
              UNION
      
              SELECT AA.application_id
                FROM SRC_COMPAS_D.Application_Agent AA, SRC_COMPAS_D.Application A
               WHERE     AA.Application_ID = A.Application_ID
                     AND A.Appl_Receipt_Date >=''2016-01-01''  
              UNION
         
              SELECT A.application_id
                FROM SRC_COMPAS_D.Application A
               WHERE     A.Hash_CD = ''2460720307''
                     AND A.Appl_Receipt_Date >= ''2016-01-01''       
              UNION
        
              SELECT A.application_id
                FROM SRC_COMPAS_D.Application_Indicator AI, SRC_COMPAS_D.Application A
               WHERE     AI.Application_ID = A.Application_ID
                     AND AI.Selling_Agent_Signature_Ind = ''Y''
                     AND A.Appl_Receipt_Date >= ''2016-01-01'' );
					 
					  MERGE INTO BDR_DM.WRK_ACQUISITIONCHANNEL target
        USING (SELECT DISTINCT a.ApplicationID
                FROM BDR_DM.WRK_ACQUISITIONCHANNEL a
                INNER JOIN SRC_COMPAS_D.application_agent aa
              ON a.ApplicationID = aa.application_id
                INNER JOIN SRC_COMPAS_D.AGENT_TYPE atp
              ON aa.AGENT_TYPE_ID = atp.AGENT_TYPE_ID
           WHERE  atp.AGENT_TYPE_DESC = ''Referral Agent'')
              source
           ON (target.applicationid = source.applicationid)
   WHEN MATCHED
   THEN
      UPDATE SET Agent = ''R'';
	  
	  MERGE INTO BDR_DM.WRK_ACQUISITIONCHANNEL target
        USING (SELECT DISTINCT aa.application_id
                 FROM SRC_COMPAS_D.application_agent aa, SRC_COMPAS_D.agent_char ac
                WHERE aa.agent_id = ac.agent_id AND ac.agent_char_type_id = 4)
              source
           ON (target.applicationid = source.application_id)
   WHEN MATCHED
   THEN
      UPDATE SET Aggregator = ''Y'';
	  
	  
	   MERGE INTO BDR_DM.WRK_ACQUISITIONCHANNEL target
        USING (SELECT DISTINCT a.ApplicationID
                FROM BDR_DM.WRK_ACQUISITIONCHANNEL a
                INNER JOIN SRC_COMPAS_D.application_agent aa
              ON a.ApplicationID = aa.application_id
                INNER JOIN SRC_COMPAS_D.AGENT_TYPE atp
              ON aa.AGENT_TYPE_ID = atp.AGENT_TYPE_ID
           WHERE a.AGGREGATOR =''Y'' AND atp.AGENT_TYPE_DESC = ''Referral Agent'')
              source
           ON (target.applicationid = source.applicationid)
   WHEN MATCHED
   THEN
      UPDATE SET Aggregator = ''R'';
	  
	  
	  MERGE INTO BDR_DM.WRK_ACQUISITIONCHANNEL TARGET
        USING (SELECT DISTINCT APPLICATION_ID
                 FROM (SELECT A.APPLICATION_ID,
    CIP.APPLICATION_ID InsApp,
    CIP.Insured_Plan_Effective_Date,
    CEHH.Emp_HHOLD_Start_Date,
    CEHH.Emp_HHOLD_Stop_Date,
    CE.Employer_Effective_Date,
    CE.Employer_Close_Date,
    CASE
       WHEN     CIP.Application_ID IS NULL
            AND A.Employer_App_Ind = ''Y''
       THEN
          ''Employer''
       WHEN     CKR.Individual_ID IS NOT NULL
            AND CIP.Insured_Plan_Effective_Date >=
                   CKR.Subsidy_Start_Date
       THEN
          ''Employer''
       WHEN     CIP.Application_ID IS NOT NULL
            AND (    (   CKR.Individual_ID IS NULL
                      OR (    CKR.Individual_ID
       IS NOT NULL
                          AND CIP.Insured_Plan_Effective_Date <
       CKR.Subsidy_Start_Date))
                 AND CAW.Application_ID IS NOT NULL
                 AND CAW.EA_Application_Waiver_Ind =
                        ''Y'')
       THEN
          ''Employer''
       WHEN     CIP.Application_ID IS NOT NULL
            AND (   CKR.Individual_ID IS NULL
                 OR (    CKR.Individual_ID
  IS NOT NULL
                     AND CIP.Insured_Plan_Effective_Date <
  CKR.Subsidy_Start_Date))
            AND (   CAW.Application_ID IS NULL
                 OR (    CAW.Application_ID
  IS NOT NULL
                     AND CAW.EA_Application_Waiver_Ind <>
  ''Y''))
            AND CSIP.Insured_Plan_ID IS NOT NULL
       THEN
          ''Employer''
       ELSE
          ''NOT Employer''
    END
       Decision
                         FROM SRC_COMPAS_D.Application A
    LEFT OUTER JOIN SRC_COMPAS_D.Insured_Plan CIP
       ON A.Application_ID = CIP.Application_ID
    LEFT OUTER JOIN SRC_COMPAS_D.Household_Member CHHM
       ON CIP.Individual_ID = CHHM.Individual_ID
    LEFT OUTER JOIN SRC_COMPAS_D.Employer_Household CEHH
       ON CHHM.Household_ID = CEHH.Household_ID
    LEFT OUTER JOIN SRC_COMPAS_D.Employer CE
       ON CEHH.Employer_ID = CE.Employer_ID
    LEFT OUTER JOIN SRC_COMPAS_D.Kit_Request CKR
       ON CIP.Individual_ID = CKR.Individual_ID
    LEFT OUTER JOIN SRC_COMPAS_D.Application_Waivers CAW
       ON A.Application_ID = CAW.Application_ID
    LEFT OUTER JOIN
    SRC_COMPAS_D.Subsidized_Insured_Plan CSIP
       ON     CIP.Insured_Plan_ID =
                 CSIP.Insured_Plan_ID
          AND CIP.Insured_Plan_Effective_Date BETWEEN CSIP.Subsidized_Ins_Plan_Start_Date
                        AND CSIP.Subsidized_Ins_Plan_Stop_Date
                        WHERE A.Appl_Receipt_Date >= ''2016-01-01'')
                WHERE     Decision = ''Employer''
                      AND (   InsApp IS NULL
 OR (    InsApp IS NOT NULL
     AND Insured_Plan_Effective_Date BETWEEN Emp_HHOLD_Start_Date
               AND Emp_HHOLD_Stop_Date
     AND Insured_Plan_Effective_Date BETWEEN Employer_Effective_Date
               AND NVL (
                      Employer_Close_Date,
                      TO_DATE (
                         ''9999-12-31'',
                         ''YYYY-MM-DD'')))))
              SOURCE
           ON (TARGET.ApplicationID = SOURCE.Application_ID)
   WHEN MATCHED
   THEN
      UPDATE SET Employer = ''Y''
   WHEN NOT MATCHED
   THEN
      INSERT     (ApplicationID, Employer)
          VALUES (source.Application_ID, ''Y'');
		  
		  
		  
		   MERGE INTO BDR_DM.WRK_ACQUISITIONCHANNEL target
        USING (  SELECT application_id,
                        MAX ( CASE    WHEN marketing_channel = ''DIRECT-TO-CONSUMER'' AND campaign_type = ''DIRECT''    THEN       ''Y'' END) directmarketing,
                        MAX ( CASE    WHEN marketing_channel = ''DIRECT-TO-CONSUMER'' AND campaign_type = ''ADVERTISING/INQUIRY''    THEN       ''Y'' END) inquiry,
                        MAX ( CASE    WHEN marketing_channel = ''DIRECT-TO-CONSUMER'' AND (TRIM (campaign_type) IS NULL OR TRIM (campaign_type) = '''' )    THEN       ''Y'' END) unattributed,
                        MAX ( CASE    WHEN marketing_channel = ''UNKNOWN - PHONE ENROLLMENT KEYCODE'' THEN       ''Y'' END) unknownphoneenrollmentkeycode,
                        MAX ( CASE    WHEN marketing_channel = ''UNKNOWN - WEB ENROLLMENT KEYCODE'' THEN       ''Y'' END) unknownwebenrollmentkeycode,
                        MAX ( CASE    WHEN marketing_channel = ''UNKNOWN - INVALID KEYCODE'' THEN ''Y'' END) unknowninvalidkeycode,
                        MAX ( CASE    WHEN marketing_channel = ''UNKNOWN - SYSTEM GENERATED KEYCODE''   THEN       ''Y'' END) unknownsystemgeneratedkeycode,
                        MAX ( CASE    WHEN marketing_channel = ''UNKNOWN - AGENT ENROLLMENT KEYCODE'' THEN       ''Y'' END) unknownagentenrollmentkeycode,
                        MAX ( CASE    WHEN marketing_channel = ''UNKNOWN OTHER'' THEN ''Y'' END) unknownother
                   FROM (SELECT ca.Application_ID,      sar.marketing_channel,      sar.campaign_type
 FROM SRC_COMPAS_D.application ca,
      BDR_SMART.application sa,
      BDR_SMART.application_reporting sar
                          WHERE     ca.appl_receipt_date >= ''2016-01-01''  
      AND ca.application_id =             sa.source_application_id
      AND sa.application_id = sar.application_id
                         UNION
                         SELECT ca.Application_ID,      sar.marketing_channel,      sar.campaign_type
 FROM SRC_COMPAS_D.application ca,
      SRC_COMPAS_D.insured_plan cip,
      BDR_SMART.insured_plan sip,
      BDR_SMART.application_reporting sar
                          WHERE     ca.appl_receipt_date >= ''2016-01-01''
      AND ca.application_id = cip.application_id
      AND cip.insured_plan_id =             sip.source_insured_plan_id
      AND sip.application_id = sar.application_id)
                  WHERE    (    marketing_channel = ''DIRECT-TO-CONSUMER''  AND campaign_type = ''DIRECT'')
                        OR (    marketing_channel = ''DIRECT-TO-CONSUMER''  AND campaign_type = ''ADVERTISING/INQUIRY'')
                        OR (    marketing_channel = ''DIRECT-TO-CONSUMER''  AND  (TRIM (campaign_type) IS NULL OR TRIM (campaign_type) = '''' )            )
                        OR marketing_channel IN (''UNKNOWN - PHONE ENROLLMENT KEYCODE'',
                       ''UNKNOWN - WEB ENROLLMENT KEYCODE'',
                       ''UNKNOWN - INVALID KEYCODE'',
                       ''UNKNOWN - SYSTEM GENERATED KEYCODE'',
                       ''UNKNOWN - AGENT ENROLLMENT KEYCODE'',
                       ''UNKNOWN OTHER'')
               GROUP BY application_id) source
           ON (target.applicationid = source.application_id)
   WHEN MATCHED
   THEN
      UPDATE SET
         target.directmarketing                 = source.directmarketing,
         target.inquiry                         = source.inquiry,
         target.unattributed                    = source.unattributed,
         target.unknownphoneenrollmentkeycode   = source.unknownphoneenrollmentkeycode,
         target.unknownwebenrollmentkeycode     = source.unknownwebenrollmentkeycode,
         target.unknowninvalidkeycode           = source.unknowninvalidkeycode,
         target.unknownsystemgeneratedkeycode   = source.unknownsystemgeneratedkeycode,
         target.unknownagentenrollmentkeycode   = source.unknownagentenrollmentkeycode,
         target.unknownother                    = source.unknownother
   WHEN NOT MATCHED
   THEN
      INSERT     (applicationid,
                  directmarketing,
                  inquiry,
                  unattributed,
                  unknownphoneenrollmentkeycode,
                  unknownwebenrollmentkeycode,
                  unknowninvalidkeycode,
                  unknownsystemgeneratedkeycode,
                  unknownagentenrollmentkeycode,
                  unknownother)
          VALUES (source.application_id,
                  source.directmarketing,
                  source.inquiry,
                  source.unattributed,
                  source.unknownphoneenrollmentkeycode,
                  source.unknownwebenrollmentkeycode,
                  source.unknowninvalidkeycode,
                  source.unknownsystemgeneratedkeycode,
                  source.unknownagentenrollmentkeycode,
                  source.unknownother);
				  
				  
				  MERGE INTO BDR_DM.WRK_ACQUISITIONCHANNEL
   USING (SELECT 1 FROM DUAL) D
   ON (1=1)
   WHEN MATCHED THEN
   UPDATE
      SET AcquisitionChannel = CASE WHEN Agent = ''Y'' AND Aggregator = ''Y'' AND Employer = ''Y'' THEN ''Aggregator/Employer''
                                                                                  WHEN Agent = ''R'' AND Aggregator = ''R'' AND Employer = ''Y'' THEN ''Aggregator Referral/Employer''
										  WHEN Agent = ''Y'' AND Aggregator = ''Y'' AND Employer IS NULL THEN ''Aggregator''
										  WHEN Agent = ''R'' AND Aggregator = ''R'' AND Employer IS NULL THEN ''Aggregator Referral''
										  WHEN Agent = ''Y'' AND Aggregator IS NULL AND Employer = ''Y'' THEN ''Agent/Employer''
										  WHEN Agent = ''R'' AND Aggregator IS NULL AND Employer = ''Y'' THEN ''Agent Referral/Employer''
										  WHEN Agent = ''Y'' AND Aggregator IS NULL AND Employer IS NULL THEN ''Agent''
										  WHEN Agent = ''R'' AND Aggregator IS NULL AND Employer IS NULL THEN ''Agent Referral''
										  WHEN Agent IS NULL AND Aggregator IS NULL AND Employer = ''Y'' THEN ''Employer''
										  WHEN DirectMarketing = ''Y'' THEN ''Direct Marketing''
										  WHEN Inquiry = ''Y'' THEN ''Inquiry''
										  WHEN Unattributed = ''Y'' THEN ''Unattributed''
										  WHEN UnknownPhoneEnrollmentKeyCode = ''Y'' THEN ''Unknown - Phone Enrollment Key Code''
										  WHEN UnknownWebEnrollmentKeyCode = ''Y'' THEN ''Unknown - Web Enrollment Key Code''
										  WHEN UnknownInvalidKeyCode = ''Y'' THEN ''Unknown - Invalid Key Code''
										  WHEN UnknownSystemGeneratedKeyCode = ''Y'' THEN ''Unknown - System Generated Key Code''
										  WHEN UnknownAgentEnrollmentKeyCode = ''Y'' THEN ''Unknown - Agent Enrollment Key Code''
										  WHEN UnknownOther = ''Y'' THEN ''Unknown Other''
										  ELSE ''UNKNOWN''
									  END;








CALL UTIL.SP_ETL_CHECK_CONSTRAINTS(:DB_NAME , :APPLICATION , :WORKFLOW_NAME , :OBJECT_NAME , :V_BATCH_ID );


UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''COMPLETE'', ERROR_MSG = null, BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
; 

UPDATE  UTIL.ETL_BATCH_OBJECT_INCR_VALU SET INCR_COLUMN_VALUE = :V_BATCH_ID, LST_MOD_DT = CURRENT_TIMESTAMP() WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID''; 

EXCEPTION

WHEN OTHER THEN


UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''ERROR'', ERROR_MSG = :SQLERRM,  BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
;



INSERT INTO  UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ERROR_MSG, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''ERROR'', :V_STEP_NAME, :V_STEP_SEQ, :SQLERRM, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() )
;



RAISE;
    
		
		
END;

';