USE SCHEMA BDR_CONF; CREATE OR REPLACE PROCEDURE "SP_CONFORMEDDIMENSIONS_IXL_INSUREDPLANSALECHANNEL_D"("DB_NAME" VARCHAR(16777216), "APPLICATION" VARCHAR(16777216), "WORKFLOW_NAME" VARCHAR(16777216), "OBJECT_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '
DECLARE
---Commented by OAS JNIKAM--------------
/*
CREATE OR REPLACE PROCEDURE DM."SP_CONFDIM_INSPLANSALECHNL_D" (
    p_RecordExists       IN     NUMBER,
    P_ToContinueStatus      OUT VARCHAR2,
    P_ErrorYNFlg            OUT VARCHAR2,
    P_ErrorStr              OUT VARCHAR2)
AS
    V_PROC_NAME    VARCHAR (50) := ''''''''''''''''''''''''''''''''SP_CONFDIM_INSPLANSALECHNL_D'''''''''''''''''''''''''''''''';

    V_ROWS_AFFTD   NUMBER (20) := 0;

    V_BTCH_ID      NUMBER (10);
BEGIN
    SELECT MAX (BATCH_ID)
      INTO V_BTCH_ID
      FROM ETL.ETL_BATCH_LOG
     WHERE APPLICATION = ''''''''''''''''''''''''''''''''CDC'''''''''''''''''''''''''''''''' AND BATCH_STATUS = ''''''''''''''''''''''''''''''''COMPLETE'''''''''''''''''''''''''''''''';
*/

---Commented by OAS JNIKAM

V_ROWS_INSERTED  INTEGER;
V_ROWS_UPDATED INTEGER;
V_ROWS_DELETED INTEGER;
V_LAST_QUERY_ID VARCHAR;

V_WH VARCHAR;
V_BATCH_ID INTEGER;
V_ETL_LST_BTCH_ID INTEGER;

V_BATCH_OBJECT_START_TIME        VARCHAR;
V_STEP_START_TIME    VARCHAR;
V_STEP_NAME VARCHAR;
V_STEP_SEQ INTEGER DEFAULT 0;



BEGIN

EXECUTE IMMEDIATE ''USE DATABASE ''||:DB_NAME; 

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_BATCH_OBJECT_START_TIME := (SELECT CURRENT_TIMESTAMP());


LET res1 RESULTSET := 
(

SELECT 

WH ,
BATCH_ID
  
FROM UTIL.ETL_BATCH_OBJECT_CONTROL
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
FETCH FIRST 1 ROW ONLY

)
;


LET C1 CURSOR FOR res1;
open C1;
FETCH C1 into  V_WH,V_BATCH_ID ;
close C1;





EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:V_WH;
USE SCHEMA BDR_CONF;

INSERT INTO UTIL.ETL_BATCH_OBJECT_INCR_VALU (APPLICATION, WORKFLOW_NAME, OBJECT_NAME, INCR_COLUMN, INCR_COLUMN_VALUE )
SELECT * FROM 
(select :APPLICATION AS APPLICATION, :WORKFLOW_NAME AS WORKFLOW_NAME, :OBJECT_NAME AS OBJECT_NAME, ''ETL_LST_BTCH_ID'' AS INCR_COLUMN, -1 AS INCR_COLUMN_VALUE) A
WHERE NOT EXISTS (SELECT 1 FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU B WHERE B.APPLICATION = A.APPLICATION AND B.WORKFLOW_NAME = A.WORKFLOW_NAME AND B.OBJECT_NAME = A.OBJECT_NAME AND B.INCR_COLUMN = A.INCR_COLUMN)
;
V_ETL_LST_BTCH_ID := (SELECT INCR_COLUMN_VALUE FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID'');  



V_STEP_NAME    := ''TARGET - INSERT WRK_IP_SALE_CHANNEL'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

CREATE OR REPLACE TRANSIENT TABLE BDR_DM.WRK_IP_SALE_CHANNEL (INSUREDPLANID INTEGER,
                    SALE_CHNL_LVL_1 VARCHAR,
                    SALE_CHNL_LVL_2 VARCHAR,
                    SALE_CHNL_LVL_3 VARCHAR)
					
					AS 
					
					
					select 
					
					SOURCE.insured_plan_id,
                    ''Agent'',
                    SOURCE.LEVEL2,
                    SOURCE.LEVEL3
					
					FROM 
					
 (SELECT DISTINCT
                       WA.AGENT,
                       wa.insured_plan_id,
                       wa.application_id,
                       a.appl_actor_id,
                       am.application_mechanism_id,
                       ac.contact_type_id,
                       A.VENDOR_CODE,
                       OAD.PHONE_ENROLLMENT_TYPE_ID,
                       UPPER (OAD.SIGNATURE_SUBMISSION),
                       CASE
                           WHEN     WA.AGENT = ''Y''
                                AND ac.contact_type_id = 1
                                AND am.application_mechanism_id = 2
                           THEN
                               ''Electronic''
                           WHEN     WA.AGENT = ''Y''
                                AND ac.contact_type_id = 3
                                AND am.application_mechanism_id = 1
                           THEN
                               ''Mail''
                           WHEN     WA.AGENT = ''Y''
                                AND ac.contact_type_id = 10
                                AND am.application_mechanism_id = 2
                           THEN
                               ''OLE''
                           WHEN     WA.AGENT = ''Y''
                                AND ac.contact_type_id = 1
                                AND OAD.PHONE_ENROLLMENT_TYPE_ID != ''Y''
                                AND am.application_mechanism_id = 2
                           THEN
                               ''Phone''
                           ELSE
                               ''Other''
                       END    LEVEL2,
                       CASE
                           WHEN     WA.AGENT = ''Y''
                                AND ac.contact_type_id = 1
                                AND am.application_mechanism_id = 2
                                AND NVL (UPPER (OAD.SIGNATURE_SUBMISSION),
                                         '' '') !=
                                    ''SECURITYQUESTION''
                           THEN
                               ''Electronic''
                           WHEN     WA.AGENT = ''Y''
                                AND ac.contact_type_id = 1
                                AND am.application_mechanism_id = 2
                                AND NVL (UPPER (OAD.SIGNATURE_SUBMISSION),
                                         '' '') =
                                    ''SECURITYQUESTION''
                           THEN
                               ''Security Question''
                           WHEN     WA.AGENT = ''Y''
                                AND ac.contact_type_id = 3
                                AND am.application_mechanism_id = 1
                           THEN
                               ''Traditional - Mail''
                           WHEN     WA.AGENT = ''Y''
                                AND ac.contact_type_id = 10
                                AND am.application_mechanism_id = 2
                                AND NVL (UPPER (OAD.SIGNATURE_SUBMISSION),
                                         '' '') =
                                    ''SECURITYQUESTION''
                           THEN
                               ''Security Question''
                           WHEN     WA.AGENT = ''Y''
                                AND ac.contact_type_id = 10
                                AND am.application_mechanism_id = 2
                                AND NVL (UPPER (OAD.SIGNATURE_SUBMISSION),
                                         '' '') !=
                                    ''SECURITYQUESTION''
                                AND A.VENDOR_CODE IS NOT NULL
                           THEN
                               ''External Partners''
                           WHEN     WA.AGENT = ''Y''
                                AND ac.contact_type_id = 10
                                AND am.application_mechanism_id = 2
                                AND NVL (UPPER (OAD.SIGNATURE_SUBMISSION),
                                         '' '') !=
                                    ''SECURITYQUESTION''
                                AND A.VENDOR_CODE IS NULL
                           THEN
                               ''Traditional - OLE''
                           WHEN     WA.AGENT = ''Y''
                                AND ac.contact_type_id = 1
                                AND OAD.PHONE_ENROLLMENT_TYPE_ID != ''Y''
                                AND am.application_mechanism_id = 2
                           THEN
                               ''Phone''
                           ELSE
                               ''Other''
                       END    LEVEL3
                  FROM (SELECT /*+ PARALLEL(8) */
                               INSURED_PLAN_ID, Application_ID, ''Y'' AS Agent
                          FROM (SELECT A.Application_ID, IP.INSURED_PLAN_ID
                                  FROM SRC_COMPAS_D.INSURED_PLAN  IP
                                       INNER JOIN SRC_COMPAS_D.APPLICATION A
                                           ON IP.Application_ID =
                                              A.Application_ID
                                 WHERE A.Appl_Actor_ID = 3
                                UNION
                                SELECT A.Application_ID, IP.INSURED_PLAN_ID
                                  FROM SRC_COMPAS_D.APPLICATION_AGENT  AA
                                       INNER JOIN SRC_COMPAS_D.INSURED_PLAN IP
                                           ON IP.Application_ID =
                                              AA.Application_ID
                                       INNER JOIN SRC_COMPAS_D.APPLICATION A
                                           ON IP.Application_ID =
                                              A.Application_ID
                                UNION
                                SELECT A.Application_ID, IP.INSURED_PLAN_ID
                                  FROM SRC_COMPAS_D.INSURED_PLAN  IP
                                       INNER JOIN SRC_COMPAS_D.APPLICATION A
                                           ON IP.Application_ID =
                                              A.Application_ID
                                 WHERE A.Hash_CD = ''2460720307''
                                UNION
                                SELECT A.Application_ID, IP.INSURED_PLAN_ID
                                  FROM SRC_COMPAS_D.APPLICATION_INDICATOR  AI
                                       INNER JOIN SRC_COMPAS_D.INSURED_PLAN IP
                                           ON IP.Application_ID =
                                              AI.Application_ID
                                       INNER JOIN SRC_COMPAS_D.APPLICATION A
                                           ON IP.Application_ID =
                                              A.Application_ID
                                 WHERE AI.Selling_Agent_Signature_Ind = ''Y''))
                       wa
                       INNER JOIN SRC_COMPAS_D.application a
                           ON wa.application_id = a.application_id
                       INNER JOIN SRC_COMPAS_D.application_actor aa
                           ON a.APPL_ACTOR_ID = aa.APPLICATION_ACTOR_ID
                       INNER JOIN SRC_COMPAS_D.application_mechanism am
                           ON a.APPL_MECHANISM_ID =
                              am.APPLICATION_MECHANISM_ID
                       INNER JOIN SRC_COMPAS_D.CONTACT_HIST_CONTACT_TYPE ac
                           ON a.APPL_CHANNEL_ID = ac.contact_type_id
                       LEFT OUTER JOIN
                       (  SELECT app.APPLICATION_ID,
                                 MAX (dtl.PHONE_ENROLLMENT_TYPE_ID)
                                     PHONE_ENROLLMENT_TYPE_ID,
                                 MAX (dtl.SIGNATURE_SUBMISSION)
                                     SIGNATURE_SUBMISSION
                            FROM SRC_COMPAS_D.OLE_APPLICATION_DETAIL_ATTR dtl,
                                 SRC_COMPAS_D.OLE_APPLICATION       app
                           WHERE dtl.OLE_APPLICATION_ID =
                                 app.OLE_APPLICATION_ID
                        GROUP BY app.APPLICATION_ID) OAD
                           ON WA.APPLICATION_ID = OAD.APPLICATION_ID
                 WHERE (wa.agent = ''Y'')
				 
				 ) source
            
			;
			

---Commented by OAS JNIKAM--------------
/*
    V_ROWS_AFFTD := SQL%ROWCOUNT;



    INSERT INTO ETL.ETL_DETAIL_LOAD_INFO (APPLICATION,
                                          ETL_BATCH_ID,
                                          ETL_PROC_NAME,
                                          ACTION,
                                          STEP_INFO,
                                          ROWS_AFFECTED,
                                          ETL_DATETIME)
         VALUES (''CONFORMED_DIMENSIONS'',
                 V_BTCH_ID,
                 V_PROC_NAME,
                 ''MERGE'',
                 ''MERGE Referral Agent INTO BDR_DM.WRK_IP_SALE_CHANNEL '',
                 V_ROWS_AFFTD,
                 SYSTIMESTAMP);

    COMMIT;



    BDR_DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS (''DM'', ''WRK_IP_SALE_CHANNEL'');

*/
---Commented by OAS JNIKAM--------------



V_ROWS_INSERTED := (SELECT count(1) FROM BDR_DM.WRK_IP_SALE_CHANNEL );





INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );	


V_STEP_NAME    := ''TARGET - MERGE WRK_IP_SALE_CHANNEL'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

    ------eAllianceRetail------

    ----AGENT_TYPE_DESC = ''Referral Agent''  agent_char_type_id = 4(aggregator)

    MERGE INTO BDR_DM.WRK_IP_SALE_CHANNEL target
         USING (SELECT DISTINCT
                       S1.INSURED_PLAN_ID,
                       S1.APPLICATION_ID,
                       S1.SOURCE_ACQN_CHNL_LVL_1,
                       S1.SOURCE_ACQN_CHNL_LVL_2,
                       CASE
                           WHEN S1.SOURCE_ACQN_CHNL_LVL_2 = ''Electronic''
                           THEN
                               (CASE
                                    WHEN NVL (
                                             UPPER (S1.SIGNATURE_SUBMISSION),
                                             '' '') =
                                         ''SECURITYQUESTION''
                                    THEN
                                        ''Security Question''
                                    ELSE
                                        ''Electronic''
                                END)
                           WHEN S1.SOURCE_ACQN_CHNL_LVL_2 = ''Mail''
                           THEN
                               ''Traditional - Mail''
                           WHEN S1.SOURCE_ACQN_CHNL_LVL_2 = ''OLE''
                           THEN
                               (CASE
                                    WHEN S1.VENDOR_CODE IS NOT NULL
                                    THEN
                                        ''External Partners''
                                    WHEN (    S1.APPL_ACTOR_ID = ''3''
                                          AND S1.CONTACT_TYPE_DESC = ''WEB''
                                          AND S1.APPL_MECHANISM_DESCRIPTION =
                                              ''WEB''
                                          AND NVL (
                                                  UPPER (
                                                      S1.SIGNATURE_SUBMISSION),
                                                  '' '') =
                                              ''SECURITYQUESTION''
                                          AND S1.VENDOR_CODE IS NULL)
                                    THEN
                                        ''Security Question''
                                    ELSE
                                        ''Traditional - OLE''
                                END)
                           WHEN S1.SOURCE_ACQN_CHNL_LVL_2 = ''Phone''
                           THEN
                               ''Optum CSS''
                           ELSE
                               ''Other''
                       END    AS SOURCE_ACQN_CHNL_LVL_3
                  FROM (SELECT DISTINCT
                               IP.INSURED_PLAN_ID,
                               aa.application_id,
                               a.appl_actor_id,
                               aa.agent_id,
                               am.APPL_MECHANISM_DESCRIPTION,
                               ct.CONTACT_TYPE_DESC,
                               OAD.PHONE_ENROLLMENT_TYPE_ID,
                               OAD.SIGNATURE_SUBMISSION,
                               a.VENDOR_CODE,
                               CASE
                                   WHEN     a.APPL_ACTOR_ID = ''2''
                                        AND ct.CONTACT_TYPE_DESC =
                                            ''PHONE (IN)''
                                        AND am.APPL_MECHANISM_DESCRIPTION =
                                            ''WEB''
                                        AND NVL (
                                                OAD.PHONE_ENROLLMENT_TYPE_ID,
                                                '' '') <>
                                            ''Y''
                                   THEN
                                       ''Phone''
                                   WHEN     a.APPL_ACTOR_ID = ''3''
                                        AND ct.CONTACT_TYPE_DESC =
                                            ''PHONE (IN)''
                                        AND am.APPL_MECHANISM_DESCRIPTION =
                                            ''WEB''
                                   THEN
                                       ''Electronic''
                                   WHEN     ct.CONTACT_TYPE_DESC =
                                            ''WRITTEN MAIL''
                                        AND am.APPL_MECHANISM_DESCRIPTION =
                                            ''MAIL''
                                   THEN
                                       ''Mail''
                                   WHEN (   (    a.APPL_ACTOR_ID = ''1''
                                             AND ct.CONTACT_TYPE_DESC = ''WEB''
                                             AND am.APPL_MECHANISM_DESCRIPTION =
                                                 ''WEB''
                                             AND a.VENDOR_CODE IS NULL
                                             AND NVL (
                                                     UPPER (
                                                         OAD.SIGNATURE_SUBMISSION),
                                                     '' '') <>
                                                 ''SECURITYQUESTION'')
                                         OR (    a.APPL_ACTOR_ID = ''3''
                                             AND ct.CONTACT_TYPE_DESC = ''WEB''
                                             AND am.APPL_MECHANISM_DESCRIPTION =
                                                 ''WEB''))
                                   THEN
                                       ''OLE''
                                   ELSE
                                       ''Other''
                               END                   AS SOURCE_ACQN_CHNL_LVL_2,
                               ''eAlliance Retail''    AS SOURCE_ACQN_CHNL_LVL_1
                          FROM SRC_COMPAS_D.application_agent  aa
                               INNER JOIN SRC_COMPAS_D.agent_char ac
                                   ON aa.agent_id = ac.agent_id
                               INNER JOIN SRC_COMPAS_D.AGENT_TYPE atp
                                   ON aa.AGENT_TYPE_ID = atp.AGENT_TYPE_ID
                               INNER JOIN SRC_COMPAS_D.application a
                                   ON a.application_id = aa.application_id
                               INNER JOIN SRC_COMPAS_D.insured_plan ip
                                   ON ip.Application_ID = a.Application_ID
                               INNER JOIN SRC_COMPAS_D.APPLICATION_MECHANISM am
                                   ON am.APPLICATION_MECHANISM_ID =
                                      a.APPL_MECHANISM_ID
                               INNER JOIN SRC_COMPAS_D.CONTACT_HIST_CONTACT_TYPE ct
                                   ON ct.CONTACT_TYPE_ID = a.APPL_CHANNEL_ID
                               LEFT OUTER JOIN
                               (  SELECT app.APPLICATION_ID,
                                         MAX (dtl.PHONE_ENROLLMENT_TYPE_ID)
                                             PHONE_ENROLLMENT_TYPE_ID,
                                         MAX (dtl.SIGNATURE_SUBMISSION)
                                             SIGNATURE_SUBMISSION
                                    FROM SRC_COMPAS_D.OLE_APPLICATION_DETAIL_ATTR dtl,
                                         SRC_COMPAS_D.OLE_APPLICATION       app
                                   WHERE dtl.OLE_APPLICATION_ID =
                                         app.OLE_APPLICATION_ID
                                GROUP BY app.APPLICATION_ID) OAD
                                   ON A.APPLICATION_ID = OAD.APPLICATION_ID
                         WHERE   --atp.AGENT_TYPE_DESC = ''Referral Agent''  AND
                                   ac.agent_char_type_id = 4
                               AND (   (aa.agent_id NOT IN
                                            (SELECT agent_id
                                               FROM BDR_DM.acqn_chnl_agt_lst
                                              WHERE     AGENT_TYPE =
                                                        ''Referral Agent''
                                                    AND channel_type =
                                                        ''eAlliance Retail'')) ---Instead of hardcode values take it from static  table for selling agent
                                    OR (aa.agent_id NOT IN
                                            (SELECT agent_id
                                               FROM BDR_DM.acqn_chnl_agt_lst
                                              WHERE     AGENT_TYPE =
                                                        ''Selling Agent''
                                                    AND channel_type =
                                                        ''eAlliance Retail''))))
                       S1) source
            ON (target.INSUREDPLANID = source.INSURED_PLAN_ID)
    WHEN MATCHED
    THEN
        UPDATE SET
            SALE_CHNL_LVL_1 = SOURCE_ACQN_CHNL_LVL_1,
            SALE_CHNL_LVL_2 = SOURCE_ACQN_CHNL_LVL_2,
            SALE_CHNL_LVL_3 = SOURCE_ACQN_CHNL_LVL_3
    WHEN NOT MATCHED
    THEN
        INSERT     (INSUREDPLANID,
                    SALE_CHNL_LVL_1,
                    SALE_CHNL_LVL_2,
                    SALE_CHNL_LVL_3)
            VALUES (source.Application_ID,
                    source.SOURCE_ACQN_CHNL_LVL_1,
                    source.SOURCE_ACQN_CHNL_LVL_2,
                    source.SOURCE_ACQN_CHNL_LVL_3);



---Commented by OAS JNIKAM--------------
/*
    V_ROWS_AFFTD := SQL%ROWCOUNT;

    INSERT INTO ETL.ETL_DETAIL_LOAD_INFO (APPLICATION,
                                          ETL_BATCH_ID,
                                          ETL_PROC_NAME,
                                          ACTION,
                                          STEP_INFO,
                                          ROWS_AFFECTED,
                                          ETL_DATETIME)
         VALUES (''CONFORMED_DIMENSIONS'',
                 V_BTCH_ID,
                 V_PROC_NAME,
                 ''MERGE'',
                 ''MERGE Refferal Agent INTO WRK_IP_SALE_CHANNEL '',
                 V_ROWS_AFFTD,
                 SYSTIMESTAMP);

    COMMIT;

    BDR_DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS (''DM'', ''WRK_IP_SALE_CHANNEL'');
*/
---Commented by OAS JNIKAM--------------

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

V_ROWS_UPDATED := (SELECT $2 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );	



INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );	


V_STEP_NAME    := ''TARGET - MERGE WRK_IP_SALE_CHANNEL'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

    -----eAllianceClassic----

    --AGENT_TYPE_DESC = ''Referral Agent''  agent_char_type_id = 4(aggregator)---

    MERGE INTO BDR_DM.WRK_IP_SALE_CHANNEL target   --where ACQN_CHNL_LVL_1=''Agent''
         USING (SELECT DISTINCT
                       S1.INSURED_PLAN_ID,
                       APPLICATION_ID,
                       SOURCE_ACQN_CHNL_LVL_1,
                       SOURCE_ACQN_CHNL_LVL_2,
                       CASE
                           WHEN S1.SOURCE_ACQN_CHNL_LVL_2 = ''Electronic''
                           THEN
                               (CASE
                                    WHEN NVL (
                                             UPPER (S1.SIGNATURE_SUBMISSION),
                                             '' '') =
                                         ''SECURITYQUESTION''
                                    THEN
                                        ''Security Question''
                                    ELSE
                                        ''Electronic''
                                END)
                           WHEN S1.SOURCE_ACQN_CHNL_LVL_2 = ''Mail''
                           THEN
                               ''Traditional - Mail''
                           WHEN S1.SOURCE_ACQN_CHNL_LVL_2 = ''OLE''
                           THEN
                               (CASE
                                    WHEN S1.VENDOR_CODE IS NOT NULL
                                    THEN
                                        ''External Partners''
                                    WHEN (    S1.APPL_ACTOR_ID = ''3''
                                          AND S1.CONTACT_TYPE_DESC = ''WEB''
                                          AND S1.APPL_MECHANISM_DESCRIPTION =
                                              ''WEB''
                                          AND NVL (
                                                  UPPER (
                                                      S1.SIGNATURE_SUBMISSION),
                                                  '' '') =
                                              ''SECURITYQUESTION''
                                          AND S1.VENDOR_CODE IS NULL)
                                    THEN
                                        ''Security Question''
                                    ELSE
                                        ''Traditional - OLE''
                                END)
                           WHEN S1.SOURCE_ACQN_CHNL_LVL_2 = ''Phone''
                           THEN
                               ''Optum CSS''
                           ELSE
                               ''Other''
                       END    AS SOURCE_ACQN_CHNL_LVL_3
                  FROM (SELECT DISTINCT
                               IP.INSURED_PLAN_ID,
                               aa.application_id,
                               a.appl_actor_id,
                               aa.agent_id,
                               am.APPL_MECHANISM_DESCRIPTION,
                               ct.CONTACT_TYPE_DESC,
                               OAD.PHONE_ENROLLMENT_TYPE_ID,
                               OAD.SIGNATURE_SUBMISSION,
                               a.VENDOR_CODE,
                               CASE
                                   WHEN     a.APPL_ACTOR_ID = ''2''
                                        AND ct.CONTACT_TYPE_DESC =
                                            ''PHONE (IN)''
                                        AND am.APPL_MECHANISM_DESCRIPTION =
                                            ''WEB''
                                        AND NVL (
                                                OAD.PHONE_ENROLLMENT_TYPE_ID,
                                                '' '') <>
                                            ''Y''
                                   THEN
                                       ''Phone''
                                   WHEN     a.APPL_ACTOR_ID = ''3''
                                        AND ct.CONTACT_TYPE_DESC =
                                            ''PHONE (IN)''
                                        AND am.APPL_MECHANISM_DESCRIPTION =
                                            ''WEB''
                                   THEN
                                       ''Electronic''
                                   WHEN     ct.CONTACT_TYPE_DESC =
                                            ''WRITTEN MAIL''
                                        AND am.APPL_MECHANISM_DESCRIPTION =
                                            ''MAIL''
                                   THEN
                                       ''Mail''
                                   WHEN (   (    a.APPL_ACTOR_ID = ''1''
                                             AND ct.CONTACT_TYPE_DESC = ''WEB''
                                             AND am.APPL_MECHANISM_DESCRIPTION =
                                                 ''WEB''
                                             AND a.VENDOR_CODE IS NULL
                                             AND NVL (
                                                     UPPER (
                                                         OAD.SIGNATURE_SUBMISSION),
                                                     '' '') <>
                                                 ''SECURITYQUESTION'')
                                         OR (    a.APPL_ACTOR_ID = ''3''
                                             AND ct.CONTACT_TYPE_DESC = ''WEB''
                                             AND am.APPL_MECHANISM_DESCRIPTION =
                                                 ''WEB''))
                                   THEN
                                       ''OLE''
                                   ELSE
                                       ''Other''
                               END                    AS SOURCE_ACQN_CHNL_LVL_2,
                               ''eAlliance Classic''    AS SOURCE_ACQN_CHNL_LVL_1
                          FROM SRC_COMPAS_D.application_agent  aa
                               INNER JOIN SRC_COMPAS_D.agent_char ac
                                   ON aa.agent_id = ac.agent_id
                               INNER JOIN SRC_COMPAS_D.AGENT_TYPE atp
                                   ON aa.AGENT_TYPE_ID = atp.AGENT_TYPE_ID
                               INNER JOIN SRC_COMPAS_D.application a
                                   ON a.application_id = aa.application_id
                               INNER JOIN SRC_COMPAS_D.insured_plan ip
                                   ON ip.Application_ID = a.Application_ID
                               INNER JOIN SRC_COMPAS_D.APPLICATION_MECHANISM am
                                   ON am.APPLICATION_MECHANISM_ID =
                                      a.APPL_MECHANISM_ID
                               INNER JOIN SRC_COMPAS_D.CONTACT_HIST_CONTACT_TYPE ct
                                   ON ct.CONTACT_TYPE_ID = a.APPL_CHANNEL_ID
                               LEFT OUTER JOIN
                               (  SELECT app.APPLICATION_ID,
                                         MAX (dtl.PHONE_ENROLLMENT_TYPE_ID)
                                             PHONE_ENROLLMENT_TYPE_ID,
                                         MAX (dtl.SIGNATURE_SUBMISSION)
                                             SIGNATURE_SUBMISSION
                                    FROM SRC_COMPAS_D.OLE_APPLICATION_DETAIL_ATTR dtl,
                                         SRC_COMPAS_D.OLE_APPLICATION       app
                                   WHERE dtl.OLE_APPLICATION_ID =
                                         app.OLE_APPLICATION_ID
                                GROUP BY app.APPLICATION_ID) OAD
                                   ON A.APPLICATION_ID = OAD.APPLICATION_ID
                         WHERE    --atp.AGENT_TYPE_DESC = ''Referral Agent'' AND
                                   ac.agent_char_type_id = 4
                               AND (   (aa.agent_id IN
                                            (SELECT agent_id
                                               FROM BDR_DM.acqn_chnl_agt_lst
                                              WHERE     AGENT_TYPE =
                                                        ''Selling Agent''
                                                    AND channel_type =
                                                        ''eAlliance Classic''))
                                    OR (aa.agent_id IN
                                            (SELECT agent_id
                                               FROM BDR_DM.acqn_chnl_agt_lst
                                              WHERE     AGENT_TYPE =
                                                        ''Referral Agent''
                                                    AND channel_type =
                                                        ''eAlliance Classic''))))
                       S1) source
            ON (target.INSUREDPLANID = source.INSURED_PLAN_ID)
    WHEN MATCHED
    THEN
        UPDATE SET
            SALE_CHNL_LVL_1 = source.SOURCE_ACQN_CHNL_LVL_1,
            SALE_CHNL_LVL_2 = source.SOURCE_ACQN_CHNL_LVL_2,
            SALE_CHNL_LVL_3 = source.SOURCE_ACQN_CHNL_LVL_3
    WHEN NOT MATCHED
    THEN
        INSERT     (INSUREDPLANID,
                    SALE_CHNL_LVL_1,
                    SALE_CHNL_LVL_2,
                    SALE_CHNL_LVL_3)
            VALUES (source.INSURED_PLAN_ID,
                    source.SOURCE_ACQN_CHNL_LVL_1,
                    source.SOURCE_ACQN_CHNL_LVL_2,
                    source.SOURCE_ACQN_CHNL_LVL_3);

 
---Commented by OAS JNIKAM--------------
/*

    V_ROWS_AFFTD := SQL%ROWCOUNT;

    INSERT INTO ETL.ETL_DETAIL_LOAD_INFO (APPLICATION,
                                          ETL_BATCH_ID,
                                          ETL_PROC_NAME,
                                          ACTION,
                                          STEP_INFO,
                                          ROWS_AFFECTED,
                                          ETL_DATETIME)
         VALUES (''CONFORMED_DIMENSIONS'',
                 V_BTCH_ID,
                 V_PROC_NAME,
                 ''MERGE'',
                 ''MERGE1 INTO WRK_SALE_CHANNEL '',
                 V_ROWS_AFFTD,
                 SYSTIMESTAMP);

    BDR_DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS (''DM'', ''WRK_IP_SALE_CHANNEL'');
*/
---Commented by OAS JNIKAM--------------


V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

V_ROWS_UPDATED := (SELECT $2 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );		

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );	


V_STEP_NAME    := ''TARGET - MERGE WRK_IP_SALE_CHANNEL'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

    --eAllianceClassic

    --AGENT_TYPE_DESC = ''Referral Agent''  agent_char_type_id <> 4(aggregator) and agent_char_type_id IN (1,2,3) AND agent_id<>''SOFTASI1''

    MERGE INTO BDR_DM.WRK_IP_SALE_CHANNEL target
         USING (SELECT DISTINCT
                       insured_plan_id,
                       APPLICATION_ID,
                       SOURCE_ACQN_CHNL_LVL_1,
                       SOURCE_ACQN_CHNL_LVL_2,
                       CASE
                           WHEN S1.SOURCE_ACQN_CHNL_LVL_2 = ''Electronic''
                           THEN
                               (CASE
                                    WHEN NVL (
                                             UPPER (S1.SIGNATURE_SUBMISSION),
                                             '' '') =
                                         ''SECURITYQUESTION''
                                    THEN
                                        ''Security Question''
                                    ELSE
                                        ''Electronic''
                                END)
                           WHEN S1.SOURCE_ACQN_CHNL_LVL_2 = ''Mail''
                           THEN
                               ''Traditional - Mail''
                           WHEN S1.SOURCE_ACQN_CHNL_LVL_2 = ''OLE''
                           THEN
                               (CASE
                                    WHEN S1.VENDOR_CODE IS NOT NULL
                                    THEN
                                        ''External Partners''
                                    WHEN (    S1.APPL_ACTOR_ID = ''3''
                                          AND S1.CONTACT_TYPE_DESC = ''WEB''
                                          AND S1.APPL_MECHANISM_DESCRIPTION =
                                              ''WEB''
                                          AND NVL (
                                                  UPPER (
                                                      S1.SIGNATURE_SUBMISSION),
                                                  '' '') =
                                              ''SECURITYQUESTION''
                                          AND S1.VENDOR_CODE IS NULL)
                                    THEN
                                        ''Security Question''
                                    ELSE
                                        ''Traditional - OLE''
                                END)
                           WHEN S1.SOURCE_ACQN_CHNL_LVL_2 = ''Phone''
                           THEN
                               ''Optum CSS''
                           ELSE
                               ''Other''
                       END    AS SOURCE_ACQN_CHNL_LVL_3
                  FROM (SELECT DISTINCT
                               ip.insured_plan_id,
                               aa.application_id,
                               a.appl_actor_id,
                               aa.agent_id,
                               am.APPL_MECHANISM_DESCRIPTION,
                               ct.CONTACT_TYPE_DESC,
                               OAD.PHONE_ENROLLMENT_TYPE_ID,
                               OAD.SIGNATURE_SUBMISSION,
                               a.VENDOR_CODE,
                               CASE
                                   WHEN     a.APPL_ACTOR_ID = ''2''
                                        AND ct.CONTACT_TYPE_DESC =
                                            ''PHONE (IN)''
                                        AND am.APPL_MECHANISM_DESCRIPTION =
                                            ''WEB''
                                        AND NVL (
                                                OAD.PHONE_ENROLLMENT_TYPE_ID,
                                                '' '') <>
                                            ''Y''
                                   THEN
                                       ''Phone''
                                   WHEN     a.APPL_ACTOR_ID = ''3''
                                        AND ct.CONTACT_TYPE_DESC =
                                            ''PHONE (IN)''
                                        AND am.APPL_MECHANISM_DESCRIPTION =
                                            ''WEB''
                                   THEN
                                       ''Electronic''
                                   WHEN     ct.CONTACT_TYPE_DESC =
                                            ''WRITTEN MAIL''
                                        AND am.APPL_MECHANISM_DESCRIPTION =
                                            ''MAIL''
                                   THEN
                                       ''Mail''
                                   WHEN (   (    a.APPL_ACTOR_ID = ''1''
                                             AND ct.CONTACT_TYPE_DESC = ''WEB''
                                             AND am.APPL_MECHANISM_DESCRIPTION =
                                                 ''WEB''
                                             AND a.VENDOR_CODE IS NULL
                                             AND NVL (
                                                     UPPER (
                                                         OAD.SIGNATURE_SUBMISSION),
                                                     '' '') <>
                                                 ''SECURITYQUESTION'')
                                         OR (    a.APPL_ACTOR_ID = ''3''
                                             AND ct.CONTACT_TYPE_DESC = ''WEB''
                                             AND am.APPL_MECHANISM_DESCRIPTION =
                                                 ''WEB''))
                                   THEN
                                       ''OLE''
                                   ELSE
                                       ''Other''
                               END                    AS SOURCE_ACQN_CHNL_LVL_2,
                               ''eAlliance Classic''    AS SOURCE_ACQN_CHNL_LVL_1
                          FROM SRC_COMPAS_D.application_agent  aa
                               INNER JOIN SRC_COMPAS_D.agent_char ac
                                   ON aa.agent_id = ac.agent_id
                               INNER JOIN SRC_COMPAS_D.AGENT_TYPE atp
                                   ON aa.AGENT_TYPE_ID = atp.AGENT_TYPE_ID
                               INNER JOIN SRC_COMPAS_D.application a
                                   ON a.application_id = aa.application_id
                               INNER JOIN SRC_COMPAS_D.insured_plan ip
                                   ON a.application_id = ip.application_id
                               INNER JOIN SRC_COMPAS_D.APPLICATION_MECHANISM am
                                   ON am.APPLICATION_MECHANISM_ID =
                                      a.APPL_MECHANISM_ID
                               INNER JOIN SRC_COMPAS_D.CONTACT_HIST_CONTACT_TYPE ct
                                   ON ct.CONTACT_TYPE_ID = a.APPL_CHANNEL_ID
                               LEFT OUTER JOIN
                               (  SELECT app.APPLICATION_ID,
                                         MAX (dtl.PHONE_ENROLLMENT_TYPE_ID)
                                             PHONE_ENROLLMENT_TYPE_ID,
                                         MAX (dtl.SIGNATURE_SUBMISSION)
                                             SIGNATURE_SUBMISSION
                                    FROM SRC_COMPAS_D.OLE_APPLICATION_DETAIL_ATTR dtl,
                                         SRC_COMPAS_D.OLE_APPLICATION       app
                                   WHERE dtl.OLE_APPLICATION_ID =
                                         app.OLE_APPLICATION_ID
                                GROUP BY app.APPLICATION_ID) OAD
                                   ON A.APPLICATION_ID = OAD.APPLICATION_ID
                         WHERE   -- atp.AGENT_TYPE_DESC = ''Referral Agent'' AND
                                   aa.application_id NOT IN
                                       (SELECT DISTINCT aa.application_id
                                          FROM SRC_COMPAS_D.application_agent  aa
                                               INNER JOIN
                                               SRC_COMPAS_D.agent_char ac
                                                   ON aa.agent_id =
                                                      ac.agent_id
                                               INNER JOIN
                                               SRC_COMPAS_D.AGENT_TYPE atp
                                                   ON aa.AGENT_TYPE_ID =
                                                      atp.AGENT_TYPE_ID
                                         WHERE     atp.AGENT_TYPE_DESC =
                                                   ''Referral Agent''
                                               AND ac.agent_char_type_id =
                                                   ''4'')
                               AND NVL (aa.agent_id, ''123'') <> ''SOFTASI1''
                               AND (   (aa.agent_id IN
                                            (SELECT agent_id
                                               FROM BDR_DM.acqn_chnl_agt_lst
                                              WHERE     AGENT_TYPE =
                                                        ''Referral Agent''
                                                    AND channel_type =
                                                        ''eAlliance Classic''))
                                    OR (aa.agent_id IN
                                            (SELECT agent_id
                                               FROM BDR_DM.acqn_chnl_agt_lst
                                              WHERE     AGENT_TYPE =
                                                        ''Selling Agent''
                                                    AND channel_type =
                                                        ''eAlliance Classic''))))
                       S1) source
            ON (target.INSUREDPLANID = source.INSURED_PLAN_ID)
    WHEN MATCHED
    THEN
        UPDATE SET
            SALE_CHNL_LVL_1 = source.SOURCE_ACQN_CHNL_LVL_1,
            SALE_CHNL_LVL_2 = source.SOURCE_ACQN_CHNL_LVL_2,
            SALE_CHNL_LVL_3 = source.SOURCE_ACQN_CHNL_LVL_3
    WHEN NOT MATCHED
    THEN
        INSERT     (INSUREDPLANID,
                    SALE_CHNL_LVL_1,
                    SALE_CHNL_LVL_2,
                    SALE_CHNL_LVL_3)
            VALUES (source.INSURED_PLAN_ID,
                    source.SOURCE_ACQN_CHNL_LVL_1,
                    source.SOURCE_ACQN_CHNL_LVL_2,
                    source.SOURCE_ACQN_CHNL_LVL_3);



---Commented by OAS JNIKAM--------------
/*
    V_ROWS_AFFTD := SQL%ROWCOUNT;

    INSERT INTO ETL.ETL_DETAIL_LOAD_INFO (APPLICATION,
                                          ETL_BATCH_ID,
                                          ETL_PROC_NAME,
                                          ACTION,
                                          STEP_INFO,
                                          ROWS_AFFECTED,
                                          ETL_DATETIME)
         VALUES (''CONFORMED_DIMENSIONS'',
                 V_BTCH_ID,
                 V_PROC_NAME,
                 ''MERGE'',
                 ''MERGE Referral Aggregator INTO WRK_IP_SALE_CHANNEL'',
                 V_ROWS_AFFTD,
                 SYSTIMESTAMP);

    COMMIT;
    BDR_DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS (''DM'', ''WRK_IP_SALE_CHANNEL'');
*/
---Commented by OAS JNIKAM--------------


V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

V_ROWS_UPDATED := (SELECT $2 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );	



INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );	


V_STEP_NAME    := ''TARGET - MERGE WRK_IP_SALE_CHANNEL'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

    ---GRS----

    MERGE INTO BDR_DM.WRK_IP_SALE_CHANNEL TARGET
         USING (SELECT s1.insured_plan_id,
                       S1.APPLICATION_ID,
                       ''GRS''     AS SOURCE_ACQN_CHNL_LVL_1,
                       S2.SOURCE_ACQN_CHNL_LVL_2,
                       S2.SOURCE_ACQN_CHNL_LVL_3
                  FROM (SELECT DISTINCT A.application_id, CIP.INSURED_PLAN_ID
                          FROM SRC_COMPAS_D.application  A
                               INNER JOIN SRC_COMPAS_D.Insured_Plan CIP
                                   ON A.Application_ID = CIP.Application_ID
                               LEFT OUTER JOIN SRC_COMPAS_D.Household_Member CHHM
                                   ON CIP.Individual_ID = CHHM.Individual_ID
                               LEFT OUTER JOIN SRC_COMPAS_D.Employer_Household CEHH
                                   ON CHHM.Household_ID = CEHH.Household_ID
                         WHERE CIP.Insured_Plan_Effective_Date BETWEEN CEHH.Emp_HHOLD_Start_Date
                                                                   AND CEHH.Emp_HHOLD_Stop_Date--AND A.Appl_Receipt_Date >= TO_DATE(V_CUTTOFDATE,''DD-MON-YYYY'')
                                                                                               )
                       S1
                       INNER JOIN
                       (SELECT s3.insured_plan_id,
                               S3.APPLICATION_ID,
                               S3.PHONE_ENROLLMENT_TYPE_ID,
                               S3.SOURCE_ACQN_CHNL_LVL_2,
                               S3.SIGNATURE_SUBMISSION,
                               S3.VENDOR_CODE,
                               CASE
                                   WHEN S3.SOURCE_ACQN_CHNL_LVL_2 =
                                        ''Electronic''
                                   THEN
                                       (CASE
                                            WHEN NVL (
                                                     UPPER (
                                                         S3.SIGNATURE_SUBMISSION),
                                                     '' '') =
                                                 ''SECURITYQUESTION''
                                            THEN
                                                ''Security Question''
                                            ELSE
                                                ''Electronic''
                                        END)
                                   WHEN S3.SOURCE_ACQN_CHNL_LVL_2 = ''Mail''
                                   THEN
                                       ''Traditional - Mail''
                                   WHEN S3.SOURCE_ACQN_CHNL_LVL_2 = ''OLE''
                                   THEN
                                       (CASE
                                            WHEN S3.VENDOR_CODE IS NOT NULL
                                            THEN
                                                ''External Partners''
                                            WHEN (    S3.APPL_ACTOR_ID = ''3''
                                                  AND S3.CONTACT_TYPE_DESC =
                                                      ''WEB''
                                                  AND S3.APPL_MECHANISM_DESCRIPTION =
                                                      ''WEB''
                                                  AND NVL (
                                                          UPPER (
                                                              S3.SIGNATURE_SUBMISSION),
                                                          '' '') =
                                                      ''SECURITYQUESTION'')
                                            THEN
                                                ''Security Question''
                                            ELSE
                                                ''Traditional - OLE''
                                        END)
                                   WHEN S3.SOURCE_ACQN_CHNL_LVL_2 = ''Phone''
                                   THEN
                                       ''Optum CSS''
                                   ELSE
                                       ''Other''
                               END    AS SOURCE_ACQN_CHNL_LVL_3
                          FROM (SELECT DISTINCT
                                       ip.insured_plan_id,
                                       a.application_id,
                                       a.appl_actor_id,
                                       am.APPL_MECHANISM_DESCRIPTION,
                                       ct.CONTACT_TYPE_DESC,
                                       OAD.PHONE_ENROLLMENT_TYPE_ID,
                                       OAD.SIGNATURE_SUBMISSION,
                                       a.VENDOR_CODE,
                                       CASE
                                           WHEN     a.APPL_ACTOR_ID = ''2''
                                                AND ct.CONTACT_TYPE_DESC =
                                                    ''PHONE (IN)''
                                                AND am.APPL_MECHANISM_DESCRIPTION =
                                                    ''WEB''
                                                AND NVL (
                                                        OAD.PHONE_ENROLLMENT_TYPE_ID,
                                                        '' '') <>
                                                    ''Y''
                                           THEN
                                               ''Phone''
                                           WHEN     a.APPL_ACTOR_ID = ''3''
                                                AND ct.CONTACT_TYPE_DESC =
                                                    ''PHONE (IN)''
                                                AND am.APPL_MECHANISM_DESCRIPTION =
                                                    ''WEB''
                                           THEN
                                               ''Electronic''
                                           WHEN     ct.CONTACT_TYPE_DESC =
                                                    ''WRITTEN MAIL''
                                                AND am.APPL_MECHANISM_DESCRIPTION =
                                                    ''MAIL''
                                           THEN
                                               ''Mail''
                                           WHEN (   (    a.APPL_ACTOR_ID =
                                                         ''1''
                                                     AND ct.CONTACT_TYPE_DESC =
                                                         ''WEB''
                                                     AND am.APPL_MECHANISM_DESCRIPTION =
                                                         ''WEB''
                                                     AND a.VENDOR_CODE
                                                             IS NULL)
                                                 OR (    a.APPL_ACTOR_ID =
                                                         ''3''
                                                     AND ct.CONTACT_TYPE_DESC =
                                                         ''WEB''
                                                     AND am.APPL_MECHANISM_DESCRIPTION =
                                                         ''WEB''))
                                           THEN
                                               ''OLE''
                                           ELSE
                                               ''Other''
                                       END    AS SOURCE_ACQN_CHNL_LVL_2
                                  FROM -- SRC_COMPAS_D.application_agent aa
                                       --               INNER JOIN SRC_COMPAS_D.agent_char ac
                                       --               ON aa.agent_id = ac.agent_id
                                       -- INNER JOIN SRC_COMPAS_D.AGENT_TYPE atp
                                       -- ON aa.AGENT_TYPE_ID = atp.AGENT_TYPE_ID
                                       --INNER JOIN
                                       SRC_COMPAS_D.application  a
                                       --  ON a.application_id = aa.application_id
                                       INNER JOIN SRC_COMPAS_D.insured_plan ip
                                           ON ip.application_id =
                                              a.application_id
                                       INNER JOIN
                                       SRC_COMPAS_D.APPLICATION_MECHANISM am
                                           ON am.APPLICATION_MECHANISM_ID =
                                              a.APPL_MECHANISM_ID
                                       INNER JOIN
                                       SRC_COMPAS_D.CONTACT_HIST_CONTACT_TYPE ct
                                           ON ct.CONTACT_TYPE_ID =
                                              a.APPL_CHANNEL_ID
                                       LEFT OUTER JOIN
                                       (  SELECT app.APPLICATION_ID,
                                                 MAX (
                                                     dtl.PHONE_ENROLLMENT_TYPE_ID)
                                                     PHONE_ENROLLMENT_TYPE_ID,
                                                 MAX (dtl.SIGNATURE_SUBMISSION)
                                                     SIGNATURE_SUBMISSION
                                            FROM SRC_COMPAS_D.OLE_APPLICATION_DETAIL_ATTR
                                                 dtl,
                                                 SRC_COMPAS_D.OLE_APPLICATION app
                                           WHERE dtl.OLE_APPLICATION_ID =
                                                 app.OLE_APPLICATION_ID
                                        GROUP BY app.APPLICATION_ID) OAD
                                           ON A.APPLICATION_ID =
                                              OAD.APPLICATION_ID) S3) S2
                           ON S1.INSURED_PLAN_ID = S2.INSURED_PLAN_ID
                 WHERE S1.INSURED_PLAN_ID NOT IN
                           (SELECT INSUREDPLANID FROM BDR_DM.WRK_IP_SALE_CHANNEL))
               source
            ON (target.INSUREDPLANID = source.INSURED_PLAN_ID)
    WHEN MATCHED
    THEN
        UPDATE SET
            SALE_CHNL_LVL_1 = source.SOURCE_ACQN_CHNL_LVL_1,
            SALE_CHNL_LVL_2 = source.SOURCE_ACQN_CHNL_LVL_2,
            SALE_CHNL_LVL_3 = source.SOURCE_ACQN_CHNL_LVL_3
    WHEN NOT MATCHED
    THEN
        INSERT     (INSUREDPLANID,
                    SALE_CHNL_LVL_1,
                    SALE_CHNL_LVL_2,
                    SALE_CHNL_LVL_3)
            VALUES (source.INSURED_PLAN_ID,
                    source.SOURCE_ACQN_CHNL_LVL_1,
                    source.SOURCE_ACQN_CHNL_LVL_2,
                    source.SOURCE_ACQN_CHNL_LVL_3);



---Commented by OAS JNIKAM--------------
/*
    V_ROWS_AFFTD := SQL%ROWCOUNT;

    INSERT INTO ETL.ETL_DETAIL_LOAD_INFO (APPLICATION,
                                          ETL_BATCH_ID,
                                          ETL_PROC_NAME,
                                          ACTION,
                                          STEP_INFO,
                                          ROWS_AFFECTED,
                                          ETL_DATETIME)
         VALUES (''CONFORMED_DIMENSIONS'',
                 V_BTCH_ID,
                 V_PROC_NAME,
                 ''MERGE'',
                 ''MERGE4 INTO WRK_IP_SALE_CHANNEL '',
                 V_ROWS_AFFTD,
                 SYSTIMESTAMP);

    --Returns the result set
    P_ToContinueStatus := ''Y'';
    P_ErrorYNFlg := ''N'';
    P_ErrorStr := '';

    INSERT INTO ETL.ETL_DETAIL_LOAD_INFO (APPLICATION,
                                          ETL_BATCH_ID,
                                          ETL_PROC_NAME,
                                          ACTION,
                                          STEP_INFO,
                                          ROWS_AFFECTED,
                                          ETL_DATETIME)
         VALUES (''CONFORMED_DIMENSIONS'',
                 V_BTCH_ID,
                 V_PROC_NAME,
                 ''END,'',
                 ''PROCEDURE ENDS '',
                 V_ROWS_AFFTD,
                 SYSTIMESTAMP);

    COMMIT;
	*/
---Commented by OAS JNIKAM--------------


V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

V_ROWS_UPDATED := (SELECT $2 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );		


INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );	


V_STEP_NAME    := ''TARGET - MERGE WRK_IP_SALE_CHANNEL'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;
    ---DTC

    MERGE INTO BDR_DM.WRK_IP_SALE_CHANNEL target
         USING (SELECT DISTINCT
                       SD1.INSURED_PLAN_ID,
                       SD1.APPLICATION_ID,
                       SD1.SOURCE_ACQN_CHNL_LVL_1,
                       SD1.SOURCE_ACQN_CHNL_LVL_2,
                       CASE
                           WHEN SD1.SOURCE_ACQN_CHNL_LVL_2 = ''Electronic''
                           THEN
                               (CASE
                                    WHEN NVL (
                                             UPPER (SD1.SIGNATURE_SUBMISSION),
                                             '' '') =
                                         ''SECURITYQUESTION''
                                    THEN
                                        ''Security Question''
                                    ELSE
                                        ''Electronic''
                                END)
                           WHEN SD1.SOURCE_ACQN_CHNL_LVL_2 = ''Mail''
                           THEN
                               ''Traditional - Mail''
                           WHEN SD1.SOURCE_ACQN_CHNL_LVL_2 = ''OLE''
                           THEN
                               (CASE
                                    WHEN SD1.VENDOR_CODE IS NOT NULL
                                    THEN
                                        ''External Partners''
                                    WHEN (    SD1.APPL_ACTOR_ID = ''3''
                                          AND SD1.CONTACT_TYPE_DESC = ''WEB''
                                          AND SD1.APPL_MECHANISM_DESCRIPTION =
                                              ''WEB''
                                          AND NVL (
                                                  UPPER (
                                                      SD1.SIGNATURE_SUBMISSION),
                                                  '' '') =
                                              ''SECURITYQUESTION''
                                          AND SD1.VENDOR_CODE IS NULL)
                                    THEN
                                        ''Security Question''
                                    ELSE
                                        ''Traditional - OLE''
                                END)
                           WHEN SD1.SOURCE_ACQN_CHNL_LVL_2 = ''Phone''
                           THEN
                               ''Optum CSS''
                           ELSE
                               ''Other''
                       END    AS SOURCE_ACQN_CHNL_LVL_3
                  FROM (SELECT DISTINCT
                               IP.INSURED_PLAN_ID,
                               d2.application_id,
                               D2.appl_actor_id,                --aa.agent_id,
                               am.APPL_MECHANISM_DESCRIPTION,
                               ct.CONTACT_TYPE_DESC,
                               OAD.PHONE_ENROLLMENT_TYPE_ID,
                               OAD.SIGNATURE_SUBMISSION,
                               D2.VENDOR_CODE,
                               CASE
                                   WHEN     D2.APPL_ACTOR_ID = ''2''
                                        AND ct.CONTACT_TYPE_DESC =
                                            ''PHONE (IN)''
                                        AND am.APPL_MECHANISM_DESCRIPTION =
                                            ''WEB''
                                        AND NVL (
                                                OAD.PHONE_ENROLLMENT_TYPE_ID,
                                                '' '') <>
                                            ''Y''
                                   THEN
                                       ''Phone''
                                   WHEN     D2.APPL_ACTOR_ID = ''3''
                                        AND ct.CONTACT_TYPE_DESC =
                                            ''PHONE (IN)''
                                        AND am.APPL_MECHANISM_DESCRIPTION =
                                            ''WEB''
                                   THEN
                                       ''Electronic''
                                   WHEN     ct.CONTACT_TYPE_DESC =
                                            ''WRITTEN MAIL''
                                        AND am.APPL_MECHANISM_DESCRIPTION =
                                            ''MAIL''
                                   THEN
                                       ''Mail''
                                   WHEN (   (    D2.APPL_ACTOR_ID = ''1''
                                             AND ct.CONTACT_TYPE_DESC = ''WEB''
                                             AND am.APPL_MECHANISM_DESCRIPTION =
                                                 ''WEB''
                                             AND D2.VENDOR_CODE IS NULL
                                             AND NVL (
                                                     UPPER (
                                                         OAD.SIGNATURE_SUBMISSION),
                                                     '' '') <>
                                                 ''SECURITYQUESTION'')
                                         OR (    D2.APPL_ACTOR_ID = ''3''
                                             AND ct.CONTACT_TYPE_DESC = ''WEB''
                                             AND am.APPL_MECHANISM_DESCRIPTION =
                                                 ''WEB''))
                                   THEN
                                       ''OLE''
                                   ELSE
                                       ''Other''
                               END      AS SOURCE_ACQN_CHNL_LVL_2,
                               ''DTC''    AS SOURCE_ACQN_CHNL_LVL_1
                          FROM (SELECT D1.APPLICATION_ID,
                                       D1.APPL_MECHANISM_ID,
                                       D1.APPL_CHANNEL_ID,
                                       D1.APPL_actor_id,
                                       D1.vendor_code
                                  FROM (SELECT ca.Application_ID,
                                               sar.marketing_channel,
                                               sar.campaign_type,
                                               ca.APPL_MECHANISM_ID,
                                               ca.APPL_CHANNEL_ID,
                                               ca.appl_actor_id,
                                               ca.vendor_code
                                          FROM SRC_COMPAS_D.application  ca,
                                               BDR_SMART.application   sa,
                                               BDR_SMART.application_reporting
                                               sar
                                         WHERE     ca.application_id =
                                                   sa.source_application_id
                                               AND sa.application_id =
                                                   sar.application_id
                                        UNION
                                        SELECT ca.Application_ID,
                                               sar.marketing_channel,
                                               sar.campaign_type,
                                               ca.APPL_MECHANISM_ID,
                                               ca.APPL_CHANNEL_ID,
                                               ca.appl_actor_id,
                                               ca.vendor_code
                                          FROM SRC_COMPAS_D.application   ca,
                                               SRC_COMPAS_D.insured_plan  cip,
                                               BDR_SMART.insured_plan   sip,
                                               BDR_SMART.application_reporting
                                               sar
                                         WHERE     ca.application_id =
                                                   cip.application_id
                                               AND cip.insured_plan_id =
                                                   sip.source_insured_plan_id
                                               AND sip.application_id =
                                                   sar.application_id) D1
                                 WHERE (   d1.marketing_channel IN
                                               (''UNKNOWN - PHONE ENROLLMENT KEYCODE'',
                                                ''UNKNOWN - WEB ENROLLMENT KEYCODE'',
                                                ''UNKNOWN - INVALID KEYCODE'',
                                                ''UNKNOWN - SYSTEM GENERATED KEYCODE'',
                                                ''UNKNOWN - AGENT ENROLLMENT KEYCODE'',
                                                ''UNKNOWN OTHER'')
                                        OR (    d1.marketing_channel =
                                                ''DIRECT-TO-CONSUMER''
                                            AND (   campaign_type IN  (''DIRECT'',''ADVERTISING/INQUIRY'')  OR TRIM (campaign_type)  IS NULL  OR TRIM (campaign_type)  = ''''             )))) D2
                               --INNER JOIN SRC_COMPAS_D.application_agent aa
                               -- ON D2.application_id = aa.application_id
                               INNER JOIN SRC_COMPAS_D.insured_plan ip
                                   ON D2.APPLICATION_ID = IP.APPLICATION_ID
                               --   INNER JOIN SRC_COMPAS_D.agent_char ac
                               --   ON aa.agent_id = ac.agent_id
                               --INNER JOIN SRC_COMPAS_D.AGENT_TYPE atp
                               --ON aa.AGENT_TYPE_ID = atp.AGENT_TYPE_ID
                               INNER JOIN SRC_COMPAS_D.APPLICATION_MECHANISM am
                                   ON am.APPLICATION_MECHANISM_ID =
                                      D2.APPL_MECHANISM_ID
                               INNER JOIN SRC_COMPAS_D.CONTACT_HIST_CONTACT_TYPE ct
                                   ON ct.CONTACT_TYPE_ID = D2.APPL_CHANNEL_ID
                               LEFT OUTER JOIN
                               (  SELECT app.APPLICATION_ID,
                                         MAX (dtl.PHONE_ENROLLMENT_TYPE_ID)
                                             PHONE_ENROLLMENT_TYPE_ID,
                                         MAX (dtl.SIGNATURE_SUBMISSION)
                                             SIGNATURE_SUBMISSION
                                    FROM SRC_COMPAS_D.OLE_APPLICATION_DETAIL_ATTR dtl,
                                         SRC_COMPAS_D.OLE_APPLICATION       app
                                   WHERE dtl.OLE_APPLICATION_ID =
                                         app.OLE_APPLICATION_ID
                                GROUP BY app.APPLICATION_ID) OAD
                                   ON D2.APPLICATION_ID = OAD.APPLICATION_ID)
                       SD1
                 WHERE SD1.INSURED_PLAN_ID NOT IN
                           (SELECT INSUREDPLANID FROM BDR_DM.WRK_IP_SALE_CHANNEL)
                UNION
                SELECT DISTINCT
                       SD2.INSURED_PLAN_ID,
                       SD2.APPLICATION_ID,
                       SD2.SOURCE_ACQN_CHNL_LVL_1,
                       SD2.SOURCE_ACQN_CHNL_LVL_2,
                       CASE
                           WHEN SD2.SOURCE_ACQN_CHNL_LVL_2 = ''Electronic''
                           THEN
                               (CASE
                                    WHEN NVL (
                                             UPPER (SD2.SIGNATURE_SUBMISSION),
                                             '' '') =
                                         ''SECURITYQUESTION''
                                    THEN
                                        ''Security Question''
                                    ELSE
                                        ''Electronic''
                                END)
                           WHEN SD2.SOURCE_ACQN_CHNL_LVL_2 = ''Mail''
                           THEN
                               ''Traditional - Mail''
                           WHEN SD2.SOURCE_ACQN_CHNL_LVL_2 = ''OLE''
                           THEN
                               (CASE
                                    WHEN SD2.VENDOR_CODE IS NOT NULL
                                    THEN
                                        ''External Partners''
                                    WHEN (    SD2.APPL_ACTOR_ID = ''3''
                                          AND SD2.CONTACT_TYPE_DESC = ''WEB''
                                          AND SD2.APPL_MECHANISM_DESCRIPTION =
                                              ''WEB''
                                          AND NVL (
                                                  UPPER (
                                                      SD2.SIGNATURE_SUBMISSION),
                                                  '' '') =
                                              ''SECURITYQUESTION''
                                          AND SD2.VENDOR_CODE IS NULL)
                                    THEN
                                        ''Security Question''
                                    ELSE
                                        ''Traditional - OLE''
                                END)
                           WHEN SD2.SOURCE_ACQN_CHNL_LVL_2 = ''Phone''
                           THEN
                               ''Optum CSS''
                           ELSE
                               ''Other''
                       END    AS SOURCE_ACQN_CHNL_LVL_3
                  FROM (SELECT DISTINCT
                               ip.insured_plan_id,
                               aa.application_id,
                               a.appl_actor_id,
                               aa.agent_id,
                               am.APPL_MECHANISM_DESCRIPTION,
                               ct.CONTACT_TYPE_DESC,
                               OAD.PHONE_ENROLLMENT_TYPE_ID,
                               OAD.SIGNATURE_SUBMISSION,
                               a.VENDOR_CODE,
                               CASE
                                   WHEN     a.APPL_ACTOR_ID = ''2''
                                        AND ct.CONTACT_TYPE_DESC =
                                            ''PHONE (IN)''
                                        AND am.APPL_MECHANISM_DESCRIPTION =
                                            ''WEB''
                                        AND NVL (
                                                OAD.PHONE_ENROLLMENT_TYPE_ID,
                                                '' '') <>
                                            ''Y''
                                   THEN
                                       ''Phone''
                                   WHEN     a.APPL_ACTOR_ID = ''3''
                                        AND ct.CONTACT_TYPE_DESC =
                                            ''PHONE (IN)''
                                        AND am.APPL_MECHANISM_DESCRIPTION =
                                            ''WEB''
                                   THEN
                                       ''Electronic''
                                   WHEN     ct.CONTACT_TYPE_DESC =
                                            ''WRITTEN MAIL''
                                        AND am.APPL_MECHANISM_DESCRIPTION =
                                            ''MAIL''
                                   THEN
                                       ''Mail''
                                   WHEN (   (    a.APPL_ACTOR_ID = ''1''
                                             AND ct.CONTACT_TYPE_DESC = ''WEB''
                                             AND am.APPL_MECHANISM_DESCRIPTION =
                                                 ''WEB''
                                             AND a.VENDOR_CODE IS NULL
                                             AND NVL (
                                                     UPPER (
                                                         OAD.SIGNATURE_SUBMISSION),
                                                     '' '') <>
                                                 ''SECURITYQUESTION'')
                                         OR (    a.APPL_ACTOR_ID = ''3''
                                             AND ct.CONTACT_TYPE_DESC = ''WEB''
                                             AND am.APPL_MECHANISM_DESCRIPTION =
                                                 ''WEB''))
                                   THEN
                                       ''OLE''
                                   ELSE
                                       ''Other''
                               END      AS SOURCE_ACQN_CHNL_LVL_2,
                               ''DTC''    AS SOURCE_ACQN_CHNL_LVL_1
                          FROM SRC_COMPAS_D.application_agent  aa
                               --               INNER JOIN SRC_COMPAS_D.agent_char ac
                               --                ON aa.agent_id = ac.agent_id
                               INNER JOIN SRC_COMPAS_D.AGENT_TYPE atp
                                   ON aa.AGENT_TYPE_ID = atp.AGENT_TYPE_ID
                               INNER JOIN SRC_COMPAS_D.application a
                                   ON a.application_id = aa.application_id
                               INNER JOIN SRC_COMPAS_D.insured_plan ip
                                   ON a.application_id = ip.application_id
                               INNER JOIN SRC_COMPAS_D.APPLICATION_MECHANISM am
                                   ON am.APPLICATION_MECHANISM_ID =
                                      a.APPL_MECHANISM_ID
                               INNER JOIN SRC_COMPAS_D.CONTACT_HIST_CONTACT_TYPE ct
                                   ON ct.CONTACT_TYPE_ID = a.APPL_CHANNEL_ID
                               LEFT OUTER JOIN
                               (  SELECT app.APPLICATION_ID,
                                         MAX (dtl.PHONE_ENROLLMENT_TYPE_ID)
                                             PHONE_ENROLLMENT_TYPE_ID,
                                         MAX (dtl.SIGNATURE_SUBMISSION)
                                             SIGNATURE_SUBMISSION
                                    FROM SRC_COMPAS_D.OLE_APPLICATION_DETAIL_ATTR dtl,
                                         SRC_COMPAS_D.OLE_APPLICATION       app
                                   WHERE dtl.OLE_APPLICATION_ID =
                                         app.OLE_APPLICATION_ID
                                GROUP BY app.APPLICATION_ID) OAD
                                   ON A.APPLICATION_ID = OAD.APPLICATION_ID
                         WHERE     atp.AGENT_TYPE_DESC = ''Referral Agent''
                               AND aa.application_id NOT IN
                                       (SELECT DISTINCT aa.application_id
                                          FROM SRC_COMPAS_D.application_agent  aa
                                               INNER JOIN
                                               SRC_COMPAS_D.agent_char ac
                                                   ON aa.agent_id =
                                                      ac.agent_id
                                               INNER JOIN
                                               SRC_COMPAS_D.AGENT_TYPE atp
                                                   ON aa.AGENT_TYPE_ID =
                                                      atp.AGENT_TYPE_ID
                                         WHERE     atp.AGENT_TYPE_DESC =
                                                   ''Referral Agent''
                                               AND ac.agent_char_type_id =
                                                   ''4'')
                               AND NVL (aa.agent_id, ''NA'') = ''SOFTASI1'') SD2
                 WHERE SD2.INSURED_PLAN_ID NOT IN
                           (SELECT INSUREDPLANID FROM BDR_DM.WRK_IP_SALE_CHANNEL)
                UNION
                SELECT DISTINCT
                       sd3.insured_plan_id,
                       SD3.APPLICATION_ID,
                       SD3.SOURCE_ACQN_CHNL_LVL_1,
                       SD3.SOURCE_ACQN_CHNL_LVL_2,
                       CASE
                           WHEN SD3.SOURCE_ACQN_CHNL_LVL_2 = ''Electronic''
                           THEN
                               (CASE
                                    WHEN NVL (
                                             UPPER (SD3.SIGNATURE_SUBMISSION),
                                             '' '') =
                                         ''SECURITYQUESTION''
                                    THEN
                                        ''Security Question''
                                    ELSE
                                        ''Electronic''
                                END)
                           WHEN SD3.SOURCE_ACQN_CHNL_LVL_2 = ''Mail''
                           THEN
                               ''Traditional - Mail''
                           WHEN SD3.SOURCE_ACQN_CHNL_LVL_2 = ''OLE''
                           THEN
                               (CASE
                                    WHEN SD3.VENDOR_CODE IS NOT NULL
                                    THEN
                                        ''External Partners''
                                    WHEN (    SD3.APPL_ACTOR_ID = ''3''
                                          AND SD3.CONTACT_TYPE_DESC = ''WEB''
                                          AND SD3.APPL_MECHANISM_DESCRIPTION =
                                              ''WEB''
                                          AND NVL (
                                                  UPPER (
                                                      SD3.SIGNATURE_SUBMISSION),
                                                  '' '') =
                                              ''SECURITYQUESTION''
                                          AND SD3.VENDOR_CODE IS NULL)
                                    THEN
                                        ''Security Question''
                                    ELSE
                                        ''Traditional - OLE''
                                END)
                           WHEN SD3.SOURCE_ACQN_CHNL_LVL_2 = ''Phone''
                           THEN
                               ''Optum CSS''
                           ELSE
                               ''Other''
                       END    AS SOURCE_ACQN_CHNL_LVL_3
                  FROM (SELECT DISTINCT
                               ip.insured_plan_id,
                               ai.application_id,
                               a.appl_actor_id,
                               aa.agent_id,
                               am.APPL_MECHANISM_DESCRIPTION,
                               ct.CONTACT_TYPE_DESC,
                               OAD.PHONE_ENROLLMENT_TYPE_ID,
                               OAD.SIGNATURE_SUBMISSION,
                               a.VENDOR_CODE,
                               CASE
                                   WHEN     a.APPL_ACTOR_ID = ''2''
                                        AND ct.CONTACT_TYPE_DESC =
                                            ''PHONE (IN)''
                                        AND am.APPL_MECHANISM_DESCRIPTION =
                                            ''WEB''
                                        AND NVL (
                                                OAD.PHONE_ENROLLMENT_TYPE_ID,
                                                '' '') <>
                                            ''Y''
                                   THEN
                                       ''Phone''
                                   WHEN     a.APPL_ACTOR_ID = ''3''
                                        AND ct.CONTACT_TYPE_DESC =
                                            ''PHONE (IN)''
                                        AND am.APPL_MECHANISM_DESCRIPTION =
                                            ''WEB''
                                   THEN
                                       ''Electronic''
                                   WHEN     ct.CONTACT_TYPE_DESC =
                                            ''WRITTEN MAIL''
                                        AND am.APPL_MECHANISM_DESCRIPTION =
                                            ''MAIL''
                                   THEN
                                       ''Mail''
                                   WHEN (   (    a.APPL_ACTOR_ID = ''1''
                                             AND ct.CONTACT_TYPE_DESC = ''WEB''
                                             AND am.APPL_MECHANISM_DESCRIPTION =
                                                 ''WEB''
                                             AND a.VENDOR_CODE IS NULL
                                             AND NVL (
                                                     UPPER (
                                                         OAD.SIGNATURE_SUBMISSION),
                                                     '' '') <>
                                                 ''SECURITYQUESTION'')
                                         OR (    a.APPL_ACTOR_ID = ''3''
                                             AND ct.CONTACT_TYPE_DESC = ''WEB''
                                             AND am.APPL_MECHANISM_DESCRIPTION =
                                                 ''WEB''))
                                   THEN
                                       ''OLE''
                                   ELSE
                                       ''Other''
                               END      AS SOURCE_ACQN_CHNL_LVL_2,
                               ''DTC''    AS SOURCE_ACQN_CHNL_LVL_1
                          FROM SRC_COMPAS_D.Application_Indicator  AI
                               INNER JOIN SRC_COMPAS_D.application a
                                   ON ai.application_id = a.application_id
                               INNER JOIN SRC_COMPAS_D.insured_plan ip
                                   ON a.application_id = ip.application_id
                               LEFT JOIN SRC_COMPAS_D.application_agent aa
                                   ON aa.application_id = a.application_id
                               LEFT JOIN SRC_COMPAS_D.APPLICATION_MECHANISM am
                                   ON am.APPLICATION_MECHANISM_ID =
                                      a.APPL_MECHANISM_ID
                               LEFT JOIN SRC_COMPAS_D.CONTACT_HIST_CONTACT_TYPE ct
                                   ON ct.CONTACT_TYPE_ID = a.APPL_CHANNEL_ID
                               LEFT OUTER JOIN
                               (  SELECT app.APPLICATION_ID,
                                         MAX (dtl.PHONE_ENROLLMENT_TYPE_ID)
                                             PHONE_ENROLLMENT_TYPE_ID,
                                         MAX (dtl.SIGNATURE_SUBMISSION)
                                             SIGNATURE_SUBMISSION
                                    FROM SRC_COMPAS_D.OLE_APPLICATION_DETAIL_ATTR dtl,
                                         SRC_COMPAS_D.OLE_APPLICATION       app
                                   WHERE dtl.OLE_APPLICATION_ID =
                                         app.OLE_APPLICATION_ID
                                GROUP BY app.APPLICATION_ID) OAD
                                   ON A.APPLICATION_ID = OAD.APPLICATION_ID
                         WHERE ai.SIGNATURE_IND = ''Y'' AND aa.agent_id IS NULL)
                       SD3
                 WHERE SD3.INSURED_PLAN_ID NOT IN
                           (SELECT INSUREDPLANID FROM BDR_DM.WRK_IP_SALE_CHANNEL)
                UNION
                SELECT DISTINCT
                       SD4.insured_plan_id,
                       SD4.APPLICATION_ID,
                       SD4.SOURCE_ACQN_CHNL_LVL_1,
                       SD4.SOURCE_ACQN_CHNL_LVL_2,
                       CASE
                           WHEN SD4.SOURCE_ACQN_CHNL_LVL_2 = ''Electronic''
                           THEN
                               (CASE
                                    WHEN NVL (
                                             UPPER (SD4.SIGNATURE_SUBMISSION),
                                             '' '') =
                                         ''SECURITYQUESTION''
                                    THEN
                                        ''Security Question''
                                    ELSE
                                        ''Electronic''
                                END)
                           WHEN SD4.SOURCE_ACQN_CHNL_LVL_2 = ''Mail''
                           THEN
                               ''Traditional - Mail''
                           WHEN SD4.SOURCE_ACQN_CHNL_LVL_2 = ''OLE''
                           THEN
                               (CASE
                                    WHEN SD4.VENDOR_CODE IS NOT NULL
                                    THEN
                                        ''External Partners''
                                    WHEN (    SD4.APPL_ACTOR_ID = ''3''
                                          AND SD4.CONTACT_TYPE_DESC = ''WEB''
                                          AND SD4.APPL_MECHANISM_DESCRIPTION =
                                              ''WEB''
                                          AND NVL (
                                                  UPPER (
                                                      SD4.SIGNATURE_SUBMISSION),
                                                  '' '') =
                                              ''SECURITYQUESTION''
                                          AND SD4.VENDOR_CODE IS NULL)
                                    THEN
                                        ''Security Question''
                                    ELSE
                                        ''Traditional - OLE''
                                END)
                           WHEN SD4.SOURCE_ACQN_CHNL_LVL_2 = ''Phone''
                           THEN
                               ''Optum CSS''
                           ELSE
                               ''Other''
                       END    AS SOURCE_ACQN_CHNL_LVL_3
                  FROM (SELECT DISTINCT
                               ip.insured_plan_id,
                               ai.application_id,
                               a.appl_actor_id,
                               aa.agent_id,
                               am.APPL_MECHANISM_DESCRIPTION,
                               ct.CONTACT_TYPE_DESC,
                               OAD.PHONE_ENROLLMENT_TYPE_ID,
                               OAD.SIGNATURE_SUBMISSION,
                               a.VENDOR_CODE,
                               CASE
                                   WHEN     a.APPL_ACTOR_ID = ''2''
                                        AND ct.CONTACT_TYPE_DESC =
                                            ''PHONE (IN)''
                                        AND am.APPL_MECHANISM_DESCRIPTION =
                                            ''WEB''
                                        AND NVL (
                                                OAD.PHONE_ENROLLMENT_TYPE_ID,
                                                '' '') <>
                                            ''Y''
                                   THEN
                                       ''Phone''
                                   WHEN     a.APPL_ACTOR_ID = ''3''
                                        AND ct.CONTACT_TYPE_DESC =
                                            ''PHONE (IN)''
                                        AND am.APPL_MECHANISM_DESCRIPTION =
                                            ''WEB''
                                   THEN
                                       ''Electronic''
                                   WHEN     ct.CONTACT_TYPE_DESC =
                                            ''WRITTEN MAIL''
                                        AND am.APPL_MECHANISM_DESCRIPTION =
                                            ''MAIL''
                                   THEN
                                       ''Mail''
                                   WHEN (   (    a.APPL_ACTOR_ID = ''1''
                                             AND ct.CONTACT_TYPE_DESC = ''WEB''
                                             AND am.APPL_MECHANISM_DESCRIPTION =
                                                 ''WEB''
                                             AND a.VENDOR_CODE IS NULL
                                             AND NVL (
                                                     UPPER (
                                                         OAD.SIGNATURE_SUBMISSION),
                                                     '' '') <>
                                                 ''SECURITYQUESTION'')
                                         OR (    a.APPL_ACTOR_ID = ''3''
                                             AND ct.CONTACT_TYPE_DESC = ''WEB''
                                             AND am.APPL_MECHANISM_DESCRIPTION =
                                                 ''WEB''))
                                   THEN
                                       ''OLE''
                                   ELSE
                                       ''Other''
                               END      AS SOURCE_ACQN_CHNL_LVL_2,
                               ''DTC''    AS SOURCE_ACQN_CHNL_LVL_1
                          FROM SRC_COMPAS_D.Application_Indicator  AI
                               INNER JOIN SRC_COMPAS_D.application a
                                   ON ai.application_id = a.application_id
                               INNER JOIN SRC_COMPAS_D.insured_plan ip
                                   ON a.application_id = ip.application_id
                               LEFT JOIN SRC_COMPAS_D.application_agent aa
                                   ON aa.application_id = a.application_id
                               LEFT JOIN SRC_COMPAS_D.APPLICATION_MECHANISM am
                                   ON am.APPLICATION_MECHANISM_ID =
                                      a.APPL_MECHANISM_ID
                               LEFT JOIN SRC_COMPAS_D.CONTACT_HIST_CONTACT_TYPE ct
                                   ON ct.CONTACT_TYPE_ID = a.APPL_CHANNEL_ID
                               LEFT OUTER JOIN
                               (  SELECT app.APPLICATION_ID,
                                         MAX (dtl.PHONE_ENROLLMENT_TYPE_ID)
                                             PHONE_ENROLLMENT_TYPE_ID,
                                         MAX (dtl.SIGNATURE_SUBMISSION)
                                             SIGNATURE_SUBMISSION
                                    FROM SRC_COMPAS_D.OLE_APPLICATION_DETAIL_ATTR dtl,
                                         SRC_COMPAS_D.OLE_APPLICATION       app
                                   WHERE dtl.OLE_APPLICATION_ID =
                                         app.OLE_APPLICATION_ID
                                GROUP BY app.APPLICATION_ID) OAD
                                   ON A.APPLICATION_ID = OAD.APPLICATION_ID
                         WHERE (   (aa.agent_id IN
                                        (SELECT agent_id
                                           FROM BDR_DM.acqn_chnl_agt_lst
                                          WHERE     AGENT_TYPE =
                                                    ''Referral Agent''
                                                AND channel_type = ''DTC''))
                                OR (aa.agent_id IN
                                        (SELECT agent_id
                                           FROM BDR_DM.acqn_chnl_agt_lst
                                          WHERE     AGENT_TYPE =
                                                    ''Selling Agent''
                                                AND channel_type = ''DTC''))))
                       SD4) source
            ON (target.INSUREDPLANID = source.INSURED_PLAN_ID)
    WHEN MATCHED
    THEN
        UPDATE SET
            SALE_CHNL_LVL_1 = source.SOURCE_ACQN_CHNL_LVL_1,
            SALE_CHNL_LVL_2 = source.SOURCE_ACQN_CHNL_LVL_2,
            SALE_CHNL_LVL_3 = source.SOURCE_ACQN_CHNL_LVL_3
    WHEN NOT MATCHED
    THEN
        INSERT     (INSUREDPLANID,
                    SALE_CHNL_LVL_1,
                    SALE_CHNL_LVL_2,
                    SALE_CHNL_LVL_3)
            VALUES (source.INSURED_PLAN_ID,
                    source.SOURCE_ACQN_CHNL_LVL_1,
                    source.SOURCE_ACQN_CHNL_LVL_2,
                    source.SOURCE_ACQN_CHNL_LVL_3);



---Commented by OAS JNIKAM--------------
/*
    V_ROWS_AFFTD := SQL%ROWCOUNT;

    INSERT INTO ETL.ETL_DETAIL_LOAD_INFO (APPLICATION,
                                          ETL_BATCH_ID,
                                          ETL_PROC_NAME,
                                          ACTION,
                                          STEP_INFO,
                                          ROWS_AFFECTED,
                                          ETL_DATETIME)
         VALUES (''CONFORMED_DIMENSIONS'',
                 V_BTCH_ID,
                 V_PROC_NAME,
                 ''MERGE'',
                 ''MERGE2 INTO WRK_IP_SALE_CHANNEL '',
                 V_ROWS_AFFTD,
                 SYSTIMESTAMP);
*/
---Commented by OAS JNIKAM--------------

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

V_ROWS_UPDATED := (SELECT $2 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );		


INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );	


V_STEP_NAME    := ''TARGET - MERGE WRK_IP_SALE_CHANNEL'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

    ------smart dtc------


    MERGE INTO BDR_DM.WRK_IP_SALE_CHANNEL target
         USING (SELECT DISTINCT IP.INSURED_PLAN_ID,
                                ''DTC''       SOURCE_ACQN_CHNL_LVL_1,
                                ''Other''     SOURCE_ACQN_CHNL_LVL_2,
                                ''Other''     SOURCE_ACQN_CHNL_LVL_3
                  FROM SRC_COMPAS_D.INSURED_PLAN  IP
                       LEFT JOIN SRC_COMPAS_D.APPLICATION A
                           ON A.APPLICATION_ID = IP.Application_ID
                       INNER JOIN BDR_SMART.INSURED_PLAN SIP
                           ON IP.INSURED_PLAN_ID = SIP.Source_INSURED_PLAN_ID
                       JOIN BDR_SMART.APPLICATION_REPORTING SAR
                           ON SIP.Application_ID = SAR.Application_ID
                 WHERE     A.APPLICATION_ID IS NULL
                       AND (   (    marketing_channel = ''DIRECT-TO-CONSUMER''
                                AND campaign_type = ''DIRECT'')
                            OR (    marketing_channel = ''DIRECT-TO-CONSUMER''
                                AND campaign_type = ''ADVERTISING/INQUIRY'')
                            OR (    marketing_channel = ''DIRECT-TO-CONSUMER''
                                AND (TRIM (campaign_type) IS NULL  OR  TRIM (campaign_type) = '''' )             )
                            OR marketing_channel IN
                                   (''UNKNOWN - PHONE ENROLLMENT KEYCODE'',
                                    ''UNKNOWN - WEB ENROLLMENT KEYCODE'',
                                    ''UNKNOWN - INVALID KEYCODE'',
                                    ''UNKNOWN - SYSTEM GENERATED KEYCODE'',
                                    ''UNKNOWN - AGENT ENROLLMENT KEYCODE'',
                                    ''UNKNOWN OTHER'',
                                    ''AGENT - NON AGGREGATOR'',
                                    ''AGENT'',
                                    ''AGENT/EMPLOYER'',
                                    ''AGENT - DESTINATIONRX'',
                                    ''AGENT - EHEALTH'',
                                    ''AGENT - EXTEND_HEALTH'',
                                    ''AGENT - INSURACTIVE'',
                                    ''AGENT - MERCER'',
                                    ''AGENT - MYCUSTOM_HEALTH'',
                                    ''AGENT - SELECTQUOTE_SENIOR'',
                                    ''AGENT - SENIOR_EDUCATORS'',
                                    ''AGENT - SENIOR_MARKET_SALES_(SMS)'',
                                    ''AGENT - TRANZACT'',
                                    ''AGENT/EMPLOYER'',
                                    ''EMPLOYER'',
                                    ''AGENT - DESTINATIONRX'',
                                    ''AGENT - EHEALTH'',
                                    ''AGENT - EXTEND_HEALTH'',
                                    ''AGENT - INSURACTIVE'',
                                    ''AGENT - MERCER'',
                                    ''AGENT - MYCUSTOM_HEALTH'',
                                    ''AGENT - SELECTQUOTE_SENIOR'',
                                    ''AGENT - SENIOR_EDUCATORS'',
                                    ''AGENT - SENIOR_MARKET_SALES_(SMS)'',
                                    ''AGENT - TRANZACT''))) source
            ON (target.INSUREDPLANID = source.INSURED_PLAN_ID)
    WHEN MATCHED
    THEN
        UPDATE SET
            SALE_CHNL_LVL_1 = source.SOURCE_ACQN_CHNL_LVL_1,
            SALE_CHNL_LVL_2 = source.SOURCE_ACQN_CHNL_LVL_2,
            SALE_CHNL_LVL_3 = source.SOURCE_ACQN_CHNL_LVL_3
    WHEN NOT MATCHED
    THEN
        INSERT     (INSUREDPLANID,
                    SALE_CHNL_LVL_1,
                    SALE_CHNL_LVL_2,
                    SALE_CHNL_LVL_3)
            VALUES (source.INSURED_PLAN_ID,
                    source.SOURCE_ACQN_CHNL_LVL_1,
                    source.SOURCE_ACQN_CHNL_LVL_2,
                    source.SOURCE_ACQN_CHNL_LVL_3);

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

V_ROWS_UPDATED := (SELECT $2 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );	

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );	

---Commented by OAS JNIKAM--------------
/*
    v_rows_afftd := SQL%ROWCOUNT;

    INSERT INTO etl.etl_detail_load_info (application,
                                          etl_batch_id,
                                          etl_proc_name,
                                          action,
                                          step_info,
                                          rows_affected,
                                          etl_datetime)
         VALUES (''CONFORMED_DIMENSIONS'',
                 v_btch_id,
                 v_proc_name,
                 ''MERGE'',
                 ''MERGE/INSERT SMART DTC INTO WRK_IP_SALE_CHANNEL '',
                 v_rows_afftd,
                 SYSTIMESTAMP);

    COMMIT;
    --

    p_tocontinuestatus := ''Y'';
    p_errorynflg := ''N'';
    p_errorstr := '''';

    INSERT INTO etl.etl_detail_load_info (application,
                                          etl_batch_id,
                                          etl_proc_name,
                                          action,
                                          step_info,
                                          rows_affected,
                                          etl_datetime)
         VALUES (''CONFORMED_DIMENSIONS'',
                 v_btch_id,
                 v_proc_name,
                 ''END'',
                 ''PROCEDURE ENDS '',
                 v_rows_afftd,
                 SYSTIMESTAMP);

    COMMIT;
EXCEPTION
    WHEN OTHERS
    THEN
        p_errorstr :=
               ''ERROR: ''
            || SQLCODE
            || ''-''
            || SQLERRM
            || ''-''
            || DBMS_UTILITY.format_error_backtrace ()
            || CHR (10)
            || DBMS_UTILITY.format_error_stack ();

        p_tocontinuestatus := ''N'';
        p_errorynflg := ''Y'';
        ROLLBACK;
END;
/
*/
---Commented by OAS JNIKAM	--------------------


CALL UTIL.SP_ETL_CHECK_CONSTRAINTS(:DB_NAME , :APPLICATION , :WORKFLOW_NAME , :OBJECT_NAME , :V_BATCH_ID );
		
UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''COMPLETE'', ERROR_MSG = null, BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
; 


UPDATE  UTIL.ETL_BATCH_OBJECT_INCR_VALU SET INCR_COLUMN_VALUE = :V_BATCH_ID, LST_MOD_DT = CURRENT_TIMESTAMP() WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID''; 

EXCEPTION

WHEN OTHER THEN


UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''ERROR'', ERROR_MSG = :SQLERRM,  BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
;



INSERT INTO  UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ERROR_MSG, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''ERROR'', :V_STEP_NAME, :V_STEP_SEQ, :SQLERRM, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() )
;



RAISE;
    
		
		
END;

';