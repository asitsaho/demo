USE SCHEMA BDR_DM; CREATE OR REPLACE PROCEDURE "SP_CLAIMS_IXL_PARTB_TEMPPARTBWGTDTL_M"("DB_NAME" VARCHAR(16777216), "APPLICATION" VARCHAR(16777216), "WORKFLOW_NAME" VARCHAR(16777216), "OBJECT_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '

-- Original workflow: wkf_Claims_PartB_IXL_TargetLoad_M
-- Original mapping: m_Claims_IXL_PartB_TEMPPARTBWGTDTL_M
-- Original folder: Claims
-- Original filename: wkf_Claims_PartB_IXL_TargetLoad_M.XML

DECLARE


V_ROWS_INSERTED  INTEGER;
V_ROWS_UPDATED INTEGER;
V_ROWS_DELETED INTEGER;
V_LAST_QUERY_ID VARCHAR;

V_WH VARCHAR;
V_BATCH_ID INTEGER;


V_BATCH_OBJECT_START_TIME        VARCHAR;
V_STEP_START_TIME    VARCHAR;
V_STEP_NAME VARCHAR;
V_STEP_SEQ INTEGER DEFAULT 0;
V_ETL_LST_BTCH_ID INTEGER;

V_PROCESS_DATE DATE;



BEGIN

EXECUTE IMMEDIATE ''USE DATABASE ''||:DB_NAME; 

ALTER SESSION 
SET TIMEZONE = ''America/Chicago'';

V_BATCH_OBJECT_START_TIME := (SELECT	CURRENT_TIMESTAMP());



LET res1 RESULTSET := 
(

SELECT 

WH ,
BATCH_ID
  
FROM UTIL.ETL_BATCH_OBJECT_CONTROL
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
FETCH FIRST 1 ROW ONLY

)
;


LET C1 CURSOR FOR res1;
open C1;
FETCH C1 into  V_WH,V_BATCH_ID ;
close C1;


LET res2 RESULTSET := 

(

WITH PARAMETERS (PROCESS_DATE) AS
(
  
SELECT * 
FROM  
(SELECT PARAMETER_NAME, PARAMETER_VALUE  FROM UTIL.ETL_OBJECT_PARAMETER_VALUE 
WHERE 1 = 1
AND APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
AND ACTIVE_FLG = ''Y''  
  
UNION ALL       

SELECT PARAMETER_NAME, PARAMETER_VALUE  FROM UTIL.ETL_GLOBAL_PARAMETER_VALUE WHERE PAR_GLOBAL_TYPE = ''PARGLOBAL_OPREPORTS'' AND ACTIVE_FLG = ''Y''
AND PARAMETER_NAME NOT IN  (
SELECT PARAMETER_NAME  FROM UTIL.ETL_OBJECT_PARAMETER_VALUE WHERE 1 = 1
AND APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
AND ACTIVE_FLG = ''Y''   ))
 
PIVOT(MAX(PARAMETER_VALUE) FOR PARAMETER_NAME IN (''PROCESS_DATE'')) 

 
)  
SELECT * FROM PARAMETERS 
)  
  
;


LET C2 CURSOR FOR res2;
open C2;
FETCH C2 into  v_process_date; 
close C2;


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:V_WH;
USE SCHEMA BDR_DM;   


INSERT INTO UTIL.ETL_BATCH_OBJECT_INCR_VALU (APPLICATION, WORKFLOW_NAME, OBJECT_NAME, INCR_COLUMN, INCR_COLUMN_VALUE )
SELECT * FROM (select :APPLICATION AS APPLICATION, :WORKFLOW_NAME AS WORKFLOW_NAME, :OBJECT_NAME AS OBJECT_NAME, ''ETL_LST_BTCH_ID'' AS INCR_COLUMN, -1 AS INCR_COLUMN_VALUE) A
WHERE NOT EXISTS (SELECT 1 FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU B WHERE B.APPLICATION = A.APPLICATION AND B.WORKFLOW_NAME = A.WORKFLOW_NAME AND B.OBJECT_NAME = A.OBJECT_NAME AND B.INCR_COLUMN = A.INCR_COLUMN)
;

V_ETL_LST_BTCH_ID :=(SELECT INCR_COLUMN_VALUE FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID'');
--COMMENTED BY OAS--
/*
CREATE OR REPLACE PROCEDURE DM.SP_TEMP_PART_B_WGT_DTL (
    P_ToStart            IN     NUMBER,
    P_ToContinueStatus      OUT VARCHAR2,
    P_ErrorYNFlg            OUT VARCHAR2,
    P_ErrorStr              OUT VARCHAR2)
---------------------------------------------------------------------------
--Purpose         : This procedure populates PART_B_WGT_DTL fact table
--
--Application Ref : Program Global Dashboard
--Called From     :
--Author          : By CTS    Inital Date : 06/01/2020
--Author          : By Padma  Updated Date : 04/02/2024

--Change History

---------------------------------------------------------------------------
--    Date             Who Changed             What Changed
-- May''21 - As part of SCR 75992, code changed to handle the start date and end date calculation during the Jan month and change in year
-- April''22- As part of US91556, code changed to use PLSRV_SK from F_CLM_HIST  instead of PLSRV_CD from D_EC_PART_B
---------------------------------------------------------------------------
AS
    v_partb_clm_pd_startdt_1   INT;
    v_partb_clm_pd_startdt_2   INT;
    v_partb_clm_pd_startdt_3   INT;
    v_partb_clm_pd_startdt_4   INT;
    v_partb_clm_pd_startdt_5   INT;
    v_partb_clm_pd_enddt_1     INT;
    v_partb_clm_pd_enddt_2     INT;
    v_partb_clm_pd_enddt_3     INT;
    v_partb_clm_pd_enddt_4     INT;
    v_partb_clm_pd_enddt_5     INT;
    V_PROC_NAME                VARCHAR (50) := ''SP_TEMP_PART_B_WGT_DTL'';
    V_ROWS_AFFTD               NUMBER (20) := 0;
    V_BTCH_ID                  NUMBER (10);
    v_partb_process_date       DATE;

BEGIN

SELECT	
		CASE
               WHEN METADATA_VALUE IS NULL THEN SYSDATE
               ELSE TO_DATE (METADATA_VALUE,
		''YYYY-MM-DD'')
           END
      INTO v_partb_process_date
      FROM	ETL.ETL_APPLICATION_METADATA
     WHERE	METADATA_TYPE = ''v_process_date'' 
	AND APPLICATION = ''PARTB'';
	
	SELECT MAX (BATCH_ID)
      INTO V_BTCH_ID
      FROM ETL.ETL_BATCH_LOG
     WHERE APPLICATION = ''PARTB'' AND BATCH_STATUS != ''COMPLETE'';

    INSERT INTO ETL.ETL_DETAIL_LOAD_INFO (APPLICATION,
                                          ETL_BATCH_ID,
                                          ETL_PROC_NAME,
                                          ACTION,
                                          STEP_INFO,
                                          ROWS_AFFECTED,
                                          ETL_DATETIME)
         VALUES (''PARTB'',
                 V_BTCH_ID,
                 V_PROC_NAME,
                 ''START'',
                 ''PROCEDURE STARTS'',
                 V_ROWS_AFFTD,
                 SYSTIMESTAMP); 

    IF (P_ToStart = 1)
    THEN
        BEGIN */
--COMMENTED BY OAS--
	
V_PROCESS_DATE := (SELECT NVL(:V_PROCESS_DATE::DATE, CURRENT_DATE));

LET clm_pd_enddt_5 INTEGER := 
	(
		SELECT	
			CASE WHEN TO_CHAR (:V_PROCESS_DATE, ''MM'') = ''01''
				THEN CONCAT (TO_CHAR (DATEADD(YEAR, -1, :V_PROCESS_DATE), ''YYYY''),
					TO_CHAR (DATEADD(DAY, -1, TRUNC (:V_PROCESS_DATE, ''MM'')), ''MMDD''))
				ELSE CONCAT (TO_CHAR (:V_PROCESS_DATE, ''YYYY''),
					TO_CHAR (DATEADD(DAY, -1, TRUNC (:V_PROCESS_DATE, ''MM'')), ''MMDD''))
			END 
		FROM DUAL 
	);

LET clm_pd_enddt_4 INTEGER :=
    (
		SELECT	
			CASE WHEN TO_CHAR (:V_PROCESS_DATE, ''MM'') = ''01''
		        THEN CONCAT (TO_CHAR (DATEADD(YEAR, -2, :V_PROCESS_DATE), ''YYYY''),
		                    TO_CHAR (DATEADD(DAY, -1, TRUNC (:V_PROCESS_DATE, ''MM'')), ''MMDD''))
		        ELSE CONCAT (TO_CHAR (DATEADD(YEAR, -1, :V_PROCESS_DATE), ''YYYY''),
		                    TO_CHAR (DATEADD(DAY, -1, TRUNC (:V_PROCESS_DATE, ''MM'')), ''MMDD''))
		    END
		FROM DUAL
	);

LET clm_pd_enddt_3 INTEGER :=
    (
		SELECT	
			CASE WHEN TO_CHAR (:V_PROCESS_DATE, ''MM'') = ''01''
		        THEN CONCAT (TO_CHAR (DATEADD(YEAR, -3, :V_PROCESS_DATE), ''YYYY''),
		                    TO_CHAR (DATEADD(DAY, -1, TRUNC (:V_PROCESS_DATE, ''MM'')), ''MMDD''))
		        ELSE CONCAT (TO_CHAR (DATEADD(YEAR, -2, :V_PROCESS_DATE), ''YYYY''),
		                    TO_CHAR (DATEADD(DAY, -1, TRUNC (:V_PROCESS_DATE, ''MM'')), ''MMDD''))
		    END
		FROM DUAL
	);

LET clm_pd_enddt_2 INTEGER :=
    (
		SELECT	
			CASE WHEN TO_CHAR (:V_PROCESS_DATE, ''MM'') = ''01''
		        THEN CONCAT (TO_CHAR (DATEADD(YEAR, -4, :V_PROCESS_DATE), ''YYYY''), 
							TO_CHAR (DATEADD(DAY, -1, TRUNC (:V_PROCESS_DATE, ''MM'')), ''MMDD''))
		        ELSE CONCAT (TO_CHAR (DATEADD(YEAR, -3, :V_PROCESS_DATE), ''YYYY''),
		                    TO_CHAR (DATEADD(DAY, -1, TRUNC (:V_PROCESS_DATE, ''MM'')), ''MMDD''))
		    END
		FROM DUAL
	);

LET clm_pd_enddt_1 INTEGER :=
    (
		SELECT	
				CASE WHEN TO_CHAR (:V_PROCESS_DATE, ''MM'') = ''01''
		            THEN CONCAT (TO_CHAR (DATEADD(YEAR, -5, :V_PROCESS_DATE), ''YYYY''),
		                        TO_CHAR (DATEADD(DAY, -1, TRUNC (:V_PROCESS_DATE, ''MM'')), ''MMDD''))
		            ELSE CONCAT (TO_CHAR (DATEADD(YEAR, -4, :V_PROCESS_DATE), ''YYYY''),
		                        TO_CHAR (DATEADD(DAY, -1, TRUNC (:V_PROCESS_DATE, ''MM'')), ''MMDD''))
		        END
		FROM DUAL
	);

LET clm_pd_startdt_5 INTEGER :=
    (
		SELECT 
			CASE WHEN TO_CHAR (:V_PROCESS_DATE, ''MM'') = ''01''
		        THEN CONCAT (TO_CHAR (DATEADD(YEAR, -1, :V_PROCESS_DATE), ''YYYY''), ''0101'')
		        ELSE CONCAT (TO_CHAR (:V_PROCESS_DATE, ''YYYY''), ''0101'')
		    END "First Day"
		FROM DUAL
	);

LET clm_pd_startdt_4 INTEGER :=
    (
		SELECT 
			CASE WHEN TO_CHAR (:V_PROCESS_DATE, ''MM'') = ''01''
		        THEN CONCAT (TO_CHAR (DATEADD(YEAR, -2, :V_PROCESS_DATE), ''YYYY''), ''0101'')
		        ELSE CONCAT (TO_CHAR (DATEADD(YEAR, -1, :V_PROCESS_DATE), ''YYYY''), ''0101'')
		    END "First Day"
		FROM DUAL
	);

LET clm_pd_startdt_3 INTEGER :=
    (
		SELECT	
			CASE
		        WHEN TO_CHAR (:V_PROCESS_DATE, ''MM'') = ''01''
		        THEN CONCAT (TO_CHAR (DATEADD(YEAR, -3, :V_PROCESS_DATE), ''YYYY''), ''0101'')
		        ELSE CONCAT (TO_CHAR (DATEADD(YEAR, -2, :V_PROCESS_DATE), ''YYYY''), ''0101'')
		    END "First Day"
		FROM DUAL
	);

LET clm_pd_startdt_2 INTEGER :=
     (
		SELECT	
			CASE
				WHEN TO_CHAR (:V_PROCESS_DATE, ''MM'') = ''01''
		        THEN CONCAT (TO_CHAR (DATEADD(YEAR, -4, :V_PROCESS_DATE), ''YYYY''), ''0101'')
		        ELSE CONCAT (TO_CHAR (DATEADD(YEAR, -3, :V_PROCESS_DATE), ''YYYY''), ''0101'')
		    END "First Day"
		FROM DUAL
	);

LET clm_pd_startdt_1 INTEGER :=
    (
		SELECT	
			CASE
		        WHEN TO_CHAR (:V_PROCESS_DATE, ''MM'') = ''01''
		        THEN CONCAT (TO_CHAR (DATEADD(YEAR, -5, :V_PROCESS_DATE), ''YYYY''), ''0101'')
		        ELSE CONCAT (TO_CHAR (DATEADD(YEAR, -4, :V_PROCESS_DATE), ''YYYY''), ''0101'')
		    END "First Day"
		FROM DUAL
	);


V_STEP_NAME    := ''MERGE - D_CPT_LOOK'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

MERGE INTO BDR_DM.D_CPT_LOOK wrk1
    USING (
		SELECT	DISTINCT
			FC.CPT_CD           AS CPT_CD,
			FC.CPT_CATGY_CD     AS CPT_CATGY_CD
		FROM BDR_DM.STG_BUS_CPT_CATGY FC) wrk2
	ON (wrk1.CPT_CD = wrk2.CPT_CD)
    WHEN MATCHED
    THEN UPDATE 
	SET wrk1.CPT_CATGY_CD = wrk2.CPT_CATGY_CD;
	
	V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

	V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

	INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME) VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

	V_STEP_NAME    := ''MERGE - D_CARR'';
	V_STEP_SEQ     :=  V_STEP_SEQ+1;
	V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
	V_ROWS_INSERTED := null;
	V_ROWS_UPDATED := null;
	V_ROWS_DELETED := null;

    MERGE INTO BDR_DM.D_CARR wrk1
    USING (
		SELECT	DISTINCT
			FC.LOCATION_NBR      AS CARR_LOC_NBR,
			FC.CARR_CATGY_CD     AS CARR_CATGY_CD
		FROM BDR_DM.STG_BUS_CARRIER FC) wrk2
    ON (wrk1.CARR_LOC_NBR = wrk2.CARR_LOC_NBR)
    WHEN MATCHED
    THEN UPDATE 
	SET wrk1.CARR_CATGY_CD = wrk2.CARR_CATGY_CD;
	
	V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

	V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

	INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
	VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

        --    DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS (''DM'', ''D_CPT_LOOK'');	--OAS DELETE
        --    DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS (''DM'', ''D_CARR'');		--OAS DELETE
--COMMENTED BY OAS--
/*            UPDATE ETL.ETL_APPLICATION_METADATA
               SET METADATA_VALUE =
                       (
		SELECT	
				CASE
		                                   WHEN TO_CHAR (v_partb_process_date,
				''MM'') =
		                                        ''01''
		                                   THEN
		                                       CONCAT (
		                                             TO_CHAR (v_partb_process_date,
		                                                      ''YYYY'')
		                                           - 1,
		                                           TO_CHAR (
		                                                 TRUNC (v_partb_process_date,
		                                                        ''MM'')
		                                               - 1,
		                                               ''MMDD''))
		                                   ELSE
		                                       CONCAT (
		                                           TO_CHAR (v_partb_process_date,
		                                                    ''YYYY''),
		                                           TO_CHAR (
		                                                 TRUNC (v_partb_process_date,
		                                                        ''MM'')
		                                               - 1,
		                                               ''MMDD''))
		                               END
		                          FROM	DUAL)
             WHERE	    APPLICATION = ''PARTB''
                   AND METADATA_TYPE = ''v_partb_clm_pd_enddt_5''
                   AND METADATA_VALUE IS NULL;

            UPDATE ETL.ETL_APPLICATION_METADATA
               SET METADATA_VALUE =
                       (
		SELECT	
				CASE
		                                   WHEN TO_CHAR (v_partb_process_date,
				''MM'') =
		                                        ''01''
		                                   THEN
		                                       CONCAT (
		                                             TO_CHAR (v_partb_process_date,
		                                                      ''YYYY'')
		                                           - 2,
		                                           TO_CHAR (
		                                                 TRUNC (v_partb_process_date,
		                                                        ''MM'')
		                                               - 1,
		                                               ''MMDD''))
		                                   ELSE
		                                       CONCAT (
		                                             TO_CHAR (v_partb_process_date,
		                                                      ''YYYY'')
		                                           - 1,
		                                           TO_CHAR (
		                                                 TRUNC (v_partb_process_date,
		                                                        ''MM'')
		                                               - 1,
		                                               ''MMDD''))
		                               END
		                          FROM	DUAL)
             WHERE	    APPLICATION = ''PARTB''
                   AND METADATA_TYPE = ''v_partb_clm_pd_enddt_4''
                   AND METADATA_VALUE IS NULL;

            UPDATE ETL.ETL_APPLICATION_METADATA
               SET METADATA_VALUE =
                       (
		SELECT	
				CASE
		                                   WHEN TO_CHAR (v_partb_process_date,
				''MM'') =
		                                        ''01''
		                                   THEN
		                                       CONCAT (
		                                             TO_CHAR (v_partb_process_date,
		                                                      ''YYYY'')
		                                           - 3,
		                                           TO_CHAR (
		                                                 TRUNC (v_partb_process_date,
		                                                        ''MM'')
		                                               - 1,
		                                               ''MMDD''))
		                                   ELSE
		                                       CONCAT (
		                                             TO_CHAR (v_partb_process_date,
		                                                      ''YYYY'')
		                                           - 2,
		                                           TO_CHAR (
		                                                 TRUNC (v_partb_process_date,
		                                                        ''MM'')
		                                               - 1,
		                                               ''MMDD''))
		                               END
		                          FROM	DUAL)
             WHERE	    APPLICATION = ''PARTB''
                   AND METADATA_TYPE = ''v_partb_clm_pd_enddt_3''
                   AND METADATA_VALUE IS NULL;

            UPDATE ETL.ETL_APPLICATION_METADATA
               SET METADATA_VALUE =
                       (
		SELECT	
				CASE
		                                   WHEN TO_CHAR (v_partb_process_date,
				''MM'') =
		                                        ''01''
		                                   THEN
		                                       CONCAT (
		                                             TO_CHAR (v_partb_process_date,
		                                                      ''YYYY'')
		                                           - 4,
		                                           TO_CHAR (
		                                                 TRUNC (v_partb_process_date,
		                                                        ''MM'')
		                                               - 1,
		                                               ''MMDD''))
		                                   ELSE
		                                       CONCAT (
		                                             TO_CHAR (v_partb_process_date,
		                                                      ''YYYY'')
		                                           - 3,
		                                           TO_CHAR (
		                                                 TRUNC (v_partb_process_date,
		                                                        ''MM'')
		                                               - 1,
		                                               ''MMDD''))
		                               END
		                          FROM	DUAL)
             WHERE	    APPLICATION = ''PARTB''
                   AND METADATA_TYPE = ''v_partb_clm_pd_enddt_2''
                   AND METADATA_VALUE IS NULL;

            UPDATE ETL.ETL_APPLICATION_METADATA
               SET METADATA_VALUE =
                       (
		SELECT	
				CASE
		                                   WHEN TO_CHAR (v_partb_process_date,
				''MM'') =
		                                        ''01''
		                                   THEN
		                                       CONCAT (
		                                             TO_CHAR (v_partb_process_date,
		                                                      ''YYYY'')
		                                           - 5,
		                                           TO_CHAR (
		                                                 TRUNC (v_partb_process_date,
		                                                        ''MM'')
		                                               - 1,
		                                               ''MMDD''))
		                                   ELSE
		                                       CONCAT (
		                                             TO_CHAR (v_partb_process_date,
		                                                      ''YYYY'')
		                                           - 4,
		                                           TO_CHAR (
		                                                 TRUNC (v_partb_process_date,
		                                                        ''MM'')
		                                               - 1,
		                                               ''MMDD''))
		                               END
		                          FROM	DUAL)
             WHERE	    APPLICATION = ''PARTB''
                   AND METADATA_TYPE = ''v_partb_clm_pd_enddt_1''
                   AND METADATA_VALUE IS NULL;

            UPDATE ETL.ETL_APPLICATION_METADATA
               SET METADATA_VALUE =
                       (
		SELECT	
				CASE
		                                   WHEN TO_CHAR (v_partb_process_date,
				''MM'') =
		                                        ''01''
		                                   THEN
		                                       CONCAT (
		                                             TO_CHAR (v_partb_process_date,
		                                                      ''YYYY'')
		                                           - 1,
		                                           ''0101'')
		                                   ELSE
		                                       CONCAT (
		                                           TO_CHAR (v_partb_process_date,
		                                                    ''YYYY''),
		                                           ''0101'')
		                               END    "First Day"
		                          FROM	DUAL)
             WHERE	    APPLICATION = ''PARTB''
                   AND METADATA_TYPE = ''v_partb_clm_pd_startdt_5''
                   AND METADATA_VALUE IS NULL;

            UPDATE ETL.ETL_APPLICATION_METADATA
               SET METADATA_VALUE =
                       (
		SELECT	
				CASE
		                                   WHEN TO_CHAR (v_partb_process_date,
				''MM'') =
		                                        ''01''
		                                   THEN
		                                       CONCAT (
		                                             TO_CHAR (v_partb_process_date,
		                                                      ''YYYY'')
		                                           - 2,
		                                           ''0101'')
		                                   ELSE
		                                       CONCAT (
		                                             TO_CHAR (v_partb_process_date,
		                                                      ''YYYY'')
		                                           - 1,
		                                           ''0101'')
		                               END    "First Day"
		                          FROM	DUAL)
             WHERE	    APPLICATION = ''PARTB''
                   AND METADATA_TYPE = ''v_partb_clm_pd_startdt_4''
                   AND METADATA_VALUE IS NULL;

            UPDATE ETL.ETL_APPLICATION_METADATA
               SET METADATA_VALUE =
                       (
		SELECT	
				CASE
		                                   WHEN TO_CHAR (v_partb_process_date,
				''MM'') =
		                                        ''01''
		                                   THEN
		                                       CONCAT (
		                                             TO_CHAR (v_partb_process_date,
		                                                      ''YYYY'')
		                                           - 3,
		                                           ''0101'')
		                                   ELSE
		                                       CONCAT (
		                                             TO_CHAR (v_partb_process_date,
		                                                      ''YYYY'')
		                                           - 2,
		                                           ''0101'')
		                               END    "First Day"
		                          FROM	DUAL)
             WHERE	    APPLICATION = ''PARTB''
                   AND METADATA_TYPE = ''v_partb_clm_pd_startdt_3''
                   AND METADATA_VALUE IS NULL;

            UPDATE ETL.ETL_APPLICATION_METADATA
               SET METADATA_VALUE =
                       (
		SELECT	
				CASE
		                                   WHEN TO_CHAR (v_partb_process_date,
				''MM'') =
		                                        ''01''
		                                   THEN
		                                       CONCAT (
		                                             TO_CHAR (v_partb_process_date,
		                                                      ''YYYY'')
		                                           - 4,
		                                           ''0101'')
		                                   ELSE
		                                       CONCAT (
		                                             TO_CHAR (v_partb_process_date,
		                                                      ''YYYY'')
		                                           - 3,
		                                           ''0101'')
		                               END    "First Day"
		                          FROM	DUAL)
             WHERE	    APPLICATION = ''PARTB''
                   AND METADATA_TYPE = ''v_partb_clm_pd_startdt_2''
                   AND METADATA_VALUE IS NULL;

            UPDATE ETL.ETL_APPLICATION_METADATA
               SET METADATA_VALUE =
                       (
		SELECT	
				CASE
		                                   WHEN TO_CHAR (v_partb_process_date,
				''MM'') =
		                                        ''01''
		                                   THEN
		                                       CONCAT (
		                                             TO_CHAR (v_partb_process_date,
		                                                      ''YYYY'')
		                                           - 5,
		                                           ''0101'')
		                                   ELSE
		                                       CONCAT (
		                                             TO_CHAR (v_partb_process_date,
		                                                      ''YYYY'')
		                                           - 4,
		                                           ''0101'')
		                               END    "First Day"
		                          FROM	DUAL)
             WHERE	    APPLICATION = ''PARTB''
                   AND METADATA_TYPE = ''v_partb_clm_pd_startdt_1''
                   AND METADATA_VALUE IS NULL;

            COMMIT;

            SELECT	METADATA_VALUE
              INTO v_partb_clm_pd_enddt_5
              FROM	ETL.ETL_APPLICATION_METADATA
             WHERE	    APPLICATION = ''PARTB''
                   AND METADATA_TYPE = ''v_partb_clm_pd_enddt_5'';

            SELECT	METADATA_VALUE
              INTO v_partb_clm_pd_enddt_4
              FROM	ETL.ETL_APPLICATION_METADATA
             WHERE	    APPLICATION = ''PARTB''
                   AND METADATA_TYPE = ''v_partb_clm_pd_enddt_4'';

            SELECT	METADATA_VALUE
              INTO v_partb_clm_pd_enddt_3
              FROM	ETL.ETL_APPLICATION_METADATA
             WHERE	    APPLICATION = ''PARTB''
                   AND METADATA_TYPE = ''v_partb_clm_pd_enddt_3'';

            SELECT	METADATA_VALUE
              INTO v_partb_clm_pd_enddt_2
              FROM	ETL.ETL_APPLICATION_METADATA
             WHERE	    APPLICATION = ''PARTB''
                   AND METADATA_TYPE = ''v_partb_clm_pd_enddt_2'';

            SELECT	METADATA_VALUE
              INTO v_partb_clm_pd_enddt_1
              FROM	ETL.ETL_APPLICATION_METADATA
             WHERE	    APPLICATION = ''PARTB''
                   AND METADATA_TYPE = ''v_partb_clm_pd_enddt_1'';

            SELECT	METADATA_VALUE
              INTO v_partb_clm_pd_startdt_5
              FROM	ETL.ETL_APPLICATION_METADATA
             WHERE	    APPLICATION = ''PARTB''
                   AND METADATA_TYPE = ''v_partb_clm_pd_startdt_5'';

            SELECT	METADATA_VALUE
              INTO v_partb_clm_pd_startdt_4
              FROM	ETL.ETL_APPLICATION_METADATA
             WHERE	    APPLICATION = ''PARTB''
                   AND METADATA_TYPE = ''v_partb_clm_pd_startdt_4'';

            SELECT	METADATA_VALUE
              INTO v_partb_clm_pd_startdt_3
              FROM	ETL.ETL_APPLICATION_METADATA
             WHERE	    APPLICATION = ''PARTB''
                   AND METADATA_TYPE = ''v_partb_clm_pd_startdt_3'';

            SELECT	METADATA_VALUE
              INTO v_partb_clm_pd_startdt_2
              FROM	ETL.ETL_APPLICATION_METADATA
             WHERE	    APPLICATION = ''PARTB''
                   AND METADATA_TYPE = ''v_partb_clm_pd_startdt_2'';

            SELECT	METADATA_VALUE
              INTO v_partb_clm_pd_startdt_1
              FROM	ETL.ETL_APPLICATION_METADATA
             WHERE	    APPLICATION = ''PARTB''
                   AND METADATA_TYPE = ''v_partb_clm_pd_startdt_1'';
*/
--COMMENTED BY OAS--
	V_STEP_NAME    := ''TRUNCATE - TEMP_PART_B_WGT_DTL'';
	V_STEP_SEQ     :=  V_STEP_SEQ+1;
	V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
	V_ROWS_INSERTED := null;
	V_ROWS_UPDATED := null;
	V_ROWS_DELETED := null;
		
	EXECUTE IMMEDIATE ''TRUNCATE TABLE BDR_DM.TEMP_PART_B_WGT_DTL'';

	INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME) VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

	--        DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS (''DM'', ''TEMP_PART_B_WGT_DTL'');	--OAS DELETE

	V_STEP_NAME    := ''INSERT - TEMP_PART_B_WGT_DTL'';
	V_STEP_SEQ     :=  V_STEP_SEQ+1;
	V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
	V_ROWS_INSERTED := null;
	V_ROWS_UPDATED := null;
	V_ROWS_DELETED := null;

	INSERT /*+ enable_parallel_dml APPEND */
	INTO BDR_DM.TEMP_PART_B_WGT_DTL
	(
		PLN_TYP_DESC    ,
		ST_CD           ,
		SRVC_YR_NBR     ,
		SRVC_FROM_MO_NBR,
		CPT_CD          ,
		CLM_LOC_CD      ,
		PLSRV_CD        ,
		PLSRV_DESC      ,
		EC_UB92_IND     ,
		CPT_CATGY_CD    ,
		CARR_CATGY_CD   ,
		BEN_TOT_AMT     ,
		BL_CNT          ,
		BEN_TOT_PD_AMT  ,
		BL_PD_CNT       ,
		MED_PLSRV_DESC  ,
		CARR_TYP_DESC   ,
		MED_PLSRV_SET
	)
		WITH wr AS 
		(	SELECT
			  b.Plan_Type,
			  b.state,
			  b.Service_Year,
			  b.Service_Month,
			  b.cpt_code,
			  b.claim_location,
			  b.PLSRV_CD,
			  b.PLSRV_DESC,
			  b.EC_UB92_FLG,
			  b.CPT_CATGY_CD,
			  NVL (b.CARR_CATGY_CD, ''Unknown'') AS CARR_CATGY_CD,
			  b.Benefit_Total,
			  b.Bill_Line_Cnt,
			  b.benefit_total_pt,
			  b.bill_line_count_pt,
			  NVL(b.PLSRV_CD||b.PLSRV_DESC,''Unknown'') as medpos,
			  Case 
						WHEN SUBSTR (b.claim_location,LENGTH (b.claim_location),1) IN (0, 1, 2) then ''Manual''
							 when b.Benefit_Total <> 0 
				and b.Service_Month < 201811 
				and b.claim_location=25 then ''Institutional''
				   when b.Benefit_Total <> 0and (b.CARR_CATGY_CD is null 
				or b.CARR_CATGY_CD = ''ANY'') 
				and (b.EC_UB92_FLG is null 
				or b.EC_UB92_FLG in (''N'',
				''O'',''Z'')) then ''Professional''
				   when b.Benefit_Total <> 0 
				and (b.CARR_CATGY_CD is null 
				or b.CARR_CATGY_CD = ''ANY'') 
				and b.EC_UB92_FLG = ''U'' then ''Institutional''
				   else NVL (b.CARR_CATGY_CD,
					''Unknown'') 
					End as Carrier,
					Case 
						when b.PLSRV_DESC is null 
				or b.PLSRV_DESC in (''Unassigned'',
				''Blank'',''Other'',''Unknown'','''') then 6
				   when b.PLSRV_CD in (''21'',
					''22'',''26'',''53'') then 2
				   when b.PLSRV_CD in (''62'') then 3
				   when b.PLSRV_CD in (''24'') then 4
				   when b.PLSRV_CD in (''65'') then 5
				   else 1 
					end as medpos_set
			from
			(
				select
				  a.Plan_Type,
				  a.state,
				  a.Service_Year,
				  a.Service_Month,
				  a.cpt_code,
				  a.claim_location,
				  TRIM(CAST(NVL(PLSRV.PLSRV_CD,
						''U'') AS VARCHAR(20))) PLSRV_CD,
				  TRIM(CAST(NVL(PLSRV.PLSRV_DESC,
						''Unknown'') AS VARCHAR(200))) PLSRV_DESC,
				  a.EC_UB92_FLG,
				  a.PointTime,
				  NVL(a.CPT_CATGY_CD,''Unknown'') as CPT_CATGY_CD,
				  CR.CARR_CATGY_CD AS CARR_CATGY_CD,
				sum(a.Benefit_Total) as Benefit_Total,
				  count(a.Bill_Line_Cnt) as Bill_Line_Cnt,
				  case 
							when a.PointTime = 0 then 0 
							else sum(a.Benefit_Total) 
						end as benefit_total_pt,
				  case 
							when a.PointTime = 0 then 0 
							else count(a.Bill_Line_Cnt) 
						end as bill_line_count_pt
				from
				  (
					select	/*+ materialize */
					pln.prdct_typ as Plan_Type,
				---	geo.D_ST_CD as state,
				
				case when clmbl.D_LGL_ENTY_SK <> 3 and cr.st_cd = ''NY'' and cr.src_area_id = 99 then ''NY'' 
      when cr.st_cd = ''FL'' and cr.src_area_id = 99 then ''FL''
      when cr.st_cd = ''MA'' then ''MA''
      when clmbl.D_LGL_ENTY_SK = 3 then cr.st_cd
      else geo.d_st_cd end as State,
				
				
				
				
					floor(clmbl.srvc_from_dt_id / 10000) as Service_Year,
					floor(clmbl.srvc_from_dt_id / 100) as Service_Month,
					cpt.cpt_cd as cpt_code,
					cast(substr(lpad(clmbl.clm_nbr, 12, 0),6,3) as int) as claim_location,
					--CASE when clm.src_ind=''F'' and PLSRV1.PLSRV_CD=''U'' then PLSRV.PLSRV_CD else PLSRV1.PLSRV_CD end as PLSRV_CD,
					--CASE when clm.src_ind=''F'' and PLSRV1.PLSRV_CD=''U'' then PLSRV.PLSRV_DESC else PLSRV1.PLSRV_DESC end as PLSRV_DESC,
					CASE      
						WHEN T.INST_PROF_IND = ''I'' 
						AND T.FCLTY_CD = ''11'' THEN ''21''
									   WHEN T.INST_PROF_IND = ''I'' 
						AND T.FCLTY_CD = ''12'' THEN ''21''
									   WHEN T.INST_PROF_IND = ''I'' 
						AND T.FCLTY_CD = ''13'' THEN ''22''
									   WHEN T.INST_PROF_IND = ''I'' 
						AND T.FCLTY_CD = ''14'' THEN ''22''
									   WHEN T.INST_PROF_IND = ''I'' 
						AND T.FCLTY_CD = ''18'' THEN ''21''
									   WHEN T.INST_PROF_IND = ''I'' 
						AND T.FCLTY_CD = ''21'' THEN ''31''
									   WHEN T.INST_PROF_IND = ''I'' 
						AND T.FCLTY_CD = ''22'' THEN ''31''
									   WHEN T.INST_PROF_IND = ''I'' 
						AND T.FCLTY_CD = ''23'' THEN ''32''
									   WHEN T.INST_PROF_IND = ''I'' 
						AND T.FCLTY_CD = ''28'' THEN ''32''
									   WHEN T.INST_PROF_IND = ''I'' 
						AND T.FCLTY_CD = ''32'' THEN ''12''
									   WHEN T.INST_PROF_IND = ''I'' 
						AND T.FCLTY_CD = ''33'' THEN ''12''
									   WHEN T.INST_PROF_IND = ''I'' 
						AND T.FCLTY_CD = ''34'' THEN ''12''
									   WHEN T.INST_PROF_IND = ''I'' 
						AND T.FCLTY_CD = ''41'' THEN ''21''
									   WHEN T.INST_PROF_IND = ''I'' 
						AND T.FCLTY_CD = ''42'' THEN ''21''
									   WHEN T.INST_PROF_IND = ''I'' 
						AND T.FCLTY_CD = ''43'' THEN ''22''
									   WHEN T.INST_PROF_IND = ''I'' 
						AND T.FCLTY_CD = ''65'' THEN ''54''
									   WHEN T.INST_PROF_IND = ''I'' 
						AND T.FCLTY_CD = ''66'' THEN ''54''
									   WHEN T.INST_PROF_IND = ''I'' 
						AND T.FCLTY_CD = ''71'' THEN ''72''
									   WHEN T.INST_PROF_IND = ''I'' 
						AND T.FCLTY_CD = ''72'' THEN ''65''
									   WHEN T.INST_PROF_IND = ''I'' 
						AND T.FCLTY_CD = ''73'' THEN ''49''
									   WHEN T.INST_PROF_IND = ''I'' 
						AND T.FCLTY_CD = ''74'' THEN ''49''
									   WHEN T.INST_PROF_IND = ''I'' 
						AND T.FCLTY_CD = ''75'' THEN ''62''
									   WHEN T.INST_PROF_IND = ''I'' 
						AND T.FCLTY_CD = ''76'' THEN ''53''
									   WHEN T.INST_PROF_IND = ''I'' 
						AND T.FCLTY_CD = ''79'' THEN ''49''
									   WHEN T.INST_PROF_IND = ''I'' 
						AND T.FCLTY_CD = ''81'' THEN ''34''
									   WHEN T.INST_PROF_IND = ''I'' 
						AND T.FCLTY_CD = ''82'' THEN ''34''
									   WHEN T.INST_PROF_IND = ''I'' 
						AND T.FCLTY_CD = ''83'' THEN ''24''
									   WHEN T.INST_PROF_IND = ''I'' 
						AND T.FCLTY_CD = ''84'' THEN ''25''
									   WHEN T.INST_PROF_IND = ''I'' 
						AND T.FCLTY_CD = ''85'' THEN ''22''
							WHEN T.FCLTY_CD IN (''  '',
						''0 '',
									''00'') THEN ''U ''
											WHEN T.FCLTY_CD IN (''1'',
						''2'',''3'',
									''4'',''5'',''6'',''7'',''8'',''9'') THEN LPAD(TRIM(T.FCLTY_CD),2,
						''0'')
						ELSE T.FCLTY_CD 
					END PLSRV_CD,
					T.EC_UB92_FLG as EC_UB92_FLG,
					CASE
						WHEN clmbl.srvc_from_dt_id BETWEEN :clm_pd_startdt_1
							AND :clm_pd_enddt_1
							AND clmbl.clm_pd_dt_id BETWEEN :clm_pd_startdt_1
							AND :clm_pd_enddt_1
						THEN 1
						WHEN clmbl.srvc_from_dt_id BETWEEN :clm_pd_startdt_2
							AND :clm_pd_enddt_2
							AND clmbl.clm_pd_dt_id BETWEEN :clm_pd_startdt_2
							AND :clm_pd_enddt_2
						THEN 1
						WHEN clmbl.srvc_from_dt_id BETWEEN :clm_pd_startdt_3
							AND :clm_pd_enddt_3
							AND clmbl.clm_pd_dt_id BETWEEN :clm_pd_startdt_3
							AND :clm_pd_enddt_3
						THEN 1
						WHEN clmbl.srvc_from_dt_id BETWEEN :clm_pd_startdt_4
							AND :clm_pd_enddt_4
							AND clmbl.clm_pd_dt_id BETWEEN :clm_pd_startdt_4
							AND :clm_pd_enddt_4
						THEN 1
						WHEN clmbl.srvc_from_dt_id BETWEEN :clm_pd_startdt_5
							AND :clm_pd_enddt_5
							AND clmbl.clm_pd_dt_id BETWEEN :clm_pd_startdt_5
							AND :clm_pd_enddt_5
						THEN 1
						ELSE 0
					END AS Pointtime,
					clmbl.adj_ben_amt as Benefit_Total,
					clmbl.clm_nbr as Bill_Line_Cnt,
					cpt.CPT_CATGY_CD
					
					
					
					
					
					
					
					
					
					
				from
				bdr_dm.F_CLM_BIL_LN_HIST clmbl
				JOIN bdr_dm.D_CPT_LOOK cpt 
				ON clmbl.D_CPT_LOOK_SK = cpt.D_CPT_LOOK_SK
				join bdr_conf.D_BEN ben 
				ON clmbl.D_BEN_SK = ben.D_BEN_SK
				JOIN bdr_conf.D_PLN_BEN_MOD pln 
				ON clmbl.D_PLN_BEN_MOD_SK = pln.D_PLN_BEN_MOD_SK
				JOIN bdr_conf.D_GEO_XREF geo 
				ON clmbl.RES_D_GEO_XREF_SK = geo.D_GEO_XREF_SK
				
				
				join BDR_conf.d_calc_rt cr on clmbl.d_calc_rt_sk = cr.d_calc_rt_sk
				
				
				
				left outer JOIN (
					SELECT	/*+parallel(8)*/ clm.F_CLM_HIST_SK,
						clm.CLM_NBR,
						STGCL.INST_PROF_IND,
						STGCL.FCLTY_CD,
						ecb.EC_UB92_FLG 
					from bdr_dm.F_CLM_HIST clm
					LEFT OUTER JOIN bdr_dm.D_EC_part_b ecb 
					ON clm.D_EC_PART_B_SK = ecb.D_EC_PART_B_SK
					JOIN SRC_FOX_D.CLM_HIST STGCL 
					ON clm.CLM_NBR = STGCL.CLM_NUM
					WHERE clm.CMPL_DT_ID BETWEEN :clm_pd_startdt_1 
					AND :clm_pd_enddt_5	
					AND TO_CHAR(STGCL.DT_CMPLTD, ''YYYYMMDD'') BETWEEN :clm_pd_startdt_1 
					AND :clm_pd_enddt_5
				)	T
				ON clmbl.F_CLM_HIST_SK = T.F_CLM_HIST_SK
				/*	dm.F_CLM_HIST clm ON clmbl.F_CLM_HIST_SK = clm.F_CLM_HIST_SK
				LEFT OUTER JOIN bdr_dm.D_EC_part_b ecb ON clm.D_EC_PART_B_SK = ecb.D_EC_PART_B_SK
				JOIN SRC_FOX_D.CLM_HIST T ON clm.CLM_NBR = T.CLM_NUM AND clm.CMPL_DT_ID = TO_CHAR(T.DT_CMPLTD,''YYYYMMDD'') -- US132788 Pt B Weights SQL Enhancement
				LEFT OUTER JOIN bdr_dm.D_EC_PART_B_BL ecbbl ON ECB.D_EC_PART_B_SK = ECBbL.D_EC_PART_B_SK and CLMBL.BIL_LN_NBR = ECBBL.EC_BL_NBR --US91556
				LEFT OUTER JOIN bdr_dm.D_PLSRV PLSRV ON clm.D_PLSRV_SK = PLSRV.D_PLSRV_SK
				LEFT OUTER JOIN bdr_dm.D_PLSRV PLSRV1 ON ecbbl.EC_BL_PLSRV_CD = PLSRV1.PLSRV_CD */ --  US132788 Pt B Weights SQL Enhancement
				WHERE clmbl.srvc_from_dt_id BETWEEN :clm_pd_startdt_1
				AND :clm_pd_enddt_5
				AND clmbl.clm_pd_dt_id <= :clm_pd_enddt_5
				AND pln.PRDCT_GRP IN (''Med Supp'')
				and ben.ben_lvl = ''B3''
				and clmbl.adj_ben_amt <> 0) a
				LEFT JOIN (
					SELECT	DISTINCT  CARR_LOC_NBR,
						CARR_CATGY_CD  
					FROM BDR_DM.D_CARR 
					ORDER BY 1) CR 
				ON a.claim_location = CR.CARR_LOC_NBR
				LEFT JOIN bdr_dm.D_PLSRV PLSRV 
				ON a.PLSRV_CD = PLSRV.PLSRV_CD
				group by
				  Plan_Type,
				  state,
				  Service_Year,
				  Service_Month,
				  cpt_code,
				  claim_location,
				  TRIM(CAST(NVL(PLSRV.PLSRV_CD,
						''U'') AS VARCHAR(20))),
				  TRIM(CAST(NVL(PLSRV.PLSRV_DESC,''Unknown'') AS VARCHAR(200))),
				  EC_UB92_FLG,
				  CPT_CATGY_CD,
				  CARR_CATGY_CD,
				  PointTime
				 HAVING	SUM (a.Benefit_Total) > 0
			) b
		)
	SELECT	/*+ parallel(8) */
	  wr.Plan_Type,
	  wr.state,
	  wr.Service_Year,
	  wr.Service_Month,
	  wr.cpt_code,
	  wr.claim_location,
	  wr.PLSRV_CD,
	  wr.PLSRV_DESC,
	  wr.EC_UB92_FLG,
	  wr.CPT_CATGY_CD,
	  wr.CARR_CATGY_CD,
	  wr.Benefit_Total,
	  wr.Bill_Line_Cnt,
	  wr.benefit_total_pt,
	  wr.bill_line_count_pt,
	  wr.medpos,
	  wr.Carrier,
	  wr.medpos_set
	FROM wr;

	V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

	V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

	INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
	VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

--COMMENTED BY OAS--
/*
            V_ROWS_AFFTD := SQL%ROWCOUNT;
            COMMIT;

            INSERT INTO ETL.ETL_DETAIL_LOAD_INFO (APPLICATION,
                                                  ETL_BATCH_ID,
                                                  ETL_PROC_NAME,
                                                  ACTION,
                                                  STEP_INFO,
                                                  ROWS_AFFECTED,
                                                  ETL_DATETIME)
                 VALUES	(''PARTB'',
                         V_BTCH_ID,
                         V_PROC_NAME,
                         ''INSERT'',
                         ''Insert into TEMP_PART_B_WGT_DTL'',
                         V_ROWS_AFFTD,
                         SYSTIMESTAMP);

            COMMIT;

            V_ROWS_AFFTD := SQL%ROWCOUNT;
            COMMIT;

            INSERT INTO ETL.ETL_DETAIL_LOAD_INFO (APPLICATION,
                                                  ETL_BATCH_ID,
                                                  ETL_PROC_NAME,
                                                  ACTION,
                                                  STEP_INFO,
                                                  ROWS_AFFECTED,
                                                  ETL_DATETIME)
                 VALUES	(''PARTB'',
                         V_BTCH_ID,
                         V_PROC_NAME,
                         ''END'',
                         ''PROCEDURE ENDS'',
                         V_ROWS_AFFTD,
                         SYSTIMESTAMP);

            COMMIT;
            --Returns the result set
            P_ToContinueStatus := ''Y'';
            P_ErrorYNFlg := ''N'';
            P_ErrorStr := '''';*/
        /*EXCEPTION
           WHEN OTHERS
           THEN
              P_ErrorStr :=
                    ''ERROR: ''
                 || SQLCODE
                 || ''-''
                 || SQLERRM
                 || ''-''
                 || DBMS_UTILITY.FORMAT_ERROR_STACK ();
              P_ToContinueStatus := ''N'';
              P_ErrorYNFlg := ''Y'';
              ROLLBACK;
              */
--		END;
--    END IF;
--COMMENTED	BY OAS--


CALL UTIL.SP_ETL_CHECK_CONSTRAINTS(:DB_NAME , :APPLICATION , :WORKFLOW_NAME , :OBJECT_NAME , :V_BATCH_ID );		---------OAS ADD


UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''COMPLETE'', ERROR_MSG = null, BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
;
UPDATE  UTIL.ETL_BATCH_OBJECT_INCR_VALU SET INCR_COLUMN_VALUE = :V_BATCH_ID, LST_MOD_DT = CURRENT_TIMESTAMP() 
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID''
;

EXCEPTION

WHEN OTHER THEN

UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''ERROR'', ERROR_MSG = :SQLERRM,  BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
;

INSERT INTO  UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ERROR_MSG, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''ERROR'', :V_STEP_NAME, :V_STEP_SEQ, :SQLERRM, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() )
;



RAISE;

END;

';