USE SCHEMA BDR_DM; CREATE OR REPLACE PROCEDURE "SP_PREMIUM_INTERMEDIATE1_IXL_WRKSUSPENDEDMEDSUPPPLANS_D"("DB_NAME" VARCHAR(16777216), "APPLICATION" VARCHAR(16777216), "WORKFLOW_NAME" VARCHAR(16777216), "OBJECT_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '

-- Original workflow: wkf_Premium_Intermediate_IXL_TargetLoad1_D
-- Original mapping: m_Premium_Intermediate1_IXL_WrkSuspendedMedsuppPlans_D
-- Original folder: Premium
-- Original filename: wkf_Premium_Intermediate_IXL_TargetLoad1_D.XML

DECLARE


V_ROWS_INSERTED  INTEGER;
V_ROWS_UPDATED INTEGER;
V_ROWS_DELETED INTEGER;
V_LAST_QUERY_ID VARCHAR;

V_WH VARCHAR;
V_BATCH_ID INTEGER;


V_BATCH_OBJECT_START_TIME        VARCHAR;
V_STEP_START_TIME    VARCHAR;
V_STEP_NAME VARCHAR;
V_STEP_SEQ INTEGER DEFAULT 0;
V_ETL_LST_BTCH_ID INTEGER;


BEGIN

EXECUTE IMMEDIATE ''USE DATABASE ''||:DB_NAME; 

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_BATCH_OBJECT_START_TIME := (SELECT CURRENT_TIMESTAMP());



LET res1 RESULTSET := 
(

SELECT 

WH ,
BATCH_ID
  
FROM UTIL.ETL_BATCH_OBJECT_CONTROL
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
FETCH FIRST 1 ROW ONLY

)
;


LET C1 CURSOR FOR res1;
open C1;
FETCH C1 into  V_WH,V_BATCH_ID ;
close C1;





EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:V_WH;

USE SCHEMA BDR_DM;

INSERT INTO UTIL.ETL_BATCH_OBJECT_INCR_VALU (APPLICATION, WORKFLOW_NAME, OBJECT_NAME, INCR_COLUMN, INCR_COLUMN_VALUE )
SELECT * FROM (select :APPLICATION AS APPLICATION, :WORKFLOW_NAME AS WORKFLOW_NAME, :OBJECT_NAME AS OBJECT_NAME, ''ETL_LST_BTCH_ID'' AS INCR_COLUMN, -1 AS INCR_COLUMN_VALUE) A
WHERE NOT EXISTS (SELECT 1 FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU B WHERE B.APPLICATION = A.APPLICATION AND B.WORKFLOW_NAME = A.WORKFLOW_NAME AND B.OBJECT_NAME = A.OBJECT_NAME AND B.INCR_COLUMN = A.INCR_COLUMN)
;

V_ETL_LST_BTCH_ID :=(SELECT INCR_COLUMN_VALUE FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID'');

--OAS COMMENTED---
-- Component sc_tgt_WRK_SUSPENDED_MEDSUPP_PLANS_Insert, Type Pre SQL 
--CALL BDR_DM.PKG_DB_UTIL.SP_DBUTIL_CONFIG_D(''BDR_DM'',''WRK_SUSPENDED_MEDSUPP_PLANS'',''PRESQL'',''s_Premium_Intermediate1_IXL_WrkSuspendedMedsuppPlans_D'');

V_STEP_NAME    := ''TARGET - Truncate WRK_SUSPENDED_MEDSUPP_PLANS'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

truncate TABLE BDR_DM.WRK_SUSPENDED_MEDSUPP_PLANS;




INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );


--pre node line TARGET for sc_tgt_WRK_SUSPENDED_MEDSUPP_PLANS_Insert
V_STEP_NAME    := ''TARGET - INSERT WRK_SUSPENDED_MEDSUPP_PLANS'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

-- Component sq_INSURED_PLAN, Type SOURCE 
CREATE OR REPLACE TEMPORARY TABLE sq_INSURED_PLAN AS
(
SELECT SRC.*, row_number() over (order by 1) AS source_record_id FROM (
select Individual_ID, 
				Insured_Plan_ID, 
				Individual_Profile_Start_Date, 
				Individual_Profile_Stop_Date, 
				Plan_CD, 
				Plan_Category_ID,
				MedsuppRiderFlag from 
(select CIP.Individual_ID, 
				ip.Insured_Plan_ID, 
				CIP.Individual_Profile_Start_Date, 
				CIP.Individual_Profile_Stop_Date, 
				ip.Plan_CD, 
				PT.Plan_Category_ID,
				case when (TPR.Related_Plan_CD is not null) or (TPR.PlanTypeText = ''Both'' and TPR.Related_Plan_CD = ''DP'') 
					then ''Y''
					else ''N''
				end as MedsuppRiderFlag 
		from SRC_COMPAS_D.Individual_Profile CIP 
		join SRC_COMPAS_D.Insured_Plan IP on cip.Individual_ID = ip.Individual_ID
		join SRC_COMPAS_D.Plan P on ip.Plan_CD = p.Plan_CD
join SRC_COMPAS_D.Plan_Type PT on p.Plan_Type_ID = pt.Plan_Type_ID and pt.Plan_Category_ID in (1,3) /*  Get only Medsupp Base plans and rider plans */
		left join (select Related_Plan_CD, ''Medsupp'' as PlanTypeText			     
		from SRC_COMPAS_D.PLAN_RELATIONSHIP
		where Related_Plan_CD in (select Plan_Cd from SRC_COMPAS_D.PLAN where Plan_Type_ID = 7)
		and Base_Plan_CD in (select Plan_Cd from SRC_COMPAS_D.PLAN a 
    join SRC_COMPAS_D.Plan_Type b on a.Plan_Type_ID = b.Plan_Type_ID and b.Plan_Category_ID = 1)
    minus
   	select Related_Plan_CD, ''Medsupp'' as PlanTypeText			     
		from SRC_COMPAS_D.PLAN_RELATIONSHIP
		where Related_Plan_CD in (select Plan_Cd from SRC_COMPAS_D.PLAN where Plan_Type_ID = 7)
		and Base_Plan_CD in (select Plan_Cd from SRC_COMPAS_D.PLAN a 
							 join SRC_COMPAS_D.Plan_Type b on a.Plan_Type_ID = b.Plan_Type_ID and b.Plan_Category_ID = 2)

    union
   	    select Related_Plan_CD, ''HIC'' as PlanTypeText			     
		from SRC_COMPAS_D.PLAN_RELATIONSHIP
		where Related_Plan_CD in (select Plan_Cd from SRC_COMPAS_D.PLAN where Plan_Type_ID = 7)
		and Base_Plan_CD in (select Plan_Cd from SRC_COMPAS_D.PLAN a 
							 join SRC_COMPAS_D.Plan_Type b on a.Plan_Type_ID = b.Plan_Type_ID and b.Plan_Category_ID = 2)
		minus
        select Related_Plan_CD, ''HIC'' as PlanTypeText			     
		from SRC_COMPAS_D.PLAN_RELATIONSHIP
		where Related_Plan_CD in (select Plan_Cd from SRC_COMPAS_D.PLAN where Plan_Type_ID = 7)
		and Base_Plan_CD in (select Plan_Cd from SRC_COMPAS_D.PLAN a 
                             join SRC_COMPAS_D.Plan_Type b on a.Plan_Type_ID = b.Plan_Type_ID and b.Plan_Category_ID = 1)	
    union
    
	  select plan_cd as Related_Plan_CD, ''Both'' as PlanTypeText
		from SRC_COMPAS_D.Plan where Plan_Type_ID = 7
		minus
		(
		(
		
		select distinct Related_Plan_CD, ''Both'' as PlanTypeText			     
		from SRC_COMPAS_D.PLAN_RELATIONSHIP
		where Related_Plan_CD in 
    (select Plan_Cd from SRC_COMPAS_D.PLAN where Plan_Type_ID = 7)
		and Base_Plan_CD in (select Plan_Cd from SRC_COMPAS_D.PLAN a 
							 join SRC_COMPAS_D.Plan_Type b on a.Plan_Type_ID = b.Plan_Type_ID and b.Plan_Category_ID = 1)
    minus	
		
		select distinct Related_Plan_CD, ''Both'' as PlanTypeText			     
		from SRC_COMPAS_D.PLAN_RELATIONSHIP
		where Related_Plan_CD in (select Plan_Cd from SRC_COMPAS_D.PLAN where Plan_Type_ID = 7)
		and Base_Plan_CD in (select Plan_Cd from SRC_COMPAS_D.PLAN a 
							 join SRC_COMPAS_D.Plan_Type b on a.Plan_Type_ID = b.Plan_Type_ID and b.Plan_Category_ID = 2)
		)				     
		union
		( 
		
		select distinct Related_Plan_CD, ''Both'' as PlanTypeText			     
		from SRC_COMPAS_D.PLAN_RELATIONSHIP
		where Related_Plan_CD in (select Plan_Cd from SRC_COMPAS_D.PLAN where Plan_Type_ID = 7)
		and Base_Plan_CD in (select Plan_Cd from SRC_COMPAS_D.PLAN a 
							 join SRC_COMPAS_D.Plan_Type b on a.Plan_Type_ID = b.Plan_Type_ID and b.Plan_Category_ID = 2)
		minus	
			
		select distinct Related_Plan_CD, ''Both'' as PlanTypeText			     
		from SRC_COMPAS_D.PLAN_RELATIONSHIP
		where Related_Plan_CD in (select Plan_Cd from SRC_COMPAS_D.PLAN where Plan_Type_ID = 7)
		and Base_Plan_CD in (select Plan_Cd from SRC_COMPAS_D.PLAN a 
							 join SRC_COMPAS_D.Plan_Type b on a.Plan_Type_ID = b.Plan_Type_ID and b.Plan_Category_ID = 1)
		)				     
		)) TPR on (p.Plan_CD = TPR.Related_Plan_CD 
		and TPR.PlanTypeText in (''Medsupp'', ''Both'') and pt.Plan_Category_ID = 3)
		where 
		(cip.Individual_Profile_Start_Date between ip.Insured_Plan_Effective_Date and nvl(ip.Insured_Plan_Termination_Date,TO_TIMESTAMP(''12/31/9999'', ''MM/DD/YYYY''))
				or
		cip.Individual_Profile_Stop_Date between ip.Insured_Plan_Effective_Date and nvl(ip.Insured_Plan_Termination_Date,TO_TIMESTAMP(''12/31/9999'', ''MM/DD/YYYY'')))
				or
		(cip.Individual_Profile_Start_Date <= ip.Insured_Plan_Effective_Date and cip.Individual_Profile_Stop_Date >= nvl(ip.Insured_Plan_Termination_Date,TO_TIMESTAMP(''12/31/9999'', ''MM/DD/YYYY'')))			
		order by Individual_ID, Insured_Plan_ID) SuspPlan 
    where 
    SuspPlan.Plan_Category_ID = 1 or SuspPlan.MedsuppRiderFlag = ''Y''
) SRC
);





-- Component sc_tgt_WRK_SUSPENDED_MEDSUPP_PLANS_Insert, Type TARGET 
INSERT INTO BDR_DM.WRK_SUSPENDED_MEDSUPP_PLANS
(
INDIVIDUAL_ID,
INSUREDPLAN_ID,
INDIVIDUAL_PROFILE_STARTDATE,
INDIVIDUAL_PROFILE_STOPDATE,
PLAN_CD
)
SELECT
sq_INSURED_PLAN.INDIVIDUAL_ID /* INDIVIDUAL_ID */,
sq_INSURED_PLAN.INSURED_PLAN_ID /* INSUREDPLAN_ID */,
sq_INSURED_PLAN.INDIVIDUAL_PROFILE_START_DATE /* INDIVIDUAL_PROFILE_STARTDATE */,
sq_INSURED_PLAN.INDIVIDUAL_PROFILE_STOP_DATE /* INDIVIDUAL_PROFILE_STOPDATE */,
sq_INSURED_PLAN.PLAN_CD /* PLAN_CD */
FROM
sq_INSURED_PLAN;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );


INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

--OAS COMMENTED--
-- Component sc_tgt_WRK_SUSPENDED_MEDSUPP_PLANS_Insert, Type Post SQL 
--CALL BDR_DM.PKG_DB_UTIL.SP_DBUTIL_CONFIG_D(''BDR_DM'',''WRK_SUSPENDED_MEDSUPP_PLANS'',''POSTSQL'',''s_Premium_Intermediate1_IXL_WrkSuspendedMedsuppPlans_D'');

--BEGIN DBMS_STATS.GATHER_TABLE_STATS (ownname => ''DM'',tabname => ''WRK_SUSPENDED_MEDSUPP_PLANS'',partname => NULL,estimate_percent => 10,DEGREE => 4,granularity => ''ALL'',method_opt =>''FOR ALL COLUMNS SIZE 1'',CASCADE => TRUE);END; 

CALL UTIL.SP_ETL_CHECK_CONSTRAINTS(:DB_NAME , :APPLICATION , :WORKFLOW_NAME , :OBJECT_NAME , :V_BATCH_ID );

UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''COMPLETE'', ERROR_MSG = null, BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
;
UPDATE  UTIL.ETL_BATCH_OBJECT_INCR_VALU SET INCR_COLUMN_VALUE = :V_BATCH_ID, LST_MOD_DT = CURRENT_TIMESTAMP() 
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID''
;

EXCEPTION

WHEN OTHER THEN

UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''ERROR'', ERROR_MSG = :SQLERRM,  BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
;

INSERT INTO  UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ERROR_MSG, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''ERROR'', :V_STEP_NAME, :V_STEP_SEQ, :SQLERRM, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() )
;



RAISE;

END;

';