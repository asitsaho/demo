USE SCHEMA BDR_DM; CREATE OR REPLACE PROCEDURE "SP_CLAIMS_PURGE_PROCESS_STEP4"("DB_NAME" VARCHAR(16777216), "APPLICATION" VARCHAR(16777216), "WORKFLOW_NAME" VARCHAR(16777216), "OBJECT_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '

-- Original workflow: wkf_Claims_Purge_Process
-- Original mapping: m_Claims_Purge_Process_step4
-- Original folder: CLAIMS
-- Original filename: wkf_Claims_Purge_Process.XML

DECLARE


V_ROWS_INSERTED  INTEGER;
V_ROWS_UPDATED INTEGER;
V_ROWS_DELETED INTEGER;
V_LAST_QUERY_ID VARCHAR;

V_WH VARCHAR;
V_BATCH_ID INTEGER;


V_BATCH_OBJECT_START_TIME        VARCHAR;
V_STEP_START_TIME    VARCHAR;
V_STEP_NAME VARCHAR;
V_STEP_SEQ INTEGER DEFAULT 0;
V_ETL_LST_BTCH_ID INTEGER;
V_PURGE_YR VARCHAR;
V_STAT_CD VARCHAR;
v_MIN_DT  VARCHAR;
v_MAX_DT  VARCHAR;


BEGIN

EXECUTE IMMEDIATE ''USE DATABASE ''||:DB_NAME; 

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_BATCH_OBJECT_START_TIME := (SELECT CURRENT_TIMESTAMP());



LET res1 RESULTSET := 
(

SELECT 

WH ,
BATCH_ID
  
FROM UTIL.ETL_BATCH_OBJECT_CONTROL
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
FETCH FIRST 1 ROW ONLY

)
;


LET C1 CURSOR FOR res1;
open C1;
FETCH C1 into  V_WH,V_BATCH_ID ;
close C1;


LET res2 RESULTSET := 

(

WITH PARAMETERS (STAT_CD) AS
(
  
SELECT * 
FROM  
(SELECT PARAMETER_NAME, PARAMETER_VALUE  FROM UTIL.ETL_OBJECT_PARAMETER_VALUE 
WHERE 1 = 1
AND APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
AND ACTIVE_FLG = ''Y''  
  
UNION ALL       

SELECT PARAMETER_NAME, PARAMETER_VALUE  FROM UTIL.ETL_GLOBAL_PARAMETER_VALUE WHERE PAR_GLOBAL_TYPE = ''PARGLOBAL_OPREPORTS'' AND ACTIVE_FLG = ''Y''
AND PARAMETER_NAME NOT IN  (
SELECT PARAMETER_NAME  FROM UTIL.ETL_OBJECT_PARAMETER_VALUE WHERE 1 = 1
AND APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
AND ACTIVE_FLG = ''Y''   ))
 
PIVOT(MAX(PARAMETER_VALUE) FOR PARAMETER_NAME IN (''STAT_CD'')) 

 
)  
SELECT * FROM PARAMETERS 
)  
  
;


LET C2 CURSOR FOR res2;
open C2;
FETCH C2 into  V_STAT_CD; 
close C2;



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:V_WH;
USE SCHEMA BDR_DM;	------------OAS ADD


INSERT INTO UTIL.ETL_BATCH_OBJECT_INCR_VALU (APPLICATION, WORKFLOW_NAME, OBJECT_NAME, INCR_COLUMN, INCR_COLUMN_VALUE )
SELECT * FROM (select :APPLICATION AS APPLICATION, :WORKFLOW_NAME AS WORKFLOW_NAME, :OBJECT_NAME AS OBJECT_NAME, ''ETL_LST_BTCH_ID'' AS INCR_COLUMN, -1 AS INCR_COLUMN_VALUE) A
WHERE NOT EXISTS (SELECT 1 FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU B WHERE B.APPLICATION = A.APPLICATION AND B.WORKFLOW_NAME = A.WORKFLOW_NAME AND B.OBJECT_NAME = A.OBJECT_NAME AND B.INCR_COLUMN = A.INCR_COLUMN)
;

V_ETL_LST_BTCH_ID :=(SELECT INCR_COLUMN_VALUE FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID'');

SELECT CASE
                           WHEN EXTRACT (MONTH FROM CURRENT_DATE) BETWEEN 7 AND 12
                           THEN
                               EXTRACT (YEAR FROM CURRENT_DATE) - 9
                           ELSE
                               EXTRACT (YEAR FROM CURRENT_DATE) - 10
                       END
                       INTO V_PURGE_YR
               					
                  FROM DUAL;






---------------COMMENTED BY OAS-----------------
/*
CREATE OR REPLACE PROCEDURE DM.CLAIM_PURGE_STEP4
AS
    V_STAT_CD   VARCHAR2 (1);
BEGIN
    SELECT METADATA_VALUE
      INTO V_STAT_CD
      FROM ETL.ETL_APPLICATION_METADATA
     WHERE METADATA_DESC = ''CLAIM_PURGE_STEP4'';
*/
---------------COMMENTED BY OAS-----------------

    IF (:V_STAT_CD = ''Y'')
    THEN
        BEGIN

---------------COMMENTED BY OAS-----------------
/*
            DECLARE
                v_rows_inserted   NUMBER (10);
                v_MIN_DT          NUMBER (10);
                v_MAX_DT          NUMBER (10);
                v_PURGE_YR        NUMBER (10);
            BEGIN
                SELECT CASE
                           WHEN EXTRACT (MONTH FROM SYSDATE) BETWEEN 7 AND 12
                           THEN
                               EXTRACT (YEAR FROM SYSDATE) - 9
                           ELSE
                               EXTRACT (YEAR FROM SYSDATE) - 10
                       END
                  INTO v_PURGE_YR
                  FROM DUAL;
*/
---------------COMMENTED BY OAS-----------------
  
			V_STEP_NAME    := :V_PURGE_YR||''_''||''DELETE - F_OVPAY_DTL'';
			V_STEP_SEQ     :=  V_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

                SELECT MIN (CMPL_DT_ID), MAX (CMPL_DT_ID)
                  INTO v_MIN_DT, v_MAX_DT
                  FROM BDR_DM.ETL_CLM_PD_DT_XREF
                 WHERE SUBSTR (CLM_PD_DT_ID, 1, 4) =
                       (SELECT CASE
                                   WHEN EXTRACT (MONTH FROM CURRENT_DATE) BETWEEN 7
                                                                         AND 12
                                   THEN
                                       EXTRACT (YEAR FROM CURRENT_DATE) - 9
                                   ELSE
                                       EXTRACT (YEAR FROM CURRENT_DATE) - 10
                               END    RES
                          FROM DUAL);


                ----------------------------------------------------------------DELETE FROM DM.F_OVPAY_DTL_SK----------------------------------------------------------------------

---------------COMMENTED BY OAS-----------------
/*
                INSERT INTO ETL.ETL_DETAIL_LOAD_INFO (APPLICATION,
                                                      ETL_BATCH_ID,
                                                      ETL_PROC_NAME,
                                                      ACTION,
                                                      STEP_INFO,
                                                      ROWS_AFFECTED,
                                                      ETL_DATETIME)
                     VALUES (''CLAIMS'',
                             1,
                             ''CLAIMPURGE_STEP4_'' || v_PURGE_YR,
                             ''START'',
                             ''Delete from F_OVPAY_DTL'',
                             0,
                             SYSTIMESTAMP);

                COMMIT;
*/
---------------COMMENTED BY OAS-----------------

               DELETE /*+ parallel(8) */
                       FROM
                    BDR_DM.F_OVPAY_DTL
                      WHERE F_OVPAY_DTL_SK IN
                                (SELECT F_OVPAY_DTL_SK
                                   FROM BDR_DM.F_OVPAY_DTL  OV
                                        JOIN BDR_DM.F_CLM_HIST F
                                            ON OV.CLM_NBR = F.CLM_NBR
                                        JOIN BDR_DM.TEMP_CLAIMHIST T
                                            ON F.F_CLM_HIST_SK =
                                               T.F_CLM_HIST_SK
                                  WHERE SRC_DEL_FLG = ''Y'');
										
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;
			
			V_ROWS_DELETED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );
			
			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );
 
---------------COMMENTED BY OAS-----------------
/*
                v_rows_inserted := SQL%ROWCOUNT;

                COMMIT;

                INSERT INTO ETL.ETL_DETAIL_LOAD_INFO (APPLICATION,
                                                      ETL_BATCH_ID,
                                                      ETL_PROC_NAME,
                                                      ACTION,
                                                      STEP_INFO,
                                                      ROWS_AFFECTED,
                                                      ETL_DATETIME)
                     VALUES (''CLAIMS'',
                             1,
                             ''CLAIMPURGE_STEP4_'' || v_PURGE_YR,
                             ''END'',
                             ''Delete from F_OVPAY_DTL'',
                             v_rows_inserted,
                             SYSTIMESTAMP);

                COMMIT;


                ----------------------------------------------------------------DELETE FROM DM.F_OVPAY_SUM----------------------------------------------------------------------


                INSERT INTO ETL.ETL_DETAIL_LOAD_INFO (APPLICATION,
                                                      ETL_BATCH_ID,
                                                      ETL_PROC_NAME,
                                                      ACTION,
                                                      STEP_INFO,
                                                      ROWS_AFFECTED,
                                                      ETL_DATETIME)
                     VALUES (''CLAIMS'',
                             1,
                             ''CLAIMPURGE_STEP4_'' || v_PURGE_YR,
                             ''START'',
                             ''Delete from F_OVPAY_SUM'',
                             0,
                             SYSTIMESTAMP);

                COMMIT;
*/
---------------COMMENTED BY OAS-----------------
  
			V_STEP_NAME    := :V_PURGE_YR||''_''||''DELETE - F_OVPAY_SUM'';
			V_STEP_SEQ     :=  V_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

                DELETE /*+ parallel(8) */
                       FROM
                    BDR_DM.F_OVPAY_SUM
                      WHERE F_OVPAY_SUM_SK IN
                                (SELECT F_OVPAY_SUM_SK
                                   FROM BDR_DM.F_OVPAY_SUM  OV
                                        JOIN BDR_DM.F_CLM_HIST F
                                            ON OV.CLM_NBR = F.CLM_NBR
                                        JOIN BDR_DM.TEMP_CLAIMHIST T
                                            ON F.F_CLM_HIST_SK =
                                               T.F_CLM_HIST_SK
                                  WHERE SRC_DEL_FLG = ''Y'');
										
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;
			
			V_ROWS_DELETED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );
			
			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );
 
---------------COMMENTED BY OAS-----------------
/*
                v_rows_inserted := SQL%ROWCOUNT;

                COMMIT;


                INSERT INTO ETL.ETL_DETAIL_LOAD_INFO (APPLICATION,
                                                      ETL_BATCH_ID,
                                                      ETL_PROC_NAME,
                                                      ACTION,
                                                      STEP_INFO,
                                                      ROWS_AFFECTED,
                                                      ETL_DATETIME)
                     VALUES (''CLAIMS'',
                             1,
                             ''CLAIMPURGE_STEP4_'' || v_PURGE_YR,
                             ''END'',
                             ''Delete from F_OVPAY_SUM'',
                             v_rows_inserted,
                             SYSTIMESTAMP);

                COMMIT;


                -------------------------------------------------------------------DELETE FROM CLAIMHIST TBL---------------------------------------------------------------------------


                INSERT INTO ETL.ETL_DETAIL_LOAD_INFO (APPLICATION,
                                                      ETL_BATCH_ID,
                                                      ETL_PROC_NAME,
                                                      ACTION,
                                                      STEP_INFO,
                                                      ROWS_AFFECTED,
                                                      ETL_DATETIME)
                     VALUES (''CLAIMS'',
                             1,
                             ''CLAIMPURGE_STEP4_'' || v_PURGE_YR,
                             ''START'',
                             ''Delete from CLAIMHIST'',
                             0,
                             SYSTIMESTAMP);

                COMMIT;
*/
---------------COMMENTED BY OAS-----------------
  
			V_STEP_NAME    := :V_PURGE_YR||''_''||''DELETE - F_CLM_HIST'';
			V_STEP_SEQ     :=  V_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

                DELETE /*+ parallel(8) */
                       FROM BDR_DM.F_CLM_HIST B
                      WHERE F_CLM_HIST_SK IN (SELECT a.F_CLM_HIST_SK
                                                FROM BDR_DM.Temp_ClaimHist a);
										
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;
			
			V_ROWS_DELETED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );
			
			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );
 
---------------COMMENTED BY OAS-----------------
/*
                v_rows_inserted := SQL%ROWCOUNT;

                COMMIT;



                INSERT INTO ETL.ETL_DETAIL_LOAD_INFO (APPLICATION,
                                                      ETL_BATCH_ID,
                                                      ETL_PROC_NAME,
                                                      ACTION,
                                                      STEP_INFO,
                                                      ROWS_AFFECTED,
                                                      ETL_DATETIME)
                     VALUES (''CLAIMS'',
                             1,
                             ''CLAIMPURGE_STEP4_'' || v_PURGE_YR,
                             ''END'',
                             ''Delete from CLAIMHIST'',
                             v_rows_inserted,
                             SYSTIMESTAMP);

                COMMIT;
*/
---------------COMMENTED BY OAS-----------------

  
			V_STEP_NAME    := :V_PURGE_YR||''_''||''DELETE - WRK_CLAIM_BILLLINE_INCURRAL'';
			V_STEP_SEQ     :=  V_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

                DELETE /*+ parallel(8) */
                       FROM BDR_DM.WRK_CLAIM_BILLLINE_INCURRAL
                      WHERE CMPL_DT_ID BETWEEN :v_MIN_DT AND :v_MAX_DT;
										
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;
			
			V_ROWS_DELETED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );
			
			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );
 
---------------COMMENTED BY OAS-----------------
/*
                v_rows_inserted := SQL%ROWCOUNT;

                COMMIT;

                INSERT INTO ETL.ETL_DETAIL_LOAD_INFO (APPLICATION,
                                                      ETL_BATCH_ID,
                                                      ETL_PROC_NAME,
                                                      ACTION,
                                                      STEP_INFO,
                                                      ROWS_AFFECTED,
                                                      ETL_DATETIME)
                     VALUES (''CLAIMS'',
                             1,
                             ''CLAIMPURGE_STEP4_'' || v_PURGE_YR,
                             ''END'',
                             ''Delete from WRK_CLAIM_BILLLINE_INCURRAL'',
                             v_rows_inserted,
                             SYSTIMESTAMP);

                COMMIT;
*/
---------------COMMENTED BY OAS-----------------

                -------------------------------------------------------------------DELETE FROM BUW AND CLM_INT DIM TBL---------------------------------------------------------------------------

  
			V_STEP_NAME    := :V_PURGE_YR||''_''||''DELETE - D_BUW'';
			V_STEP_SEQ     :=  V_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

                DELETE /*+ parallel(8) */
                       FROM
                    BDR_DM.D_BUW
                      WHERE D_BUW_SK IN
                                (SELECT /*+ parallel(8) */
                                        A.D_BUW_SK
                                   FROM BDR_DM.D_BUW  a
                                        JOIN SRC_FOX_D.CLM_HIST b
                                            ON     a.CH_KEY = b.CH_KEY
                                               AND a.CH_ACCT_PART_NBR =
                                                   b.CH_ACCT_PART_NUM
                                  WHERE     TO_CHAR (DT_CMPLTD, ''YYYYMMDD'') BETWEEN :v_MIN_DT
                                                                                AND :v_MAX_DT
                                        AND D_BUW_SK > 0);
										
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;
			
			V_ROWS_DELETED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );
			
			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );
 
                --2111
---------------COMMENTED BY OAS-----------------
/*
                v_rows_inserted := SQL%ROWCOUNT;

                COMMIT;


                INSERT INTO ETL.ETL_DETAIL_LOAD_INFO (APPLICATION,
                                                      ETL_BATCH_ID,
                                                      ETL_PROC_NAME,
                                                      ACTION,
                                                      STEP_INFO,
                                                      ROWS_AFFECTED,
                                                      ETL_DATETIME)
                     VALUES (''CLAIMS'',
                             1,
                             ''CLAIMPURGE_STEP4_'' || v_PURGE_YR,
                             ''END'',
                             ''Delete from D_BUW'',
                             v_rows_inserted,
                             SYSTIMESTAMP);

                COMMIT;
*/
---------------COMMENTED BY OAS-----------------

                --------------------------DELETE FROM D_CLM_INT DIM
  
			V_STEP_NAME    := :V_PURGE_YR||''_''||''DELETE - D_CLM_INT'';
			V_STEP_SEQ     :=  V_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

                DELETE /*+ parallel(8) */
                       FROM
                    BDR_DM.D_CLM_INT
                      WHERE D_CLM_INT_SK IN
                                (SELECT /*+ parallel(8) */
                                        a.D_CLM_INT_SK
                                   FROM BDR_DM.D_CLM_INT  a
                                        JOIN SRC_FOX_D.CLM_HIST b
                                            ON     a.CH_KEY = b.CH_KEY
                                               AND a.CH_ACCT_PART_NBR =
                                                   b.CH_ACCT_PART_NUM
                                  WHERE     TO_CHAR (DT_CMPLTD, ''YYYYMMDD'') BETWEEN :v_MIN_DT
                                                                                AND :v_MAX_DT
                                        AND D_CLM_INT_SK > 0);
										
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;
			
			V_ROWS_DELETED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );
			
			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );
 
                --24712
---------------COMMENTED BY OAS-----------------
/*
                v_rows_inserted := SQL%ROWCOUNT;

                COMMIT;



                INSERT INTO ETL.ETL_DETAIL_LOAD_INFO (APPLICATION,
                                                      ETL_BATCH_ID,
                                                      ETL_PROC_NAME,
                                                      ACTION,
                                                      STEP_INFO,
                                                      ROWS_AFFECTED,
                                                      ETL_DATETIME)
                     VALUES (''CLAIMS'',
                             1,
                             ''CLAIMPURGE_STEP4_'' || v_PURGE_YR,
                             ''END'',
                             ''Delete from D_CLM_INT'',
                             v_rows_inserted,
                             SYSTIMESTAMP);

                COMMIT;
            END;
*/
---------------COMMENTED BY OAS-----------------
		END;
	END IF;
--			END;
--			/




UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''COMPLETE'', ERROR_MSG = null, BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
;
UPDATE  UTIL.ETL_BATCH_OBJECT_INCR_VALU SET INCR_COLUMN_VALUE = :V_BATCH_ID, LST_MOD_DT = CURRENT_TIMESTAMP() 
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID''
;


EXCEPTION

WHEN OTHER THEN

UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''ERROR'', ERROR_MSG = :SQLERRM,  BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
;

INSERT INTO  UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ERROR_MSG, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''ERROR'', :V_STEP_NAME, :V_STEP_SEQ, :SQLERRM, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() )
;



RAISE;

END;

';