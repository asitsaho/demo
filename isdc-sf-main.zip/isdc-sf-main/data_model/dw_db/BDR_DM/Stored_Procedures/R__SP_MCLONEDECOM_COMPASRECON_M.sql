USE SCHEMA BDR_DM;
CREATE OR REPLACE PROCEDURE "SP_MCLONEDECOM_COMPASRECON_M"("DB_NAME" VARCHAR(16777216), "APPLICATION" VARCHAR(16777216), "WORKFLOW_NAME" VARCHAR(16777216), "OBJECT_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '

-- Original workflow: wkf_MCloneDecom_CompasRecon_M
-- Original mapping: m_MCloneDecom_CompasRecon_M
-- Original folder: Compas_Reports

DECLARE


V_ROWS_INSERTED  INTEGER;
V_ROWS_UPDATED INTEGER;
V_ROWS_DELETED INTEGER;
V_LAST_QUERY_ID VARCHAR;

V_WH VARCHAR;
V_BATCH_ID INTEGER;


V_BATCH_OBJECT_START_TIME        VARCHAR;
V_STEP_START_TIME    VARCHAR;
V_STEP_NAME VARCHAR;
V_STEP_SEQ INTEGER DEFAULT 0;
V_ETL_LST_BTCH_ID INTEGER;

g_retro_date TIMESTAMP := TO_TIMESTAMP(''01-Jan-2002'',''dd-mon-yyyy'');

v_report_date     TIMESTAMP;
v_report_start	  TIMESTAMP;
v_report_end	  TIMESTAMP;
V_DAY INTEGER;

v_amount        NUMBER(38,2);
v_lockbox_tot_amt   NUMBER(38,2);
v_lockbox_prem_amt   NUMBER(38,2);
v_lockbox_emp_amt   NUMBER(38,2);
v_lockbox_memb_amt   NUMBER(38,2);
v_lockbox_and_amt   NUMBER(38,2);
v_eft_tot_amt   NUMBER(38,2);
v_eft_prem_amt   NUMBER(38,2);
v_eft_emp_amt   NUMBER(38,2);
v_eft_memb_amt   NUMBER(38,2);
v_eft_and_amt   NUMBER(38,2);
v_enrollment_amt    NUMBER(38,2);
v_enrollment_tot_amt   NUMBER(38,2);
v_enrollment_prem_amt   NUMBER(38,2);
v_enrollment_emp_amt   NUMBER(38,2);
v_enrollment_memb_amt   NUMBER(38,2);
v_enrollment_and_amt   NUMBER(38,2);
v_checkfree_tot_amt   NUMBER(38,2);
v_checkfree_prem_amt   NUMBER(38,2);
v_checkfree_emp_amt   NUMBER(38,2);
v_checkfree_memb_amt   NUMBER(38,2);
v_checkfree_and_amt   NUMBER(38,2);
v_auto_credit_tot_amt NUMBER(38,2);
v_auto_credit_prem_amt NUMBER(38,2);
v_auto_credit_emp_amt NUMBER(38,2);
v_auto_credit_memb_amt NUMBER(38,2);
v_auto_credit_and_amt NUMBER(38,2);

v_online_credit_tot_amt   NUMBER(38,2);
v_online_credit_prem_amt   NUMBER(38,2);
v_online_credit_emp_amt   NUMBER(38,2);
v_online_credit_memb_amt   NUMBER(38,2);
v_online_credit_and_amt   NUMBER(38,2);
v_online_check_tot_amt   NUMBER(38,2);
v_online_check_prem_amt   NUMBER(38,2);
v_online_check_emp_amt   NUMBER(38,2);
v_online_check_memb_amt   NUMBER(38,2);
v_online_check_and_amt   NUMBER(38,2);
v_online_wire_tot_amt   NUMBER(38,2);
v_online_wire_prem_amt   NUMBER(38,2);
v_online_wire_emp_amt   NUMBER(38,2);
v_online_wire_memb_amt   NUMBER(38,2);
v_online_wire_and_amt   NUMBER(38,2);
v_online_misc_tot_amt   NUMBER(38,2);
v_online_misc_prem_amt   NUMBER(38,2);
v_online_misc_emp_amt   NUMBER(38,2);
v_online_misc_memb_amt   NUMBER(38,2);
v_online_misc_and_amt   NUMBER(38,2);

v_waiver_tot_amt   NUMBER(38,2);
v_waiver_prem_amt   NUMBER(38,2);
v_waiver_emp_amt   NUMBER(38,2);
v_prorated_credit_tot_amt   NUMBER(38,2);
v_prorated_credit_prem_amt   NUMBER(38,2);
v_prorated_credit_emp_amt   NUMBER(38,2);

v_retrocredit_tot_amt   NUMBER(38,2);
v_retrocredit_prem_amt   NUMBER(38,2);
v_retrocredit_emp_amt   NUMBER(38,2);

v_refund        NUMBER(38,2);

v_returns_tot_amt   NUMBER(38,2);
v_returns_prem_amt   NUMBER(38,2);
v_returns_emp_amt   NUMBER(38,2);
v_returns_memb_amt   NUMBER(38,2);
v_returns_and_amt   NUMBER(38,2);

v_eft_protest        NUMBER(38,2);

v_miscloss_tot_amt   NUMBER(38,2);
v_miscloss_prem_amt   NUMBER(38,2);
v_miscloss_emp_amt   NUMBER(38,2);
v_retrodebit_tot_amt   NUMBER(38,2);
v_retrodebit_prem_amt   NUMBER(38,2);
v_retrodebit_emp_amt   NUMBER(38,2);

v_proratedloss_tot_amt   NUMBER(38,2);
v_proratedloss_prem_amt   NUMBER(38,2);
v_proratedloss_emp_amt   NUMBER(38,2);

v_claims_prem        NUMBER(38,2);
v_claims_tot        NUMBER(38,2);
v_claims_emp        NUMBER(38,2);
v_claims_memb    NUMBER(38,2);
v_claims_and    NUMBER(38,2);

v_unclaimed_tot_amt   NUMBER(38,2);

v_nonaffiliate        NUMBER(38,2);

v_unclaimed_prem_amt   NUMBER(38,2);
v_unclaimed_emp_amt   NUMBER(38,2);
v_unclaimed_memb_amt   NUMBER(38,2);
v_unclaimed_and_amt   NUMBER(38,2);

v_pdp_amt       NUMBER(38,2);
v_mapd_amt      NUMBER(38,2);
v_emp_pdp_amt   NUMBER(38,2);
v_emp_mapd_amt  NUMBER(38,2);

v_bt_no_mt_tot_amt   NUMBER(38,2);
v_bt_no_mt_prem_amt   NUMBER(38,2);
v_bt_no_mt_emp_amt   NUMBER(38,2);
v_bt_no_mt_memb_amt   NUMBER(38,2);
v_bt_no_mt_and_amt   NUMBER(38,2);

v_count         NUMBER;


BEGIN

EXECUTE IMMEDIATE ''USE DATABASE ''||:DB_NAME; 

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_BATCH_OBJECT_START_TIME := (SELECT CURRENT_TIMESTAMP());



LET res1 RESULTSET := 
(

SELECT 

WH ,
BATCH_ID
  
FROM UTIL.ETL_BATCH_OBJECT_CONTROL
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
FETCH FIRST 1 ROW ONLY

)
;


LET C1 CURSOR FOR res1;
open C1;
FETCH C1 into  V_WH,V_BATCH_ID ;
close C1;


LET res2 RESULTSET := 

(

WITH PARAMETERS (DAY) AS
(
  
SELECT * 
FROM  
(SELECT PARAMETER_NAME, PARAMETER_VALUE  FROM UTIL.ETL_OBJECT_PARAMETER_VALUE 
WHERE 1 = 1
AND APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
AND ACTIVE_FLG = ''Y''  
  
UNION ALL       

SELECT PARAMETER_NAME, PARAMETER_VALUE  FROM UTIL.ETL_GLOBAL_PARAMETER_VALUE WHERE PAR_GLOBAL_TYPE = ''PARGLOBAL_OPREPORTS'' AND ACTIVE_FLG = ''Y''
AND PARAMETER_NAME NOT IN  (
SELECT PARAMETER_NAME  FROM UTIL.ETL_OBJECT_PARAMETER_VALUE WHERE 1 = 1
AND APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
AND ACTIVE_FLG = ''Y''   ))
 
PIVOT(MAX(PARAMETER_VALUE) FOR PARAMETER_NAME IN (''DAY'')) 

 
)  
SELECT * FROM PARAMETERS 
)   
;


LET C2 CURSOR FOR res2;
open C2;
FETCH C2 into V_DAY; 
close C2;



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:V_WH;
USE SCHEMA BDR_DM;	------------OAS ADD


INSERT INTO UTIL.ETL_BATCH_OBJECT_INCR_VALU (APPLICATION, WORKFLOW_NAME, OBJECT_NAME, INCR_COLUMN, INCR_COLUMN_VALUE )
SELECT * FROM (select :APPLICATION AS APPLICATION, :WORKFLOW_NAME AS WORKFLOW_NAME, :OBJECT_NAME AS OBJECT_NAME, ''ETL_LST_BTCH_ID'' AS INCR_COLUMN, -1 AS INCR_COLUMN_VALUE) A
WHERE NOT EXISTS (SELECT 1 FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU B WHERE B.APPLICATION = A.APPLICATION AND B.WORKFLOW_NAME = A.WORKFLOW_NAME AND B.OBJECT_NAME = A.OBJECT_NAME AND B.INCR_COLUMN = A.INCR_COLUMN)
;

V_ETL_LST_BTCH_ID :=(SELECT INCR_COLUMN_VALUE FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID'');


						----------------CODE FOR MAIN PROCEDURE ETL.SP_ETL_MCLONE_DECOM_M BEGINS------------------------

--------COMMENTED BY OAS--------
/*
CREATE OR REPLACE PROCEDURE ETL."SP_ETL_MCLONE_DECOM_M"(
    p_etlname IN VARCHAR2,
    p_etlseq  IN NUMBER,
    p_tocontinuestatus OUT VARCHAR2,
    p_errorynflg OUT VARCHAR2,
    p_errorstr OUT VARCHAR2)
AS

BEGIN

		SELECT MIN(proc_launch_order)			------RESULT WILL BE 12
          INTO lv_min_order
          FROM ETL.ETL_MCLONE_DECOM_PROC_LIST
          WHERE etl_name = p_etlname	-----''COMPAS_RECON''
          AND etl_seq    = p_etlseq		-----1
          AND active_ind = ''Y'';
		

          SELECT MAX(proc_launch_order)		----------RESULT WILL BE 12
          INTO lv_max_order
          FROM ETL.ETL_MCLONE_DECOM_PROC_LIST
          WHERE etl_name = p_etlname	-----''COMPAS_RECON''
          AND etl_seq    = p_etlseq		-----1
          AND active_ind = ''Y'';

          SELECT MAX(batch_id)
          INTO lv_batch_id
          FROM etl.etl_batch_log
          WHERE application = ''COMPAS_REPORTS''
          AND batch_status != ''COMPLETE'';

          UPDATE ETL.ETL_MCLONE_DECOM_PROC_LIST
          SET batch_id   = lv_batch_id
          WHERE etl_name = p_etlname
          AND etl_seq    = p_etlseq
          AND active_ind = ''Y'';
          COMMIT;

          --Find Next Row to Process
          WHILE lv_min_order < (lv_max_order + 1 )		-----------12< 12+1 for 1st iteration --> TRUE,  13<12+1 for next iteration --> FALSE --- 
          LOOP

                    --dbms_output.put_line(''Min Loop Start'' || lv_min_order);
                    --dbms_output.put_line(''Max Loop Start'' || lv_max_order);

                    lv_next_rec_found      := ''Y'';

                    WHILE lv_next_rec_found = ''Y''
                    LOOP
                              BEGIN
                                      lv_proc_name := NULL;

                                      -- Get the Proc Name
                                      SELECT proc_name,
                                        batch_id		
                                      INTO lv_proc_name,	
                                        lv_batch_id
                                      FROM
                                        (SELECT proc_name,
                                          batch_id
                                        FROM ETL.ETL_MCLONE_DECOM_PROC_LIST
                                        WHERE run_status      in (''READY'',''ERROR'')
                                        AND proc_launch_order = lv_min_order	--------------12 
                                        AND active_ind = ''Y''
                                        )
                                      WHERE ROWNUM = 1;

                                      --Proc Found
                                      IF lv_proc_name IS NOT NULL THEN

                                                SELECT SYSDATE INTO lv_etl_start_time FROM dual;

                                                UPDATE ETL.ETL_MCLONE_DECOM_PROC_LIST
                                                SET run_status        = ''INPROCESS'',
                                                  etl_start_time      = lv_etl_start_time
                                                WHERE batch_id        = lv_batch_id
                                                AND proc_name         = lv_proc_name
                                                AND proc_launch_order = lv_min_order;

                                                --Continue, if no records updated
                                                lv_row_aff_by_upd   := SQL % rowcount;

                                                IF lv_row_aff_by_upd = 0 THEN
                                                  ROLLBACK;
                                                  CONTINUE;
                                                ELSE
                                                  COMMIT;
                                                END IF;
                                      END IF;

                                      --Execute Procedure
                                      BEGIN
                                                lv_proc_final := ''begin '' || lv_proc_name || '' end;'';

                                                EXECUTE IMMEDIATE (lv_proc_final);		-------OAS - IT WILL CALL COMPAS_MO.PKG_DAILY_RECON.PR_RECON();
*/
--------COMMENTED BY OAS--------

									------------- CODE FOR COMPAS_MO.PKG_DAILY_RECON.PR_RECON(); BEGINS---------------

	--------COMMENTED BY OAS--------
	/*	
		PROCEDURE pr_recon
		IS

			CURSOR c IS SELECT create_time FROM COMPAS_MO.monthend_log
			ORDER BY create_time DESC;

			-- v_report_date   DATE := LAST_DAY(ADD_MONTHS(TRUNC(SYSDATE),-1));
			-- SCR  14625 and SCR 21908
			v_report_date      DATE := COMPAS_MO.fn_get_last_day_of_month;
			v_report_start  TIMESTAMP;
			v_report_end    TIMESTAMP;

		BEGIN


			OPEN c;
			FETCH c INTO v_report_end;

			/* Monthend_log is ordered by create_time desc therefore the 1st row is the
			current monthend time i.e. the report_end timestamp and the 2nd row is the
			last monthend time i.e. the report_start timestamp. Report date is the last
			day of the prior month  *//*

			IF c%NOTFOUND THEN
				RAISE NO_DATA_FOUND;
			END IF;

			FETCH c INTO v_report_start;

			IF c%NOTFOUND THEN
				RAISE NO_DATA_FOUND;
			END IF;

			CLOSE c;
	*/
	---------------COMMENTED BY OAS-----------------
			v_report_date := (SELECT TRUNC(TO_TIMESTAMP(CASE WHEN extract(day FROM CURRENT_TIMESTAMP) <= :V_DAY THEN
								LAST_DAY(ADD_MONTHS(CURRENT_TIMESTAMP, -1))
							ELSE
								LAST_DAY(CURRENT_TIMESTAMP) END), ''DD''));
								
v_report_start :=  (select to_timestamp(substr(max(timestamp_value),1,14),''YYYYMMDDHH24MISS'') from util.etl_extract_process_dates where application=''CDC_COMPAS'' and substr(timestamp_value,1,6) in 
(SELECT TO_CHAR(ADD_MONTHS(CURRENT_DATE, -2),''YYYYMM'') ) );
			
v_report_end := ( select to_timestamp(substr(max(timestamp_value),1,14),''YYYYMMDDHH24MISS'') from util.etl_extract_process_dates where application=''CDC_COMPAS'' and substr(timestamp_value,1,6) in 
(SELECT TO_CHAR(ADD_MONTHS(CURRENT_DATE, -1),''YYYYMM'') ) );

		--pr_recon2(v_report_date,v_report_start,v_report_end);
		
									------------- CODE FOR pr_recon2(); BEGINS---------------
	---------------COMMENTED BY OAS-----------------
	/*
			PROCEDURE pr_recon2 ( p_report_date  IN DATE ,
                     p_report_start IN timestamp,
                     p_report_end   IN timestamp )
			IS

			/*

			DECLARE
			p_report_date DATE  := ''31-Jul-2004'';
			p_report_start TIMESTAMP := TO_TIMESTAMP(''01-JUL-2004 00:13:06'',''DD-MON-YYYY HH24:MI:SS'');
			p_report_end   TIMESTAMP := TO_TIMESTAMP(''31-JUL-2004 17:42:41'',''DD-MON-YYYY HH24:MI:SS'');
			BEGIN
			pkg_daily_recon.pr_recon(p_report_date , p_report_start , p_report_end );
			END;

			*//*

			v_report_date     DATE;
			v_procedure     VARCHAR2(50);

			BEGIN

				v_report_date := TRUNC(p_report_date);
				v_procedure := ''*** COMPAS RECONCILATION ***'';
	*/
	---------------COMMENTED BY OAS-----------------
		  
			V_STEP_NAME    := ''*** COMPAS RECONCILATION *** - DELETE - daily_recon'';
			V_STEP_SEQ     := : v_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

				DELETE FROM BDR_DM.daily_recon WHERE report_date = :v_report_date;
			    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_DELETED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );
		  
		  
			V_STEP_NAME    := ''INSERT - daily_recon'';
			V_STEP_SEQ     := : v_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

				INSERT INTO BDR_DM.daily_recon (report_date, report_start_date, report_end_date)
				VALUES      (:v_report_date, :v_report_start, :v_report_end);
			    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

		---------------COMMENTED BY OAS-----------------
		/*
				DELETE FROM COMPAS_MO.daily_recon_log WHERE report_date = :v_report_date;

				COMMIT;

				pr_log_start(v_report_date,v_procedure);

				-- Lockbox, EFT, Checkfree, Enrollment, automated credit card
		sum_payments( v_report_date, p_report_start, p_report_end );
		*/
		---------------COMMENTED BY OAS-----------------
		
									------------- CODE FOR sum_payments BEGINS---------------	
		  
			v_amount := 0.0;
		  
			V_STEP_NAME    := ''sum_payments - UPDATE - daily_recon'';
			V_STEP_SEQ     := : v_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

				SELECT  /*+  parallel(a)  parallel(b) */
					sum(DECODE(a.monetary_trans_vehicle_type_id, 1, b.total_amount, 0)) ,
					sum(DECODE(a.monetary_trans_vehicle_type_id, 1, b.premium_amount, 0)) ,
					sum(DECODE(a.monetary_trans_vehicle_type_id, 1, b.employer_amount, 0)) ,
					sum(DECODE(a.monetary_trans_vehicle_type_id, 1, b.membership_amount, 0)),
					sum(DECODE(a.monetary_trans_vehicle_type_id, 1, b.andrus_amount, 0)) ,

					sum(DECODE(a.monetary_trans_vehicle_type_id, 2, b.total_amount, 0)) ,
					sum(DECODE(a.monetary_trans_vehicle_type_id, 2, b.premium_amount, 0)) ,
					sum(DECODE(a.monetary_trans_vehicle_type_id, 2, b.employer_amount, 0)) ,
					sum(DECODE(a.monetary_trans_vehicle_type_id, 2, b.membership_amount, 0)),
					sum(DECODE(a.monetary_trans_vehicle_type_id, 2, b.andrus_amount, 0)) ,

					SUM(DECODE(a.monetary_trans_vehicle_type_id, 4, b.total_amount, 0)) ,
					sum(DECODE(a.monetary_trans_vehicle_type_id, 4, b.premium_amount, 0)) ,
					sum(DECODE(a.monetary_trans_vehicle_type_id, 4, b.employer_amount, 0)) ,
					sum(DECODE(a.monetary_trans_vehicle_type_id, 4, b.membership_amount, 0)),
					sum(DECODE(a.monetary_trans_vehicle_type_id, 4, b.andrus_amount, 0)) ,

					SUM(DECODE(a.monetary_trans_vehicle_type_id, 3, b.total_amount, 0)) ,
					sum(DECODE(a.monetary_trans_vehicle_type_id, 3, b.premium_amount, 0)) ,
					sum(DECODE(a.monetary_trans_vehicle_type_id, 3, b.employer_amount, 0)) ,
					sum(DECODE(a.monetary_trans_vehicle_type_id, 3, b.membership_amount, 0)),
					sum(DECODE(a.monetary_trans_vehicle_type_id, 3, b.andrus_amount, 0)),

					SUM(DECODE(a.monetary_trans_vehicle_type_id, 7, b.total_amount, 0)) ,
					sum(DECODE(a.monetary_trans_vehicle_type_id, 7, b.premium_amount, 0)) ,
					sum(DECODE(a.monetary_trans_vehicle_type_id, 7, b.employer_amount, 0)) ,
					sum(DECODE(a.monetary_trans_vehicle_type_id, 7, b.membership_amount, 0)),
					sum(DECODE(a.monetary_trans_vehicle_type_id, 7, b.andrus_amount, 0))

				INTO
				v_lockbox_tot_amt,v_lockbox_prem_amt,v_lockbox_emp_amt ,v_lockbox_memb_amt,v_lockbox_and_amt,
				v_eft_tot_amt,v_eft_prem_amt,v_eft_emp_amt ,v_eft_memb_amt,v_eft_and_amt,
				v_enrollment_tot_amt,v_enrollment_prem_amt,v_enrollment_emp_amt ,v_enrollment_memb_amt,v_enrollment_and_amt,
				v_checkfree_tot_amt,v_checkfree_prem_amt,v_checkfree_emp_amt ,v_checkfree_memb_amt,v_checkfree_and_amt,
				v_auto_credit_tot_amt,v_auto_credit_prem_amt,v_auto_credit_emp_amt,v_auto_credit_memb_amt,v_auto_credit_and_amt

				FROM   SRC_COMPAS_M.billing_trans_log a, SRC_COMPAS_M.billing_trans_log_alloc b
				WHERE  a.billing_trans_id = b.billing_trans_id
				AND    a.parent_billing_trans_id IS NULL
				AND    a.monetary_trans_type_id = 1 --pymt
				AND    a.billing_trans_type_id = 6 --applied
				AND    a.monetary_trans_vehicle_type_id IN  (1,2,3,4,7)
				AND    a.monetary_trans_reason_type_id IS NULL
				AND    b.billable_entity_type_id IN (1,2,3)
				AND   trunc(a.creation_date, ''DD'') BETWEEN TO_TIMESTAMP(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'')
				AND TO_TIMESTAMP(to_char(:v_report_end,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'');


				UPDATE BDR_DM.daily_recon
				SET lockbox_total_amt = :v_lockbox_tot_amt,
					lockbox_premium_amt = :v_lockbox_prem_amt,
					lockbox_employer_amt = :v_lockbox_emp_amt,
					lockbox_membership_amt = :v_lockbox_memb_amt,
					lockbox_andrus_amt = :v_lockbox_and_amt ,
					enrollment_total_amt  = :v_enrollment_tot_amt,
					enrollment_premium_amt= :v_enrollment_prem_amt,
					enrollment_employer_amt = :v_enrollment_emp_amt,
					enrollment_membership_amt = :v_enrollment_memb_amt,
					enrollment_andrus_amt = :v_enrollment_and_amt,
					thirdparty_total_amt  = :v_checkfree_tot_amt,
					thirdparty_premium_amt= :v_checkfree_prem_amt,
					thirdparty_employer_amt = :v_checkfree_emp_amt,
					thirdparty_membership_amt  = :v_checkfree_memb_amt,
					thirdparty_andrus_amt = :v_checkfree_and_amt,
					eft_total_amt  = :v_eft_tot_amt,
					eft_premium_amt= :v_eft_prem_amt,
					eft_employer_amt = :v_eft_emp_amt,
					eft_membership_amt = :v_eft_memb_amt,
					eft_andrus_amt = :v_eft_and_amt,
					auto_credit_total_amt = :v_auto_credit_tot_amt,
					auto_credit_premium_amt = :v_auto_credit_prem_amt,
					auto_credit_employer_amt = :v_auto_credit_emp_amt,
					auto_credit_membership_amt = :v_auto_credit_memb_amt

				WHERE  report_date = :v_report_date;
				    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );
			
									------------- CODE FOR sum_payments ENDS---------------									
		
				-- Online chredit, check, wire, misc
		--sum_online_payments ( v_report_date, p_report_start, p_report_end );		-------OAS DELETE
				
									------------- CODE FOR sum_online_payments BEGINS---------------	
		  
			V_STEP_NAME    := ''sum_online_payments - UPDATE - daily_recon'';
			V_STEP_SEQ     := : v_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

				SELECT  /*+  parallel(a)  parallel(b) */
					sum(DECODE(a.monetary_trans_reason_type_id, 7, b.total_amount, 0)) ,
					sum(DECODE(a.monetary_trans_reason_type_id, 7, b.premium_amount, 0)) ,
					sum(DECODE(a.monetary_trans_reason_type_id, 7, b.employer_amount, 0)) ,
					sum(DECODE(a.monetary_trans_reason_type_id, 7, b.membership_amount, 0)),
					sum(DECODE(a.monetary_trans_reason_type_id, 7, b.andrus_amount, 0)) ,

					sum(DECODE(a.monetary_trans_reason_type_id, 8, b.total_amount, 0)) ,
					sum(DECODE(a.monetary_trans_reason_type_id, 8, b.premium_amount, 0)) ,
					sum(DECODE(a.monetary_trans_reason_type_id, 8, b.employer_amount, 0)) ,
					sum(DECODE(a.monetary_trans_reason_type_id, 8, b.membership_amount, 0)),
					sum(DECODE(a.monetary_trans_reason_type_id, 8, b.andrus_amount, 0)) ,

					SUM(DECODE(a.monetary_trans_reason_type_id, 9, b.total_amount, 0)) ,
					sum(DECODE(a.monetary_trans_reason_type_id, 9, b.premium_amount, 0)) ,
					sum(DECODE(a.monetary_trans_reason_type_id, 9, b.employer_amount, 0)) ,
					sum(DECODE(a.monetary_trans_reason_type_id, 9, b.membership_amount, 0)),
					sum(DECODE(a.monetary_trans_reason_type_id, 9, b.andrus_amount, 0)) ,

					SUM(DECODE(a.monetary_trans_reason_type_id, 21, b.total_amount, 0)) ,
					sum(DECODE(a.monetary_trans_reason_type_id, 21, b.premium_amount, 0)) ,
					sum(DECODE(a.monetary_trans_reason_type_id, 21, b.employer_amount, 0)) ,
					sum(DECODE(a.monetary_trans_reason_type_id, 21, b.membership_amount, 0)),
					sum(DECODE(a.monetary_trans_reason_type_id, 21, b.andrus_amount, 0))
				INTO
				v_online_check_tot_amt,v_online_check_prem_amt,v_online_check_emp_amt ,v_online_check_memb_amt,v_online_check_and_amt,
				v_online_credit_tot_amt,v_online_credit_prem_amt,v_online_credit_emp_amt ,v_online_credit_memb_amt,v_online_credit_and_amt,
				v_online_wire_tot_amt,v_online_wire_prem_amt,v_online_wire_emp_amt ,v_online_wire_memb_amt,v_online_wire_and_amt,
				v_online_misc_tot_amt,v_online_misc_prem_amt,v_online_misc_emp_amt ,v_online_misc_memb_amt,v_online_misc_and_amt

				FROM SRC_COMPAS_M.billing_trans_log a, SRC_COMPAS_M.billing_trans_log_alloc b
				WHERE a.billing_trans_id = b.billing_trans_id
				AND a.monetary_trans_type_id = 1
				AND a.billing_trans_type_id = 6
				AND a.monetary_trans_vehicle_type_id = 6
				AND a.monetary_trans_reason_type_id IN (7,8,9,21)
				AND b.billable_entity_type_id IN (1, 2)
				AND a.creation_date BETWEEN to_timestamp(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'')
				AND to_timestamp(to_char(:v_report_end,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'');


				UPDATE BDR_DM.daily_recon
				SET online_credit_total_amt = :v_online_credit_tot_amt,
					online_credit_premium_amt = :v_online_credit_prem_amt,
					online_credit_employer_amt = :v_online_credit_emp_amt,
					online_credit_membership_amt = :v_online_credit_memb_amt,
					online_credit_andrus_amt = :v_online_credit_and_amt ,
					online_check_total_amt  = :v_online_check_tot_amt,
					online_check_premium_amt= :v_online_check_prem_amt,
					online_check_employer_amt = :v_online_check_emp_amt,
					online_check_membership_amt = :v_online_check_memb_amt,
					online_check_andrus_amt = :v_online_check_and_amt,
					online_wire_total_amt  = :v_online_wire_tot_amt,
					online_wire_premium_amt= :v_online_wire_prem_amt,
					online_wire_employer_amt = :v_online_wire_emp_amt,
					online_wire_membership_amt  = :v_online_wire_memb_amt,
					online_wire_andrus_amt = :v_online_wire_and_amt,
					online_misc_total_amt  = :v_online_misc_tot_amt,
					online_misc_premium_amt= :v_online_misc_prem_amt,
					online_misc_employer_amt = :v_online_misc_emp_amt,
					online_misc_membership_amt = :v_online_misc_memb_amt,
					online_misc_andrus_amt = :v_online_misc_and_amt
				WHERE  report_date = :v_report_date;
				    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_online_payments ENDS---------------	
									
				-- Accounting adjustments waiver, pro-rated credits
			--sum_acctadj_payments ( v_report_date, p_report_start, p_report_end );		-----OAS DELETE

									------------- CODE FOR sum_acctadj_payments BEGINS---------------	
		  
			V_STEP_NAME    := ''sum_acctadj_payments - UPDATE - daily_recon'';
			V_STEP_SEQ     := : v_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;
									
				SELECT  /*+ parallel(a) parallel(b) USE_HASH (a b) */
					sum(DECODE(a.monetary_trans_reason_type_id, 1, b.total_amount, 0)) ,
					sum(DECODE(a.monetary_trans_reason_type_id, 1, b.premium_amount, 0)) ,
					sum(DECODE(a.monetary_trans_reason_type_id, 1, b.employer_amount, 0)) ,
					sum(DECODE(a.monetary_trans_reason_type_id, 2, b.total_amount, 0)) ,
					sum(DECODE(a.monetary_trans_reason_type_id, 2, b.premium_amount, 0)) ,
					sum(DECODE(a.monetary_trans_reason_type_id, 2, b.employer_amount, 0))
				INTO
				v_waiver_tot_amt,v_waiver_prem_amt,v_waiver_emp_amt ,
				v_prorated_credit_tot_amt,v_prorated_credit_prem_amt,v_prorated_credit_emp_amt

				  FROM SRC_COMPAS_M.billing_trans_log a, SRC_COMPAS_M.billing_trans_log_alloc b
				 WHERE a.billing_trans_id = b.billing_trans_id
				   AND a.monetary_trans_type_id = 4
				   AND a.billing_trans_type_id IN (5,6)
				   AND a.monetary_trans_vehicle_type_id IN (5,6)
				   AND a.monetary_trans_reason_type_id IN (1,2)
				   AND b.billable_entity_type_id IN (1, 2)
				   AND a.creation_date BETWEEN to_timestamp(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'')
				AND to_timestamp(to_char(:v_report_end,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'');


				UPDATE BDR_DM.daily_recon
				SET aa_waiver_total_amt = :v_waiver_tot_amt,
					aa_waiver_prem_amt = :v_waiver_prem_amt,
					aa_waiver_emp_amt = :v_waiver_emp_amt,

					aa_prorated_credit_total_amt   = :v_prorated_credit_tot_amt,
					aa_prorated_credit_prem_amt = :v_prorated_credit_prem_amt,
					aa_prorated_credit_emp_amt = :v_prorated_credit_emp_amt

				WHERE  report_date = :v_report_date;
				
									------------- CODE FOR sum_acctadj_payments ENDS---------------	
							
							
				-- Accounting adjustments - retroactive credit payments
		--sum_acctadj_retrocredit_pymts ( v_report_date, p_report_start, p_report_end );	-------OAS DELETE

									------------- CODE FOR sum_acctadj_retrocredit_pymts BEGINS---------------	
		  
			V_STEP_NAME    := ''sum_acctadj_retrocredit_pymts - UPDATE - daily_recon'';
			V_STEP_SEQ     := : v_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;
						
				SELECT  sum( b.total_amount) ,
						sum( b.premium_amount) ,
						sum( b.employer_amount)
				INTO    v_retrocredit_tot_amt,v_retrocredit_prem_amt,v_retrocredit_emp_amt
				  FROM SRC_COMPAS_M.billing_trans_log a, SRC_COMPAS_M.billing_trans_log_alloc b
				 WHERE a.billing_trans_id = b.billing_trans_id
				   AND a.monetary_trans_type_id = 4
				   AND a.billing_trans_type_id  IN (5,6)
				   AND a.monetary_trans_vehicle_type_id  IN (5,6)
				   AND a.monetary_trans_reason_type_id = 23
				   AND b.billable_entity_type_id IN (1, 2)
				   AND   a.creation_date BETWEEN to_timestamp(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'')
				AND to_timestamp(to_char(:v_report_end,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'');

				UPDATE BDR_DM.daily_recon
				SET aa_retro_credit_total_amt = nvl(:v_retrocredit_tot_amt,0),
					aa_retro_credit_prem_amt = nvl(:v_retrocredit_prem_amt,0),
					aa_retro_credit_emp_amt = nvl(:v_retrocredit_emp_amt,0)
				WHERE  report_date = :v_report_date;
				    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_acctadj_retrocredit_pymts ENDS---------------	
									
									
				-- Refunds
		--sum_refund ( v_report_date, p_report_start, p_report_end );	---OAS DELETE
		
									------------- CODE FOR sum_refund BEGINS---------------	
		  
			v_refund := 0;
		  
			V_STEP_NAME    := ''sum_refund - UPDATE - daily_recon'';
			V_STEP_SEQ     := : v_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

				SELECT SUM (refund_amount)
				  INTO v_refund
				  FROM SRC_COMPAS_M.refund
				 WHERE applied_date BETWEEN TO_TIMESTAMP (TO_CHAR (:v_report_start, ''mm/dd/yyyy hh24:mi:ss''), ''mm/dd/yyyy hh24:mi:ss'') AND TO_TIMESTAMP (TO_CHAR (:v_report_end, ''mm/dd/yyyy hh24:mi:ss''), ''mm/dd/yyyy hh24:mi:ss'')
				   AND refund_status_id in (3 -- void (check)
										  , 4 -- reapplied ( eft)
										  , 5 -- issue ( eft or check)
										  , 6 -- reissue (check)
										   );

				UPDATE BDR_DM.daily_recon
				SET    refunds = :v_refund
				WHERE  report_date = :v_report_date;
				    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_refund ENDS---------------

									
				-- Returns
		--sum_return ( v_report_date, p_report_start, p_report_end );	-----OAS DELETE
									------------- CODE FOR sum_returns BEGINS---------------	
		  
			V_STEP_NAME    := ''sum_returns - UPDATE - daily_recon'';
			V_STEP_SEQ     := : v_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;
						
				SELECT  /*+  parallel(a) parallel(b) */
						SUM(b.total_amount) AS v_returns_tot_amt,
						SUM(b.premium_amount) AS v_returns_prem_amt,
						SUM(b.employer_amount) AS v_returns_emp_amt,
						SUM(b.membership_amount) AS v_returns_memb_amt,
						SUM(b.andrus_amount) AS v_returns_and_amt
				INTO    v_returns_tot_amt,v_returns_prem_amt,v_returns_emp_amt,
						v_returns_memb_amt,v_returns_and_amt
				FROM    SRC_COMPAS_M.billing_trans_log a, SRC_COMPAS_M.billing_trans_log_alloc b
				WHERE  a.billing_trans_id = b.billing_trans_id
				AND  a.monetary_trans_type_id = 1
				AND  a.billing_trans_type_id = 5
				AND  a.monetary_trans_vehicle_type_id = 6
				AND  (a.monetary_trans_reason_type_id IS NULL
						OR a.monetary_trans_reason_type_id <> 15)
				AND  b.billable_entity_type_id IN (1, 2)
				AND  a.creation_date BETWEEN TO_TIMESTAMP(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'') AND TO_TIMESTAMP(to_char(:v_report_end,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'');

				UPDATE BDR_DM.daily_recon
				SET     returns_total_amt = nvl(:v_returns_tot_amt,0),
						returns_premium_amt = nvl(:v_returns_prem_amt,0),
						returns_employer_amt = nvl(:v_returns_emp_amt,0),
						returns_membership_amt = nvl(:v_returns_memb_amt,0),
						returns_andrus_amt = nvl(:v_returns_and_amt,0)
				WHERE  report_date = :v_report_date;
				    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_returns ENDS---------------	
									
									
				-- EFT Protest
		--sum_eft_protest ( v_report_date, p_report_start, p_report_end );		-----OAS DELETE
									------------- CODE FOR sum_eft_protest BEGINS---------------	
		  
			v_eft_protest := 0.0;
		  
			V_STEP_NAME    := ''sum_eft_protest - UPDATE - daily_recon'';
			V_STEP_SEQ     := : v_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

				SELECT  /*+  parallel(a)  parallel(b) */
				sum(b.total_amount) AS eft_protest
				INTO    v_eft_protest
				FROM SRC_COMPAS_M.billing_trans_log a, SRC_COMPAS_M.billing_trans_log_alloc b
				WHERE a.billing_trans_id = b.billing_trans_id
				AND a.monetary_trans_type_id = 1
				AND a.billing_trans_type_id = 5
				AND a.monetary_trans_vehicle_type_id = 2
				AND b.billable_entity_type_id IN (1, 2)
				AND a.creation_date BETWEEN TO_TIMESTAMP(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'') AND TO_TIMESTAMP(to_char(:v_report_end,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'');

				UPDATE BDR_DM.daily_recon
				SET     eft_protest = nvl(:v_eft_protest,0)
				WHERE  report_date = :v_report_date;
				    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_eft_protest ENDS---------------	
									
									
			-- Retro debit, Misc loss
		--sum_acctadj_retrodebit_mscloss ( v_report_date, p_report_start, p_report_end );	--OAS DELETE
									------------- CODE FOR sum_acctadj_retrodebit_mscloss BEGINS---------------	
		  
			V_STEP_NAME    := ''sum_acctadj_retrodebit_mscloss - UPDATE - daily_recon'';
			V_STEP_SEQ     := : v_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

				 SELECT  /*+  parallel(a) parallel(b)  USE_HASH (a b) */
						sum(DECODE(a.monetary_trans_reason_type_id, 22, b.total_amount, 0)) ,
						sum(DECODE(a.monetary_trans_reason_type_id, 22, b.premium_amount, 0)) ,
						sum(DECODE(a.monetary_trans_reason_type_id, 22, b.employer_amount, 0)) ,
						sum(DECODE(a.monetary_trans_reason_type_id, 12, b.total_amount, 0)) ,
						sum(DECODE(a.monetary_trans_reason_type_id, 12, b.premium_amount, 0)) ,
						sum(DECODE(a.monetary_trans_reason_type_id, 12, b.employer_amount, 0))
				INTO    v_retrodebit_tot_amt,v_retrodebit_prem_amt,v_retrodebit_emp_amt ,
						v_miscloss_tot_amt,v_miscloss_prem_amt,v_miscloss_emp_amt
				FROM SRC_COMPAS_M.billing_trans_log a, SRC_COMPAS_M.billing_trans_log_alloc b
				WHERE a.billing_trans_id = b.billing_trans_id
				AND a.monetary_trans_type_id = 4
				AND a.billing_trans_type_id  IN (5,6)
				AND a.monetary_trans_vehicle_type_id  IN (5,6)
				AND a.monetary_trans_reason_type_id IN (22,12)
				AND b.billable_entity_type_id IN (1, 2)
				AND a.creation_date BETWEEN TO_TIMESTAMP(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'') AND TO_TIMESTAMP(to_char(:v_report_end,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'');

				UPDATE BDR_DM.daily_recon
				SET aa_retro_debit_total_amt = :v_retrodebit_tot_amt,
					aa_retro_debit_prem_amt = :v_retrodebit_prem_amt,
					aa_retro_debit_emp_amt = :v_retrodebit_emp_amt,

					aa_misc_loss_total_amt   = :v_miscloss_tot_amt,
					aa_misc_loss_prem_amt = :v_miscloss_prem_amt,
					aa_misc_loss_emp_amt = :v_miscloss_emp_amt

				WHERE  report_date = :v_report_date;
				    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_acctadj_retrodebit_mscloss ENDS---------------	


			-- Pro Rated Loss
		--sum_acctadj_prorated_loss ( v_report_date, p_report_start, p_report_end );	---OAS DELETE
		
									------------- CODE FOR sum_acctadj_prorated_loss BEGINS---------------	
		  
			V_STEP_NAME    := ''sum_acctadj_prorated_loss - UPDATE - daily_recon'';
			V_STEP_SEQ     := : v_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

				SELECT  sum( b.total_amount) ,
						sum( b.premium_amount) ,
						sum( b.employer_amount)
				INTO    v_proratedloss_tot_amt,v_proratedloss_prem_amt,v_proratedloss_emp_amt
				  FROM SRC_COMPAS_M.billing_trans_log a, SRC_COMPAS_M.billing_trans_log_alloc b
				 WHERE a.billing_trans_id = b.billing_trans_id
				   AND a.monetary_trans_type_id = 4
				   AND a.billing_trans_type_id  IN (5,6)
				   AND a.monetary_trans_vehicle_type_id  IN (5,6)
				   AND a.monetary_trans_reason_type_id = 25
				   AND b.billable_entity_type_id IN (1, 2)
				   AND a.creation_date BETWEEN TO_TIMESTAMP(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'') AND TO_TIMESTAMP(to_char(:v_report_end,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'');

				UPDATE BDR_DM.daily_recon
				SET   aa_prorated_loss_total_amt   = nvl(:v_proratedloss_tot_amt,0),
					aa_prorated_loss_prem_amt = nvl(:v_proratedloss_prem_amt,0),
					aa_prorated_loss_emp_amt = nvl(:v_proratedloss_emp_amt,0)
				WHERE  report_date = :v_report_date;
				    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_acctadj_prorated_loss ENDS---------------	


			-- Claims
		--sum_claims ( v_report_date, p_report_start, p_report_end );	----OAS DELETE
				
									------------- CODE FOR sum_claims BEGINS---------------	
		  
			V_STEP_NAME    := ''sum_claims - UPDATE - daily_recon'';
			V_STEP_SEQ     := : v_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

				SELECT  sum( b.total_amount) ,
						sum( b.premium_amount) ,
						sum( b.employer_amount),
						SUM(b.membership_amount),
						SUM(b.andrus_amount)
				INTO    v_claims_tot,v_claims_prem,v_claims_emp,v_claims_memb,v_claims_and
				  FROM SRC_COMPAS_M.billing_trans_log a, SRC_COMPAS_M.billing_trans_log_alloc b
				 WHERE a.billing_trans_id = b.billing_trans_id
				   AND b.billable_entity_type_id = 4
				   AND a.creation_date BETWEEN TO_TIMESTAMP(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'') AND TO_TIMESTAMP(to_char(:v_report_end,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'');


				UPDATE BDR_DM.daily_recon
				SET     claims_total_amt = nvl(:v_claims_tot,0),
						claims_premium_amt = nvl(:v_claims_prem,0),
						claims_employer_amt = nvl(:v_claims_emp,0),
						claims_membership_amt = nvl(:v_claims_memb,0),
						claims_andrus_amt = nvl(:v_claims_and,0)
				WHERE  report_date = :v_report_date;
				    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_claims ENDS---------------

			--unclaimedrefund
		--sum_unclaimedrefund ( v_report_date, p_report_start, p_report_end );		----------OAS DELETE
									------------- CODE FOR sum_unclaimedrefund BEGINS---------------	
		  
			V_STEP_NAME    := ''sum_unclaimedrefund - UPDATE - daily_recon'';
			V_STEP_SEQ     := : v_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

					SELECT /*+  parallel(a) parallel(b) */ SUM(b.total_amount)
					INTO    v_unclaimed_tot_amt
					FROM SRC_COMPAS_M.billing_trans_log a, SRC_COMPAS_M.billing_trans_log_alloc b
					WHERE a.billing_trans_id = b.billing_trans_id
					AND b.billable_entity_type_id = 5
					AND a.monetary_trans_type_id = 3
					AND a.creation_date BETWEEN TO_TIMESTAMP(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'') AND TO_TIMESTAMP(to_char(:v_report_end,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'');


					UPDATE BDR_DM.daily_recon
					SET unclaimed_refund_amt = nvl(:v_unclaimed_tot_amt,0)
					WHERE  report_date = :v_report_date;
				    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_unclaimedrefund ENDS---------------	


			-- Non-affiliate
		--sum_nonaffiliate ( v_report_date, p_report_start, p_report_end );		-------OAS DELETE	
		
									------------- CODE FOR sum_nonaffiliate BEGINS---------------	
		  
			v_nonaffiliate := 0.0;
		  
			V_STEP_NAME    := ''sum_nonaffiliate - UPDATE - daily_recon'';
			V_STEP_SEQ     := : v_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;	

					SELECT  sum(total_amount) AS nonaff
					INTO    v_nonaffiliate
					FROM (
						SELECT DISTINCT a.orig_process_date
									, a.received_date
									, a.parent_billing_trans_id
									, b.total_amount
									, b.premium_amount
									, b.membership_amount
									, b.andrus_amount
									, b.employer_amount
									, b.member_number
						FROM    SRC_COMPAS_M.billing_trans_log a, SRC_COMPAS_M.billing_trans_log_alloc b
						WHERE   a.billing_trans_id = b.billing_trans_id
						AND     b.billable_entity_type_id = 6
						AND a.creation_date BETWEEN TO_TIMESTAMP(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'') AND TO_TIMESTAMP(to_char(:v_report_end,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'')
					   );

					UPDATE BDR_DM.daily_recon
					SET    NONAFFILATE = nvl(:v_nonaffiliate,0)
					WHERE  report_date = :v_report_date;
				    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_nonaffiliate ENDS---------------	


			-- Unclaimed
		--sum_unclaimedfunds ( v_report_date, p_report_start, p_report_end );	---------OAS DELETE
				
									------------- CODE FOR sum_unclaimedfunds BEGINS---------------	
				/*
				Payments residing in suspense with no COMPAS household are placed in the category
				of unclaimed funds.  This may be the payment itself being moved to suspense, or
				the protest of the payment from suspense or the refund of a payment from suspense.

				The Unclaimed Funds total is included when reconciling the MSOA with COMPAS
				reports and the bank.  It explains where payments that were received in COMPAS
				reside.  It is used to  reduce the report and bank amounts as it a category of
				where funds are placed
				*/
				
			V_STEP_NAME    := ''sum_unclaimedfunds - UPDATE - daily_recon'';
			V_STEP_SEQ     := : v_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

					SELECT  SUM(b.total_amount) ,
							SUM(b.premium_amount) ,
							SUM(b.employer_amount) ,
							SUM(b.membership_amount) ,
							SUM(b.andrus_amount)
					INTO    v_unclaimed_tot_amt,v_unclaimed_prem_amt,v_unclaimed_emp_amt,
							v_unclaimed_memb_amt,v_unclaimed_and_amt
					  FROM SRC_COMPAS_M.billing_trans_log a, SRC_COMPAS_M.billing_trans_log_alloc b
					 WHERE a.billing_trans_id = b.billing_trans_id
					   AND b.billable_entity_type_id = 5
					   AND a.monetary_trans_type_id <> 3
					   AND a.creation_date BETWEEN TO_TIMESTAMP(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'') AND TO_TIMESTAMP(to_char(:v_report_end,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'');


					UPDATE BDR_DM.daily_recon
					SET unclaimed_total_amt = nvl(:v_unclaimed_tot_amt,0),
						unclaimed_premium_amt = nvl(:v_unclaimed_prem_amt,0),
						unclaimed_employer_amt = nvl(:v_unclaimed_emp_amt,0),
						unclaimed_membership_amt = nvl(:v_unclaimed_memb_amt,0),
						unclaimed_andrus_amt  = nvl(:v_unclaimed_and_amt,0)
					WHERE  report_date = :v_report_date;
				    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_unclaimedfunds ENDS---------------
									
		--sum_pension_payments( v_report_date, p_report_start, p_report_end );	-----OAS DELETE

									------------- CODE FOR sum_pension_payments BEGINS---------------	
		  
			v_amount := 0.0;
		  
			V_STEP_NAME    := ''sum_pension_payments - UPDATE - daily_recon'';
			V_STEP_SEQ     := : v_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

					SELECT  sum(b.total_amount)
					INTO    v_amount
					FROM
						SRC_COMPAS_M.billing_trans_log a
						,SRC_COMPAS_M.billing_trans_log_alloc b
					WHERE
						a.billing_trans_id = b.billing_trans_id
						AND a.monetary_trans_type_id = 1 --pymt
						AND a.billing_trans_type_id = 6 --applied
						AND a.monetary_trans_vehicle_type_id = 2 -- eft
						AND a.monetary_trans_reason_type_id = 26 -- pension payment
						AND b.billable_entity_type_id in (1,2,3)
						AND a.creation_date BETWEEN TO_TIMESTAMP(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'') AND TO_TIMESTAMP(to_char(:v_report_end,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'');

					UPDATE BDR_DM.daily_recon
					SET    pension_payment = nvl(:v_amount,0)
					WHERE  report_date = :v_report_date;
				    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_pension_payments ENDS---------------	


		--sum_excess_prorated_credit( v_report_date, p_report_start, p_report_end );	---OAS DELETE

									------------- CODE FOR sum_excess_prorated_credit BEGINS---------------	
		  			
				/*
				COMPAS is creating pro-rated credits when an insured plan termination is started
				but not completed.

				COMPAS reports are including these volumes.  The MSOA will appear to be lower
				than COMPAS reports, and the amount reported to the bank will be incorrectly
				increased.
				*/
			
			v_amount := 0.0;
			
			V_STEP_NAME    := ''sum_excess_prorated_credit - UPDATE - daily_recon'';
			V_STEP_SEQ     := : v_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

					SELECT /*+ parallel(mt) parallel(A) */ SUM( a.total_amount)
					INTO    v_amount
					FROM  (
							SELECT  b.received_date, b2.*
						FROM    SRC_COMPAS_M.billing_trans_log b, SRC_COMPAS_M.billing_trans_log_alloc b2
						WHERE   b.billing_trans_id = b2.billing_trans_id
						AND     b.monetary_trans_type_id = 4 --acctg adj
						 -- select pro-rated credit and pro-rated loss payments and protests
						AND     b.billing_trans_type_id in (5, 6)  --6 is applied, 5 is protest
						AND     b.monetary_trans_vehicle_type_id = 5 --auto
						AND     b.monetary_trans_reason_type_id in (2,25) -- 2 is prorated credit; 25 is prorated loss
						AND     b2.billable_entity_type_id = 1
						AND b.creation_date BETWEEN TO_TIMESTAMP(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'') AND TO_TIMESTAMP(to_char(:v_report_end,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'')
					) A LEFT OUTER JOIN SRC_COMPAS_M.monetary_trans mt
					ON a.billing_trans_id = mt.billing_trans_id 
					AND mt.monetary_trans_id IS  NULL;

					UPDATE BDR_DM.daily_recon
					SET    excess_prorated_credit = nvl(:v_amount,0)
					WHERE  report_date = :v_report_date;
				    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_excess_prorated_credit ENDS---------------	

		--sum_overstated_emp_credit( v_report_date, p_report_start, p_report_end );

									------------- CODE FOR sum_overstated_emp_credit BEGINS---------------	
									
				/*
				Households will hold employer non-applied funds (naf) when a change in premium
				occurs after the household has been billed, or after the household has been paid.

				The naf is returned to the employer when the household is billed the following
				month.  This is in the form of an automated accounting adjustment to the employer.
				It appears as a credit on the new bill and is added to employer naf.

				The MSOA will double report the credit amount added to employer naf because it
				sums both household/employer naf and employer naf.  This will occur if the employer
				has not paid the current bill at month end.

				The problem does not exist if the employer pays the current bill because both
				household naf are reversed when the payment is made.
				*/

			v_amount := 0.0;
		  
			V_STEP_NAME    := ''sum_overstated_emp_credit - UPDATE - daily_recon'';
			V_STEP_SEQ     := : v_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;
			
					SELECT  sum(credit_amount)
					INTO    v_amount
					FROM SRC_COMPAS_M.employer_billing_bucket
					WHERE (last_modified_date >= bill_date
					AND nvl(paid_ind, ''N'') = ''Y'')
					OR nvl(paid_ind, ''N'') = ''N''
					AND trunc(bill_date, ''MONTH'') = TRUNC(ADD_MONTHS(:v_report_date,1), ''MONTH'');

					UPDATE BDR_DM.daily_recon
					SET    overstated_emp_credit = nvl(:v_amount,0)
					WHERE  report_date = :v_report_date;
				    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_overstated_emp_credit ENDS---------------	

		--sum_overstated_reduced_emp_cr( v_report_date, p_report_start, p_report_end );	----OAS DELETE

									------------- CODE FOR sum_overstated_reduced_emp_cr BEGINS---------------	
		
				/*
				This is the reverse of Overstated Employer Credit issue above. Employer payment
				will reduce both employer naf and household employer naf when the employer pays
				their bill.

				NAF is reduced in duplicate.
				*/
				
			v_amount := 0.0;
		  
			V_STEP_NAME    := ''sum_overstated_reduced_emp_cr - UPDATE - daily_recon'';
			V_STEP_SEQ     := : v_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

				SELECT  SUM(credit_amount) * -1
				INTO    v_amount
				FROM    SRC_COMPAS_M.employer_billing_bucket bb
				WHERE   bb.paid_ind = ''Y''
				AND     bb.last_modified_date >= bb.bill_date AND bb.bill_date <= TO_TIMESTAMP(''1-nov-2004'',''DD-Mon-YYYY'')
				AND     credit_amount < 0
				AND TO_CHAR(bb.last_modified_date,''MM-YYYY'') = TO_CHAR(:v_report_date, ''MM-YYYY'');

				UPDATE BDR_DM.daily_recon
				SET    overstated_reduced_emp_credit = nvl(:v_amount,0)
				WHERE  report_date = :v_report_date;
				    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_overstated_reduced_emp_cr ENDS---------------	

		--sum_emp_membership_paid_amt( v_report_date, p_report_start, p_report_end );

									------------- CODE FOR sum_emp_membership_paid_amt BEGINS---------------	
			
			v_amount := 0.0;
		  
			V_STEP_NAME    := ''sum_emp_membership_paid_amt - UPDATE - daily_recon'';
			V_STEP_SEQ     := : v_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

				SELECT  /*+  USE_HASH (btl btla) */ SUM(btla.membership_amount)
				INTO    v_amount
				FROM    SRC_COMPAS_M.billing_trans_log btl, SRC_COMPAS_M.billing_trans_log_alloc btla
				WHERE   btl.billing_trans_id = btla.billing_trans_id
				AND     ( btla.billable_entity_type_id = 1 -- hhld
				OR  btla.billable_entity_type_id = 2 -- emp
				)
				AND btl.monetary_trans_type_id = 5 -- emp dist
				AND (
					(btl.billing_trans_type_id = 6  -- applied
					AND btla.membership_amount > 0)
					OR (btl.billing_trans_type_id = 5  -- protest
					AND btla.membership_amount < 0)
				 )
				AND btl.monetary_trans_vehicle_type_id = 6 -- online
				AND btl.creation_date BETWEEN TO_TIMESTAMP(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'') AND TO_TIMESTAMP(to_char(:v_report_end,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'');


				UPDATE BDR_DM.daily_recon
				SET    EMP_MEMBERSHIP_PAID_AMT = nvl(:v_amount,0)
				WHERE  report_date = :v_report_date;
				    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_emp_membership_paid_amt ENDS---------------	

		--sum_bank_adjustments_amt( v_report_date, p_report_start, p_report_end );	---OAS DELETE

									------------- CODE FOR sum_bank_adjustments_amt BEGINS---------------	
				
			v_amount := 0.0;
		  
			V_STEP_NAME    := ''sum_bank_adjustments_amt - UPDATE - daily_recon'';
			V_STEP_SEQ     := : v_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

				SELECT /*+  parallel(a) parallel(b)  */ SUM(b.total_amount)
				INTO   v_amount
				FROM   SRC_COMPAS_M.billing_trans_log a,    SRC_COMPAS_M.billing_trans_log_alloc b
				WHERE  a.billing_trans_id = b.billing_trans_id
				AND    a.parent_billing_trans_id is not null
				AND (
						(
						a.monetary_trans_reason_type_id in (10,11) --bank adj, missing pymt
						and a.billing_trans_type_id = 6 --applied
						AND b.BILLABLE_ENTITY_TYPE_ID in (1,2) --hhld, emp
						AND a.MONETARY_TRANS_VEHICLE_TYPE_ID = 6 --online
						AND a.MONETARY_TRANS_TYPE_ID = 1 --payment
						)
					OR
						(
						a.monetary_trans_reason_type_id = 15
						and a.parent_billing_trans_id is not null
						AND b.BILLABLE_ENTITY_TYPE_ID in (1,2,6) --hhld, emp, nonaffiliate
						and a.BILLING_TRANS_TYPE_ID = 5 --protest
						and a.MONETARY_TRANS_VEHICLE_TYPE_ID = 6 --online
						AND a.MONETARY_TRANS_TYPE_ID = 1 --payment
						)
					OR
						(
						a.monetary_trans_reason_type_id = 16
						AND a.billing_trans_type_id = 3
						and a.parent_billing_trans_id is not NULL
						and not exists
							(
							select /*+  parallel(log2) parallel(alloc2)   */ log2.billing_trans_id
							from SRC_COMPAS_M.billing_trans_log log2, SRC_COMPAS_M.billing_trans_log_alloc alloc2
							where
							log2.billing_trans_id = alloc2.billing_trans_id
							and log2.billing_trans_type_id = 3
							and log2.parent_billing_trans_id = a.parent_billing_trans_id
							and alloc2.billable_entity_type_id <> b.billable_entity_type_id
							)
						)
					)
				AND a.creation_date BETWEEN TO_TIMESTAMP(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'') AND TO_TIMESTAMP(to_char(:v_report_end,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'');

				UPDATE BDR_DM.daily_recon
				SET    BANK_ADJUSTMENT_AMT = nvl(:v_amount,0)
				WHERE  report_date = :v_report_date;
				    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_bank_adjustments_amt ENDS---------------	

		--sum_membership_andrus_amt( v_report_date, p_report_start, p_report_end );		--------OAS DELETE

									------------- CODE FOR sum_membership_andrus_amt BEGINS---------------	
			v_amount := 0.0;
					
			V_STEP_NAME    := ''sum_membership_andrus_amt - UPDATE - daily_recon'';
			V_STEP_SEQ     := : v_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

			   SELECT  sum(amount)
			   INTO    v_amount
			   FROM    SRC_COMPAS_M.assoc_non_premium_rpt
			   WHERE   due_date BETWEEN TO_TIMESTAMP(TO_CHAR(:v_report_start,''mm/dd/yyyy''),''mm/dd/yyyy'') AND TO_TIMESTAMP(TO_CHAR(:v_report_end,''mm/dd/yyyy''),''mm/dd/yyyy'')
			   --AND     creation_date BETWEEN to_date(to_char(p_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'') AND to_date(to_char(p_report_end,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'')
			   and (
					 -- membership and andrus payments from household
					 (account_receivable_type_id in (3,4)--membership, andrus
					  and responsible_party_type_id = 1 -- hhold
					  and billing_trans_type_id = 6) --applied
				 or
					-- funds distributed from premium to membership/andrus
					 (account_receivable_type_id in (3,4)--membership, andrus
					  and billing_trans_type_id in (3,4) --reallocate, misapplied)
					  and amount > 0)
				 or
					-- funds reversed from membership/andrus
					 (account_receivable_type_id in (3,4)--membership, andrus
					  and billing_trans_type_id = 5) -- protest
				 or
					-- hhld funds misapplied or realloc from membership/andrus
					(account_receivable_type_id in (3,4)--membership, andrus
					 and responsible_party_type_id = 1 -- hhold
					 and billing_trans_type_id in (3,4) -- realloc, misapplied
					 and amount < 0)
				or
					-- emp funds misapplied from membership
					(account_receivable_type_id = 3 --membership
					 and responsible_party_type_id = 2 -- emp
					 and billing_trans_type_id = 4 -- misapplied
					 and amount < 0)
				 );

				UPDATE BDR_DM.daily_recon
				SET    MEMBERSHIP_ANDRUS_FUNDS_AMT = nvl(:v_amount,0)
				WHERE  report_date = :v_report_date;
				    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_membership_andrus_amt ENDS---------------	
		
		--sum_protest_emp_acct_adj(v_report_date,p_report_start,p_report_end);	-----OAS DELETE

									------------- CODE FOR sum_protest_emp_acct_adj BEGINS---------------	
		  
			v_amount := 0.0;
				
			V_STEP_NAME    := ''sum_protest_emp_acct_adj - UPDATE - daily_recon'';
			V_STEP_SEQ     := : v_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;
			
				Select /*+  parallel(btl)  parallel(btla)  */ sum(btla.total_amount)
				INTO   v_amount
				FROM   SRC_COMPAS_M.billing_trans_log       btl
					 , SRC_COMPAS_M.billing_trans_log_alloc btla
				WHERE  btl.billing_trans_id  = btla.billing_trans_id
					and btl.monetary_trans_type_id = 1 --payment
					and btl.billing_trans_type_id = 5 --protest
					and btl.monetary_trans_reason_type_id is null
				AND    btl.parent_billing_trans_id IN
				(SELECT /*+  parallel(a)  parallel(b)  */ a.billing_trans_id
					FROM
						SRC_COMPAS_M.billing_trans_log a
						,SRC_COMPAS_M.billing_trans_log_alloc b
					WHERE
						a.billing_trans_id = b.billing_trans_id
					and a.monetary_trans_type_id = 4
					and b.billable_entity_type_id = 2
					and a.monetary_trans_reason_type_id is null
					and b.creation_date BETWEEN TO_TIMESTAMP(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'') AND TO_TIMESTAMP(to_char(:v_report_end,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss''));

				UPDATE BDR_DM.daily_recon
				SET    PROTESTED_EMP_ACCT_ADJ_AMT = nvl(:v_amount,0)
				WHERE  report_date = :v_report_date;
				    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_protest_emp_acct_adj ENDS---------------	
		
		--sum_date_differ_future( v_report_date, p_report_start, p_report_end );	-------OAS DELETE
		
									------------- CODE FOR sum_date_differ_future BEGINS---------------	
				/*
				This query select items that have a received date greater than our snapshot
				report period, but were actually created in our reporting period
				*/
				
			v_amount := 0.0;
				
			V_STEP_NAME    := ''sum_date_differ_future - UPDATE - daily_recon'';
			V_STEP_SEQ     := : v_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

				SELECT NVL(sum(b.total_amount),0)
				INTO   v_amount
				FROM   SRC_COMPAS_M.billing_trans_log a, SRC_COMPAS_M.billing_trans_log_alloc b
				WHERE  a.billing_trans_id = b.billing_trans_id
				and trunc(a.received_date, ''DD'') > TO_TIMESTAMP(to_char(:v_report_end,''mm/dd/yyyy''),''mm/dd/yyyy'')
				and a.creation_date BETWEEN  TO_TIMESTAMP(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'') AND TO_TIMESTAMP(to_char(:v_report_end,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'')
				and a.monetary_trans_type_id <> 3;

				UPDATE BDR_DM.daily_recon
				SET    date_differ_future_amt = nvl(:v_amount,0)
				WHERE  report_date = :v_report_date;						
				    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_date_differ_future ENDS---------------	

		--sum_membership_andrus_amt( v_report_date, p_report_start, p_report_end );		----OAS DELETE

									------------- CODE FOR sum_membership_andrus_amt BEGINS---------------	
		  
			v_amount := 0.0;
				
			V_STEP_NAME    := ''sum_membership_andrus_amt - UPDATE - daily_recon'';
			V_STEP_SEQ     := : v_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

			   SELECT  sum(amount)
			   INTO    v_amount
			   FROM    SRC_COMPAS_M.assoc_non_premium_rpt
			   WHERE   due_date BETWEEN TO_TIMESTAMP(TO_CHAR(:v_report_start,''mm/dd/yyyy''),''mm/dd/yyyy'') AND TO_TIMESTAMP(TO_CHAR(:v_report_end,''mm/dd/yyyy''),''mm/dd/yyyy'')
			   --AND     creation_date BETWEEN to_date(to_char(p_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'') AND to_date(to_char(p_report_end,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'')
			   and (
					 -- membership and andrus payments from household
					 (account_receivable_type_id in (3,4)--membership, andrus
					  and responsible_party_type_id = 1 -- hhold
					  and billing_trans_type_id = 6) --applied
				 or
					-- funds distributed from premium to membership/andrus
					 (account_receivable_type_id in (3,4)--membership, andrus
					  and billing_trans_type_id in (3,4) --reallocate, misapplied)
					  and amount > 0)
				 or
					-- funds reversed from membership/andrus
					 (account_receivable_type_id in (3,4)--membership, andrus
					  and billing_trans_type_id = 5) -- protest
				 or
					-- hhld funds misapplied or realloc from membership/andrus
					(account_receivable_type_id in (3,4)--membership, andrus
					 and responsible_party_type_id = 1 -- hhold
					 and billing_trans_type_id in (3,4) -- realloc, misapplied
					 and amount < 0)
				or
					-- emp funds misapplied from membership
					(account_receivable_type_id = 3 --membership
					 and responsible_party_type_id = 2 -- emp
					 and billing_trans_type_id = 4 -- misapplied
					 and amount < 0)
				 );

				UPDATE BDR_DM.daily_recon
				SET    MEMBERSHIP_ANDRUS_FUNDS_AMT = nvl(:v_amount,0)
				WHERE  report_date = :v_report_date;				
				    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_membership_andrus_amt ENDS---------------	

		--sum_scr_2633(v_report_date,p_report_start,p_report_end)	-----OAS DELETE

									------------- CODE FOR sum_scr_2633 BEGINS---------------	
		  
			v_amount := 0.0;
				
			V_STEP_NAME    := ''sum_scr_2633 - UPDATE - daily_recon'';
			V_STEP_SEQ     := : v_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;
				
				SELECT NVL(SUM(b.total_amount),0)
				INTO   v_amount
				FROM  SRC_COMPAS_M.billing_trans_log a, SRC_COMPAS_M.billing_trans_log_alloc b
				WHERE
					a.billing_trans_id = b.billing_trans_id
				   and a.last_modified_by like ''%2633%''
				   AND a.creation_date BETWEEN TO_TIMESTAMP(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'') AND TO_TIMESTAMP(to_char(:v_report_end,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'');

				UPDATE BDR_DM.daily_recon
				SET    sum_scr_2633 = nvl(:v_amount,0)
				WHERE  report_date = :v_report_date;
								    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_scr_2633 ENDS---------------	

		--sum_from_pdp_mapd_amt(v_report_date,p_report_start,p_report_end);		------OAS DELETE
		
									------------- CODE FOR sum_from_pdp_mapd_amt BEGINS---------------	
			
			v_pdp_amt      := 0;
			v_mapd_amt     := 0;
			v_emp_pdp_amt  := 0;
			v_emp_mapd_amt := 0;
				
			V_STEP_NAME    := ''sum_from_pdp_mapd_amt - UPDATE - daily_recon'';
			V_STEP_SEQ     := : v_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

				SELECT  SUM (CASE
								   WHEN     monetary_trans_reason_type_id = 29
										  AND billable_entity_type_id = 1 THEN
									  b.total_amount
								   ELSE
									  0
								 END)
							 AS pdp_amt
					  , SUM (CASE
								   WHEN     monetary_trans_reason_type_id = 30
										  AND billable_entity_type_id = 1 THEN
									  b.total_amount
								   ELSE
									  0
								 END)
							 AS mapd_amt
					  , SUM (CASE
								   WHEN     monetary_trans_reason_type_id = 29
										  AND billable_entity_type_id = 2 THEN
									  b.total_amount
								   ELSE
									  0
								 END)
							 AS emp_pdp_amt
					  , SUM (CASE
								   WHEN     monetary_trans_reason_type_id = 30
										  AND billable_entity_type_id = 2 THEN
									  b.total_amount
								   ELSE
									  0
								 END)
							 AS emp_mapd_amt
					INTO   v_pdp_amt,v_mapd_amt, v_emp_pdp_amt, v_emp_mapd_amt
				  FROM SRC_COMPAS_M.billing_trans_log a, SRC_COMPAS_M.billing_trans_log_alloc b
				WHERE      a.billing_trans_id = b.billing_trans_id
						 AND a.monetary_trans_type_id = 1
						 AND a.billing_trans_type_id = 6
						 AND a.monetary_trans_reason_type_id IN (29, 30)
						 AND b.billable_entity_type_id IN (1, 2)
						AND a.creation_date BETWEEN TO_TIMESTAMP(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'')
						AND TO_TIMESTAMP(to_char(:v_report_end,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'');


					UPDATE BDR_DM.daily_recon
					SET   TRANSFER_FROM_PDP_AMT      = : v_pdp_amt
						, TRANSFER_FROM_MAPD_AMT     = : v_mapd_amt
						, EMP_TRANSFER_FROM_PDP_AMT  = : v_emp_pdp_amt
						, EMP_TRANSFER_FROM_MAPD_AMT = : v_emp_mapd_amt
					WHERE  report_date = :v_report_date;	
				    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_from_pdp_mapd_amt ENDS---------------	
					
		--sum_to_pdp_mapd_amt(v_report_date,p_report_start,p_report_end);
		
									------------- CODE FOR sum_to_pdp_mapd_amt BEGINS---------------	
				
			V_STEP_NAME    := ''sum_to_pdp_mapd_amt - UPDATE - daily_recon'';
			V_STEP_SEQ     := : v_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

					SELECT  sum(DECODE(b.billable_entity_type_id, 7, b.total_amount, 0)) ,
							sum(DECODE(b.billable_entity_type_id, 8, b.total_amount, 0))
					INTO    v_pdp_amt,v_mapd_amt

					  FROM SRC_COMPAS_M.billing_trans_log a, SRC_COMPAS_M.billing_trans_log_alloc b
					 WHERE a.billing_trans_id = b.billing_trans_id
					   AND b.billable_entity_type_id IN (7,8)
					   AND a.creation_date BETWEEN TO_TIMESTAMP(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'')
					   AND TO_TIMESTAMP(to_char(:v_report_end,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'');


					UPDATE BDR_DM.daily_recon
					SET TRANSFER_TO_PDP_AMT = nvl(:v_pdp_amt,0),
						TRANSFER_TO_MAPD_AMT = nvl(:v_mapd_amt,0)
					WHERE  report_date = :v_report_date;
				    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_to_pdp_mapd_amt ENDS---------------	
			
			-- From Mtran
		--sum_date_differ_prior( v_report_date, p_report_start, p_report_end );		-------OAS DELETE
		
									------------- CODE FOR sum_date_differ_prior BEGINS---------------	

			/*
			This query select items that have a received date less than our snapshot
			report period, but were actually created in our reporting period
			*/

			v_amount := 0.0;
				
			V_STEP_NAME    := ''sum_date_differ_prior - UPDATE - daily_recon'';
			V_STEP_SEQ     := : v_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

				select NVL(sum(transaction_amount),0)
				INTO v_amount
				from SRC_COMPAS_M.monetary_trans
				where trunc(applied_date, ''DD'') between TO_TIMESTAMP(to_char(:v_report_start,''mm/dd/yyyy''),''mm/dd/yyyy'') and TO_TIMESTAMP(to_char(:v_report_end,''mm/dd/yyyy''),''mm/dd/yyyy'')
				and trunc(received_date, ''DD'')< TO_TIMESTAMP(to_char(:v_report_start,''mm/dd/yyyy''),''mm/dd/yyyy'')
				and creation_date > TO_TIMESTAMP(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'')
				and monetary_trans_type_id = 1 --payment
				and billing_trans_type_id = 6 --applied
				and parent_billing_trans_id is null;

				UPDATE BDR_DM.daily_recon
				SET    date_differ_prior_amt = nvl(:v_amount,0)
				WHERE  report_date = :v_report_date;	
				    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_date_differ_prior ENDS---------------	
				
		--sum_bill_trans_no_mon_trans( v_report_date, p_report_start, p_report_end );
		
									------------- CODE FOR sum_bill_trans_no_mon_trans BEGINS---------------	
			/*
			COMPAS has several tables that hold financial transactions.  The billing transaction
			tables are used for reporting and the monetary transaction tables are used when
			applying funds to A/R.  Both tables should reconcile with each other.

			COMPAS had some problems with being unable to fully complete a transaction. The
			result is that the two tables were out of sync.  The billing transaction tables
			hold the partially completed transactions while the monetary transaction tables
			hold the correct, final transactions
			*/
			
			V_STEP_NAME    := ''sum_bill_trans_no_mon_trans - UPDATE - daily_recon'';
			V_STEP_SEQ     := : v_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

				SELECT  SUM(b.total_amount) ,
						SUM(b.premium_amount) ,
						SUM(b.employer_amount) ,
						SUM(b.membership_amount) ,
						SUM(b.andrus_amount)
				INTO    v_bt_no_mt_tot_amt,  v_bt_no_mt_prem_amt, v_bt_no_mt_emp_amt,
						v_bt_no_mt_memb_amt, v_bt_no_mt_and_amt
				FROM    SRC_COMPAS_M.billing_trans_log a, SRC_COMPAS_M.billing_trans_log_alloc b
				WHERE   a.billing_trans_id = b.billing_trans_id
				AND     b.billable_entity_type_id = 1
				AND     b.target_billable_entity_type_id = 1
				AND     a.monetary_trans_type_id <> 5
				AND     NVL(a.monetary_trans_reason_type_id,9999) NOT IN (2,25)
				AND     a.creation_date BETWEEN TO_TIMESTAMP(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'') AND TO_TIMESTAMP(to_char(:v_report_end,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'')
				AND  NOT  a.billing_trans_id IN  (
						SELECT mt.billing_trans_id
						FROM  SRC_COMPAS_M.monetary_trans mt);

				UPDATE BDR_DM.daily_recon
				SET btran_no_mtran_total_amt = nvl(:v_bt_no_mt_tot_amt,0),
					btran_no_mtran_premium_amt = nvl(:v_bt_no_mt_prem_amt,0),
					btran_no_mtran_employer_amt = nvl(:v_bt_no_mt_emp_amt,0),
					btran_no_mtran_membership_amt = nvl(:v_bt_no_mt_memb_amt,0),
					btran_no_mtran_andrus_amt  = nvl(:v_bt_no_mt_and_amt,0)
				WHERE  report_date = :v_report_date;
				    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_bill_trans_no_mon_trans ENDS---------------	
	
		--sum_btran_no_motran_empdist(v_report_date,p_report_start,p_report_end);	-----OAS DELETE
		
									------------- CODE FOR sum_btran_no_motran_empdist BEGINS---------------	
			v_amount := 0.0;
				
			V_STEP_NAME    := ''sum_btran_no_motran_empdist - UPDATE - daily_recon'';
			V_STEP_SEQ     := : v_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

				SELECT /*+ parallel(b) parallel(ba) */ NVL(SUM(ba.total_amount),0)
				INTO   v_amount
				from SRC_COMPAS_M.billing_trans_log b, SRC_COMPAS_M.billing_trans_log_alloc ba
				where b.billing_trans_id = ba.billing_trans_id
				and ba.billable_entity_type_id = 1
				and ba.target_billable_entity_type_id = 1
				and b.monetary_trans_type_id = 5
				and ba.total_amount > 0
				and b.creation_date BETWEEN TO_TIMESTAMP(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'') AND TO_TIMESTAMP(to_char(:v_report_end,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'')
				and not b.billing_trans_id in (
					select  /*+ parallel(mt) */ mt.billing_trans_id
					from    SRC_COMPAS_M.monetary_trans mt)
				AND ba.creation_date BETWEEN TO_TIMESTAMP(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'') AND TO_TIMESTAMP(to_char(:v_report_end,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'');

				UPDATE BDR_DM.daily_recon
				SET    BTRAN_NO_MTRAN_EMPDIST_AMT = nvl(:v_amount,0)
				WHERE  report_date = :v_report_date;
				    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_btran_no_motran_empdist ENDS---------------	
						
		--sum_mon_trans_no_bill_trans(v_report_date,p_report_start,p_report_end);	---------OAS DELETE
		
									------------- CODE FOR sum_mon_trans_no_bill_trans BEGINS---------------	
		  
			v_amount := 0.0;
		  
			V_STEP_NAME    := ''sum_mon_trans_no_bill_trans - UPDATE - daily_recon'';
			V_STEP_SEQ     := : v_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;
				SELECT  /*+ parallel(mt) */ sum(mt.transaction_amount)
				INTO    v_amount
				FROM    SRC_COMPAS_M.monetary_trans mt
				WHERE   mt.billing_trans_id not in
				(SELECT /*+ parallel(btl) parallel(btla) */ btl.billing_trans_id
				 from   SRC_COMPAS_M.billing_trans_log btl
					,   SRC_COMPAS_M.billing_trans_log_alloc btla
				 where  btl.billing_trans_id = btla.billing_trans_id)
				 and    mt.creation_date BETWEEN TO_TIMESTAMP(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'') AND TO_TIMESTAMP(to_char(:v_report_end,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'')
				 and    mt.monetary_trans_type_id <> 5;

				UPDATE BDR_DM.daily_recon
				SET    MTRAN_NO_BTRAN_AMT = nvl(:v_amount,0)
				WHERE  report_date = :v_report_date;						
				    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_mon_trans_no_bill_trans ENDS---------------	

			-- From AR
		--sum_pre_retro_ar( v_report_date,p_report_start,p_report_end);		-------OAS DELETE
		
									------------- CODE FOR sum_pre_retro_ar BEGINS---------------
									
			/* COMPAS reports on premium beginning 1/2002.  Note: A retro change date of
			1/2002 prevents any adjustments from occurring prior to 2002.

			Retro changes are required by the business pre 2002 due to e.g., a date of death
			change. A procedure is currently in place allows the business to modify pre 2002
			A/R. This process temporarily applies current premium to pre 2002 A/R.

			The MSOA for a single month will reflect a reduction in earned premium with no
			matching reconciling event, such as a refund or protest.

			The MSOA for the month of when the A/R is corrected will reflect an increase in
			earned premium with no matching reconciling event, such as a payment.
			*/

			v_amount := 0.0;
			
			V_STEP_NAME    := ''sum_pre_retro_ar - UPDATE - daily_recon'';
			V_STEP_SEQ     := : v_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

			SELECT sum(paid_amount)
			INTO v_amount
			FROM SRC_COMPAS_M.account_receivable
			WHERE due_date < :g_retro_date
			AND acct_receivable_type_id = 2;

			UPDATE BDR_DM.daily_recon
			SET    pre_retro_paid_premium = nvl(:v_amount,0)
			WHERE  report_date = :v_report_date;
				    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_pre_retro_ar ENDS---------------	
						
		--sum_pre_retro_ar_current_month( v_report_date, p_report_start, p_report_end );		-------OAS DELETE

		
									------------- CODE FOR sum_pre_retro_ar_current_month BEGINS---------------	
		  
			v_amount := 0.0;
		  
			V_STEP_NAME    := ''sum_pre_retro_ar_current_month - UPDATE - daily_recon'';
			V_STEP_SEQ     := : v_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

				SELECT sum(paid_amount)
				INTO v_amount
				FROM SRC_COMPAS_M.account_receivable
				WHERE due_date < :g_retro_date
				AND acct_receivable_type_id = 2
				AND creation_date BETWEEN TO_TIMESTAMP(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'')
				AND TO_TIMESTAMP(to_char(:v_report_end,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'');

				UPDATE BDR_DM.daily_recon
				SET    PRE_retro_PAID_PREMIUM_CURRENT = nvl(:v_amount,0)
				WHERE  report_date = :v_report_date;	
				    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_pre_retro_ar_current_month ENDS---------------	
				
		--sum_pre_retro_ar_prior_month( v_report_date,p_report_start,p_report_end);		-------OAS DELETE
		
									------------- CODE FOR sum_pre_retro_ar_prior_month BEGINS---------------	
		  
			v_amount := 0.0;
			
			V_STEP_NAME    := ''sum_pre_retro_ar_prior_month - UPDATE - daily_recon'';
			V_STEP_SEQ     := : v_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

				SELECT pre_retro_paid_premium_current
				INTO   v_amount
				FROM   BDR_DM.daily_recon a
				WHERE  a.report_date = ADD_MONTHS(:v_report_date, -1);
		

				UPDATE BDR_DM.daily_recon
				SET    PRE_retro_PAID_PREMIUM_PRIOR = nvl(:v_amount,0)
				WHERE  report_date = :v_report_date;
				    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_pre_retro_ar_prior_month ENDS---------------	
				
		--sum_pre_retro_ar_prior_mnth_ot(v_report_date,p_report_start,p_report_end);		-------OAS DELETE
		
									------------- CODE FOR sum_pre_retro_ar_prior_mnth_ot BEGINS---------------	
		  
			v_amount := 0.0;
			
			V_STEP_NAME    := ''sum_pre_retro_ar_prior_mnth_ot - UPDATE - daily_recon'';
			V_STEP_SEQ     := : v_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

				SELECT   sum(paid_amount)
				INTO     v_amount
				FROM     SRC_COMPAS_M.account_receivable
				WHERE    due_date < :g_retro_date
				AND      creation_date < TO_TIMESTAMP(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'')
				AND      acct_receivable_type_id = 2 ; -- premium

				UPDATE BDR_DM.daily_recon
				SET    PRE_retro_PAID_PREM_PRIOR_OT = nvl(:v_amount, 0)
				WHERE  report_date = :v_report_date;
								    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_pre_retro_ar_prior_mnth_ot ENDS---------------	

		--sum_hhld_waiting_recalc(v_report_date,p_report_start,p_report_end);		-------OAS DELETE
		
									------------- CODE FOR sum_hhld_waiting_recalc BEGINS---------------	
		  
			v_amount := 0.0;
		  
			V_STEP_NAME    := ''sum_hhld_waiting_recalc - UPDATE - daily_recon'';
			V_STEP_SEQ     := : v_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;
						
				select /*+ parallel(ar) parallel(mt) */ NVL(SUM(ar.paid_amount) - SUM(mt.paid_amount),0), COUNT(*)
				INTO v_amount, v_count
				from
				(select household_id, sum(paid_amount) as paid_amount
				from SRC_COMPAS_M.account_receivable
				where responsible_party_type_id = 1
				group by household_id) ar,
				(select household_id, sum(transaction_amount) as paid_amount
				from SRC_COMPAS_M.monetary_trans
				where responsible_party_type_id = 1
				group by household_id) mt
				where ar.household_id = mt.household_id
				and ar.paid_amount <> mt.paid_amount;

				UPDATE BDR_DM.daily_recon
				SET HOUSEHOLDS_WAITING_RECALC_AMT = nvl(:v_amount,0),
					HOUSEHOLDS_WAITING_RECALC_CNT = :v_count
				WHERE  report_date = :v_report_date;
				    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_hhld_waiting_recalc ENDS---------------	

		--sum_pre_retro_ar_prior_mnth_ot(v_report_date,p_report_start,p_report_end);		-------OAS DELETE
		
									------------- CODE FOR sum_pre_retro_ar_prior_mnth_ot BEGINS---------------	
		  
			v_amount := 0.0;
			
			V_STEP_NAME    := ''sum_pre_retro_ar_prior_mnth_ot - 2nd UPDATE - daily_recon'';
			V_STEP_SEQ     := : v_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

				SELECT   sum(paid_amount)
				INTO     v_amount
				FROM     SRC_COMPAS_M.account_receivable
				WHERE    due_date < :g_retro_date
				AND      creation_date < TO_TIMESTAMP(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'')
				AND      acct_receivable_type_id = 2 ; -- premium

				UPDATE BDR_DM.daily_recon
				SET    PRE_retro_PAID_PREM_PRIOR_OT = nvl(:v_amount, 0)
				WHERE  report_date = :v_report_date;
								    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_pre_retro_ar_prior_mnth_ot ENDS---------------	

		--sum_hhld_waiting_recalc(v_report_date,p_report_start,p_report_end);		-------OAS DELETE
		
									------------- CODE FOR sum_hhld_waiting_recalc BEGINS---------------	
		  
			v_amount := 0.0;
		  
			V_STEP_NAME    := ''sum_hhld_waiting_recalc - 2nd UPDATE - daily_recon'';
			V_STEP_SEQ     := : v_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;
						
				select /*+ parallel(ar) parallel(mt) */ NVL(SUM(ar.paid_amount) - SUM(mt.paid_amount),0), COUNT(*)
				INTO v_amount, v_count
				from
				(select household_id, sum(paid_amount) as paid_amount
				from SRC_COMPAS_M.account_receivable
				where responsible_party_type_id = 1
				group by household_id) ar,
				(select household_id, sum(transaction_amount) as paid_amount
				from SRC_COMPAS_M.monetary_trans
				where responsible_party_type_id = 1
				group by household_id) mt
				where ar.household_id = mt.household_id
				and ar.paid_amount <> mt.paid_amount;

				UPDATE BDR_DM.daily_recon
				SET HOUSEHOLDS_WAITING_RECALC_AMT = nvl(:v_amount,0),
					HOUSEHOLDS_WAITING_RECALC_CNT = :v_count
				WHERE  report_date = :v_report_date;
				    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_hhld_waiting_recalc ENDS---------------	
						
		--sum_overstated_emp_credit( v_report_date, p_report_start, p_report_end );		-------OAS DELETE
		
									------------- CODE FOR sum_overstated_emp_credit BEGINS---------------	
			
			v_amount := 0.0;
		  
			V_STEP_NAME    := ''sum_overstated_emp_credit - UPDATE - daily_recon'';
			V_STEP_SEQ     := : v_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;
			
				SELECT  sum(credit_amount)
				INTO    v_amount
				FROM SRC_COMPAS_M.employer_billing_bucket
				WHERE (last_modified_date >= bill_date
				AND nvl(paid_ind, ''N'') = ''Y'')
				OR nvl(paid_ind, ''N'') = ''N''
				AND trunc(bill_date, ''MONTH'') = TRUNC(ADD_MONTHS(:v_report_date,1), ''MONTH'');

				UPDATE BDR_DM.daily_recon
				SET    overstated_emp_credit = nvl(:v_amount,0)
				WHERE  report_date = :v_report_date;
				    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_overstated_emp_credit ENDS---------------	

		--		pr_log_complete(v_report_date,v_procedure);		-----OAS DELETE
		  
			V_STEP_NAME    := ''UPDATE - daily_recon'';
			V_STEP_SEQ     := : v_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

				UPDATE BDR_DM.DAILY_RECON
				SET CREATED_BY = ''combatch'',
				CREATION_DATE = TRUNC(CURRENT_TIMESTAMP, ''DD''),
				LAST_MODIFIED_BY = ''combatch'',
				LAST_MODIFIED_DATE = TRUNC(CURRENT_TIMESTAMP, ''DD'')
				WHERE REPORT_DATE = :v_report_date;
			    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

---------------COMMENTED BY OAS-----------------		  				
/*
				COMMIT;

				--pkg_utility.pr_write_status(''recon_status'');

				--COMPAS_MO.send_email(''"recon"<ois_it_operations@uhc.com>'',g_email,TO_CHAR(p_report_date, ''mm/dd/yyyy'') || '' COMPAS Reconcilation done'', '' '');

			EXCEPTION
				WHEN OTHERS THEN
					dbms_output.put_line(''Error '' || SUBSTR(SQLERRM,1,240));
					pr_log_error(p_report_date, v_procedure, SQLERRM);
					--COMPAS_MO.send_email(''"recon"<ois_it_operations@uhc.com>'',g_email,''COMPAS Reconcilation error'', SQLERRM);

			END;
*/
---------------COMMENTED BY OAS-----------------
									------------- CODE FOR pr_recon2(); ENDS---------------	
									
	---------------COMMENTED BY OAS-----------------
	/*
		EXCEPTION
			WHEN OTHERS THEN
				dbms_output.put_line(''Error '' || SUBSTR(SQLERRM,1,240));
				pr_log_error(v_report_date, ''pr_recon'', SQLERRM);
				--COMPAS_MO.send_email(''"recon"<ois_it_operations@uhc.com>'',g_email,''COMPAS Reconcilation error'', SQLERRM);

		END;
	*/
	---------------COMMENTED BY OAS-----------------
									------------- CODE FOR COMPAS_MO.PKG_DAILY_RECON.PR_RECON(); ENDS---------------
									
---------------COMMENTED BY OAS-----------------									
/*
		
                                                EXCEPTION
                                                WHEN OTHERS THEN

                                                        lv_error_msg := SUBSTR(SQLERRM, 1, 250);
                                                        SELECT SYSDATE INTO lv_etl_end_time FROM dual;

                                                        UPDATE ETL.ETL_MCLONE_DECOM_PROC_LIST
                                                        SET run_status  = ''ERROR'',
                                                          etl_end_time  = lv_etl_end_time,
                                                          etl_error_msg = lv_error_msg
                                                        WHERE proc_name = lv_proc_name;
                                                        COMMIT;

                                                        SELECT SYSDATE INTO lv_etl_end_time FROM dual;

                                                        UPDATE ETL.ETL_MCLONE_DECOM_PROC_LIST
                                                        SET etl_time_taken = round((cast(etl_end_time as date) - cast(etl_start_time as date)) * 24 * 60 * 60)
                                                        WHERE proc_name    = lv_proc_name;

                                                        COMMIT;

                                                        lv_exception := ''Y'';
                                                        RAISE;
                                      END;

                                      IF lv_exception = ''Y'' THEN
                                      --DBMS_OUTPUT.PUT_LINE(''lv_exception'');
                                        EXIT;
                                      END IF;

                                      SELECT SYSDATE INTO lv_etl_end_time FROM dual;

                                      UPDATE ETL.ETL_MCLONE_DECOM_PROC_LIST
                                      SET run_status  = ''COMPLETE'',
                                      etl_end_time  = lv_etl_end_time
                                      WHERE proc_name = lv_proc_name;

                                      COMMIT;

                                      UPDATE ETL.ETL_MCLONE_DECOM_PROC_LIST
                                      SET etl_time_taken = round((cast(etl_end_time as date) - cast(etl_start_time as date)) * 24 * 60 * 60)
                                      WHERE proc_name    = lv_proc_name;

                                      COMMIT;


                              END;
                              BEGIN

                                        SELECT proc_name
                                        INTO lv_proc_name
                                        FROM
                                        (SELECT proc_name
                                        FROM ETL.ETL_MCLONE_DECOM_PROC_LIST
                                        WHERE run_status      IN (''READY'',''ERROR'')
                                        AND proc_launch_order = lv_min_order
                                        AND active_ind = ''Y''
                                        )
                                        WHERE ROWNUM = 1;

                                        EXCEPTION WHEN NO_DATA_FOUND THEN
                                        lv_next_rec_found := ''N'';
                                        --dbms_output.put_line(''Exception'');
                              END;

                              --lv_proc_final := '''';
                              --lv_proc_name := '''';
                    END LOOP;

                    SELECT LISTAGG(run_status , '''') WITHIN GROUP (
                    ORDER BY run_status)
                    INTO lv_flag
                    FROM
                      (SELECT DISTINCT run_status
                      FROM ETL.ETL_MCLONE_DECOM_PROC_LIST
                      WHERE proc_launch_order = lv_min_order
                      AND active_ind = ''Y''
                      );

                    IF lv_flag      = ''COMPLETE'' OR (lv_min_order = lv_max_order) THEN
                      lv_min_order := lv_min_order + 1;		--------------------12+1 => FALSE FOR NEXT ITERATION
                    END IF;

          END LOOP;

          --Returns the result set
          P_ToContinueStatus := ''Y'';
          P_ErrorYNFlg       := ''N'';
          P_ErrorStr         := '''';

          EXCEPTION WHEN OTHERS THEN
            P_ErrorStr         := ''ERROR: '' || SQLCODE || ''-'' || SQLERRM || ''-'' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE()|| Chr(10)||DBMS_UTILITY.FORMAT_ERROR_STACK();
            P_ToContinueStatus := ''N'';
            P_ErrorYNFlg       := ''Y'';
            ROLLBACK;
END;
/
*/
---------------COMMENTED BY OAS-----------------

						----------------CODE FOR MAIN PROCEDURE ETL.SP_ETL_MCLONE_DECOM_M ENDS------------------------
						

CALL UTIL.SP_ETL_CHECK_CONSTRAINTS(:DB_NAME , :APPLICATION , :WORKFLOW_NAME , :OBJECT_NAME , :V_BATCH_ID );		---------OAS ADD

UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''COMPLETE'', ERROR_MSG = null, BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
;
UPDATE  UTIL.ETL_BATCH_OBJECT_INCR_VALU SET INCR_COLUMN_VALUE = :V_BATCH_ID, LST_MOD_DT = CURRENT_TIMESTAMP() 
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID''
;



EXCEPTION

WHEN OTHER THEN

UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''ERROR'', ERROR_MSG = :SQLERRM,  BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
;

INSERT INTO  UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ERROR_MSG, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''ERROR'', :V_STEP_NAME, :V_STEP_SEQ, :SQLERRM, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() )
;



RAISE;

END;

';