USE SCHEMA BDR_DM; CREATE OR REPLACE PROCEDURE "SP_CLAIMS_IXL_PARTB_RPARTBWGTDTL_M"("DB_NAME" VARCHAR(16777216), "APPLICATION" VARCHAR(16777216), "WORKFLOW_NAME" VARCHAR(16777216), "OBJECT_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '

-- Original workflow: wkf_Claims_PartB_IXL_TargetLoad_M
-- Original mapping: m_Claims_IXL_PartB_RPARTBWGTDTL_M
-- Original folder: Claims
-- Original filename: wkf_Claims_PartB_IXL_TargetLoad_M.XML

DECLARE


V_ROWS_INSERTED  INTEGER;
V_ROWS_UPDATED INTEGER;
V_ROWS_DELETED INTEGER;
V_LAST_QUERY_ID VARCHAR;

V_WH VARCHAR;
V_BATCH_ID INTEGER;


V_BATCH_OBJECT_START_TIME        VARCHAR;
V_STEP_START_TIME    VARCHAR;
V_STEP_NAME VARCHAR;
V_STEP_SEQ INTEGER DEFAULT 0;
V_ETL_LST_BTCH_ID INTEGER;

V_BEN_AMT_MULVALUE VARCHAR;


BEGIN

EXECUTE IMMEDIATE ''USE DATABASE ''||:DB_NAME; 

ALTER SESSION 
SET TIMEZONE = ''America/Chicago'';

V_BATCH_OBJECT_START_TIME := (SELECT	CURRENT_TIMESTAMP());



LET res1 RESULTSET := 
(

SELECT 

WH ,
BATCH_ID
  
FROM UTIL.ETL_BATCH_OBJECT_CONTROL
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
FETCH FIRST 1 ROW ONLY

)
;


LET C1 CURSOR FOR res1;
open C1;
FETCH C1 into  V_WH,V_BATCH_ID ;
close C1;


LET res2 RESULTSET := 

(

WITH PARAMETERS (BEN_AMT_MULVALUE) AS
(
  
SELECT * 
FROM  
(SELECT PARAMETER_NAME, PARAMETER_VALUE  FROM UTIL.ETL_OBJECT_PARAMETER_VALUE 
WHERE 1 = 1
AND APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
AND ACTIVE_FLG = ''Y''  
  
UNION ALL       

SELECT PARAMETER_NAME, PARAMETER_VALUE  FROM UTIL.ETL_GLOBAL_PARAMETER_VALUE WHERE PAR_GLOBAL_TYPE = ''PARGLOBAL_OPREPORTS'' AND ACTIVE_FLG = ''Y''
AND PARAMETER_NAME NOT IN  (
SELECT PARAMETER_NAME  FROM UTIL.ETL_OBJECT_PARAMETER_VALUE WHERE 1 = 1
AND APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
AND ACTIVE_FLG = ''Y''   ))
 
PIVOT(MAX(PARAMETER_VALUE) FOR PARAMETER_NAME IN (''BEN_AMT_MULVALUE'')) 

 
)  
SELECT * FROM PARAMETERS 
)  
  
;


LET C2 CURSOR FOR res2;
open C2;
FETCH C2 into  V_BEN_AMT_MULVALUE; 
close C2;


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:V_WH;
USE SCHEMA BDR_DM;   


INSERT INTO UTIL.ETL_BATCH_OBJECT_INCR_VALU (APPLICATION, WORKFLOW_NAME, OBJECT_NAME, INCR_COLUMN, INCR_COLUMN_VALUE )
SELECT * FROM (select :APPLICATION AS APPLICATION, :WORKFLOW_NAME AS WORKFLOW_NAME, :OBJECT_NAME AS OBJECT_NAME, ''ETL_LST_BTCH_ID'' AS INCR_COLUMN, -1 AS INCR_COLUMN_VALUE) A
WHERE NOT EXISTS (SELECT 1 FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU B WHERE B.APPLICATION = A.APPLICATION AND B.WORKFLOW_NAME = A.WORKFLOW_NAME AND B.OBJECT_NAME = A.OBJECT_NAME AND B.INCR_COLUMN = A.INCR_COLUMN)
;

V_ETL_LST_BTCH_ID :=(SELECT INCR_COLUMN_VALUE FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID'');
--COMMENTED BY OAS--
/*
CREATE OR REPLACE PROCEDURE DM.SP_R_PART_B_WGT_DTL (
    P_ToStart            IN     NUMBER,
    P_ToContinueStatus      OUT VARCHAR2,
    P_ErrorYNFlg            OUT VARCHAR2,
    P_ErrorStr              OUT VARCHAR2)
---------------------------------------------------------------------------
--Purpose         : This procedure populates PART_B_WGT_DTL fact table
--
--Application Ref : Program Global Dashboard
--Called From     :
--Author          : By CTS    Inital Date : 06/01/2017
--Change History
---------------------------------------------------------------------------
--    Date             Who Changed             What Changed
--
--
---------------------------------------------------------------------------
AS
    V_BEN_AMT_MULVALUE   DECIMAL (20, 20);
    V_PROC_NAME          VARCHAR (50) := ''SP_R_PART_B_WGT_DTL'';
    V_ROWS_AFFTD         NUMBER (20) := 0;
    V_BTCH_ID            NUMBER (10);

BEGIN
	
     SELECT MAX (BATCH_ID)
      INTO V_BTCH_ID
      FROM ETL.ETL_BATCH_LOG
     WHERE APPLICATION = ''PARTB'' AND BATCH_STATUS != ''COMPLETE''; 
	
    SELECT METADATA_VALUE
      INTO V_BEN_AMT_MULVALUE
      FROM ETL.ETL_APPLICATION_METADATA
     WHERE APPLICATION = ''PARTB'' AND METADATA_TYPE = ''V_BEN_AMT_MULVALUE'';
	
    INSERT INTO ETL.ETL_DETAIL_LOAD_INFO (APPLICATION,
                                          ETL_BATCH_ID,
                                          ETL_PROC_NAME,
                                          ACTION,
                                          STEP_INFO,
                                          ROWS_AFFECTED,
                                          ETL_DATETIME)
         VALUES (''PARTB'',
                 V_BTCH_ID,
                 V_PROC_NAME,
                 ''START'',
                 ''PROCEDURE STARTS'',
                 V_ROWS_AFFTD,
                 SYSTIMESTAMP);

  COMMIT;

    IF (P_ToStart = 1)
    THEN
        BEGIN
	*/
	--COMMENTED BY OAS--
	V_STEP_NAME    := ''TRUNCATE - R_PART_B_WGT_DTL'';
	V_STEP_SEQ     :=  V_STEP_SEQ+1;
	V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
	V_ROWS_INSERTED := null;
	V_ROWS_UPDATED := null;
	V_ROWS_DELETED := null;

    EXECUTE IMMEDIATE ''TRUNCATE TABLE BDR_DM.R_PART_B_WGT_DTL'';

	INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME) VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );
	
    --DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS (''DM'', ''R_PART_B_WGT_DTL'');

	V_STEP_NAME    := ''INSERT - R_PART_B_WGT_DTL'';
	V_STEP_SEQ     :=  V_STEP_SEQ+1;
	V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
	V_ROWS_INSERTED := null;
	V_ROWS_UPDATED := null;
	V_ROWS_DELETED := null;

    INSERT INTO /*+ enable_parallel_dml APPEND */
    BDR_DM.R_PART_B_WGT_DTL (PLSRV_2_DESC,
        PLN_TYP_DESC,
        ST_CD,
        SRVC_YR_NBR,
        SRVC_FROM_MO_NBR,
        BEN_TOT_AMT,
        BL_CNT,
        BEN_TOT_PD_AMT,
        BL_PD_CNT,
        CPT_CD,
        PLSRV_DESC,
        CLM_LOC_CD,
        CATGY_CD,
        EC_UB92_IND,
        MED_PLSRV_DESC,
        CARR_TYP_DESC,
        ETL_LST_BTCH_ID)
    WITH TEMP_PART_B_WGT_DTL_SET6 AS
    (
		SELECT /*+ materialize */
        CASE
            WHEN CPT_CATGY_CD IN
                     (''Ambulance'', ''DME'', ''Drugs'')
            THEN
                CPT_CATGY_CD
            WHEN     CPT_CATGY_CD IN
                         (''ASC'', ''Unknown'')
                 AND CARR_TYP_DESC = ''DMERC''
            THEN
                ''Leftover DMERC''
            WHEN     CPT_CATGY_CD = ''Therapy''
                 AND CARR_TYP_DESC IN
                         (''DMERC'', ''Professional'')
            THEN
                ''Therapy EC''
            WHEN     CPT_CATGY_CD = ''Therapy''
                 AND CARR_TYP_DESC = ''Institutional''
            THEN
                ''Therapy FEK''
            WHEN     CPT_CATGY_CD = ''Therapy''
                 AND CARR_TYP_DESC = ''Manual''
            THEN
                ''Therapy Manual''
            WHEN CARR_TYP_DESC = ''Professional''
            THEN
                ''Physician''
            WHEN CARR_TYP_DESC = ''Institutional''
            THEN
                ''OPPS''
            ELSE
                ''Leftover''
        END AS PLSRV_DESC,
        PLN_TYP_DESC,
        ST_CD,
        SRVC_YR_NBR,
        SRVC_FROM_MO_NBR,
        BEN_TOT_AMT,
        BL_CNT,
        BEN_TOT_PD_AMT,
        BL_PD_CNT,
        CPT_CD,
        CLM_LOC_CD,
        CPT_CATGY_CD,
        EC_UB92_IND,
        MED_PLSRV_DESC,
        CARR_TYP_DESC
        FROM BDR_DM.TEMP_PART_B_WGT_DTL
        WHERE MED_PLSRV_SET = 6),
    TEMP_PART_B_WGT_DTL_SET1 AS
    (
		SELECT /*+ materialize */
        CASE
            WHEN CPT_CATGY_CD IN (''Ambulance'', ''DME'', ''Drugs'')
            THEN
                CPT_CATGY_CD
            WHEN  CPT_CATGY_CD IN (''ASC'', ''Unknown'')
                AND CARR_TYP_DESC = ''DMERC''
            THEN
                ''Leftover DMERC''
            WHEN CPT_CATGY_CD = ''Therapy''
                AND CARR_TYP_DESC IN (''DMERC'', ''Professional'')
            THEN
                ''Therapy EC''
            WHEN CPT_CATGY_CD = ''Therapy''
                AND CARR_TYP_DESC = ''Institutional''
            THEN
                ''Therapy FEK''
		    WHEN CPT_CATGY_CD = ''Therapy''
                AND CARR_TYP_DESC = ''Manual''
            THEN
                ''Therapy Manual''            ------SB : US101354 - New Enhancement
            WHEN CPT_CATGY_CD IN (''ASC'', ''Unknown'')
                AND CARR_TYP_DESC IN (''Institutional'', ''Professional'', ''Manual'')         ------SB : US101354 - New Enhancement
            THEN
                ''Physician''
            WHEN CARR_TYP_DESC = ''Unknown''
            THEN
                ''Unknown Carrier Code''
            WHEN CARR_TYP_DESC = ''Manual''
            THEN
                ''Leftover''                  ------SB : US101354 - New Enhancement
            ELSE
                ''Error''
        END AS PLSRV_DESC,
        PLN_TYP_DESC,
        ST_CD,
        SRVC_YR_NBR,
        SRVC_FROM_MO_NBR,
        BEN_TOT_AMT,
        BL_CNT,
        BEN_TOT_PD_AMT,
        BL_PD_CNT,
        CPT_CD,
        CLM_LOC_CD,
        CPT_CATGY_CD,
        EC_UB92_IND,
        MED_PLSRV_DESC,
        CARR_TYP_DESC
        FROM BDR_DM.TEMP_PART_B_WGT_DTL
        WHERE MED_PLSRV_SET = 1),
    TEMP_PART_B_WGT_DTL_SET2 AS
    (
		SELECT /*+ materialize */
        CASE
        WHEN CPT_CATGY_CD IN (''Ambulance'', ''DME'', ''Drugs'')
            THEN
                CPT_CATGY_CD
            WHEN CPT_CATGY_CD IN (''ASC'', ''Unknown'')
                AND CARR_TYP_DESC = ''DMERC''
            THEN
                ''Leftover DMERC''
            WHEN CPT_CATGY_CD = ''Therapy''
                 AND CARR_TYP_DESC IN (''DMERC'', ''Professional'')
            THEN
                ''Therapy EC''
            WHEN CPT_CATGY_CD = ''Therapy''
                 AND CARR_TYP_DESC = ''Institutional''
            THEN
                ''Therapy FEK''
	        WHEN CPT_CATGY_CD = ''Therapy''
                 AND CARR_TYP_DESC = ''Manual''
            THEN
                ''Therapy Manual''            ------SB : US101354 - New Enhancement
            WHEN CPT_CATGY_CD IN (''ASC'', ''Unknown'')
                 AND CARR_TYP_DESC = ''Professional''
            THEN
                ''Physician''
            WHEN CPT_CATGY_CD IN (''ASC'', ''Unknown'')
                 AND CARR_TYP_DESC = ''Institutional''
            THEN
                ''OPPS''
            WHEN CARR_TYP_DESC = ''Unknown''
            THEN
                ''Unknown Carrier Code''

--------------------------------------------------------------------------------------------

			WHEN     CARR_TYP_DESC = ''Manual''
                AND SUBSTR (MED_PLSRV_DESC, 1, 2) IN (''21'', ''22'')
                AND CPT_CATGY_CD = ''Unknown''
			THEN
               ''OPPS''                                    ------SB : US101354 - New Enhancement
			WHEN     CARR_TYP_DESC = ''Manual''
                AND SUBSTR (MED_PLSRV_DESC, 1, 2) IN (''21'', ''22'')
                AND CPT_CATGY_CD <> ''Unknown''
			THEN
               ''Physician''                               ------SB : US101354 - New Enhancement

--------------------------------------------------------------------------------------------
            WHEN CARR_TYP_DESC = ''Manual''
            THEN
                ''Leftover''                  ------SB : US101354 - New Enhancement
            ELSE
                ''Error''
        END AS PLSRV_DESC,
        PLN_TYP_DESC,
        ST_CD,
        SRVC_YR_NBR,
        SRVC_FROM_MO_NBR,
        BEN_TOT_AMT,
        BL_CNT,
        BEN_TOT_PD_AMT,
        BL_PD_CNT,
        CPT_CD,
        CLM_LOC_CD,
        CPT_CATGY_CD,
        EC_UB92_IND,
        MED_PLSRV_DESC,
        CARR_TYP_DESC
        FROM BDR_DM.TEMP_PART_B_WGT_DTL
        WHERE MED_PLSRV_SET = 2),
    TEMP_PART_B_WGT_DTL_SET3 AS
    (
		SELECT /*+ materialize */
        CASE
            WHEN CPT_CATGY_CD IN
                     (''Ambulance'', ''DME'', ''Drugs'')
            THEN
                CPT_CATGY_CD
            WHEN     CPT_CATGY_CD IN
                         (''Therapy'', ''ASC'', ''Unknown'')
                 AND CARR_TYP_DESC IN
                         (''DMERC'', ''Professional'')
            THEN
                ''Therapy EC''
            WHEN     CPT_CATGY_CD IN
                         (''Therapy'', ''ASC'', ''Unknown'')
                 AND CARR_TYP_DESC = ''Institutional''
            THEN
                ''Therapy FEK''
			WHEN     CPT_CATGY_CD = ''Therapy''
                 AND CARR_TYP_DESC = ''Manual''
            THEN
                ''Therapy Manual''            ------SB : US101354 - New Enhancement
            WHEN CARR_TYP_DESC = ''Unknown''
            THEN
                ''Unknown Carrier Code''
			WHEN CARR_TYP_DESC = ''Manual''
            THEN
                ''Leftover''                  ------SB : US101354 - New Enhancement
            ELSE
                ''Error''
        END    AS PLSRV_DESC,
        PLN_TYP_DESC,
        ST_CD,
        SRVC_YR_NBR,
        SRVC_FROM_MO_NBR,
        BEN_TOT_AMT,
        BL_CNT,
        BEN_TOT_PD_AMT,
        BL_PD_CNT,
        CPT_CD,
        CLM_LOC_CD,
        CPT_CATGY_CD,
        EC_UB92_IND,
        MED_PLSRV_DESC,
        CARR_TYP_DESC
        FROM BDR_DM.TEMP_PART_B_WGT_DTL
        WHERE MED_PLSRV_SET = 3),
    TEMP_PART_B_WGT_DTL_SET5 AS
    (
		SELECT /*+ materialize */
        CASE
            WHEN CPT_CATGY_CD IN
                     (''Ambulance'', ''DME'', ''Drugs'')
            THEN
                CPT_CATGY_CD
            WHEN     CPT_CATGY_CD IN
                         (''ASC'', ''Unknown'')
                 AND CARR_TYP_DESC = ''DMERC''
            THEN
                ''Leftover DMERC''
            WHEN     CPT_CATGY_CD = ''Therapy''
                 AND CARR_TYP_DESC IN
                         (''DMERC'', ''Professional'')
            THEN
                ''Therapy EC''
            WHEN     CPT_CATGY_CD = ''Therapy''
                 AND CARR_TYP_DESC = ''Institutional''
            THEN
                ''Therapy FEK''
			WHEN     CPT_CATGY_CD = ''Therapy''
                 AND CARR_TYP_DESC = ''Manual''
            THEN
                ''Therapy Manual''            ------SB : US101354 - New Enhancement
			WHEN     CPT_CATGY_CD IN
                         (''ASC'', ''Unknown'')
                 AND CARR_TYP_DESC IN (''Institutional'',''Manual'')
            THEN
                ''Dialysis''                  ------SB : US101354 - New Enhancement
            WHEN     CPT_CATGY_CD IN
                         (''ASC'', ''Unknown'')
                 AND CARR_TYP_DESC = ''Professional''
            THEN
                ''Physician''
            WHEN CARR_TYP_DESC = ''Unknown''
            THEN
                ''Unknown Carrier Code''
			WHEN CARR_TYP_DESC = ''Manual''
            THEN
                ''Leftover''                  ------SB : US101354 - New Enhancement
            ELSE
                ''Error''
        END             AS PLSRV_DESC,
        PLN_TYP_DESC,
        ST_CD,
        SRVC_YR_NBR,
        SRVC_FROM_MO_NBR,
        BEN_TOT_AMT,
        BL_CNT,
        BEN_TOT_PD_AMT,
        BL_PD_CNT,
        CPT_CD,
        CLM_LOC_CD,
        CPT_CATGY_CD AS CATGY_CD,
        EC_UB92_IND,
        MED_PLSRV_DESC,
        CARR_TYP_DESC
        FROM BDR_DM.TEMP_PART_B_WGT_DTL
        WHERE MED_PLSRV_SET = 5),
    TEMP_PART_B_WGT_DTL_SET4 AS
    (
		SELECT /*+ materialize */
        CASE
            WHEN CPT_CATGY_CD IN
                     (''Ambulance'', ''DME'', ''Drugs'')
            THEN
                CPT_CATGY_CD
            WHEN     CPT_CATGY_CD IN
                         (''ASC'', ''Unknown'')
                 AND CARR_TYP_DESC = ''DMERC''
            THEN
                ''Leftover DMERC''
            WHEN     CPT_CATGY_CD = ''Therapy''
                 AND CARR_TYP_DESC IN
                         (''DMERC'', ''Professional'')
            THEN
                ''Therapy EC''
			WHEN     CPT_CATGY_CD = ''Therapy''
                 AND CARR_TYP_DESC = ''Manual''
            THEN
                ''Therapy Manual''            ------SB : US101354 - New Enhancement
            WHEN     CPT_CATGY_CD = ''Therapy''
                 AND CARR_TYP_DESC = ''Institutional''
            THEN
                ''Therapy FEK''
            WHEN     CPT_CATGY_CD IN
                         (''ASC'', ''Unknown'')
                 AND CARR_TYP_DESC = ''Institutional''
            THEN
                ''OPPS''
            WHEN     CPT_CATGY_CD = ''ASC''
                 AND CARR_TYP_DESC IN (''Professional'',''Manual'')
            THEN
                ''ASC''                       ------SB : US101354 - New Enhancement
            WHEN     CPT_CATGY_CD = ''Unknown''
                 AND CARR_TYP_DESC = ''Professional''
            THEN
                ''Physician''

            WHEN CARR_TYP_DESC = ''Unknown''
            THEN
                ''Unknown Carrier Code''
			WHEN CARR_TYP_DESC = ''Manual''
            THEN
                ''Leftover''                  ------SB : US101354 - New Enhancement
            ELSE
                ''Error''
        END    AS PLSRV_DESC,
        PLN_TYP_DESC,
        ST_CD,
        SRVC_YR_NBR,
        SRVC_FROM_MO_NBR,
        BEN_TOT_AMT,
        BL_CNT,
        BEN_TOT_PD_AMT,
        BL_PD_CNT,
        CPT_CD,
        CLM_LOC_CD,
        CPT_CATGY_CD,
        EC_UB92_IND,
        MED_PLSRV_DESC,
        CARR_TYP_DESC
        FROM BDR_DM.TEMP_PART_B_WGT_DTL
        WHERE MED_PLSRV_SET = 4),
    TEMP_PART_B_WGT_DTL_SET4_NEW AS
    (
		SELECT ''Physician'' AS PLSRV_DESC,
			PLN_TYP_DESC,
			ST_CD,
			SRVC_YR_NBR,
			SRVC_FROM_MO_NBR,
			BEN_TOT_AMT * (1 - :V_BEN_AMT_MULVALUE)
			AS BEN_TOT_AMT_NEW, 0
			AS BL_CNT, -- bl_cnt will be counted in ASC bucket
			BEN_TOT_PD_AMT * (1 - :V_BEN_AMT_MULVALUE)
			AS BEN_TOT_PD_AMT_NEW, 0
			AS BL_PD_CNT, -- bl_pd_cnt will be counted in ASC bucket
			CPT_CD,
			CLM_LOC_CD,
			CPT_CATGY_CD,
			EC_UB92_IND,
			MED_PLSRV_DESC,
			CARR_TYP_DESC
        FROM TEMP_PART_B_WGT_DTL_SET4
        WHERE PLSRV_DESC = ''ASC''
        UNION
        SELECT PLSRV_DESC,
			PLN_TYP_DESC,
			ST_CD,
			SRVC_YR_NBR,
			SRVC_FROM_MO_NBR,
			BEN_TOT_AMT * (:V_BEN_AMT_MULVALUE)
				AS BEN_TOT_AMT_ASC,
			BL_CNT,
			BEN_TOT_PD_AMT * (:V_BEN_AMT_MULVALUE)
				AS BEN_TOT_PD_AMT_ASC,
			BL_PD_CNT,
			CPT_CD,
			CLM_LOC_CD,
			CPT_CATGY_CD,
			EC_UB92_IND,
			MED_PLSRV_DESC,
			CARR_TYP_DESC
        FROM TEMP_PART_B_WGT_DTL_SET4
        WHERE PLSRV_DESC = ''ASC''
        UNION
        SELECT PLSRV_DESC,
            PLN_TYP_DESC,
            ST_CD,
            SRVC_YR_NBR,
            SRVC_FROM_MO_NBR,
            BEN_TOT_AMT,
            BL_CNT,
            BEN_TOT_PD_AMT,
            BL_PD_CNT,
            CPT_CD,
            CLM_LOC_CD,
            CPT_CATGY_CD,
            EC_UB92_IND,
            MED_PLSRV_DESC,
            CARR_TYP_DESC
        FROM TEMP_PART_B_WGT_DTL_SET4
        WHERE PLSRV_DESC <> ''ASC''),
    TEMP_PART_B_WGT_DTL_FINAL AS
    (
		SELECT /*+ materialize */
        CASE
            WHEN PLSRV_DESC IN
                     (''Leftover DMERC'', ''DME'')
            THEN
                ''DME''
            WHEN PLSRV_DESC IN (''Therapy EC'')
            THEN
                ''Therapy Carrier''
            WHEN PLSRV_DESC IN
                     (''Therapy FEK'', ''Therapy Manual'')
            THEN
                ''Therapy Intermediary''
            ELSE
                PLSRV_DESC
        END          AS PLSRV_2_DESC,
        PLN_TYP_DESC,
        ST_CD,
        SRVC_YR_NBR,
        SRVC_FROM_MO_NBR,
        BEN_TOT_AMT,
        BL_CNT,
        BEN_TOT_PD_AMT,
        BL_PD_CNT,
        CPT_CD,
        PLSRV_DESC,
        CLM_LOC_CD,
        CPT_CATGY_CD,
        EC_UB92_IND,
        MED_PLSRV_DESC,
        CARR_TYP_DESC,
        :V_BATCH_ID AS ETL_LST_BTCH_ID
        FROM (SELECT * FROM TEMP_PART_B_WGT_DTL_SET1
              UNION ALL
              SELECT * FROM TEMP_PART_B_WGT_DTL_SET2
              UNION ALL
              SELECT * FROM TEMP_PART_B_WGT_DTL_SET3
              UNION ALL
              SELECT * FROM TEMP_PART_B_WGT_DTL_SET4_NEW
              UNION ALL
              SELECT * FROM TEMP_PART_B_WGT_DTL_SET5
              UNION ALL
              SELECT * FROM TEMP_PART_B_WGT_DTL_SET6))
    SELECT /*+ parallel(8) */
        PLSRV_2_DESC,
        PLN_TYP_DESC,
        ST_CD,
        SRVC_YR_NBR,
        SRVC_FROM_MO_NBR,
        SUM (BEN_TOT_AMT),
        SUM (BL_CNT),
        SUM (BEN_TOT_PD_AMT),
        SUM (BL_PD_CNT),
        CPT_CD,
        PLSRV_DESC,
        CLM_LOC_CD,
        CPT_CATGY_CD,
        EC_UB92_IND,
        MED_PLSRV_DESC,
        CARR_TYP_DESC,
        ETL_LST_BTCH_ID
    FROM TEMP_PART_B_WGT_DTL_FINAL
    GROUP BY PLSRV_2_DESC,
             PLN_TYP_DESC,
             ST_CD,
             SRVC_YR_NBR,
             SRVC_FROM_MO_NBR,
             CPT_CD,
             PLSRV_DESC,
             CLM_LOC_CD,
             CPT_CATGY_CD,
             EC_UB92_IND,
             MED_PLSRV_DESC,
             CARR_TYP_DESC,
             ETL_LST_BTCH_ID
    ORDER BY SRVC_YR_NBR,
             SRVC_FROM_MO_NBR,
             PLN_TYP_DESC,
             PLSRV_2_DESC,
             ST_CD;
	
	V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

	V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

	INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
	VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );
	
--COMMENTED BY OAS--
/*
    V_ROWS_AFFTD := SQL%ROWCOUNT;

    COMMIT;

    INSERT INTO ETL.ETL_DETAIL_LOAD_INFO (APPLICATION,
                                          ETL_BATCH_ID,
                                          ETL_PROC_NAME,
                                          ACTION,
                                          STEP_INFO,
                                          ROWS_AFFECTED,
                                          ETL_DATETIME)
         VALUES (''PARTB'',
                 V_BTCH_ID,
                 V_PROC_NAME,
                 ''INSERT'',
                 ''Insert into R_PART_B_WGT_DTL'',
                 V_ROWS_AFFTD,
                 SYSTIMESTAMP);

    COMMIT;

    V_ROWS_AFFTD := SQL%ROWCOUNT;
*/
--COMMENTED BY OAS--
------SB : US101354 - New Enhancement -------Start

V_STEP_NAME    := ''MERGE - R_PART_B_WGT_DTL'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;


MERGE   /*+ ENABLE_PARALLEL_DML */
INTO    BDR_DM.R_PART_B_WGT_DTL TGT
USING   (
	SELECT 	--ROWID,
	R_PART_B_WGT_DTL_SK,	--OAS ADD
	CASE WHEN PLSRV_2_DESC = ''Error'' AND CATGY_CD = ''Therapy'' THEN ''Therapy Manual''
	     WHEN PLSRV_2_DESC = ''Error'' AND MED_PLSRV_DESC = ''11Office'' THEN ''Physician''
	     WHEN PLSRV_2_DESC = ''Error'' AND SUBSTR(MED_PLSRV_DESC,1,2) IN (''21'',''22'') AND CATGY_CD = ''Unknown'' THEN ''OPPS''
	     WHEN PLSRV_2_DESC = ''Error'' AND SUBSTR(MED_PLSRV_DESC,1,2) IN (''21'',''22'') AND CATGY_CD <> ''Unknown'' THEN ''Physician''
	     WHEN PLSRV_2_DESC = ''Error'' AND CATGY_CD IN (''ASC'',''Unknown'') AND SUBSTR(MED_PLSRV_DESC,1,2) = ''24'' THEN ''ASC''
	     WHEN PLSRV_2_DESC = ''Error'' AND SUBSTR(MED_PLSRV_DESC,1,2) = ''65'' THEN ''Dialysis''
	     ELSE ''Leftover''
	     END DERIVED_PLSRV_2_DESC
	FROM 	BDR_DM.R_PART_B_WGT_DTL
	WHERE 	PLSRV_2_DESC = ''Error''
	) SRC
--ON      (SRC.ROWID = TGT.ROWID)							--OAS DELETE
ON (SRC.R_PART_B_WGT_DTL_SK = TGT.R_PART_B_WGT_DTL_SK)		--OAS ADD
WHEN MATCHED THEN UPDATE
SET TGT.PLSRV_2_DESC = SRC.DERIVED_PLSRV_2_DESC;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME) VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );
--COMMENTED	BY OAS--
/*           V_ROWS_AFFTD := SQL%ROWCOUNT;

            COMMIT;

            INSERT INTO ETL.ETL_DETAIL_LOAD_INFO (APPLICATION,
                                                  ETL_BATCH_ID,
                                                  ETL_PROC_NAME,
                                                  ACTION,
                                                  STEP_INFO,
                                                  ROWS_AFFECTED,
                                                  ETL_DATETIME)
                 VALUES (''PARTB'',
                         V_BTCH_ID,
                         V_PROC_NAME,
                         ''UPDATE'',
                         ''UPDATE R_PART_B_WGT_DTL for Error Bucket'',
                         V_ROWS_AFFTD,
                         SYSTIMESTAMP);

            COMMIT;

------SB : US101354 - New Enhancement -------End

            INSERT INTO ETL.ETL_DETAIL_LOAD_INFO (APPLICATION,
                                                  ETL_BATCH_ID,
                                                  ETL_PROC_NAME,
                                                  ACTION,
                                                  STEP_INFO,
                                                  ROWS_AFFECTED,
                                                  ETL_DATETIME)
                 VALUES (''PARTB'',
                         V_BTCH_ID,
                         V_PROC_NAME,
                         ''END'',
                         ''PROCEDURE ENDS'',
                         V_ROWS_AFFTD,
                         SYSTIMESTAMP);

            COMMIT;

            --Returns the result set
            P_ToContinueStatus := ''Y'';
            P_ErrorYNFlg := ''N'';
            P_ErrorStr := '''';*/
        /*EXCEPTION
           WHEN OTHERS
           THEN
              P_ErrorStr :=
                    ''ERROR: ''
                 || SQLCODE
                 || ''-''
                 || SQLERRM
                 || ''-''
                 || DBMS_UTILITY.FORMAT_ERROR_STACK ();
              P_ToContinueStatus := ''N'';
              P_ErrorYNFlg := ''Y'';
              ROLLBACK;
              */
--        END;
--    END IF;
--COMMENTED	BY OAS--


CALL UTIL.SP_ETL_CHECK_CONSTRAINTS(:DB_NAME , :APPLICATION , :WORKFLOW_NAME , :OBJECT_NAME , :V_BATCH_ID );		---------OAS ADD


UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''COMPLETE'', ERROR_MSG = null, BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
;
UPDATE  UTIL.ETL_BATCH_OBJECT_INCR_VALU SET INCR_COLUMN_VALUE = :V_BATCH_ID, LST_MOD_DT = CURRENT_TIMESTAMP() 
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID''
;

EXCEPTION

WHEN OTHER THEN

UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''ERROR'', ERROR_MSG = :SQLERRM,  BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
;

INSERT INTO  UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ERROR_MSG, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''ERROR'', :V_STEP_NAME, :V_STEP_SEQ, :SQLERRM, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() )
;



RAISE;

END;

';