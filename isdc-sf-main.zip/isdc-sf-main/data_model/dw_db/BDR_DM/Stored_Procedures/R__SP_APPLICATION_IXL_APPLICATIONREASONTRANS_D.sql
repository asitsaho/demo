USE SCHEMA BDR_DM; CREATE OR REPLACE PROCEDURE "SP_APPLICATION_IXL_APPLICATIONREASONTRANS_D"("DB_NAME" VARCHAR(16777216), "APPLICATION" VARCHAR(16777216), "WORKFLOW_NAME" VARCHAR(16777216), "OBJECT_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '

-- Original workflow: wkf_Application_IXL_TargetLoad_D
-- Original mapping: m_Application_IXL_ApplicationReasonTrans_D
-- Original folder: Application
-- Original filename: wkf_Application_IXL_TargetLoad_D.XML

DECLARE


V_ROWS_INSERTED  INTEGER;
V_ROWS_UPDATED INTEGER;
V_ROWS_DELETED INTEGER;
V_LAST_QUERY_ID VARCHAR;

V_WH VARCHAR;
V_BATCH_ID INTEGER;


V_BATCH_OBJECT_START_TIME        VARCHAR;
V_STEP_START_TIME    VARCHAR;
V_STEP_NAME VARCHAR;
V_STEP_SEQ INTEGER DEFAULT 0;
V_ETL_LST_BTCH_ID INTEGER;

V_MP_APPL_APPLICATION VARCHAR;
V_MP_MetadataType VARCHAR;
V_MP_MetadataDesc VARCHAR;
V_MP_CDC_APPLICATION VARCHAR;

BEGIN

EXECUTE IMMEDIATE ''USE DATABASE ''||:DB_NAME; 

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_BATCH_OBJECT_START_TIME := (SELECT CURRENT_TIMESTAMP());



LET res1 RESULTSET := 
(

SELECT 

WH ,
BATCH_ID
  
FROM UTIL.ETL_BATCH_OBJECT_CONTROL
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
FETCH FIRST 1 ROW ONLY

)
;


LET C1 CURSOR FOR res1;
open C1;
FETCH C1 into  V_WH,V_BATCH_ID ;
close C1;







EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:V_WH;
USE SCHEMA BDR_DM;	--OAS ADD--


INSERT INTO UTIL.ETL_BATCH_OBJECT_INCR_VALU (APPLICATION, WORKFLOW_NAME, OBJECT_NAME, INCR_COLUMN, INCR_COLUMN_VALUE )
SELECT * FROM (select :APPLICATION AS APPLICATION, :WORKFLOW_NAME AS WORKFLOW_NAME, :OBJECT_NAME AS OBJECT_NAME, ''ETL_LST_BTCH_ID'' AS INCR_COLUMN, -1 AS INCR_COLUMN_VALUE) A
WHERE NOT EXISTS (SELECT 1 FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU B WHERE B.APPLICATION = A.APPLICATION AND B.WORKFLOW_NAME = A.WORKFLOW_NAME AND B.OBJECT_NAME = A.OBJECT_NAME AND B.INCR_COLUMN = A.INCR_COLUMN)
;

V_ETL_LST_BTCH_ID :=(SELECT INCR_COLUMN_VALUE FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID'');


-- Component LKP_GETBATCHID, Type Prerequisite Lookup Object 
--COMMENTED BY OAS--
/* CREATE OR REPLACE TEMPORARY TABLE LKP_GETBATCHID AS
(
SELECT MAX(BATCH_ID) AS BATCH_ID ,APPLICATION AS APPLICATION FROM UTIL.ETL_BATCH_LOG WHERE  BATCH_STATUS=''COMPLETE'' GROUP BY APPLICATION
); */
--COMMENTED BY OAS--


-- PIPELINE START FOR 1

--COMMENTED BY OAS as it is just creating a DUMMY target--

-- Component sq_F_APPL_RSN_TRANS_DAY_InitialRecordCheck, Type SOURCE 
/*
CREATE OR REPLACE TEMPORARY TABLE sq_F_APPL_RSN_TRANS_DAY_InitialRecordCheck AS
(
SELECT SRC.*, row_number() over (order by 1) AS source_record_id FROM (
SELECT nvl((SELECT 1 as Record_Check
  FROM (SELECT 1 FROM BDR_DM.F_APPL_RSN_TRANS_DAY ORDER BY appl_id )
 limit 1),0) as Record_Check
 ,''UTIL'' as ETL_Schema
 from dual
) SRC
);


-- Component exp_GetApplicationInitial, Type EXPRESSION 
CREATE OR REPLACE TEMPORARY TABLE exp_GetApplicationInitial AS
(
SELECT
sq_F_APPL_RSN_TRANS_DAY_InitialRecordCheck.Record_Check as Record_Check,
sq_F_APPL_RSN_TRANS_DAY_InitialRecordCheck.ETL_Schema as ETL_Schema,
:V_MP_APPL_APPLICATION as out_Application,
:V_MP_MetadataType as out_MetadataType,
:V_MP_MetadataDesc as out_MetadataDesc,
:V_MP_CDC_APPLICATION as out_LastBatchIDApplication,
sq_F_APPL_RSN_TRANS_DAY_InitialRecordCheck.source_record_id
FROM
sq_F_APPL_RSN_TRANS_DAY_InitialRecordCheck
);


-- Component fil_Record_Check_Initial, Type FILTER 
CREATE OR REPLACE TEMPORARY TABLE fil_Record_Check_Initial AS
(
SELECT
exp_GetApplicationInitial.Record_Check as Record_Check,
exp_GetApplicationInitial.ETL_Schema as ETL_Schema,
exp_GetApplicationInitial.out_Application as Application,
exp_GetApplicationInitial.out_MetadataType as MetadataType,
exp_GetApplicationInitial.out_LastBatchIDApplication as LastBatchIDApplication,
exp_GetApplicationInitial.out_MetadataDesc as MetadataDesc,
exp_GetApplicationInitial.source_record_id
FROM
exp_GetApplicationInitial
WHERE exp_GetApplicationInitial.Record_Check = 0
);

----COMMENTED BY OAS----
--// ******** No handler defined for type SQL_TRANSFORM, node sql_UpdateApplicationMetadataInitial *******
-- update ~ETL_Schema~.ETL_APPLICATION_METADATA
-- set METADATA_VALUE=-1
-- where  APPLICATION=''~Application~'' and METADATA_TYPE=''~MetadataType~'' and METADATA_DESC=''~MetadataDesc~'';
--COMMIT;
----COMMENTED BY OAS----

V_STEP_NAME := ''UPDATE ETL_APPLICATION_METADATA''; 
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;

update UTIL.ETL_APPLICATION_METADATA
set METADATA_VALUE=-1
from fil_Record_Check_Initial 
where UTIL.ETL_APPLICATION_METADATA.APPLICATION = fil_Record_Check_Initial.Application 
and UTIL.ETL_APPLICATION_METADATA.METADATA_TYPE = fil_Record_Check_Initial.MetadataType 
and UTIL.ETL_APPLICATION_METADATA.METADATA_DESC = fil_Record_Check_Initial.MetadataDesc;
 
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );


INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

-- Component sc_ff_Dynamic_OutputInitial, Type TARGET_EXPORT_PREPARE Stage data before exporting
--CREATE OR REPLACE TEMPORARY TABLE sc_ff_Dynamic_OutputInitial AS
--(
--SELECT
--sql_UpdateApplicationMetadataInitial.MetadataType_output /* OutputColumn */--,
--sql_UpdateApplicationMetadataInitial.Application_output /* FileName */
--FROM
--sql_UpdateApplicationMetadataInitial
--);


-- Component sc_ff_Dynamic_OutputInitial, Type EXPORT_DATA Exporting data

--COMMENTED BY OAS as it is just creating a DUMMY target--

-- PIPELINE END FOR 1

-- PIPELINE START FOR 2


--pre node line TARGET for sc_tgt_F_APPL_RSN_TRANS_DAY
V_STEP_NAME    := ''TARGET - INSERT F_APPL_RSN_TRANS_DAY'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

-- Component sq_Application_Reason, Type SOURCE 
CREATE OR REPLACE TEMPORARY TABLE sq_Application_Reason AS
(
SELECT SRC.*, row_number() over (order by 1) AS source_record_id FROM (
select
SRC.APPLICATION_ID,
SRC.ActivityDateID,
SRC.D_ADJD_CD_SK,
SRC.ApplReasonSKey,
SRC.ReceivedQty,
SRC.PendingQty,
SRC.AcceptedQty,
SRC.DeniedQty,
SRC.WithdrawnQty,
SRC.SourceETLBatchID,
CASE WHEN f_appl_rsn_trans_day.APPL_ID is null and f_appl_rsn_trans_day.D_APPL_RSN_SK is null and f_appl_rsn_trans_day.D_ADJD_CD_SK is null
     THEN
     ''INSERT''
     ELSE
     ''REJECT''
END AS ACTION from(
SELECT S.Application_ID as APPLICATION_ID,
to_char((CURRENT_DATE-1),''YYYYMMDD'') AS ActivityDateID ,
NVL(AC.D_ADJD_CD_SK,-1) AS D_ADJD_CD_SK,
 NVL(AR1.D_APPL_RSN_SK,-1) as ApplReasonSKey,
1 AS ReceivedQty,
CASE WHEN S.Adjudication_CD = ''P'' THEN 1 ELSE 0 END AS PendingQty,
CASE WHEN S.Adjudication_CD = ''A'' THEN 1 ELSE 0 END AS AcceptedQty,
CASE WHEN S.Adjudication_CD = ''D'' THEN 1 ELSE 0 END AS DeniedQty,
CASE WHEN S.Adjudication_CD = ''W'' THEN 1 ELSE 0 END AS WithdrawnQty,
AR.ETL_LST_BTCH_ID as SourceETLBatchID
FROM SRC_COMPAS_D.Application_Reason AR
join SRC_COMPAS_D.Reason r on r.Reason_ID = ar.Reason_ID
join SRC_COMPAS_D.Reason_Type rt on rt.Reason_Type_ID = r.Reason_Type_ID
left outer join BDR_DM.D_APPL_RSN AR1 on ar1.RSN_ID = r.Reason_ID and AR1.RSN_TYP_ID = r.Reason_Type_ID 
LEFT OUTER JOIN SRC_COMPAS_D.Application S ON AR.Application_ID = S.Application_ID
LEFT OUTER JOIN BDR_DM.D_APPL_ADJD_CD AC ON S.Adjudication_CD = AC.ADJD_CD
WHERE  CAST(s.APPL_RECEIPT_DATE AS DATE) >= (SELECT DATEADD(''year'', -9,(trunc(CURRENT_DATE,''year'')))::TIMESTAMP as CutOffDate FROM DUAL)
--COMMENTED BY OAS--
/* AND AR.ETL_LST_BTCH_ID > (select METADATA_VALUE FROM UTIL.ETL_APPLICATION_METADATA WHERE 
APPLICATION=''APPLICATION'' AND METADATA_DESC=''F_APPL_RSN_TRANS_DAY'')*/
--COMMENTED BY OAS--
AND AR.ETL_LST_BTCH_ID > :V_ETL_LST_BTCH_ID )SRC  --OAS ADD
LEFT OUTER JOIN BDR_DM.f_appl_rsn_trans_day on
SRC.APPLICATION_ID=f_appl_rsn_trans_day.APPL_ID and
SRC.ApplReasonSKey=f_appl_rsn_trans_day.D_APPL_RSN_SK and
SRC.D_ADJD_CD_SK=f_appl_rsn_trans_day.D_ADJD_CD_SK
) SRC
);


-- Component exp_GetBtachId, Type EXPRESSION 
CREATE OR REPLACE TEMPORARY TABLE exp_GetBtachId AS
(
SELECT
sq_Application_Reason.APPLICATION_ID as APPLICATION_ID,
sq_Application_Reason.ActivityDateID as ActivityDateID,
sq_Application_Reason.D_ADJD_CD_SK as D_ADJD_CD_SK,
sq_Application_Reason.ApplReasonSKey as ApplReasonSKey,
sq_Application_Reason.ReceivedQty as ReceivedQty,
sq_Application_Reason.PendingQty as PendingQty,
sq_Application_Reason.AcceptedQty as AcceptedQty,
sq_Application_Reason.DeniedQty as DeniedQty,
sq_Application_Reason.WithdrawnQty as WithdrawnQty,
sq_Application_Reason.SourceETLBatchID as SourceETLBatchID,
--LKP_1.BATCH_ID /* replaced lookup LKP_GETBATCHID */ as out_lkp_ETL_BATCH_ID,	--OAS DELETE--
:V_BATCH_ID /* replaced lookup LKP_GETBATCHID */ as out_lkp_ETL_BATCH_ID,	--OAS ADD--
sq_Application_Reason.ACTION as ACTION,
sq_Application_Reason.source_record_id,
row_number() over (partition by sq_Application_Reason.source_record_id order by sq_Application_Reason.source_record_id) as RNK
FROM
sq_Application_Reason
--LEFT JOIN LKP_GETBATCHID LKP_1 ON LKP_1.APPLICATION = $MP_CONTROLLER_APPLICATION	--OAS DELETE--
QUALIFY row_number() over (partition by sq_Application_Reason.source_record_id order by sq_Application_Reason.source_record_id) = 1
);


-- Component fil_RejectRecords, Type FILTER 
CREATE OR REPLACE TEMPORARY TABLE fil_RejectRecords AS
(
SELECT
exp_GetBtachId.APPLICATION_ID as APPLICATION_ID,
exp_GetBtachId.ActivityDateID as ActivityDateID,
exp_GetBtachId.D_ADJD_CD_SK as D_ADJD_CD_SK,
exp_GetBtachId.ApplReasonSKey as ApplReasonSKey,
exp_GetBtachId.ReceivedQty as ReceivedQty,
exp_GetBtachId.PendingQty as PendingQty,
exp_GetBtachId.AcceptedQty as AcceptedQty,
exp_GetBtachId.DeniedQty as DeniedQty,
exp_GetBtachId.WithdrawnQty as WithdrawnQty,
exp_GetBtachId.SourceETLBatchID as SourceETLBatchID,
exp_GetBtachId.out_lkp_ETL_BATCH_ID as out_lkp_ETL_BATCH_ID,
exp_GetBtachId.ACTION as ACTION,
exp_GetBtachId.source_record_id
FROM
exp_GetBtachId
WHERE exp_GetBtachId.ACTION = ''INSERT''
);




-- Component sc_tgt_F_APPL_RSN_TRANS_DAY, Type TARGET 
INSERT INTO BDR_DM.F_APPL_RSN_TRANS_DAY
(
APPL_ID,
ACTV_DT_ID,
D_ADJD_CD_SK,
D_APPL_RSN_SK,
RECV_QTY,
PND_QTY,
ACPT_QTY,
DENY_QTY,
WTHDR_QTY,
SRC_ETL_BTCH_ID,
ETL_LST_BTCH_ID
)
SELECT
fil_RejectRecords.APPLICATION_ID /* APPL_ID */,
fil_RejectRecords.ActivityDateID /* ACTV_DT_ID */,
fil_RejectRecords.D_ADJD_CD_SK /* D_ADJD_CD_SK */,
fil_RejectRecords.ApplReasonSKey /* D_APPL_RSN_SK */,
fil_RejectRecords.ReceivedQty /* RECV_QTY */,
fil_RejectRecords.PendingQty /* PND_QTY */,
fil_RejectRecords.AcceptedQty /* ACPT_QTY */,
fil_RejectRecords.DeniedQty /* DENY_QTY */,
fil_RejectRecords.WithdrawnQty /* WTHDR_QTY */,
fil_RejectRecords.SourceETLBatchID /* SRC_ETL_BTCH_ID */,
fil_RejectRecords.out_lkp_ETL_BATCH_ID /* ETL_LST_BTCH_ID */
FROM
fil_RejectRecords;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );


INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );


-- PIPELINE END FOR 2
-- Component sc_tgt_F_APPL_RSN_TRANS_DAY, Type Post SQL 
--CALL $Param_DMSchema.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''$Param_DMSchema'',''F_APPL_RSN_TRANS_DAY'');	--OAS DELETE--


-- PIPELINE START FOR 3

--COMMENTED BY OAS as it is just creating a DUMMY target--

-- Component sq_F_APPL_RSN_TRANS_DAY_RecordCheckFinal, Type SOURCE 
/*
CREATE OR REPLACE TEMPORARY TABLE sq_F_APPL_RSN_TRANS_DAY_RecordCheckFinal AS
(
SELECT SRC.*, row_number() over (order by 1) AS source_record_id FROM (
SELECT nvl((SELECT 1 as Record_Check
  FROM (SELECT 1 FROM BDR_DM.F_APPL_RSN_TRANS_DAY ORDER BY appl_id )
 order by 1 limit 1),0) as Record_Check
 ,''UTIL'' as ETL_Schema
 from dual
) SRC
);


-- Component exp_GetApplicationFinal, Type EXPRESSION 
CREATE OR REPLACE TEMPORARY TABLE exp_GetApplicationFinal AS
(
SELECT
sq_F_APPL_RSN_TRANS_DAY_RecordCheckFinal.Record_Check as Record_Check,
sq_F_APPL_RSN_TRANS_DAY_RecordCheckFinal.ETL_Schema as ETL_Schema,
:V_MP_APPL_APPLICATION as out_Application,
:V_MP_MetadataType as out_MetadataType,
:V_MP_MetadataDesc as out_MetadataDesc,
:V_MP_CDC_APPLICATION as out_LastBatchIDApplication,
sq_F_APPL_RSN_TRANS_DAY_RecordCheckFinal.source_record_id
FROM
sq_F_APPL_RSN_TRANS_DAY_RecordCheckFinal
);


-- Component fil_Record_Check_Final, Type FILTER 
CREATE OR REPLACE TEMPORARY TABLE fil_Record_Check_Final AS
(
SELECT
exp_GetApplicationFinal.Record_Check as Record_Check,
exp_GetApplicationFinal.ETL_Schema as ETL_Schema,
exp_GetApplicationFinal.out_Application as Application,
exp_GetApplicationFinal.out_MetadataType as MetadataType,
exp_GetApplicationFinal.out_LastBatchIDApplication as LastBatchIDApplication,
exp_GetApplicationFinal.out_MetadataDesc as MetadataDesc,
exp_GetApplicationFinal.source_record_id
FROM
exp_GetApplicationFinal
WHERE exp_GetApplicationFinal.Record_Check = 1
);

---COMMENTED BY OAS---
--// ******** No handler defined for type SQL_TRANSFORM, node sql_UpdateApplicationMetadataFinal *******
/* update ~ETL_Schema~.ETL_APPLICATION_METADATA 
set METADATA_VALUE=( select max(BATCH_ID) from ~ETL_Schema~.ETL_BATCH_LOG where APPLICATION=''~LastBatchIDApplication~'' and BATCH_STATUS =''COMPLETE'' )
 where  APPLICATION=''~Application~'' and METADATA_TYPE=''~MetadataType~'' and METADATA_DESC=''~MetadataDesc~'';
COMMIT; */
---COMMENTED BY OAS---

/*
V_STEP_NAME := ''UPDATE ETL_APPLICATION_METADATA''; 
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;


update UTIL.ETL_APPLICATION_METADATA 
set METADATA_VALUE = :V_BATCH_ID -- ( select max(BATCH_ID) from :V_ETL_Schema.ETL_BATCH_LOG where APPLICATION='':V_Application'' and BATCH_STATUS =''COMPLETE'' )
from fil_Record_Check_Final 
 where UTIL.ETL_APPLICATION_METADATA.APPLICATION = fil_Record_Check_Final.Application
 and UTIL.ETL_APPLICATION_METADATA.METADATA_TYPE = fil_Record_Check_Final.MetadataType
 and UTIL.ETL_APPLICATION_METADATA.METADATA_DESC = fil_Record_Check_Final.MetadataDesc;

 
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) )


INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );


-- Component sc_ff_Dynamic_OutputFinal, Type TARGET_EXPORT_PREPARE Stage data before exporting
CREATE OR REPLACE TEMPORARY TABLE sc_ff_Dynamic_OutputFinal AS
(
SELECT*/
--sql_UpdateApplicationMetadataFinal.MetadataType_output /* OutputColumn */--,
--sql_UpdateApplicationMetadataFinal.Application_output /* FileName */
/*FROM
sql_UpdateApplicationMetadataFinal
);
 */

-- Component sc_ff_Dynamic_OutputFinal, Type EXPORT_DATA Exporting data

--COMMENTED BY OAS as it is just creating a DUMMY target--

-- PIPELINE END FOR 3

CALL UTIL.SP_ETL_CHECK_CONSTRAINTS(:DB_NAME , :APPLICATION , :WORKFLOW_NAME , :OBJECT_NAME , :V_BATCH_ID );

UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''COMPLETE'', ERROR_MSG = null, BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
;
UPDATE  UTIL.ETL_BATCH_OBJECT_INCR_VALU SET INCR_COLUMN_VALUE = :V_BATCH_ID, LST_MOD_DT = CURRENT_TIMESTAMP() 
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID''
;

EXCEPTION

WHEN OTHER THEN

UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''ERROR'', ERROR_MSG = :SQLERRM,  BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
;

INSERT INTO  UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ERROR_MSG, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''ERROR'', :V_STEP_NAME, :V_STEP_SEQ, :SQLERRM, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() )
;



RAISE;

END;

';