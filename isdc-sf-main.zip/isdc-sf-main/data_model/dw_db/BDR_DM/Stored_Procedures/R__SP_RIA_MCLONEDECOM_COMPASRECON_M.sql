USE SCHEMA BDR_DM;
CREATE OR REPLACE PROCEDURE "SP_RIA_MCLONEDECOM_COMPASRECON_M"("DB_NAME" VARCHAR(16777216), "APPLICATION" VARCHAR(16777216), "WORKFLOW_NAME" VARCHAR(16777216), "OBJECT_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '

-- Original workflow: wkf_RIA_MCloneDecom_CompasRecon_M
-- Original mapping: m_RIA_MCloneDecom_CompasRecon_M
-- Original folder: Compas_Reports

DECLARE


V_ROWS_INSERTED  INTEGER;
V_ROWS_UPDATED INTEGER;
V_ROWS_DELETED INTEGER;
V_LAST_QUERY_ID VARCHAR;

V_WH VARCHAR;
V_BATCH_ID INTEGER;


V_BATCH_OBJECT_START_TIME         VARCHAR;
V_STEP_START_TIME    VARCHAR;
V_STEP_NAME VARCHAR;
V_STEP_SEQ INTEGER DEFAULT 0;
V_ETL_LST_BTCH_ID INTEGER;

g_retro_date TIMESTAMP := TO_TIMESTAMP(''01-Jan-2002'',''dd-mon-yyyy'');

v_report_date				TIMESTAMP;
v_report_start				TIMESTAMP;
v_report_end				TIMESTAMP;
V_DAY						INTEGER;

v_lockbox_tot_amt        	NUMBER(38,2);
v_eft_tot_amt   		 	NUMBER(38,2);
v_enrollment_tot_amt   		NUMBER(38,2);
v_checkfree_tot_amt   		NUMBER(38,2);
v_auto_credit_tot_amt 		NUMBER(38,2);

v_online_credit_tot_amt     NUMBER(38,2);
v_online_check_tot_amt      NUMBER(38,2);
v_online_wire_tot_amt   	NUMBER(38,2);
v_online_misc_tot_amt   	NUMBER(38,2);

v_waiver_tot_amt            NUMBER(38,2);
v_prorated_credit_tot_amt   NUMBER(38,2);

v_refund					NUMBER(38,2);
V_SRC_CUST_ID				VARCHAR;

v_returns_tot_amt			NUMBER(38,2);

v_eft_protest				NUMBER(38,2);

v_miscloss_tot_amt			NUMBER(38,2);
v_retrodebit_tot_amt		NUMBER(38,2);

v_proratedloss_tot_amt		NUMBER(38,2);

v_claims_tot				NUMBER(38,2);

v_unclaimed_tot_amt			NUMBER(38,2);

v_amount					NUMBER(38,2);

v_pdp_amt					NUMBER(38,2);



BEGIN

EXECUTE IMMEDIATE ''USE DATABASE ''||:DB_NAME; 

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_BATCH_OBJECT_START_TIME := (SELECT CURRENT_TIMESTAMP());



LET res1 RESULTSET := 
(

SELECT 

WH ,
BATCH_ID
  
FROM UTIL.ETL_BATCH_OBJECT_CONTROL
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
FETCH FIRST 1 ROW ONLY

)
;


LET C1 CURSOR FOR res1;
open C1;
FETCH C1 into  V_WH,V_BATCH_ID ;
close C1;


LET res2 RESULTSET := 

(

WITH PARAMETERS (DAY, SRC_CUST_ID) AS
(
  
SELECT * 
FROM  
(SELECT PARAMETER_NAME, PARAMETER_VALUE  FROM UTIL.ETL_OBJECT_PARAMETER_VALUE 
WHERE 1 = 1
AND APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
AND ACTIVE_FLG = ''Y''  
  
UNION ALL       

SELECT PARAMETER_NAME, PARAMETER_VALUE  FROM UTIL.ETL_GLOBAL_PARAMETER_VALUE WHERE PAR_GLOBAL_TYPE = ''PARGLOBAL_OPREPORTS'' AND ACTIVE_FLG = ''Y''
AND PARAMETER_NAME NOT IN  (
SELECT PARAMETER_NAME  FROM UTIL.ETL_OBJECT_PARAMETER_VALUE WHERE 1 = 1
AND APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
AND ACTIVE_FLG = ''Y''   ))
 
PIVOT(MAX(PARAMETER_VALUE) FOR PARAMETER_NAME IN (''DAY'', ''SRC_CUST_ID'')) 

 
)  
SELECT * FROM PARAMETERS 
)   
;


LET C2 CURSOR FOR res2;
open C2;
FETCH C2 into V_DAY, V_SRC_CUST_ID; 
close C2;



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:V_WH;
USE SCHEMA BDR_DM;	------------OAS ADD


INSERT INTO UTIL.ETL_BATCH_OBJECT_INCR_VALU (APPLICATION, WORKFLOW_NAME, OBJECT_NAME, INCR_COLUMN, INCR_COLUMN_VALUE )
SELECT * FROM (select :APPLICATION AS APPLICATION, :WORKFLOW_NAME AS WORKFLOW_NAME, :OBJECT_NAME AS OBJECT_NAME, ''ETL_LST_BTCH_ID'' AS INCR_COLUMN, -1 AS INCR_COLUMN_VALUE) A
WHERE NOT EXISTS (SELECT 1 FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU B WHERE B.APPLICATION = A.APPLICATION AND B.WORKFLOW_NAME = A.WORKFLOW_NAME AND B.OBJECT_NAME = A.OBJECT_NAME AND B.INCR_COLUMN = A.INCR_COLUMN)
;

V_ETL_LST_BTCH_ID :=(SELECT INCR_COLUMN_VALUE FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID'');


						----------------CODE FOR MAIN PROCEDURE ETL.SP_ETL_MCLONE_DECOM_M BEGINS------------------------

--------COMMENTED BY OAS--------
/*
CREATE OR REPLACE PROCEDURE ETL."SP_ETL_MCLONE_DECOM_M"(
    p_etlname IN VARCHAR2,
    p_etlseq  IN NUMBER,
    p_tocontinuestatus OUT VARCHAR2,
    p_errorynflg OUT VARCHAR2,
    p_errorstr OUT VARCHAR2)
AS

BEGIN

		SELECT MIN(proc_launch_order)			------RESULT WILL BE 12
          INTO lv_min_order
          FROM ETL.ETL_MCLONE_DECOM_PROC_LIST
          WHERE etl_name = p_etlname	-----''COMPAS_RECON''
          AND etl_seq    = p_etlseq		-----1
          AND active_ind = ''Y'';
		

          SELECT MAX(proc_launch_order)		----------RESULT WILL BE 12
          INTO lv_max_order
          FROM ETL.ETL_MCLONE_DECOM_PROC_LIST
          WHERE etl_name = p_etlname	-----''COMPAS_RECON''
          AND etl_seq    = p_etlseq		-----1
          AND active_ind = ''Y'';

          SELECT MAX(batch_id)
          INTO lv_batch_id
          FROM etl.etl_batch_log
          WHERE application = ''COMPAS_REPORTS''
          AND batch_status != ''COMPLETE'';

          UPDATE ETL.ETL_MCLONE_DECOM_PROC_LIST
          SET batch_id   = lv_batch_id
          WHERE etl_name = p_etlname
          AND etl_seq    = p_etlseq
          AND active_ind = ''Y'';
          COMMIT;

          --Find Next Row to Process
          WHILE lv_min_order < (lv_max_order + 1 )		-----------12< 12+1 for 1st iteration --> TRUE,  13<12+1 for next iteration --> FALSE --- 
          LOOP

                    --dbms_output.put_line(''Min Loop Start'' || lv_min_order);
                    --dbms_output.put_line(''Max Loop Start'' || lv_max_order);

                    lv_next_rec_found      := ''Y'';

                    WHILE lv_next_rec_found = ''Y''
                    LOOP
                              BEGIN
                                      lv_proc_name := NULL;

                                      -- Get the Proc Name
                                      SELECT proc_name,
                                        batch_id		
                                      INTO lv_proc_name,	
                                        lv_batch_id
                                      FROM
                                        (SELECT proc_name,
                                          batch_id
                                        FROM ETL.ETL_MCLONE_DECOM_PROC_LIST
                                        WHERE run_status      in (''READY'',''ERROR'')
                                        AND proc_launch_order = lv_min_order	--------------12 
                                        AND active_ind = ''Y''
                                        )
                                      WHERE ROWNUM = 1;

                                      --Proc Found
                                      IF lv_proc_name IS NOT NULL THEN

                                                SELECT SYSDATE INTO lv_etl_start_time FROM dual;

                                                UPDATE ETL.ETL_MCLONE_DECOM_PROC_LIST
                                                SET run_status        = ''INPROCESS'',
                                                  etl_start_time      = lv_etl_start_time
                                                WHERE batch_id        = lv_batch_id
                                                AND proc_name         = lv_proc_name
                                                AND proc_launch_order = lv_min_order;

                                                --Continue, if no records updated
                                                lv_row_aff_by_upd   := SQL % rowcount;

                                                IF lv_row_aff_by_upd = 0 THEN
                                                  ROLLBACK;
                                                  CONTINUE;
                                                ELSE
                                                  COMMIT;
                                                END IF;
                                      END IF;

                                      --Execute Procedure
                                      BEGIN
                                                lv_proc_final := ''begin '' || lv_proc_name || '' end;'';

                                                EXECUTE IMMEDIATE (lv_proc_final);		-------OAS - IT WILL CALL COMPAS_MO.PKG_RIA_DAILY_RECON.PR_RECON();
*/
--------COMMENTED BY OAS--------

									------------- CODE FOR COMPAS_MO.PKG_RIA_DAILY_RECON.PR_RECON() BEGINS---------------

	--------COMMENTED BY OAS--------
	
	/*	
		PROCEDURE pr_recon
		IS

			CURSOR c IS SELECT create_time FROM COMPAS_MO.monthend_log
			ORDER BY create_time DESC;

			-- v_report_date   DATE := LAST_DAY(ADD_MONTHS(TRUNC(SYSDATE),-1));
			-- SCR  14625 and SCR 21908
			v_report_date      DATE := COMPAS_MO.fn_get_last_day_of_month;
			v_report_start  TIMESTAMP;
			v_report_end    TIMESTAMP;

		BEGIN


			OPEN c;
			FETCH c INTO v_report_end;

			/* Monthend_log is ordered by create_time desc therefore the 1st row is the
			current monthend time i.e. the report_end timestamp and the 2nd row is the
			last monthend time i.e. the report_start timestamp. Report date is the last
			day of the prior month  *//*

			IF c%NOTFOUND THEN
				RAISE NO_DATA_FOUND;
			END IF;

			FETCH c INTO v_report_start;

			IF c%NOTFOUND THEN
				RAISE NO_DATA_FOUND;
			END IF;

			CLOSE c;
	*/
	---------------COMMENTED BY OAS-----------------
			v_report_date := (SELECT TRUNC(TO_TIMESTAMP(CASE WHEN extract(day FROM CURRENT_TIMESTAMP) <= :V_DAY THEN
								LAST_DAY(ADD_MONTHS(CURRENT_TIMESTAMP, -1))
							ELSE
								LAST_DAY(CURRENT_TIMESTAMP) END), ''DD''));
								
v_report_start :=  (select to_timestamp(substr(max(timestamp_value),1,14),''YYYYMMDDHH24MISS'') from util.etl_extract_process_dates where application=''CDC_COMPAS'' and substr(timestamp_value,1,6) in 
(SELECT TO_CHAR(ADD_MONTHS(CURRENT_DATE, -2),''YYYYMM'') ) );
			
v_report_end := ( select to_timestamp(substr(max(timestamp_value),1,14),''YYYYMMDDHH24MISS'') from util.etl_extract_process_dates where application=''CDC_COMPAS'' and substr(timestamp_value,1,6) in 
(SELECT TO_CHAR(ADD_MONTHS(CURRENT_DATE, -1),''YYYYMM'') ) );

			--pr_recon2(v_report_date,v_report_start,v_report_end);
			
										------------- CODE FOR pr_recon2(); BEGINS---------------
		---------------COMMENTED BY OAS-----------------
		/*
		PROCEDURE pr_recon2 ( p_report_date  IN DATE ,
						 p_report_start IN timestamp,
						 p_report_end   IN timestamp )
		IS

		/*

		DECLARE
		p_report_date DATE  := ''31-Jul-2004'';
		p_report_start TIMESTAMP := TO_TIMESTAMP(''01-JUL-2004 00:13:06'',''DD-MON-YYYY HH24:MI:SS'');
		p_report_end   TIMESTAMP := TO_TIMESTAMP(''31-JUL-2004 17:42:41'',''DD-MON-YYYY HH24:MI:SS'');
		BEGIN
		PKG_RIA_DAILY_RECON.pr_recon(p_report_date , p_report_start , p_report_end );
		END;

		*//*

		v_report_date     DATE;
		v_procedure     VARCHAR2(50);

		BEGIN

			v_report_date := TRUNC(p_report_date);
			v_procedure := ''*** COMPAS RECONCILATION ***'';
	*/
	---------------COMMENTED BY OAS-----------------
		  
			V_STEP_NAME    := ''*** COMPAS RECONCILATION *** - DELETE - RIA_DAILY_RECON'';
			V_STEP_SEQ     := : v_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;
			
				DELETE FROM BDR_DM.RIA_DAILY_RECON WHERE report_date = :v_report_date;
						    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_DELETED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );
		  
		  
			V_STEP_NAME    := ''INSERT - daily_recon'';
			V_STEP_SEQ     := : v_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

				INSERT INTO BDR_DM.RIA_DAILY_RECON (report_date, report_start_date, report_end_date)
				VALUES      (:v_report_date, :v_report_start, :v_report_end);
			    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

		---------------COMMENTED BY OAS-----------------
		/*
			DELETE FROM COMPAS_MO.daily_recon_log WHERE report_date = v_report_date;

			COMMIT;

			pr_log_start(v_report_date,v_procedure);

			-- Lockbox, EFT, Checkfree, Enrollment, automated credit card
			sum_payments_AOP( v_report_date, p_report_start, p_report_end );
		*/
		---------------COMMENTED BY OAS-----------------
		
									------------- CODE FOR sum_payments_AOP BEGINS---------------
		  
			V_STEP_NAME    := ''sum_payments_AOP - UPDATE - RIA_DAILY_RECON'';
			V_STEP_SEQ     :=  V_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

				select /*+  parallel(PF)  parallel(TT) parallel(TS) */ SUM(LOCKBOX_TOTAL_AMT),SUM(ENROLLMENT_TOTAL_AMT),SUM(THIRDPARTY_TOTAL_AMT),SUM(EFT_TOTAL_AMT),SUM(AUTO_CREDIT_TOTAL_AMT)
				INTO v_lockbox_tot_amt,v_enrollment_tot_amt,v_checkfree_tot_amt,v_eft_tot_amt,v_auto_credit_tot_amt
				from
				(
				SELECT
							CASE WHEN TS.TNDR_SOURCE_TYPE_FLG = ''LOCK'' AND TT.GENERATE_APAY_SW=''NO'' AND TT.SRC_TNDR_TYPE_CD NOT IN (''TPRY'',''CCAP'',''WIRC'',''WIRS'',''CCAP'')
							AND TS.SRC_TNDR_SOURCE_CD NOT IN (''JPMTPP'',''JPMCC'',''TI_PDP'') AND TS.EXT_SOURCE_ID <> ''EXSIDCOMPAS''  THEN (NVL(PF.PAY_AMT,0)) Else 0 END as LOCKBOX_TOTAL_AMT,
							CASE WHEN TS.SRC_TNDR_SOURCE_CD = ''ENROLL'' AND TS.EXT_SOURCE_ID <> ''EXSIDCOMPAS''  THEN NVL(PF.PAY_AMT,0) 	Else 0 END as ENROLLMENT_TOTAL_AMT,
							CASE WHEN TT.SRC_TNDR_TYPE_CD IN (''TPRY'')  AND TS.SRC_TNDR_SOURCE_CD IN (''JPMTPP'') AND TS.EXT_SOURCE_ID <> ''EXSIDCOMPAS''  THEN NVL(PF.PAY_AMT,0)   Else 0  END as THIRDPARTY_TOTAL_AMT,
							CASE WHEN TT.GENERATE_APAY_SW = ''YES'' AND TT.SRC_TNDR_TYPE_CD NOT IN (''PENS'',''PENM'') AND TS.EXT_SOURCE_ID <> ''EXSIDCOMPAS''  THEN NVL(PF.PAY_AMT,0)   Else 0  END as EFT_TOTAL_AMT,
							CASE WHEN TT.SRC_TNDR_TYPE_CD IN (''CCAP'') AND TS.SRC_TNDR_SOURCE_CD IN (''JPMCC'') AND TS.EXT_SOURCE_ID <> ''EXSIDCOMPAS''   THEN NVL(PF.PAY_AMT,0)   Else 0  END as AUTO_CREDIT_TOTAL_AMT
					FROM
							SRC_RIA.PAYMENT_FACT PF
							INNER JOIN SRC_RIA.TNDR_TYPE_DIM TT ON TT.SRC_TNDR_TYPE_CD = PF.TNDR_TYPE_CD
							INNER JOIN SRC_RIA.TNDR_SRC_DIM TS ON TS.SRC_TNDR_SOURCE_CD = PF.TNDR_SRC_CD
					Where   TO_TIMESTAMP ( to_char(PF.FREEZE_DT,''mm/dd/yyyy hh24:mi:ss''), ''mm/dd/yyyy hh24:mi:ss'' ) BETWEEN
							TO_TIMESTAMP(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'') AND
							TO_TIMESTAMP(to_char(:v_report_end,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'')
				);

					UPDATE  BDR_DM.RIA_DAILY_RECON
					SET 	lockbox_total_amt 		= NVL(:v_lockbox_tot_amt,0),
							enrollment_total_amt  	= NVL(:v_enrollment_tot_amt,0),
							thirdparty_total_amt  	= NVL(:v_checkfree_tot_amt,0),
							eft_total_amt  			= NVL(:v_eft_tot_amt,0),
							auto_credit_total_amt 	= NVL(:v_auto_credit_tot_amt,0)
					WHERE   report_date 			= :v_report_date;									
				    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_payments_AOP ENDS---------------	
	
			-- Online chredit, check, wire, misc
			--sum_online_payments_AOP ( v_report_date, p_report_start, p_report_end );		----------OAS DELETE
			
									------------- CODE FOR sum_online_payments_AOP BEGINS---------------
		  
			V_STEP_NAME    := ''sum_online_payments_AOP - UPDATE - RIA_DAILY_RECON'';
			V_STEP_SEQ     :=  V_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

				select /*+  parallel(PF)  parallel(TT) */ SUM(ONLINE_CREDIT_TOTAL_AMT),SUM(ONLINE_CHECK_TOTAL_AMT),SUM(ONLINE_WIRE_TOTAL_AMT),SUM(ONLINE_MISC_TOTAL_AMT)
					   INTO v_online_credit_tot_amt,v_online_check_tot_amt,v_online_wire_tot_amt,v_online_misc_tot_amt
				from
				(
					select
						CASE WHEN TNDR_TYPE_DESCR = ''Credit Card'' AND TS.EXT_SOURCE_ID <> ''EXSIDCOMPAS'' THEN NVL(PF.PAY_AMT,0) 		Else 0 	END as ONLINE_CREDIT_TOTAL_AMT,
						CASE WHEN SRC_TNDR_TYPE_CD =''CHK'' AND TS.EXT_SOURCE_ID <> ''EXSIDCOMPAS''		  THEN NVL(PF.PAY_AMT,0) 		Else 0 	END as ONLINE_CHECK_TOTAL_AMT,
						CASE WHEN SRC_TNDR_TYPE_CD IN (''WIRC'',''WIRS'') AND TS.EXT_SOURCE_ID <> ''EXSIDCOMPAS''	THEN NVL(PF.PAY_AMT,0) 	Else 0  END as ONLINE_WIRE_TOTAL_AMT,
						CASE WHEN SRC_TNDR_TYPE_CD IN (''MOK'',''MOC'')   AND TS.EXT_SOURCE_ID <> ''EXSIDCOMPAS''  	THEN NVL(PF.PAY_AMT,0) 	Else 0 	END as ONLINE_MISC_TOTAL_AMT
				FROM
						SRC_RIA.PAYMENT_FACT PF
						INNER JOIN SRC_RIA.TNDR_TYPE_DIM TT ON TT.SRC_TNDR_TYPE_CD = PF.TNDR_TYPE_CD
						INNER JOIN SRC_RIA.TNDR_SRC_DIM TS ON TS.SRC_TNDR_SOURCE_CD = PF.TNDR_SRC_CD
				Where   TO_TIMESTAMP ( to_char(PF.FREEZE_DT,''mm/dd/yyyy hh24:mi:ss''), ''mm/dd/yyyy hh24:mi:ss'' ) BETWEEN
						TO_TIMESTAMP(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'') AND
						TO_TIMESTAMP(to_char(:v_report_end,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'')
				);


				UPDATE BDR_DM.RIA_DAILY_RECON
				SET online_credit_total_amt = NVL(:v_online_credit_tot_amt,0),
					online_check_total_amt  = NVL(:v_online_check_tot_amt,0),
					online_wire_total_amt  =  NVL(:v_online_wire_tot_amt,0),
					online_misc_total_amt  =  NVL(:v_online_misc_tot_amt,0)

				WHERE  report_date = :v_report_date;
				    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_online_payments_AOP ENDS---------------	

			-- Accounting adjustments waiver, pro-rated credits
			--SUM_ACCTADJ_PAYMENTS_AOP ( v_report_date, p_report_start, p_report_end );		----------OAS DELETE
		
									------------- CODE FOR SUM_ACCTADJ_PAYMENTS_AOP BEGINS---------------
		  
			V_STEP_NAME    := ''SUM_ACCTADJ_PAYMENTS_AOP - UPDATE - RIA_DAILY_RECON'';
			V_STEP_SEQ     :=  V_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

				select /*+  parallel(AF)  parallel(AD) */ SUM(AA_WAIVER_TOTAL_AMT),SUM(AA_PRORATED_CREDIT_TOTAL_AMT) INTO v_waiver_tot_amt,v_prorated_credit_tot_amt
				from
				(
				SELECT
						CASE WHEN AD.SRC_ADJ_TYPE_CD in (''WPRMDFWV'') THEN NVL(AF.ADJ_AMT,0)   Else 0 END as AA_WAIVER_TOTAL_AMT,
						CASE WHEN AD.SRC_ADJ_TYPE_CD in (''WPRRTDCR'') THEN NVL(AF.ADJ_AMT,0)   Else 0 END as AA_PRORATED_CREDIT_TOTAL_AMT

				FROM
						SRC_RIA.ADJUSTMENT_FACT AF Inner JOIN SRC_RIA.ADJ_TYPE_DIM AD ON AF.SRC_ADJ_TYPE_CD=AD.SRC_ADJ_TYPE_CD
				Where   TO_TIMESTAMP(to_char(AF.FREEZE_DT,''mm/dd/yyyy hh24:mi:ss''), ''mm/dd/yyyy hh24:mi:ss'' ) BETWEEN
						TO_TIMESTAMP(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'') AND
						TO_TIMESTAMP(to_char(:v_report_end,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'')
				);

				UPDATE BDR_DM.RIA_DAILY_RECON
				SET    AA_WAIVER_TOTAL_AMT=NVL(:v_waiver_tot_amt,0),
					   AA_PRORATED_CREDIT_TOTAL_AMT=NVL(:v_prorated_credit_tot_amt,0)
				WHERE  report_date = :v_report_date;
				    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR SUM_ACCTADJ_PAYMENTS_AOP ENDS---------------	

			-- Refunds
			--sum_refund_AOP ( v_report_date, p_report_start, p_report_end );		----------OAS DELETE
		
									------------- CODE FOR sum_refund_AOP BEGINS---------------
		  
			v_refund := 0;
		  
			V_STEP_NAME    := ''sum_refund_AOP - UPDATE - RIA_DAILY_RECON'';
			V_STEP_SEQ     :=  V_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

				SELECT /*+ parallel (8)  */ SUM(ADJ_AMT) INTO v_refund FROM
				(

				SELECT /*+ parallel (8)  */ SUM(ADJ_AMT) AS ADJ_AMT FROM SRC_RIA.ADJUSTMENT_FACT AF INNER JOIN SRC_RIA.CUSTOMER_DIM CUST_DIM ON CUST_DIM.SRC_CUST_ID=AF.UDDGEN30 WHERE SRC_ADJ_ID IN
				(SELECT   DISTINCT RWR.ADJ_ID FROM
				SRC_RIA.C1_REF_WO_REQ RW INNER JOIN
				SRC_RIA.C1_REF_WO_REQ_DTLS RWR
				ON RWR.REF_WO_REQ_ID = RW.REF_WO_REQ_ID AND TRIM(RW.BO_STATUS_CD) IN (''PROCESSED'',''REISSUE'',''VOID'') AND RW.BUS_OBJ_CD LIKE ''%Ref%''
				WHERE EXISTS (SELECT 1 FROM SRC_RIA.C1_REF_WO_REQ_CHAR RWC WHERE  RWR.REF_WO_REQ_ID = RWC.REF_WO_REQ_ID AND RWC.CHAR_TYPE_CD= ''CM-SNTDT'')
				)
				AND CUST_DIM.SRC_CUST_ID <>(:V_SRC_CUST_ID)
				AND TO_TIMESTAMP(to_char(AF.FREEZE_DT,''mm/dd/yyyy hh24:mi:ss''), ''mm/dd/yyyy hh24:mi:ss'' ) BETWEEN
				TO_TIMESTAMP(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'') AND
				TO_TIMESTAMP(to_char(:v_report_end,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'')

				UNION ALL

				SELECT /*+ parallel (8)  */ SUM(ADJ_AMT) AS ADJ_AMT FROM SRC_RIA.ADT_ADJUSTMENT_FACT AF INNER JOIN SRC_RIA.CUSTOMER_DIM CUST_DIM ON CUST_DIM.SRC_CUST_ID=AF.UDDGEN30 WHERE AF.ADT_TYP_CD=''D'' AND SRC_ADJ_ID IN
				(SELECT   DISTINCT RWR.ADJ_ID FROM
				SRC_RIA.C1_REF_WO_REQ RW INNER JOIN
				SRC_RIA.C1_REF_WO_REQ_DTLS RWR
				ON RWR.REF_WO_REQ_ID = RW.REF_WO_REQ_ID AND TRIM(RW.BO_STATUS_CD) IN (''PROCESSED'',''REISSUE'',''VOID'') AND RW.BUS_OBJ_CD LIKE ''%Ref%''
				WHERE EXISTS (SELECT 1 FROM SRC_RIA.C1_REF_WO_REQ_CHAR RWC WHERE  RWR.REF_WO_REQ_ID = RWC.REF_WO_REQ_ID  AND RWC.CHAR_TYPE_CD= ''CM-SNTDT'')
				)
				AND CUST_DIM.SRC_CUST_ID <>(:V_SRC_CUST_ID)
				AND TO_TIMESTAMP(to_char(AF.FREEZE_DT,''mm/dd/yyyy hh24:mi:ss''), ''mm/dd/yyyy hh24:mi:ss'' ) BETWEEN
				TO_TIMESTAMP(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'') AND
				TO_TIMESTAMP(to_char(:v_report_end,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'')

				) ;

					UPDATE BDR_DM.RIA_DAILY_RECON
					SET    refunds = nvl(:v_refund,0)
					WHERE  report_date = :v_report_date;
									    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_refund_AOP ENDS---------------	

			-- Returns
			--sum_return_AOP ( v_report_date, p_report_start, p_report_end );		----------OAS DELETE
		
									------------- CODE FOR sum_return_AOP BEGINS---------------
		  
			V_STEP_NAME    := ''sum_return_AOP - UPDATE - RIA_DAILY_RECON'';
			V_STEP_SEQ     :=  V_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

				SELECT /*+  parallel(AF) parallel(AD) */ SUM(ADJ_AMT) INTO    v_returns_tot_amt
				FROM SRC_RIA.ADJUSTMENT_FACT AF JOIN SRC_RIA.ADJ_TYPE_DIM AD ON AF.SRC_ADJ_TYPE_CD=AD.SRC_ADJ_TYPE_CD
				WHERE AD.SRC_ADJ_TYPE_CD IN (''CMREFMOT'')
				AND   TO_TIMESTAMP(to_char(AF.FREEZE_DT,''mm/dd/yyyy hh24:mi:ss''), ''mm/dd/yyyy hh24:mi:ss'' ) BETWEEN
					  TO_TIMESTAMP(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'') AND
					  TO_TIMESTAMP(to_char(:v_report_end,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'')
				;

					UPDATE BDR_DM.RIA_DAILY_RECON
					SET     returns_total_amt = nvl(:v_returns_tot_amt,0)
					WHERE  report_date = :v_report_date;
									    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_return_AOP ENDS---------------	

			-- EFT Protest
			--sum_eft_protest_AOP ( v_report_date, p_report_start, p_report_end );		----------OAS DELETE
		
									------------- CODE FOR sum_eft_protest_AOP BEGINS---------------
		  
			v_eft_protest := 0.0;
		  
			V_STEP_NAME    := ''sum_eft_protest_AOP - UPDATE - RIA_DAILY_RECON'';
			V_STEP_SEQ     :=  V_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;
			
				SELECT /*+  parallel(AF) parallel(AD) */ SUM(ADJ_AMT) INTO    v_eft_protest
				FROM SRC_RIA.ADJUSTMENT_FACT AF JOIN SRC_RIA.ADJ_TYPE_DIM AD ON AF.SRC_ADJ_TYPE_CD=AD.SRC_ADJ_TYPE_CD
				WHERE AD.SRC_ADJ_TYPE_CD IN (''CMREFARB'')
				AND   TO_TIMESTAMP(to_char(AF.FREEZE_DT,''mm/dd/yyyy hh24:mi:ss''), ''mm/dd/yyyy hh24:mi:ss'' ) BETWEEN
				  TO_TIMESTAMP(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'') AND
				  TO_TIMESTAMP(to_char(:v_report_end,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'')
				;

				UPDATE BDR_DM.RIA_DAILY_RECON
				SET     eft_protest = nvl(:v_eft_protest,0)
				WHERE  report_date = :v_report_date;
				    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_eft_protest_AOP ENDS---------------	
				
			-- Retro debit, Misc loss
			--sum_acctadj_retrodebit_mscloss_AOP ( v_report_date, p_report_start, p_report_end );		----------OAS DELETE
		
									------------- CODE FOR sum_acctadj_retrodebit_mscloss_AOP BEGINS---------------
		  
			V_STEP_NAME    := ''sum_acctadj_retrodebit_mscloss_AOP - UPDATE - RIA_DAILY_RECON'';
			V_STEP_SEQ     :=  V_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;
				
				select /*+  parallel(AF)  parallel(AD) */ SUM(AA_MISC_LOSS_TOTAL_AMT),SUM(AA_RETRO_DEBIT_TOTAL_AMT)
				INTO v_miscloss_tot_amt,v_retrodebit_tot_amt
				from
				(
				SELECT
						CASE WHEN AD.SRC_ADJ_TYPE_CD in (''WMISCLSS'') THEN NVL(AF.ADJ_AMT,0)   Else 0 END as AA_MISC_LOSS_TOTAL_AMT,
						CASE WHEN AD.SRC_ADJ_TYPE_CD in (''WRETRODB'') THEN NVL(AF.ADJ_AMT,0)   Else 0 END as AA_RETRO_DEBIT_TOTAL_AMT
				FROM
						SRC_RIA.ADJUSTMENT_FACT AF Inner JOIN SRC_RIA.ADJ_TYPE_DIM AD ON AF.SRC_ADJ_TYPE_CD=AD.SRC_ADJ_TYPE_CD
						Where   TO_TIMESTAMP(to_char(AF.FREEZE_DT,''mm/dd/yyyy hh24:mi:ss''), ''mm/dd/yyyy hh24:mi:ss'' ) BETWEEN
						TO_TIMESTAMP(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'') AND
						TO_TIMESTAMP(to_char(:v_report_end,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'')
				);

				UPDATE BDR_DM.RIA_DAILY_RECON
				SET  aa_retro_debit_total_amt = NVL(:v_retrodebit_tot_amt,0),
					 aa_misc_loss_total_amt   = NVL(:v_miscloss_tot_amt,0)
					 WHERE  report_date = :v_report_date;	
				    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_acctadj_retrodebit_mscloss_AOP ENDS---------------	
					 
			-- Pro Rated Loss
			--sum_acctadj_prorated_loss_AOP ( v_report_date, p_report_start, p_report_end );		----------OAS DELETE
		
									------------- CODE FOR sum_acctadj_prorated_loss_AOP BEGINS---------------
		  
			V_STEP_NAME    := ''sum_acctadj_prorated_loss_AOP - UPDATE - RIA_DAILY_RECON'';
			V_STEP_SEQ     :=  V_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;
			
				SELECT  /*+  parallel(AF)  parallel(AD) */ sum(AF.ADJ_AMT)
				INTO    v_proratedloss_tot_amt
				FROM SRC_RIA.ADJUSTMENT_FACT AF Inner join SRC_RIA.ADJ_TYPE_DIM AD on AF.SRC_ADJ_TYPE_CD=AD.SRC_ADJ_TYPE_CD
				WHERE AD.SRC_ADJ_TYPE_CD in (''WRPRTDLS'') AND
				TO_TIMESTAMP(to_char(AF.FREEZE_DT,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'') BETWEEN
				TO_TIMESTAMP(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'') AND
				TO_TIMESTAMP(to_char(:v_report_end,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'');

				UPDATE BDR_DM.RIA_DAILY_RECON
				SET   aa_prorated_loss_total_amt   = nvl(:v_proratedloss_tot_amt,0)
				WHERE  report_date = :v_report_date;	
								    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_acctadj_prorated_loss_AOP ENDS---------------	

			-- Claims
			--sum_claims_AOP ( v_report_date, p_report_start, p_report_end );		----------OAS DELETE
		
									------------- CODE FOR sum_claims_AOP BEGINS---------------
		  
			V_STEP_NAME    := ''sum_claims_AOP - UPDATE - RIA_DAILY_RECON'';
			V_STEP_SEQ     :=  V_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;
				
				SELECT  /*+  parallel(AF)  parallel(AD) */ sum(AF.ADJ_AMT)
				INTO v_claims_tot
				FROM SRC_RIA.ADJUSTMENT_FACT AF Inner join SRC_RIA.ADJ_TYPE_DIM AD on AF.SRC_ADJ_TYPE_CD=AD.SRC_ADJ_TYPE_CD
				where AD.SRC_ADJ_TYPE_CD in (''ICCLAIMS'') AND
				TO_TIMESTAMP(to_char(AF.FREEZE_DT,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'') BETWEEN
				TO_TIMESTAMP(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'') AND
				TO_TIMESTAMP(to_char(:v_report_end,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'');


				UPDATE BDR_DM.RIA_DAILY_RECON
				SET    claims_total_amt = nvl(:v_claims_tot,0)
				WHERE  report_date = :v_report_date;
				    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_claims_AOP ENDS---------------	
				
			--sum_unclaimedrefund_AOP ( v_report_date, p_report_start, p_report_end );		----------OAS DELETE
		
									------------- CODE FOR sum_unclaimedrefund_AOP BEGINS---------------
		  
			V_STEP_NAME    := ''sum_unclaimedrefund_AOP - UPDATE - RIA_DAILY_RECON'';
			V_STEP_SEQ     :=  V_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;
			
				SELECT /*+ parallel (8)  */ SUM(ADJ_AMT) INTO v_unclaimed_tot_amt FROM
				(

				SELECT /*+ parallel (8)  */ SUM(ADJ_AMT) AS ADJ_AMT FROM SRC_RIA.ADJUSTMENT_FACT AF INNER JOIN SRC_RIA.CUSTOMER_DIM CUST_DIM ON CUST_DIM.SRC_CUST_ID=AF.UDDGEN30 WHERE SRC_ADJ_ID IN
				(SELECT   DISTINCT RWR.ADJ_ID FROM
				SRC_RIA.C1_REF_WO_REQ RW INNER JOIN
				SRC_RIA.C1_REF_WO_REQ_DTLS RWR
				ON RWR.REF_WO_REQ_ID = RW.REF_WO_REQ_ID AND TRIM(RW.BO_STATUS_CD) IN (''PROCESSED'',''REISSUE'',''VOID'') AND RW.BUS_OBJ_CD LIKE ''%Ref%''
				WHERE EXISTS (SELECT 1 FROM SRC_RIA.C1_REF_WO_REQ_CHAR RWC WHERE  RWR.REF_WO_REQ_ID = RWC.REF_WO_REQ_ID AND RWC.CHAR_TYPE_CD= ''CM-SNTDT'')
				)
				AND CUST_DIM.SRC_CUST_ID =(:V_SRC_CUST_ID)
				AND TO_TIMESTAMP(to_char(AF.FREEZE_DT,''mm/dd/yyyy hh24:mi:ss''), ''mm/dd/yyyy hh24:mi:ss'' ) BETWEEN
				TO_TIMESTAMP(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'') AND
				TO_TIMESTAMP(to_char(:v_report_end,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'')

				UNION ALL

				SELECT /*+ parallel (8)  */ SUM(ADJ_AMT) AS ADJ_AMT FROM SRC_RIA.ADT_ADJUSTMENT_FACT AF INNER JOIN SRC_RIA.CUSTOMER_DIM CUST_DIM ON CUST_DIM.SRC_CUST_ID=AF.UDDGEN30 WHERE AF.ADT_TYP_CD=''D'' AND SRC_ADJ_ID IN
				(SELECT   DISTINCT RWR.ADJ_ID FROM
				SRC_RIA.C1_REF_WO_REQ RW INNER JOIN
				SRC_RIA.C1_REF_WO_REQ_DTLS RWR
				ON RWR.REF_WO_REQ_ID = RW.REF_WO_REQ_ID AND TRIM(RW.BO_STATUS_CD) IN (''PROCESSED'',''REISSUE'',''VOID'') AND RW.BUS_OBJ_CD LIKE ''%Ref%''
				WHERE EXISTS (SELECT 1 FROM SRC_RIA.C1_REF_WO_REQ_CHAR RWC WHERE  RWR.REF_WO_REQ_ID = RWC.REF_WO_REQ_ID AND RWC.CHAR_TYPE_CD= ''CM-SNTDT'')
				)
				AND CUST_DIM.SRC_CUST_ID =(:V_SRC_CUST_ID)
				AND TO_TIMESTAMP(to_char(AF.FREEZE_DT,''mm/dd/yyyy hh24:mi:ss''), ''mm/dd/yyyy hh24:mi:ss'' ) BETWEEN
				TO_TIMESTAMP(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'') AND
				TO_TIMESTAMP(to_char(:v_report_end,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'')

				) ;

					UPDATE BDR_DM.RIA_DAILY_RECON
					SET unclaimed_refund_amt = nvl(:v_unclaimed_tot_amt,0)
					WHERE  report_date = :v_report_date;	
				    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_unclaimedrefund_AOP ENDS---------------					

			-- Unclaimed
			--sum_unclaimedfunds_AOP ( v_report_date, p_report_start, p_report_end );		----------OAS DELETE
		
									------------- CODE FOR sum_unclaimedfunds_AOP BEGINS---------------
		  
			V_STEP_NAME    := ''sum_unclaimedfunds_AOP - UPDATE - RIA_DAILY_RECON'';
			V_STEP_SEQ     :=  V_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;
		
				SELECT  /*+  parallel(AF)  parallel(AD) */ sum(AF.ADJ_AMT)
				INTO v_unclaimed_tot_amt
				FROM SRC_RIA.ADJUSTMENT_FACT AF Inner join SRC_RIA.ADJ_TYPE_DIM AD on AF.SRC_ADJ_TYPE_CD=AD.SRC_ADJ_TYPE_CD
				where AD.SRC_ADJ_TYPE_CD in (''ICESCHMT'') AND
				TO_TIMESTAMP(to_char(AF.FREEZE_DT,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'') BETWEEN
				TO_TIMESTAMP(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'') AND
				TO_TIMESTAMP(to_char(:v_report_end,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'');

				UPDATE BDR_DM.RIA_DAILY_RECON
				SET unclaimed_total_amt = nvl(:v_unclaimed_tot_amt,0)
				WHERE  report_date = :v_report_date;
				    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_unclaimedfunds_AOP ENDS---------------	
				
			--sum_pension_payments_AOP( v_report_date, p_report_start, p_report_end );		----------OAS DELETE
		
									------------- CODE FOR sum_pension_payments_AOP BEGINS---------------
		  
			v_amount := 0.0;
		  
			V_STEP_NAME    := ''sum_pension_payments_AOP - UPDATE - RIA_DAILY_RECON'';
			V_STEP_SEQ     :=  V_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;
		
				SELECT NVL(SUM(PF.PAY_AMT),0) into v_amount FROM

				SRC_RIA.PAYMENT_FACT PF
				INNER JOIN SRC_RIA.TNDR_TYPE_DIM TT ON TT.SRC_TNDR_TYPE_CD = PF.TNDR_TYPE_CD
				INNER JOIN SRC_RIA.TNDR_SRC_DIM TS ON TS.SRC_TNDR_SOURCE_CD = PF.TNDR_SRC_CD
				where TT.SRC_TNDR_TYPE_CD IN (''PENS'',''PENM'') AND TS.EXT_SOURCE_ID <> ''EXSIDCOMPAS''
				and
				TO_TIMESTAMP(to_char(PF.FREEZE_DT,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'') BETWEEN
				TO_TIMESTAMP(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'') AND
				TO_TIMESTAMP(to_char(:v_report_end,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'')
				;

				UPDATE BDR_DM.RIA_DAILY_RECON
				SET    pension_payment = NVL(:v_amount,0)
				WHERE  report_date = :v_report_date;
								    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_pension_payments_AOP ENDS---------------	

			--sum_emp_membership_paid_amt_AOP( v_report_date, p_report_start, p_report_end );		----------OAS DELETE
			
									------------- CODE FOR sum_emp_membership_paid_amt_AOP BEGINS---------------
		  
			v_amount := 0.0;
		  
			V_STEP_NAME    := ''sum_emp_membership_paid_amt_AOP - UPDATE - RIA_DAILY_RECON'';
			V_STEP_SEQ     :=  V_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;
					
				SELECT /*+  parallel(MF)  parallel(AF) parallel(CD) */ sum(NVL(cur_amt,0)) into v_amount
				from SRC_RIA.CM_MEM_FEE_DL_STG_VW MF
				LEFT OUTER JOIN SRC_RIA.ADJUSTMENT_FACT AF ON MF.FT_ID = AF.SRC_FT_ID
				LEFT OUTER JOIN SRC_RIA.CUSTOMER_DIM CD ON CD.SRC_CUST_ID=AF.UDDGEN30
				WHERE  MF.CDC_FLAG <> ''D'' and CD.id_type_cd=''EMPID''
				and TO_TIMESTAMP(to_char(MF.FREEZE_DTTM,''mm/dd/yyyy hh24:mi:ss''), ''mm/dd/yyyy hh24:mi:ss'' ) BETWEEN
				TO_TIMESTAMP(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'') AND
				TO_TIMESTAMP(to_char(:v_report_end,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'');

				UPDATE BDR_DM.RIA_DAILY_RECON
				SET    EMP_MEMBERSHIP_PAID_AMT = NVL(:v_amount,0)
				WHERE  report_date = :v_report_date;
				    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_emp_membership_paid_amt_AOP ENDS---------------	

			--sum_bank_adjustments_amt_AOP( v_report_date, p_report_start, p_report_end );		----------OAS DELETE
		
									------------- CODE FOR sum_bank_adjustments_amt_AOP BEGINS---------------
		  
			v_amount := 0.0;
		  
			V_STEP_NAME    := ''sum_bank_adjustments_amt_AOP - UPDATE - RIA_DAILY_RECON'';
			V_STEP_SEQ     :=  V_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;
			
				SELECT /*+  parallel(AF) parallel(AD) */ SUM(ADJ_AMT) INTO    v_amount
				FROM SRC_RIA.ADJUSTMENT_FACT AF JOIN SRC_RIA.ADJ_TYPE_DIM AD ON AF.SRC_ADJ_TYPE_CD=AD.SRC_ADJ_TYPE_CD
				WHERE AD.SRC_ADJ_TYPE_CD IN (''CMREFMRB'')
				AND   TO_TIMESTAMP(to_char(AF.FREEZE_DT,''mm/dd/yyyy hh24:mi:ss''), ''mm/dd/yyyy hh24:mi:ss'' ) BETWEEN
					  TO_TIMESTAMP(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'') AND
					  TO_TIMESTAMP(to_char(:v_report_end,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'')
				;

					UPDATE BDR_DM.RIA_DAILY_RECON
					SET    BANK_ADJUSTMENT_AMT = NVL(:v_amount,0)
					WHERE  report_date = :v_report_date;
									    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_bank_adjustments_amt_AOP ENDS---------------	

			--sum_membership_andrus_amt_AOP( v_report_date, p_report_start, p_report_end );		----------OAS DELETE
		
									------------- CODE FOR sum_membership_andrus_amt_AOP BEGINS---------------
		  
			v_amount := 0.0;
		  
			V_STEP_NAME    := ''sum_membership_andrus_amt_AOP - UPDATE - RIA_DAILY_RECON'';
			V_STEP_SEQ     :=  V_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

				SELECT /*+  parallel(MF)  parallel(AF) parallel(CD) */ sum(nvl(cur_amt,0)) INTO v_amount
				from SRC_RIA.CM_MEM_FEE_DL_STG_VW MF
				LEFT OUTER JOIN SRC_RIA.ADJUSTMENT_FACT AF ON MF.FT_ID = AF.SRC_FT_ID
				LEFT OUTER JOIN SRC_RIA.CUSTOMER_DIM CD ON CD.SRC_CUST_ID=AF.UDDGEN30
				WHERE  MF.CDC_FLAG <> ''D'' and CD.ID_TYPE_CD<>''EMPID''
				and TO_TIMESTAMP(to_char(MF.FREEZE_DTTM,''mm/dd/yyyy hh24:mi:ss''), ''mm/dd/yyyy hh24:mi:ss'' ) BETWEEN
				TO_TIMESTAMP(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'') AND
				TO_TIMESTAMP(to_char(:v_report_end,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'');

				UPDATE BDR_DM.RIA_DAILY_RECON
				SET    MEMBERSHIP_ANDRUS_FUNDS_AMT = NVL(:v_amount,0)
				WHERE  report_date = :v_report_date;
				    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_membership_andrus_amt_AOP ENDS---------------	
		
			--sum_from_pdp_mapd_amt_AOP(v_report_date,p_report_start,p_report_end);		----------OAS DELETE
			
									------------- CODE FOR sum_from_pdp_mapd_amt_AOP BEGINS---------------
		  
			v_pdp_amt := 0;
		  
			V_STEP_NAME    := ''sum_from_pdp_mapd_amt_AOP - UPDATE - RIA_DAILY_RECON'';
			V_STEP_SEQ     :=  V_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;
		
				SELECT /*+  parallel(PF) parallel(TS) */ SUM(PF.PAY_AMT) INTO v_pdp_amt FROM
					SRC_RIA.PAYMENT_FACT PF
					INNER JOIN SRC_RIA.TNDR_SRC_DIM  TS ON TS.SRC_TNDR_SOURCE_CD = PF.TNDR_SRC_CD AND TS.SRC_TNDR_SOURCE_CD=''TI_PDP'' AND TS.EXT_SOURCE_ID <> ''EXSIDCOMPAS''
				Where   TO_TIMESTAMP ( to_char(PF.FREEZE_DT,''mm/dd/yyyy hh24:mi:ss''), ''mm/dd/yyyy hh24:mi:ss'' ) BETWEEN
					TO_TIMESTAMP(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'') AND
					TO_TIMESTAMP(to_char(:v_report_end,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'');

				UPDATE BDR_DM.RIA_DAILY_RECON
				SET   TRANSFER_FROM_PDP_AMT      =  NVL(:v_pdp_amt,0)
				WHERE  report_date = :v_report_date;	
				    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_from_pdp_mapd_amt_AOP ENDS---------------	
				
			--sum_to_pdp_mapd_amt_AOP(v_report_date,p_report_start,p_report_end);		----------OAS DELETE
		
									------------- CODE FOR sum_to_pdp_mapd_amt_AOP BEGINS---------------
		  
			V_STEP_NAME    := ''sum_to_pdp_mapd_amt_AOP - UPDATE - RIA_DAILY_RECON'';
			V_STEP_SEQ     :=  V_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

				select /*+  parallel(AF)  parallel(AD) */ sum(NVL(ADJ_AMT,0))  into v_pdp_amt

				FROM SRC_RIA.ADJUSTMENT_FACT AF inner join SRC_RIA.ADJ_TYPE_DIM AD on AF.SRC_ADJ_TYPE_CD=AD.SRC_ADJ_TYPE_CD
				where AD.SRC_ADJ_TYPE_CD in (''ICPDP'')
				and
				TO_TIMESTAMP(to_char(AF.FREEZE_DT,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'') BETWEEN
				TO_TIMESTAMP(to_char(:v_report_start,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'') AND
				TO_TIMESTAMP(to_char(:v_report_end,''mm/dd/yyyy hh24:mi:ss''),''mm/dd/yyyy hh24:mi:ss'');


				UPDATE BDR_DM.RIA_DAILY_RECON
				SET TRANSFER_TO_PDP_AMT = NVL(:v_pdp_amt,0)
					WHERE  report_date = :v_report_date;
				    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

									------------- CODE FOR sum_to_pdp_mapd_amt_AOP ENDS---------------	
		
			--pr_log_complete(v_report_date,v_procedure);		-----OAS DELETE
		  
			V_STEP_NAME    := ''UPDATE - RIA_DAILY_RECON'';
			V_STEP_SEQ     := : v_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

			UPDATE BDR_DM.RIA_DAILY_RECON
			SET CREATED_BY = ''combatch'',
			CREATION_DATE = TRUNC(CURRENT_TIMESTAMP, ''DD''),
			LAST_MODIFIED_BY = ''combatch'',
			LAST_MODIFIED_DATE = TRUNC(CURRENT_TIMESTAMP, ''DD'')
			WHERE REPORT_DATE = :v_report_date;
			    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

			V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

	---------------COMMENTED BY OAS-----------------		  				
	/*
			COMMIT;

			--pkg_utility.pr_write_status(''recon_status'');

			--COMPAS_MO.send_email(''"recon"<ois_it_operations@uhc.com>'',g_email,TO_CHAR(p_report_date, ''mm/dd/yyyy'') || '' COMPAS Reconcilation done'', '' '');

		EXCEPTION
			WHEN OTHERS THEN
				dbms_output.put_line(''Error '' || SUBSTR(SQLERRM,1,240));
				pr_log_error(p_report_date, v_procedure, SQLERRM);
				--COMPAS_MO.send_email(''"recon"<ois_it_operations@uhc.com>'',g_email,''COMPAS Reconcilation error'', SQLERRM);

		END;

	*/
	---------------COMMENTED BY OAS-----------------
									------------- CODE FOR pr_recon2(); ENDS---------------	
									
	---------------COMMENTED BY OAS-----------------
	/*
		EXCEPTION
			WHEN OTHERS THEN
				dbms_output.put_line(''Error '' || SUBSTR(SQLERRM,1,240));
				pr_log_error(v_report_date, ''pr_recon'', SQLERRM);
				--COMPAS_MO.send_email(''"recon"<ois_it_operations@uhc.com>'',g_email,''COMPAS Reconcilation error'', SQLERRM);

		END;	
	
	*/
--------COMMENTED BY OAS--------	
									------------- CODE FOR COMPAS_MO.PKG_RIA_DAILY_RECON.PR_RECON() ENDS---------------
									
---------------COMMENTED BY OAS-----------------									
/*
		
                                                EXCEPTION
                                                WHEN OTHERS THEN

                                                        lv_error_msg := SUBSTR(SQLERRM, 1, 250);
                                                        SELECT SYSDATE INTO lv_etl_end_time FROM dual;

                                                        UPDATE ETL.ETL_MCLONE_DECOM_PROC_LIST
                                                        SET run_status  = ''ERROR'',
                                                          etl_end_time  = lv_etl_end_time,
                                                          etl_error_msg = lv_error_msg
                                                        WHERE proc_name = lv_proc_name;
                                                        COMMIT;

                                                        SELECT SYSDATE INTO lv_etl_end_time FROM dual;

                                                        UPDATE ETL.ETL_MCLONE_DECOM_PROC_LIST
                                                        SET etl_time_taken = round((cast(etl_end_time as date) - cast(etl_start_time as date)) * 24 * 60 * 60)
                                                        WHERE proc_name    = lv_proc_name;

                                                        COMMIT;

                                                        lv_exception := ''Y'';
                                                        RAISE;
                                      END;

                                      IF lv_exception = ''Y'' THEN
                                      --DBMS_OUTPUT.PUT_LINE(''lv_exception'');
                                        EXIT;
                                      END IF;

                                      SELECT SYSDATE INTO lv_etl_end_time FROM dual;

                                      UPDATE ETL.ETL_MCLONE_DECOM_PROC_LIST
                                      SET run_status  = ''COMPLETE'',
                                      etl_end_time  = lv_etl_end_time
                                      WHERE proc_name = lv_proc_name;

                                      COMMIT;

                                      UPDATE ETL.ETL_MCLONE_DECOM_PROC_LIST
                                      SET etl_time_taken = round((cast(etl_end_time as date) - cast(etl_start_time as date)) * 24 * 60 * 60)
                                      WHERE proc_name    = lv_proc_name;

                                      COMMIT;


                              END;
                              BEGIN

                                        SELECT proc_name
                                        INTO lv_proc_name
                                        FROM
                                        (SELECT proc_name
                                        FROM ETL.ETL_MCLONE_DECOM_PROC_LIST
                                        WHERE run_status      IN (''READY'',''ERROR'')
                                        AND proc_launch_order = lv_min_order
                                        AND active_ind = ''Y''
                                        )
                                        WHERE ROWNUM = 1;

                                        EXCEPTION WHEN NO_DATA_FOUND THEN
                                        lv_next_rec_found := ''N'';
                                        --dbms_output.put_line(''Exception'');
                              END;

                              --lv_proc_final := '''';
                              --lv_proc_name := '''';
                    END LOOP;

                    SELECT LISTAGG(run_status , '''') WITHIN GROUP (
                    ORDER BY run_status)
                    INTO lv_flag
                    FROM
                      (SELECT DISTINCT run_status
                      FROM ETL.ETL_MCLONE_DECOM_PROC_LIST
                      WHERE proc_launch_order = lv_min_order
                      AND active_ind = ''Y''
                      );

                    IF lv_flag      = ''COMPLETE'' OR (lv_min_order = lv_max_order) THEN
                      lv_min_order := lv_min_order + 1;		--------------------12+1 => FALSE FOR NEXT ITERATION
                    END IF;

          END LOOP;

          --Returns the result set
          P_ToContinueStatus := ''Y'';
          P_ErrorYNFlg       := ''N'';
          P_ErrorStr         := '''';

          EXCEPTION WHEN OTHERS THEN
            P_ErrorStr         := ''ERROR: '' || SQLCODE || ''-'' || SQLERRM || ''-'' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE()|| Chr(10)||DBMS_UTILITY.FORMAT_ERROR_STACK();
            P_ToContinueStatus := ''N'';
            P_ErrorYNFlg       := ''Y'';
            ROLLBACK;
END;
/
*/
---------------COMMENTED BY OAS-----------------

						----------------CODE FOR MAIN PROCEDURE ETL.SP_ETL_MCLONE_DECOM_M ENDS------------------------
						

CALL UTIL.SP_ETL_CHECK_CONSTRAINTS(:DB_NAME , :APPLICATION , :WORKFLOW_NAME , :OBJECT_NAME , :V_BATCH_ID );		---------OAS ADD

UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''COMPLETE'', ERROR_MSG = null, BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
;
UPDATE  UTIL.ETL_BATCH_OBJECT_INCR_VALU SET INCR_COLUMN_VALUE = :V_BATCH_ID, LST_MOD_DT = CURRENT_TIMESTAMP() 
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID''
;



EXCEPTION

WHEN OTHER THEN

UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''ERROR'', ERROR_MSG = :SQLERRM,  BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
;

INSERT INTO  UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ERROR_MSG, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''ERROR'', :V_STEP_NAME, :V_STEP_SEQ, :SQLERRM, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() )
;



RAISE;

END;

';