USE SCHEMA BDR_DM;
CREATE OR REPLACE FUNCTION FN_QUERY_EARLY_PPO_DELINQUENTS("P_DELINQUENT_DATE" TIMESTAMP_NTZ(9))
RETURNS FLOAT
LANGUAGE SQL
AS '
       SELECT /*+ PARALLEL(8) */ sum (ipbb.BILL_PREM_AMT + NVL( ABS(ipbb.EMPLOYER_SUBSIDY_AMT) ,0) ) AS emp_amount 
	   FROM SRC_RIA.PREM_BUCKET_FACT ipbb, 
		(SELECT  /*+ PARALLEL(8) */ ar.indv_id 
		FROM BDR_DM.AR_RIA_PPO_STAGE  ps, BDR_MSOA.WRK_RIA_ACCTRECEIVABLENEW  ar 
		WHERE ar.indv_id = ps.individual_id 
		--    AND ar.RECEIVABLE_TYPE    = ''Medical''
		--    AND ar.RESPONSIBLE_PARTY_ID IN (1, 2) 
		 AND ar.DUE_DT <= to_date(TO_CHAR(p_delinquent_date, ''mm/dd/yyyy''), ''mm/dd/yyyy'')  GROUP BY ar.indv_id
		HAVING SUM (ar.PD_AMT) < SUM (ar.DUE_AMT) and  SUM(ar.Due_AMT)>0 ) ppo, 
		SRC_COMPAS_M.insured_plan ip , SRC_COMPAS_M.PLAN p, SRC_COMPAS_M.plan_type pt
		WHERE to_date(TO_CHAR(p_delinquent_date,''mm/dd/yyyy''),''mm/dd/yyyy'')	<= ipbb.END_DATE
		AND ipbb.individual_id = ppo.indv_id
		AND ip.insured_plan_id = ipbb.insured_plan_id
		AND p.plan_cd = ip.plan_cd
		AND pt.plan_type_id = p.plan_type_id
		AND pt.plan_category_id = 4
		AND to_date(TO_CHAR(p_delinquent_date,''mm/dd/yyyy''),''mm/dd/yyyy'')
		<=  NVL(ip.insured_plan_termination_date, TO_DATE(''12/31/9999'',''mm/dd/yyyy''))
		
';