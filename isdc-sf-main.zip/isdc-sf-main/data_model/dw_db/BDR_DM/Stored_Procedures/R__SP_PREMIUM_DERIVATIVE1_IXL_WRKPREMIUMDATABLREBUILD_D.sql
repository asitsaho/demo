USE SCHEMA BDR_DM; CREATE OR REPLACE PROCEDURE "SP_PREMIUM_DERIVATIVE1_IXL_WRKPREMIUMDATABLREBUILD_D"("DB_NAME" VARCHAR(16777216), "APPLICATION" VARCHAR(16777216), "WORKFLOW_NAME" VARCHAR(16777216), "OBJECT_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '

-- Original workflow: wkf_RIA_Premium_Derivative_IXL_TargetLoad1_D
-- Original mapping: m_Premium_Derivative1_IXL_WrkPremiumDataBlRebuild_D
-- Original folder: Premium
-- Original filename: wkf_RIA_Premium_Derivative_IXL_TargetLoad1_D.XML

DECLARE


V_ROWS_INSERTED  INTEGER;
V_ROWS_UPDATED INTEGER;
V_ROWS_DELETED INTEGER;
V_LAST_QUERY_ID VARCHAR;

V_WH VARCHAR;
V_BATCH_ID INTEGER;


V_BATCH_OBJECT_START_TIME        VARCHAR;
V_STEP_START_TIME    VARCHAR;
V_STEP_NAME VARCHAR;
V_STEP_SEQ INTEGER DEFAULT 0;
V_ETL_LST_BTCH_ID INTEGER;

V_ACTIVITY_DATE VARCHAR;
V_CONFMONTH    VARCHAR;
V_ETLNUMBEROFMONTHSBACK VARCHAR;
V_PURGE_START VARCHAR;
V_PURGE_END VARCHAR;
V_AOP_LIVE_DATE VARCHAR;

BEGIN

EXECUTE IMMEDIATE ''USE DATABASE ''||:DB_NAME; 

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_BATCH_OBJECT_START_TIME := (SELECT CURRENT_TIMESTAMP());



LET res1 RESULTSET := 
(

SELECT 

WH ,
BATCH_ID
  
FROM UTIL.ETL_BATCH_OBJECT_CONTROL
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
FETCH FIRST 1 ROW ONLY

)
;


LET C1 CURSOR FOR res1;
open C1;
FETCH C1 into  V_WH,V_BATCH_ID ;
close C1;


LET res2 RESULTSET := 

(

WITH PARAMETERS (CONF_MONTH, ETLNUMBEROFMONTHSBACK, PURGE_START, AOP_LIVE_DATE) AS
(
  
SELECT * 
FROM  
(SELECT PARAMETER_NAME, PARAMETER_VALUE  FROM UTIL.ETL_OBJECT_PARAMETER_VALUE 
WHERE 1 = 1
AND APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
AND ACTIVE_FLG = ''Y''  
  
UNION ALL       

SELECT PARAMETER_NAME, PARAMETER_VALUE  FROM UTIL.ETL_GLOBAL_PARAMETER_VALUE WHERE PAR_GLOBAL_TYPE = ''PARGLOBAL_OPREPORTS'' AND ACTIVE_FLG = ''Y''
AND PARAMETER_NAME NOT IN  (
SELECT PARAMETER_NAME  FROM UTIL.ETL_OBJECT_PARAMETER_VALUE WHERE 1 = 1
AND APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
AND ACTIVE_FLG = ''Y''   ))
 
PIVOT(MAX(PARAMETER_VALUE) FOR PARAMETER_NAME IN (''CONF_MONTH'', ''ETLNUMBEROFMONTHSBACK'', ''PURGE_START'', ''AOP_LIVE_DATE'')) 

 
)  
SELECT * FROM PARAMETERS 
)  
  
;


LET C2 CURSOR FOR res2;
open C2;
FETCH C2 into  V_CONFMONTH, V_ETLNUMBEROFMONTHSBACK, V_PURGE_START, V_AOP_LIVE_DATE; 
close C2;




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:V_WH;
USE SCHEMA BDR_DM;	--OAS ADD


INSERT INTO UTIL.ETL_BATCH_OBJECT_INCR_VALU (APPLICATION, WORKFLOW_NAME, OBJECT_NAME, INCR_COLUMN, INCR_COLUMN_VALUE )
SELECT * FROM (select :APPLICATION AS APPLICATION, :WORKFLOW_NAME AS WORKFLOW_NAME, :OBJECT_NAME AS OBJECT_NAME, ''ETL_LST_BTCH_ID'' AS INCR_COLUMN, -1 AS INCR_COLUMN_VALUE) A
WHERE NOT EXISTS (SELECT 1 FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU B WHERE B.APPLICATION = A.APPLICATION AND B.WORKFLOW_NAME = A.WORKFLOW_NAME AND B.OBJECT_NAME = A.OBJECT_NAME AND B.INCR_COLUMN = A.INCR_COLUMN)
;

V_ETL_LST_BTCH_ID :=(SELECT INCR_COLUMN_VALUE FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID'');

--------------------------------COMMENTED BY OAS--------------------------------
/*
CREATE OR REPLACE PROCEDURE DM.SP_PREMIUM_WRKDATABSLNREBLD_D(
    iv_Dummy IN NUMBER,
    P_ToContinueStatus OUT VARCHAR2,
    P_ErrorYNFlg OUT VARCHAR2,
    P_ErrorStr OUT VARCHAR2 )
AS
  V_PROC_NAME             VARCHAR(50):=''SP_PREMIUM_WRKDATABSLNREBLD_D'';
  V_ROWS_AFFTD            NUMBER(20) :=0;
  V_BTCH_ID               NUMBER(10);
  V_ACTIVITY_DATE          DATE;
  v_confmonth             DATE;
  v_uw_curretlbatchid     NUMBER(10,0);
-- v_uw_lastetlbatchid     NUMBER(10,0);	-- DISABLED FOR RetroAct+RIA MERGE
  v_etlcurrentbatchid     NUMBER(10,0);
-- v_etllastbatchid        NUMBER(10,0);	-- DISABLED FOR RetroAct+RIA MERGE
-- v_etllastdcmprocessdate DATE;			-- DISABLED FOR RetroAct+RIA MERGE
  v_etlnumberofmonthsback NUMBER(10,0);
-- v_etlapplbatchid        NUMBER(10,0);		-- DISABLED FOR RetroAct+RIA MERGE
  v_purge_start DATE;
  v_purge_end DATE;
  V_AOP_LIVE_DATE DATE;
BEGIN
  SELECT MAX(BATCH_ID)
  INTO V_BTCH_ID
  FROM ETL.ETL_BATCH_LOG
  WHERE APPLICATION=''CDC''
  AND BATCH_STATUS =''COMPLETE'';
  INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''DERIVATIVE PREMIUM1'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''START'',
      ''PROCEDURE STARTS'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );
*/
-------------------------------------COMMENTED BY OAS-------------------------------------


-------------------------------OAS DELETE --FETCHING THESE VALUES FROM OBJECT PARAMETER TABLE--------------------------------
  /* SELECT TO_DATE(metadata_value,''MM-DD-YYYY'')
  INTO V_ACTIVITY_DATE
  FROM etl.etl_application_metadata
  WHERE application = ''PREMIUM''
  AND metadata_type = ''ACTIVITY_DATE''; -- GETTING UPDATED BEFORE LOADING TNA BASELINE IN INTERIM PREMIUM II
  SELECT TO_DATE(metadata_value,''YYYY-MM-DD'')
  INTO v_confmonth
  FROM etl.etl_application_metadata
  WHERE application = ''PREMIUM''
  AND metadata_type = ''CONF_MONTH''; */
 -------------------------------OAS DELETE --FETCHING THESE VALUES FROM OBJECT PARAMETER TABLE--------------------------------
 
 V_ACTIVITY_DATE := (SELECT CURRENT_DATE-1 FROM DUAL);			---------------------OAS ADD
 
 
  /*SELECT metadata_value							-- DISABLED FOR RetroAct+RIA MERGE
  INTO v_etllastbatchid
  FROM etl.etl_application_metadata
  WHERE application = ''PREMIUM''
  AND metadata_type = ''PGD_ISDWETLLastBatchID''; -- GETTING UPDATED IN UPDATE PREMIUM BASELINE
  SELECT metadata_value
  INTO v_uw_lastetlbatchid
  FROM etl.etl_application_metadata
  WHERE application = ''PREMIUM''
  AND metadata_type = ''PGD_UWFactETLLastBatchID''; -- GETTING UPDATED END OF THIS PROC
  SELECT TO_DATE(metadata_value,''MM-DD-YYYY HH24:MI:SS'')
  INTO v_etllastdcmprocessdate
  FROM etl.etl_application_metadata
  WHERE application = ''PREMIUM''
  AND metadata_type = ''PGD_DCMLastDate'';*/ -- GETTING UPDATED END OF THIS PROC
  
  
------------------------------OAS DELETE --NOT BEING USED IN THIS PROCEDURE-----------------------------
  /* SELECT MAX(batch_id)
  INTO v_uw_curretlbatchid
  FROM etl.etl_batch_log
  WHERE application = ''UNDERWRITING''
  AND batch_status  = ''COMPLETE''; */
------------------------------OAS DELETE --NOT BEING USED IN THIS PROCEDURE-----------------------------
 
 /*  SELECT MAX(batch_id)
  INTO v_etlcurrentbatchid
  FROM etl.etl_batch_log
  WHERE application = ''CDC''
  AND batch_status  = ''COMPLETE''; */	---OAS COMMENTED --SAME VALUE AS V_BTCH_ID
  
  
-------------------------------OAS DELETE --FETCHING THESE VALUES FROM OBJECT PARAMETER TABLE--------------------------------
 /*  SELECT metadata_value
  INTO v_etlnumberofmonthsback
  FROM etl.etl_application_metadata
  WHERE application = ''PREMIUM''
  AND metadata_type = ''PGD_MonthsBack''; -- Static
  SELECT TO_DATE(metadata_value,''YYYY-MM-DD'')
  INTO v_purge_start
  FROM etl.etl_application_metadata
  WHERE application = ''PREMIUM''
  AND metadata_type = ''PURGE_START''; */ --Static 2009-01-01
-------------------------------OAS DELETE --FETCHING THESE VALUES FROM OBJECT PARAMETER TABLE--------------------------------

V_PURGE_START := (SELECT TO_DATE(:V_PURGE_START,''YYYYMMDD''));			-----------------OAS ADD
  
  
 /* SELECT metadata_value									-- DISABLED FOR RetroAct+RIA MERGE
  INTO v_etlapplbatchid
  FROM etl.etl_application_metadata
  WHERE application = ''PREMIUM''
  AND metadata_type = ''APPLFactETLLastBatchID''; */-- GETTING UPDATED IN UPDATE PREMIUM BASELINE


SELECT TO_DATE(TO_CHAR(TRUNC(add_months(:V_ACTIVITY_DATE,-1*(:V_ETLNUMBEROFMONTHSBACK)),''YEAR''),''DD/MM/YYYY''),''DD/MM/YYYY'') into v_purge_end FROM DUAL;

--SELECT TO_DATE(METADATA_VALUE,''YYYY/MM/DD'') INTO V_AOP_LIVE_DATE FROM ETL.ETL_APPLICATION_METADATA WHERE APPLICATION= ''PREMIUM'' AND METADATA_DESC =''AOP_LIVE_DATE'';		------------------OAS DELETE --FETCHING THIS VALUE FROM OBJECT PARAMETER TABLE

V_AOP_LIVE_DATE := (SELECT TO_DATE(:V_AOP_LIVE_DATE,''YYYYMMDD''));	-----------------OAS ADD

  /*
  SELECT metadata_value INTO v_etllastdcmprocessdate
  FROM etl.etl_application_metadata
  WHERE application = ''PREMIUM''
  AND metadata_type = ''PGD_ConfMaxDate''; -- Static
  */
  --             SET @vBaselineCutoffDate = CONVERT(DATE,DATEADD(M,@ETLNumberOfMonthsBack * -1,''1/1/'' + convert(char(4),year(@ActivityDate))));
  --DBMS_STATS.GATHER_TABLE_STATS (OWNNAME => ''DM'',TABNAME => ''WRK_SUSPENDED_MEDSUPP_PLANS'',PARTNAME => NULL,ESTIMATE_PERCENT => 10, DEGREE => 4, GRANULARITY => ''ALL'', METHOD_OPT => ''FOR ALL COLUMNS SIZE 1'',CASCADE => TRUE);
  --DBMS_STATS.GATHER_TABLE_STATS (OWNNAME => ''DM'',TABNAME => ''WRK_PREM_BBAEMP_SUBSIDY'',PARTNAME => NULL,ESTIMATE_PERCENT => 10, DEGREE => 4, GRANULARITY => ''ALL'', METHOD_OPT => ''FOR ALL COLUMNS SIZE 1'',CASCADE => TRUE);
  --DBMS_STATS.GATHER_TABLE_STATS (OWNNAME => ''DM'',TABNAME => ''WRK_PGD_INSPLANBENMOD'',PARTNAME => NULL,ESTIMATE_PERCENT => 10, DEGREE => 4, GRANULARITY => ''ALL'', METHOD_OPT => ''FOR ALL COLUMNS SIZE 1'',CASCADE => TRUE);
  --DBMS_STATS.GATHER_TABLE_STATS (OWNNAME => ''DM'',TABNAME => ''WRK_ACCOUNT_NUMBER_DATA'',PARTNAME => NULL,ESTIMATE_PERCENT => 10, DEGREE => 4, GRANULARITY => ''ALL'', METHOD_OPT => ''FOR ALL COLUMNS SIZE 1'',CASCADE => TRUE);
  --DBMS_STATS.GATHER_TABLE_STATS (OWNNAME => ''DM'',TABNAME => ''D_EMP_GRS_ATR'',PARTNAME => NULL,ESTIMATE_PERCENT => 10, DEGREE => 4, GRANULARITY => ''ALL'', METHOD_OPT => ''FOR ALL COLUMNS SIZE 1'',CASCADE => TRUE);
  --DBMS_STATS.GATHER_TABLE_STATS (OWNNAME => ''DM'',TABNAME => ''WRK_COMPAS_DEMOGRAPHICDATA'',PARTNAME => NULL,ESTIMATE_PERCENT => 10, DEGREE => 4, GRANULARITY => ''ALL'', METHOD_OPT => ''FOR ALL COLUMNS SIZE 1'',CASCADE => TRUE);
  --DBMS_STATS.GATHER_TABLE_STATS (OWNNAME => ''DM'',TABNAME => ''WRK_PREMIUM_DATABASELINE_TNA'',PARTNAME => NULL,ESTIMATE_PERCENT => 10, DEGREE => 4, GRANULARITY => ''ALL'', METHOD_OPT => ''FOR ALL COLUMNS SIZE 1'',CASCADE => TRUE);
  --DBMS_STATS.GATHER_TABLE_STATS (OWNNAME => ''DM'',TABNAME => ''WRK_PGD_TEMP_UW_TAGS'',PARTNAME => NULL,ESTIMATE_PERCENT => 10, DEGREE => 4, GRANULARITY => ''ALL'', METHOD_OPT => ''FOR ALL COLUMNS SIZE 1'',CASCADE => TRUE);
  
  
-------------------------------------COMMENTED BY OAS-------------------------------------
  /* DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''WRK_COMPAS_DEMOGRAPHICDATA'');
  DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''WRK_PREMIUM_DATABASELINE_TNA''); */
-------------------------------------COMMENTED BY OAS-------------------------------------


  -- EXECUTE IMMEDIATE ''TRUNCATE TABLE DM.TEMP_BASELINE_REBULD_DISTINDID'';   -- DISABLED FOR RetroAct+RIA MERGE
  
  
V_STEP_NAME    := ''TRUNCATE - TEMP_MONTH_DATE'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

  EXECUTE IMMEDIATE ''TRUNCATE TABLE BDR_DM.TEMP_MONTH_DATE'';

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );


V_STEP_NAME    := ''TRUNCATE - wrk_premium_data_bl_rebuild'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;
 
  EXECUTE IMMEDIATE ''TRUNCATE TABLE BDR_DM.wrk_premium_data_bl_rebuild'';
  
INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );
  
V_STEP_NAME    := ''TRUNCATE - temp_premium_data_bl_rebuild'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

  EXECUTE IMMEDIATE ''TRUNCATE TABLE BDR_DM.temp_premium_data_bl_rebuild'';
  
INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );
  
-------------------------------------COMMENTED BY OAS-------------------------------------
  /* EXECUTE IMMEDIATE ''ALTER TABLE  DM.wrk_premium_data_bl_rebuild modify BLR_RN generated as identity start with 1 cache 50000'';
  BEGIN
    EXECUTE IMMEDIATE ''ALTER TABLE WRK_PREMIUM_DATA_BL_REBUILD DROP CONSTRAINT INDX_WRK_PREMIUM_DATA_P01'';
    EXECUTE IMMEDIATE ''DROP INDEX INDX_WRK_PREMIUM_DATA_P01'';
    EXECUTE IMMEDIATE ''DROP INDEX INDX_WRK_PREMIUM_DATA_A01'';
  EXCEPTION
  WHEN OTHERS THEN
    NULL;
  END; */
-------------------------------------COMMENTED BY OAS-------------------------------------


-- EXECUTE IMMEDIATE ''truncate table DM.WRK_INSD_PLN_PRFL_OVRLP_TMP'';
--  EXECUTE IMMEDIATE ''truncate table DM.WRK_INSD_PLN_PRFL_OVRLP_TMP2'';
--  EXECUTE IMMEDIATE ''truncate table DM.WRK_INSD_PLN_PRFL_OVRLP_TMP3'';
--  EXECUTE IMMEDIATE ''truncate table DM.WRK_INSD_PLN_PRFL_TMP'';
  
V_STEP_NAME    := ''TRUNCATE - WRK_INSD_PLN_PRFL_TMP2'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

  EXECUTE IMMEDIATE ''truncate table BDR_DM.WRK_INSD_PLN_PRFL_TMP2'';
  
INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

--																		-- DISABLED FOR RetroAct+RIA MERGE
--  INSERT
--   /*+ ENABLE_PARALLEL_DML PARALLEL APPEND */
--  INTO dm.TEMP_BASELINE_REBULD_DISTINDID
--    (SELECT demo.individual_id
--      FROM dm.wrk_compas_demographicdata demo
--      WHERE demo.ipb_etl_lst_btch_id > v_etllastbatchid
--      OR demo.ip_etl_lst_btch_id     > v_etllastbatchid
--      OR demo.ind_etl_lst_btch_id    > v_etllastbatchid
--      OR demo.bba_etl_lst_btch_id    > v_etllastbatchid
--       UNION
--      SELECT demo.individual_id
--      FROM compas.insured_plan ip
--      JOIN dm.wrk_compas_demographicdata demo
--      ON ip.insured_plan_id       = demo.insuredplan_id
--      JOIN dm.f_appl_trans_day f
--      ON ip.application_id = f.APPL_ID
--      WHERE CURR_ROW_FLG = ''Y'' and
--       f.etl_lst_btch_id > v_etlapplbatchid
--      UNION
--      SELECT demo.individual_id
--      FROM compas.account_receivable ar
--      JOIN dm.wrk_compas_demographicdata demo
--      ON ar.household_id       = demo.household_id
--      WHERE ar.etl_lst_btch_id > v_etllastbatchid
--      UNION
--      SELECT demo.individual_id
--      FROM compas.household_address ha
--      JOIN dm.wrk_compas_demographicdata demo
--      ON ha.household_id       = demo.household_id
--      WHERE ha.etl_lst_btch_id > v_etllastbatchid
--      UNION
--      SELECT demo.individual_id
--      FROM compas.insured_plan_benefit_mod benmod
--      JOIN dm.wrk_compas_demographicdata demo
--      ON benmod.insured_plan_id    = demo.insuredplan_id
--      WHERE benmod.etl_lst_btch_id > v_etllastbatchid
--      UNION
--      SELECT demo.individual_id
--      FROM compas.individual_profile iprof
--      JOIN dm.wrk_compas_demographicdata demo
--      ON iprof.individual_id      = demo.individual_id
--      WHERE iprof.etl_lst_btch_id > v_etllastbatchid
--      UNION
--      SELECT demo.individual_id
--      FROM compas.household_profile hp -- ACCT_NBR
--      JOIN dm.wrk_compas_demographicdata demo
--      ON hp.household_id       = demo.household_id
--      WHERE hp.etl_lst_btch_id > v_etllastbatchid
--      UNION
--      SELECT demo.individual_id
--      FROM compas.household_member hm -- ACCT_NBR
--      JOIN dm.wrk_compas_demographicdata demo
--      ON hm.household_id       = demo.household_id
--      WHERE hm.etl_lst_btch_id > v_etllastbatchid ------------
--      UNION
--      SELECT demo.individual_id
--      FROM undwr.f_undwr fuw -- UNDWR Tags 9/9/2015 JS
--      JOIN dm.wrk_compas_demographicdata demo
--      ON fuw.insd_pln_id        = demo.insuredplan_id
--      WHERE fuw.etl_lst_btch_id > v_uw_lastetlbatchid
--      UNION
--      SELECT demo.individual_id
--      FROM undwr.f_undwr fuw -- UNDWR Tags 9/9/2015 JS
--      JOIN dm.wrk_compas_demographicdata demo
--      ON fuw.indv_id            = demo.individual_id
--      WHERE fuw.etl_lst_btch_id > v_uw_lastetlbatchid
--      UNION
--      SELECT demo.individual_id -- Added for Legal Entity 04/19/2016
--      FROM compas.insured_plan_profile ipp
--      JOIN dm.wrk_compas_demographicdata demo
--      ON ipp.insured_plan_id    = demo.insuredplan_id
--      WHERE ipp.etl_lst_btch_id > v_etllastbatchid
--      UNION
--      SELECT demo.individual_id -- Added for Compas D_AGE_LOOK_FRACnt
--      FROM compas.insured_plan ip
--      JOIN compas.application a
--      ON ip.application_id = a.application_id
--      JOIN dm.wrk_compas_demographicdata demo
--      ON ip.insured_plan_id   = demo.insuredplan_id
--      WHERE a.etl_lst_btch_id > v_etllastbatchid
--      UNION
--      SELECT demo.individual_id -- Added for Compas D_AGE_LOOK_FRACnt
--      FROM compas.insured_plan ip
--      JOIN compas.application a
--      ON ip.application_id = a.application_id
--      JOIN compas.application_agent ag
--      ON a.application_id = ag.application_id
--      JOIN dm.wrk_compas_demographicdata demo
--      ON ip.insured_plan_id    = demo.insuredplan_id
--      WHERE ag.etl_lst_btch_id > v_etllastbatchid
--      UNION
--      SELECT demo.individual_id
--      FROM compas.employer_household eh
--      JOIN dm.wrk_compas_demographicdata demo
--      ON eh.household_id       = demo.household_id
--      WHERE eh.etl_lst_btch_id > v_etllastbatchid
--      UNION
--      SELECT demo.individual_id --- added 1 11 2018
--      FROM compas.household_billing_profile hbp
--      JOIN dm.wrk_compas_demographicdata demo
--      ON hbp.household_id       = demo.household_id
--      WHERE hbp.etl_lst_btch_id > v_etllastbatchid
--      UNION
--      SELECT demo.individual_id --- added 1 11 2018
--      FROM COMPAS.billing_bucket_adjustment bbad
--      JOIN dm.wrk_compas_demographicdata demo
--      ON bbad.household_id       = demo.household_id
--      WHERE bbad.etl_lst_btch_id > v_etllastbatchid
--      UNION
--      SELECT demo.individual_id --- added 1 11 2018
--      FROM COMPAS.adjustment adj
--      JOIN COMPAS.billing_bucket_adjustment bbadj
--      ON adj.adjustment_id = bbadj.adjustment_id
--      JOIN dm.wrk_compas_demographicdata demo
--      ON bbadj.household_id     = demo.household_id
--      WHERE adj.etl_lst_btch_id > v_etllastbatchid
--      UNION
--      SELECT demo.individual_id --- added 1 11 2018
--      FROM COMPAS.calculated_rate cal
--      JOIN COMPAS.ins_plan_billing_bucket ipbbt
--      ON cal.calculated_rate_id = ipbbt.calculated_rate_id
--      JOIN dm.wrk_compas_demographicdata demo
--      ON ipbbt.household_id     = demo.household_id
--      WHERE cal.etl_lst_btch_id > v_etllastbatchid
--      UNION
--      SELECT demo.individual_id
--      FROM dm.wrk_compas_demographicdata demo
--      JOIN compas.policy p
--      ON demo.individual_id = p.individual_id
--      INNER JOIN
--        ( SELECT DISTINCT mbr_pol_id
--        FROM dcm.dcm_comm_pd
--        WHERE m_r_prdct_catgy IN (
--                        ''AARP MS'',
--                        ''MS''
--                    )
--        AND lgr_itm_dt        > v_etllastdcmprocessdate--()@ETLLastDCMPROCESS_DATE
--        ) dcm
--      ON p.policy_number = dcm.mbr_pol_id
--      UNION
--      SELECT demo.individual_id
--      FROM adt_compas.adt_account_receivable adtar
--      JOIN dm.wrk_compas_demographicdata demo
--      ON adtar.household_id          = demo.household_id
--      WHERE adt_row_creat_by_btch_id > v_etllastbatchid
--      AND adt_typ_cd                 = ''D''
--      AND acct_receivable_type_id    = 2
--      AND responsible_party_type_id IN ( 1,2 )
--      UNION
--      SELECT demo.individual_id
--      FROM adt_compas.adt_insured_plan_benefit_mod adtbenmod
--      JOIN dm.wrk_compas_demographicdata demo
--      ON adtbenmod.insured_plan_id   = demo.insuredplan_id
--      WHERE adt_row_creat_by_btch_id > v_etllastbatchid
--      AND benefit_mod_type_id       <= 6
--      AND adt_typ_cd                 = ''D''
--      UNION
--      SELECT demo.individual_id
--      FROM adt_compas.adt_individual_profile adtipprof
--      JOIN dm.wrk_compas_demographicdata demo
--      ON adtipprof.individual_id     = demo.individual_id
--      WHERE adt_row_creat_by_btch_id > v_etllastbatchid
--      AND adt_typ_cd                 = ''D''
--      UNION
--      SELECT demo.individual_id
--      FROM adt_compas.adt_billing_bucket_adjustment adtbba--billingbucket
--      JOIN dm.wrk_compas_demographicdata demo
--      ON adtbba.ins_plan_billing_bucket_id = demo.insplan_billingbucket_id
--      WHERE adt_row_creat_by_btch_id       > v_etllastbatchid
--      AND adt_typ_cd                       = ''D''
--      UNION --- -- Adding Cert Channel 8/4/2015
--      SELECT demo.individual_id
--      FROM dm.wrk_compas_demographicdata demo
--      INNER JOIN dm.wrk_ipacqchannel_chg ipac
--      ON demo.insuredplan_id = ipac.insuredplanid
--      UNION
--      SELECT demo.individual_id
--      FROM adt_compas.adt_household_profile adthp -- added for ACCT_NBR
--      JOIN dm.wrk_compas_demographicdata demo
--      ON adthp.household_id          = demo.household_id
--      WHERE adt_row_creat_by_btch_id > v_etllastbatchid
--      AND adt_typ_cd                 = ''D''
--      UNION
--      SELECT demo.individual_id
--      FROM adt_compas.adt_household_member adthm -- added for ACCT_NBR
--      JOIN dm.wrk_compas_demographicdata demo
--      ON adthm.household_id          = demo.household_id
--      WHERE adt_row_creat_by_btch_id > v_etllastbatchid
--      AND adt_typ_cd                 = ''D''
--      UNION
--      SELECT demo.individual_id ----  Added for Legal Entity 04/19/2016
--      FROM adt_compas.adt_insured_plan_profile adtipp
--      JOIN dm.wrk_compas_demographicdata demo
--      ON adtipp.insured_plan_id      = demo.insuredplan_id
--      WHERE adt_row_creat_by_btch_id > v_etllastbatchid
--      AND adt_typ_cd                 = ''D''
--      UNION
--      SELECT demo.individual_id --- added 1 11 2018
--      FROM adt_compas.adt_household_billing_profile adthbp
--      JOIN dm.wrk_compas_demographicdata demo
--      ON adthbp.household_id         = demo.household_id
--      WHERE adt_row_creat_by_btch_id > v_etllastbatchid
--      AND adt_typ_cd                 = ''D''
--      UNION
--      SELECT demo.individual_id --- added 1 11 2018
--      FROM adt_COMPAS.adt_billing_bucket_adjustment adtbbad
--      JOIN dm.wrk_compas_demographicdata demo
--      ON adtbbad.household_id        = demo.household_id
--      WHERE adt_row_creat_by_btch_id > v_etllastbatchid
--      AND adt_typ_cd                 = ''D''
--      UNION
--      SELECT demo.individual_id --- added 1 11 2018
--      FROM adt_COMPAS.adt_adjustment adtadj
--      JOIN adt_COMPAS.adt_billing_bucket_adjustment adtbbadj
--      ON adtadj.adjustment_id = adtbbadj.adjustment_id
--      JOIN dm.wrk_compas_demographicdata demo
--      ON adtbbadj.household_id              = demo.household_id
--      WHERE adtadj.adt_row_creat_by_btch_id > v_etllastbatchid
--      AND adtadj.adt_typ_cd                 = ''D''
--      UNION
--      SELECT demo.individual_id --- added 1 11 2018
--      FROM adt_COMPAS.adt_calculated_rate adtcal
--      JOIN adt_COMPAS.adt_ins_plan_billing_bucket adtipbbt
--      ON adtcal.calculated_rate_id = adtipbbt.calculated_rate_id
--      JOIN dm.wrk_compas_demographicdata demo
--      ON adtipbbt.household_id              = demo.household_id
--      WHERE adtcal.adt_row_creat_by_btch_id > v_etllastbatchid
--      AND adtcal.adt_typ_cd                 = ''D''
--      UNION
--      SELECT demo.individual_id ----  Added for D_AGE_LOOK_FRACnt
--      FROM compas.insured_plan ip
--      JOIN adt_compas.adt_application adta
--      ON ip.application_id = adta.application_id
--      JOIN dm.wrk_compas_demographicdata demo
--      ON ip.insured_plan_id          = demo.insuredplan_id
--      WHERE adt_row_creat_by_btch_id > v_etllastbatchid
--      AND adt_typ_cd                 = ''D''
--      UNION
--      SELECT demo.individual_id ----  Added for D_AGE_LOOK_FRACnt
--      FROM compas.insured_plan ip
--      JOIN compas.application a
--      ON ip.application_id = a.application_id
--      JOIN adt_compas.adt_application_agent adtag
--      ON a.application_id = adtag.application_id
--      JOIN dm.wrk_compas_demographicdata demo
--      ON ip.insured_plan_id          = demo.insuredplan_id
--      WHERE adt_row_creat_by_btch_id > v_etllastbatchid
--      AND adt_typ_cd                 = ''D'' ----------------------------------------------------------
--      UNION
--      SELECT tna.individual_id
--      FROM compas.insured_plan ip
--      INNER JOIN dm.wrk_premium_databaseline_tna tna
--      ON ip.insured_plan_id    = tna.insuredplan_id
--      WHERE ip.etl_lst_btch_id > v_etllastbatchid
--        UNION
--      SELECT tna.individual_id
--      FROM compas.insured_plan ip
--      JOIN dm.wrk_premium_databaseline_tna tna
--      ON ip.insured_plan_id       = tna.insuredplan_id
--      JOIN dm.f_appl_trans_day f
--      ON ip.application_id = f.APPL_ID
--      WHERE CURR_ROW_FLG = ''Y'' and
--       f.etl_lst_btch_id > v_etlapplbatchid
--        UNION
--      SELECT tna.individual_id
--      FROM compas.individual ind
--      INNER JOIN dm.wrk_premium_databaseline_tna tna
--      ON ind.individual_id      = tna.individual_id
--      WHERE ind.etl_lst_btch_id > v_etllastbatchid
--      UNION
--      SELECT tna.individual_id
--      FROM compas.account_receivable ar
--      INNER JOIN dm.wrk_premium_databaseline_tna tna
--      ON ar.household_id       = tna.household_id
--      WHERE ar.etl_lst_btch_id > v_etllastbatchid
--      UNION
--      SELECT tna.individual_id
--      FROM compas.household_address ha
--      INNER JOIN dm.wrk_premium_databaseline_tna tna
--      ON ha.household_id       = tna.household_id
--      WHERE ha.etl_lst_btch_id > v_etllastbatchid
--      UNION
--      SELECT tna.individual_id
--      FROM compas.insured_plan_benefit_mod benmod
--      INNER JOIN dm.wrk_premium_databaseline_tna tna
--      ON benmod.insured_plan_id    = tna.insuredplan_id
--      WHERE benmod.etl_lst_btch_id > v_etllastbatchid
--      UNION
--      SELECT tna.individual_id --- added 1 11 2018
--      FROM compas.household_billing_profile hbp
--      JOIN dm.wrk_premium_databaseline_tna tna
--      ON hbp.household_id       = tna.household_id
--      WHERE hbp.etl_lst_btch_id > v_etllastbatchid
--      UNION
--      SELECT tna.individual_id --- added 1 11 2018
--      FROM COMPAS.billing_bucket_adjustment bbad
--      JOIN dm.wrk_premium_databaseline_tna tna
--      ON bbad.household_id       = tna.household_id
--      WHERE bbad.etl_lst_btch_id > v_etllastbatchid
--      UNION
--      SELECT tna.individual_id --- added 1 11 2018
--      FROM COMPAS.adjustment adj
--      JOIN COMPAS.billing_bucket_adjustment bbadj
--      ON adj.adjustment_id = bbadj.adjustment_id
--      JOIN dm.wrk_premium_databaseline_tna tna
--      ON bbadj.household_id     = tna.household_id
--      WHERE adj.etl_lst_btch_id > v_etllastbatchid
--      UNION
--      SELECT tna.individual_id --- added 1 11 2018
--      FROM COMPAS.calculated_rate cal
--      JOIN COMPAS.ins_plan_billing_bucket ipbbt
--      ON cal.calculated_rate_id = ipbbt.calculated_rate_id
--      JOIN dm.wrk_premium_databaseline_tna tna
--      ON ipbbt.household_id     = tna.household_id
--      WHERE cal.etl_lst_btch_id > v_etllastbatchid
--      UNION
--      SELECT tna.individual_id
--      FROM compas.individual_profile iprof
--      INNER JOIN dm.wrk_premium_databaseline_tna tna
--      ON iprof.individual_id      = tna.individual_id
--      WHERE iprof.etl_lst_btch_id > v_etllastbatchid
--      UNION
--      SELECT tna.individual_id
--      FROM compas.employer_household eh
--      JOIN dm.wrk_premium_databaseline_tna tna
--      ON eh.household_id       = tna.household_id
--      WHERE eh.etl_lst_btch_id > v_etllastbatchid
--      UNION
--      SELECT tna.individual_id
--      FROM dm.wrk_premium_databaseline_tna tna
--      JOIN compas.policy p
--      ON tna.individual_id = p.individual_id
--      INNER JOIN
--        ( SELECT DISTINCT mbr_pol_id
--        FROM dcm.dcm_comm_pd
--        WHERE     m_r_prdct_catgy IN (
--                        ''AARP MS'',
--                        ''MS''
--                    )
--        AND lgr_itm_dt        > v_etllastdcmprocessdate--()@ETLLastDCMPROCESS_DATE
--        ) dcm
--      ON p.policy_number = dcm.mbr_pol_id
--      UNION
--      SELECT tna.individual_id
--      FROM adt_compas.adt_account_receivable adtar
--      INNER JOIN dm.wrk_premium_databaseline_tna tna
--      ON adtar.household_id          = tna.household_id
--      WHERE adt_row_creat_by_btch_id > v_etllastbatchid
--      AND adt_typ_cd                 = ''D''
--      AND acct_receivable_type_id    = 2
--      AND responsible_party_type_id IN ( 1,2 )
--      UNION
--      SELECT tna.individual_id
--      FROM adt_compas.adt_insured_plan_benefit_mod adtbenmod
--      INNER JOIN dm.wrk_premium_databaseline_tna tna
--      ON adtbenmod.insured_plan_id   = tna.insuredplan_id
--      WHERE adt_row_creat_by_btch_id > v_etllastbatchid
--      AND benefit_mod_type_id       <= 6
--      AND adt_typ_cd                 = ''D''
--      UNION
--      SELECT tna.individual_id
--      FROM adt_compas.adt_individual_profile adtipprof
--      INNER JOIN dm.wrk_premium_databaseline_tna tna
--      ON adtipprof.individual_id     = tna.individual_id
--      WHERE adt_row_creat_by_btch_id > v_etllastbatchid
--      AND adt_typ_cd                 = ''D''
--      UNION
--      SELECT tna.individual_id
--      FROM compas.household_profile hp -- ACCT_NBR
--      JOIN dm.wrk_premium_databaseline_tna tna
--      ON hp.household_id       = tna.household_id
--      WHERE hp.etl_lst_btch_id > v_etllastbatchid
--      UNION
--      SELECT tna.individual_id
--      FROM compas.household_member hm -- ACCT_NBR
--      JOIN dm.wrk_premium_databaseline_tna tna
--      ON hm.household_id       = tna.household_id
--      WHERE hm.etl_lst_btch_id > v_etllastbatchid
--      UNION
--      SELECT tna.individual_id
--      FROM undwr.f_undwr fuw -- UNDWR Tags 9/9/2015 JS
--      JOIN dm.wrk_premium_databaseline_tna tna
--      ON fuw.indv_id            = tna.individual_id
--      WHERE fuw.etl_lst_btch_id > v_uw_lastetlbatchid
--      UNION
--      SELECT tna.individual_id
--      FROM undwr.f_undwr fuw -- UNDWR Tags 9/9/2015 JS
--      JOIN dm.wrk_premium_databaseline_tna tna
--      ON fuw.insd_pln_id        = tna.insuredplan_id
--      WHERE fuw.etl_lst_btch_id > v_uw_lastetlbatchid
--      UNION --- Adding Cert Channel 8/05/2015
--      SELECT tna.individual_id
--      FROM dm.wrk_premium_databaseline_tna tna
--      INNER JOIN dm.wrk_ipacqchannel_chg ipac
--      ON tna.insuredplan_id = ipac.insuredplanid
--      UNION
--      SELECT tna.individual_id
--      FROM adt_compas.adt_household_profile adthp -- added for ACCT_NBR
--      JOIN dm.wrk_premium_databaseline_tna tna
--      ON adthp.household_id          = tna.household_id
--      WHERE adt_row_creat_by_btch_id > v_etllastbatchid
--      AND adt_typ_cd                 = ''D''
--      UNION
--      SELECT tna.individual_id --- added 1 11 2018
--      FROM adt_compas.adt_household_billing_profile adthbp
--      JOIN dm.wrk_premium_databaseline_tna tna
--      ON adthbp.household_id         = tna.household_id
--      WHERE adt_row_creat_by_btch_id > v_etllastbatchid
--      AND adt_typ_cd                 = ''D''
--      UNION
--      SELECT tna.individual_id --- added 1 11 2018
--      FROM adt_COMPAS.adt_billing_bucket_adjustment adtbbad
--      JOIN dm.wrk_premium_databaseline_tna tna
--      ON adtbbad.household_id        = tna.household_id
--      WHERE adt_row_creat_by_btch_id > v_etllastbatchid
--      AND adt_typ_cd                 = ''D''
--      UNION
--      SELECT tna.individual_id --- added 1 11 2018
--      FROM adt_COMPAS.adt_adjustment adtadj
--      JOIN adt_COMPAS.adt_billing_bucket_adjustment adtbbadj
--      ON adtadj.adjustment_id = adtbbadj.adjustment_id
--      JOIN dm.wrk_premium_databaseline_tna tna
--      ON adtbbadj.household_id              = tna.household_id
--      WHERE adtadj.adt_row_creat_by_btch_id > v_etllastbatchid
--      AND adtadj.adt_typ_cd                 = ''D''
--      UNION
--      SELECT tna.individual_id --- added 1 11 2018
--      FROM adt_COMPAS.adt_calculated_rate adtcal
--      JOIN adt_COMPAS.adt_ins_plan_billing_bucket adtipbbt
--      ON adtcal.calculated_rate_id = adtipbbt.calculated_rate_id
--      JOIN dm.wrk_premium_databaseline_tna tna
--      ON adtipbbt.household_id              = tna.household_id
--      WHERE adtcal.adt_row_creat_by_btch_id > v_etllastbatchid
--      AND adtcal.adt_typ_cd                 = ''D''
--      UNION
--      SELECT tna.individual_id
--      FROM adt_compas.adt_household_member adthm -- added for ACCT_NBR
--      JOIN dm.wrk_premium_databaseline_tna tna
--      ON adthm.household_id          = tna.household_id
--      WHERE adt_row_creat_by_btch_id > v_etllastbatchid
--      AND adt_typ_cd                 = ''D''
--      UNION
--      SELECT tna.individual_id-- Added for Legal Entity 04/19/2016
--      FROM compas.insured_plan_profile ipp
--      INNER JOIN dm.wrk_premium_databaseline_tna tna
--      ON ipp.insured_plan_id    = tna.insuredplan_id
--      WHERE ipp.etl_lst_btch_id > v_etllastbatchid
--      UNION
--      SELECT tna.individual_id-- Added for Legal Entity 04/19/2016
--      FROM adt_compas.adt_insured_plan_profile adtipp
--      INNER JOIN dm.wrk_premium_databaseline_tna tna
--      ON adtipp.insured_plan_id    = tna.insuredplan_id
--      WHERE adtipp.etl_lst_btch_id > v_etllastbatchid
--      UNION
--      SELECT tna.individual_id -- Added for Compas D_AGE_LOOK_FRACnt
--      FROM compas.insured_plan ip
--      JOIN compas.application a
--      ON ip.application_id = a.application_id
--      JOIN dm.wrk_premium_databaseline_tna tna
--      ON ip.insured_plan_id   = tna.insuredplan_id
--      WHERE a.etl_lst_btch_id > v_etllastbatchid
--      UNION
--      SELECT tna.individual_id -- Added for Compas D_AGE_LOOK_FRACnt
--      FROM compas.insured_plan ip
--      JOIN compas.application a
--      ON ip.application_id = a.application_id
--      JOIN compas.application_agent ag
--      ON a.application_id = ag.application_id
--      JOIN dm.wrk_premium_databaseline_tna tna
--      ON ip.insured_plan_id    = tna.insuredplan_id
--      WHERE ag.etl_lst_btch_id > v_etllastbatchid
--      UNION
--      SELECT tna.individual_id ----  Added for Compas D_AGE_LOOK_FRACnt
--      FROM compas.insured_plan ip
--      JOIN adt_compas.adt_application adta
--      ON ip.application_id = adta.application_id
--      JOIN dm.wrk_premium_databaseline_tna tna
--      ON ip.insured_plan_id          = tna.insuredplan_id
--      WHERE adt_row_creat_by_btch_id > v_etllastbatchid
--      AND adt_typ_cd                 = ''D''
--      UNION
--      SELECT tna.individual_id ----  Added for Compas D_AGE_LOOK_FRACnt
--      FROM compas.insured_plan ip
--      JOIN compas.application a
--      ON ip.application_id = a.application_id
--      JOIN adt_compas.adt_application_agent adtag
--      ON a.application_id = adtag.application_id
--      JOIN dm.wrk_premium_databaseline_tna tna
--      ON ip.insured_plan_id          = tna.insuredplan_id
--      WHERE adt_row_creat_by_btch_id > v_etllastbatchid
--      AND adt_typ_cd                 = ''D''
--    );
--  V_ROWS_AFFTD:=SQL%ROWCOUNT;
--  COMMIT;
--  DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''TEMP_BASELINE_REBULD_DISTINDID'');
--  --DBMS_STATS.GATHER_TABLE_STATS (OWNNAME => ''DM'',TABNAME => ''TEMP_BASELINE_REBULD_DISTINDID'',PARTNAME => NULL,ESTIMATE_PERCENT => 10, DEGREE => 4, GRANULARITY => ''ALL'', METHOD_OPT => ''FOR ALL COLUMNS SIZE 1'',CASCADE => TRUE);
--  INSERT
--  INTO ETL.ETL_DETAIL_LOAD_INFO
--    (
--      APPLICATION ,
--      ETL_BATCH_ID,
--      ETL_PROC_NAME ,
--      ACTION ,
--      STEP_INFO ,
--      ROWS_AFFECTED ,
--      ETL_DATETIME
--    )
--    VALUES
--    (
--      ''DERIVATIVE PREMIUM1'',
--      V_BTCH_ID,
--      V_PROC_NAME,
--      ''INSERT'',
--      ''Insert into temp table TEMP_BASELINE_REBULD_DISTINDID'',
--      V_ROWS_AFFTD,
--      SYSTIMESTAMP
--    );
  
V_STEP_NAME    := ''INSERT - TEMP_MONTH_DATE'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

  INSERT
  INTO BDR_DM.TEMP_MONTH_DATE
    (SELECT TO_DATE(TO_CHAR(ADD_MONTHS(TRUNC(add_months(:V_ACTIVITY_DATE,-1*:V_ETLNUMBEROFMONTHSBACK),''YEAR''),L),''DD/MM/YYYY''),''DD/MM/YYYY'') AS MonthDate
      FROM
        (/* SELECT LEVEL-1 L
        FROM DUAL
          CONNECT BY LEVEL < =--168
          ROUND(MONTHS_BETWEEN(v_confmonth,TRUNC(add_months(:V_ACTIVITY_DATE,-1*V_ETLNUMBEROFMONTHSBACK),''YEAR'')) ) */		-------------OAS DELETE
		WITH RECURSIVE LEVEL_CTE(L) AS (
			SELECT 0 AS L
			UNION ALL
			SELECT L+1
			FROM LEVEL_CTE
			WHERE L+1 <= ROUND(MONTHS_BETWEEN(
				TO_DATE(:V_CONFMONTH, ''YYYY-MM-DD''),TRUNC(add_months(TO_DATE(:V_ACTIVITY_DATE, ''YYYY-MM-DD''),-1*:V_ETLNUMBEROFMONTHSBACK),''YEAR'')
				)
			)
		)
		SELECT L FROM LEVEL_CTE														-------------------OAS ADD
        )
         WHERE TO_DATE(TO_CHAR(ADD_MONTHS(TRUNC(add_months(:V_ACTIVITY_DATE,-1*:V_ETLNUMBEROFMONTHSBACK),''YEAR''),L),''DD/MM/YYYY''),''DD/MM/YYYY'') < :V_AOP_LIVE_DATE     ----Adding in US118151
    );
	    	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

  -------------------------------------COMMENTED BY OAS-------------------------------------
/*
V_ROWS_AFFTD:=SQL%ROWCOUNT;
  INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''DERIVATIVE PREMIUM1'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''INSERT'',
      ''Insert into temp table TEMP_MONTH_DATE'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );
*/
-------------------------------------COMMENTED BY OAS-------------------------------------


--
-- INSERT /*+ append */          -- DISABLED FOR RetroAct+RIA MERGE
--  INTO DM.WRK_INSD_PLN_PRFL_OVRLP_TMP
--  SELECT
--    /*+ Parallel (8)*/
--    DISTINCT a1.*
--  FROM CONF.D_INSD_PLN_PRFL a1
--  JOIN CONF.D_INSD_PLN_PRFL a2
--  ON a1.SRC_INSD_PLN_ID         = a2.SRC_INSD_PLN_ID
--  AND a1.SRC_DEL_FLG            = a2.SRC_DEL_FLG
--  AND a1.INSD_PLN_PRFL_STRT_DT <= a2.INSD_PLN_PRFL_STOP_DT
--  AND a1.INSD_PLN_PRFL_STOP_DT >= a2.INSD_PLN_PRFL_STRT_DT
--  AND a1.INSD_PLN_PRFL_STRT_DT != a2.INSD_PLN_PRFL_STRT_DT;
--  COMMIT;
--
--
--
--  INSERT /*+ append */
--  INTO DM.WRK_INSD_PLN_PRFL_OVRLP_TMP2
--  SELECT
--    /*+ Parallel (8)*/
--    *
--  FROM
--    (SELECT D_INSD_PLN_PRFL_SK,
--      INSD_PLN_PRFL_STOP_DT,
--      INSD_PLN_PRFL_STRT_DT,
--      SRC_INSD_PLN_ID,
--      SRC_DEL_FLG,
--      ENT_AGE,
--      ROW_NUMBER () OVER (PARTITION BY SRC_INSD_PLN_ID ORDER BY INSD_PLN_PRFL_STOP_DT DESC, INSD_PLN_PRFL_STRT_DT DESC) AS RN,
--      SRC_INSD_PLN_PRFL_ID
--    FROM DM.WRK_INSD_PLN_PRFL_OVRLP_TMP
--    )
--  WHERE RN = 1;
--  COMMIT;
--
--
--  INSERT /*+ append */
--  INTO DM.WRK_INSD_PLN_PRFL_OVRLP_TMP3
--  SELECT
--    /*+ Parallel (8)*/
--    D_INSD_PLN_PRFL_SK,
--    INSD_PLN_PRFL_STOP_DT,
--    INSD_PLN_PRFL_STRT_DT,
--    SRC_INSD_PLN_ID,
--    SRC_DEL_FLG,
--    ENT_AGE,
--    SRC_INSD_PLN_PRFL_ID
--  FROM DM.WRK_INSD_PLN_PRFL_OVRLP_TMP2
--  UNION
--  SELECT D_INSD_PLN_PRFL_SK,
--    INSD_PLN_PRFL_STOP_DT,
--    INSD_PLN_PRFL_STRT_DT,
--    SRC_INSD_PLN_ID,
--    SRC_DEL_FLG,
--    ENT_AGE,
--    SRC_INSD_PLN_PRFL_ID
--  FROM CONF.D_INSD_PLN_PRFL
--  WHERE D_INSD_PLN_PRFL_SK NOT IN
--    ( SELECT D_INSD_PLN_PRFL_SK FROM DM.WRK_INSD_PLN_PRFL_OVRLP_TMP
--    );
--  COMMIT;
--
--
--  INSERT /*+ append */
--  INTO DM.WRK_INSD_PLN_PRFL_TMP
--  SELECT
--    /*+ Parallel (8)*/
--    D_INSD_PLN_PRFL_SK,
--    INSD_PLN_PRFL_STOP_DT,
--    INSD_PLN_PRFL_STRT_DT,
--    SRC_INSD_PLN_ID,
--    SRC_DEL_FLG,
--    ENT_AGE,
--    ROW_NUMBER () OVER (PARTITION BY SRC_INSD_PLN_ID, INSD_PLN_PRFL_STOP_DT, INSD_PLN_PRFL_STRT_DT ORDER BY SRC_DEL_FLG) AS R,
--    SRC_INSD_PLN_PRFL_ID
--  FROM DM.WRK_INSD_PLN_PRFL_OVRLP_TMP3;
--  COMMIT;

  
V_STEP_NAME    := ''INSERT - WRK_INSD_PLN_PRFL_TMP2'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

  INSERT /*+ append */
  INTO BDR_DM.WRK_INSD_PLN_PRFL_TMP2
  SELECT /*+ Parallel */
    * FROM BDR_DM.WRK_INSD_PLN_PRFL_TMP WHERE R = 1;
--  COMMIT;
    	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

-------------------------------------COMMENTED BY OAS-------------------------------------
/*   DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''WRK_INSD_PLN_PRFL_TMP2'');

  DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''TEMP_MONTH_DATE''); */
-------------------------------------COMMENTED BY OAS-------------------------------------
  
  --DBMS_STATS.GATHER_TABLE_STATS (OWNNAME => ''DM'',TABNAME => ''TEMP_MONTH_DATE'',PARTNAME => NULL,ESTIMATE_PERCENT => 10, DEGREE => 4, GRANULARITY => ''ALL'', METHOD_OPT => ''FOR ALL COLUMNS SIZE 1'',CASCADE => TRUE);
    
V_STEP_NAME    := ''INSERT - wrk_premium_data_bl_rebuild'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

  INSERT
    /*+ ENABLE_PARALLEL_DML APPEND */
  INTO BDR_DM.wrk_premium_data_bl_rebuild
    (
      household_id,
      individual_id,
      ins_plan_billing_bucket_id,
      insured_plan_id,
      household_address_id,
      premium_due_date,
      activity_date,
      paid_cert,
      del_cert,
      term_cert,
      paid_premium_amt,
      delinquent_premium_due_amt,
      plan_cd,
      benefit_mod_category_id,
      insured_plan_effective_date,
      insured_plan_termination_date,
      cert_termination_date,
      state_cd,
      zip_cd,
      country_cd,
      issue_state,
      issue_country_cd,
      issue_zip_cd,
      gender_cd,
      date_of_birth,
      etl_lst_btch_id,
      cert_acqn_chnl_level3,
      account_number,
      termination_reason_name,
      conservation_reason_name,
      plan_group,
      product_group,
      cert_actv_lvl_3_txt,
      undwr_tag_key,
      prdct_eff_dt,
      prdct_acqn_chnl_level3,
      legal_entity_name,
      mbr_pd_prem_amt,
      mbr_delq_prem_amt,
      er_pd_prem_amt,
      er_delq_prem_amt,
      current_signature_date,
      original_signature_date,
      original_insuredplan_id,
      writing_agent,
      selling_agent,
      original_selling_agent,
      ret_typ_id,
      er_skey,
      dcm_insured_plan_id,
      dcm_insured_plan_eff_date,
      dcm_plan_cd,
      dcm_signature_date,
      dcm_writing_agent,
      dcm_derived_compas_agent,
      agt_wrt_skey,
      agt_sel_orig_skey,
      agt_sel_skey,
      agt_dcm_wrt_skey,
      D_DSCNT_ANNL_PAYR_SK,
      D_DSCNT_EFT_SK,
      D_DSCNT_ERLY_ENRL_SK,
      D_DSCNT_LNGVTY_SK,
      D_DSCNT_MULTI_INSD_SK,
      D_SURCHRG_TBCC_USER_SK,
      D_SURCHRG_TIER_SK,
      D_INSD_PLN_PRFL_SK,
      D_CALC_RT_SK,
      MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
      DSCNT_PD_ANNL_PAYR_AMT,
      DSCNT_PD_EFT_AMT,
      DSCNT_PD_ERLY_ENRL_AMT,
      DSCNT_PD_LNGVTY_AMT,
      DSCNT_PD_MULTI_INSD_AMT,
      SURCHRG_PD_TBCC_USER_AMT,
      SURCHRG_PD_TIER_AMT,
      DSCNT_DELQ_ANNL_PAYR_AMT,
      DSCNT_DELQ_EFT_AMT,
      DSCNT_DELQ_ERLY_ENRL_AMT,
      DSCNT_DELQ_LNGVTY_AMT,
      DSCNT_DELQ_MULTI_INSD_AMT,
      SURCHRG_DELQ_TBCC_USER_AMT,
      SURCHRG_DELQ_TIER_AMT,
      ORIGINAL_REFERRAL_AGENT,
      REFERRAL_AGENT,
      AGT_REF_ORIG_D_AGT_SK,
      AGT_REF_D_AGT_SK,
      D_MBR_INFO_SK,
      D_PLN_BEN_MOD_SK,
      RES_D_GEO_XREF_SK,
      PLN_ISS_D_GEO_XREF_SK,
      D_RTNG_AREA_SK,
      F_APPL_TRANS_DAY_SK,
	   CERT_SALE_CHNL_LVL_1,
      CERT_SALE_CHNL_LVL_2,
      CERT_SALE_CHNL_LVL_3,
	  D_NEW_TO_MEDCR_SK,
	  DSCNT_PD_NEW_TO_MEDCR_AMT,
	  DSCNT_DLQNT_NEW_TO_MEDCR_AMT
    )
   SELECT  /*+ PARALLEL (8) */
    RBL.household_id,
      RBL.individual_id,
      RBL.insplan_billingbucket_id AS ins_plan_billing_bucket_id,
      RBL.insuredplan_id AS insured_plan_id,
      RBL.household_addressid AS household_address_id,
      RBL.premiumdue_dt AS premium_due_date,
      RBL.activity_date,
      RBL.paidcert AS paid_cert,
      RBL.delcert AS del_cert,
      RBL.termcert AS term_cert,
      RBL.pd_prem_amt AS paid_premium_amt,
      RBL.delinquentpremium_due_amt AS delinquent_premium_due_amt,
      RBL.plan_cd,
      RBL.plan_cdbenmodcat AS benefit_mod_category_id,
      RBL.insuredplan_effectivedate AS insured_plan_effective_date,
      RBL.insuredplan_terminationdate AS insured_plan_termination_date,
      RBL.certterminationdate AS cert_termination_date,
      RBL.d_st_cd AS state_cd,
      RBL.zip_cd,
      RBL.cntry_cd AS country_cd,
      RBL.issue_state,
      RBL.issue_country_cd,
      RBL.issue_zip_cd,
      RBL.gender_cd,
      RBL.date_of_birth,
      RBL.etl_lst_btch_id,
      RBL.cert_acqn_chnl_level3,
      RBL.acct_nbr AS account_number,
      RBL.termination_reason_name,
      RBL.conservation_reason_name,
      RBL.pln_grp AS plan_group,
      RBL.prdct_grp AS product_group,
      RBL.cert_actv_lvl_3_txt,
      RBL.d_undwr_tag_sk AS undwr_tag_key,
      RBL.prdct_eff_dt,
      RBL.prdct_acqn_chnl_level3,
      RBL.legal_entity_name,
      RBL.mbr_pd_prem_amt,
      RBL.mbr_delq_prem_amt,
      RBL.emp_pd_prem_amt AS er_pd_prem_amt,
      RBL.emp_delq_prem_amt AS er_delq_prem_amt,
      RBL.current_signature_date,
      RBL.original_signature_date,
      RBL.original_insured_plan_id AS original_insuredplan_id,
      RBL.writing_agent,
      RBL.selling_agent,
      RBL.original_selling_agent,
      RBL.ret_typ_id,
      RBL. d_emp_sk AS er_skey,
      RBL.dcm_insured_plan_id AS cm_insured_plan_id,
      RBL.dcm_insd_pln_eff_dt AS dcm_insured_plan_eff_date,
      RBL.dcm_plan_cd,
      RBL.dcm_signature_date,
      RBL.dcm_writing_agent,
      RBL.dcm_derived_compas_agent,
      RBL.agt_wrt_d_agt_sk AS agt_wrt_skey,
      RBL.agt_sel_orig_d_agt_sk AS agt_sel_orig_skey,
      RBL.agt_sel_d_agt_sk AS agt_sel_skey,
      RBL.agt_dcm_wrt_d_agt_sk AS agt_dcm_wrt_skey,
      RBL.D_DSCNT_ANNL_PAYR_SK,
      RBL.D_DSCNT_EFT_SK,
      RBL.D_DSCNT_ERLY_ENRL_SK,
      RBL.D_DSCNT_LNGVTY_SK,
      RBL.D_DSCNT_MULTI_INSD_SK,
      RBL.D_SURCHRG_TBCC_USER_SK,
      RBL.D_SURCHRG_TIER_SK,
      RBL.D_INSD_PLN_PRFL_SK,
      RBL.D_CALC_RT_SK,
      RBL.MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
      RBL.DSCNT_PD_ANNL_PAYR_AMT,
      RBL.DSCNT_PD_EFT_AMT,
      RBL.DSCNT_PD_ERLY_ENRL_AMT,
      RBL.DSCNT_PD_LNGVTY_AMT,
      RBL.DSCNT_PD_MULTI_INSD_AMT,
      RBL.SURCHRG_PD_TBCC_USER_AMT,
      RBL.SURCHRG_PD_TIER_AMT,
      RBL.DSCNT_DELQ_ANNL_PAYR_AMT,
      RBL.DSCNT_DELQ_EFT_AMT,
      RBL.DSCNT_DELQ_ERLY_ENRL_AMT,
      RBL.DSCNT_DELQ_LNGVTY_AMT,
      RBL.DSCNT_DELQ_MULTI_INSD_AMT,
      RBL.SURCHRG_DELQ_TBCC_USER_AMT,
      RBL.SURCHRG_DELQ_TIER_AMT,
      RBL.ORIGINAL_REFERRAL_AGENT,
      RBL.REFERRAL_AGENT,
      RBL.AGT_REF_ORIG_D_AGT_SK,
      RBL.AGT_REF_D_AGT_SK,
     	   CASE WHEN RBL.INDIVIDUAL_ID = MI.INDV_ID THEN MI.D_MBR_INFO_SK ELSE -1 END D_MBR_INFO_SK,
	   PBM.D_PLN_BEN_MOD_SK,
           CASE WHEN RG.D_ST_CD IS NOT NULL THEN RG.D_GEO_XREF_SK ELSE -1 END RES_D_GEO_XREF_SK,

--US89097- Issue State Billing Zip Code Filter Date

	   CASE WHEN RBL.insuredplan_effectivedate >=TO_DATE(''2020-01-01'',''YYYY-MM-DD'') THEN
	    CASE WHEN (LTRIM(RTRIM(RBL.STATE_PLAN_BILLING_ID)) IS NOT NULL AND LTRIM(RTRIM(SPB.STATE_CD)) IS NOT NULL)
	   THEN NVL(AR1.D_GEO_XREF_SK,-1) ELSE -1 END
	   ELSE NVL(RX.D_GEO_XREF_SK , -1) END PLN_ISS_D_GEO_XREF_SK,

	   CASE WHEN RA.D_ST_CD IS NOT NULL THEN RA.D_RTNG_AREA_SK ELSE -1 END D_RTNG_AREA_SK,
      RBL.F_APPL_TRANS_DAY_SK,
	  RBL.SALE_CHNL_LVL_1,
		RBL.SALE_CHNL_LVL_2,
		RBL.SALE_CHNL_LVL_3,
	  RBL.D_NEW_TO_MEDCR_SK,
	  RBL.DSCNT_PD_NEW_TO_MEDCR_AMT,
	  RBL.DSCNT_DLQNT_NEW_TO_MEDCR_AMT
         FROM
  (SELECT
      /*+ PARALLEL (8) */
    DISTINCT demo.household_id,
    demo.individual_id,
    demo.insplan_billingbucket_id,
    demo.insuredplan_id,
    NVL(ha.household_address_id,-1) AS household_addressid, --nvl for HHOLDAddress fix JS 9/9
    NVL(ar.due_date,cd.monthdate)   AS premiumdue_dt,
   :V_ACTIVITY_DATE                  AS activity_date,
    CASE
      WHEN ( ( demo.insuredplan_terminationdate IS NULL
      AND TO_DATE(''9999-12-31'',''YYYY-MM-DD'')    <= cd.monthdate )
      OR ( cd.monthdate                          = NVL(demo.individual_profile_startdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')) ) )
      THEN 0--''Y''
      WHEN ( ( demo.insuredplan_terminationdate                                                                                                                                                IS NOT NULL
      AND TRUNC(add_months(TO_DATE(REPLACE(TO_CHAR(demo.insuredplan_terminationdate,''YYYY-MM-DD HH24:MI:SS''/* ''RRRR-MM-DD HH24:MI:SS'' */),''9999-12-31 00:00:00'',''9999-11-30 00:00:00''),''YYYY-MM-DD HH24:MI:SS''/* ''RRRR-MM-DD HH24:MI:SS'' */),1),''MONTH'') <= cd.monthdate )
      OR ( cd.monthdate                                                                                                                                                                         = NVL(demo.individual_profile_startdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')) ) )
      THEN 0--''Y''
      WHEN ( ar.due_date IS NULL )
      OR ( cd.monthdate BETWEEN NVL(demo.individual_profile_startdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')) AND NVL(demo.individual_profile_stopdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')) )
      THEN 0--''S''
      ELSE
        CASE
          WHEN ( SUM(ar.due_amount) > 0
          AND ( SUM(ar.paid_amount) = SUM(ar.due_amount) ) )--''N''
          THEN 1
          ELSE 0
        END
    END paidcert,
    CASE
      WHEN ( ( demo.insuredplan_terminationdate IS NULL
      AND TO_DATE(''9999-12-31'',''YYYY-MM-DD'')    <= cd.monthdate )
      OR ( cd.monthdate                          = NVL(demo.individual_profile_startdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')) ) )
      THEN 0--''Y''
      WHEN ( ( demo.insuredplan_terminationdate                                                                                                                                                IS NOT NULL
      AND TRUNC(add_months(TO_DATE(REPLACE(TO_CHAR(demo.insuredplan_terminationdate,''YYYY-MM-DD HH24:MI:SS''/* ''RRRR-MM-DD HH24:MI:SS'' */),''9999-12-31 00:00:00'',''9999-11-30 00:00:00''),''YYYY-MM-DD HH24:MI:SS''/* ''RRRR-MM-DD HH24:MI:SS'' */),1),''MONTH'') <= cd.monthdate )
      OR ( cd.monthdate                                                                                                                                                                         = NVL(demo.individual_profile_startdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')) ) )
      THEN 0--''Y''
      WHEN ( ar.due_date IS NULL )
      OR ( cd.monthdate BETWEEN NVL(demo.individual_profile_startdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')) AND NVL(demo.individual_profile_stopdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')) )
      THEN 0--''S''
      ELSE
        CASE
          WHEN ( SUM(ar.due_amount) > 0
          AND ( SUM(ar.paid_amount) < SUM(ar.due_amount) ) )--''N''
          THEN 1
          ELSE 0
        END
    END delcert,
    CASE
      WHEN ( ( demo.insuredplan_terminationdate IS NULL
      AND TO_DATE(''9999-12-31'',''YYYY-MM-DD'')    <= cd.monthdate )
      OR ( cd.monthdate                          = NVL(demo.individual_profile_startdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')) ) )
      THEN 1--''Y''
      WHEN ( ( demo.insuredplan_terminationdate                                                                                                                                               IS NOT NULL
      AND TRUNC(add_months(TO_DATE(REPLACE(TO_CHAR(demo.insuredplan_terminationdate,''YYYY-MM-DD HH24:MI:SS''/* ''RRRR-MM-DD HH24:MI:SS'' */),''9999-12-31 00:00:00'',''9999-11-30 00:00:00''),''YYYY-MM-DD HH24:MI:SS''/* ''RRRR-MM-DD HH24:MI:SS'' */),1),''MONTH'')<= cd.monthdate )
      OR ( cd.monthdate                                                                                                                                                                        = NVL(demo.individual_profile_startdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')) ) )
      THEN 1--''Y''
      WHEN ( ar.due_date IS NULL )
      OR ( cd.monthdate BETWEEN NVL(demo.individual_profile_startdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')) AND NVL(demo.individual_profile_stopdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')) )
      THEN 0--''S''
      ELSE 0
    END termcert,
    CASE
      WHEN ( ( demo.insuredplan_terminationdate IS NULL
      AND TO_DATE(''9999-12-31'',''YYYY-MM-DD'')    <= cd.monthdate )
      OR ( cd.monthdate                          = NVL(demo.individual_profile_startdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')) ) )
      THEN 0--''Y''
      WHEN ( ( demo.insuredplan_terminationdate                                                                                                                                                IS NOT NULL
      AND TRUNC(add_months(TO_DATE(REPLACE(TO_CHAR(demo.insuredplan_terminationdate,''YYYY-MM-DD HH24:MI:SS''/* ''RRRR-MM-DD HH24:MI:SS'' */),''9999-12-31 00:00:00'',''9999-11-30 00:00:00''),''YYYY-MM-DD HH24:MI:SS''/* ''RRRR-MM-DD HH24:MI:SS'' */),1),''MONTH'') <= cd.monthdate )
      OR ( cd.monthdate                                                                                                                                                                         = NVL(demo.individual_profile_startdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')) ) )
      THEN 0--''Y''
      WHEN ( ar.due_date IS NULL )
      OR ( cd.monthdate BETWEEN NVL(demo.individual_profile_startdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')) AND NVL(demo.individual_profile_stopdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')) )
      THEN 0--''S''
      ELSE
        CASE
          WHEN ( SUM(ar.due_amount) > 0
          AND ( SUM(ar.paid_amount) = SUM(ar.due_amount) ) )--''N''
          THEN demo.premium_dueamt
          ELSE 0
        END
    END pd_prem_amt,
    CASE
      WHEN ( ( demo.insuredplan_terminationdate IS NULL
      AND TO_DATE(''9999-12-31'',''YYYY-MM-DD'')    <= cd.monthdate )
      OR ( cd.monthdate                          = NVL(demo.individual_profile_startdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')) ) )
      THEN 0--''Y''
      WHEN ( ( demo.insuredplan_terminationdate                                                                                                                                                IS NOT NULL
      AND TRUNC(add_months(TO_DATE(REPLACE(TO_CHAR(demo.insuredplan_terminationdate,''YYYY-MM-DD HH24:MI:SS''/* ''RRRR-MM-DD HH24:MI:SS'' */),''9999-12-31 00:00:00'',''9999-11-30 00:00:00''),''YYYY-MM-DD HH24:MI:SS''/* ''RRRR-MM-DD HH24:MI:SS'' */),1),''MONTH'') <= cd.monthdate )
      OR ( cd.monthdate                                                                                                                                                                         = NVL(demo.individual_profile_startdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')) ) )
      THEN 0--''Y''
      WHEN ( ar.due_date IS NULL )
      OR ( cd.monthdate BETWEEN NVL(demo.individual_profile_startdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')) AND NVL(demo.individual_profile_stopdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')) )
      THEN 0--''S''
      ELSE
        CASE
          WHEN ( SUM(ar.due_amount) > 0
          AND ( SUM(ar.paid_amount) < SUM(ar.due_amount) ) )--''N''
          THEN demo.premium_dueamt
          ELSE 0
        END
    END delinquentpremium_due_amt,
    demo.plan_cd,
    NVL(ipbenmod.plancd_benmodcat,0) AS plan_cdbenmodcat,
    demo.insuredplan_effectivedate,
    demo.insuredplan_terminationdate,
    CASE
      WHEN ((demo.insuredplan_terminationdate IS NULL
      AND TO_DATE(''9999-12-31'',''YYYY-MM-DD'')  <= cd.monthdate)
      OR (cd.monthdate                         = NVL(demo.individual_profile_startdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD''))))
      THEN cd.MonthDate
      WHEN ((demo.insuredplan_terminationdate                                                                                                                                                  IS NOT NULL
      AND TRUNC(add_months(TO_DATE(REPLACE(TO_CHAR(demo.insuredplan_terminationdate,''YYYY-MM-DD HH24:MI:SS''/* ''RRRR-MM-DD HH24:MI:SS'' */),''9999-12-31 00:00:00'',''9999-11-30 00:00:00''),''YYYY-MM-DD HH24:MI:SS''/* ''RRRR-MM-DD HH24:MI:SS'' */),1),''MONTH'') <= cd.monthdate)
      OR (cd.monthdate                                                                                                                                                                          = NVL(demo.individual_profile_startdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD''))))
      THEN cd.MonthDate
      WHEN (ar.due_date IS NULL)
      OR (cd.monthdate BETWEEN NVL(demo.individual_profile_startdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')) AND NVL(demo.individual_profile_stopdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')))
      THEN NULL
      ELSE NULL
    END certterminationdate,
    NVL(ha.state_cd,''ZZ'')   AS d_st_cd,  --nvl for HHOLDAddress fix JS 9/9
    NVL(ha.zip_cd,''99999'')  AS zip_cd,   --nvl for HHOLDAddress fix JS 9/9
    NVL(ha.country_cd,''ZZ'') AS cntry_cd, --nvl for HHOLDAddress fix JS 9/9
    demo.issue_state,
    demo.issue_country_cd,
    demo.issue_zip_cd,
    demo.gender_cd,
    demo.date_of_birth,
    --v_etlcurrentbatchid AS etl_lst_btch_id,			--------------------OAS DELETE
	:V_BATCH_ID AS etl_lst_btch_id,			--------------------OAS ADD
    demo.cert_acqn_chnl_level3, -- Adding Cert Channel 8/4/2015
    NVL(an.account_number,''-1'') AS acct_nbr,
    demo.termination_reason_name, --Added 20150825,Cert Activity
    demo.conservation_reason_name,
    pbm.pln_grp,
    pbm.prdct_grp,
    ''UNKNOWN''               AS cert_actv_lvl_3_txt,
    NVL(uw.d_uw_tag_key,-1) AS d_undwr_tag_sk,         --UNDWR JS 9/9/2015
    NULL                    AS prdct_eff_dt,           -- Adding PRDCT Eff Dt 4/9/2016
    NULL                    AS prdct_acqn_chnl_level3, -- Adding Prdct Acq Chnl 4/9/2016
    le.legal_entity_name,                              -- Added for Legal Entity 04/19/2016
    le.LEGAL_ENTITY_CATEGORY_ID,
    0.00 mbr_pd_prem_amt,
    0.00 mbr_delq_prem_amt,
    0.00 emp_pd_prem_amt,
    0.00 emp_delq_prem_amt,
    NULL AS current_signature_date,
    NULL AS original_signature_date,
    NULL AS original_insured_plan_id,
    NULL AS writing_agent,          -- Adding Wrt D_AGE_LOOK_FRACnt 9/21/2016
    NULL AS selling_agent,          -- Adding Sel D_AGE_LOOK_FRACnt 9/21/2016
    NULL AS original_selling_agent, -- Added OrigSel D_AGE_LOOK_FRACnt 9/21/2016
    demo.ret_typ_id,
    -2 d_emp_sk,
    NULL AS dcm_insured_plan_id,
    NULL AS dcm_insd_pln_eff_dt,
    NULL AS dcm_plan_cd,
    NULL AS dcm_signature_date,
    NULL AS dcm_writing_agent,
    NULL AS dcm_derived_compas_agent,
    -1   AS agt_wrt_d_agt_sk,
    -1   AS agt_sel_orig_d_agt_sk,
    -1   AS agt_sel_d_agt_sk,
    -1   AS agt_dcm_wrt_d_agt_sk,
    demo.D_DSCNT_ANNL_PAYR_SK,
    1 AS D_DSCNT_EFT_SK,
    demo.D_DSCNT_ERLY_ENRL_SK,
    demo.D_DSCNT_LNGVTY_SK,
    demo.D_DSCNT_MULTI_INSD_SK,
    NVL(tbcc.D_SURCHRG_TBCC_USER_SK,demo.D_SURCHRG_TBCC_USER_SK) D_SURCHRG_TBCC_USER_SK, -- SCR61587 28Jun2018
    NVL(st.D_SURCHRG_TIER_SK,demo.D_SURCHRG_TIER_SK) D_SURCHRG_TIER_SK,                  -- SCR61587 28Jun2018
    -1 AS D_INSD_PLN_PRFL_SK,
    demo.D_CALC_RT_SK,
    0 AS MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
    0 AS DSCNT_PD_ANNL_PAYR_AMT,
    0 AS DSCNT_PD_EFT_AMT,
    0 AS DSCNT_PD_ERLY_ENRL_AMT,
    0 AS DSCNT_PD_LNGVTY_AMT,
    0 AS DSCNT_PD_MULTI_INSD_AMT,
    0 AS SURCHRG_PD_TBCC_USER_AMT,
    0 AS SURCHRG_PD_TIER_AMT,
    0 AS DSCNT_DELQ_ANNL_PAYR_AMT,
    0 AS DSCNT_DELQ_EFT_AMT,
    0 AS DSCNT_DELQ_ERLY_ENRL_AMT,
    0 AS DSCNT_DELQ_LNGVTY_AMT,
    0 AS DSCNT_DELQ_MULTI_INSD_AMT,
    0 AS SURCHRG_DELQ_TBCC_USER_AMT,
    0 AS SURCHRG_DELQ_TIER_AMT,
    NULL AS ORIGINAL_REFERRAL_AGENT,
    NULL AS REFERRAL_AGENT,
    -2   AS AGT_REF_ORIG_D_AGT_SK,
    -2   AS AGT_REF_D_AGT_SK,
     CASE WHEN  NVL(ha.country_cd,''ZZ'')IN (''PR'', ''VI'',''GU'',''AS'',''MP'') AND NVL(ha.state_cd,''ZZ'') =''XX''
		   THEN NVL(ha.country_cd,''ZZ'')
     	   ELSE NVL(ha.state_cd,''ZZ'') END AS STATECD_DER,
       CASE WHEN (NVL(ha.country_cd,''ZZ'')= ''US'') OR (NVL(ha.state_cd,''ZZ'') IN (''PR'',''VI'',''GU'',''AS'',''MP'')) OR (/*PDT.STATECD = ''XX'' AND*/  NVL(ha.country_cd,''ZZ'')IN (''PR'', ''VI'',''GU'',''AS'',''MP''))
                    THEN SUBSTR(NVL(ha.zip_cd,''99999''),1,5)
           ELSE NVL(ha.zip_cd,''99999'') END AS ZIP_CD_DER,
       CASE WHEN (NVL(ha.state_cd,''ZZ'') IN (''PR'',''VI'',''GU'',''AS'',''MP''))  OR (NVL(ha.country_cd,''ZZ'')IN (''PR'',''VI'',''GU'',''AS'',''MP'') /*AND PDT.STATECD =''XX''*/)
                    THEN ''US''
	   ELSE  NVL(ha.country_cd,''ZZ'') END AS COUNTRY_CD_DER,

       CASE WHEN demo.issue_country_cd IN (''PR'', ''VI'',''GU'',''AS'',''MP'') AND demo.issue_state =''XX''
		    THEN demo.issue_country_cd
     	   ELSE demo.issue_state END AS ISSUE_STATE_DER,
       CASE WHEN (demo.issue_country_cd = ''US'') OR (demo.issue_state IN (''PR'',''VI'',''GU'',''AS'',''MP'')) OR (/*PDT.ISSUESTATE = ''XX'' AND*/ demo.issue_country_cd IN (''PR'', ''VI'',''GU'',''AS'',''MP''))
                    THEN SUBSTR(NVL(demo.issue_zip_cd,''99999''),1,5)
           ELSE NVL(demo.issue_zip_cd,''99999'') END AS ISSUE_ZIP_CD_DER,
       CASE WHEN (demo.issue_state IN (''PR'',''VI'',''GU'',''AS'',''MP'')) OR (demo.issue_country_cd IN (''PR'',''VI'',''GU'',''AS'',''MP'') /*AND PDT.ISSUESTATE =''XX''*/)
		    THEN ''US''
	   ELSE demo.issue_country_cd END AS ISSUE_COUNTRY_CD_DER,
        nvl(appl.F_APPL_TRANS_DAY_SK, -1) as F_APPL_TRANS_DAY_SK,
		IPP.STATE_PLAN_BILLING_ID,
		IPP.BILLING_ZIP_CD,
		demo.SALE_CHNL_LVL_1,
		demo.SALE_CHNL_LVL_2,
		demo.SALE_CHNL_LVL_3,
	  demo.D_NEW_TO_MEDCR_SK,
	  0 AS DSCNT_PD_NEW_TO_MEDCR_AMT,
	  0 AS DSCNT_DLQNT_NEW_TO_MEDCR_AMT
  FROM BDR_DM.wrk_compas_demographicdata demo
  JOIN BDR_DM.temp_baseline_rebuld_distindid indvid
  ON indvid.individual_id = demo.individual_id
  JOIN BDR_DM.TEMP_MONTH_DATE cd
  ON cd.monthdate BETWEEN demo.billingbucket_startdate AND demo.der_billingbucket_stopdate
  LEFT OUTER JOIN SRC_COMPAS_D.household_address ha
  ON demo.household_id = ha.household_id --Added for HHOLDAddress fix by Jignesh Shah 9/9/2015
  AND cd.monthdate BETWEEN ha.hhold_addr_start_date AND ha.hhold_addr_stop_date
  AND ( ha.address_type_id  = 1
  AND NVL(ha.delete_ind,''N'') = ''N'' )
  LEFT JOIN SRC_COMPAS_D.ACCOUNT_RECEIVABLE ar
  ON ( demo.household_id            = ar.household_id --Changed Demo.HOUSEHOLD_ID instead of AR.HOUSEHOLD_ID
  AND ar.due_date                   = cd.monthdate
  AND ar.acct_receivable_type_id    = 2         -- premium
  AND ar.responsible_party_type_id IN ( 1, 2 ) )-- household,employer
  LEFT JOIN BDR_DM.wrk_pgd_insplanbenmod ipbenmod
  ON ( demo.insuredplan_id = ipbenmod.insured_plan_id
  AND cd.monthdate BETWEEN ipbenmod.insplanbenmod_startdate AND ipbenmod.insplanbenmod_stopdate )
  LEFT OUTER JOIN BDR_DM.wrk_account_number_data an
  ON ( demo.household_id = an.household_id
  AND an.individual_id   = demo.individual_id
  AND cd.monthdate BETWEEN an.account_startdate AND an.account_stopdate )
  LEFT JOIN BDR_CONF.d_pln_ben_mod pbm
  ON NVL(demo.plan_cd,''zz'')            = NVL(pbm.compas_pln_cd,''zz'')
  AND NVL(ipbenmod.plancd_benmodcat,0) = NVL(pbm.compas_ben_mod_catgy_id,0)
  LEFT OUTER JOIN BDR_DM.wrk_pgd_temp_uw_tags uw
  ON
    --demo.individual_id = uw.f_uw_individual_id  AND          20180417 due to compas merge scenario.
    demo.insuredplan_id = uw.f_uw_insuredplan_id
    LEFT JOIN BDR_DM.WRK_INSD_PLN_PRFL_TMP2 IPP_TEMP ON DEMO.insuredplan_id = IPP_TEMP.SRC_INSD_PLN_ID
    AND NVL(ar.due_date,cd.monthdate) BETWEEN IPP_TEMP.INSD_PLN_PRFL_STRT_DT AND IPP_TEMP.INSD_PLN_PRFL_STOP_DT AND IPP_TEMP.SRC_DEL_FLG = ''N''
  LEFT JOIN SRC_COMPAS_D.insured_plan_profile ipp
  ON ipp.insured_plan_profile_id = IPP_TEMP.SRC_INSD_PLN_PRFL_ID
 LEFT JOIN SRC_COMPAS_D.legal_entity le
  ON le.legal_entity_id = ipp.legal_entity_id
    -- SCR61587 28Jun2018
  LEFT JOIN BDR_DM.D_SURCHRG_TBCC_USER tbcc
  ON tbcc.SURCHRG_TBCC_USER_FLG=demo.SMOKER_IND
  AND cd.monthdate             >= TO_DATE(''01-JAN-2019'',''DD-MON-YYYY'')
  AND pbm.prdct_typ            = ''Modernized''
  AND pbm.prdct_grp            = ''Med Supp''
  LEFT JOIN BDR_DM.D_SURCHRG_TIER st
  ON st.RT_DTRM_CD_ID=demo.RDC_ID
  AND cd.monthdate   >= TO_DATE(''01-JAN-2019'',''DD-MON-YYYY'')
  AND pbm.prdct_typ  = ''Modernized''
  AND pbm.prdct_grp  = ''Med Supp''
  LEFT JOIN SRC_COMPAS_D.insured_plan ip
  on demo.insuredplan_id = ip.insured_plan_id
  LEFT JOIN BDR_DM.f_appl_trans_day appl
  on ip.application_id =appl.appl_id and  appl.CURR_ROW_FLG = ''Y''
  GROUP BY cd.monthdate,
    demo.household_id,
    demo.individual_id,
    demo.insplan_billingbucket_id,
    demo.insuredplan_id,
    NVL(ha.household_address_id,-1), --nvl for HHOLDAddress fix JS 9/9
    ar.due_date,
    demo.premium_dueamt,
    demo.plan_cd,
    NVL(ipbenmod.plancd_benmodcat,0),
    demo.insuredplan_effectivedate,
    demo.insuredplan_terminationdate,
    NVL(ha.state_cd,''ZZ''),
    NVL(ha.zip_cd,''99999''),
    NVL(ha.country_cd,''ZZ''),
    demo.individual_profile_startdate,
    demo.individual_profile_stopdate,
    demo.issue_state,
    demo.issue_country_cd,
    demo.issue_zip_cd,
    demo.gender_cd,
    demo.date_of_birth,
    demo.cert_acqn_chnl_level3,   -- Adding Cert Channel 8/4/2015
    NVL(an.account_number,''-1''),  --ACCT_NBR 8/2/2015
    demo.termination_reason_name, --Added 20150825,Cert Activity
    demo.conservation_reason_name,
    pbm.pln_grp,
    pbm.prdct_grp,
    NVL(uw.d_uw_tag_key,-1), --UNDWR JS 9/9/2015
    le.legal_entity_name,    -- -- Added for Legal Entity 04/19/2016
    le.LEGAL_ENTITY_CATEGORY_ID,
    demo.ret_typ_id,
    demo.D_DSCNT_ANNL_PAYR_SK,
    demo.D_DSCNT_ERLY_ENRL_SK,
    demo.D_DSCNT_LNGVTY_SK,
    demo.D_DSCNT_MULTI_INSD_SK,
    NVL(tbcc.D_SURCHRG_TBCC_USER_SK,demo.D_SURCHRG_TBCC_USER_SK),
    NVL(st.D_SURCHRG_TIER_SK,demo.D_SURCHRG_TIER_SK),
    demo.D_CALC_RT_SK,
    NVL(appl.F_APPL_TRANS_DAY_SK, -1),
	IPP.STATE_PLAN_BILLING_ID,
	IPP.BILLING_ZIP_CD,
	demo.SALE_CHNL_LVL_1,
	demo.SALE_CHNL_LVL_2,
	demo.SALE_CHNL_LVL_3,
	demo.D_NEW_TO_MEDCR_SK) RBL
    INNER JOIN (SELECT	D_PLN_BEN_MOD_SK,
			COMPAS_PLN_CD,
			NVL(COMPAS_BEN_MOD_CATGY_ID,0) AS COMPAS_BEN_MOD_CATGY_ID,
			COMPAS_PLN_CATGY_ID,
			PRDCT_GRP --PREMIUMDUEAGE
	 --INTO   #EDWREF_PLANBENMOD
 FROM BDR_CONF.D_PLN_BEN_MOD)PBM
	 ON NVL(RBL.PLAN_CD,''ZZ'') = NVL(PBM.COMPAS_PLN_CD,''ZZ'')
         AND RBL.plan_cdbenmodcat = PBM.COMPAS_BEN_MOD_CATGY_ID
 LEFT JOIN BDR_CONF.D_MBR_INFO MI
        ON RBL.INDIVIDUAL_ID = MI.INDV_ID
 LEFT JOIN (select * from (SELECT AR.*,ROW_NUMBER() OVER (PARTITION BY AR.D_ST_CD,AR.ZIP_CD,AR.D_CNTRY_CD ORDER BY AR.D_GEO_XREF_SK) RN
    FROM BDR_CONF.D_GEO_XREF AR) WHERE RN=1) RG
        ON RBL.STATECD_DER = RG.D_ST_CD
       AND RBL.ZIP_CD_DER = RG.ZIP_CD
       AND RBL.COUNTRY_CD_DER = RG.D_CNTRY_CD
	   LEFT JOIN (select * from (SELECT AR.*,ROW_NUMBER() OVER (PARTITION BY AR.D_ST_CD,AR.ZIP_CD,AR.D_CNTRY_CD ORDER BY AR.D_GEO_XREF_SK) RN
    FROM BDR_CONF.D_GEO_XREF AR) WHERE RN=1) RX
        ON RBL.ISSUE_STATE_DER = RX.D_ST_CD
       AND RBL.ISSUE_ZIP_CD_DER= RX.ZIP_CD
       AND RBL.ISSUE_COUNTRY_CD_DER = RX.D_CNTRY_CD
 --US89097- Issue State Billing Zip Code Filter Date
       LEFT OUTER JOIN SRC_COMPAS_D.state_plan_billing SPB ON RBL.STATE_PLAN_BILLING_ID=SPB.STATE_PLAN_BILLING_ID
       LEFT OUTER JOIN  (select * from (SELECT AR.*,ROW_NUMBER() OVER (PARTITION BY AR.D_ST_CD,AR.ZIP_CD ORDER BY AR.D_GEO_XREF_SK) RN
    FROM BDR_CONF.D_GEO_XREF AR) WHERE RN=1) AR1
	ON LTRIM(RTRIM(SPB.STATE_CD))=LTRIM(RTRIM(ar1.D_ST_CD))
	AND ltrim(rtrim(RBL.BILLING_ZIP_CD))=LTRIM(RTRIM(AR1.ZIP_CD))
       LEFT JOIN BDR_CONF.D_RTNG_AREA RA
       ON RBL.STATECD_DER = RA.D_ST_CD
      AND RBL.ZIP_CD_DER = RA.ZIP_CD
      AND RBL.premiumdue_dt BETWEEN RA.AREA_MAP_STRT_DT AND RA.AREA_MAP_STOP_DT
      AND PBM.COMPAS_PLN_CATGY_ID = RA.PLN_CATGY_ID
      AND RBL.LEGAL_ENTITY_CATEGORY_ID =RA.LGL_ENTY_CATGY_ID;
	      	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

    -------------------------------------COMMENTED BY OAS-------------------------------------
/*
V_ROWS_AFFTD:=SQL%ROWCOUNT;
  COMMIT;
  INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''DERIVATIVE PREMIUM1'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''INSERT1'',
      ''Insert into temp table wrk_premium_data_bl_rebuild'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );
  COMMIT;
*/
-------------------------------------COMMENTED BY OAS-------------------------------------

  
V_STEP_NAME    := ''INSERT - wrk_premium_data_bl_rebuild'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

  INSERT
    /*+ ENABLE_PARALLEL_DML APPEND */
  INTO BDR_DM.wrk_premium_data_bl_rebuild
    (
      household_id,
      individual_id,
      ins_plan_billing_bucket_id,
      insured_plan_id,
      household_address_id,
      premium_due_date,
      activity_date,
      paid_cert,
      del_cert,
      term_cert,
      paid_premium_amt,
      delinquent_premium_due_amt,
      plan_cd,
      benefit_mod_category_id,
      insured_plan_effective_date,
      insured_plan_termination_date,
      cert_termination_date,
      state_cd,
      zip_cd,
      country_cd,
      issue_state,
      issue_country_cd,
      issue_zip_cd,
      gender_cd,
      date_of_birth,
      etl_lst_btch_id,
      cert_acqn_chnl_level3,
      account_number,
      termination_reason_name,
      conservation_reason_name,
      plan_group,
      product_group,
      cert_actv_lvl_3_txt,
      undwr_tag_key,
      prdct_eff_dt,
      prdct_acqn_chnl_level3,
      legal_entity_name,
      mbr_pd_prem_amt,
      mbr_delq_prem_amt,
      er_pd_prem_amt,
      er_delq_prem_amt,
      current_signature_date,
      original_signature_date,
      original_insuredplan_id,
      writing_agent,
      selling_agent,
      original_selling_agent,
      ret_typ_id,
      er_skey,
      dcm_insured_plan_id,
      dcm_insured_plan_eff_date,
      dcm_plan_cd,
      dcm_signature_date,
      dcm_writing_agent,
      dcm_derived_compas_agent,
      agt_wrt_skey,
      agt_sel_orig_skey,
      agt_sel_skey,
      agt_dcm_wrt_skey,
      D_DSCNT_ANNL_PAYR_SK,
      D_DSCNT_EFT_SK,
      D_DSCNT_ERLY_ENRL_SK,
      D_DSCNT_LNGVTY_SK,
      D_DSCNT_MULTI_INSD_SK,
      D_SURCHRG_TBCC_USER_SK,
      D_SURCHRG_TIER_SK,
      D_INSD_PLN_PRFL_SK,
      D_CALC_RT_SK,
      MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
      DSCNT_PD_ANNL_PAYR_AMT,
      DSCNT_PD_EFT_AMT,
      DSCNT_PD_ERLY_ENRL_AMT,
      DSCNT_PD_LNGVTY_AMT,
      DSCNT_PD_MULTI_INSD_AMT,
      SURCHRG_PD_TBCC_USER_AMT,
      SURCHRG_PD_TIER_AMT,
      DSCNT_DELQ_ANNL_PAYR_AMT,
      DSCNT_DELQ_EFT_AMT,
      DSCNT_DELQ_ERLY_ENRL_AMT,
      DSCNT_DELQ_LNGVTY_AMT,
      DSCNT_DELQ_MULTI_INSD_AMT,
      SURCHRG_DELQ_TBCC_USER_AMT,
      SURCHRG_DELQ_TIER_AMT,
      ORIGINAL_REFERRAL_AGENT,
      REFERRAL_AGENT,
      AGT_REF_ORIG_D_AGT_SK,
      AGT_REF_D_AGT_SK,
      D_MBR_INFO_SK,
      D_PLN_BEN_MOD_SK,
      RES_D_GEO_XREF_SK,
      PLN_ISS_D_GEO_XREF_SK,
      D_RTNG_AREA_SK,
      F_APPL_TRANS_DAY_SK,
	  CERT_SALE_CHNL_LVL_1,
	  CERT_SALE_CHNL_LVL_2,
	  CERT_SALE_CHNL_LVL_3,
	  D_NEW_TO_MEDCR_SK,
      DSCNT_PD_NEW_TO_MEDCR_AMT,
      DSCNT_DLQNT_NEW_TO_MEDCR_AMT
    )
   SELECT  /*+ PARALLEL (8) */
    tna.household_id,
      tna.individual_id,
      tna.insplan_billingbucket_id AS ins_plan_billing_bucket_id,
      tna.insuredplan_id AS insured_plan_id,
      tna.household_addressid AS household_address_id,
      tna.premium_due_date AS premium_due_date,
      tna.activitydate as activity_date,
      tna.paid_cert AS paid_cert,
      tna.del_cert AS del_cert,
      tna.term_cert AS term_cert,
      tna.paid_premium_amt AS paid_premium_amt,
      tna.delinquent_premium_dueamt AS delinquent_premium_due_amt,
      tna.plan_cd,
      tna.plan_cdbenmodcat AS benefit_mod_category_id,
      tna.insuredplan_effectivedate AS insured_plan_effective_date,
      tna.insuredplan_terminationdate AS insured_plan_termination_date,
      tna.cert_terminationdate AS cert_termination_date,
      tna.d_st_cd AS state_cd,
      tna.zip_cd,
      tna.cntry_cd AS country_cd,
      tna.issue_state,
      tna.issue_country_cd,
      tna.issue_zip_cd,
      tna.gender_cd,
      tna.date_of_birth,
      tna.etllastbatchid as etl_lst_btch_id,
      tna.cert_acqn_chnl_level3,
      tna.acct_nbr AS account_number,
      tna.termination_reason_name,
      tna.conservation_reason_name,
      tna.plan_group AS plan_group,
      tna.product_group AS product_group,
      tna.cert_actv_lvl_3_txt,
      tna.d_undwr_tag_sk AS undwr_tag_key,
      tna.prdct_eff_dt,
      tna.prdct_acqn_chnl_level3,
      tna.legal_entity_name,
      tna.mbr_pd_prem_amt,
      tna.mbr_delq_prem_amt,
      tna.emp_pd_prem_amt AS er_pd_prem_amt,
      tna.emp_delq_prem_amt AS er_delq_prem_amt,
      tna.current_signature_date,
      tna.original_signature_date,
      tna.original_insured_plan_id AS original_insuredplan_id,
      tna.writing_agent,
      tna.selling_agent,
      tna.original_selling_agent,
      tna.ret_typ_id,
      tna. d_emp_sk AS er_skey,
      tna.dcm_insured_plan_id AS cm_insured_plan_id,
      tna.dcm_insd_pln_eff_dt AS dcm_insured_plan_eff_date,
      tna.dcm_plan_cd,
      tna.dcm_signature_date,
      tna.dcm_writing_agent,
      tna.dcm_derived_compas_agent,
      tna.agt_wrt_d_agt_sk AS agt_wrt_skey,
      tna.agt_sel_orig_d_agt_sk AS agt_sel_orig_skey,
      tna.agt_sel_d_agt_sk AS agt_sel_skey,
      tna.agt_dcm_wrt_d_agt_sk AS agt_dcm_wrt_skey,
      tna.D_DSCNT_ANNL_PAYR_SK,
      tna.D_DSCNT_EFT_SK,
      tna.D_DSCNT_ERLY_ENRL_SK,
      tna.D_DSCNT_LNGVTY_SK,
      tna.D_DSCNT_MULTI_INSD_SK,
      tna.D_SURCHRG_TBCC_USER_SK,
      tna.D_SURCHRG_TIER_SK,
      tna.D_INSD_PLN_PRFL_SK,
      tna.D_CALC_RT_SK,
      tna.MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
      tna.DSCNT_PD_ANNL_PAYR_AMT,
      tna.DSCNT_PD_EFT_AMT,
      tna.DSCNT_PD_ERLY_ENRL_AMT,
      tna.DSCNT_PD_LNGVTY_AMT,
      tna.DSCNT_PD_MULTI_INSD_AMT,
      tna.SURCHRG_PD_TBCC_USER_AMT,
      tna.SURCHRG_PD_TIER_AMT,
      tna.DSCNT_DELQ_ANNL_PAYR_AMT,
      tna.DSCNT_DELQ_EFT_AMT,
      tna.DSCNT_DELQ_ERLY_ENRL_AMT,
      tna.DSCNT_DELQ_LNGVTY_AMT,
      tna.DSCNT_DELQ_MULTI_INSD_AMT,
      tna.SURCHRG_DELQ_TBCC_USER_AMT,
      tna.SURCHRG_DELQ_TIER_AMT,
      tna.ORIGINAL_REFERRAL_AGENT,
      tna.REFERRAL_AGENT,
      tna.AGT_REF_ORIG_D_AGT_SK,
      tna.AGT_REF_D_AGT_SK,
     	   CASE WHEN tna.INDIVIDUAL_ID = MI.INDV_ID THEN MI.D_MBR_INFO_SK ELSE -1 END D_MBR_INFO_SK,
	   PBM.D_PLN_BEN_MOD_SK,
           CASE WHEN RG.D_ST_CD IS NOT NULL THEN RG.D_GEO_XREF_SK ELSE -1 END RES_D_GEO_XREF_SK,
--US89097- Issue State Billing Zip Code Filter Date
   	   CASE WHEN tna.insuredplan_effectivedate >=TO_DATE(''2020-01-01'',''YYYY-MM-DD'') THEN
	    CASE WHEN (LTRIM(RTRIM(TNA.STATE_PLAN_BILLING_ID)) IS NOT NULL AND LTRIM(RTRIM(SPB.STATE_CD)) IS NOT NULL)
	   THEN NVL(AR1.D_GEO_XREF_SK,-1) ELSE -1 END
	   ELSE NVL(RX.D_GEO_XREF_SK , -1) END PLN_ISS_D_GEO_XREF_SK,
	   CASE WHEN RA.D_ST_CD IS NOT NULL THEN RA.D_RTNG_AREA_SK ELSE -1 END D_RTNG_AREA_SK,
	   TNA.F_APPL_TRANS_DAY_SK,
	   TNA.CERT_SALE_CHNL_LVL_1,
	   TNA.CERT_SALE_CHNL_LVL_2,
	   TNA.CERT_SALE_CHNL_LVL_3,
	   tna.D_NEW_TO_MEDCR_SK,
       tna.DSCNT_PD_NEW_TO_MEDCR_AMT,
       tna.DSCNT_DLQNT_NEW_TO_MEDCR_AMT
         FROM
(SELECT
    /*+ PARALLEL (8) */
    DISTINCT tna.household_id,
    tna.individual_id,
    tna.insplan_billingbucket_id,
    tna.insuredplan_id,
    NVL(ha.household_address_id,-1) AS household_addressid, --nvl for HHOLDAddress fix JS 9/9
    tna.premium_due_date,
    :V_ACTIVITY_DATE AS activitydate,
    tna.paid_cert,
    tna.del_cert,
    tna.term_cert,
    tna.paid_premium_amt,
    tna.delinquent_premium_dueamt,
    tna.plan_cd,
    NVL(ipbenmod.plancd_benmodcat,0) AS plan_cdbenmodcat,
    tna.insuredplan_effectivedate,
    tna.insuredplan_terminationdate,
    tna.cert_terminationdate,
    NVL(ha.state_cd,''ZZ'')   AS d_st_cd,  --nvl for HHOLDAddress fix JS 9/9
    NVL(ha.zip_cd,''99999'')  AS zip_cd,   --nvl for HHOLDAddress fix JS 9/9
    NVL(ha.country_cd,''ZZ'') AS cntry_cd, --nvl for HHOLDAddress fix JS 9/9
    tna.issue_state,
    tna.issue_country_cd,
    tna.issue_zip_cd,
    tna.gender_cd,
    tna.date_of_birth,
   -- v_etlcurrentbatchid AS etllastbatchid,		----------------OAS DELETE
   :V_BATCH_ID AS etllastbatchid,		----------------OAS ADD
    tna.cert_acqn_chnl_level3, -- Adding Cert Channel 8/5/2015
    NVL(account_number,''-1'') AS acct_nbr,
    tna.termination_reason_name, --Added cert activity
    tna.conservation_reason_name,
    tna.plan_group,
    tna.product_group,
    tna.cert_actv_lvl_3_txt,
    NVL(uw.d_uw_tag_key,-1) AS d_undwr_tag_sk,
    NULL                    AS prdct_eff_dt,          -- Adding PRDCT Eff Dt 4/9/2016
    NULL                    AS prdct_acqn_chnl_level3,-- Adding Prdct Acq Chnl 4/9/2016
    le.legal_entity_name,                             -- Added for Legal Entity 04/19/2016
    le.LEGAL_ENTITY_CATEGORY_ID,
    0.00 mbr_pd_prem_amt,
    0.00 mbr_delq_prem_amt,
    0.00 emp_pd_prem_amt,
    0.00 emp_delq_prem_amt,
    NULL AS current_signature_date,
    NULL AS original_signature_date,
    NULL AS original_insured_plan_id,
    NULL AS writing_agent,          -- Adding Wrt AGENT 9/21/2016
    NULL AS selling_agent,          -- Adding Sel AGENT 9/21/2016
    NULL AS original_selling_agent, -- Added OrigSel AGENT 9/21/2016
    tna.ret_typ_id,
    -2 d_emp_sk,
    NULL AS dcm_insured_plan_id,
    NULL AS dcm_insd_pln_eff_dt,
    NULL AS dcm_plan_cd,
    NULL AS dcm_signature_date,
    NULL AS dcm_writing_agent,
    NULL AS dcm_derived_compas_agent,
    -1   AS agt_wrt_d_agt_sk,
    -1   AS agt_sel_orig_d_agt_sk,
    -1   AS agt_sel_d_agt_sk,
    -1   AS agt_dcm_wrt_d_agt_sk,
    1    AS D_DSCNT_ANNL_PAYR_SK,
    1    AS D_DSCNT_EFT_SK,
    1    AS D_DSCNT_ERLY_ENRL_SK,
    1    AS D_DSCNT_LNGVTY_SK,
    1    AS D_DSCNT_MULTI_INSD_SK,
    1    AS D_SURCHRG_TBCC_USER_SK,
    1    AS D_SURCHRG_TIER_SK,
    -1   AS D_INSD_PLN_PRFL_SK,
    -1   AS D_CALC_RT_SK,
    0    AS MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
    0    AS DSCNT_PD_ANNL_PAYR_AMT,
    0    AS DSCNT_PD_EFT_AMT,
    0    AS DSCNT_PD_ERLY_ENRL_AMT,
    0    AS DSCNT_PD_LNGVTY_AMT,
    0    AS DSCNT_PD_MULTI_INSD_AMT,
    0    AS SURCHRG_PD_TBCC_USER_AMT,
    0    AS SURCHRG_PD_TIER_AMT,
    0    AS DSCNT_DELQ_ANNL_PAYR_AMT,
    0    AS DSCNT_DELQ_EFT_AMT,
    0    AS DSCNT_DELQ_ERLY_ENRL_AMT,
    0    AS DSCNT_DELQ_LNGVTY_AMT,
    0    AS DSCNT_DELQ_MULTI_INSD_AMT,
    0    AS SURCHRG_DELQ_TBCC_USER_AMT,
    0    AS SURCHRG_DELQ_TIER_AMT,
    NULL AS ORIGINAL_REFERRAL_AGENT,
    NULL AS REFERRAL_AGENT,
    -2   AS AGT_REF_ORIG_D_AGT_SK,
    -2   AS AGT_REF_D_AGT_SK,
       CASE WHEN  NVL(ha.country_cd,''ZZ'')IN (''PR'', ''VI'',''GU'',''AS'',''MP'') AND NVL(ha.state_cd,''ZZ'') =''XX''
		   THEN NVL(ha.country_cd,''ZZ'')
     	   ELSE NVL(ha.state_cd,''ZZ'') END AS STATECD_DER,
       CASE WHEN (NVL(ha.country_cd,''ZZ'')= ''US'') OR (NVL(ha.state_cd,''ZZ'') IN (''PR'',''VI'',''GU'',''AS'',''MP'')) OR (/*PDT.STATECD = ''XX'' AND*/  NVL(ha.country_cd,''ZZ'')IN (''PR'', ''VI'',''GU'',''AS'',''MP''))
                    THEN SUBSTR(NVL(ha.zip_cd,''99999''),1,5)
           ELSE NVL(ha.zip_cd,''99999'') END AS ZIP_CD_DER,
       CASE WHEN (NVL(ha.state_cd,''ZZ'') IN (''PR'',''VI'',''GU'',''AS'',''MP''))  OR (NVL(ha.country_cd,''ZZ'')IN (''PR'',''VI'',''GU'',''AS'',''MP'') /*AND PDT.STATECD =''XX''*/)
                    THEN ''US''
	   ELSE  NVL(ha.country_cd,''ZZ'') END AS COUNTRY_CD_DER,

       CASE WHEN tna.issue_country_cd IN (''PR'', ''VI'',''GU'',''AS'',''MP'') AND tna.issue_state =''XX''
		    THEN tna.issue_country_cd
     	   ELSE tna.issue_state END AS ISSUE_STATE_DER,
       CASE WHEN (tna.issue_country_cd = ''US'') OR (tna.issue_state IN (''PR'',''VI'',''GU'',''AS'',''MP'')) OR (/*PDT.ISSUESTATE = ''XX'' AND*/ tna.issue_country_cd IN (''PR'', ''VI'',''GU'',''AS'',''MP''))
                    THEN SUBSTR(NVL(tna.issue_zip_cd,''99999''),1,5)
           ELSE NVL(tna.issue_zip_cd,''99999'') END AS ISSUE_ZIP_CD_DER,
       CASE WHEN (tna.issue_state IN (''PR'',''VI'',''GU'',''AS'',''MP'')) OR (tna.issue_country_cd IN (''PR'',''VI'',''GU'',''AS'',''MP'') /*AND PDT.ISSUESTATE =''XX''*/)
		    THEN ''US''
	   ELSE tna.issue_country_cd END AS ISSUE_COUNTRY_CD_DER,
	   NVL(appl.F_APPL_TRANS_DAY_SK, -1) as F_APPL_TRANS_DAY_SK,
	   IPP.STATE_PLAN_BILLING_ID,
	   IPP.BILLING_ZIP_CD,
	   TNA.CERT_SALE_CHNL_LVL_1,
	   TNA.CERT_SALE_CHNL_LVL_2,
	   TNA.CERT_SALE_CHNL_LVL_3,
	   1 AS D_NEW_TO_MEDCR_SK,
       0 AS DSCNT_PD_NEW_TO_MEDCR_AMT,
       0 AS DSCNT_DLQNT_NEW_TO_MEDCR_AMT
  FROM BDR_DM.wrk_premium_databaseline_tna tna
  JOIN BDR_DM.temp_baseline_rebuld_distindid indvid
  ON indvid.individual_id = tna.individual_id
  JOIN BDR_DM.TEMP_MONTH_DATE cd
  ON cd.monthdate BETWEEN tna.insuredplan_effectivedate AND tna.insuredplan_terminationdate
  LEFT OUTER JOIN SRC_COMPAS_D.household_address ha
  ON tna.household_id = ha.household_id --Added for HHOLDAddress fix by Jignesh Shah 9/9/2015
  AND cd.monthdate BETWEEN ha.hhold_addr_start_date AND ha.hhold_addr_stop_date
  AND ( ha.address_type_id   = 1
  AND NVL(ha.delete_ind,''N'') = ''N'' )
  LEFT JOIN BDR_DM.wrk_pgd_insplanbenmod ipbenmod
  ON ( tna.insuredplan_id = ipbenmod.insured_plan_id
  AND cd.monthdate BETWEEN ipbenmod.insplanbenmod_startdate AND ipbenmod.insplanbenmod_stopdate )
  LEFT OUTER JOIN BDR_DM.wrk_pgd_temp_uw_tags uw
  ON
    --tna.individual_id = uw.f_uw_individual_id AND       20180417 disabled due to compas individualid merge scenario.
    tna.insuredplan_id = uw.f_uw_insuredplan_id
        LEFT JOIN BDR_DM.WRK_INSD_PLN_PRFL_TMP2 IPP_TEMP ON tna.insuredplan_id = IPP_TEMP.SRC_INSD_PLN_ID
and tna.premium_due_date BETWEEN IPP_TEMP.INSD_PLN_PRFL_STRT_DT AND IPP_TEMP.INSD_PLN_PRFL_STOP_DT AND IPP_TEMP.SRC_DEL_FLG = ''N''
  LEFT OUTER JOIN SRC_COMPAS_D.insured_plan_profile ipp
   ON ipp.insured_plan_profile_id = IPP_TEMP.SRC_INSD_PLN_PRFL_ID
  LEFT JOIN SRC_COMPAS_D.legal_entity le
  ON le.legal_entity_id = ipp.legal_entity_id
  LEFT JOIN SRC_COMPAS_D.insured_plan ip
  on tna.insuredplan_id = ip.insured_plan_id
  LEFT JOIN BDR_DM.f_appl_trans_day appl
  on ip.application_id =appl.appl_id and  appl.CURR_ROW_FLG = ''Y''
  GROUP BY cd.monthdate,
    tna.household_id,
    tna.individual_id,
    tna.insplan_billingbucket_id,
    tna.insuredplan_id,
    NVL(ha.household_address_id,-1), --nvl for HHOLDAddress fix JS 9/9
    tna.premium_due_date,            --ar.DUE_DATE,
    --tna.PREMIUM_DUE_AMT,                                                                -- Ask Steve
    tna.plan_cd,
    tna.premium_due_date,
    tna.paid_cert,
    tna.del_cert,
    tna.term_cert,
    tna.paid_premium_amt,
    tna.delinquent_premium_dueamt,
    NVL(ipbenmod.plancd_benmodcat,0),
    tna.insuredplan_effectivedate,
    tna.insuredplan_terminationdate,
    tna.cert_terminationdate,
    NVL(ha.state_cd,''ZZ''),
    NVL(ha.zip_cd,''99999''),
    NVL(ha.country_cd,''ZZ''),
    tna.issue_state,
    tna.issue_country_cd,
    tna.issue_zip_cd,
    tna.gender_cd,
    tna.date_of_birth,
    tna.cert_acqn_chnl_level3, --- Adding Cert Channel 8/5/2015
    NVL(account_number,''-1''),
    tna.termination_reason_name, --added cert activity
    tna.conservation_reason_name,
    tna.plan_group,
    tna.product_group,
    tna.cert_actv_lvl_3_txt,
    NVL(uw.d_uw_tag_key,-1), --UNDWR 9/9/2015
    le.legal_entity_name,    -- -- Added for Legal Entity 04/19/2016
    le.LEGAL_ENTITY_CATEGORY_ID,
    tna.ret_typ_id,
    NVL(appl.F_APPL_TRANS_DAY_SK, -1),
	IPP.STATE_PLAN_BILLING_ID,
	IPP.BILLING_ZIP_CD,
	tna.CERT_SALE_CHNL_LVL_1,
	tna.CERT_SALE_CHNL_LVL_2,
	tna.CERT_SALE_CHNL_LVL_3) TNA
    INNER JOIN (SELECT	D_PLN_BEN_MOD_SK,
			COMPAS_PLN_CD,
			NVL(COMPAS_BEN_MOD_CATGY_ID,0) AS COMPAS_BEN_MOD_CATGY_ID,
			COMPAS_PLN_CATGY_ID,
			PRDCT_GRP --PREMIUMDUEAGE
	 --INTO   #EDWREF_PLANBENMOD
 FROM BDR_CONF.D_PLN_BEN_MOD)PBM
	 ON NVL(tna.PLAN_CD,''ZZ'') = NVL(PBM.COMPAS_PLN_CD,''ZZ'')
         AND tna.plan_cdbenmodcat = PBM.COMPAS_BEN_MOD_CATGY_ID
 LEFT JOIN BDR_CONF.D_MBR_INFO MI
        ON tna.INDIVIDUAL_ID = MI.INDV_ID
 LEFT JOIN (select * from (SELECT AR.*,ROW_NUMBER() OVER (PARTITION BY AR.D_ST_CD,AR.ZIP_CD,AR.D_CNTRY_CD ORDER BY AR.D_GEO_XREF_SK) RN
    FROM BDR_CONF.D_GEO_XREF AR) WHERE RN=1) RG
        ON tna.STATECD_DER = RG.D_ST_CD
       AND tna.ZIP_CD_DER = RG.ZIP_CD
       AND tna.COUNTRY_CD_DER = RG.D_CNTRY_CD
	   LEFT JOIN (select * from (SELECT AR.*,ROW_NUMBER() OVER (PARTITION BY AR.D_ST_CD,AR.ZIP_CD,AR.D_CNTRY_CD ORDER BY AR.D_GEO_XREF_SK) RN
    FROM BDR_CONF.D_GEO_XREF AR) WHERE RN=1) RX
        ON tna.ISSUE_STATE_DER = RX.D_ST_CD
       AND tna.ISSUE_ZIP_CD_DER= RX.ZIP_CD
       AND tna.ISSUE_COUNTRY_CD_DER = RX.D_CNTRY_CD
 --US89097- Issue State Billing Zip Code Filter Date
       LEFT OUTER JOIN SRC_COMPAS_D.state_plan_billing SPB ON TNA.STATE_PLAN_BILLING_ID=SPB.STATE_PLAN_BILLING_ID
       LEFT OUTER JOIN  (select * from (SELECT AR.*,ROW_NUMBER() OVER (PARTITION BY AR.D_ST_CD,AR.ZIP_CD ORDER BY AR.D_GEO_XREF_SK) RN
    FROM BDR_CONF.D_GEO_XREF AR) WHERE RN=1) AR1
	ON LTRIM(RTRIM(SPB.STATE_CD))=LTRIM(RTRIM(ar1.D_ST_CD))
	AND ltrim(rtrim(TNA.BILLING_ZIP_CD))=LTRIM(RTRIM(AR1.ZIP_CD))
       LEFT JOIN BDR_CONF.D_RTNG_AREA RA
       ON tna.STATECD_DER = RA.D_ST_CD
      AND tna.ZIP_CD_DER = RA.ZIP_CD
      AND tna.premium_due_date BETWEEN RA.AREA_MAP_STRT_DT AND RA.AREA_MAP_STOP_DT
      AND PBM.COMPAS_PLN_CATGY_ID = RA.PLN_CATGY_ID
      AND tna.LEGAL_ENTITY_CATEGORY_ID=RA.LGL_ENTY_CATGY_ID;
	      	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

  -------------------------------------COMMENTED BY OAS-------------------------------------
/*
V_ROWS_AFFTD:=SQL%ROWCOUNT;
  -- commit;
  INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''DERIVATIVE PREMIUM1'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''INSERT2'',
      ''Insert into temp table wrk_premium_data_bl_rebuild'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );
  COMMIT;
*/
-------------------------------------COMMENTED BY OAS-------------------------------------
  
V_STEP_NAME    := ''TRUNCATE - temp_premium_range'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

  EXECUTE IMMEDIATE ''TRUNCATE TABLE BDR_DM.temp_premium_range'';

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

  
V_STEP_NAME    := ''TRUNCATE - wrk_individual_id_dates'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

EXECUTE IMMEDIATE ''TRUNCATE TABLE BDR_DM.wrk_individual_id_dates'';

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );
  
V_STEP_NAME    := ''TRUNCATE - TEMP_PREM_PURGE'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

EXECUTE IMMEDIATE ''TRUNCATE TABLE BDR_DM.TEMP_PREM_PURGE'';

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

--EXECUTE IMMEDIATE ''TRUNCATE TABLE DM.WRK_PREMIUM_PURGED'';
  
V_STEP_NAME    := ''TRUNCATE - wrk_tna_individual_id_dates'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

EXECUTE IMMEDIATE ''TRUNCATE TABLE BDR_DM.wrk_tna_individual_id_dates'';

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );
  
V_STEP_NAME    := ''TRUNCATE - TEMP_TNA_PREM_PURGE'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

EXECUTE IMMEDIATE ''TRUNCATE TABLE BDR_DM.TEMP_TNA_PREM_PURGE'';

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

--EXECUTE IMMEDIATE ''TRUNCATE TABLE DM.WRK_PREMIUM_PURGED_TNA'';

  
V_STEP_NAME    := ''INSERT - temp_premium_range'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

  insert into BDR_DM.temp_premium_range
WITH dtRange(Dt) AS
(
    SELECT :V_PURGE_START::DATE as Dt from dual
    UNION ALL
    SELECT add_months(Dt::DATE, 1)
    FROM DtRange
    WHERE Dt < :v_purge_end )
    --select * from dtRange where Dt > = :V_PURGE_START and  Dt < :v_purge_end;		----------------OAS DELETE 
	select * from dtRange where Dt >  DATEADD(''DD'', -1, :V_PURGE_START::DATE) and  Dt < :v_purge_end;		----------------OAS ADD

 --   commit;
     	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );


--DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''TEMP_PREMIUM_RANGE'');		-------------OAS DELETE
  
V_STEP_NAME    := ''INSERT - wrk_individual_id_dates'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

 INSERT /*+ ENABLE_PARALLEL_DML APPEND */  INTO BDR_DM.wrk_individual_id_dates
 SELECT /*+ parallel(8) */  demo.INDIVIDUAL_ID, demo.insuredplan_id as INSURED_PLAN_ID, min( dtRange.Dt) as min_due_date,  max(dtRange.Dt) as max_due_date
     FROM BDR_DM.wrk_compas_demographicdata demo
        INNER JOIN BDR_DM.temp_baseline_rebuld_distindid indvid
  ON indvid.individual_id = demo.individual_id
        INNER JOIN BDR_DM.temp_premium_range dtRange
  ON dtRange.DT BETWEEN demo.billingbucket_startdate AND demo.der_billingbucket_stopdate
  group by demo.INDIVIDUAL_ID, demo.insuredplan_id;
    	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

  -------------------------------------COMMENTED BY OAS-------------------------------------
/*
V_ROWS_AFFTD:=SQL%ROWCOUNT;
  -- commit;
  INSERT INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''DERIVATIVE PREMIUM1'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''INSERT'',
      ''Insert into temp table wrk_individual_id_dates'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );
  COMMIT;


DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''wrk_individual_id_dates'');
*/
-------------------------------------COMMENTED BY OAS-------------------------------------
  
V_STEP_NAME    := ''INSERT - TEMP_PREM_PURGE'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

 INSERT /*+ ENABLE_PARALLEL_DML APPEND */  INTO BDR_DM.TEMP_PREM_PURGE
 select /*+ parallel(8) */  distinct INDIVIDUAL_ID, INSURED_PLAN_ID, due_date from (
 select /*+ parallel(8) */ INDIVIDUAL_ID, INSURED_PLAN_ID, min_due_date as due_date from BDR_DM.wrk_individual_id_dates
 union all
 select /*+ parallel(8) */ INDIVIDUAL_ID, INSURED_PLAN_ID, max_due_date as due_date from BDR_DM.wrk_individual_id_dates);
     	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );


   -------------------------------------COMMENTED BY OAS-------------------------------------
/*
V_ROWS_AFFTD:=SQL%ROWCOUNT;

  INSERT INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''DERIVATIVE PREMIUM1'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''INSERT'',
      ''Insert into temp table TEMP_PREM_PURGE'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );
  COMMIT;

DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''TEMP_PREM_PURGE'');
*/
-------------------------------------COMMENTED BY OAS-------------------------------------

  
V_STEP_NAME    := ''INSERT - wrk_premium_data_bl_rebuild'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

  INSERT
    /*+ ENABLE_PARALLEL_DML APPEND */
  INTO BDR_DM.wrk_premium_data_bl_rebuild
    (
      household_id,
      individual_id,
      ins_plan_billing_bucket_id,
      insured_plan_id,
      household_address_id,
      premium_due_date,
      activity_date,
      paid_cert,
      del_cert,
      term_cert,
      paid_premium_amt,
      delinquent_premium_due_amt,
      plan_cd,
      benefit_mod_category_id,
      insured_plan_effective_date,
      insured_plan_termination_date,
      cert_termination_date,
      state_cd,
      zip_cd,
      country_cd,
      issue_state,
      issue_country_cd,
      issue_zip_cd,
      gender_cd,
      date_of_birth,
      etl_lst_btch_id,
      cert_acqn_chnl_level3,
      account_number,
      termination_reason_name,
      conservation_reason_name,
      plan_group,
      product_group,
      cert_actv_lvl_3_txt,
      undwr_tag_key,
      prdct_eff_dt,
      prdct_acqn_chnl_level3,
      legal_entity_name,
      mbr_pd_prem_amt,
      mbr_delq_prem_amt,
      er_pd_prem_amt,
      er_delq_prem_amt,
      current_signature_date,
      original_signature_date,
      original_insuredplan_id,
      writing_agent,
      selling_agent,
      original_selling_agent,
      dcm_insured_plan_id,
      dcm_insured_plan_eff_date,
      dcm_plan_cd,
      dcm_signature_date,
      dcm_writing_agent,
      dcm_derived_compas_agent,
      ret_typ_id,
      er_skey,
      agt_wrt_skey,
      agt_sel_orig_skey,
      agt_sel_skey,
      agt_dcm_wrt_skey,
      D_DSCNT_ANNL_PAYR_SK,
      D_DSCNT_EFT_SK,
      D_DSCNT_ERLY_ENRL_SK,
      D_DSCNT_LNGVTY_SK,
      D_DSCNT_MULTI_INSD_SK,
      D_SURCHRG_TBCC_USER_SK,
      D_SURCHRG_TIER_SK,
      D_INSD_PLN_PRFL_SK,
      D_CALC_RT_SK,
      MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
      DSCNT_PD_ANNL_PAYR_AMT,
      DSCNT_PD_EFT_AMT,
      DSCNT_PD_ERLY_ENRL_AMT,
      DSCNT_PD_LNGVTY_AMT,
      DSCNT_PD_MULTI_INSD_AMT,
      SURCHRG_PD_TBCC_USER_AMT,
      SURCHRG_PD_TIER_AMT,
      DSCNT_DELQ_ANNL_PAYR_AMT,
      DSCNT_DELQ_EFT_AMT,
      DSCNT_DELQ_ERLY_ENRL_AMT,
      DSCNT_DELQ_LNGVTY_AMT,
      DSCNT_DELQ_MULTI_INSD_AMT,
      SURCHRG_DELQ_TBCC_USER_AMT,
      SURCHRG_DELQ_TIER_AMT,
      ORIGINAL_REFERRAL_AGENT,
      REFERRAL_AGENT,
      AGT_REF_ORIG_D_AGT_SK,
      AGT_REF_D_AGT_SK,
      D_MBR_INFO_SK,
      D_PLN_BEN_MOD_SK,
      RES_D_GEO_XREF_SK,
      PLN_ISS_D_GEO_XREF_SK,
      D_RTNG_AREA_SK,
      F_APPL_TRANS_DAY_SK,
	  CERT_SALE_CHNL_LVL_1,
	  CERT_SALE_CHNL_LVL_2,
	  CERT_SALE_CHNL_LVL_3,
	  D_NEW_TO_MEDCR_SK,
      DSCNT_PD_NEW_TO_MEDCR_AMT,
      DSCNT_DLQNT_NEW_TO_MEDCR_AMT
    )
       SELECT /*+ parallel(8) */   distinct
         household_id as HOUSEHOLD_ID,
    individual_id as INDIVIDUAL_ID,
    insplan_billingbucket_id as INS_PLAN_BILLING_BUCKET_ID,
    insuredplan_id as INSURED_PLAN_ID,
     -1 as           HOUSEHOLD_ADDRESS_ID,
          due_date as PREMIUM_DUE_DATE,
          :V_ACTIVITY_DATE  as ACTIVITY_DATE,
          paidcert,
    delcert,
    termcert,
          0 as PAID_PREMIUM_AMT,
          0 as DELINQUENT_PREMIUM_DUE_AMT,
           PLAN_CD as PLAN_CD,
          0 as BENEFIT_MOD_CATEGORY_ID, --default
           insuredplan_effectivedate as INSURED_PLAN_EFFECTIVE_DATE,
           insuredplan_terminationdate as INSURED_PLAN_TERMINATION_DATE,
       certterminationdate,
    ''ZZ'' as STATE_CD,
    ''99999'' as ZIP_CD,
    ''ZZ'' as COUNTRY_CD,
    issue_state,
    issue_country_cd,
    issue_zip_cd,
    gender_cd,
    date_of_birth,
   -- v_etlcurrentbatchid AS etl_lst_btch_id,		-----------------------OAS DELETE
   :V_BATCH_ID AS etl_lst_btch_id,		-----------------------OAS ADD
    cert_acqn_chnl_level3, -- Adding Cert Channel 8/4/2015
    ''-1'' AS ACCOUNT_NUMBER,
     termination_reason_name as TERMINATION_REASON_NAME,
     conservation_reason_name as CONSERVATION_REASON_NAME,
     pln_grp as PLAN_GROUP,
     prdct_grp as PRODUCT_GROUP,
     NULL as CERT_ACTV_LVL_3_TXT,
     -1 as UNDWR_TAG_KEY,
      NULL AS prdct_eff_dt,
      NULL AS prdct_acqn_chnl_level3,
      NULL AS LEGAL_ENTITY_NAME,
      0.00 mbr_pd_prem_amt,
        0.00 mbr_delq_prem_amt,
        0.00 emp_pd_prem_amt,
        0.00 emp_delq_prem_amt,
        NULL AS current_signature_date,
        NULL AS original_signature_date,
        NULL AS original_insured_plan_id,
        NULL AS writing_agent,
        NULL AS selling_agent,
        NULL AS original_selling_agent,
        NULL AS dcm_insured_plan_id,
        NULL AS dcm_insd_pln_eff_dt,
        NULL AS dcm_plan_cd,
        NULL AS dcm_signature_date,
        NULL AS dcm_writing_agent,
        NULL AS dcm_derived_compas_agent,
      ret_typ_id,
    -2 as d_emp_sk,
    -1   AS agt_wrt_d_agt_sk,
    -1   AS agt_sel_orig_d_agt_sk,
    -1   AS agt_sel_d_agt_sk,
    -1   AS agt_dcm_wrt_d_agt_sk,
     -1 as D_DSCNT_ANNL_PAYR_SK,
    -1 AS D_DSCNT_EFT_SK,
    -1 as D_DSCNT_ERLY_ENRL_SK,
    -1 as D_DSCNT_LNGVTY_SK,
    -1 as D_DSCNT_MULTI_INSD_SK,
    -1 as D_SURCHRG_TBCC_USER_SK, -- SCR61587 28Jun2018
    -1 as D_SURCHRG_TIER_SK,                  -- SCR61587 28Jun2018
    -1 AS D_INSD_PLN_PRFL_SK,
    -1 as D_CALC_RT_SK,
    0 AS MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
    0 AS DSCNT_PD_ANNL_PAYR_AMT,
    0 AS DSCNT_PD_EFT_AMT,
    0 AS DSCNT_PD_ERLY_ENRL_AMT,
    0 AS DSCNT_PD_LNGVTY_AMT,
    0 AS DSCNT_PD_MULTI_INSD_AMT,
    0 AS SURCHRG_PD_TBCC_USER_AMT,
    0 AS SURCHRG_PD_TIER_AMT,
    0 AS DSCNT_DELQ_ANNL_PAYR_AMT,
    0 AS DSCNT_DELQ_EFT_AMT,
    0 AS DSCNT_DELQ_ERLY_ENRL_AMT,
    0 AS DSCNT_DELQ_LNGVTY_AMT,
    0 AS DSCNT_DELQ_MULTI_INSD_AMT,
    0 AS SURCHRG_DELQ_TBCC_USER_AMT,
    0 AS SURCHRG_DELQ_TIER_AMT,
    NULL AS ORIGINAL_REFERRAL_AGENT,
    NULL AS REFERRAL_AGENT,
    -2   AS AGT_REF_ORIG_D_AGT_SK,
    -2   AS AGT_REF_D_AGT_SK,
    -1 as D_MBR_INFO_SK,
    -1 as D_PLN_BEN_MOD_SK,
    -1 as RES_D_GEO_XREF_SK,
    -1 as PLN_ISS_D_GEO_XREF_SK,
    -1 as D_RTNG_AREA_SK,
    -1 as F_APPL_TRANS_DAY_SK,
	SALE_CHNL_LVL_1,
	SALE_CHNL_LVL_2,
	SALE_CHNL_LVL_3,
	1 AS D_NEW_TO_MEDCR_SK,
     0 AS DSCNT_PD_NEW_TO_MEDCR_AMT,
     0 AS DSCNT_DLQNT_NEW_TO_MEDCR_AMT
    from (
 SELECT /*+ parallel(8) */
         demo.household_id ,
    demo.individual_id ,
    demo.insplan_billingbucket_id ,
    demo.insuredplan_id ,
    bc.due_date ,
              CASE   WHEN ( ( demo.insuredplan_terminationdate IS NULL
      AND TO_DATE(''9999-12-31'',''YYYY-MM-DD'')    <= bc.due_date )
      OR ( bc.due_date                          = NVL(demo.individual_profile_startdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')) ) )
      THEN 0--''Y''
      WHEN ( ( demo.insuredplan_terminationdate                                                                                                                                                IS NOT NULL
      AND TRUNC(add_months(TO_DATE(REPLACE(TO_CHAR(demo.insuredplan_terminationdate,''YYYY-MM-DD HH24:MI:SS''/* ''RRRR-MM-DD HH24:MI:SS'' */),''9999-12-31 00:00:00'',''9999-11-30 00:00:00''),''YYYY-MM-DD HH24:MI:SS''/* ''RRRR-MM-DD HH24:MI:SS'' */),1),''MONTH'') <= bc.due_date )
      OR ( bc.due_date                                                                                                                                                                         = NVL(demo.individual_profile_startdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')) ) )
      THEN 0--''Y''
      WHEN ( ar.due_date IS NULL )
      OR ( bc.due_date BETWEEN NVL(demo.individual_profile_startdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')) AND NVL(demo.individual_profile_stopdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')) )
      THEN 0--''S''
      ELSE
        CASE
          WHEN ( SUM(ar.due_amount) > 0
          AND ( SUM(ar.paid_amount) = SUM(ar.due_amount) ) )--''N''
          THEN 1
          ELSE 0
        END
    END paidcert,
    CASE
      WHEN ( ( demo.insuredplan_terminationdate IS NULL
      AND TO_DATE(''9999-12-31'',''YYYY-MM-DD'')    <= bc.due_date )
      OR ( bc.due_date                          = NVL(demo.individual_profile_startdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')) ) )
      THEN 0--''Y''
      WHEN ( ( demo.insuredplan_terminationdate                                                                                                                                                IS NOT NULL
      AND TRUNC(add_months(TO_DATE(REPLACE(TO_CHAR(demo.insuredplan_terminationdate,''YYYY-MM-DD HH24:MI:SS''/* ''RRRR-MM-DD HH24:MI:SS'' */),''9999-12-31 00:00:00'',''9999-11-30 00:00:00''),''YYYY-MM-DD HH24:MI:SS''/* ''RRRR-MM-DD HH24:MI:SS'' */),1),''MONTH'') <= bc.due_date )
      OR ( bc.due_date                                                                                                                                                                         = NVL(demo.individual_profile_startdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')) ) )
      THEN 0--''Y''
      WHEN ( ar.due_date IS NULL )
      OR ( bc.due_date BETWEEN NVL(demo.individual_profile_startdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')) AND NVL(demo.individual_profile_stopdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')) )
      THEN 0--''S''
      ELSE
        CASE
          WHEN ( SUM(ar.due_amount) > 0
          AND ( SUM(ar.paid_amount) < SUM(ar.due_amount) ) )--''N''
          THEN 1
          ELSE 0
        END
    END delcert,
    CASE
      WHEN ( ( demo.insuredplan_terminationdate IS NULL
      AND TO_DATE(''9999-12-31'',''YYYY-MM-DD'')    <= bc.due_date )
      OR ( bc.due_date                          = NVL(demo.individual_profile_startdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')) ) )
      THEN 1--''Y''
      WHEN ( ( demo.insuredplan_terminationdate                                                                                                                                               IS NOT NULL
      AND TRUNC(add_months(TO_DATE(REPLACE(TO_CHAR(demo.insuredplan_terminationdate,''YYYY-MM-DD HH24:MI:SS''/* ''RRRR-MM-DD HH24:MI:SS'' */),''9999-12-31 00:00:00'',''9999-11-30 00:00:00''),''YYYY-MM-DD HH24:MI:SS''/* ''RRRR-MM-DD HH24:MI:SS'' */),1),''MONTH'')<= bc.due_date )
      OR ( bc.due_date                                                                                                                                                                        = NVL(demo.individual_profile_startdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')) ) )
      THEN 1--''Y''
      WHEN ( ar.due_date IS NULL )
      OR ( bc.due_date BETWEEN NVL(demo.individual_profile_startdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')) AND NVL(demo.individual_profile_stopdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')) )
      THEN 0--''S''
      ELSE 0
    END termcert,
          demo.PLAN_CD ,
           demo.insuredplan_effectivedate ,
           demo.insuredplan_terminationdate ,
      CASE
      WHEN ((demo.insuredplan_terminationdate IS NULL
      AND TO_DATE(''9999-12-31'',''YYYY-MM-DD'')  <= bc.due_date)
      OR (bc.due_date                         = NVL(demo.individual_profile_startdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD''))))
      THEN bc.due_date
      WHEN ((demo.insuredplan_terminationdate                                                                                                                                                  IS NOT NULL
      AND TRUNC(add_months(TO_DATE(REPLACE(TO_CHAR(demo.insuredplan_terminationdate,''YYYY-MM-DD HH24:MI:SS''/* ''RRRR-MM-DD HH24:MI:SS'' */),''9999-12-31 00:00:00'',''9999-11-30 00:00:00''),''YYYY-MM-DD HH24:MI:SS''/* ''RRRR-MM-DD HH24:MI:SS'' */),1),''MONTH'') <= bc.due_date)
      OR (bc.due_date                                                                                                                                                                          = NVL(demo.individual_profile_startdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD''))))
      THEN bc.due_date
      WHEN (ar.due_date IS NULL)
      OR (bc.due_date BETWEEN NVL(demo.individual_profile_startdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')) AND NVL(demo.individual_profile_stopdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')))
      THEN NULL
      ELSE NULL
    END certterminationdate,
    demo.issue_state,
    demo.issue_country_cd,
    demo.issue_zip_cd,
    demo.gender_cd,
    demo.date_of_birth,
      demo.cert_acqn_chnl_level3, -- Adding Cert Channel 8/4/2015
      demo.termination_reason_name,
     demo.conservation_reason_name ,
     pbm.pln_grp ,
     pbm.prdct_grp,
      demo.ret_typ_id,
	  demo.SALE_CHNL_LVL_1,
	  demo.SALE_CHNL_LVL_2,
	  demo.SALE_CHNL_LVL_3
      --demo.F_APPL_TRANS_DAY_SK
               FROM BDR_DM.wrk_compas_demographicdata demo
              inner join BDR_DM.TEMP_PREM_PURGE bc
              ON bc.INDIVIDUAL_ID = demo.INDIVIDUAL_ID
              AND bc.due_date between demo.billingbucket_startdate AND demo.der_billingbucket_stopdate
      LEFT JOIN SRC_COMPAS_D.ACCOUNT_RECEIVABLE ar
    ON ( demo.household_id            = ar.household_id
    AND ar.due_date               = bc.due_date
    AND ar.acct_receivable_type_id    = 2         -- premium
    AND ar.responsible_party_type_id IN ( 1, 2 ) )-- household,employer
    LEFT JOIN BDR_DM.wrk_pgd_insplanbenmod ipbenmod
    ON ( demo.insuredplan_id = ipbenmod.insured_plan_id
    AND bc.due_date BETWEEN ipbenmod.insplanbenmod_startdate AND ipbenmod.insplanbenmod_stopdate )
   LEFT JOIN BDR_CONF.d_pln_ben_mod pbm
   ON NVL(demo.plan_cd,''zz'')            = NVL(pbm.compas_pln_cd,''zz'')
   AND NVL(ipbenmod.plancd_benmodcat,0) = NVL(pbm.compas_ben_mod_catgy_id,0)
  group by    bc.due_date,
    demo.household_id,
    demo.individual_id,
    demo.insplan_billingbucket_id,
    demo.insuredplan_id,
    ar.due_date,
    demo.plan_cd,
    NVL(ipbenmod.plancd_benmodcat,0),
    demo.insuredplan_effectivedate,
    demo.insuredplan_terminationdate,
    demo.individual_profile_startdate,
    demo.individual_profile_stopdate,
    demo.issue_state,
    demo.issue_country_cd,
    demo.issue_zip_cd,
    demo.gender_cd,
    demo.date_of_birth,
    demo.cert_acqn_chnl_level3,   -- Adding Cert Channel 8/4/2015
    demo.termination_reason_name, --Added 20150825,Cert Activity
    demo.conservation_reason_name,
    pbm.pln_grp,
    pbm.prdct_grp,
    demo.ret_typ_id,
    demo.D_DSCNT_ANNL_PAYR_SK,
    demo.D_DSCNT_ERLY_ENRL_SK,
    demo.D_DSCNT_LNGVTY_SK,
    demo.D_DSCNT_MULTI_INSD_SK,
    demo.D_CALC_RT_SK,
	demo.SALE_CHNL_LVL_1,
	demo.SALE_CHNL_LVL_2,
	demo.SALE_CHNL_LVL_3,
	demo.D_NEW_TO_MEDCR_SK);
    	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );



   -------------------------------------COMMENTED BY OAS-------------------------------------
/*
V_ROWS_AFFTD:=SQL%ROWCOUNT;

  INSERT INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''DERIVATIVE PREMIUM1'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''INSERT'',
      ''Insert into PREMIUM_PURGED'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );
  COMMIT;
*/
-------------------------------------COMMENTED BY OAS-------------------------------------
----tna records-purge --------


  
V_STEP_NAME    := ''INSERT - wrk_tna_individual_id_dates'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

 INSERT /*+ ENABLE_PARALLEL_DML APPEND */  INTO BDR_DM.wrk_tna_individual_id_dates
     select /*+ parallel(8) */  ip.INDIVIDUAL_ID, ip.INSURED_PLAN_ID, min(dtRange.Dt) as min_due_date,  max(dtRange.Dt) as max_due_date
  FROM SRC_COMPAS_D.INSURED_PLAN IP
  JOIN BDR_DM.temp_baseline_rebuld_distindid indvid
  ON indvid.individual_id = IP.individual_id
          INNER JOIN BDR_DM.temp_premium_range DtRange
  ON dtRange.DT BETWEEN IP.INSURED_PLAN_EFFECTIVE_DATE AND IP.INSURED_PLAN_TERMINATION_DATE
  JOIN SRC_COMPAS_D.INDIVIDUAL IND
  ON IP.INDIVIDUAL_ID = IND.INDIVIDUAL_ID
        JOIN SRC_COMPAS_D.HOUSEHOLD_MEMBER HM
        ON IP.INDIVIDUAL_ID = HM.INDIVIDUAL_ID
        WHERE IP.INSURED_PLAN_EFFECTIVE_DATE = IP.INSURED_PLAN_TERMINATION_DATE
             AND IP.INSURED_PLAN_ID NOT IN
  ( SELECT DISTINCT INSURED_PLAN_ID FROM SRC_COMPAS_D.INS_PLAN_BILLING_BUCKET
  )
AND IP.INSURED_PLAN_EFFECTIVE_DATE BETWEEN HM.HHOLD_MEMBER_START_DATE AND HM.HHOLD_MEMBER_STOP_DATE
  group by ip.INDIVIDUAL_ID, ip.INSURED_PLAN_ID;
    	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

    -------------------------------------COMMENTED BY OAS-------------------------------------
/*
V_ROWS_AFFTD:=SQL%ROWCOUNT;

  INSERT INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''DERIVATIVE PREMIUM1'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''INSERT'',
      ''Insert into temp table wrk_tna_individual_id_dates'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );
  COMMIT;
*/
-------------------------------------COMMENTED BY OAS-------------------------------------
  
V_STEP_NAME    := ''INSERT - TEMP_TNA_PREM_PURGE'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

  INSERT /*+ ENABLE_PARALLEL_DML APPEND */  INTO BDR_DM.TEMP_TNA_PREM_PURGE
 select /*+ parallel(8) */  distinct INDIVIDUAL_ID, INSURED_PLAN_ID, due_date from (
 select /*+ parallel(8) */ INDIVIDUAL_ID, INSURED_PLAN_ID, min_due_date as due_date from BDR_DM.wrk_tna_individual_id_dates
  union all
 select /*+ parallel(8) */ INDIVIDUAL_ID, INSURED_PLAN_ID, max_due_date as due_date from BDR_DM.wrk_tna_individual_id_dates);
    	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

    -------------------------------------COMMENTED BY OAS-------------------------------------
/*
V_ROWS_AFFTD:=SQL%ROWCOUNT;

  INSERT INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''DERIVATIVE PREMIUM1'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''INSERT'',
      ''Insert into temp table TEMP_TNA_PREM_PURGE'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );

  COMMIT;
*/
-------------------------------------COMMENTED BY OAS-------------------------------------

  /* INSERT  INTO DM.WRK_PREMIUM_PURGED_TNA
    (HOUSEHOLD_ID , INDIVIDUAL_ID, INS_PLAN_BILLING_BUCKET_ID , INSURED_PLAN_ID , HOUSEHOLD_ADDRESS_ID , PREMIUM_DUE_DATE , INSURED_PLAN_EFFECTIVE_DATE , INSURED_PLAN_TERMINATION_DATE , CERT_TERMINATION_DATE ,
TERMINATION_REASON_NAME , CONSERVATION_REASON_NAME, PRODUCT_GROUP, PLAN_GROUP, PLAN_CD, CERT_ACQN_CHNL_LEVEL3)
*/
  
V_STEP_NAME    := ''INSERT - wrk_premium_data_bl_rebuild'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

INSERT
    /*+ ENABLE_PARALLEL_DML APPEND */
  INTO BDR_DM.wrk_premium_data_bl_rebuild
    (
      household_id,
      individual_id,
      ins_plan_billing_bucket_id,
      insured_plan_id,
      household_address_id,
      premium_due_date,
      activity_date,
      paid_cert,
      del_cert,
      term_cert,
      paid_premium_amt,
      delinquent_premium_due_amt,
      plan_cd,
      benefit_mod_category_id,
      insured_plan_effective_date,
      insured_plan_termination_date,
      cert_termination_date,
      state_cd,
      zip_cd,
      country_cd,
      issue_state,
      issue_country_cd,
      issue_zip_cd,
      gender_cd,
      date_of_birth,
      etl_lst_btch_id,
      cert_acqn_chnl_level3,
      account_number,
      termination_reason_name,
      conservation_reason_name,
      plan_group,
      product_group,
      cert_actv_lvl_3_txt,
      undwr_tag_key,
      prdct_eff_dt,
      prdct_acqn_chnl_level3,
      legal_entity_name,
      mbr_pd_prem_amt,
      mbr_delq_prem_amt,
      er_pd_prem_amt,
      er_delq_prem_amt,
      current_signature_date,
      original_signature_date,
      original_insuredplan_id,
      writing_agent,
      selling_agent,
      original_selling_agent,
      dcm_insured_plan_id,
      dcm_insured_plan_eff_date,
      dcm_plan_cd,
      dcm_signature_date,
      dcm_writing_agent,
      dcm_derived_compas_agent,
      ret_typ_id,
      er_skey,
      agt_wrt_skey,
      agt_sel_orig_skey,
      agt_sel_skey,
      agt_dcm_wrt_skey,
      D_DSCNT_ANNL_PAYR_SK,
      D_DSCNT_EFT_SK,
      D_DSCNT_ERLY_ENRL_SK,
      D_DSCNT_LNGVTY_SK,
      D_DSCNT_MULTI_INSD_SK,
      D_SURCHRG_TBCC_USER_SK,
      D_SURCHRG_TIER_SK,
      D_INSD_PLN_PRFL_SK,
      D_CALC_RT_SK,
      MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
      DSCNT_PD_ANNL_PAYR_AMT,
      DSCNT_PD_EFT_AMT,
      DSCNT_PD_ERLY_ENRL_AMT,
      DSCNT_PD_LNGVTY_AMT,
      DSCNT_PD_MULTI_INSD_AMT,
      SURCHRG_PD_TBCC_USER_AMT,
      SURCHRG_PD_TIER_AMT,
      DSCNT_DELQ_ANNL_PAYR_AMT,
      DSCNT_DELQ_EFT_AMT,
      DSCNT_DELQ_ERLY_ENRL_AMT,
      DSCNT_DELQ_LNGVTY_AMT,
      DSCNT_DELQ_MULTI_INSD_AMT,
      SURCHRG_DELQ_TBCC_USER_AMT,
      SURCHRG_DELQ_TIER_AMT,
      ORIGINAL_REFERRAL_AGENT,
      REFERRAL_AGENT,
      AGT_REF_ORIG_D_AGT_SK,
      AGT_REF_D_AGT_SK,
      D_MBR_INFO_SK,
      D_PLN_BEN_MOD_SK,
      RES_D_GEO_XREF_SK,
      PLN_ISS_D_GEO_XREF_SK,
      D_RTNG_AREA_SK,
      F_APPL_TRANS_DAY_SK,
	  CERT_SALE_CHNL_LVL_1,
	  CERT_SALE_CHNL_LVL_2,
	  CERT_SALE_CHNL_LVL_3,
	  D_NEW_TO_MEDCR_SK,
      DSCNT_PD_NEW_TO_MEDCR_AMT,
     DSCNT_DLQNT_NEW_TO_MEDCR_AMT
    )
 SELECT /*+ parallel(8) */ DISTINCT
             HM.household_id as HOUSEHOLD_ID,
    IP.individual_id as INDIVIDUAL_ID,
    -1 as INS_PLAN_BILLING_BUCKET_ID,
    IP.INSURED_PLAN_ID as INSURED_PLAN_ID,
     -1 as           HOUSEHOLD_ADDRESS_ID,
               NVL(IP.INSURED_PLAN_EFFECTIVE_DATE, tbc.due_date) AS PREMIUM_DUE_DATE,
          :V_ACTIVITY_DATE as ACTIVITY_DATE,
          0 as PAID_CERT,
          0 as DEL_CERT,
          1 as TERM_CERT,
          0 as PAID_PREMIUM_AMT,
          0 as DELINQUENT_PREMIUM_DUE_AMT,
           IP.PLAN_CD as PLAN_CD,
          0 as BENEFIT_MOD_CATEGORY_ID, --default
  IP.INSURED_PLAN_EFFECTIVE_DATE   AS INSUREDPLAN_EFFECTIVEDATE ,
  IP.INSURED_PLAN_TERMINATION_DATE AS INSUREDPLAN_TERMINATIONDATE ,
  IP.INSURED_PLAN_TERMINATION_DATE AS CERT_TERMINATIONDATE ,
    ''ZZ'' as STATE_CD,
    ''99999'' as ZIP_CD,
    ''ZZ'' as COUNTRY_CD,
    ''ZZ'' as issue_state,
    ''ZZ'' as issue_country_cd,
    ''99999'' as issue_zip_cd,
    ''U'' as gender_cd,
    IND.DATE_OF_BIRTH,
    --v_etlcurrentbatchid AS etl_lst_btch_id,		-----------------------------OAS DELETE
	:V_BATCH_ID AS etl_lst_btch_id,		-----------------------------OAS ADD
  NVL(IPAC.ACQUISITIONCHANNEL,''UNKNOWN'') as CERT_ACQN_CHNL_LEVEL3,
    ''-1'' AS ACCOUNT_NUMBER,
      TR.TERMINATION_REASON_NAME ,
      CR.CONSERVATION_REASON_NAME ,
     pbm.pln_grp as PLAN_GROUP,
     pbm.prdct_grp as PRODUCT_GROUP,
      NULL as CERT_ACTV_LVL_3_TXT,
     -1 as UNDWR_TAG_KEY,
      NULL AS prdct_eff_dt,
      NULL AS prdct_acqn_chnl_level3,
      NULL AS LEGAL_ENTITY_NAME,
      0.00 mbr_pd_prem_amt,
        0.00 mbr_delq_prem_amt,
        0.00 emp_pd_prem_amt,
        0.00 emp_delq_prem_amt,
        NULL AS current_signature_date,
        NULL AS original_signature_date,
        NULL AS original_insured_plan_id,
        NULL AS writing_agent,
        NULL AS selling_agent,
        NULL AS original_selling_agent,
        NULL AS dcm_insured_plan_id,
        NULL AS dcm_insd_pln_eff_dt,
        NULL AS dcm_plan_cd,
        NULL AS dcm_signature_date,
        NULL AS dcm_writing_agent,
        NULL AS dcm_derived_compas_agent,
      -1 as ret_typ_id,
    -2 as d_emp_sk,
    -1   AS agt_wrt_d_agt_sk,
    -1   AS agt_sel_orig_d_agt_sk,
    -1   AS agt_sel_d_agt_sk,
    -1   AS agt_dcm_wrt_d_agt_sk,
     -1 as D_DSCNT_ANNL_PAYR_SK,
    -1 AS D_DSCNT_EFT_SK,
    -1 as D_DSCNT_ERLY_ENRL_SK,
    -1 as D_DSCNT_LNGVTY_SK,
    -1 as D_DSCNT_MULTI_INSD_SK,
    -1 as D_SURCHRG_TBCC_USER_SK,
    -1 as D_SURCHRG_TIER_SK,
    -1 AS D_INSD_PLN_PRFL_SK,
    -1 as D_CALC_RT_SK,
    0 AS MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
    0 AS DSCNT_PD_ANNL_PAYR_AMT,
    0 AS DSCNT_PD_EFT_AMT,
    0 AS DSCNT_PD_ERLY_ENRL_AMT,
    0 AS DSCNT_PD_LNGVTY_AMT,
    0 AS DSCNT_PD_MULTI_INSD_AMT,
    0 AS SURCHRG_PD_TBCC_USER_AMT,
    0 AS SURCHRG_PD_TIER_AMT,
    0 AS DSCNT_DELQ_ANNL_PAYR_AMT,
    0 AS DSCNT_DELQ_EFT_AMT,
    0 AS DSCNT_DELQ_ERLY_ENRL_AMT,
    0 AS DSCNT_DELQ_LNGVTY_AMT,
    0 AS DSCNT_DELQ_MULTI_INSD_AMT,
    0 AS SURCHRG_DELQ_TBCC_USER_AMT,
    0 AS SURCHRG_DELQ_TIER_AMT,
    NULL AS ORIGINAL_REFERRAL_AGENT,
    NULL AS REFERRAL_AGENT,
    -2   AS AGT_REF_ORIG_D_AGT_SK,
    -2   AS AGT_REF_D_AGT_SK,
    -1 as D_MBR_INFO_SK,
    -1 as D_PLN_BEN_MOD_SK,
    -1 as RES_D_GEO_XREF_SK,
    -1 as PLN_ISS_D_GEO_XREF_SK,
    -1 as D_RTNG_AREA_SK,
    -1 as F_APPL_TRANS_DAY_SK,
	IPAC1.SALE_CHNL_LVL_1,
	IPAC1.SALE_CHNL_LVL_2,
	IPAC1.SALE_CHNL_LVL_3,
	1 AS D_NEW_TO_MEDCR_SK,
    0 AS DSCNT_PD_NEW_TO_MEDCR_AMT,
    0 AS DSCNT_DLQNT_NEW_TO_MEDCR_AMT
   FROM SRC_COMPAS_D.INSURED_PLAN IP
           JOIN SRC_COMPAS_D.INDIVIDUAL IND
       ON IP.INDIVIDUAL_ID = IND.INDIVIDUAL_ID
                INNER JOIN BDR_DM.TEMP_TNA_PREM_PURGE tbc
          ON tbc.INDIVIDUAL_ID = IP.INDIVIDUAL_ID
  and tbc.due_date BETWEEN IP.INSURED_PLAN_EFFECTIVE_DATE AND IP.INSURED_PLAN_TERMINATION_DATE
        JOIN SRC_COMPAS_D.HOUSEHOLD_MEMBER HM
        ON IP.INDIVIDUAL_ID = HM.INDIVIDUAL_ID
        LEFT JOIN SRC_COMPAS_D.TERMINATION_REASON TR
  ON IP.TERMINATION_REASON_ID = TR.TERMINATION_REASON_ID
  LEFT JOIN SRC_COMPAS_D.CONSERVATION_REASON CR
 ON IP.CONSERVATION_REASON_ID = CR.CONSERVATION_REASON_ID
 LEFT JOIN BDR_DM.WRK_PGD_INSPLANBENMOD IPBENMOD
 ON (IP.INSURED_PLAN_ID = IPBENMOD.INSURED_PLAN_ID)
 AND tbc.due_date BETWEEN IPBENMOD.INSPLANBENMOD_STARTDATE AND IPBENMOD.INSPLANBENMOD_STOPDATE
 LEFT JOIN BDR_CONF.D_PLN_BEN_MOD PBM
 ON NVL(IP.PLAN_CD,''ZZ'')              = NVL(PBM.COMPAS_PLN_CD,''ZZ'')
 AND NVL(IPBENMOD.PLANCD_BENMODCAT,0) = NVL(PBM.COMPAS_BEN_MOD_CATGY_ID,0)
 LEFT JOIN BDR_DM.WRK_IPACQUISITIONCHANNEL IPAC
 ON IP.INSURED_PLAN_ID = IPAC.INSUREDPLANID
 LEFT JOIN BDR_DM.WRK_IP_SALE_CHANNEL IPAC1
 ON IP.INSURED_PLAN_ID = IPAC1.INSUREDPLANID
        WHERE IP.INSURED_PLAN_EFFECTIVE_DATE = IP.INSURED_PLAN_TERMINATION_DATE
             AND IP.INSURED_PLAN_ID NOT IN
  ( SELECT DISTINCT INSURED_PLAN_ID FROM SRC_COMPAS_D.INS_PLAN_BILLING_BUCKET
  )
 AND IP.INSURED_PLAN_EFFECTIVE_DATE BETWEEN HM.HHOLD_MEMBER_START_DATE AND HM.HHOLD_MEMBER_STOP_DATE;
    	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

   -------------------------------------COMMENTED BY OAS-------------------------------------
/*
V_ROWS_AFFTD:=SQL%ROWCOUNT;

  INSERT INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''DERIVATIVE PREMIUM1'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''INSERT'',
      ''Insert into temp table TEMP_TNA_PREM_PURGE'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );

  COMMIT;
*/
-------------------------------------COMMENTED BY OAS-------------------------------------
  
V_STEP_NAME    := ''INSERT - wrk_premium_data_bl_exp'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

  INSERT
    /*+ ENABLE_PARALLEL_DML PARALLEL APPEND */
  INTO BDR_DM.wrk_premium_data_bl_exp
    (
      BL_RN,
      household_id,
      individual_id,
      ins_plan_billing_bucket_id,
      insured_plan_id,
      household_address_id,
      premium_due_date,
      activity_date,
      paid_cert,
      del_cert,
      term_cert,
      paid_premium_amt,
      delinquent_premium_due_amt,
      plan_cd,
      benefit_mod_category_id,
      insured_plan_effective_date,
      insured_plan_termination_date,
      cert_termination_date,
      state_cd,
      zip_cd,
      country_cd,
      issue_state,
      issue_country_cd,
      issue_zip_cd,
      gender_cd,
      date_of_birth,
      etl_lst_btch_id,
      cert_acqn_chnl_level3,
      account_number,
      termination_reason_name,
      conservation_reason_name,
      plan_group,
      product_group,
      cert_actv_lvl_3_txt,
      undwr_tag_key,
      prdct_eff_dt,
      prdct_acqn_chnl_level3,
      legal_entity_name
    )
  SELECT
    /*+ PARALLEL */
    BLR_RN,
    household_id,
    individual_id,
    ins_plan_billing_bucket_id,
    insured_plan_id,
    household_address_id,
    premium_due_date,
    activity_date,
    paid_cert,
    del_cert,
    term_cert,
    paid_premium_amt,
    delinquent_premium_due_amt,
    plan_cd,
    benefit_mod_category_id,
    insured_plan_effective_date,
    insured_plan_termination_date,
    cert_termination_date,
    state_cd,
    zip_cd,
    country_cd,
    issue_state,
    issue_country_cd,
    issue_zip_cd,
    gender_cd,
    date_of_birth,
    etl_lst_btch_id,
    cert_acqn_chnl_level3,
    account_number,
    termination_reason_name,
    conservation_reason_name,
    plan_group,
    product_group,
    cert_actv_lvl_3_txt,
    undwr_tag_key,
    prdct_eff_dt,
    prdct_acqn_chnl_level3,
    legal_entity_name
  FROM BDR_DM.wrk_premium_data_bl_rebuild
  WHERE paid_cert=0
  AND del_cert   = 0
  AND term_cert  = 0;
      	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );


-------------------------------------COMMENTED BY OAS-------------------------------------
/*
  V_ROWS_AFFTD  :=SQL%ROWCOUNT;
  INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''DERIVATIVE PREMIUM1'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''INSERT'',
      ''Insert into temp table wrk_premium_data_bl_exp'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );
  ----Delete Paid + Del + Term = 0 From BLR 11/13/2015.

     DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''WRK_PREMIUM_DATA_BL_REBUILD'');
*/
-------------------------------------COMMENTED BY OAS-------------------------------------
  
V_STEP_NAME    := ''DELETE - wrk_premium_data_bl_rebuild'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

  DELETE
  FROM BDR_DM.wrk_premium_data_bl_rebuild
  WHERE paid_cert=0
  AND del_cert   = 0
  AND term_cert  = 0;
      	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_DELETED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

-------------------------------------COMMENTED BY OAS-------------------------------------
/*
  V_ROWS_AFFTD  :=SQL%ROWCOUNT;

   INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''DERIVATIVE PREMIUM1'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''DELETE'',
      ''Delete from table dm.wrk_premium_data_bl_rebuild'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );

      DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''WRK_PREMIUM_DATA_BL_REBUILD'');

         BEGIN

      EXECUTE IMMEDIATE ''CREATE UNIQUE INDEX INDX_WRK_PREMIUM_DATA_P01 ON WRK_PREMIUM_DATA_BL_REBUILD(BLR_RN) parallel 16'';

   EXECUTE IMMEDIATE ''ALTER INDEX INDX_WRK_PREMIUM_DATA_P01 NOPARALLEL'';

   EXECUTE IMMEDIATE ''ALTER TABLE WRK_PREMIUM_DATA_BL_REBUILD ADD CONSTRAINT INDX_WRK_PREMIUM_DATA_P01 PRIMARY KEY (BLR_RN)'';

   EXCEPTION WHEN OTHERS THEN

   NULL;

   END;
*/
-------------------------------------COMMENTED BY OAS-------------------------------------


  --DBMS_STATS.GATHER_TABLE_STATS (ownname => ''DM'',tabname => ''WRK_PREMIUM_DATA_BL_REBUILD'',partname => NULL,estimate_percent => 10, DEGREE => 4, granularity => ''ALL'', method_opt => ''FOR ALL COLUMNS SIZE 1'',CASCADE => TRUE);

/*
  UPDATE ETL.ETL_APPLICATION_METADATA							--DISABLED FOR RetroAct+RIA MERGE
  SET METADATA_VALUE = v_UW_CurrETLBatchID
  WHERE APPLICATION  =''PREMIUM''
  AND METADATA_TYPE  =''PGD_UWFactETLLastBatchID'';

  UPDATE ETL.ETL_APPLICATION_METADATA
  SET METADATA_VALUE =
    (SELECT TO_CHAR(MAX(LGR_ITM_DT),''MM-DD-YYYY HH24:MI:SS'')
    FROM dcm.DCM_COMM_PD
    WHERE   m_r_prdct_catgy IN (
                    ''AARP MS'',
                    ''MS''
                )
    )
  WHERE APPLICATION=''PREMIUM''
  AND METADATA_TYPE=''PGD_DCMLastDate''; */
  
  
-------------------------------------COMMENTED BY OAS-------------------------------------
/*
  COMMIT;
  INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''DERIVATIVE PREMIUM1'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''END'',
      ''PROCEDURE END'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );
  P_ToContinueStatus := ''Y'';
  P_ErrorYNFlg       := ''N'';
  P_ErrorStr         := '''';
EXCEPTION
WHEN OTHERS THEN
  P_ErrorStr         := ''ERROR: '' || SQLCODE || ''-'' || SQLERRM || ''-'' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE()|| Chr(10)||DBMS_UTILITY.FORMAT_ERROR_STACK();
  P_ToContinueStatus := ''N'';
  P_ErrorYNFlg       := ''Y'';
  ROLLBACK;
END;
/ */
-------------------------------------------COMMENTED BY OAS--------------------------------------------

CALL UTIL.SP_ETL_CHECK_CONSTRAINTS(:DB_NAME , :APPLICATION , :WORKFLOW_NAME , :OBJECT_NAME , :V_BATCH_ID );


UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''COMPLETE'', ERROR_MSG = null, BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
;
UPDATE  UTIL.ETL_BATCH_OBJECT_INCR_VALU SET INCR_COLUMN_VALUE = :V_BATCH_ID, LST_MOD_DT = CURRENT_TIMESTAMP() 
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID''
;

EXCEPTION

WHEN OTHER THEN

UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''ERROR'', ERROR_MSG = :SQLERRM,  BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
;

INSERT INTO  UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ERROR_MSG, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''ERROR'', :V_STEP_NAME, :V_STEP_SEQ, :SQLERRM, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() )
;



RAISE;

END;

';