USE SCHEMA BDR_DM; CREATE OR REPLACE PROCEDURE "SP_APPLICATION_IXL_WRK_WRITINGSELLINGAGENT_D"("DB_NAME" VARCHAR(16777216), "APPLICATION" VARCHAR(16777216), "WORKFLOW_NAME" VARCHAR(16777216), "OBJECT_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '

-- Original workflow: wkf_Application_IXL_TargetLoad_D
-- Original mapping: m_Application_IXL_wrk_WritingSellingAgent_D
-- Original folder: Application
-- Original filename: wkf_Application_IXL_TargetLoad_D.XML

DECLARE


V_ROWS_INSERTED  INTEGER;
V_ROWS_UPDATED INTEGER;
V_ROWS_DELETED INTEGER;
V_LAST_QUERY_ID VARCHAR;

V_WH VARCHAR;
V_BATCH_ID INTEGER;


V_BATCH_OBJECT_START_TIME        VARCHAR;
V_STEP_START_TIME    VARCHAR;
V_STEP_NAME VARCHAR;
V_STEP_SEQ INTEGER DEFAULT 0;
V_ETL_LST_BTCH_ID INTEGER;


BEGIN

EXECUTE IMMEDIATE ''USE DATABASE ''||:DB_NAME; 

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_BATCH_OBJECT_START_TIME := (SELECT CURRENT_TIMESTAMP());



LET res1 RESULTSET := 
(

SELECT 

WH ,
BATCH_ID
  
FROM UTIL.ETL_BATCH_OBJECT_CONTROL
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
FETCH FIRST 1 ROW ONLY

)
;


LET C1 CURSOR FOR res1;
open C1;
FETCH C1 into  V_WH,V_BATCH_ID ;
close C1;





EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:V_WH;
USE SCHEMA BDR_DM;	--OAS ADD


INSERT INTO UTIL.ETL_BATCH_OBJECT_INCR_VALU (APPLICATION, WORKFLOW_NAME, OBJECT_NAME, INCR_COLUMN, INCR_COLUMN_VALUE )
SELECT * FROM (select :APPLICATION AS APPLICATION, :WORKFLOW_NAME AS WORKFLOW_NAME, :OBJECT_NAME AS OBJECT_NAME, ''ETL_LST_BTCH_ID'' AS INCR_COLUMN, -1 AS INCR_COLUMN_VALUE) A
WHERE NOT EXISTS (SELECT 1 FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU B WHERE B.APPLICATION = A.APPLICATION AND B.WORKFLOW_NAME = A.WORKFLOW_NAME AND B.OBJECT_NAME = A.OBJECT_NAME AND B.INCR_COLUMN = A.INCR_COLUMN)
;

V_ETL_LST_BTCH_ID :=(SELECT INCR_COLUMN_VALUE FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID'');



V_STEP_NAME    := ''TRUNCATE WRK_APPL_WRITING_AGENT'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

TRUNCATE TABLE BDR_DM.WRK_APPL_WRITING_AGENT;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

V_STEP_NAME    := ''TRUNCATE WRK_APPL_SELLING_AGENT'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

TRUNCATE TABLE BDR_DM.WRK_APPL_SELLING_AGENT;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

V_STEP_NAME    := ''TRUNCATE WRK_APPL_REFERRAL_AGENT'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

TRUNCATE TABLE BDR_DM.WRK_APPL_REFERRAL_AGENT;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );


V_STEP_NAME    := ''INSERT QUERY'';
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());



    INSERT
        ALL WHEN actionflg = ''ZOTHERSWRITING''
                 OR actionflg = ''MATCHEDWRITING''
                 OR actionflg = ''AGENTWRITING'' THEN

            INTO bdr_dm.wrk_appl_writing_agent
            VALUES (
                application_id,
                agent_id,
                current_signature_date,
                d_agt_sk
            )
            WHEN actionflg = ''ZOTHERSSELLING''
                 OR actionflg = ''MATCHEDSELLING''
                 OR actionflg = ''AGENTSELLING'' THEN

                INTO bdr_dm.wrk_appl_selling_agent
                VALUES (
                    application_id,
                    agent_id,
                    current_signature_date,
                    d_agt_sk
                )
            WHEN actionflg = ''ZOTHERSREFERRAL''
                 OR actionflg = ''MATCHEDREFERRAL''
                 OR actionflg = ''AGENTREFERRAL'' THEN

                INTO bdr_dm.wrk_appl_referral_agent
                VALUES (
                    application_id,
                    agent_id,
                    current_signature_date,
                    d_agt_sk
                )
    SELECT
        *
    FROM
        (
            WITH tmp_appl_writing_selling_referral AS (
                SELECT 
                    *
                FROM
                    (
                        SELECT
                            CAST(
                                CASE
                                    WHEN blr.agent_id NOT IN(
                                        ''-1'',''-2''
                                    )
                                         AND(replace(TO_CHAR(blr.current_signature_date,''YYYYMMDD''),''-'','''') BETWEEN wr_sel_ref_agt.agt_wrt_strt_dt_id AND wr_sel_ref_agt.agt_wrt_end_dt_id
)
                                         AND blr.agent_type_id = 1 THEN ''MATCHEDWRITING''
                                    WHEN blr.agent_id NOT IN(
                                        ''-1'',''-2''
                                    )
                                         AND(replace(TO_CHAR(blr.current_signature_date,''YYYYMMDD''),''-'','''') BETWEEN wr_sel_ref_agt.agt_wrt_strt_dt_id AND wr_sel_ref_agt.agt_wrt_end_dt_id
)
                                         AND blr.agent_type_id = 2 THEN ''MATCHEDSELLING''
                                    WHEN blr.agent_id NOT IN(
                                        ''-1'',''-2''
                                    )
                                         AND(replace(TO_CHAR(blr.current_signature_date,''YYYYMMDD''),''-'','''') BETWEEN wr_sel_ref_agt.agt_wrt_strt_dt_id AND wr_sel_ref_agt.agt_wrt_end_dt_id
)
                                         AND blr.agent_type_id = 5 THEN ''MATCHEDREFERRAL''
                                    WHEN blr.agent_id IN(
                                        ''-1'',''-2''
                                    )
                                         AND blr.agent_type_id = 1 THEN ''AGENTWRITING''
                                    WHEN blr.agent_id IN(
                                        ''-1'',''-2''
                                    )
                                         AND blr.agent_type_id = 2 THEN ''AGENTSELLING''
                                    WHEN blr.agent_id IN(
                                        ''-1'',''-2''
                                    )
                                         AND blr.agent_type_id = 5 THEN ''AGENTREFERRAL''
                                    WHEN blr.agent_type_id = 1 THEN ''ZOTHERSWRITING''
                                    WHEN blr.agent_type_id = 2 THEN ''ZOTHERSSELLING''
                                    WHEN blr.agent_type_id = 5 THEN ''ZOTHERSREFERRAL''
                                    ELSE ''ZOTHERS''
                                END
                            AS VARCHAR ) AS actionflg,

 --BLR.BLR_RN,BLR.INSURED_PLAN_ID, BLR.PREMIUM_DUE_DATE,
                            blr.application_id,
                            wr_sel_ref_agt.d_agt_sk,
                            blr.agent_id,
                            blr.agent_type_id,
                            blr.current_signature_date,
                            wr_sel_ref_agt.row_eff_strt_dt,
                            wr_sel_ref_agt.agt_wrt_strt_dt_id,
                            wr_sel_ref_agt.agt_id
                        FROM
                            (
                                SELECT --BL.BLR_RN, BL.INSURED_PLAN_ID, BL.PREMIUM_DUE_DATE,
                                    app.application_id,
                                    CASE
                                            WHEN app.appl_signature_date IS NULL
                                                 OR ( app.appl_signature_date > app.requested_effective_date ) THEN
                                                CASE
                                                    WHEN app.appl_receipt_date IS NULL
                                                         OR ( app.appl_receipt_date > app.requested_effective_date ) THEN
                                                        CASE
                                                            WHEN app.creation_date > app.requested_effective_date THEN app.requested_effective_date
                                                            ELSE app.creation_date
                                                        END
                                                    ELSE app.appl_receipt_date
                                                END
                                            ELSE app.appl_signature_date
                                        END
                                    AS current_signature_date,
                                    CASE
                                            WHEN pbm.prdct_grp <> ''Med Supp'' THEN ''-2''
                                            WHEN pbm.prdct_grp = ''Med Supp''
                                                 AND chl.acqn_chnl_lvl_3 IS  NULL THEN ''-2''
                                            WHEN  chl.acqn_chnl_lvl_3 IS  NULL  THEN ''-2''
                                            WHEN agent_type_id IS NULL THEN ''-1''
                                            ELSE nvl(aag_wr.agent_id,''-1'')
                                        END
                                    AS agent_id,
                                    nvl(agent_type_id,1) agent_type_id
                                FROM          /*DM.WRK_PREMIUM_DATA_BL_REBUILD BL
LEFT JOIN     COMPAS.INSURED_PLAN IP    ON     BL.INSURED_PLAN_ID = IP.INSURED_PLAN_ID*/
                                    SRC_COMPAS_D.application app
                                    LEFT JOIN SRC_COMPAS_D.insured_plan ip ON app.application_id = ip.application_id
									LEFT JOIN (SELECT DISTINCT 
        INSURED_PLAN_ID,
		INS_PLAN_BEN_MOD_START_DATE,
		INS_PLAN_BEN_MOD_STOP_DATE,
		CASE 
			WHEN NVL(BENEFIT_MOD_TYPE_ID,-1) BETWEEN 1 AND 4 THEN 1
			WHEN NVL(BENEFIT_MOD_TYPE_ID,-1) BETWEEN 5 AND 6 THEN 2
		ELSE 0
		  END AS PlanCdBenModCat     
	  FROM SRC_COMPAS_D.INSURED_PLAN_BENEFIT_MOD
		WHERE BENEFIT_MOD_TYPE_ID BETWEEN 1 AND 6 ) ipbenmod ON ( IP.INSURED_PLAN_ID = ipbenmod.insured_plan_id)
                                    LEFT JOIN bdr_conf.d_pln_ben_mod pbm ON NVL(pbm.compas_pln_cd,''zz'') =  NVL(ip.plan_cd,''zz'')
									AND NVL(ipbenmod.PlanCdBenModCat,0) = NVL(pbm.compas_ben_mod_catgy_id,0)
                                    LEFT JOIN SRC_COMPAS_D.application_agent aag_wr ON ( (
                                        app.application_id = aag_wr.application_id
                                        AND aag_wr.agent_type_id = 1
                                    ) )
                                    LEFT JOIN bdr_dm.wrk_acquisitionchannel wac ON app.application_id = wac.applicationid
                                    LEFT JOIN (
                                        SELECT DISTINCT
                                            acqn_chnl_lvl_3
                                        FROM
                                            bdr_conf.d_acqn_chnl
                                        WHERE
                                            acqn_chnl_lvl_1  IN (
                                                ''Aggregator'',
                                                ''Agent''
                                            )
                                    ) chl ON wac.acquisitionchannel = chl.acqn_chnl_lvl_3
                                UNION
                                SELECT       -- BL.BLR_RN,BL.INSURED_PLAN_ID, BL.PREMIUM_DUE_DATE,
                                    app.application_id,
                                    CASE
                                            WHEN app.appl_signature_date IS NULL
                                                 OR ( app.appl_signature_date > app.requested_effective_date ) THEN
                                                CASE
                                                    WHEN app.appl_receipt_date IS NULL
                                                         OR ( app.appl_receipt_date > app.requested_effective_date ) THEN
                                                        CASE
                                                            WHEN app.creation_date > app.requested_effective_date THEN app.requested_effective_date
                                                            ELSE app.creation_date
                                                        END
                                                    ELSE app.appl_receipt_date
                                                END
                                            ELSE app.appl_signature_date
                                        END
                                    AS current_signature_date,
                                    CASE
                                            WHEN pbm.prdct_grp <> ''Med Supp'' THEN ''-2''
                                            WHEN pbm.prdct_grp = ''Med Supp''
                                                 AND chl.acqn_chnl_lvl_3 IS  NULL THEN ''-2''
                                            WHEN  chl.acqn_chnl_lvl_3 IS  NULL  THEN ''-2''
                                            WHEN agent_type_id IS NULL THEN ''-1''
                                            ELSE nvl(aag_wr.agent_id,''-1'')
                                        END
                                    AS agent_id,
                                    nvl(agent_type_id,2) agent_type_id
                                FROM
                                    SRC_COMPAS_D.application app
                                    LEFT JOIN SRC_COMPAS_D.insured_plan ip ON app.application_id = ip.application_id
									LEFT JOIN (SELECT DISTINCT 
        INSURED_PLAN_ID,
		INS_PLAN_BEN_MOD_START_DATE,
		INS_PLAN_BEN_MOD_STOP_DATE,
		CASE 
			WHEN NVL(BENEFIT_MOD_TYPE_ID,-1) BETWEEN 1 AND 4 THEN 1
			WHEN NVL(BENEFIT_MOD_TYPE_ID,-1) BETWEEN 5 AND 6 THEN 2
		ELSE 0
		  END AS PlanCdBenModCat     
	  FROM SRC_COMPAS_D.INSURED_PLAN_BENEFIT_MOD
		WHERE BENEFIT_MOD_TYPE_ID BETWEEN 1 AND 6 ) ipbenmod ON ( IP.INSURED_PLAN_ID = ipbenmod.insured_plan_id)
                                    LEFT JOIN bdr_conf.d_pln_ben_mod pbm ON NVL(pbm.compas_pln_cd,''zz'') =  NVL(ip.plan_cd,''zz'')
									AND NVL(ipbenmod.PlanCdBenModCat,0) = NVL(pbm.compas_ben_mod_catgy_id,0)
                                    LEFT JOIN SRC_COMPAS_D.application_agent aag_wr ON ( (
                                        app.application_id = aag_wr.application_id
                                        AND aag_wr.agent_type_id = 2
                                    ) )
                                    LEFT JOIN bdr_dm.wrk_acquisitionchannel wac ON app.application_id = wac.applicationid
                                    LEFT JOIN (
                                        SELECT DISTINCT
                                            acqn_chnl_lvl_3
                                        FROM
                                            bdr_conf.d_acqn_chnl
                                        WHERE
                                            acqn_chnl_lvl_1  IN (
                                                ''Aggregator'',
                                                ''Agent''
                                            )
                                    ) chl ON wac.acquisitionchannel = chl.acqn_chnl_lvl_3
                                UNION
                                SELECT        --BL.BLR_RN,BL.INSURED_PLAN_ID, BL.PREMIUM_DUE_DATE,
                                    app.application_id,
                                    CASE
                                            WHEN app.appl_signature_date IS NULL
                                                 OR ( app.appl_signature_date > app.requested_effective_date ) THEN
                                                CASE
                                                    WHEN app.appl_receipt_date IS NULL
                                                         OR ( app.appl_receipt_date > app.requested_effective_date ) THEN
                                                        CASE
                                                            WHEN app.creation_date > app.requested_effective_date THEN app.requested_effective_date
                                                            ELSE app.creation_date
                                                        END
                                                    ELSE app.appl_receipt_date
                                                END
                                            ELSE app.appl_signature_date
                                        END
                                    AS current_signature_date,
                                    CASE
                                            WHEN pbm.prdct_grp <> ''Med Supp'' THEN ''-2''
                                            WHEN pbm.prdct_grp = ''Med Supp'' AND chl.acqn_chnl_lvl_3 IS  NULL THEN ''-2''
											WHEN chl.acqn_chnl_lvl_3 IS  NULL  THEN ''-2''
                                            WHEN agent_type_id IS NULL THEN ''-2''
                                            ELSE nvl(aag_wr.agent_id,''-1'')
                                        END
                                    AS agent_id,
                                    nvl(agent_type_id,5) agent_type_id
                                FROM
                                    SRC_COMPAS_D.application app
                                    LEFT JOIN SRC_COMPAS_D.insured_plan ip ON app.application_id = ip.application_id
									LEFT JOIN (SELECT DISTINCT 
        INSURED_PLAN_ID,
		INS_PLAN_BEN_MOD_START_DATE,
		INS_PLAN_BEN_MOD_STOP_DATE,
		CASE 
			WHEN NVL(BENEFIT_MOD_TYPE_ID,-1) BETWEEN 1 AND 4 THEN 1
			WHEN NVL(BENEFIT_MOD_TYPE_ID,-1) BETWEEN 5 AND 6 THEN 2
		ELSE 0
		  END AS PlanCdBenModCat     
	  FROM SRC_COMPAS_D.INSURED_PLAN_BENEFIT_MOD
		WHERE BENEFIT_MOD_TYPE_ID BETWEEN 1 AND 6 ) ipbenmod ON ( IP.INSURED_PLAN_ID = ipbenmod.insured_plan_id)
                                    LEFT JOIN bdr_conf.d_pln_ben_mod pbm ON NVL(pbm.compas_pln_cd,''zz'') =  NVL(ip.plan_cd,''zz'')
									AND NVL(ipbenmod.PlanCdBenModCat,0) = NVL(pbm.compas_ben_mod_catgy_id,0)
                                    LEFT JOIN SRC_COMPAS_D.application_agent aag_wr ON ( (
                                        app.application_id = aag_wr.application_id
                                        AND aag_wr.agent_type_id = 5
                                    ) )
                                    LEFT JOIN bdr_dm.wrk_acquisitionchannel wac ON app.application_id = wac.applicationid
                                    LEFT JOIN (
                                        SELECT DISTINCT
                                            acqn_chnl_lvl_3
                                        FROM
                                            bdr_conf.d_acqn_chnl
                                        WHERE
                                            acqn_chnl_lvl_1  IN (
                                                ''Aggregator'',
                                                ''Agent''
                                            )
                                    ) chl ON wac.acquisitionchannel = chl.acqn_chnl_lvl_3
                            ) blr
                            LEFT JOIN bdr_dm.temp_agt_org_selling_writing wr_sel_ref_agt ON blr.agent_id = wr_sel_ref_agt.agt_id
                    )
            ) SELECT  
                DISTINCT  --added on 04/10/2025
				actionflg,
                application_id,
                agent_id,
                current_signature_date,
                nvl(d_agt_sk,-1) AS d_agt_sk
              FROM
                (
                    SELECT
                        alt.actionflg,
                        alt.application_id,
                        alt.d_agt_sk,
                        alt.agent_id,
                        alt.agent_type_id,
                        alt.current_signature_date,
                        alt.row_eff_strt_dt,
                        alt.agt_wrt_strt_dt_id,
                        alt.agt_id,
                        ROW_NUMBER() OVER(
                            PARTITION BY alt.application_id
                            ORDER BY
                                abs(DATEDIFF(day,alt.current_signature_date, TO_DATE(alt.agt_wrt_strt_dt_id::VARCHAR,''YYYYMMDD''))),alt.row_eff_strt_dt DESC
                        ) AS rn
                    FROM
                        (
                            SELECT
                                *
                            FROM
                                tmp_appl_writing_selling_referral
                            WHERE
                                actionflg = ''ZOTHERSWRITING''
                        ) alt
                        LEFT JOIN tmp_appl_writing_selling_referral mtch ON mtch.application_id = alt.application_id
                                                                            AND mtch.actionflg = ''MATCHEDWRITING''
                    WHERE
                        mtch.application_id IS NULL
                    UNION
                    SELECT

                        alt.actionflg,
                        alt.application_id,
                        alt.d_agt_sk,
                        alt.agent_id,
                        alt.agent_type_id,
                        alt.current_signature_date,
                        alt.row_eff_strt_dt,
                        alt.agt_wrt_strt_dt_id,
                        alt.agt_id,
                        ROW_NUMBER() OVER(
                            PARTITION BY alt.application_id
                            ORDER BY
                                abs(DATEDIFF(day, alt.current_signature_date, TO_DATE(alt.agt_wrt_strt_dt_id::VARCHAR,''YYYYMMDD''))),alt.row_eff_strt_dt DESC
                        ) rn
                    FROM
                        (
                            SELECT
                                *
                            FROM
                                tmp_appl_writing_selling_referral
                            WHERE
                                actionflg = ''ZOTHERSSELLING''
                        ) alt
                        LEFT JOIN tmp_appl_writing_selling_referral mtch ON mtch.application_id = alt.application_id
                                                                            AND mtch.actionflg = ''MATCHEDSELLING''
                    WHERE
                        mtch.application_id IS NULL
                    UNION
                    SELECT
                        alt.actionflg,
                        alt.application_id,
                        alt.d_agt_sk,
                        alt.agent_id,
                        alt.agent_type_id,
                        alt.current_signature_date,
                        alt.row_eff_strt_dt,
                        alt.agt_wrt_strt_dt_id,
                        alt.agt_id,
                        ROW_NUMBER() OVER(
                            PARTITION BY alt.application_id
                            ORDER BY
                                abs(DATEDIFF(day, alt.current_signature_date, TO_DATE(alt.agt_wrt_strt_dt_id::VARCHAR,''YYYYMMDD''))),alt.row_eff_strt_dt DESC
                        ) AS rn
                    FROM
                        (
                            SELECT
                                *
                            FROM
                                tmp_appl_writing_selling_referral
                            WHERE
                                actionflg = ''ZOTHERSREFERRAL''
                        ) alt
                        LEFT JOIN tmp_appl_writing_selling_referral mtch ON mtch.application_id = alt.application_id
                                                                            AND mtch.actionflg = ''MATCHEDREFERRAL''
                    WHERE
                        mtch.application_id IS NULL
                )
              WHERE
                rn = 1
            UNION ALL
            SELECT DISTINCT ---added on 04/10/2025 
                actionflg,
                application_id,
                agent_id,
                current_signature_date,
                d_agt_sk
            FROM
                tmp_appl_writing_selling_referral
            WHERE
                actionflg IN (
                    ''MATCHEDSELLING'',
                    ''MATCHEDWRITING'',
                    ''MATCHEDREFERRAL''
                )
            UNION ALL
            SELECT  DISTINCT ---added on 04/10/2025 
                actionflg,
                application_id,
                agent_id,
                current_signature_date,
                CAST(agent_id AS INT) AS d_agt_sk
            FROM
                tmp_appl_writing_selling_referral
            WHERE
                actionflg IN (
                    ''AGENTSELLING'',
                    ''AGENTWRITING'',
                    ''AGENTREFERRAL''
                )
        );
		
		
		
V_STEP_NAME    := ''INSERT WRK_APPL_WRITING_AGENT'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_ROWS_INSERTED := (SELECT count(1) FROM BDR_DM.WRK_APPL_WRITING_AGENT);

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );


V_STEP_NAME    := ''INSERT WRK_APPL_SELLING_AGENT'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_ROWS_INSERTED := (SELECT count(1) FROM BDR_DM.WRK_APPL_WRITING_AGENT);

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

V_STEP_NAME    := ''INSERT WRK_APPL_REFERRAL_AGENT'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_ROWS_INSERTED := (SELECT count(1) FROM BDR_DM.WRK_APPL_WRITING_AGENT);

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

	
V_STEP_NAME    := ''DELETE wrk_appl_selling_agent'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

    DELETE  FROM bdr_dm.wrk_appl_selling_agent
    WHERE
        ( application_id,
          agt_sel_d_agt_sk ) IN (
            SELECT DISTINCT
                application_id,
                agt_sel_d_agt_sk
            FROM
                (
                    SELECT 
                        application_id,
                        selling_agent,
                        current_signature_date,
                        agt_sel_d_agt_sk,
                        ROW_NUMBER() OVER(
                            PARTITION BY application_id,selling_agent,current_signature_date
                            ORDER BY
                                agt_sel_d_agt_sk DESC
                        ) rn
                    FROM
                        bdr_dm.wrk_appl_selling_agent
                )
            WHERE
                rn > 1
        );

	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_DELETED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

V_STEP_NAME    := ''DELETE wrk_appl_writing_agent'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

    DELETE FROM bdr_dm.wrk_appl_writing_agent
    WHERE
        ( application_id,
          agt_wrt_d_agt_sk ) IN (
            SELECT DISTINCT
                application_id,
                agt_wrt_d_agt_sk
            FROM
                (
                    SELECT 
                        application_id,
                        writing_agent,
                        current_signature_date,
                        agt_wrt_d_agt_sk,
                        ROW_NUMBER() OVER(
                            PARTITION BY application_id,writing_agent,current_signature_date
                            ORDER BY
                                agt_wrt_d_agt_sk DESC
                        ) rn
                    FROM
                        bdr_dm.wrk_appl_writing_agent
                )
            WHERE
                rn > 1
        );

	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_DELETED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

V_STEP_NAME    := ''DELETE wrk_appl_referral_agent'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

    DELETE FROM bdr_dm.wrk_appl_referral_agent
    WHERE
        ( application_id,
          agt_ref_d_agt_sk ) IN (
            SELECT DISTINCT
                application_id,
                agt_ref_d_agt_sk
            FROM
                (
                    SELECT 
                        application_id,
                        referral_agent,
                        current_signature_date,
                        agt_ref_d_agt_sk,
                        ROW_NUMBER() OVER(
                            PARTITION BY application_id,referral_agent,current_signature_date
                            ORDER BY
                                agt_ref_d_agt_sk DESC
                        ) rn
                    FROM
                        bdr_dm.wrk_appl_referral_agent
                )
            WHERE
                rn > 1
        );

	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_DELETED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );



--  delete /*+ enable_parallel_dml parallel(8) */  from DM.WRK_APPL_SELLING_AGENT where AGT_SEL_SKEY in
--  (SELECT AGT_SEL_SKEY FROM(select /*+ parallel(8) */  BLR_RN,SELLING_AGENT,CURRENT_SIGNATURE_DATE,AGT_SEL_SKEY, ROW_NUMBER() OVER(PARTITION BY BLR_RN,SELLING_AGENT,CURRENT_SIGNATURE_DATE
--              ORDER BY AGT_SEL_SKEY DESC) RN FROM  DM.WRK_APPL_SELLING_AGENT) WHERE RN>1);
--              V_ROWS_AFFTD:=SQL%ROWCOUNT;
--              commit;
--  
--  delete /*+ enable_parallel_dml parallel(8) */  from DM.WRK_APPL_WRITING_AGENT where AGT_WRT_SKEY in
--    (SELECT AGT_WRT_SKEY FROM(select /*+ parallel(8) */  BLR_RN,WRITING_AGENT,CURRENT_SIGNATURE_DATE,AGT_WRT_SKEY ,ROW_NUMBER() OVER(PARTITION BY BLR_RN,WRITING_AGENT,CURRENT_SIGNATURE_DATE
--              ORDER BY AGT_WRT_SKEY DESC) RN FROM  DM.WRK_APPL_WRITING_AGENT) WHERE RN>1);
--              V_ROWS_AFFTD:=SQL%ROWCOUNT;
--              commit;
--  
--   delete /*+ enable_parallel_dml parallel(8) */  from DM.WRK_APPL_REFERRAL_AGENT where AGT_REF_SKEY in
--    (SELECT AGT_REF_SKEY FROM(select /*+ parallel(8) */  BLR_RN, REFERRAL_AGENT, CURRENT_SIGNATURE_DATE, AGT_REF_SKEY, ROW_NUMBER() OVER(PARTITION BY BLR_RN, REFERRAL_AGENT, CURRENT_SIGNATURE_DATE
--              ORDER BY AGT_REF_SKEY DESC) RN FROM  DM.WRK_APPL_REFERRAL_AGENT) WHERE RN>1);
--              V_ROWS_AFFTD:=SQL%ROWCOUNT;
--              commit;

CALL UTIL.SP_ETL_CHECK_CONSTRAINTS(:DB_NAME , :APPLICATION , :WORKFLOW_NAME , :OBJECT_NAME , :V_BATCH_ID );


UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''COMPLETE'', ERROR_MSG = null, BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
;
UPDATE  UTIL.ETL_BATCH_OBJECT_INCR_VALU SET INCR_COLUMN_VALUE = :V_BATCH_ID, LST_MOD_DT = CURRENT_TIMESTAMP() 
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID''
;

EXCEPTION

WHEN OTHER THEN

UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''ERROR'', ERROR_MSG = :SQLERRM,  BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
;

INSERT INTO  UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ERROR_MSG, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''ERROR'', :V_STEP_NAME, :V_STEP_SEQ, :SQLERRM, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() )
;



RAISE;

END;

';