USE SCHEMA BDR_DM; CREATE OR REPLACE PROCEDURE "SP_CLAIMS_U_OCRSBLLNHST_LNKEXP_M"("DB_NAME" VARCHAR(16777216), "APPLICATION" VARCHAR(16777216), "WORKFLOW_NAME" VARCHAR(16777216), "OBJECT_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '

-- Original workflow: wkf_Claims_Fact_IXL_TargetLoad4_M
-- Original mapping: m_Claims_U_OCRSBLLNHST_LNKEXP_M
-- Original folder: Claims
-- Original filename: wkf_Claims_Fact_IXL_TargetLoad4_M.XML

DECLARE


V_ROWS_INSERTED  INTEGER;
V_ROWS_UPDATED INTEGER;
V_ROWS_DELETED INTEGER;
V_LAST_QUERY_ID VARCHAR;

V_WH VARCHAR;
V_BATCH_ID INTEGER;


V_BATCH_OBJECT_START_TIME        VARCHAR;
V_STEP_START_TIME    VARCHAR;
V_STEP_NAME VARCHAR;
V_STEP_SEQ INTEGER DEFAULT 0;
V_ETL_LST_BTCH_ID INTEGER;

lv_flip_bit         NUMBER (1,0);
V_CUTOFFDT VARCHAR;





BEGIN

EXECUTE IMMEDIATE ''USE DATABASE ''||:DB_NAME; 

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_BATCH_OBJECT_START_TIME := (SELECT CURRENT_TIMESTAMP());



LET res1 RESULTSET := 
(

SELECT 

WH ,
BATCH_ID
  
FROM UTIL.ETL_BATCH_OBJECT_CONTROL
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
FETCH FIRST 1 ROW ONLY

)
;


LET C1 CURSOR FOR res1;
open C1;
FETCH C1 into  V_WH,V_BATCH_ID ;
close C1;


LET res2 RESULTSET := 

(

WITH PARAMETERS (CUTOFFDT) AS
(
  
SELECT * 
FROM  
(SELECT PARAMETER_NAME, PARAMETER_VALUE  FROM UTIL.ETL_OBJECT_PARAMETER_VALUE 
WHERE 1 = 1
AND APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
AND ACTIVE_FLG = ''Y''  
  
UNION ALL       

SELECT PARAMETER_NAME, PARAMETER_VALUE  FROM UTIL.ETL_GLOBAL_PARAMETER_VALUE WHERE PAR_GLOBAL_TYPE = ''PARGLOBAL_OPREPORTS'' AND ACTIVE_FLG = ''Y''
AND PARAMETER_NAME NOT IN  (
SELECT PARAMETER_NAME  FROM UTIL.ETL_OBJECT_PARAMETER_VALUE WHERE 1 = 1
AND APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
AND ACTIVE_FLG = ''Y''   ))
 
PIVOT(MAX(PARAMETER_VALUE) FOR PARAMETER_NAME IN (''CUTOFFDT'')) 

 
)  
SELECT * FROM PARAMETERS 
)  
  
;


LET C2 CURSOR FOR res2;
open C2;
FETCH C2 into  V_CUTOFFDT; 
close C2;



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:V_WH;
USE SCHEMA BDR_DM;		--OAS ADD


INSERT INTO UTIL.ETL_BATCH_OBJECT_INCR_VALU (APPLICATION, WORKFLOW_NAME, OBJECT_NAME, INCR_COLUMN, INCR_COLUMN_VALUE )
SELECT * FROM (select :APPLICATION AS APPLICATION, :WORKFLOW_NAME AS WORKFLOW_NAME, :OBJECT_NAME AS OBJECT_NAME, ''ETL_LST_BTCH_ID'' AS INCR_COLUMN, -1 AS INCR_COLUMN_VALUE) A
WHERE NOT EXISTS (SELECT 1 FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU B WHERE B.APPLICATION = A.APPLICATION AND B.WORKFLOW_NAME = A.WORKFLOW_NAME AND B.OBJECT_NAME = A.OBJECT_NAME AND B.INCR_COLUMN = A.INCR_COLUMN)
;

V_ETL_LST_BTCH_ID :=(SELECT INCR_COLUMN_VALUE FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID'');
--COMMENTED BY OAS--
/*
CREATE OR REPLACE PROCEDURE DM.SP_CLM_U_OCRSBLLNHST_LNKEXP_M
(
    iv_Dummy IN NUMBER,
    P_ToContinueStatus OUT VARCHAR2,
    P_ErrorYNFlg OUT VARCHAR2,
    P_ErrorStr OUT VARCHAR2 )
  ---------------------------------------------------------------------------
  --Purpose         : This procedure updatesocrsbilllinefacteHistory fact table
  --  This procedure will link Claim data with Premium (Exception scenario)
  --Application Ref : Program Global Dashboard
  --Called From     :
  --Author          : By CTS    Inital Date : 8/28/2017
  --Change History
  ---------------------------------------------------------------------------
  --    Date			 Who Changed        What Changed
  --	02/05/2018		 Swetal Brahmbhatt  Added ADW/CDW Decom attributes
  ---------------------------------------------------------------------------
  -- Begin Standard Declarations
  -- Begin Local Variables
AS
  lv_daterange_start  NUMBER(8);
  lv_daterange_end    NUMBER(8);
  lv_clm_lnkg_strt_dt NUMBER(8);
  lv_clm_lnkg_end_dt  NUMBER(8);
  lv_cutoff_dt        DATE;
  lv_btch_size        NUMBER (8) := 1000000;
  lv_flip_bit         NUMBER (1);
  V_BTCH_ID           NUMBER(10);
  V_PROC_NAME         VARCHAR(50):=''SP_CLM_U_OCRSBLLNHST_LNKEXP_M'';
  V_ROWS_AFFTD        NUMBER(20) :=0;
BEGIN
  SELECT MAX(BATCH_ID)
  INTO V_BTCH_ID
  FROM ETL.ETL_BATCH_LOG
  WHERE APPLICATION=''CDC''
  AND BATCH_STATUS =''COMPLETE'';
  INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''MONTHLY_CLAIMS'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''START'',
      ''PROCEDURE STARTS'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );
  COMMIT;*/
  --COMMENTED BY OAS--
  
  /* SELECT
    CASE
      WHEN TO_CHAR(SYSDATE,''YYYYMMDD'')>= NVL(MAX(Metadata_value) ,''0000000'')
      THEN 1
      ELSE 0
    END
  INTO lv_flip_bit
  FROM ETL.ETL_APPLICATION_METADATA
  WHERE Application = ''CLAIMS''
  AND METADATA_TYPE = ''CUTOFFDT'' AND METADATA_DESC=''F_CLAIM_HIST'';
  DBMS_OUTPUT.PUT_LINE(''MONTHLY CLAIMS | sp_clm_upd_ocrsbilln_lnk_exp_m | INSERT | PROCEDURE STARTS | ''||SQL%ROWCOUNT ||'' | ''||systimestamp); */	--OAS DELETE
  
  SELECT
    CASE
      WHEN TO_CHAR(CURRENT_TIMESTAMP,''YYYYMMDD'')>= NVL(:V_CUTOFFDT ,''0000000'')
      THEN 1
      ELSE 0
    END
  INTO lv_flip_bit
  FROM DUAL;

V_STEP_NAME    := ''TRUNCATE - TEMP_BIL_LN_HIST_MONTHLY'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

  EXECUTE IMMEDIATE ''TRUNCATE TABLE BDR_DM.TEMP_BIL_LN_HIST_MONTHLY'';

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

V_STEP_NAME    := ''TRUNCATE - TEMP_F_PREM_TRANS_MO_OCRSEXP'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

  EXECUTE IMMEDIATE ''TRUNCATE TABLE BDR_DM.TEMP_F_PREM_TRANS_MO_OCRSEXP'';

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

  --Insert BillLine data into temp table which are not linked
  
V_STEP_NAME    := ''INSERT - temp_bil_ln_hist_monthly'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

  INSERT /*+ enable_parallel_dml APPEND */
  INTO BDR_DM.temp_bil_ln_hist_monthly(BIL_LN_HIST_SK, D_MBR_INFO_SK, INCUR_DT_ID, D_CLM_PLN_SK, TEMP_D_PLN_BEN_MOD_SK, TEMP_RES_D_GEO_XREF_SK, TEMP_CERT_EFF_DT_ID, PLN_ISS_D_GEO_XREF_SK, TEMP_D_RTNG_AREA_SK, D_GDR_ID_SK, PREM_DUE_AGE_ID, CLM_STS_CD, CERT_D_ACQN_CHNL_SK, PRDCT_D_ACQN_CHNL_SK, MBR_D_ACQN_CHNL_SK, D_UNDWR_TAG_SK, COMPAS_PLN_DSPL_CD, PLANSUBGROUP, F_PREM_TRANS_MO_SK, PRDCT_EFF_DT_ID, D_LGL_ENTY_SK, AGT_WRT_D_AGT_SK, AGT_SEL_ORIG_D_AGT_SK, AGT_SEL_D_AGT_SK, AGT_DCM_WRT_D_AGT_SK, D_EMP_SK, D_RET_TYP_SK, UPDATEIND, TABLE_NAME, D_DSCNT_ANNL_PAYR_SK, D_DSCNT_EFT_SK, D_DSCNT_ERLY_ENRL_SK, D_DSCNT_LNGVTY_SK, D_DSCNT_MULTI_INSD_SK, D_SURCHRG_TIER_SK, D_SURCHRG_TBCC_USER_SK, D_INSD_PLN_PRFL_SK, D_CALC_RT_SK, MEDSUP_PLN_ENT_AGE_LOOK_FRAC, CERT_EFF_AGE_LOOK_FRAC, AGT_REF_ORIG_D_AGT_SK, AGT_REF_D_AGT_SK, D_NEW_TO_MEDCR_SK)
    (SELECT /*+ parallel(8) */ 
		--BL.ROWID ROW_ID,		--OAS DELETE
        BL.OCRS_BL_HIST_SKEY ,
        BL.MEMBER_INFO_SKEY ,
        SUBSTR(BL.INCURRAL_DATE_ID, 0, 6) INCURRAL_DATE_ID ,
        BL.CLAIM_PLAN_SKEY ,
        BL.TEMP_PLAN_BEN_MOD_SKEY ,
        BL.TEMP_RESIDENT_GEOGRAPHY_SKEY ,
        BL.TEMP_CERT_EFFECTIVE_DATE_ID ,
        BL.PLAN_ISSUE_GEOGRAPHY_SKEY ,
        BL.TEMP_RATING_AREA_SKEY ,
        BL.GENDER_ID ,
        BL.PREMIUM_DUE_AGE_ID ,
        NULL AS CLM_STS_CD,
        -1 CERT_D_ACQN_CHNL_SK ,
        -1 PRDCT_D_ACQN_CHNL_SK ,
        -1 MBR_D_ACQN_CHNL_SK ,
        -1 D_UNDWR_TAG_SK ,
        NULL AS COMPAS_PLN_DSPL_CD,
        NULL AS PLANSUBGROUP,
        -1 F_PREM_TRANS_MO_SK ,
        -1 PRDCT_EFF_DT_ID ,
        -1 D_LGL_ENTY_SK ,
        -1 AGT_WRT_D_AGT_SK ,
        -1 AGT_SEL_ORIG_D_AGT_SK ,
        -1 AGT_SEL_D_AGT_SK ,
        -1 AGT_DCM_WRT_D_AGT_SK ,
        -1 D_EMP_SK ,
        -1 D_RET_TYP_SK ,
        0 UpDateInd ,
        ''F_OCRS_BIL_LN_HIST_LNKG_EXCEPTION'' AS TABLE_NAME,
		-1	D_DSCNT_ANNL_PAYR_SK,
		-1	D_DSCNT_EFT_SK,
		-1	D_DSCNT_ERLY_ENRL_SK,
		-1	D_DSCNT_LNGVTY_SK,
		-1	D_DSCNT_MULTI_INSD_SK,
		-1	D_SURCHRG_TIER_SK,
		-1	D_SURCHRG_TBCC_USER_SK,
		-1	D_INSD_PLN_PRFL_SK,
		-1	D_CALC_RT_SK,
		999.99 MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
		999.99 CERT_EFF_AGE_LOOK_FRAC,
		-2 AGT_REF_ORIG_D_AGT_SK,
		-2 AGT_REF_D_AGT_SK,
		1 D_NEW_TO_MEDCR_SK
         FROM BDR_DM.WRK_OCRS_BILL_LINE_HIST BL
      INNER JOIN BDR_DM.D_CLM_PLN CL ON
  	  CL.D_CLM_PLN_SK=BL.CLAIM_PLAN_SKEY
      WHERE CLM_PREM_LNK_KEY = 0
      AND INCURRAL_DATE_ID   > -1
    );
	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

  --COMMENTED BY OAS--
/*V_ROWS_AFFTD:=SQL%ROWCOUNT;

  COMMIT;

 -- BDR_DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''TEMP_BIL_LN_HIST_MONTHLY'');
  --DBMS_OUTPUT.PUT_LINE(''MONTHLY CLAIMS | sp_clm_upd_ocrsbilln_lnk_exp_m | INSERT | Insert into temp table BDR_DM.temp_bil_ln_hist_monthly | ''||SQL%ROWCOUNT ||'' | ''||systimestamp);
  INSERT INTO etl.etl_detail_load_info
            (application,
             etl_batch_id,
             etl_proc_name,
             action,
             step_info,
             rows_affected,
             etl_datetime)
VALUES      ( ''MONTHLY_CLAIMS'',
             v_btch_id,
             v_proc_name,
             ''INSERT'',
             ''INSERT INTO TEMP TABLE'',
             v_rows_afftd,
             systimestamp );
 COMMIT;
     --DBMS_STATS.GATHER_TABLE_STATS (ownname => ''DM'',tabname => ''TEMP_PREM_LNK_MONTHLY'',partname => NULL,estimate_percent => 10,
      --DEGREE => 4, granularity => ''ALL'', method_opt => ''FOR ALL COLUMNS SIZE 1'',CASCADE => TRUE);

BDR_DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''TEMP_PREM_LNK_MONTHLY'');*/
--COMMENTED BY OAS--

V_STEP_NAME    := ''INSERT - temp_f_prem_trans_mo_ocrsexp'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

INSERT /*+ enable_parallel_dml APPEND */ INTO BDR_DM.temp_f_prem_trans_mo_ocrsexp
(SELECT /*+ parallel(8) */ BIL_LN_HIST_SK,F_PREM_TRANS_MO_SK,PREM_DUE_MO_ID,D_MBR_INFO_SK,D_PLN_BEN_MOD_SK,CERT_EFF_MO_ID,CERT_TRM_MO_ID,RES_D_GEO_XREF_SK,PLN_ISS_D_GEO_XREF_SK,D_RTNG_AREA_SK,PREM_DUE_AGE_ID,D_GDR_ID_SK,PD_CERT_QTY,DELQ_CERT_QTY,TERM_CERT_QTY,PD_PREM_AMT,DELQ_PREM_AMT,COMPAS_INSD_PLN_ID,ACTV_MO_ID,XCLD_FROM_DFLT_FLG,ETL_LST_BTCH_ID,PRDCT_D_ACQN_CHNL_SK,CERT_D_ACQN_CHNL_SK,MBR_D_ACQN_CHNL_SK,ACCT_NBR,D_CERT_ACTV_SK,D_UNDWR_TAG_SK,PRDCT_EFF_MO_ID,D_LGL_ENTY_SK,MBR_PD_PREM_AMT,MBR_DELQ_PREM_AMT,EMP_PD_PREM_AMT,EMP_DELQ_PREM_AMT,AGT_WRT_D_AGT_SK,AGT_SEL_ORIG_D_AGT_SK,AGT_SEL_D_AGT_SK,D_RET_TYP_SK,D_EMP_SK,AGT_DCM_WRT_D_AGT_SK,RN,
         D_DSCNT_ANNL_PAYR_SK,D_DSCNT_EFT_SK,D_DSCNT_ERLY_ENRL_SK,D_DSCNT_LNGVTY_SK,D_DSCNT_MULTI_INSD_SK,D_SURCHRG_TBCC_USER_SK,D_SURCHRG_TIER_SK,D_INSD_PLN_PRFL_SK,D_CALC_RT_SK,MEDSUP_PLN_ENT_AGE_LOOK_FRAC,CERT_EFF_AGE_LOOK_FRAC, AGT_REF_ORIG_D_AGT_SK, AGT_REF_D_AGT_SK,D_NEW_TO_MEDCR_SK
 FROM   (SELECT bl.bil_ln_hist_sk,
                prm.*, bl.incur_dt_id,
                -- Modified for PAT Missmatch 15Mar2018
                --Row_number() over ( PARTITION BY prm.d_mbr_info_sk, prm.prem_due_mo_id, prm.d_pln_ben_mod_sk ORDER BY prm.actv_mo_id DESC) rn
                Row_number() over ( PARTITION BY prm.d_mbr_info_sk, prm.prem_due_mo_id, prm.d_pln_ben_mod_sk ORDER BY prm.actv_mo_id DESC, prm.f_prem_trans_mo_sk desc) rn
         FROM   BDR_DM.temp_bil_ln_hist_monthly bl
                join BDR_CONF.d_mbr_info m1
                  ON bl.d_mbr_info_sk = m1.d_mbr_info_sk
                join BDR_CONF.d_mbr_info m2
                  ON m1.isid = m2.isid
                join BDR_DM.f_prem_trans_mo prm
                  ON m2.d_mbr_info_sk = prm.d_mbr_info_sk
         WHERE   prm.d_mbr_info_sk >- 1
                AND ( prm.pd_cert_qty > 0
                       OR prm.delq_cert_qty > 0 )
              --  AND prm.prem_due_mo_id BETWEEN ( bl.incur_dt_id - 100 ) AND ( bl.incur_dt_id + 100 )
                )
 WHERE  rn = 1 AND prem_due_mo_id BETWEEN ( incur_dt_id - 100 ) AND ( incur_dt_id + 100 ));

 --commit;
 	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );


     --DBMS_STATS.GATHER_TABLE_STATS (ownname => ''DM'',tabname => ''TEMP_F_PREM_TRANS_MO_OCRSEXP'',partname => NULL,estimate_percent => 10,
     -- DEGREE => 4, granularity => ''ALL'', method_opt => ''FOR ALL COLUMNS SIZE 1'',CASCADE => TRUE);
 -- BDR_DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''TEMP_F_PREM_TRANS_MO_OCRSEXP'');			--OAS DELETE
  --Update Member and Geography attributes based on the matching MemberInfoSkey and Incurral to PremiumDue
  
V_STEP_NAME    := ''MERGE - TEMP_BIL_LN_HIST_MONTHLY'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

     MERGE /*+ enable_parallel_dml parallel */ INTO BDR_DM.TEMP_BIL_LN_HIST_MonthLY BL1 USING
  ( WITH tt_F_PREM_TRANS_MO AS
    (SELECT
      /* +METERIALIZE */
      Prm.D_MBR_INFO_SK ,
      Prm.PREM_DUE_MO_ID ,
      Prm.D_PLN_BEN_MOD_SK ,
      MAX(Prm.ACTV_MO_ID) MaxACTV_MO_ID
    FROM BDR_DM.TEMP_BIL_LN_HIST_MONTHLY BL
    JOIN BDR_CONF.D_MBR_INFO M1
    ON BL.D_MBR_INFO_SK = M1.D_MBR_INFO_SK
    JOIN BDR_CONF.D_MBR_INFO M2
    ON M1.ISID = M2.ISID
    JOIN BDR_DM.F_PREM_TRANS_MO Prm
    ON M2.D_MBR_INFO_SK   = Prm.D_MBR_INFO_SK
    WHERE Prm.D_MBR_INFO_SK > -1
    AND ( Prm.PD_CERT_QTY > 0
    OR Prm.DELQ_CERT_QTY  > 0 )
    GROUP BY Prm.D_MBR_INFO_SK,
      Prm.PREM_DUE_MO_ID,
      Prm.D_PLN_BEN_MOD_SK
    )

  select /*+ parallel(8) */ * from (SELECT BL1.TEMP_BIL_LN_HIST_MONTHLY_SK/* ROW_ID */ row_ID,
    -- Modified for PAT Missmatch 15Mar2018
    --ROW_NUMBER() OVER (PARTITION BY BL1.BIL_LN_HIST_SK,BL1.D_MBR_INFO_SK,P.PREM_DUE_MO_ID ORDER BY P.F_PREM_TRANS_MO_SK) AS RN,
    ROW_NUMBER() OVER (PARTITION BY BL1.BIL_LN_HIST_SK,BL1.D_MBR_INFO_SK,P.PREM_DUE_MO_ID ORDER BY P.ACTV_MO_ID DESC, P.F_PREM_TRANS_MO_SK DESC) AS RN,
    P.RES_D_GEO_XREF_SK,
    P.PLN_ISS_D_GEO_XREF_SK,
    P.D_GDR_ID_SK,
    P.F_PREM_TRANS_MO_SK,
    P.D_EMP_SK,
    P.D_RET_TYP_SK,
    1
  FROM BDR_DM.TEMP_BIL_LN_HIST_MONTHLY BL1
  JOIN BDR_CONF.D_MBR_INFO M1  ON BL1.D_MBR_INFO_SK = M1.D_MBR_INFO_SK
  JOIN BDR_CONF.D_MBR_INFO M2  ON M1.ISID = M2.ISID
  JOIN TT_F_PREM_TRANS_MO TPrm  ON M2.D_MBR_INFO_SK = TPrm.D_MBR_INFO_SK  AND BL1.INCUR_DT_ID = TPrm.PREM_DUE_MO_ID
  JOIN BDR_DM.F_PREM_TRANS_MO P
  ON P.D_MBR_INFO_SK     = TPrm.D_MBR_INFO_SK
  AND P.PREM_DUE_MO_ID   = TPrm.PREM_DUE_MO_ID
  AND P.D_PLN_BEN_MOD_SK = TPrm.D_PLN_BEN_MOD_SK
  AND P.ACTV_MO_ID       = TPrm.MaxACTV_MO_ID
  WHERE P.PD_CERT_QTY      > 0
  OR P.DELQ_CERT_QTY     > 0
)
where rn=1
)
  src ON ( BL1.TEMP_BIL_LN_HIST_MONTHLY_SK/* ROW_ID */ = src.row_ID  )
WHEN MATCHED THEN
  UPDATE
  SET BL1.TEMP_RES_D_GEO_XREF_SK = src.RES_D_GEO_XREF_SK,
    BL1.PLN_ISS_D_GEO_XREF_SK    = src.PLN_ISS_D_GEO_XREF_SK,
    BL1.D_GDR_ID_SK              = src.D_GDR_ID_SK,
    BL1.F_PREM_TRANS_MO_SK       = src.F_PREM_TRANS_MO_SK,
    BL1.D_EMP_SK                 = src.D_EMP_SK,
    BL1.D_RET_TYP_SK             = src.D_RET_TYP_SK,
    BL1.UpDateInd                = 1;
	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

  --COMMENTED BY OAS--
/*V_ROWS_AFFTD:=SQL%ROWCOUNT;

  commit;

  BDR_DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''TEMP_BIL_LN_HIST_MonthLY''); -- Adding stats 02/01/2018
  INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''MONTHLY_CLAIMS'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''MERGE'',
      ''UPDATE MEMBER AND GEOGRAPHY ATTRIBUTES BASED ON THE MATCHING MEMBERINFOSKEY AND INCURRAL TO PREMIUMDUE'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );

  DBMS_OUTPUT.PUT_LINE(''MONTHLY CLAIMS | sp_clm_upd_ocrsbilln_lnk_exp_m | UPDATE | Update Member and Geography attributes based on the matching MemberInfoSkey and Incurral to PremiumDue | ''||SQL%ROWCOUNT ||'' | ''||systimestamp);
  --Get all the requiredinfo with travesing mechanism to find nearest PremiumDueMonth
   COMMIT;*/
--COMMENTED BY OAS--
  
V_STEP_NAME    := ''MERGE - TEMP_BIL_LN_HIST_MONTHLY'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

  MERGE /*+ enable_parallel_dml parallel */ INTO BDR_DM.TEMP_BIL_LN_HIST_MONTHLY bl1 USING
  ( SELECT /*+ parallel(8) */
    bl2.row_id row_id,
    bl2.d_pln_ben_mod_sk,
    bl2.cert_eff_dt_id,
    bl2.d_rtng_area_sk,
    bl2.pln_iss_d_geo_xref_sk,
    CAST( ( ( (CAST(CAST( (bl2.prem_due_age_id * 12) AS DECIMAL(5,0) ) AS int) ) + (-1 * (actualmindiff) ) ) / 12.00) AS DECIMAL(6,2) ) prem_due_age_id_derived,
    bl2.cert_d_acqn_chnl_sk,
    bl2.prdct_d_acqn_chnl_sk,
    bl2.mbr_d_acqn_chnl_sk,
    bl2.d_undwr_tag_sk,
    CASE WHEN bl2.prdct_eff_mo_id =-1 THEN ''-1'' ELSE NVL(TO_CHAR(bl2.prdct_eff_mo_id), '''') ||  ''01'' END
    AS prdct_eff_dt_id,
    bl2.d_lgl_enty_sk,
    bl2.f_prem_trans_mo_sk,
    bl2.agt_wrt_d_agt_sk,
    bl2.agt_sel_orig_d_agt_sk,
    bl2.agt_sel_d_agt_sk,
    bl2.agt_dcm_wrt_d_agt_sk,
    bl2.TEMP_RES_D_GEO_XREF_SK,
    bl2.d_gdr_id_sk,
    bl2.d_mbr_info_sk,
    bl2.D_EMP_SK,
    bl2.D_RET_TYP_SK,
    2 updateind,
	bl2.D_DSCNT_ANNL_PAYR_SK,
	bl2.D_DSCNT_EFT_SK,
	bl2.D_DSCNT_ERLY_ENRL_SK,
	bl2.D_DSCNT_LNGVTY_SK,
	bl2.D_DSCNT_MULTI_INSD_SK,
	bl2.D_SURCHRG_TIER_SK,
	bl2.D_SURCHRG_TBCC_USER_SK,
	bl2.D_INSD_PLN_PRFL_SK,
	bl2.D_CALC_RT_SK,
	bl2.MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
	bl2.CERT_EFF_AGE_LOOK_FRAC,
	bl2.AGT_REF_ORIG_D_AGT_SK,
	bl2.AGT_REF_D_AGT_SK,
	bl2.D_NEW_TO_MEDCR_SK
FROM
    (
        SELECT
            bl1.TEMP_BIL_LN_HIST_MONTHLY_SK/* row_id */ row_id,
            bl1.bil_ln_hist_sk f_ocrs_bil_ln_hist_sk,
         --   p.d_mbr_info_sk,
            p.d_pln_ben_mod_sk,
            p.res_d_geo_xref_sk,
            NVL(TO_CHAR(p.cert_eff_mo_id), '''') ||  ''01'' cert_eff_dt_id,
            p.pln_iss_d_geo_xref_sk,
            p.d_rtng_area_sk,
         --   p.d_gdr_id_sk,
            p.prem_due_age_id,
            abs(months_between(TO_DATE(TO_CHAR(p.prem_due_mo_id),''YYYYMM''),TO_DATE(TO_CHAR(bl1.incur_dt_id),''YYYYMM'') ) ) mindiff,
            months_between(TO_DATE(TO_CHAR(p.prem_due_mo_id),''YYYYMM''), TO_DATE(TO_CHAR(bl1.incur_dt_id),''YYYYMM'') ) actualmindiff,
            ROW_NUMBER() OVER(PARTITION BY
                bl1.bil_ln_hist_sk
                ORDER BY
                    bl1.bil_ln_hist_sk,
                    abs(months_between(TO_DATE(TO_CHAR(p.prem_due_mo_id),''YYYYMM''),TO_DATE(TO_CHAR(bl1.incur_dt_id),''YYYYMM'') ) ),
                    bl1.prem_due_age_id,
                    updateind
                DESC
            ) rn_updind1,
            ROW_NUMBER() OVER(PARTITION BY
                bl1.bil_ln_hist_sk
                ORDER BY
                    bl1.bil_ln_hist_sk,
                    abs(months_between(TO_DATE(TO_CHAR(p.prem_due_mo_id),''YYYYMM''),TO_DATE(TO_CHAR(bl1.incur_dt_id),''YYYYMM'') ) ),
                    bl1.prem_due_age_id,
                    updateind
            ) rn_updind0,
            p.cert_d_acqn_chnl_sk,
            p.prdct_d_acqn_chnl_sk,
            p.mbr_d_acqn_chnl_sk,
            p.d_undwr_tag_sk,
            p.f_prem_trans_mo_sk,
            p.prdct_eff_mo_id,
            p.d_lgl_enty_sk,
            p.agt_wrt_d_agt_sk,
            p.agt_sel_orig_d_agt_sk,
            p.agt_sel_d_agt_sk,
            p.agt_dcm_wrt_d_agt_sk,
       --      p.d_emp_sk,
       --     p.d_ret_typ_sk,
            updateind,
            case when updateind=1 then bl1.TEMP_RES_D_GEO_XREF_SK else p.res_d_geo_xref_sk end as TEMP_RES_D_GEO_XREF_SK,
            case when updateind=1 then bl1.d_gdr_id_sk else p.d_gdr_id_sk end as d_gdr_id_sk,
            case when updateind=1 then bl1.d_mbr_info_sk else p.d_mbr_info_sk end as d_mbr_info_sk,
            case when updateind=1 then bl1.D_EMP_SK else p.d_emp_sk end as D_EMP_SK,
            case when updateind=1 then bl1.D_RET_TYP_SK else p.d_ret_typ_sk end as D_RET_TYP_SK,
			P.D_DSCNT_ANNL_PAYR_SK,
			P.D_DSCNT_EFT_SK,
			P.D_DSCNT_ERLY_ENRL_SK,
			P.D_DSCNT_LNGVTY_SK,
			P.D_DSCNT_MULTI_INSD_SK,
			P.D_SURCHRG_TIER_SK,
			P.D_SURCHRG_TBCC_USER_SK,
			P.D_INSD_PLN_PRFL_SK,
			P.D_CALC_RT_SK,
			P.MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
			P.CERT_EFF_AGE_LOOK_FRAC,
			P.AGT_REF_ORIG_D_AGT_SK,
	                P.AGT_REF_D_AGT_SK,
					P.D_NEW_TO_MEDCR_SK
        FROM
            BDR_DM.temp_bil_ln_hist_monthly bl1
            JOIN BDR_DM.d_clm_pln cp ON bl1.d_clm_pln_sk = cp.d_clm_pln_sk
            JOIN BDR_DM.temp_f_prem_trans_mo_ocrsexp p ON bl1.d_mbr_info_sk = p.d_mbr_info_sk
            JOIN BDR_CONF.d_pln_ben_mod pb ON p.d_pln_ben_mod_sk = pb.d_pln_ben_mod_sk AND cp.compas_pln_dspl_cd = pb.compas_pln_dspl_cd
    ) bl2
WHERE
    rn_updind1 = 1 AND     rn_updind0 = 1
  ) src ON ( bl1.TEMP_BIL_LN_HIST_MONTHLY_SK/* row_id */  = src.row_id  )
WHEN MATCHED THEN --UpDate the temp table for matching COMPAS_PLN_DSPL_CD
  UPDATE
  SET
    bl1.temp_d_pln_ben_mod_sk 	= src.d_pln_ben_mod_sk,
    bl1.TEMP_RES_D_GEO_XREF_SK 	= src.TEMP_RES_D_GEO_XREF_SK,
    bl1.temp_cert_eff_dt_id     = src.cert_eff_dt_id,
    bl1.pln_iss_d_geo_xref_sk   = src.pln_iss_d_geo_xref_sk,
    bl1.temp_d_rtng_area_sk     = src.d_rtng_area_sk,
    bl1.D_GDR_ID_SK             = src.d_gdr_id_sk,
    bl1.prem_due_age_id         = src.prem_due_age_id_derived,
    bl1.d_mbr_info_sk           = src.d_mbr_info_sk,
    bl1.cert_d_acqn_chnl_sk     = src.cert_d_acqn_chnl_sk,
    bl1.prdct_d_acqn_chnl_sk    = src.prdct_d_acqn_chnl_sk,
    bl1.mbr_d_acqn_chnl_sk      = src.mbr_d_acqn_chnl_sk,
    bl1.d_undwr_tag_sk          = src.d_undwr_tag_sk,
    bl1.prdct_eff_dt_id         = src.prdct_eff_dt_id,
    bl1.d_lgl_enty_sk           = src.d_lgl_enty_sk,
    bl1.f_prem_trans_mo_sk      = src.f_prem_trans_mo_sk,
    bl1.agt_wrt_d_agt_sk        = src.agt_wrt_d_agt_sk,
    bl1.agt_sel_orig_d_agt_sk   = src.agt_sel_orig_d_agt_sk,
    bl1.agt_sel_d_agt_sk        = src.agt_sel_d_agt_sk,
    bl1.agt_dcm_wrt_d_agt_sk    = src.agt_dcm_wrt_d_agt_sk,
    bl1.D_EMP_SK                = src.D_EMP_SK,
    bl1.D_RET_TYP_SK            = src.D_RET_TYP_SK,
	bl1.D_DSCNT_ANNL_PAYR_SK = SRC.D_DSCNT_ANNL_PAYR_SK,
	bl1.D_DSCNT_EFT_SK = SRC.D_DSCNT_EFT_SK,
	bl1.D_DSCNT_ERLY_ENRL_SK = SRC.D_DSCNT_ERLY_ENRL_SK,
	bl1.D_DSCNT_LNGVTY_SK = SRC.D_DSCNT_LNGVTY_SK,
	bl1.D_DSCNT_MULTI_INSD_SK = SRC.D_DSCNT_MULTI_INSD_SK,
	bl1.D_SURCHRG_TIER_SK = SRC.D_SURCHRG_TIER_SK,
	bl1.D_SURCHRG_TBCC_USER_SK = SRC.D_SURCHRG_TBCC_USER_SK,
	bl1.D_INSD_PLN_PRFL_SK = SRC.D_INSD_PLN_PRFL_SK,
	bl1.D_CALC_RT_SK = SRC.D_CALC_RT_SK,
	bl1.MEDSUP_PLN_ENT_AGE_LOOK_FRAC = SRC.MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
	bl1.CERT_EFF_AGE_LOOK_FRAC = SRC.CERT_EFF_AGE_LOOK_FRAC,
	bl1.AGT_REF_ORIG_D_AGT_SK = SRC.AGT_REF_ORIG_D_AGT_SK,
	bl1.AGT_REF_D_AGT_SK  =  SRC.AGT_REF_D_AGT_SK,
        bl1.updateind               = 2,
		bl1.D_NEW_TO_MEDCR_SK = SRC.D_NEW_TO_MEDCR_SK;

 -- COMMIT;
 	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

  --COMMENTED BY OAS--
/*V_ROWS_AFFTD:=SQL%ROWCOUNT;

   COMMIT;
BDR_DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''TEMP_BIL_LN_HIST_MonthLY''); -- Adding stats 02/01/2018
  INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''MONTHLY_CLAIMS'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''MERGE'',
      ''UPDATE THE TEMP TABLE FOR MATCHING COMPAS_PLN_DSPL_CD AND RECORDS DUE TO TRAVERSING MECHANISM'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );
commit;
  DBMS_OUTPUT.PUT_LINE(''MONTHLY CLAIMS | sp_clm_upd_ocrsbilln_lnk_exp_m | UPDATE | UpDate the temp table for matching COMPAS_PLN_DSPL_CD and records due to traversing mechanism | ''||SQL%ROWCOUNT ||'' | ''||systimestamp);*/
--COMMENTED BY OAS--
  
V_STEP_NAME    := ''MERGE - TEMP_BIL_LN_HIST_MONTHLY'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

MERGE /*+ enable_parallel_dml parallel */
INTO  BDR_DM.temp_bil_ln_hist_monthly bl1
using (
      SELECT  /*+ parallel(8) */     bl2.row_id row_id,
                   bl2.d_pln_ben_mod_sk,
                   bl2.cert_eff_dt_id,
                   bl2.d_rtng_area_sk,
                   bl2.pln_iss_d_geo_xref_sk,
                   Cast( ( ( (Cast(Cast( (bl2.prem_due_age_id * 12) AS DECIMAL(5,0) ) AS INT) ) + (-1 * (actualmindiff) ) ) / 12.00) AS DECIMAL(6,2) ) prem_due_age_id,
                   bl2.cert_d_acqn_chnl_sk,
                   bl2.prdct_d_acqn_chnl_sk,
                   bl2.mbr_d_acqn_chnl_sk,
                   bl2.d_undwr_tag_sk,
                   CASE
                                WHEN bl2.prdct_eff_mo_id =-1 THEN ''-1''
                                ELSE NVL(TO_CHAR(bl2.prdct_eff_mo_id), '''')
                                                          || ''01''
                   END AS prdct_eff_dt_id,
                   bl2.d_lgl_enty_sk,
                   bl2.f_prem_trans_mo_sk,
                   bl2.agt_wrt_d_agt_sk,
                   bl2.agt_sel_orig_d_agt_sk,
                   bl2.agt_sel_d_agt_sk,
                   bl2.agt_dcm_wrt_d_agt_sk,
				       bl2.TEMP_RES_D_GEO_XREF_SK,
					bl2.d_gdr_id_sk,
				bl2.D_EMP_SK,
				bl2.D_RET_TYP_SK,
                   2 updateind,
				   bl2.D_DSCNT_ANNL_PAYR_SK,
					bl2.D_DSCNT_EFT_SK,
					bl2.D_DSCNT_ERLY_ENRL_SK,
					bl2.D_DSCNT_LNGVTY_SK,
					bl2.D_DSCNT_MULTI_INSD_SK,
					bl2.D_SURCHRG_TIER_SK,
					bl2.D_SURCHRG_TBCC_USER_SK,
					bl2.D_INSD_PLN_PRFL_SK,
					bl2.D_CALC_RT_SK,
					bl2.MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
					bl2.CERT_EFF_AGE_LOOK_FRAC,
					bl2.AGT_REF_ORIG_D_AGT_SK,
					bl2.AGT_REF_D_AGT_SK,
					bl2.D_NEW_TO_MEDCR_SK
      FROM         (
                     SELECT   bl1.TEMP_BIL_LN_HIST_MONTHLY_SK/* row_id */         row_id,
                              bl1.bil_ln_hist_sk f_ocrs_bil_ln_hist_sk,
                              p.d_mbr_info_sk,
                              p.d_pln_ben_mod_sk,
                              p.res_d_geo_xref_sk,
                              NVL(TO_CHAR(p.cert_eff_mo_id), '''')
                                       || ''01'' cert_eff_dt_id,
                              p.pln_iss_d_geo_xref_sk,
                              p.d_rtng_area_sk,
                           --   p.d_gdr_id_sk,
                              p.prem_due_age_id,
                              Abs(Months_between(To_date(TO_CHAR(bl1.incur_dt_id),''YYYYMM''),To_date(TO_CHAR(p.prem_due_mo_id),''YYYYMM'') ) ) mindiff,
                              Months_between(To_date(TO_CHAR(bl1.incur_dt_id),''YYYYMM''),To_date(TO_CHAR(p.prem_due_mo_id),''YYYYMM'') ) actualmindiff,
                              Row_number() OVER(partition BY bl1.bil_ln_hist_sk ORDER BY bl1.bil_ln_hist_sk, Abs(Months_between(To_date(TO_CHAR(bl1.incur_dt_id),''YYYYMM''),To_date(TO_CHAR(p.prem_due_mo_id),''YYYYMM'') ) ), bl1.prem_due_age_id, updateind DESC ) rn_updind1,
                              Row_number() OVER(partition BY bl1.bil_ln_hist_sk ORDER BY bl1.bil_ln_hist_sk, Abs(Months_between(To_date(TO_CHAR(bl1.incur_dt_id),''YYYYMM''),To_date(TO_CHAR(p.prem_due_mo_id),''YYYYMM'') ) ), bl1.prem_due_age_id, updateind )      rn_updind0,
                              p.cert_d_acqn_chnl_sk,
                              p.prdct_d_acqn_chnl_sk,
                              p.mbr_d_acqn_chnl_sk,
                              p.d_undwr_tag_sk,
                              p.f_prem_trans_mo_sk,
                              p.prdct_eff_mo_id,
                              p.d_lgl_enty_sk,
                              p.agt_wrt_d_agt_sk,
                              p.agt_sel_orig_d_agt_sk,
                              p.agt_sel_d_agt_sk,
                              p.agt_dcm_wrt_d_agt_sk,
                              p.d_emp_sk,
                              p.d_ret_typ_sk,
                              updateind,
							  case when updateind=1 then bl1.TEMP_RES_D_GEO_XREF_SK else p.res_d_geo_xref_sk end as TEMP_RES_D_GEO_XREF_SK,
							  case when updateind=1 then bl1.d_gdr_id_sk else p.d_gdr_id_sk end as d_gdr_id_sk,
							  P.D_DSCNT_ANNL_PAYR_SK,
								P.D_DSCNT_EFT_SK,
								P.D_DSCNT_ERLY_ENRL_SK,
								P.D_DSCNT_LNGVTY_SK,
								P.D_DSCNT_MULTI_INSD_SK,
								P.D_SURCHRG_TIER_SK,
								P.D_SURCHRG_TBCC_USER_SK,
								P.D_INSD_PLN_PRFL_SK,
								P.D_CALC_RT_SK,
								P.MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
								P.CERT_EFF_AGE_LOOK_FRAC,
								P.AGT_REF_ORIG_D_AGT_SK,
					                        P.AGT_REF_D_AGT_SK,
											P.D_NEW_TO_MEDCR_SK

                     FROM     BDR_DM.temp_bil_ln_hist_monthly  bl1
                     JOIN     BDR_DM.d_clm_pln cp
                     ON       bl1.d_clm_pln_sk = cp.d_clm_pln_sk
                     JOIN     BDR_DM.temp_f_prem_trans_mo_ocrsexp p
                     ON       bl1.d_mbr_info_sk = p.d_mbr_info_sk
                     JOIN     BDR_CONF.d_pln_ben_mod pb
                     ON       p.d_pln_ben_mod_sk = pb.d_pln_ben_mod_sk
                     AND      cp.pln_grp = pb.pln_grp -------------PlanSubGroup -------------
                     WHERE    updateind IN (0,1 )
	) BL2 WHERE
    rn_updind1 = 1 AND     rn_updind0 = 1) src
ON (bl1.TEMP_BIL_LN_HIST_MONTHLY_SK/* row_id */ = src.row_id )
WHEN matched THEN
UPDATE
  SET
    bl1.temp_d_pln_ben_mod_sk 	= src.d_pln_ben_mod_sk,
    bl1.TEMP_RES_D_GEO_XREF_SK 	= src.TEMP_RES_D_GEO_XREF_SK,
    bl1.temp_cert_eff_dt_id     = src.cert_eff_dt_id,
    bl1.pln_iss_d_geo_xref_sk   = src.pln_iss_d_geo_xref_sk,
    bl1.temp_d_rtng_area_sk     = src.d_rtng_area_sk,
    bl1.D_GDR_ID_SK             = src.d_gdr_id_sk,
    bl1.prem_due_age_id         = src.prem_due_age_id,
    bl1.cert_d_acqn_chnl_sk     = src.cert_d_acqn_chnl_sk,
    bl1.prdct_d_acqn_chnl_sk    = src.prdct_d_acqn_chnl_sk,
    bl1.mbr_d_acqn_chnl_sk      = src.mbr_d_acqn_chnl_sk,
    bl1.d_undwr_tag_sk          = src.d_undwr_tag_sk,
    bl1.prdct_eff_dt_id         = src.prdct_eff_dt_id,
    bl1.d_lgl_enty_sk           = src.d_lgl_enty_sk,
    bl1.f_prem_trans_mo_sk      = src.f_prem_trans_mo_sk,
    bl1.agt_wrt_d_agt_sk        = src.agt_wrt_d_agt_sk,
    bl1.agt_sel_orig_d_agt_sk   = src.agt_sel_orig_d_agt_sk,
    bl1.agt_sel_d_agt_sk        = src.agt_sel_d_agt_sk,
    bl1.agt_dcm_wrt_d_agt_sk    = src.agt_dcm_wrt_d_agt_sk,
    bl1.D_EMP_SK                = src.D_EMP_SK,
    bl1.D_RET_TYP_SK            = src.D_RET_TYP_SK,
	bl1.D_DSCNT_ANNL_PAYR_SK = SRC.D_DSCNT_ANNL_PAYR_SK,
	bl1.D_DSCNT_EFT_SK = SRC.D_DSCNT_EFT_SK,
	bl1.D_DSCNT_ERLY_ENRL_SK = SRC.D_DSCNT_ERLY_ENRL_SK,
	bl1.D_DSCNT_LNGVTY_SK = SRC.D_DSCNT_LNGVTY_SK,
	bl1.D_DSCNT_MULTI_INSD_SK = SRC.D_DSCNT_MULTI_INSD_SK,
	bl1.D_SURCHRG_TIER_SK = SRC.D_SURCHRG_TIER_SK,
	bl1.D_SURCHRG_TBCC_USER_SK = SRC.D_SURCHRG_TBCC_USER_SK,
	bl1.D_INSD_PLN_PRFL_SK = SRC.D_INSD_PLN_PRFL_SK,
	bl1.D_CALC_RT_SK = SRC.D_CALC_RT_SK,
	bl1.MEDSUP_PLN_ENT_AGE_LOOK_FRAC = SRC.MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
	bl1.CERT_EFF_AGE_LOOK_FRAC = SRC.CERT_EFF_AGE_LOOK_FRAC,
	bl1.AGT_REF_ORIG_D_AGT_SK  = SRC.AGT_REF_ORIG_D_AGT_SK,
	bl1.AGT_REF_D_AGT_SK = SRC.AGT_REF_D_AGT_SK,
        bl1.updateind               = 2,
		bl1.D_NEW_TO_MEDCR_SK = SRC.D_NEW_TO_MEDCR_SK;
 -- COMMIT;
 	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

  --COMMENTED BY OAS--
/*V_ROWS_AFFTD:=SQL%ROWCOUNT;

   COMMIT;

   BDR_DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''TEMP_BIL_LN_HIST_MonthLY''); -- Adding stats 02/01/2018
  INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,      ETL_BATCH_ID,      ETL_PROC_NAME ,      ACTION ,      STEP_INFO ,      ROWS_AFFECTED ,      ETL_DATETIME
    )
    VALUES
    (
      ''MONTHLY_CLAIMS'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''MERGE'',
      ''UPDATE THE TEMP TABLE FOR MATCHING COMPAS_PLN_DSPL_CD AND RECORDS DUE TO TRAVERSING MECHANISM'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );
commit;
   DBMS_OUTPUT.PUT_LINE(''MONTHLY CLAIMS | sp_clm_upd_ocrsbilln_lnk_exp_m | UPDATE | UpDate the temp table for matching PLAN_GROUP and records due to traversing mechanism| ''||SQL%ROWCOUNT ||'' | ''||systimestamp);*/
   --COMMENTED BY OAS--
  --INSERT INTO Temp table where INCUR_DT_ID is unknown -1
    
V_STEP_NAME    := ''INSERT - TEMP_BIL_LN_HIST_MONTHLY'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

  INSERT /*+ enable_parallel_dml APPEND */
  INTO BDR_DM.temp_bil_ln_hist_monthly(BIL_LN_HIST_SK, D_MBR_INFO_SK, INCUR_DT_ID, D_CLM_PLN_SK, TEMP_D_PLN_BEN_MOD_SK, TEMP_RES_D_GEO_XREF_SK, TEMP_CERT_EFF_DT_ID, PLN_ISS_D_GEO_XREF_SK, TEMP_D_RTNG_AREA_SK, D_GDR_ID_SK, PREM_DUE_AGE_ID, CLM_STS_CD, CERT_D_ACQN_CHNL_SK, PRDCT_D_ACQN_CHNL_SK, MBR_D_ACQN_CHNL_SK, D_UNDWR_TAG_SK, COMPAS_PLN_DSPL_CD, PLANSUBGROUP, F_PREM_TRANS_MO_SK, PRDCT_EFF_DT_ID, D_LGL_ENTY_SK, AGT_WRT_D_AGT_SK, AGT_SEL_ORIG_D_AGT_SK, AGT_SEL_D_AGT_SK, AGT_DCM_WRT_D_AGT_SK, D_EMP_SK, D_RET_TYP_SK, UPDATEIND, TABLE_NAME, D_DSCNT_ANNL_PAYR_SK, D_DSCNT_EFT_SK, D_DSCNT_ERLY_ENRL_SK, D_DSCNT_LNGVTY_SK, D_DSCNT_MULTI_INSD_SK, D_SURCHRG_TIER_SK, D_SURCHRG_TBCC_USER_SK, D_INSD_PLN_PRFL_SK, D_CALC_RT_SK, MEDSUP_PLN_ENT_AGE_LOOK_FRAC, CERT_EFF_AGE_LOOK_FRAC, AGT_REF_ORIG_D_AGT_SK, AGT_REF_D_AGT_SK, D_NEW_TO_MEDCR_SK)
    (SELECT /*+ parallel(8) */ 
		--BL.ROWID ROW_ID,		--OAS DELETE
        BL.OCRS_BL_HIST_SKEY ,
        BL.MEMBER_INFO_SKEY ,
        SUBSTR(BL.INCURRAL_DATE_ID, 0, 6) INCURRAL_DATE_ID ,
        BL.CLAIM_PLAN_SKEY ,
        BL.TEMP_PLAN_BEN_MOD_SKEY ,
       -- BL.RESIDENT_GEOGRAPHY_SKEY ,
        BL.temp_RESIDENT_GEOGRAPHY_SKEY ,
        BL.TEMP_CERT_EFFECTIVE_DATE_ID ,
        BL.PLAN_ISSUE_GEOGRAPHY_SKEY ,
        BL.TEMP_RATING_AREA_SKEY ,
        BL.GENDER_ID ,
        BL.PREMIUM_DUE_AGE_ID ,
        NULL AS CLM_STS_CD,
        -1 CERT_D_ACQN_CHNL_SK ,
        -1 PRDCT_D_ACQN_CHNL_SK ,
        -1 MBR_D_ACQN_CHNL_SK ,
        -1 D_UNDWR_TAG_SK ,
        NULL AS COMPAS_PLN_DSPL_CD,
        NULL AS PLANSUBGROUP,
        -1 F_PREM_TRANS_MO_SK ,
        -1 PRDCT_EFF_DT_ID ,
        -1 D_LGL_ENTY_SK ,
        -1 AGT_WRT_D_AGT_SK ,
        -1 AGT_SEL_ORIG_D_AGT_SK ,
        -1 AGT_SEL_D_AGT_SK ,
        -1 AGT_DCM_WRT_D_AGT_SK ,
        -1 D_EMP_SK ,
        -1 D_RET_TYP_SK ,
        0 UpDateInd ,
        ''F_OCRS_BIL_LN_HIST_LNKG_EXCEPTION'' AS TABLE_NAME,
		-1	D_DSCNT_ANNL_PAYR_SK,
		-1	D_DSCNT_EFT_SK,
		-1	D_DSCNT_ERLY_ENRL_SK,
		-1	D_DSCNT_LNGVTY_SK,
		-1	D_DSCNT_MULTI_INSD_SK,
		-1	D_SURCHRG_TIER_SK,
		-1	D_SURCHRG_TBCC_USER_SK,
		-1	D_INSD_PLN_PRFL_SK,
		-1	D_CALC_RT_SK,
		999.99 MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
		999.99 CERT_EFF_AGE_LOOK_FRAC,
		-2 AGT_REF_ORIG_D_AGT_SK,
		-2 AGT_REF_D_AGT_SK,
		1 D_NEW_TO_MEDCR_SK
      FROM BDR_DM.WRK_OCRS_BILL_LINE_HIST BL
      WHERE CLM_PREM_LNK_KEY = 0
      AND INCURRAL_DATE_ID   = -1
    );
 -- COMMIT;
 	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

  --COMMENTED BY OAS--
/*V_ROWS_AFFTD:=SQL%ROWCOUNT;

  COMMIT;

  BDR_DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''TEMP_BIL_LN_HIST_MONTHLY'');
  INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''MONTHLY_CLAIMS'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''INSERT'',
      '' INSERT THE INCURRAL_DATE_ID = -1 RECORDS INTO TEMP TABLE BDR_DM.TEMP_BIL_LN_HIST_MONTHLY'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );
 COMMIT;
  DBMS_OUTPUT.PUT_LINE(''MONTHLY CLAIMS | sp_clm_upd_ocrsbilln_lnk_exp_m | INSERT | Insert the INCURRAL_DATE_ID = -1 records into temp table BDR_DM.temp_bil_ln_hist_monthly | ''||SQL%ROWCOUNT ||'' | ''||systimestamp);*/
--COMMENTED BY OAS--
  --UpDate D_PLN_BEN_MOD_SK for not linked data
    
V_STEP_NAME    := ''MERGE - TEMP_BIL_LN_HIST_MONTHLY'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

  MERGE /*+ enable_parallel_dml parallel */ INTO BDR_DM.temp_bil_ln_hist_monthly b USING
  (SELECT /*+ parallel(8) */ b.TEMP_BIL_LN_HIST_MONTHLY_SK/* row_id */ row_id,
      pb.d_pln_ben_mod_sk,
      2
    FROM BDR_DM.temp_bil_ln_hist_monthly b
    JOIN BDR_DM.d_clm_pln cp
    ON b.d_clm_pln_sk = cp.d_clm_pln_sk
    JOIN
      (SELECT /*+ parallel(8) */ pb.d_pln_ben_mod_sk,
        pb.compas_pln_dspl_cd,
        pb.compas_pln_cd
      FROM BDR_CONF.d_pln_ben_mod pb
      JOIN
        (SELECT /*+ parallel(8) */ compas_pln_cd,
          COUNT(compas_pln_cd) cnt
        FROM BDR_CONF.d_pln_ben_mod
        GROUP BY compas_pln_cd
        HAVING COUNT(compas_pln_cd) > 1
        ) pb1
      ON pb.compas_pln_cd            = pb1.compas_pln_cd
      WHERE ( compas_ben_mod_catgy_id IS NOT NULL AND COMPAS_BEN_MOD_CATGY_ID!=0 ) -- Added for SCR#64787
      UNION
      SELECT /*+ parallel(8) */ pb.d_pln_ben_mod_sk,
        pb.compas_pln_dspl_cd,
        pb.compas_pln_cd
      FROM BDR_CONF.d_pln_ben_mod pb
      JOIN
        (SELECT /*+ parallel(8) */ compas_pln_cd,
          COUNT(compas_pln_cd) cnt
        FROM BDR_CONF.d_pln_ben_mod
        GROUP BY compas_pln_cd
        HAVING COUNT(compas_pln_cd) = 1
        ) pb1
      ON pb.compas_pln_cd = pb1.compas_pln_cd
      ) pb
    ON cp.compas_pln_cd    = pb.compas_pln_cd
    WHERE d_pln_ben_mod_sk =-1
  )
  src ON ( b.TEMP_BIL_LN_HIST_MONTHLY_SK/* row_id */ = src.row_id  )
WHEN MATCHED THEN
  UPDATE SET b.temp_d_pln_ben_mod_sk = src.d_pln_ben_mod_sk, b.updateind = 2;
 --COMMIT;
 	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

  --COMMENTED BY OAS--
/*V_ROWS_AFFTD:=SQL%ROWCOUNT;

   COMMIT;

   BDR_DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''TEMP_BIL_LN_HIST_MonthLY''); -- Adding stats 02/01/2018
  INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''MONTHLY_CLAIMS'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''MERGE'',
      ''UPDATE D_PLN_BEN_MOD_SK FOR NOT LINKED DATA'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );
commit;
  DBMS_OUTPUT.PUT_LINE(''MONTHLY CLAIMS | sp_clm_upd_ocrsbilln_lnk_exp_m | UPDATE | UpDate D_PLN_BEN_MOD_SK for not linked data | ''||SQL%ROWCOUNT ||'' | ''||systimestamp);*/
--COMMENTED BY OAS--
  --UpDate BillLine fact
    
V_STEP_NAME    := ''MERGE - wrk_ocrs_bill_line_hist'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

  MERGE /*+ enable_parallel_dml parallel */ INTO BDR_DM.wrk_ocrs_bill_line_hist bl USING
  (SELECT /*+ parallel(8) */ bl.OCRS_BL_HIST_SKEY/* rowid */ row_id,
      blt.temp_d_pln_ben_mod_sk,
      CASE
        WHEN :lv_flip_bit = 1
        THEN blt.temp_d_pln_ben_mod_sk
        ELSE bl.plan_ben_mod_skey
      END AS plan_ben_mod_skey,
      blt.temp_res_d_geo_xref_sk,
      CASE
        WHEN :lv_flip_bit = 1
        THEN blt.temp_res_d_geo_xref_sk
        ELSE bl.resident_geography_skey
      END AS resident_geography_skey,
      blt.temp_cert_eff_dt_id,
      CASE
        WHEN :lv_flip_bit = 1
        THEN blt.temp_cert_eff_dt_id
        ELSE bl.cert_effective_date_id
      END AS cert_effective_date_id,
      blt.pln_iss_d_geo_xref_sk,
      blt.temp_d_rtng_area_sk,
      CASE
        WHEN :lv_flip_bit = 1
        THEN blt.temp_d_rtng_area_sk
        ELSE bl.rating_area_skey
      END AS rating_area_skey,
      blt.d_gdr_id_sk,
      blt.prem_due_age_id,
      blt.cert_d_acqn_chnl_sk,
      blt.prdct_d_acqn_chnl_sk,
      blt.mbr_d_acqn_chnl_sk,
      blt.d_undwr_tag_sk,
      blt.prdct_eff_dt_id,
      blt.d_lgl_enty_sk,
      blt.f_prem_trans_mo_sk,
      blt.agt_wrt_d_agt_sk,
      blt.agt_sel_orig_d_agt_sk,
      blt.agt_sel_d_agt_sk,
      blt.agt_dcm_wrt_d_agt_sk,
      blt.d_emp_sk,
      blt.d_ret_typ_sk,
      CASE
        WHEN blt.f_prem_trans_mo_sk =-1
        THEN 0
        ELSE 2
      END AS CLM_PREM_LNK_KEY,
	  blt.D_DSCNT_ANNL_PAYR_SK,
	blt.D_DSCNT_EFT_SK,
	blt.D_DSCNT_ERLY_ENRL_SK,
	blt.D_DSCNT_LNGVTY_SK,
	blt.D_DSCNT_MULTI_INSD_SK,
	blt.D_SURCHRG_TIER_SK,
	blt.D_SURCHRG_TBCC_USER_SK,
	blt.D_INSD_PLN_PRFL_SK,
	blt.D_CALC_RT_SK,
	blt.MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
	blt.CERT_EFF_AGE_LOOK_FRAC,
	blt.AGT_REF_ORIG_D_AGT_SK,
	blt.AGT_REF_D_AGT_SK,
	blt.D_NEW_TO_MEDCR_SK
    FROM BDR_DM.temp_bil_ln_hist_monthly blt
    JOIN BDR_DM.wrk_ocrs_bill_line_hist bl
    ON blt.bil_ln_hist_sk     = bl.ocrs_bl_hist_skey
    WHERE bl.clm_prem_lnk_key = 0
  )
  src ON ( bl.OCRS_BL_HIST_SKEY = src.row_id )
WHEN MATCHED THEN
  UPDATE
  SET bl.TEMP_PLAN_BEN_MOD_SKEY     = src.temp_d_pln_ben_mod_sk,
    bl.PLAN_BEN_MOD_SKEY            = src.plan_ben_mod_skey,
    bl.TEMP_RESIDENT_GEOGRAPHY_SKEY = src.temp_res_d_geo_xref_sk,
    bl.RESIDENT_GEOGRAPHY_SKEY      = src.resident_geography_skey,
    bl.TEMP_CERT_EFFECTIVE_DATE_ID  = src.temp_cert_eff_dt_id,
    bl.CERT_EFFECTIVE_DATE_ID       = src.cert_effective_date_id,
    bl.PLAN_ISSUE_GEOGRAPHY_SKEY    = src.pln_iss_d_geo_xref_sk,
    bl.TEMP_RATING_AREA_SKEY        = src.temp_d_rtng_area_sk,
    bl.RATING_AREA_SKEY             = src.rating_area_skey,
    bl.GENDER_ID                    = src.d_gdr_id_sk,
    bl.PREMIUM_DUE_AGE_ID           = src.prem_due_age_id,
    bl.CERT_ACQN_CHNL_KEY           = src.cert_d_acqn_chnl_sk,
    bl.PRDCT_ACQN_CHNL_KEY          = src.prdct_d_acqn_chnl_sk,
    bl.MBR_ACQN_CHNL_KEY            = src.mbr_d_acqn_chnl_sk,
    bl.UNDWR_TAG_KEY                = src.d_undwr_tag_sk,
    bl.PRDCT_EFF_DT_ID              = src.prdct_eff_dt_id,
    --bl.LGL_ENTY_KEY                 = src.d_lgl_enty_sk,
    bl.FACT_PREM_TRANS_MONTHLY_SKEY = src.f_prem_trans_mo_sk,
    bl.AGT_WRT_SKEY                 = src.agt_wrt_d_agt_sk,
    bl.AGT_SEL_ORIG_SKEY            = src.agt_sel_orig_d_agt_sk,
    bl.AGT_SEL_SKEY                 = src.agt_sel_d_agt_sk,
    bl.AGT_DCM_WRT_SKEY             = src.agt_dcm_wrt_d_agt_sk,
    bl.ER_SKEY                      = src.d_emp_sk,
    bl.RET_TYP_SKEY                 = src.d_ret_typ_sk,
	bl.D_DSCNT_ANNL_PAYR_SK = SRC.D_DSCNT_ANNL_PAYR_SK,
	bl.D_DSCNT_EFT_SK = SRC.D_DSCNT_EFT_SK,
	bl.D_DSCNT_ERLY_ENRL_SK = SRC.D_DSCNT_ERLY_ENRL_SK,
	bl.D_DSCNT_LNGVTY_SK = SRC.D_DSCNT_LNGVTY_SK,
	bl.D_DSCNT_MULTI_INSD_SK = SRC.D_DSCNT_MULTI_INSD_SK,
	bl.D_SURCHRG_TIER_SK = SRC.D_SURCHRG_TIER_SK,
	bl.D_SURCHRG_TBCC_USER_SK = SRC.D_SURCHRG_TBCC_USER_SK,
	bl.D_INSD_PLN_PRFL_SK = SRC.D_INSD_PLN_PRFL_SK,
	bl.D_CALC_RT_SK = SRC.D_CALC_RT_SK,
	bl.MEDSUP_PLN_ENT_AGE_LOOK_FRAC = SRC.MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
	bl.CERT_EFF_AGE_LOOK_FRAC = SRC.CERT_EFF_AGE_LOOK_FRAC,
        bl.CLM_PREM_LNK_KEY      = src.CLM_PREM_LNK_KEY,
        bl.AGT_REF_ORIG_D_AGT_SK = SRC.AGT_REF_ORIG_D_AGT_SK,
        bl.AGT_REF_D_AGT_SK = SRC.AGT_REF_D_AGT_SK,
        bl.D_NEW_TO_MEDCR_SK = SRC.D_NEW_TO_MEDCR_SK;		-- No LinkAge process applied = 0 ; Regular linkAge process applied = 1 ; Exception linkAge process applied = 2
 -- COMMIT;
 	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

  --COMMENTED BY OAS--
/*V_ROWS_AFFTD:=SQL%ROWCOUNT;

   COMMIT;
  INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''MONTHLY_CLAIMS'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''MERGE'',
      ''FINAL UPDATE INTO BDR_DM.WRK_OCRS_BILL_LINE_HIST'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );
  COMMIT;
  INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''MONTHLY_CLAIMS'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''END'',
      ''PROCEDURE ENDS'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );
  COMMIT;
  DBMS_OUTPUT.PUT_LINE(''MONTHLY CLAIMS | sp_clm_upd_ocrsbilln_lnk_exp_m | UPDATE | Final Update into BDR_DM.wrk_ocrs_bill_line_hist | ''||SQL%ROWCOUNT ||'' | ''||systimestamp);
  DBMS_OUTPUT.PUT_LINE(''MONTHLY CLAIMS | sp_clm_upd_ocrsbilln_lnk_exp_m | INSERT | PROCEDURE ENDS | ''||SQL%ROWCOUNT ||'' | ''||systimestamp);*/
  --COMMENTED BY OAS--
  /* P_ErrorYNFlg := ''N'';
  P_ErrorStr := '''';
  EXCEPTION
  WHEN OTHERS
  THEN
  P_ErrorStr :=
  ''ERROR: ''
  || SQLCODE
  || ''-''
  || SQLERRM
  || ''-''
  || DBMS_UTILITY.FORMAT_ERROR_STACK ();
  P_ToConTaxIDNoueSTATUS := ''N'';
  P_ErrorYNFlg := ''Y'';
  ROLLBACK;
*/
--COMMENTED BY OAS--
 /* P_ErrorYNFlg := ''N'';
  P_ErrorStr := '''';
EXCEPTION
   WHEN OTHERS
   THEN
    P_ErrorStr := ''ERROR: '' || SQLCODE || ''-'' || SQLERRM || ''-'' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE()|| Chr(10)||DBMS_UTILITY.FORMAT_ERROR_STACK();
      P_ToContinueStatus := ''N'';
      P_ErrorYNFlg := ''Y'';
      ROLLBACK;
  END;
/*/
--COMMENTED BY OAS--

CALL UTIL.SP_ETL_CHECK_CONSTRAINTS(:DB_NAME , :APPLICATION , :WORKFLOW_NAME , :OBJECT_NAME , :V_BATCH_ID );		---------OAS ADD


UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''COMPLETE'', ERROR_MSG = null, BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
;
UPDATE  UTIL.ETL_BATCH_OBJECT_INCR_VALU SET INCR_COLUMN_VALUE = :V_BATCH_ID, LST_MOD_DT = CURRENT_TIMESTAMP() 
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID''
;

EXCEPTION

WHEN OTHER THEN

UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''ERROR'', ERROR_MSG = :SQLERRM,  BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
;

INSERT INTO  UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ERROR_MSG, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''ERROR'', :V_STEP_NAME, :V_STEP_SEQ, :SQLERRM, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() )
;



RAISE;

END;

';