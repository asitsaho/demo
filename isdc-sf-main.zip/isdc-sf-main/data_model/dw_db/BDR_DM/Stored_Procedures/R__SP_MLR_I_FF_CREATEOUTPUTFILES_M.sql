USE SCHEMA BDR_DM; 
CREATE OR REPLACE PROCEDURE BDR_DM.SP_MLR_I_FF_CREATEOUTPUTFILES_M("DB_NAME" VARCHAR(16777216), "APPLICATION" VARCHAR(16777216), "WORKFLOW_NAME" VARCHAR(16777216), "OBJECT_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '

-- Original workflow: wkf_MLR_I_CreateFFOutputs_M
-- Original mapping: m_MLR_I_FF_CreateOutputFiles_M
-- Original folder: Claims
-- Original filename: wkf_MLR_I_CreateFFOutputs_M.XML

DECLARE


V_ROWS_INSERTED  INTEGER;
V_ROWS_UPDATED INTEGER;
V_ROWS_DELETED INTEGER;
V_LAST_QUERY_ID VARCHAR;

V_WH VARCHAR;
V_BATCH_ID INTEGER;
V_ROWS_LOADED INTEGER; 


V_BATCH_OBJECT_START_TIME        VARCHAR;
V_STEP_START_TIME    VARCHAR;
V_STEP_NAME VARCHAR;
V_STEP_SEQ INTEGER DEFAULT 0;
V_ETL_LST_BTCH_ID INTEGER;
V_STAGE VARCHAR;
V_OUTBOX_DIR VARCHAR; 
V_STAGE_QUERY1 VARCHAR;
V_STAGE_QUERY2  VARCHAR;
V_FILE_NAME VARCHAR;

V_DATE VARCHAR;
V_BAD_FN VARCHAR;
V_LR_FN VARCHAR;
V_STAT_FN VARCHAR;



BEGIN

EXECUTE IMMEDIATE ''USE DATABASE ''||:DB_NAME; 

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_BATCH_OBJECT_START_TIME := (SELECT CURRENT_TIMESTAMP());

SELECT to_char(DATE_TRUNC(''MONTH'', CURRENT_DATE), ''YYYYMMDD'') INTO V_DATE;	------------OAS ADD


LET res1 RESULTSET := 
(

SELECT 

WH ,
BATCH_ID
  
FROM UTIL.ETL_BATCH_OBJECT_CONTROL
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
FETCH FIRST 1 ROW ONLY

)
;


LET C1 CURSOR FOR res1;
open C1;
FETCH C1 into  V_WH,V_BATCH_ID ;
close C1;


LET res2 RESULTSET := 

(

WITH PARAMETERS (BAD_FN, LR_FN, STAT_FN, STAGE, OUTBOX_DIR) AS
(
  
SELECT * 
FROM  
(SELECT PARAMETER_NAME, PARAMETER_VALUE  FROM UTIL.ETL_OBJECT_PARAMETER_VALUE 
WHERE 1 = 1
AND APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
AND ACTIVE_FLG = ''Y''  
  
UNION ALL       

SELECT PARAMETER_NAME, PARAMETER_VALUE  FROM UTIL.ETL_GLOBAL_PARAMETER_VALUE WHERE PAR_GLOBAL_TYPE = ''PARGLOBAL_OPREPORTS'' AND ACTIVE_FLG = ''Y''
AND PARAMETER_NAME NOT IN  (
SELECT PARAMETER_NAME  FROM UTIL.ETL_OBJECT_PARAMETER_VALUE WHERE 1 = 1
AND APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
AND ACTIVE_FLG = ''Y''   ))
 
PIVOT(MAX(PARAMETER_VALUE) FOR PARAMETER_NAME IN (''BAD_FN'', ''LR_FN'', ''STAT_FN'', ''STAGE'', ''OUTBOX_DIR'')) 

 
)  
SELECT * FROM PARAMETERS 
)  
  
;


LET C2 CURSOR FOR res2;
open C2;
FETCH C2 into  V_BAD_FN, V_LR_FN, V_STAT_FN, V_STAGE, V_OUTBOX_DIR; 
close C2;




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:V_WH;
USE SCHEMA BDR_DM;	------------OAS ADD


INSERT INTO UTIL.ETL_BATCH_OBJECT_INCR_VALU (APPLICATION, WORKFLOW_NAME, OBJECT_NAME, INCR_COLUMN, INCR_COLUMN_VALUE )
SELECT * FROM (select :APPLICATION AS APPLICATION, :WORKFLOW_NAME AS WORKFLOW_NAME, :OBJECT_NAME AS OBJECT_NAME, ''ETL_LST_BTCH_ID'' AS INCR_COLUMN, -1 AS INCR_COLUMN_VALUE) A
WHERE NOT EXISTS (SELECT 1 FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU B WHERE B.APPLICATION = A.APPLICATION AND B.WORKFLOW_NAME = A.WORKFLOW_NAME AND B.OBJECT_NAME = A.OBJECT_NAME AND B.INCR_COLUMN = A.INCR_COLUMN)
;

V_ETL_LST_BTCH_ID :=(SELECT INCR_COLUMN_VALUE FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID'');



EXECUTE IMMEDIATE ''REMOVE ''||:V_STAGE||:V_OUTBOX_DIR;   -----Remove previous files----------- OAS ADD--

-- PIPELINE START FOR 1

V_STEP_NAME := ''ISDW_Loss_Ratio_report.csv''; 
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
  
-- Component SQ_sc_WRK_MKT_LR_MO, Type SOURCE 
CREATE OR REPLACE TEMPORARY TABLE SQ_sc_WRK_MKT_LR_MO AS
(
SELECT SRC.*, row_number() over (order by 1) AS source_record_id FROM (
select case when ACCT_NBR = -1 then ''000000000000000'' else lpad(ACCT_NBR,15,''0'') end as ACCT_NBR
, case when INDV_ID = -1 then ''0000000000000'' else lpad(INDV_ID,13,''0'') end as INDV_ID
, sum(case when PRDCT_TYP_NBR = 1 then RNK_NBR else 0 end) as MedSuppRank
, sum(case when PRDCT_TYP_NBR = 2 then RNK_NBR else 0 end) as HIPRank
from BDR_DM.WRK_MKT_LR_MO 
where PRDCT_TYP_NBR in (1,2)
group by ACCT_NBR, INDV_ID
) SRC
);


-- Component rtr_LRreports_BAD, Type ROUTER Output Group BAD
CREATE OR REPLACE TEMPORARY TABLE rtr_LRreports_BAD AS
(
SELECT
SQ_sc_WRK_MKT_LR_MO.ACCT_NBR as ACCT_NBR,
SQ_sc_WRK_MKT_LR_MO.INDV_ID as INDV_ID,
SQ_sc_WRK_MKT_LR_MO.MedSuppRank as MedSuppRNK,
SQ_sc_WRK_MKT_LR_MO.HIPRank as HIPRNK,
SQ_sc_WRK_MKT_LR_MO.source_record_id
FROM
SQ_sc_WRK_MKT_LR_MO
WHERE SQ_sc_WRK_MKT_LR_MO.MedSuppRank > 4 OR SQ_sc_WRK_MKT_LR_MO.HIPRank > 4 OR ( SQ_sc_WRK_MKT_LR_MO.MedSuppRank = 0 AND SQ_sc_WRK_MKT_LR_MO.HIPRank = 0 ) OR SQ_sc_WRK_MKT_LR_MO.INDV_ID IS NULL OR SQ_sc_WRK_MKT_LR_MO.INDV_ID = ''0000000000000''
);


-- Component rtr_LRreports_DEFAULT1, Type ROUTER Output Group DEFAULT1
CREATE OR REPLACE TEMPORARY TABLE rtr_LRreports_DEFAULT1 AS
(
SELECT
SQ_sc_WRK_MKT_LR_MO.ACCT_NBR as ACCT_NBR,
SQ_sc_WRK_MKT_LR_MO.INDV_ID as INDV_ID,
SQ_sc_WRK_MKT_LR_MO.MedSuppRank as MedSuppRNK,
SQ_sc_WRK_MKT_LR_MO.HIPRank as HIPRNK,
SQ_sc_WRK_MKT_LR_MO.source_record_id
FROM
SQ_sc_WRK_MKT_LR_MO
WHERE NOT ( SQ_sc_WRK_MKT_LR_MO.MedSuppRank > 4 OR SQ_sc_WRK_MKT_LR_MO.HIPRank > 4 OR ( SQ_sc_WRK_MKT_LR_MO.MedSuppRank = 0 AND SQ_sc_WRK_MKT_LR_MO.HIPRank = 0 ) OR SQ_sc_WRK_MKT_LR_MO.INDV_ID IS NULL OR SQ_sc_WRK_MKT_LR_MO.INDV_ID = ''0000000000000'' )
);


-- Component exp_FF_BadLR, Type EXPRESSION 
CREATE OR REPLACE TEMPORARY TABLE exp_FF_BadLR AS
(
SELECT
rtr_LRreports_BAD.ACCT_NBR || rtr_LRreports_BAD.HIPRNK || rtr_LRreports_BAD.MedSuppRNK as OutputLine
FROM
rtr_LRreports_BAD
);





-- Component exp_FF_LR, Type EXPRESSION 
CREATE OR REPLACE TEMPORARY TABLE exp_FF_LR AS
(
SELECT
rtr_LRreports_DEFAULT1.INDV_ID || rtr_LRreports_DEFAULT1.HIPRNK || rtr_LRreports_DEFAULT1.MedSuppRNK as OutputLine
FROM
rtr_LRreports_DEFAULT1
);


----------------------------------

-- Component sc_tgt_FF_LR, Type TARGET_EXPORT_PREPARE Stage data before exporting
CREATE OR REPLACE TEMPORARY TABLE sc_tgt_FF_LR AS
(
SELECT
exp_FF_LR.OutputLine /* OutputColumn */
FROM
exp_FF_LR
);

-- Component sc_tgt_FF_LR, Type EXPORT_DATA Exporting data
V_ROWS_LOADED := (select count(1) from sc_tgt_FF_LR);


V_FILE_NAME := (select to_varchar(DATEADD(''MM'', -1, CURRENT_DATE), ''YYYY'')||''_''||to_char(CURRENT_DATE, ''MMMM'') || ''_'' || :V_LR_FN) ;

  
V_STAGE_QUERY1 := ''COPY INTO ''||:V_STAGE||:V_OUTBOX_DIR||:V_FILE_NAME ||

'' FROM (
        SELECT *
        FROM sc_tgt_FF_LR
    )
    file_format = (type = ''''CSV'''',
                   field_delimiter = '''','''',
				   empty_field_as_null=false
			       NULL_IF = ('''''''',''''NULL'''', ''''Null'''',''''null'''')
                   compression = NONE
                  )
    HEADER = FALSE
    OVERWRITE = TRUE
    MAX_FILE_SIZE = 4900000000
    SINGLE = TRUE;'';



V_STAGE_QUERY2 := ''COPY INTO ''||:V_STAGE||:V_OUTBOX_DIR||:V_FILE_NAME ||

'' FROM (
        SELECT '''' ''''
    )
    file_format = (type = ''''CSV'''',
                   field_delimiter = '''','''',
				   empty_field_as_null=false
			       NULL_IF = ('''''''',''''NULL'''', ''''Null'''',''''null'''')
                   compression = NONE
                  )
    HEADER = FALSE
    OVERWRITE = TRUE
    MAX_FILE_SIZE = 4900000000
    SINGLE = TRUE;'';
	
IF (V_ROWS_LOADED > 0) THEN 

execute immediate ''USE SCHEMA ''|| ''BDR_DM'';                                  
execute immediate  :V_STAGE_QUERY1;  

ELSEIF (V_ROWS_LOADED = 0) THEN 

execute immediate ''USE SCHEMA ''|| ''BDR_DM'';                                  
execute immediate  :V_STAGE_QUERY2;  


END IF;  	
	
	
CREATE OR REPLACE TEMPORARY TABLE sc_tgt_FF_BadLR AS
(
SELECT
exp_FF_BadLR.OutputLine /* OutputColumn */
FROM
exp_FF_BadLR
);

V_ROWS_LOADED := (select count(1) from sc_tgt_FF_BadLR);



V_FILE_NAME := (select to_varchar(DATEADD(''MM'', -1, CURRENT_DATE), ''YYYY'')||''_''||to_char(CURRENT_DATE, ''MMMM'') || ''_'' || :V_BAD_FN) ;

  
V_STAGE_QUERY1 := ''COPY INTO ''||:V_STAGE||:V_OUTBOX_DIR||:V_FILE_NAME ||

'' FROM (
        SELECT *
        FROM sc_tgt_FF_BadLR
    )
    file_format = (type = ''''CSV'''',
                   field_delimiter = '''','''',
				   empty_field_as_null=false
			       NULL_IF = ('''''''',''''NULL'''', ''''Null'''',''''null'''')
                   compression = NONE
                  )
    HEADER = FALSE
    OVERWRITE = TRUE
    MAX_FILE_SIZE = 4900000000
    SINGLE = TRUE;'';



V_STAGE_QUERY2 := ''COPY INTO ''||:V_STAGE||:V_OUTBOX_DIR||:V_FILE_NAME ||

'' FROM (
        SELECT '''' ''''
    )
    file_format = (type = ''''CSV'''',
                   field_delimiter = '''','''',
				   empty_field_as_null=false
			       NULL_IF = ('''''''',''''NULL'''', ''''Null'''',''''null'''')
                   compression = NONE
                  )
    HEADER = FALSE
    OVERWRITE = TRUE
    MAX_FILE_SIZE = 4900000000
    SINGLE = TRUE;'';
	
IF (V_ROWS_LOADED > 0) THEN 

execute immediate ''USE SCHEMA ''|| ''BDR_DM'';                                  
execute immediate  :V_STAGE_QUERY1;  

ELSEIF (V_ROWS_LOADED = 0) THEN 

execute immediate ''USE SCHEMA ''|| ''BDR_DM'';                                  
execute immediate  :V_STAGE_QUERY2;  


END IF; 



INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_LOADED, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_LOADED, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );





-- PIPELINE END FOR 1

-- PIPELINE START FOR 2

V_STEP_NAME := ''ISDW_Loss_Ratio_report_Statistics.csv''; 
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;

-- Component SQ_sc_WRK_MKT_LR_MO1, Type SOURCE 
CREATE OR REPLACE TEMPORARY TABLE SQ_sc_WRK_MKT_LR_MO1 AS
(
SELECT SRC.*, row_number() over (order by 1) AS source_record_id FROM (
with cte as (
    select sum(case when HIPRank = 1 then 1 else 0 end) as HIPRank_1
    , sum(case when HIPRank = 2 then 1 else 0 end) as HIPRank_2
    , sum(case when HIPRank = 3 then 1 else 0 end) as HIPRank_3
    , sum(case when HIPRank = 4 then 1 else 0 end) as HIPRank_4
    , sum(case when MedSuppRank = 1 then 1 else 0 end) as MedSuppRank_1
    , sum(case when MedSuppRank = 2 then 1 else 0 end) as MedSuppRank_2
    , sum(case when MedSuppRank = 3 then 1 else 0 end) as MedSuppRank_3
    , sum(case when MedSuppRank = 4 then 1 else 0 end) as MedSuppRank_4
    , sum(case when HIPRank > 0 then 1 else 0 end) as HIPtot
    , sum(case when MedSuppRank > 0 then 1 else 0 end) as MedSupptot
    from (
        select case when ACCT_NBR = -1 then ''000000000000000'' else lpad(ACCT_NBR,15,''0'') end as ACCT_NBR
        , case when INDV_ID = -1 then ''0000000000000'' else lpad(INDV_ID,13,''0'') end as INDV_ID
        , sum(case when PRDCT_TYP_NBR = 1 then RNK_NBR else 0 end) as MedSuppRank
        , sum(case when PRDCT_TYP_NBR = 2 then RNK_NBR else 0 end) as HIPRank
        from BDR_DM.WRK_MKT_LR_MO 
        where PRDCT_TYP_NBR in (1,2)
        group by ACCT_NBR, INDV_ID
    )
    where HIPRank <= 4
    and MedSuppRank <= 4
    and not(MedSuppRank = 0 and HIPRank = 0)
    and INDV_ID IS NOT NULL 
    AND INDV_ID <> ''0000000000000''
)
select ''*'' as StatRep from dual
union all
select ''*'' from dual
union all
select ''  Supplemental Health Insurance Program Loss Ratio Report Run Date For: ''
||trim(TO_CHAR(TO_TIMESTAMP(:V_DATE, ''YYYYMMDD''),''MONTH''))||'' 1ST, ''||trim(to_char(TO_TIMESTAMP(:V_DATE, ''YYYYMMDD''),''YYYY'')) from dual
union all
select ''*'' from dual
union all
select ''*------------------------------------------------------------------*'' from dual
union all
select ''                       HIP Total: ''||trim(TO_CHAR(hiptot, ''99G999G999G999'')) from cte
union all
select ''* ------------------------------------------------------------------*'' from dual
union all
select ''     HIP Rank 1 Count: ''||trim(TO_CHAR(HIPRank_1, ''99G999G999G999''))
||''         Percentage of Total:  ''||trim(to_char(case when hiptot = 0 then 0 else 100*HIPRank_1/hiptot end,''990.00''))||''%'' from cte
union all
select ''     HIP Rank 2 Count: ''||trim(TO_CHAR(HIPRank_2, ''99G999G999G999''))
||''         Percentage of Total:  ''||trim(to_char(case when hiptot = 0 then 0 else 100*HIPRank_2/hiptot end,''990.00''))||''%'' from cte
union all
select ''     HIP Rank 3 Count: ''||trim(TO_CHAR(HIPRank_3, ''99G999G999G999''))
||''         Percentage of Total:  ''||trim(to_char(case when hiptot = 0 then 0 else 100*HIPRank_3/hiptot end,''990.00''))||''%'' from cte
union all
select ''     HIP Rank 4 Count: ''||trim(TO_CHAR(HIPRank_4, ''99G999G999G999''))
||''         Percentage of Total:  ''||trim(to_char(case when hiptot = 0 then 0 else 100*HIPRank_4/hiptot end,''990.00''))||''%'' from cte
union all
select ''* ------------------------------------------------------------------*'' from dual
union all
select ''*'' from dual
union all
select ''*'' from dual
union all
select ''*'' from dual
union all
select ''*------------------------------------------------------------------*'' from dual
union all
select ''                     Med Supp Total: ''||trim(TO_CHAR(MedSupptot, ''99G999G999G999'')) from cte
union all
select ''*------------------------------------------------------------------*'' from dual
union all
select ''Med Supp Rank 1 Count: ''||trim(TO_CHAR(MedSuppRank_1, ''99G999G999G999''))
||''         Percentage of Total:  ''||trim(to_char(case when MedSupptot = 0 then 0 else 100*MedSuppRank_1/MedSupptot end,''990.00''))||''%'' from cte
union all
select ''Med Supp Rank 2 Count: ''||trim(TO_CHAR(MedSuppRank_2, ''99G999G999G999''))
||''         Percentage of Total:  ''||trim(to_char(case when MedSupptot = 0 then 0 else 100*MedSuppRank_2/MedSupptot end,''990.00''))||''%'' from cte
union all
select ''Med Supp Rank 3 Count: ''||trim(TO_CHAR(MedSuppRank_3, ''99G999G999G999''))
||''         Percentage of Total:  ''||trim(to_char(case when MedSupptot = 0 then 0 else 100*MedSuppRank_3/MedSupptot end,''990.00''))||''%'' from cte
union all
select ''Med Supp Rank 4 Count: ''||trim(TO_CHAR(MedSuppRank_4, ''99G999G999G999''))
||''         Percentage of Total:  ''||trim(to_char(case when MedSupptot = 0 then 0 else 100*MedSuppRank_4/MedSupptot end,''990.00''))||''%'' from cte
union all
select ''* ------------------------------------------------------------------*'' from dual
) SRC
);


-- Component exp_FF_STATS, Type EXPRESSION 
CREATE OR REPLACE TEMPORARY TABLE exp_FF_STATS AS
(
SELECT
SQ_sc_WRK_MKT_LR_MO1.StatRep as OutputLine
FROM
SQ_sc_WRK_MKT_LR_MO1
);


-- Component sc_tgt_FF_STATS, Type TARGET_EXPORT_PREPARE Stage data before exporting
CREATE OR REPLACE TEMPORARY TABLE sc_tgt_FF_STATS AS
(
SELECT
exp_FF_STATS.OutputLine /* OutputColumn */
FROM
exp_FF_STATS
);


-- Component sc_tgt_FF_STATS, Type EXPORT_DATA Exporting data

V_ROWS_LOADED := (select count(1) from sc_tgt_FF_STATS);


V_FILE_NAME := (select to_varchar(DATEADD(''MM'', -1, CURRENT_DATE), ''YYYY'')||''_''||to_char(CURRENT_DATE, ''MMMM'') || ''_'' || :V_STAT_FN) ;

  
V_STAGE_QUERY1 := ''COPY INTO ''||:V_STAGE||:V_OUTBOX_DIR||:V_FILE_NAME ||

'' FROM (
        SELECT *
        FROM sc_tgt_FF_STATS
    )
    file_format = (type = ''''CSV'''',
                   field_delimiter = '''','''',
				   empty_field_as_null=false
			       NULL_IF = ('''''''',''''NULL'''', ''''Null'''',''''null'''')
                   compression = NONE
                  )
    HEADER = FALSE
    OVERWRITE = TRUE
    MAX_FILE_SIZE = 4900000000
    SINGLE = TRUE;'';



V_STAGE_QUERY2 := ''COPY INTO ''||:V_STAGE||:V_OUTBOX_DIR||:V_FILE_NAME ||

'' FROM (
        SELECT '''' ''''
    )
    file_format = (type = ''''CSV'''',
                   field_delimiter = '''','''',
				   empty_field_as_null=false
			       NULL_IF = ('''''''',''''NULL'''', ''''Null'''',''''null'''')
                   compression = NONE
                  )
    HEADER = FALSE
    OVERWRITE = TRUE
    MAX_FILE_SIZE = 4900000000
    SINGLE = TRUE;'';
	
IF (V_ROWS_LOADED > 0) THEN 

execute immediate ''USE SCHEMA ''|| ''BDR_DM'';                                  
execute immediate  :V_STAGE_QUERY1;  

ELSEIF (V_ROWS_LOADED = 0) THEN 

execute immediate ''USE SCHEMA ''|| ''BDR_DM'';                                  
execute immediate  :V_STAGE_QUERY2;  


END IF; 



INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_LOADED, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_LOADED, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );


-- PIPELINE END FOR 2

-- PIPELINE START FOR 3

V_STEP_NAME := ''MLR_Extract_Log.csv''; 
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;

-- Component SQ_sc_WRK_MKT_LR_MO2, Type SOURCE 
CREATE OR REPLACE TEMPORARY TABLE SQ_sc_WRK_MKT_LR_MO2 AS
(
SELECT SRC.*, row_number() over (order by 1) AS source_record_id FROM (
    WITH cte AS (
        SELECT 
            SUM(CASE WHEN HIPRank = 1 THEN 1 ELSE 0 END) AS HIPRank_1,
            SUM(CASE WHEN HIPRank = 2 THEN 1 ELSE 0 END) AS HIPRank_2,
            SUM(CASE WHEN HIPRank = 3 THEN 1 ELSE 0 END) AS HIPRank_3,
            SUM(CASE WHEN HIPRank = 4 THEN 1 ELSE 0 END) AS HIPRank_4,
            SUM(CASE WHEN MedSuppRank = 1 THEN 1 ELSE 0 END) AS MedSuppRank_1,
            SUM(CASE WHEN MedSuppRank = 2 THEN 1 ELSE 0 END) AS MedSuppRank_2,
            SUM(CASE WHEN MedSuppRank = 3 THEN 1 ELSE 0 END) AS MedSuppRank_3,
            SUM(CASE WHEN MedSuppRank = 4 THEN 1 ELSE 0 END) AS MedSuppRank_4,
            SUM(CASE WHEN HIPRank > 0 THEN 1 ELSE 0 END) AS HIPtot,
            SUM(CASE WHEN MedSuppRank > 0 THEN 1 ELSE 0 END) AS MedSupptot,
            COUNT(1) AS GoodCnt
        FROM (
            SELECT 
                CASE WHEN ACCT_NBR = -1 THEN ''000000000000000'' ELSE LPAD(ACCT_NBR, 15, ''0'') END AS ACCT_NBR,
                CASE WHEN INDV_ID = -1 THEN ''0000000000000'' ELSE LPAD(INDV_ID, 13, ''0'') END AS INDV_ID,
                SUM(CASE WHEN PRDCT_TYP_NBR = 1 THEN RNK_NBR ELSE 0 END) AS MedSuppRank,
                SUM(CASE WHEN PRDCT_TYP_NBR = 2 THEN RNK_NBR ELSE 0 END) AS HIPRank
            FROM BDR_DM.WRK_MKT_LR_MO 
            WHERE PRDCT_TYP_NBR IN (1, 2)
            GROUP BY ACCT_NBR, INDV_ID
        ) AS subquery
        WHERE HIPRank <= 4
          AND MedSuppRank <= 4
          AND NOT (MedSuppRank = 0 AND HIPRank = 0)
          AND INDV_ID IS NOT NULL 
          AND INDV_ID <> ''0000000000000''
    ),
    TotCnt AS (
        SELECT COUNT(1) AS TotCnt 
        FROM (
            SELECT ACCT_NBR, INDV_ID 
            FROM BDR_DM.WRK_MKT_LR_MO 
            WHERE PRDCT_TYP_NBR IN (1, 2)
            GROUP BY ACCT_NBR, INDV_ID
        ) AS count_query
    )
    SELECT 
        ''PR LOSS RATIO REPORT  File spooled into '' || ''@UTIL.STAGE_AZURE_ISDC/claims/outbox'' || :V_LR_FN || CHR(13) || CHR(10) AS LogRep
    UNION ALL
    SELECT ''PR LOSS RATIO REPORT  Number of records spooled is equal to '' || GoodCnt || CHR(13) || CHR(10) FROM cte
    UNION ALL
    SELECT ''PR LOSS RATIO REPORT  Bad information spooled into '' || ''@UTIL.STAGE_AZURE_ISDC/claims/outbox'' || :V_BAD_FN || CHR(13) || CHR(10) FROM dual
    UNION ALL
    SELECT ''PR LOSS RATIO REPORT  Number of bad records spooled is equal to '' || (TotCnt.TotCnt - GoodCnt) || CHR(13) || CHR(10) FROM cte, TotCnt
    UNION ALL
    SELECT ''PR LOSS RATIO REPORT  Total number of accounts processed is equal to '' || TotCnt || CHR(13) || CHR(10) FROM TotCnt
    UNION ALL
    SELECT ''PR LOSS RATIO REPORT  HIP Total: '' || HIPtot || CHR(13) || CHR(10) FROM cte
    UNION ALL
    SELECT ''PR LOSS RATIO REPORT  HIP 1 Count: '' || HIPRank_1 || CHR(13) || CHR(10) FROM cte
    UNION ALL
    SELECT ''PR LOSS RATIO REPORT  HIP 2 Count: '' || HIPRank_2 || CHR(13) || CHR(10) FROM cte
    UNION ALL
    SELECT ''PR LOSS RATIO REPORT  HIP 3 Count: '' || HIPRank_3 || CHR(13) || CHR(10) FROM cte
    UNION ALL
    SELECT ''PR LOSS RATIO REPORT  HIP 4 Count: '' || HIPRank_4 || CHR(13) || CHR(10) FROM cte
    UNION ALL
    SELECT ''PR LOSS RATIO REPORT  Med Supp Total: '' || MedSupptot || CHR(13) || CHR(10) FROM cte
    UNION ALL
    SELECT ''PR LOSS RATIO REPORT  Med Supp 1 Count: '' || MedSuppRank_1 || CHR(13) || CHR(10) FROM cte
    UNION ALL
    SELECT ''PR LOSS RATIO REPORT  Med Supp 2 Count: '' || MedSuppRank_2 || CHR(13) || CHR(10) FROM cte
    UNION ALL
    SELECT ''PR LOSS RATIO REPORT  Med Supp 3 Count: '' || MedSuppRank_3 || CHR(13) || CHR(10) FROM cte
    UNION ALL
    SELECT ''PR LOSS RATIO REPORT  Med Supp 4 Count: '' || MedSuppRank_4 || CHR(13) || CHR(10) FROM cte
    UNION ALL
    SELECT ''PR LOSS RATIO REPORT  HIP 1 Percent: '' || CASE WHEN HIPtot = 0 THEN 0 ELSE ROUND(HIPRank_1 / HIPtot * 100, 2) END || ''%'' || CHR(13) || CHR(10) FROM cte
    UNION ALL
    SELECT ''PR LOSS RATIO REPORT  HIP 2 Percent: '' || CASE WHEN HIPtot = 0 THEN 0 ELSE ROUND(HIPRank_2 / HIPtot * 100, 2) END || ''%'' || CHR(13) || CHR(10) FROM cte
    UNION ALL
    SELECT ''PR LOSS RATIO REPORT  HIP 3 Percent: '' || CASE WHEN HIPtot = 0 THEN 0 ELSE ROUND(HIPRank_3 / HIPtot * 100, 2) END || ''%'' || CHR(13) || CHR(10) FROM cte
    UNION ALL
    SELECT ''PR LOSS RATIO REPORT  HIP 4 Percent: '' || CASE WHEN HIPtot = 0 THEN 0 ELSE ROUND(HIPRank_4 / HIPtot * 100, 2) END || ''%'' || CHR(13) || CHR(10) FROM cte
    UNION ALL
    SELECT ''PR LOSS RATIO REPORT  Med Supp 1 Percent: '' || CASE WHEN MedSupptot = 0 THEN 0 ELSE ROUND(MedSuppRank_1 / MedSupptot * 100, 2) END || ''%'' || CHR(13) || CHR(10) FROM cte
    UNION ALL
    SELECT ''PR LOSS RATIO REPORT  Med Supp 2 Percent: '' || CASE WHEN MedSupptot = 0 THEN 0 ELSE ROUND(MedSuppRank_2 / MedSupptot * 100, 2) END || ''%'' || CHR(13) || CHR(10) FROM cte
    UNION ALL
    SELECT ''PR LOSS RATIO REPORT  Med Supp 3 Percent: '' || CASE WHEN MedSupptot = 0 THEN 0 ELSE ROUND(MedSuppRank_3 / MedSupptot * 100, 2) END || ''%'' || CHR(13) || CHR(10) FROM cte
    UNION ALL
    SELECT ''PR LOSS RATIO REPORT  Med Supp 4 Percent: '' || CASE WHEN MedSupptot = 0 THEN 0 ELSE ROUND(MedSuppRank_4 / MedSupptot * 100, 2) END || ''%'' || CHR(13) || CHR(10) FROM cte
    UNION ALL
    SELECT ''PR LOSS RATIO REPORT  Ended '' FROM dual
  ) SRC
);


-- Component sc_tgt_FF_log, Type TARGET_EXPORT_PREPARE Stage data before exporting
CREATE OR REPLACE TEMPORARY TABLE sc_tgt_FF_log AS
(
SELECT
SQ_sc_WRK_MKT_LR_MO2.LOGREP /* OutputLine */
FROM
SQ_sc_WRK_MKT_LR_MO2
);



V_FILE_NAME := ''MLR_Extract_Log_'' || (SELECT TO_CHAR(CURRENT_DATE, ''YYYYMM'')) ||''.txt'';
  
    V_STAGE_QUERY1 := ''COPY INTO ''||:V_STAGE||:V_OUTBOX_DIR||:V_FILE_NAME ||
  ''   FROM (
        SELECT *
        FROM sc_tgt_FF_log
    )
    file_format = (type = ''''CSV'''',
                   RECORD_DELIMITER =  NONE
                   field_delimiter = '''','''',
				   empty_field_as_null=false
			       NULL_IF = ('''''''',''''NULL'''', ''''Null'''',''''null'''')
                   compression = NONE
                  )
    HEADER = FALSE
    OVERWRITE = TRUE
    MAX_FILE_SIZE = 4900000000
    SINGLE = TRUE;''  ;

                               
execute immediate  :V_STAGE_QUERY1;  

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_LOADED, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_LOADED, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );


-- PIPELINE END FOR 3



UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''COMPLETE'', ERROR_MSG = null, BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
;
UPDATE  UTIL.ETL_BATCH_OBJECT_INCR_VALU SET INCR_COLUMN_VALUE = :V_BATCH_ID, LST_MOD_DT = CURRENT_TIMESTAMP() 
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID''
;


RETURN ''ECG_FILE_TRANSFER'';

EXCEPTION

WHEN OTHER THEN

UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''ERROR'', ERROR_MSG = :SQLERRM,  BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
;

INSERT INTO  UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ERROR_MSG, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''ERROR'', :V_STEP_NAME, :V_STEP_SEQ, :SQLERRM, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() )
;



RAISE;

END;

';