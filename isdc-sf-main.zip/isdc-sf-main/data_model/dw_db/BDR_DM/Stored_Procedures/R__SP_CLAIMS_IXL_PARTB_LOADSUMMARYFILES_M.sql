USE SCHEMA BDR_DM; CREATE OR REPLACE PROCEDURE "SP_CLAIMS_IXL_PARTB_LOADSUMMARYFILES_M"("DB_NAME" VARCHAR(16777216), "APPLICATION" VARCHAR(16777216), "WORKFLOW_NAME" VARCHAR(16777216), "OBJECT_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '

-- Original workflow: wkf_Claims_PartB_IXL_TargetLoad_M
-- Original mapping: m_Claims_IXL_PartB_loadSummaryfiles_M
-- Original folder: Claims
-- Original filename: wkf_Claims_PartB_IXL_TargetLoad_M.XML

DECLARE


V_ROWS_INSERTED  INTEGER;
V_ROWS_UPDATED INTEGER;
V_ROWS_DELETED INTEGER;
V_LAST_QUERY_ID VARCHAR;

V_WH VARCHAR;
V_BATCH_ID INTEGER;


V_BATCH_OBJECT_START_TIME        VARCHAR;
V_STEP_START_TIME    VARCHAR;
V_STEP_NAME VARCHAR;
V_STEP_SEQ INTEGER DEFAULT 0;
V_ETL_LST_BTCH_ID INTEGER;

V_ROWS_LOADED INTEGER;
V_STAGE_QUERY1 VARCHAR;
V_STAGE_QUERY2 VARCHAR;
V_STAGE VARCHAR;
V_OUTBOX_DIR VARCHAR; 
V_FILE_NAME VARCHAR;
V_FILE_PATTERN VARCHAR;


BEGIN

EXECUTE IMMEDIATE ''USE DATABASE ''||:DB_NAME; 

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_BATCH_OBJECT_START_TIME := (SELECT CURRENT_TIMESTAMP());



LET res1 RESULTSET := 
(

SELECT 

WH ,
BATCH_ID
  
FROM UTIL.ETL_BATCH_OBJECT_CONTROL
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
FETCH FIRST 1 ROW ONLY

)
;


LET C1 CURSOR FOR res1;
open C1;
FETCH C1 into  V_WH,V_BATCH_ID ;
close C1;



LET res2 RESULTSET := 

(

WITH PARAMETERS (STAGE, OUTBOX_DIR, FILE_PATTERN) AS
(
  
SELECT * 
FROM  
(SELECT PARAMETER_NAME, PARAMETER_VALUE  FROM UTIL.ETL_OBJECT_PARAMETER_VALUE 
WHERE 1 = 1
AND APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
AND ACTIVE_FLG = ''Y''  
  
UNION ALL       

SELECT PARAMETER_NAME, PARAMETER_VALUE  FROM UTIL.ETL_GLOBAL_PARAMETER_VALUE WHERE PAR_GLOBAL_TYPE = ''PARGLOBAL_OPREPORTS'' AND ACTIVE_FLG = ''Y''
AND PARAMETER_NAME NOT IN  (
SELECT PARAMETER_NAME  FROM UTIL.ETL_OBJECT_PARAMETER_VALUE WHERE 1 = 1
AND APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
AND ACTIVE_FLG = ''Y''   ))
 
PIVOT(MAX(PARAMETER_VALUE) FOR PARAMETER_NAME IN (''STAGE'', ''OUTBOX_DIR'', ''FILE_PATTERN'')) 

 
)  
SELECT * FROM PARAMETERS 
)  
  
;


LET C2 CURSOR FOR res2;
open C2;
FETCH C2 into  V_STAGE, V_OUTBOX_DIR, V_FILE_PATTERN; 
close C2;



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:V_WH;
USE SCHEMA BDR_DM;		--OAS ADD


INSERT INTO UTIL.ETL_BATCH_OBJECT_INCR_VALU (APPLICATION, WORKFLOW_NAME, OBJECT_NAME, INCR_COLUMN, INCR_COLUMN_VALUE )
SELECT * FROM (select :APPLICATION AS APPLICATION, :WORKFLOW_NAME AS WORKFLOW_NAME, :OBJECT_NAME AS OBJECT_NAME, ''ETL_LST_BTCH_ID'' AS INCR_COLUMN, -1 AS INCR_COLUMN_VALUE) A
WHERE NOT EXISTS (SELECT 1 FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU B WHERE B.APPLICATION = A.APPLICATION AND B.WORKFLOW_NAME = A.WORKFLOW_NAME AND B.OBJECT_NAME = A.OBJECT_NAME AND B.INCR_COLUMN = A.INCR_COLUMN)
;

V_ETL_LST_BTCH_ID :=(SELECT INCR_COLUMN_VALUE FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID'');

  
EXECUTE IMMEDIATE ''REMOVE ''||:V_STAGE||:V_OUTBOX_DIR;   -----Remove previous files----------- 


-- PIPELINE START FOR 1

V_STEP_NAME := ''GENERATE Part_B_Weights_OPPS_By_CPT FILE''; 
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_LOADED := NULL;

-- Component sq_R_PART_B_WGT_OPPS_SUM, Type SOURCE 
CREATE OR REPLACE TEMPORARY TABLE sq_R_PART_B_WGT_OPPS_SUM AS
(
SELECT SRC.*, row_number() over (order by 1) AS source_record_id FROM (
SELECT
R_PART_B_WGT_OPPS_SUM.CPT_CD,
R_PART_B_WGT_OPPS_SUM.SRVC_YR_NBR,
R_PART_B_WGT_OPPS_SUM.SRVC_FROM_MO_NBR,
R_PART_B_WGT_OPPS_SUM.BEN_TOT_AMT,
R_PART_B_WGT_OPPS_SUM.BL_CNT,
R_PART_B_WGT_OPPS_SUM.BEN_TOT_PD_AMT,
R_PART_B_WGT_OPPS_SUM.BL_PD_CNT
FROM BDR_DM.R_PART_B_WGT_OPPS_SUM
) SRC
);


-- Component exp_Filename_oppssum, Type EXPRESSION 
CREATE OR REPLACE TEMPORARY TABLE exp_Filename_oppssum AS
(
SELECT
--to_char ( CURRENT_TIMESTAMP , ''Mon'' ) || to_char ( CURRENT_TIMESTAMP , ''yyyy'' ) as v_month,
--''Part_B_Weights_OPPS_By_CPT_'' || v_month || ''.csv'' as o_Filename,
sq_R_PART_B_WGT_OPPS_SUM.CPT_CD as CPT_CD,
sq_R_PART_B_WGT_OPPS_SUM.SRVC_YR_NBR as SRVC_YR_NBR,
sq_R_PART_B_WGT_OPPS_SUM.SRVC_FROM_MO_NBR as SRVC_FROM_MO_NBR,
sq_R_PART_B_WGT_OPPS_SUM.BEN_TOT_AMT as BEN_TOT_AMT,
sq_R_PART_B_WGT_OPPS_SUM.BL_CNT as BL_CNT,
sq_R_PART_B_WGT_OPPS_SUM.BEN_TOT_PD_AMT as BEN_TOT_PD_AMT,
sq_R_PART_B_WGT_OPPS_SUM.BL_PD_CNT as BL_PD_CNT,
sq_R_PART_B_WGT_OPPS_SUM.source_record_id
FROM
sq_R_PART_B_WGT_OPPS_SUM
);




-- Component sc_tgt_FF_PART_B_WGT_OPPS_SUM, Type TARGET_EXPORT_PREPARE Stage data before exporting
CREATE OR REPLACE TEMPORARY TABLE sc_tgt_FF_PART_B_WGT_OPPS_SUM AS
(
SELECT
--exp_Filename_oppssum.o_Filename /* FileName */,
exp_Filename_oppssum.CPT_CD /* CPT_CD */,
exp_Filename_oppssum.SRVC_YR_NBR /* SRVC_YR_NBR */,
exp_Filename_oppssum.SRVC_FROM_MO_NBR /* SRVC_FROM_MO_NBR */,
exp_Filename_oppssum.BEN_TOT_AMT /* BEN_TOT_AMT */,
exp_Filename_oppssum.BL_CNT /* BL_CNT */,
exp_Filename_oppssum.BEN_TOT_PD_AMT /* BEN_TOT_PD_AMT */,
exp_Filename_oppssum.BL_PD_CNT /* BL_PD_CNT */
FROM
exp_Filename_oppssum
);

V_ROWS_LOADED := (select count(1) from sc_tgt_FF_PART_B_WGT_OPPS_SUM);

V_FILE_NAME := ''Part_B_Weights_OPPS_By_CPT_'' || (SELECT to_char ( CURRENT_TIMESTAMP , ''Mon'' )) || (SELECT to_char ( CURRENT_TIMESTAMP , ''yyyy'' )) || ''.csv''; 


-- Component sc_tgt_FF_PART_B_WGT_OPPS_SUM, Type EXPORT_DATA Exporting data
V_STAGE_QUERY1 := ''COPY INTO ''||:V_STAGE||:V_OUTBOX_DIR||:V_FILE_NAME || 
'' FROM (
            SELECT * FROM sc_tgt_FF_PART_B_WGT_OPPS_SUM
               )
file_format = (type = ''''CSV'''',
                   field_delimiter = '''','''',
				   empty_field_as_null=false
			       NULL_IF = ('''''''',''''NULL'''', ''''Null'''',''''null'''')
                   compression = NONE
              )
HEADER = TRUE
OVERWRITE = True
MAX_FILE_SIZE = 4900000000
SINGLE = TRUE;''
;


V_STAGE_QUERY2 := ''COPY INTO ''||:V_STAGE||:V_OUTBOX_DIR||:V_FILE_NAME || 
'' FROM (
            SELECT ''''CPT_CD'''',
				''''SRVC_YR_NBR'''',
				''''SRVC_FROM_MO_NBR'''',
				''''BEN_TOT_AMT'''',
				''''BL_CNT'''',
				''''BEN_TOT_PD_AMT'''',
				''''BL_PD_CNT''''
               )
file_format = (type = ''''CSV'''',
                   field_delimiter = '''','''',
				   empty_field_as_null=false
			       NULL_IF = ('''''''',''''NULL'''', ''''Null'''',''''null'''')
                   compression = NONE
              )
HEADER = FALSE
OVERWRITE = True
MAX_FILE_SIZE = 4900000000
SINGLE = TRUE;''
;


IF (V_ROWS_LOADED > 0) THEN 

execute immediate ''USE SCHEMA ''|| ''BDR_DM'';                                  
execute immediate  :V_STAGE_QUERY1;  

ELSEIF (V_ROWS_LOADED = 0) THEN 

execute immediate ''USE SCHEMA ''|| ''BDR_DM'';                                  
execute immediate  :V_STAGE_QUERY2;  


END IF;  


INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_LOADED, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_LOADED, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );



-- PIPELINE END FOR 1

-- PIPELINE START FOR 2

V_STEP_NAME := ''GENERATE Part_B_Weights_Drug_By_CPT FILE''; 
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_LOADED := NULL;

-- Component sq_R_PART_B_WGT_RX_SUM, Type SOURCE 
CREATE OR REPLACE TEMPORARY TABLE sq_R_PART_B_WGT_RX_SUM AS
(
SELECT SRC.*, row_number() over (order by 1) AS source_record_id FROM (
SELECT
R_PART_B_WGT_RX_SUM.CPT_CD,
R_PART_B_WGT_RX_SUM.SRVC_YR_NBR,
R_PART_B_WGT_RX_SUM.SRVC_FROM_MO_NBR,
R_PART_B_WGT_RX_SUM.BEN_TOT_AMT,
R_PART_B_WGT_RX_SUM.BL_CNT,
R_PART_B_WGT_RX_SUM.BEN_TOT_PD_AMT,
R_PART_B_WGT_RX_SUM.BL_PD_CNT
FROM BDR_DM.R_PART_B_WGT_RX_SUM
) SRC
);


-- Component exp_Filename_Rxsum, Type EXPRESSION 
CREATE OR REPLACE TEMPORARY TABLE exp_Filename_Rxsum AS
(
SELECT
--to_char ( CURRENT_TIMESTAMP , ''Mon'' ) || to_char ( CURRENT_TIMESTAMP , ''yyyy'' ) as v_month,
--''Part_B_Weights_Drug_By_CPT_'' || v_month || ''.csv'' as o_Filename,
sq_R_PART_B_WGT_RX_SUM.CPT_CD as CPT_CD,
sq_R_PART_B_WGT_RX_SUM.SRVC_YR_NBR as SRVC_YR_NBR,
sq_R_PART_B_WGT_RX_SUM.SRVC_FROM_MO_NBR as SRVC_FROM_MO_NBR,
sq_R_PART_B_WGT_RX_SUM.BEN_TOT_AMT as BEN_TOT_AMT,
sq_R_PART_B_WGT_RX_SUM.BL_CNT as BL_CNT,
sq_R_PART_B_WGT_RX_SUM.BEN_TOT_PD_AMT as BEN_TOT_PD_AMT,
sq_R_PART_B_WGT_RX_SUM.BL_PD_CNT as BL_PD_CNT,
sq_R_PART_B_WGT_RX_SUM.source_record_id
FROM
sq_R_PART_B_WGT_RX_SUM
);


-- Component sc_tgt_FF_PART_B_WGT_RX_SUM, Type TARGET_EXPORT_PREPARE Stage data before exporting
CREATE OR REPLACE TEMPORARY TABLE sc_tgt_FF_PART_B_WGT_RX_SUM AS
(
SELECT
--exp_Filename_Rxsum.o_Filename /* FileName */,
exp_Filename_Rxsum.CPT_CD /* CPT_CD */,
exp_Filename_Rxsum.SRVC_YR_NBR /* SRVC_YR_NBR */,
exp_Filename_Rxsum.SRVC_FROM_MO_NBR /* SRVC_FROM_MO_NBR */,
exp_Filename_Rxsum.BEN_TOT_AMT /* BEN_TOT_AMT */,
exp_Filename_Rxsum.BL_CNT /* BL_CNT */,
exp_Filename_Rxsum.BEN_TOT_PD_AMT /* BEN_TOT_PD_AMT */,
exp_Filename_Rxsum.BL_PD_CNT /* BL_PD_CNT */
FROM
exp_Filename_Rxsum
);


V_ROWS_LOADED := (select count(1) from sc_tgt_FF_PART_B_WGT_RX_SUM);

V_FILE_NAME := ''Part_B_Weights_Drug_By_CPT_'' || (SELECT to_char ( CURRENT_TIMESTAMP , ''Mon'' )) || (SELECT to_char ( CURRENT_TIMESTAMP , ''yyyy'' )) || ''.csv'';

-- Component sc_tgt_FF_PART_B_WGT_RX_SUM, Type EXPORT_DATA Exporting data
V_STAGE_QUERY1 := ''COPY INTO ''||:V_STAGE||:V_OUTBOX_DIR||:V_FILE_NAME || 
'' FROM (
            SELECT * FROM sc_tgt_FF_PART_B_WGT_RX_SUM
               )
file_format = (type = ''''CSV'''',
                   field_delimiter = '''','''',
				   empty_field_as_null=false
			       NULL_IF = ('''''''',''''NULL'''', ''''Null'''',''''null'''')
                   compression = NONE
              )
HEADER = TRUE
OVERWRITE = True
MAX_FILE_SIZE = 4900000000
SINGLE = TRUE;''
;


V_STAGE_QUERY2 := ''COPY INTO ''||:V_STAGE||:V_OUTBOX_DIR||:V_FILE_NAME || 
'' FROM (
            SELECT ''''CPT_CD'''',
				''''SRVC_YR_NBR'''',
				''''SRVC_FROM_MO_NBR'''',
				''''BEN_TOT_AMT'''',
				''''BL_CNT'''',
				''''BEN_TOT_PD_AMT'''',
				''''BL_PD_CNT''''
               )
file_format = (type = ''''CSV'''',
                   field_delimiter = '''','''',
				   empty_field_as_null=false
			       NULL_IF = ('''''''',''''NULL'''', ''''Null'''',''''null'''')
                   compression = NONE
              )
HEADER = FALSE
OVERWRITE = True
MAX_FILE_SIZE = 4900000000
SINGLE = TRUE;''
;


IF (V_ROWS_LOADED > 0) THEN 

execute immediate ''USE SCHEMA ''|| ''BDR_DM'';                                  
execute immediate  :V_STAGE_QUERY1;  

ELSEIF (V_ROWS_LOADED = 0) THEN 

execute immediate ''USE SCHEMA ''|| ''BDR_DM'';                                  
execute immediate  :V_STAGE_QUERY2;  


END IF;  


INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_LOADED, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_LOADED, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );



-- PIPELINE END FOR 2

-- PIPELINE START FOR 3

V_STEP_NAME := ''GENERATE Part_B_Weights_Physician_By_CPT FILE''; 
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());

-- Component sq_R_PART_B_WGT_PHYSN_SUM, Type SOURCE 
CREATE OR REPLACE TEMPORARY TABLE sq_R_PART_B_WGT_PHYSN_SUM AS
(
SELECT SRC.*, row_number() over (order by 1) AS source_record_id FROM (
SELECT
R_PART_B_WGT_PHYSN_SUM.CPT_CD,
R_PART_B_WGT_PHYSN_SUM.SRVC_YR_NBR,
R_PART_B_WGT_PHYSN_SUM.SRVC_FROM_MO_NBR,
R_PART_B_WGT_PHYSN_SUM.BEN_TOT_AMT,
R_PART_B_WGT_PHYSN_SUM.BL_CNT,
R_PART_B_WGT_PHYSN_SUM.BEN_TOT_PD_AMT,
R_PART_B_WGT_PHYSN_SUM.BL_PD_CNT
FROM BDR_DM.R_PART_B_WGT_PHYSN_SUM
) SRC
);


-- Component exp_Filename_physsum, Type EXPRESSION 
CREATE OR REPLACE TEMPORARY TABLE exp_Filename_physsum AS
(
SELECT
--to_char ( CURRENT_TIMESTAMP , ''Mon'' ) || to_char ( CURRENT_TIMESTAMP , ''yyyy'' ) as v_month,
--''Part_B_Weights_Physician_By_CPT_'' || v_month || ''.csv'' as o_Filename,
sq_R_PART_B_WGT_PHYSN_SUM.CPT_CD as CPT_CD,
sq_R_PART_B_WGT_PHYSN_SUM.SRVC_YR_NBR as SRVC_YR_NBR,
sq_R_PART_B_WGT_PHYSN_SUM.SRVC_FROM_MO_NBR as SRVC_FROM_MO_NBR,
sq_R_PART_B_WGT_PHYSN_SUM.BEN_TOT_AMT as BEN_TOT_AMT,
sq_R_PART_B_WGT_PHYSN_SUM.BL_CNT as BL_CNT,
sq_R_PART_B_WGT_PHYSN_SUM.BEN_TOT_PD_AMT as BEN_TOT_PD_AMT,
sq_R_PART_B_WGT_PHYSN_SUM.BL_PD_CNT as BL_PD_CNT,
sq_R_PART_B_WGT_PHYSN_SUM.source_record_id
FROM
sq_R_PART_B_WGT_PHYSN_SUM
);


-- Component sc_tgt_FF_PART_B_WGT_PHYSN_SUM, Type TARGET_EXPORT_PREPARE Stage data before exporting
CREATE OR REPLACE TEMPORARY TABLE sc_tgt_FF_PART_B_WGT_PHYSN_SUM AS
(
SELECT
--exp_Filename_physsum.o_Filename /* FileName */,
exp_Filename_physsum.CPT_CD /* CPT_CD */,
exp_Filename_physsum.SRVC_YR_NBR /* SRVC_YR_NBR */,
exp_Filename_physsum.SRVC_FROM_MO_NBR /* SRVC_FROM_MO_NBR */,
exp_Filename_physsum.BEN_TOT_AMT /* BEN_TOT_AMT */,
exp_Filename_physsum.BL_CNT /* BL_CNT */,
exp_Filename_physsum.BEN_TOT_PD_AMT /* BEN_TOT_PD_AMT */,
exp_Filename_physsum.BL_PD_CNT /* BL_PD_CNT */
FROM
exp_Filename_physsum
);

V_ROWS_LOADED := (select count(1) from sc_tgt_FF_PART_B_WGT_PHYSN_SUM);

V_FILE_NAME := ''Part_B_Weights_Physician_By_CPT_'' || (SELECT to_char ( CURRENT_TIMESTAMP , ''Mon'' )) || (SELECT to_char ( CURRENT_TIMESTAMP , ''yyyy'' )) || ''.csv'';

-- Component sc_tgt_FF_PART_B_WGT_PHYSN_SUM, Type EXPORT_DATA Exporting data
V_STAGE_QUERY1 := ''COPY INTO ''||:V_STAGE||:V_OUTBOX_DIR||:V_FILE_NAME || 
'' FROM (
            SELECT * FROM sc_tgt_FF_PART_B_WGT_PHYSN_SUM
               )
file_format = (type = ''''CSV'''',
                   field_delimiter = '''','''',
				   empty_field_as_null=false
			       NULL_IF = ('''''''',''''NULL'''', ''''Null'''',''''null'''')
                   compression = NONE
              )
HEADER = TRUE
OVERWRITE = True
MAX_FILE_SIZE = 4900000000
SINGLE = TRUE;''
;


V_STAGE_QUERY2 := ''COPY INTO ''||:V_STAGE||:V_OUTBOX_DIR||:V_FILE_NAME || 
'' FROM (
            SELECT ''''CPT_CD'''',
				''''SRVC_YR_NBR'''',
				''''SRVC_FROM_MO_NBR'''',
				''''BEN_TOT_AMT'''',
				''''BL_CNT'''',
				''''BEN_TOT_PD_AMT'''',
				''''BL_PD_CNT''''

               )
file_format = (type = ''''CSV'''',
                   field_delimiter = '''','''',
				   empty_field_as_null=false
			       NULL_IF = ('''''''',''''NULL'''', ''''Null'''',''''null'''')
                   compression = NONE
              )
HEADER = FALSE
OVERWRITE = True
MAX_FILE_SIZE = 4900000000
SINGLE = TRUE;''
;


IF (V_ROWS_LOADED > 0) THEN 

execute immediate ''USE SCHEMA ''|| ''BDR_DM'';                                  
execute immediate  :V_STAGE_QUERY1;  

ELSEIF (V_ROWS_LOADED = 0) THEN 

execute immediate ''USE SCHEMA ''|| ''BDR_DM'';                                  
execute immediate  :V_STAGE_QUERY2;  


END IF;  


INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_LOADED, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_LOADED, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );



-- PIPELINE END FOR 3

-- PIPELINE START FOR 4

V_STEP_NAME := ''GENERATE Part_B_Weights_DME_By_CPT FILE''; 
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_LOADED := NULL;

-- Component sq_R_PART_B_WGT_DME_SUM, Type SOURCE 
CREATE OR REPLACE TEMPORARY TABLE sq_R_PART_B_WGT_DME_SUM AS
(
SELECT SRC.*, row_number() over (order by 1) AS source_record_id FROM (
SELECT
R_PART_B_WGT_DME_SUM.CPT_CD,
R_PART_B_WGT_DME_SUM.SRVC_YR_NBR,
R_PART_B_WGT_DME_SUM.SRVC_FROM_MO_NBR,
R_PART_B_WGT_DME_SUM.BEN_TOT_AMT,
R_PART_B_WGT_DME_SUM.BL_CNT,
R_PART_B_WGT_DME_SUM.BEN_TOT_PD_AMT,
R_PART_B_WGT_DME_SUM.BL_PD_CNT
FROM BDR_DM.R_PART_B_WGT_DME_SUM
) SRC
);


-- Component exp_filename_dmesum, Type EXPRESSION 
CREATE OR REPLACE TEMPORARY TABLE exp_filename_dmesum AS
(
SELECT
--to_char ( CURRENT_TIMESTAMP , ''Mon'' ) || to_char ( CURRENT_TIMESTAMP , ''yyyy'' ) as v_month,
--''Part_B_Weights_DME_By_CPT_'' || v_month || ''.csv'' as o_Filename,
sq_R_PART_B_WGT_DME_SUM.CPT_CD as CPT_CD,
sq_R_PART_B_WGT_DME_SUM.SRVC_YR_NBR as SRVC_YR_NBR,
sq_R_PART_B_WGT_DME_SUM.SRVC_FROM_MO_NBR as SRVC_FROM_MO_NBR,
sq_R_PART_B_WGT_DME_SUM.BEN_TOT_AMT as BEN_TOT_AMT,
sq_R_PART_B_WGT_DME_SUM.BL_CNT as BL_CNT,
sq_R_PART_B_WGT_DME_SUM.BEN_TOT_PD_AMT as BEN_TOT_PD_AMT,
sq_R_PART_B_WGT_DME_SUM.BL_PD_CNT as BL_PD_CNT,
sq_R_PART_B_WGT_DME_SUM.source_record_id
FROM
sq_R_PART_B_WGT_DME_SUM
);


-- Component sc_tgt_FF_PART_B_WGT_DME_SUM, Type TARGET_EXPORT_PREPARE Stage data before exporting
CREATE OR REPLACE TEMPORARY TABLE sc_tgt_FF_PART_B_WGT_DME_SUM AS
(
SELECT
--exp_filename_dmesum.o_Filename /* FileName */,
exp_filename_dmesum.CPT_CD /* CPT_CD */,
exp_filename_dmesum.SRVC_YR_NBR /* SRVC_YR_NBR */,
exp_filename_dmesum.SRVC_FROM_MO_NBR /* SRVC_FROM_MO_NBR */,
exp_filename_dmesum.BEN_TOT_AMT /* BEN_TOT_AMT */,
exp_filename_dmesum.BL_CNT /* BL_CNT */,
exp_filename_dmesum.BEN_TOT_PD_AMT /* BEN_TOT_PD_AMT */,
exp_filename_dmesum.BL_PD_CNT /* BL_PD_CNT */
FROM
exp_filename_dmesum
);

V_ROWS_LOADED := (select count(1) from sc_tgt_FF_PART_B_WGT_DME_SUM);

V_FILE_NAME := ''Part_B_Weights_DME_By_CPT_'' || (SELECT to_char ( CURRENT_TIMESTAMP , ''Mon'' )) || (SELECT to_char ( CURRENT_TIMESTAMP , ''yyyy'' )) || ''.csv'';

-- Component sc_tgt_FF_PART_B_WGT_DME_SUM, Type EXPORT_DATA Exporting data
V_STAGE_QUERY1 := ''COPY INTO ''||:V_STAGE||:V_OUTBOX_DIR||:V_FILE_NAME || 
'' FROM (
            SELECT * FROM sc_tgt_FF_PART_B_WGT_DME_SUM
               )
file_format = (type = ''''CSV'''',
                   field_delimiter = '''','''',
				   empty_field_as_null=false
			       NULL_IF = ('''''''',''''NULL'''', ''''Null'''',''''null'''')
                   compression = NONE
              )
HEADER = TRUE
OVERWRITE = True
MAX_FILE_SIZE = 4900000000
SINGLE = TRUE;''
;


V_STAGE_QUERY2 := ''COPY INTO''||:V_STAGE||:V_OUTBOX_DIR||:V_FILE_NAME || 
'' FROM (
            SELECT ''''CPT_CD'''',
				''''SRVC_YR_NBR'''',
				''''SRVC_FROM_MO_NBR'''',
				''''BEN_TOT_AMT'''',
				''''BL_CNT'''',
				''''BEN_TOT_PD_AMT'''',
				''''BL_PD_CNT''''

               )
file_format = (type = ''''CSV'''',
                   field_delimiter = '''','''',
				   empty_field_as_null=false
			       NULL_IF = ('''''''',''''NULL'''', ''''Null'''',''''null'''')
                   compression = NONE
              )
HEADER = FALSE
OVERWRITE = True
MAX_FILE_SIZE = 4900000000
SINGLE = TRUE;''
;


IF (V_ROWS_LOADED > 0) THEN 

execute immediate ''USE SCHEMA ''|| ''BDR_DM'';                                  
execute immediate  :V_STAGE_QUERY1;  

ELSEIF (V_ROWS_LOADED = 0) THEN 

execute immediate ''USE SCHEMA ''|| ''BDR_DM'';                                  
execute immediate  :V_STAGE_QUERY2;  


END IF;  


INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_LOADED, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_LOADED, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );



-- PIPELINE END FOR 4

-- PIPELINE START FOR 5

V_STEP_NAME := ''GENERATE Part_B_Weights_POS_Breakdown FILE''; 
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_LOADED := NULL;

-- Component sq_R_PART_B_WGT_TOT_SUM, Type SOURCE 
CREATE OR REPLACE TEMPORARY TABLE sq_R_PART_B_WGT_TOT_SUM AS
(
SELECT SRC.*, row_number() over (order by 1) AS source_record_id FROM (
SELECT
R_PART_B_WGT_TOT_SUM.PLSRV_2_DESC,
R_PART_B_WGT_TOT_SUM.PLN_TYP_DESC,
R_PART_B_WGT_TOT_SUM.ST_CD,
R_PART_B_WGT_TOT_SUM.SRVC_YR_NBR,
R_PART_B_WGT_TOT_SUM.SRVC_FROM_MO_NBR,
R_PART_B_WGT_TOT_SUM.BEN_TOT_AMT,
R_PART_B_WGT_TOT_SUM.BL_CNT,
R_PART_B_WGT_TOT_SUM.BEN_TOT_PD_AMT,
R_PART_B_WGT_TOT_SUM.BL_PD_CNT
FROM BDR_DM.R_PART_B_WGT_TOT_SUM
) SRC
);


-- Component exp_Filename_Totsum, Type EXPRESSION 
CREATE OR REPLACE TEMPORARY TABLE exp_Filename_Totsum AS
(
SELECT
--to_char ( CURRENT_TIMESTAMP , ''Mon'' ) || to_char ( CURRENT_TIMESTAMP , ''yyyy'' ) as v_month,
--''Part_B_Weights_POS_Breakdown_'' || v_month || ''.csv'' as o_Filename,
sq_R_PART_B_WGT_TOT_SUM.PLSRV_2_DESC as PLSRV_2_DESC,
sq_R_PART_B_WGT_TOT_SUM.PLN_TYP_DESC as PLN_TYP_DESC,
sq_R_PART_B_WGT_TOT_SUM.ST_CD as ST_CD,
sq_R_PART_B_WGT_TOT_SUM.SRVC_YR_NBR as SRVC_YR_NBR,
sq_R_PART_B_WGT_TOT_SUM.SRVC_FROM_MO_NBR as SRVC_FROM_MO_NBR,
sq_R_PART_B_WGT_TOT_SUM.BEN_TOT_AMT as BEN_TOT_AMT,
sq_R_PART_B_WGT_TOT_SUM.BL_CNT as BL_CNT,
sq_R_PART_B_WGT_TOT_SUM.BEN_TOT_PD_AMT as BEN_TOT_PD_AMT,
sq_R_PART_B_WGT_TOT_SUM.BL_PD_CNT as BL_PD_CNT,
sq_R_PART_B_WGT_TOT_SUM.source_record_id
FROM
sq_R_PART_B_WGT_TOT_SUM
);


-- Component sc_tgt_FF_PART_B_WGT_TOT_SUM, Type TARGET_EXPORT_PREPARE Stage data before exporting
CREATE OR REPLACE TEMPORARY TABLE sc_tgt_FF_PART_B_WGT_TOT_SUM AS
(
SELECT
--exp_Filename_Totsum.o_Filename /* FileName */,
exp_Filename_Totsum.PLSRV_2_DESC /* PLSRV_2_DESC */,
exp_Filename_Totsum.PLN_TYP_DESC /* PLN_TYP_DESC */,
exp_Filename_Totsum.ST_CD /* ST_CD */,
exp_Filename_Totsum.SRVC_YR_NBR /* SRVC_YR_NBR */,
exp_Filename_Totsum.SRVC_FROM_MO_NBR /* SRVC_FROM_MO_NBR */,
exp_Filename_Totsum.BEN_TOT_AMT /* BEN_TOT_AMT */,
exp_Filename_Totsum.BL_CNT /* BL_CNT */,
exp_Filename_Totsum.BEN_TOT_PD_AMT /* BEN_TOT_PD_AMT */,
exp_Filename_Totsum.BL_PD_CNT /* BL_PD_CNT */
FROM
exp_Filename_Totsum
);

V_ROWS_LOADED := (select count(1) from sc_tgt_FF_PART_B_WGT_TOT_SUM);

V_FILE_NAME := ''Part_B_Weights_POS_Breakdown_'' || (SELECT to_char ( CURRENT_TIMESTAMP , ''Mon'' )) || (SELECT to_char ( CURRENT_TIMESTAMP , ''yyyy'' )) || ''.csv'';

-- Component sc_tgt_FF_PART_B_WGT_TOT_SUM, Type EXPORT_DATA Exporting data
V_STAGE_QUERY1 := ''COPY INTO ''||:V_STAGE||:V_OUTBOX_DIR||:V_FILE_NAME || 
'' FROM (
            SELECT * FROM sc_tgt_FF_PART_B_WGT_TOT_SUM
               )
file_format = (type = ''''CSV'''',
                   field_delimiter = '''','''',
				   empty_field_as_null=false
			       NULL_IF = ('''''''',''''NULL'''', ''''Null'''',''''null'''')
                   compression = NONE
              )
HEADER = TRUE
OVERWRITE = True
MAX_FILE_SIZE = 4900000000
SINGLE = TRUE;''
;


V_STAGE_QUERY2 := ''COPY INTO ''||:V_STAGE||:V_OUTBOX_DIR||:V_FILE_NAME || 
'' FROM (
            SELECT ''''CPT_CD'''',
				''''SRVC_YR_NBR'''',
				''''SRVC_FROM_MO_NBR'''',
				''''BEN_TOT_AMT'''',
				''''BL_CNT'''',
				''''BEN_TOT_PD_AMT'''',
				''''BL_PD_CNT''''

               )
file_format = (type = ''''CSV'''',
                   field_delimiter = '''','''',
				   empty_field_as_null=false
			       NULL_IF = ('''''''',''''NULL'''', ''''Null'''',''''null'''')
                   compression = NONE
              )
HEADER = FALSE
OVERWRITE = True
MAX_FILE_SIZE = 4900000000
SINGLE = TRUE;''
;


IF (V_ROWS_LOADED > 0) THEN 

execute immediate ''USE SCHEMA ''|| ''BDR_DM'';                                  
execute immediate  :V_STAGE_QUERY1;  

ELSEIF (V_ROWS_LOADED = 0) THEN 

execute immediate ''USE SCHEMA ''|| ''BDR_DM'';                                  
execute immediate  :V_STAGE_QUERY2;  


END IF;  


INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_LOADED, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_LOADED, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );



-- PIPELINE END FOR 5

-- PIPELINE START FOR 6

V_STEP_NAME := ''GENERATE Part_B_Weights_Dialysis_By_CPT FILE''; 
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_LOADED := NULL;

-- Component sq_R_PART_B_WGT_DLS_SUM, Type SOURCE 
CREATE OR REPLACE TEMPORARY TABLE sq_R_PART_B_WGT_DLS_SUM AS
(
SELECT SRC.*, row_number() over (order by 1) AS source_record_id FROM (
SELECT
R_PART_B_WGT_DLS_SUM.CPT_CD,
R_PART_B_WGT_DLS_SUM.SRVC_YR_NBR,
R_PART_B_WGT_DLS_SUM.SRVC_FROM_MO_NBR,
R_PART_B_WGT_DLS_SUM.BEN_TOT_AMT,
R_PART_B_WGT_DLS_SUM.BL_CNT,
R_PART_B_WGT_DLS_SUM.BEN_TOT_PD_AMT,
R_PART_B_WGT_DLS_SUM.BL_PD_CNT
FROM BDR_DM.R_PART_B_WGT_DLS_SUM
) SRC
);


-- Component exp_Filename, Type EXPRESSION 
CREATE OR REPLACE TEMPORARY TABLE exp_Filename AS
(
SELECT
--to_char ( CURRENT_TIMESTAMP , ''Mon'' ) || to_char ( CURRENT_TIMESTAMP , ''yyyy'' ) as v_month,
--''Part_B_Weights_Dialysis_By_CPT_'' || v_month || ''.csv'' as o_Filename,
sq_R_PART_B_WGT_DLS_SUM.CPT_CD as CPT_CD,
sq_R_PART_B_WGT_DLS_SUM.SRVC_YR_NBR as SRVC_YR_NBR,
sq_R_PART_B_WGT_DLS_SUM.SRVC_FROM_MO_NBR as SRVC_FROM_MO_NBR,
sq_R_PART_B_WGT_DLS_SUM.BEN_TOT_AMT as BEN_TOT_AMT,
sq_R_PART_B_WGT_DLS_SUM.BL_CNT as BL_CNT,
sq_R_PART_B_WGT_DLS_SUM.BEN_TOT_PD_AMT as BEN_TOT_PD_AMT,
sq_R_PART_B_WGT_DLS_SUM.BL_PD_CNT as BL_PD_CNT,
sq_R_PART_B_WGT_DLS_SUM.source_record_id
FROM
sq_R_PART_B_WGT_DLS_SUM
);


-- Component sc_tgt_FF_PART_B_WGT_DLS_SUM, Type TARGET_EXPORT_PREPARE Stage data before exporting
CREATE OR REPLACE TEMPORARY TABLE sc_tgt_FF_PART_B_WGT_DLS_SUM AS
(
SELECT
--exp_Filename.o_Filename /* FileName */,
exp_Filename.CPT_CD /* CPT_CD */,
exp_Filename.SRVC_YR_NBR /* SRVC_YR_NBR */,
exp_Filename.SRVC_FROM_MO_NBR /* SRVC_FROM_MO_NBR */,
exp_Filename.BEN_TOT_AMT /* BEN_TOT_AMT */,
exp_Filename.BL_CNT /* BL_CNT */,
exp_Filename.BEN_TOT_PD_AMT /* BEN_TOT_PD_AMT */,
exp_Filename.BL_PD_CNT /* BL_PD_CNT */
FROM
exp_Filename
);

V_ROWS_LOADED := (select count(1) from sc_tgt_FF_PART_B_WGT_DLS_SUM);

V_FILE_NAME := ''Part_B_Weights_Dialysis_By_CPT_'' || (SELECT to_char ( CURRENT_TIMESTAMP , ''Mon'' )) || (SELECT to_char ( CURRENT_TIMESTAMP , ''yyyy'' )) || ''.csv'';

-- Component sc_tgt_FF_PART_B_WGT_DLS_SUM, Type EXPORT_DATA Exporting data
V_STAGE_QUERY1 := ''COPY INTO ''||:V_STAGE||:V_OUTBOX_DIR||:V_FILE_NAME || 
'' FROM (
            SELECT * FROM sc_tgt_FF_PART_B_WGT_DLS_SUM
               )
file_format = (type = ''''CSV'''',
                   field_delimiter = '''','''',
				   empty_field_as_null=false
			       NULL_IF = ('''''''',''''NULL'''', ''''Null'''',''''null'''')
                   compression = NONE
              )
HEADER = TRUE
OVERWRITE = True
MAX_FILE_SIZE = 4900000000
SINGLE = TRUE;''
;


V_STAGE_QUERY2 := ''COPY INTO ''||:V_STAGE||:V_OUTBOX_DIR||:V_FILE_NAME || 
'' FROM (
            SELECT ''''CPT_CD'''',
				''''SRVC_YR_NBR'''',
				''''SRVC_FROM_MO_NBR'''',
				''''BEN_TOT_AMT'''',
				''''BL_CNT'''',
				''''BEN_TOT_PD_AMT'''',
				''''BL_PD_CNT''''
               )
file_format = (type = ''''CSV'''',
                   field_delimiter = '''','''',
				   empty_field_as_null=false
			       NULL_IF = ('''''''',''''NULL'''', ''''Null'''',''''null'''')
                   compression = NONE
              )
HEADER = FALSE
OVERWRITE = True
MAX_FILE_SIZE = 4900000000
SINGLE = TRUE;''
;


IF (V_ROWS_LOADED > 0) THEN 

execute immediate ''USE SCHEMA ''|| ''BDR_DM'';                                  
execute immediate  :V_STAGE_QUERY1;  

ELSEIF (V_ROWS_LOADED = 0) THEN 

execute immediate ''USE SCHEMA ''|| ''BDR_DM'';                                  
execute immediate  :V_STAGE_QUERY2;  


END IF;  


INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_LOADED, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_LOADED, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );



-- PIPELINE END FOR 6
--COMMENTED BY OAS--
/*
--post node line Post SQL for sq_R_PART_B_WGT_DLS_SUM_SRC
V_STEP_NAME    := ''Post_SQL - Update ETL_APPLICATION_METADATA'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

-- Component sq_R_PART_B_WGT_DLS_SUM, Type Post SQL 
 Update UTIL.ETL_APPLICATION_METADATA set METADATA_VALUE=''''  where application=''PARTB'' and METADATA_TYPE in (''v_partb_clm_pd_startdt_1'',''v_partb_clm_pd_startdt_2'',''v_partb_clm_pd_startdt_3'',''v_partb_clm_pd_startdt_4'',''v_partb_clm_pd_startdt_5'',''v_partb_clm_pd_enddt_1'',''v_partb_clm_pd_enddt_2'',''v_partb_clm_pd_enddt_3'',''v_partb_clm_pd_enddt_4'',''v_partb_clm_pd_enddt_5'',''v_process_date''); 

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_UPDATED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );


INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );
*/
--COMMENTED BY OAS--


UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''COMPLETE'', ERROR_MSG = null, BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
;
UPDATE  UTIL.ETL_BATCH_OBJECT_INCR_VALU SET INCR_COLUMN_VALUE = :V_BATCH_ID, LST_MOD_DT = CURRENT_TIMESTAMP() 
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID''
;


RETURN ''ECG_FILE_TRANSFER'';


EXCEPTION

WHEN OTHER THEN

UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''ERROR'', ERROR_MSG = :SQLERRM,  BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
;

INSERT INTO  UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ERROR_MSG, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''ERROR'', :V_STEP_NAME, :V_STEP_SEQ, :SQLERRM, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() )
;



RAISE;

END;

';