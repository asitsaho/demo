USE SCHEMA BDR_DM; CREATE OR REPLACE PROCEDURE "SP_APPLICATION_IXL_LOADWRKINCAPPLTRANSDAY_D"("DB_NAME" VARCHAR(16777216), "APPLICATION" VARCHAR(16777216), "WORKFLOW_NAME" VARCHAR(16777216), "OBJECT_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '

-- Original workflow: wkf_Application_IXL_TargetLoad_D
-- Original mapping: m_Application_IXL_LoadWrkIncApplTransDay_D
-- Original folder: Application
-- Original filename: wkf_Application_IXL_TargetLoad_D.XML

DECLARE


V_ROWS_INSERTED  INTEGER;
V_ROWS_UPDATED INTEGER;
V_ROWS_DELETED INTEGER;
V_LAST_QUERY_ID VARCHAR;

V_WH VARCHAR;
V_BATCH_ID INTEGER;


V_BATCH_OBJECT_START_TIME        VARCHAR;
V_STEP_START_TIME    VARCHAR;
V_STEP_NAME VARCHAR;
V_STEP_SEQ INTEGER DEFAULT 0;
V_ETL_LST_BTCH_ID INTEGER;






BEGIN

EXECUTE IMMEDIATE ''USE DATABASE ''||:DB_NAME; 

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_BATCH_OBJECT_START_TIME := (SELECT CURRENT_TIMESTAMP());



LET res1 RESULTSET := 
(

SELECT 

WH ,
BATCH_ID
  
FROM UTIL.ETL_BATCH_OBJECT_CONTROL
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
FETCH FIRST 1 ROW ONLY

)
;


LET C1 CURSOR FOR res1;
open C1;
FETCH C1 into  V_WH,V_BATCH_ID ;
close C1;






EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:V_WH;
USE SCHEMA BDR_DM;	--OAS ADD--


INSERT INTO UTIL.ETL_BATCH_OBJECT_INCR_VALU (APPLICATION, WORKFLOW_NAME, OBJECT_NAME, INCR_COLUMN, INCR_COLUMN_VALUE )
SELECT * FROM (select :APPLICATION AS APPLICATION, :WORKFLOW_NAME AS WORKFLOW_NAME, :OBJECT_NAME AS OBJECT_NAME, ''ETL_LST_BTCH_ID'' AS INCR_COLUMN, -1 AS INCR_COLUMN_VALUE) A
WHERE NOT EXISTS (SELECT 1 FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU B WHERE B.APPLICATION = A.APPLICATION AND B.WORKFLOW_NAME = A.WORKFLOW_NAME AND B.OBJECT_NAME = A.OBJECT_NAME AND B.INCR_COLUMN = A.INCR_COLUMN)
;

V_ETL_LST_BTCH_ID :=(SELECT INCR_COLUMN_VALUE FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID'');


-- PIPELINE START FOR 1
-- Component sc_tgt_WrkIncApplTransDay, Type Pre SQL 

V_STEP_NAME    := ''TARGET - TRUNCATE WRK_INC_APPL_TRANS_DAY'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

--CALL $Param_DMSchema.PKG_DB_UTIL.SP_TRUNCATE_TABLE(''$Param_DMSchema'',''WRK_INC_APPL_TRANS_DAY'');	--OAS DELETE--


TRUNCATE TABLE BDR_DM.WRK_INC_APPL_TRANS_DAY;	--OAS ADD--

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

--pre node line TARGET for sc_tgt_WrkIncApplTransDay
V_STEP_NAME    := ''TARGET - INSERT WRK_INC_APPL_TRANS_DAY'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

-- Component sq_Application, Type SOURCE 
CREATE OR REPLACE TEMPORARY TABLE sq_Application AS
(
SELECT SRC.*, row_number() over (order by 1) AS source_record_id FROM (
SELECT APPL.APPLICATION_ID ,
  MAX(ATD.F_APPL_TRANS_DAY_SK) AS LAST_RECORD_KEY,
  CASE
    WHEN ATD.APPL_ID IS NULL
    THEN ''INSERT''
    ELSE ''OLD''
  END AS ACTION_FLAG
FROM SRC_COMPAS_D.APPLICATION APPL
LEFT OUTER JOIN BDR_DM.F_APPL_TRANS_DAY ATD
ON APPL.APPLICATION_ID = ATD.APPL_ID
--COMMENTED BY OAS--
/* LEFT OUTER JOIN UTIL.ETL_APPLICATION_METADATA APPMET
ON  APPLICATION          = '':V_MP_APPL_APPLICATION''
AND METADATA_TYPE        = '':V_MP_MetadataType''
AND METADATA_DESC        = '':V_MP_MetadataDesc'' */
--COMMENTED BY OAS--
--WHERE APPL.ETL_LST_BTCH_ID   > TO_NUMBER(APPMET.METADATA_VALUE,''''9999999999999999'''')	--OAS DELETE
WHERE APPL.ETL_LST_BTCH_ID   > :V_ETL_LST_BTCH_ID 	--OAS ADD
AND APPL.APPL_RECEIPT_DATE   > ADD_MONTHS(TRUNC(CURRENT_DATE,''YEAR''),-12 * 9)
GROUP BY APPL.APPLICATION_ID,
  CASE
    WHEN ATD.APPL_ID IS NULL
    THEN ''INSERT''
    ELSE ''OLD''
  END 
  UNION
  SELECT ATD.APPL_ID,
  MAX(ATD.F_APPL_TRANS_DAY_SK) AS LAST_RECORD_KEY,
  CASE
    WHEN ATD.APPL_ID IS NULL
    THEN ''INSERT''
    ELSE ''OLD''
  END AS ACTION_FLAG
  FROM BDR_CONF.D_AGT DA INNER JOIN BDR_DM.WRK_APPL_WRITING_AGENT  WAWA
  ON DA.AGT_ID=WAWA.WRITING_AGENT 
  LEFT OUTER JOIN BDR_DM.F_APPL_TRANS_DAY ATD
  ON WAWA.APPLICATION_ID = ATD.APPL_ID
  --COMMENTED BY OAS--
/*   LEFT OUTER JOIN UTIL.ETL_APPLICATION_METADATA APPMET
  ON  APPLICATION        = '':V_MP_D_AGT_CONFDIMENSIONS''
AND METADATA_TYPE        = '':V_MP_D_AGT_MetadataType''
AND METADATA_DESC        = '':V_MP_D_AGT_MetadataDesc''  */
--COMMENTED BY OAS--
--WHERE DA.ETL_LST_BTCH_ID   > TO_NUMBER(APPMET.METADATA_VALUE,''''9999999999999999'''')	--OAS DELETE
WHERE DA.ETL_LST_BTCH_ID   >= 192999 --:V_ETL_LST_BTCH_ID -- OAS ADD (Should be >= --OAS - SPALLA2)
GROUP BY ATD.APPL_ID,
  CASE
    WHEN ATD.APPL_ID IS NULL
    THEN ''INSERT''
    ELSE ''OLD''
  END 
 UNION 
 SELECT ATD.APPL_ID,
  MAX(ATD.F_APPL_TRANS_DAY_SK) AS LAST_RECORD_KEY,
  CASE
    WHEN ATD.APPL_ID IS NULL
    THEN ''INSERT''
    ELSE ''OLD''
  END AS ACTION_FLAG
  FROM BDR_CONF.D_AGT DA INNER JOIN BDR_DM.WRK_APPL_SELLING_AGENT  WASA
  ON DA.AGT_ID=WASA.SELLING_AGENT 
  LEFT OUTER JOIN BDR_DM.F_APPL_TRANS_DAY ATD
   ON WASA.APPLICATION_ID = ATD.APPL_ID
   --COMMENTED BY OAS--
/*    LEFT OUTER JOIN UTIL.ETL_APPLICATION_METADATA APPMET
  ON  APPLICATION        = '':V_MP_D_AGT_CONFDIMENSIONS''
AND METADATA_TYPE        = '':V_MP_D_AGT_MetadataType''
AND METADATA_DESC        = '':V_MP_D_AGT_MetadataDesc'' */
--COMMENTED BY OAS--
--WHERE DA.ETL_LST_BTCH_ID   > TO_NUMBER(APPMET.METADATA_VALUE,''''9999999999999999'''')	--OAS DELETE
WHERE DA.ETL_LST_BTCH_ID   >= 192999 --:V_ETL_LST_BTCH_ID --OAS ADD (Should be >= --OAS - SPALLA2)
GROUP BY ATD.APPL_ID,
  CASE
    WHEN ATD.APPL_ID IS NULL
    THEN ''INSERT''
    ELSE ''OLD''
  END  
UNION
SELECT ATD.APPL_ID,
 MAX(ATD.F_APPL_TRANS_DAY_SK) AS LAST_RECORD_KEY,
  CASE
    WHEN ATD.APPL_ID IS NULL
    THEN ''INSERT''
    ELSE ''OLD''
  END AS ACTION_FLAG
  FROM BDR_CONF.D_AGT DA INNER JOIN BDR_DM.WRK_APPL_REFERRAL_AGENT  WARA
  ON DA.AGT_ID=WARA.REFERRAL_AGENT 
  LEFT OUTER JOIN BDR_DM.F_APPL_TRANS_DAY ATD
  ON WARA.APPLICATION_ID = ATD.APPL_ID
  --COMMENTED BY OAS--
/*   LEFT OUTER JOIN UTIL.ETL_APPLICATION_METADATA APPMET
  ON  APPLICATION       = '':V_MP_D_AGT_CONFDIMENSIONS''
AND METADATA_TYPE        = '':V_MP_D_AGT_MetadataType''
AND METADATA_DESC        = '':V_MP_D_AGT_MetadataDesc'' */
--COMMENTED BY OAS--
--WHERE DA.ETL_LST_BTCH_ID   > TO_NUMBER(APPMET.METADATA_VALUE,''''9999999999999999'''')	--OAS DELETE
WHERE DA.ETL_LST_BTCH_ID   >= 192999 --:V_ETL_LST_BTCH_ID --OAS ADD (Should be >= --OAS - SPALLA2)
GROUP BY ATD.APPL_ID,
  CASE
    WHEN ATD.APPL_ID IS NULL
    THEN ''INSERT''
    ELSE ''OLD''
  END
) SRC
);




-- Component sc_tgt_WrkIncApplTransDay, Type TARGET 
INSERT INTO BDR_DM.WRK_INC_APPL_TRANS_DAY
(
APPLICATION_ID,
LAST_RECORD_KEY,
ACTION_FLAG
)
SELECT
sq_Application.APPLICATION_ID /* APPLICATION_ID */,
sq_Application.LAST_RECORD_KEY /* LAST_RECORD_KEY */,
sq_Application.ACTION_FLAG /* ACTION_FLAG */
FROM
sq_Application;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );


INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );


-- PIPELINE END FOR 1
---COMMENTED BY OAS---
/*
--post node line Post SQL for sc_tgt_WrkIncApplTransDay
V_STEP_NAME    := ''Post_SQL - UPDATE ETL_APPLICATION_METADATA'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

-- Component sc_tgt_WrkIncApplTransDay, Type Post SQL 
 UPDATE UTIL.ETL_APPLICATION_METADATA
SET METADATA_VALUE= 
  (SELECT NVL(MAX(BATCH_ID),-1)
  FROM UTIL.ETL_BATCH_LOG
  WHERE APPLICATION=''$MP_D_AGT_ISID''
  AND BATCH_STATUS =''COMPLETE''
  ) 
WHERE APPLICATION='':V_MP_D_AGT_CONFDIMENSIONS''
AND METADATA_DESC='':V_MP_D_AGT_MetadataDesc''
AND METADATA_TYPE='':V_MP_D_AGT_MetadataType'';

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );


INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );
*/
---COMMENTED BY OAS---
-- PIPELINE START FOR 2


--pre node line TARGET for sc_tgt_WrkIncApplTransDayUpdate
V_STEP_NAME    := ''TARGET - MERGE wrk_inc_appl_trans_day'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;



MERGE INTO BDR_DM.wrk_inc_appl_trans_day glr USING (
    SELECT
        application_id,
        MAX(last_record_key) last_record_key
    FROM
        (
            SELECT
                ggrphy_allcols.application_id,
                MAX(atd.f_appl_trans_day_sk) last_record_key
            FROM
                (
                    SELECT
                        application_id application_id,
                        last_record_key last_record_key,
                        MAX(appl_receipt_date) appl_receipt_date,
                        MAX(adjudication_date) adjudication_date,
                        MAX(adjudication_cd_id) adjudication_cd_id,
                        MAX(requested_effective_date) requested_effective_date,
                        MAX(insured_plan_effective_date) insured_plan_effective_date,
                        MAX(plan_request_1) plan_request_1,
                        MAX(plan_request_2) plan_request_2,
                        MAX(rider_request_1) rider_request_1,
                        MAX(rider_request_2) rider_request_2,
                        MAX(rider_request_3) rider_request_3,
                        MAX(rider_request_4) rider_request_4,
                        MAX(appl_actor_id) appl_actor_id,
                        MAX(appl_channel_id) appl_channel_id,
                        MAX(appl_mechanism_id) appl_mechanism_id,
                        MAX(geography_xref_key) geography_xref_key,
						MAX(appl_vendor_id) appl_vendor_id,
						MAX(AGT_SEL_D_AGT_SK) AGT_SEL_D_AGT_SK,
					    MAX(AGT_WRT_D_AGT_SK) AGT_WRT_D_AGT_SK,
						MAX(AGT_REF_D_AGT_SK) AGT_REF_D_AGT_SK
                    FROM
                        (
                            SELECT
                                cap.application_id,
                                glr.last_record_key,
                                to_number(TO_CHAR(cap.appl_receipt_date,''YYYYMMDD'')) appl_receipt_date,
                                CASE
                                        WHEN cap.adjudication_cd = ''P'' THEN -1
                                        WHEN cap.adjudication_cd <> ''P''
                                             AND cap.adjudication_date IS NULL THEN to_number(TO_CHAR(cap.last_modified_date,''YYYYMMDD''))
                                        ELSE nvl(to_number(TO_CHAR(cap.adjudication_date,''YYYYMMDD'')),-1)
                                    END
                                adjudication_date,
                                CASE
                                        WHEN cap.adjudication_cd = ''A'' THEN 1
                                        WHEN cap.adjudication_cd = ''D'' THEN 2
                                        WHEN cap.adjudication_cd = ''P'' THEN 3
                                        WHEN cap.adjudication_cd = ''W'' THEN 4
                                        ELSE -1
                                    END
                                adjudication_cd_id,
                                nvl(to_number(TO_CHAR(cap.requested_effective_date,''YYYYMMDD'')),-1) requested_effective_date,
                                nvl(to_number(TO_CHAR(cap.insured_plan_effective_date,''YYYYMMDD'')),-1) insured_plan_effective_date,
                                nvl(cap.plan_request_1,''XXX'') plan_request_1,
                                nvl(cap.plan_request_2,''XXX'') plan_request_2,
                                nvl(cap.rider_request_1,''XXX'') rider_request_1,
                                nvl(cap.rider_request_2,''XXX'') rider_request_2,
                                nvl(cap.rider_request_3,''XXX'') rider_request_3,
                                nvl(cap.rider_request_4,''XXX'') rider_request_4,
                                nvl(cap.appl_actor_id,-1) appl_actor_id,
                                nvl(cap.appl_channel_id,-1) appl_channel_id,
                                nvl(cap.appl_mechanism_id,-1) appl_mechanism_id,
                                NULL AS geography_xref_key,
								nvl(EXT_VEND.D_EXTR_OLE_VEND_SK,-2) appl_vendor_id,
								case when NVL(wawr.AGT_WRT_D_AGT_SK,-1) = -1 and NVL(wara.AGT_REF_D_AGT_SK,-2) <> -2 then -2 else NVL(wawr.AGT_WRT_D_AGT_SK,-1) end  AS AGT_WRT_D_AGT_SK ,
								case when NVL(wasa.AGT_SEL_D_AGT_SK,-1) = -1 and NVL(wara.AGT_REF_D_AGT_SK,-2) <> -2 then -2 else NVL(wasa.AGT_SEL_D_AGT_SK,-1)  end AS AGT_SEL_D_AGT_SK ,
								NVL(wara.AGT_REF_D_AGT_SK,-2) AGT_REF_D_AGT_SK
                            FROM
                                SRC_COMPAS_D.application cap
                                INNER JOIN bdr_dm.wrk_inc_appl_trans_day glr ON cap.application_id = glr.application_id
                                                                            AND glr.action_flag = ''OLD''
								LEFT JOIN  bdr_dm.D_EXTR_OLE_VEND EXT_VEND ON EXT_VEND.VEND_CD=cap.vendor_code
								LEFT  JOIN bdr_DM.WRK_APPL_WRITING_AGENT wawr ON wawr.application_id=cap.application_id
								LEFT  JOIN BDR_DM.WRK_APPL_SELLING_AGENT wasa ON wasa.application_id=cap.application_id
								LEFT  JOIN BDR_DM.WRK_APPL_REFERRAL_AGENT wara ON wara.application_id=cap.application_id
								
                            UNION
                            SELECT
                                app.application_id,
                                glr.last_record_key,
                                NULL AS appl_receipt_date,
                                NULL AS adjudication_date,
                                NULL AS adjudication_cd_id,
                                NULL AS requested_effective_date,
                                NULL AS insured_plan_effective_date,
                                NULL AS plan_request_1,
                                NULL AS plan_request_2,
                                NULL AS rider_request_1,
                                NULL AS rider_request_2,
                                NULL AS rider_request_3,
                                NULL AS rider_request_4,
                                NULL AS appl_actor_id,
                                NULL AS appl_channel_id,
                                NULL AS appl_mechanism_id,
                                CASE
                                        WHEN usstzip.d_geo_xref_sk IS NOT NULL THEN usstzip.d_geo_xref_sk
                                        WHEN allstzip.d_geo_xref_sk IS NOT NULL THEN allstzip.d_geo_xref_sk
                                        WHEN usst.d_geo_xref_sk IS NOT NULL THEN usst.d_geo_xref_sk
                                        WHEN allunq.d_geo_xref_sk IS NOT NULL THEN allunq.d_geo_xref_sk
                                        WHEN uszip.d_geo_xref_sk IS NOT NULL THEN uszip.d_geo_xref_sk
                                        ELSE -1
                                    END
                                AS geography_xref_key,
								NULL AS appl_vendor_id,
								NULL AS AGT_WRT_D_AGT_SK,
								NULL AS AGT_SEL_D_AGT_SK,
								NULL AS  AGT_REF_D_AGT_SK
                            FROM
                                SRC_COMPAS_D.application app
                                INNER JOIN bdr_dm.wrk_inc_appl_trans_day glr ON app.application_id = glr.application_id
                                                                            AND glr.action_flag = ''OLD''
                                LEFT OUTER JOIN (
                                    SELECT
                                        zip_cd,
                                        d_st_cd,
                                        d_cntry_cd,
                                        cnty_cd,
                                        d_geo_xref_sk
                                    FROM
                                        bdr_conf.d_geo_xref
																
WHERE
                                        d_cntry_cd = ''US''
                                ) usstzip ON app.state_cd = usstzip.d_st_cd
                                             AND substr(app.zip_cd,1,5) = usstzip.zip_cd
                                LEFT OUTER JOIN (
                                    SELECT
                                        zip_cd,
                                        d_st_cd,
                                        d_cntry_cd,
                                        cnty_cd,
                                        d_geo_xref_sk
                                    FROM
                                        bdr_conf.d_geo_xref
                                ) allstzip ON app.state_cd = allstzip.d_st_cd
                                              AND app.zip_cd = allstzip.zip_cd
                                LEFT OUTER JOIN (
                                    SELECT
                                        zip_cd,
                                        d_st_cd,
                                        d_cntry_cd,
                                        cnty_cd,
                                        d_geo_xref_sk
                                    FROM
                                        bdr_conf.d_geo_xref
																
WHERE
                                        d_cntry_cd = ''US''
                                        AND zip_cd = ''99999''
                                ) usst ON app.state_cd = usst.d_st_cd
                                LEFT OUTER JOIN (
                                    SELECT
                                        *
                                    FROM
                                        (
                                            SELECT
                                                zip_cd,
                                                d_st_cd,
                                                d_cntry_cd,
                                                cnty_cd,
                                                d_geo_xref_sk,
                                                COUNT(1) OVER(
                                                    PARTITION BY zip_cd
                                                ) AS cnt
                                            FROM
                                                bdr_conf.d_geo_xref
                                        )
																
WHERE
                                        cnt = 1
                                ) allunq ON app.state_cd = allunq.d_st_cd
                                            AND substr(app.zip_cd,1,5) = allunq.zip_cd
                                LEFT OUTER JOIN (
                                    SELECT
                                        zip_cd,
                                        d_st_cd,
                                        d_cntry_cd,
                                        cnty_cd,
                                        d_geo_xref_sk
                                    FROM
                                        bdr_conf.d_geo_xref
																
WHERE
                                        d_cntry_cd = ''US''
                                        AND cnty_cd <>-1
                                        AND cty IS NOT NULL
                                ) uszip ON substr(app.zip_cd,1,5) = uszip.zip_cd
                        ) ggrphy_allcols
                    GROUP BY
                        application_id,
                        last_record_key
                ) ggrphy_allcols
                INNER JOIN bdr_dm.f_appl_trans_day atd ON ggrphy_allcols.application_id = atd.appl_id
                                                      AND ggrphy_allcols.last_record_key = atd.f_appl_trans_day_sk
										
WHERE
                (
                    atd.appl_recpt_dt_id <> ggrphy_allcols.appl_receipt_date
                    OR nvl(atd.appl_adjd_dt_id,-1) <> ggrphy_allcols.adjudication_date
                    OR atd.d_adjd_cd_sk <> ggrphy_allcols.adjudication_cd_id
                    OR nvl(atd.req_eff_dt_id,-1) <> ggrphy_allcols.requested_effective_date
                    OR nvl(atd.insd_pln_eff_dt_id,-1) <> ggrphy_allcols.insured_plan_effective_date
                    OR nvl(atd.pln_req_1,''XXX'') <> ggrphy_allcols.plan_request_1
                    OR nvl(atd.pln_req_2,''XXX'') <> ggrphy_allcols.plan_request_2
                    OR nvl(atd.ride_req_1,''XXX'') <> ggrphy_allcols.rider_request_1
                    OR nvl(atd.ride_req_2,''XXX'') <> ggrphy_allcols.rider_request_2
                    OR nvl(atd.ride_req_3,''XXX'') <> ggrphy_allcols.rider_request_3
                    OR nvl(atd.ride_req_4,''XXX'') <> ggrphy_allcols.rider_request_4
                    OR atd.d_appl_actor_sk <> ggrphy_allcols.appl_actor_id
					OR atd.D_EXTR_OLE_VEND_SK <> ggrphy_allcols.appl_vendor_id
                    OR
                    CASE
                            WHEN atd.d_appl_cntc_typ_sk = 1 THEN 12
                            WHEN atd.d_appl_cntc_typ_sk = 2 THEN 1
                            WHEN atd.d_appl_cntc_typ_sk = 3 THEN 10
                            WHEN atd.d_appl_cntc_typ_sk = 4 THEN 3
                            ELSE -1
                        END
                    <> ggrphy_allcols.appl_channel_id
                    OR atd.d_appl_mech_sk <> ggrphy_allcols.appl_mechanism_id
                    OR atd.d_geo_xref_sk <> ggrphy_allcols.geography_xref_key
					OR   atd.AGT_SEL_D_AGT_SK <> ggrphy_allcols.AGT_SEL_D_AGT_SK
					OR   atd.AGT_WRT_D_AGT_SK <> ggrphy_allcols.AGT_WRT_D_AGT_SK
					OR   atd.AGT_REF_D_AGT_SK <> ggrphy_allcols.AGT_REF_D_AGT_SK
                )
            GROUP BY
                ggrphy_allcols.application_id
            UNION
            SELECT
                atd.appl_id,
                MAX(atd.f_appl_trans_day_sk)
            FROM
                bdr_dm.f_appl_trans_day atd
                LEFT OUTER JOIN bdr_dm.wrk_acquisitionchannel wac ON atd.appl_id = wac.applicationid
                LEFT OUTER JOIN bdr_conf.d_acqn_chnl dac ON wac.acquisitionchannel = dac.acqn_chnl_lvl_3
										
WHERE
                atd.APPL_RECPT_DT_ID   > TO_CHAR(ADD_MONTHS(TRUNC(SYSDATE(),''YEAR''),-12 * 9),''YYYYMMDD'')
				 AND atd.curr_row_flg = ''Y''
                AND nvl(dac.d_acqn_chnl_sk,-1) != atd.d_acqn_chnl_sk				
            GROUP BY
                atd.appl_id
UNION
            SELECT
                atd.appl_id,
                MAX(atd.f_appl_trans_day_sk)
            FROM
                bdr_dm.f_appl_trans_day atd
                LEFT OUTER JOIN  BDR_DM.WRK_SALE_CHANNEL wan ON atd.appl_id = wan.applicationid
                LEFT OUTER JOIN bdr_conf.d_sale_chnl dan 
				ON  dan.SALE_CHNL_LVL_1 = wan.SALE_CHANNEL_LEVEL_1
                AND dan.SALE_CHNL_LVL_2 = wan.SALE_CHANNEL_LEVEL_2
                AND dan.SALE_CHNL_LVL_3 = wan.SALE_CHANNEL_LEVEL_3
										
WHERE
                atd.APPL_RECPT_DT_ID   > TO_CHAR(ADD_MONTHS(TRUNC(SYSDATE(),''YEAR''),-12 * 9),''YYYYMMDD'')
				 AND atd.curr_row_flg = ''Y''
                AND nvl(dan.D_SALE_CHNL_SK,-1) != atd.D_SALE_CHNL_SK				
            GROUP BY
                atd.appl_id
        )
    GROUP BY
        application_id
)
updt_qlfd ON ( updt_qlfd.application_id = glr.application_id )
WHEN MATCHED THEN UPDATE SET glr.action_flag = ''UPDATE''
WHEN NOT MATCHED THEN INSERT (
    application_id,
    last_record_key,
    action_flag ) VALUES (
    updt_qlfd.application_id,
    updt_qlfd.last_record_key,
''UPDATE'' );

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

V_ROWS_UPDATED := (SELECT $2 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );


INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );


-- PIPELINE END FOR 2

CALL UTIL.SP_ETL_CHECK_CONSTRAINTS(:DB_NAME , :APPLICATION , :WORKFLOW_NAME , :OBJECT_NAME , :V_BATCH_ID );

UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''COMPLETE'', ERROR_MSG = null, BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
;
UPDATE  UTIL.ETL_BATCH_OBJECT_INCR_VALU SET INCR_COLUMN_VALUE = :V_BATCH_ID, LST_MOD_DT = CURRENT_TIMESTAMP() 
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID''
;

EXCEPTION

WHEN OTHER THEN

UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''ERROR'', ERROR_MSG = :SQLERRM,  BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
;

INSERT INTO  UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ERROR_MSG, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''ERROR'', :V_STEP_NAME, :V_STEP_SEQ, :SQLERRM, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() )
;



RAISE;

END;

';