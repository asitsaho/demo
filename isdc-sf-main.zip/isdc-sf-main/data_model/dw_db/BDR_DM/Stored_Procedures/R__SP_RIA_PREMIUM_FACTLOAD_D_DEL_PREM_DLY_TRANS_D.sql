USE SCHEMA BDR_DM; CREATE OR REPLACE PROCEDURE "SP_RIA_PREMIUM_FACTLOAD_D_DEL_PREM_DLY_TRANS_D"("DB_NAME" VARCHAR(16777216), "APPLICATION" VARCHAR(16777216), "WORKFLOW_NAME" VARCHAR(16777216), "OBJECT_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '

-- Original workflow: wkf_RIA_Premium_Factload_IXL_TargetLoad_D
-- Original mapping: m_RIA_Premium_FactLoad_D_TempPremDelTrans_D
-- Original folder: Premium
-- Original filename: wkf_RIA_Premium_Factload_IXL_TargetLoad_D.XML

DECLARE


V_ROWS_INSERTED  INTEGER;
V_ROWS_UPDATED INTEGER;
V_ROWS_DELETED INTEGER;
V_LAST_QUERY_ID VARCHAR;

V_WH VARCHAR;
V_BATCH_ID INTEGER;


V_BATCH_OBJECT_START_TIME VARCHAR;
V_STEP_START_TIME    VARCHAR;
V_STEP_NAME VARCHAR;
V_STEP_SEQ INTEGER DEFAULT 0;
V_ETL_LST_BTCH_ID INTEGER;

BEGIN

EXECUTE IMMEDIATE ''USE DATABASE ''||:DB_NAME; 

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_BATCH_OBJECT_START_TIME := (SELECT CURRENT_TIMESTAMP());



LET res1 RESULTSET := 
(

SELECT 

WH ,
BATCH_ID
  
FROM UTIL.ETL_BATCH_OBJECT_CONTROL
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
FETCH FIRST 1 ROW ONLY

)
;


LET C1 CURSOR FOR res1;
open C1;
FETCH C1 into  V_WH,V_BATCH_ID ;
close C1;


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:V_WH;

USE SCHEMA BDR_DM;	  

INSERT INTO UTIL.ETL_BATCH_OBJECT_INCR_VALU (APPLICATION, WORKFLOW_NAME, OBJECT_NAME, INCR_COLUMN, INCR_COLUMN_VALUE )
SELECT * FROM (select :APPLICATION AS APPLICATION, :WORKFLOW_NAME AS WORKFLOW_NAME, :OBJECT_NAME AS OBJECT_NAME, ''ETL_LST_BTCH_ID'' AS INCR_COLUMN, -1 AS INCR_COLUMN_VALUE) A
WHERE NOT EXISTS (SELECT 1 FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU B WHERE B.APPLICATION = A.APPLICATION AND B.WORKFLOW_NAME = A.WORKFLOW_NAME AND B.OBJECT_NAME = A.OBJECT_NAME AND B.INCR_COLUMN = A.INCR_COLUMN)
;

V_ETL_LST_BTCH_ID :=(SELECT INCR_COLUMN_VALUE FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID'');

-----------------Step1

V_STEP_NAME    := ''TARGET - TRUNCATE BDR_DM.TEMP_DUPS_CHANGE_TRANS'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;
 
  EXECUTE IMMEDIATE ''truncate table BDR_DM.TEMP_DUPS_CHANGE_TRANS'';
 
INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

---------------Step2

V_STEP_NAME    := ''TARGET - INSERT BDR_DM.TEMP_DUPS_CHANGE_TRANS'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;


        INSERT INTO BDR_DM.TEMP_DUPS_CHANGE_TRANS (ROW_ID,
                                           OLD_HOUSEHOLD_ID,
                                           NEW_HOUSEHOLD_ID,
                                           INDIVIDUAL_ID,
                                           OLD_INS_PLAN_BILLING_BUCKET_ID,
                                           NEW_INS_PLAN_BILLING_BUCKET_ID,
                                           INSURED_PLAN_ID,
                                           OLD_HOUSEHOLD_ADDRESS_ID,
                                           NEW_HOUSEHOLD_ADDRESS_ID,
                                           PREMIUM_DUE_DATE,
                                           OLD_ACTIVITY_DATE,
                                           NEW_ACTIVITY_DATE,
                                           OLD_PAID_CERT,
                                           NEW_PAID_CERT,
                                           OLD_DEL_CERT,
                                           NEW_DEL_CERT,
                                           OLD_TERM_CERT,
                                           NEW_TERM_CERT,
                                           OLD_PAID_PREMIUM_AMT,
                                           NEW_PAID_PREMIUM_AMT,
                                           OLD_DELINQUENT_PREMIUM_DUE_AMT,
                                           NEW_DELINQUENT_PREMIUM_DUE_AMT,
                                           OLD_PLAN_CD,
                                           NEW_PLAN_CD,
                                           OLD_BENEFIT_MOD_CATEGORY_ID,
                                           NEW_BENEFIT_MOD_CATEGORY_ID,
                                           OLD_INSURED_PLAN_EFF_DATE,
                                           NEW_INSURED_PLAN_EFF_DATE,
                                           OLD_INSURED_PLAN_TERM_DATE,
                                           NEW_INSURED_PLAN_TERM_DATE,
                                           OLD_CERT_TERMINATION_DATE,
                                           NEW_CERT_TERMINATION_DATE,
                                           OLD_STATE_CD,
                                           NEW_STATE_CD,
                                           OLD_ZIP_CD,
                                           NEW_ZIP_CD,
                                           OLD_COUNTRY_CD,
                                           NEW_COUNTRY_CD,
                                           OLD_ISSUE_STATE,
                                           NEW_ISSUE_STATE,
                                           OLD_ISSUE_COUNTRY_CD,
                                           NEW_ISSUE_COUNTRY_CD,
                                           OLD_ISSUE_ZIP_CD,
                                           NEW_ISSUE_ZIP_CD,
                                           OLD_GENDER_CD,
                                           NEW_GENDER_CD,
                                           OLD_DATE_OF_BIRTH,
                                           NEW_DATE_OF_BIRTH,
                                           OLD_CERT_ACQN_CHNL_LEVEL3,
                                           NEW_CERT_ACQN_CHNL_LEVEL3,
                                           OLD_ACCOUNT_NUMBER,
                                           NEW_ACCOUNT_NUMBER,
                                           OLD_CERT_ACTV_LVL_3_TXT,
                                           NEW_CERT_ACTV_LVL_3_TXT,
                                           OLD_TERMINATION_REASON_NAME,
                                           NEW_TERMINATION_REASON_NAME,
                                           OLD_CONSERVATION_REASON_NAME,
                                           NEW_CONSERVATION_REASON_NAME,
                                           OLD_PLAN_GROUP,
                                           NEW_PLAN_GROUP,
                                           OLD_PRODUCT_GROUP,
                                           NEW_PRODUCT_GROUP,
                                           OLD_UNDWR_TAG_KEY,
                                           NEW_UNDWR_TAG_KEY,
                                           OLD_PRDCT_EFF_DT,
                                           NEW_PRDCT_EFF_DT,
                                           OLD_PRDCT_ACQN_CHNL_LEVEL3,
                                           NEW_PRDCT_ACQN_CHNL_LEVEL3,
                                           OLD_LEGAL_ENTITY_NAME,
                                           NEW_LEGAL_ENTITY_NAME,
                                           OLD_MBR_PD_PREM_AMT,
                                           NEW_MBR_PD_PREM_AMT,
                                           OLD_MBR_DELQ_PREM_AMT,
                                           NEW_MBR_DELQ_PREM_AMT,
                                           OLD_ER_PD_PREM_AMT,
                                           NEW_ER_PD_PREM_AMT,
                                           OLD_ER_DELQ_PREM_AMT,
                                           NEW_ER_DELQ_PREM_AMT,
                                           OLD_CURRENT_SIGNATURE_DATE,
                                           NEW_CURRENT_SIGNATURE_DATE,
                                           OLD_ORIGINAL_SIGNATURE_DATE,
                                           NEW_ORIGINAL_SIGNATURE_DATE,
                                           OLD_ORIGINAL_INSUREDPLAN_ID,
                                           NEW_ORIGINAL_INSUREDPLAN_ID,
                                           OLD_WRITING_AGENT,
                                           NEW_WRITING_AGENT,
                                           OLD_SELLING_AGENT,
                                           NEW_SELLING_AGENT,
                                           OLD_ORIGINAL_SELLING_AGENT,
                                           NEW_ORIGINAL_SELLING_AGENT,
                                           OLD_RET_TYP_ID,
                                           NEW_RET_TYP_ID,
                                           OLD_ER_SKEY,
                                           NEW_ER_SKEY,
                                           OLD_DCM_INSURED_PLAN_ID,
                                           NEW_DCM_INSURED_PLAN_ID,
                                           OLD_DCM_INSURED_PLAN_EFF_DATE,
                                           NEW_DCM_INSURED_PLAN_EFF_DATE,
                                           OLD_DCM_PLAN_CD,
                                           NEW_DCM_PLAN_CD,
                                           OLD_DCM_SIGNATURE_DATE,
                                           NEW_DCM_SIGNATURE_DATE,
                                           OLD_DCM_WRITING_AGENT,
                                           NEW_DCM_WRITING_AGENT,
                                           OLD_DCM_DERIVED_COMPAS_AGENT,
                                           NEW_DCM_DERIVED_COMPAS_AGENT,
                                           OLD_AGT_WRT_SKEY,
                                           NEW_AGT_WRT_SKEY,
                                           OLD_AGT_SEL_ORIG_SKEY,
                                           NEW_AGT_SEL_ORIG_SKEY,
                                           OLD_AGT_SEL_SKEY,
                                           NEW_AGT_SEL_SKEY,
                                           OLD_AGT_DCM_WRT_SKEY,
                                           NEW_AGT_DCM_WRT_SKEY,
                                           O_D_DSCNT_ANNL_PAYR_SK,
                                           O_D_DSCNT_EFT_SK,
                                           O_D_DSCNT_ERLY_ENRL_SK,
                                           O_D_DSCNT_LNGVTY_SK,
                                           O_D_DSCNT_MULTI_INSD_SK,
                                           O_D_SURCHRG_TBCC_USER_SK,
                                           O_D_SURCHRG_TIER_SK,
                                           O_D_INSD_PLN_PRFL_SK,
                                           O_D_CALC_RT_SK,
                                           O_MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
                                           O_DSCNT_PD_ANNL_PAYR_AMT,
                                           O_DSCNT_PD_EFT_AMT,
                                           O_DSCNT_PD_ERLY_ENRL_AMT,
                                           O_DSCNT_PD_LNGVTY_AMT,
                                           O_DSCNT_PD_MULTI_INSD_AMT,
                                           O_SURCHRG_PD_TBCC_USER_AMT,
                                           O_SURCHRG_PD_TIER_AMT,
                                           O_DSCNT_DELQ_ANNL_PAYR_AMT,
                                           O_DSCNT_DELQ_EFT_AMT,
                                           O_DSCNT_DELQ_ERLY_ENRL_AMT,
                                           O_DSCNT_DELQ_LNGVTY_AMT,
                                           O_DSCNT_DELQ_MULTI_INSD_AMT,
                                           O_SURCHRG_DELQ_TBCC_USER_AMT,
                                           O_SURCHRG_DELQ_TIER_AMT,
                                           N_D_DSCNT_ANNL_PAYR_SK,
                                           N_D_DSCNT_EFT_SK,
                                           N_D_DSCNT_ERLY_ENRL_SK,
                                           N_D_DSCNT_LNGVTY_SK,
                                           N_D_DSCNT_MULTI_INSD_SK,
                                           N_D_SURCHRG_TBCC_USER_SK,
                                           N_D_SURCHRG_TIER_SK,
                                           N_D_INSD_PLN_PRFL_SK,
                                           N_D_CALC_RT_SK,
                                           N_MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
                                           N_DSCNT_PD_ANNL_PAYR_AMT,
                                           N_DSCNT_PD_EFT_AMT,
                                           N_DSCNT_PD_ERLY_ENRL_AMT,
                                           N_DSCNT_PD_LNGVTY_AMT,
                                           N_DSCNT_PD_MULTI_INSD_AMT,
                                           N_SURCHRG_PD_TBCC_USER_AMT,
                                           N_SURCHRG_PD_TIER_AMT,
                                           N_DSCNT_DELQ_ANNL_PAYR_AMT,
                                           N_DSCNT_DELQ_EFT_AMT,
                                           N_DSCNT_DELQ_ERLY_ENRL_AMT,
                                           N_DSCNT_DELQ_LNGVTY_AMT,
                                           N_DSCNT_DELQ_MULTI_INSD_AMT,
                                           N_SURCHRG_DELQ_TBCC_USER_AMT,
                                           N_SURCHRG_DELQ_TIER_AMT,
                                           O_ORIGINAL_REFERRAL_AGENT,
                                           N_ORIGINAL_REFERRAL_AGENT,
                                           O_REFERRAL_AGENT,
                                           N_REFERRAL_AGENT,
                                           O_AGT_REF_ORIG_D_AGT_SK,
                                           N_AGT_REF_ORIG_D_AGT_SK,
                                           O_AGT_REF_D_AGT_SK,
                                           N_AGT_REF_D_AGT_SK,
                                           O_D_MBR_INFO_SK,
                                           N_D_MBR_INFO_SK,
                                           O_D_PLN_BEN_MOD_SK,
                                           N_D_PLN_BEN_MOD_SK,
                                           O_RES_D_GEO_XREF_SK,
                                           N_RES_D_GEO_XREF_SK,
                                           O_PLN_ISS_D_GEO_XREF_SK,
                                           N_PLN_ISS_D_GEO_XREF_SK,
                                           O_D_RTNG_AREA_SK,
                                           N_D_RTNG_AREA_SK,
                                           O_F_APPL_TRANS_DAY_SK,
                                           N_F_APPL_TRANS_DAY_SK,
                                           O_CERT_SALE_CHNL_LVL_1,
                                           N_CERT_SALE_CHNL_LVL_1,
                                           O_CERT_SALE_CHNL_LVL_2,
                                           N_CERT_SALE_CHNL_LVL_2,
                                           O_CERT_SALE_CHNL_LVL_3,
                                           N_CERT_SALE_CHNL_LVL_3,
                                           O_PRDCT_SALE_CHNL_LVL_1,
                                           N_PRDCT_SALE_CHNL_LVL_1,
                                           O_PRDCT_SALE_CHNL_LVL_2,
                                           N_PRDCT_SALE_CHNL_LVL_2,
                                           O_PRDCT_SALE_CHNL_LVL_3,
                                           N_PRDCT_SALE_CHNL_LVL_3,
                                           O_D_NEW_TO_MEDCR_SK,
                                           O_DSCNT_PD_NEW_TO_MEDCR_AMT,
                                           O_DSCNT_DLQNT_NEW_TO_MEDCR_AMT,
                                           N_D_NEW_TO_MEDCR_SK,
                                           N_DSCNT_PD_NEW_TO_MEDCR_AMT,
                                           N_DSCNT_DLQNT_NEW_TO_MEDCR_AMT,
                                           O_D_UNDWR_GUID_SK,
                                           N_D_UNDWR_GUID_SK,
                                           O_D_AGT_POL_SK,
                                           N_D_AGT_POL_SK,
                                           N_PRO_RATED_CREDIT,
                                           O_PRO_RATED_CREDIT,
                                           N_ENT_AGE_EFFDT,
                                           O_ENT_AGE_EFFDT)
        (SELECT ROWID
                    ROW_ID,
                OLD_HOUSEHOLD_ID,
                NEW_HOUSEHOLD_ID,
                INDIVIDUAL_ID,
                OLD_INS_PLAN_BILLING_BUCKET_ID,
                NEW_INS_PLAN_BILLING_BUCKET_ID,
                INSURED_PLAN_ID,
                OLD_HOUSEHOLD_ADDRESS_ID,
                NEW_HOUSEHOLD_ADDRESS_ID,
                PREMIUM_DUE_DATE,
                OLD_ACTIVITY_DATE,
                NEW_ACTIVITY_DATE,
                NVL (OLD_PAID_CERT, 0) * -1
                    OLD_PAID_CERT,
                NEW_PAID_CERT,
                NVL (OLD_DEL_CERT, 0) * -1
                    OLD_DEL_CERT,
                NEW_DEL_CERT,
                NVL (OLD_TERM_CERT, 0) * -1
                    OLD_TERM_CERT,
                NEW_TERM_CERT,
                NVL (OLD_PAID_PREMIUM_AMT, 0) * -1
                    OLD_PAID_PREMIUM_AMT,
                NEW_PAID_PREMIUM_AMT,
                NVL (OLD_DELINQUENT_PREMIUM_DUE_AMT, 0) * -1
                    OLD_DELINQUENT_PREMIUM_DUE_AMT,
                NEW_DELINQUENT_PREMIUM_DUE_AMT,
                OLD_PLAN_CD,
                NEW_PLAN_CD,
                OLD_BENEFIT_MOD_CATEGORY_ID,
                NEW_BENEFIT_MOD_CATEGORY_ID,
                OLD_INSURED_PLAN_EFF_DATE,
                NEW_INSURED_PLAN_EFF_DATE,
                OLD_INSURED_PLAN_TERM_DATE,
                NEW_INSURED_PLAN_TERM_DATE,
                OLD_CERT_TERMINATION_DATE,
                NEW_CERT_TERMINATION_DATE,
                OLD_STATE_CD,
                NEW_STATE_CD,
                OLD_ZIP_CD,
                NEW_ZIP_CD,
                OLD_COUNTRY_CD,
                NEW_COUNTRY_CD,
                OLD_ISSUE_STATE,
                NEW_ISSUE_STATE,
                OLD_ISSUE_COUNTRY_CD,
                NEW_ISSUE_COUNTRY_CD,
                OLD_ISSUE_ZIP_CD,
                NEW_ISSUE_ZIP_CD,
                OLD_GENDER_CD,
                NEW_GENDER_CD,
                OLD_DATE_OF_BIRTH,
                NEW_DATE_OF_BIRTH,
                OLD_CERT_ACQN_CHNL_LEVEL3,
                NEW_CERT_ACQN_CHNL_LEVEL3,
                OLD_ACCOUNT_NUMBER,
                NEW_ACCOUNT_NUMBER,
                OLD_CERT_ACTV_LVL_3_TXT,
                NEW_CERT_ACTV_LVL_3_TXT,
                OLD_TERMINATION_REASON_NAME,
                NEW_TERMINATION_REASON_NAME,
                OLD_CONSERVATION_REASON_NAME,
                NEW_CONSERVATION_REASON_NAME,
                OLD_PLAN_GROUP,
                NEW_PLAN_GROUP,
                OLD_PRODUCT_GROUP,
                NEW_PRODUCT_GROUP,
                OLD_UNDWR_TAG_KEY,
                NEW_UNDWR_TAG_KEY,
                OLD_PRDCT_EFF_DT,
                NEW_PRDCT_EFF_DT,
                OLD_PRDCT_ACQN_CHNL_LEVEL3,
                NEW_PRDCT_ACQN_CHNL_LEVEL3,
                OLD_LEGAL_ENTITY_NAME,
                NEW_LEGAL_ENTITY_NAME,
                NVL (OLD_MBR_PD_PREM_AMT, 0) * -1
                    OLD_MBR_PD_PREM_AMT,
                NEW_MBR_PD_PREM_AMT,
                NVL (OLD_MBR_DELQ_PREM_AMT, 0) * -1
                    OLD_MBR_DELQ_PREM_AMT,
                NEW_MBR_DELQ_PREM_AMT,
                NVL (OLD_ER_PD_PREM_AMT, 0) * -1
                    OLD_ER_PD_PREM_AMT,
                NEW_ER_PD_PREM_AMT,
                NVL (OLD_ER_DELQ_PREM_AMT, 0) * -1
                    OLD_ER_DELQ_PREM_AMT,
                NEW_ER_DELQ_PREM_AMT,
                OLD_CURRENT_SIGNATURE_DATE,
                NEW_CURRENT_SIGNATURE_DATE,
                OLD_ORIGINAL_SIGNATURE_DATE,
                NEW_ORIGINAL_SIGNATURE_DATE,
                OLD_ORIGINAL_INSUREDPLAN_ID,
                NEW_ORIGINAL_INSUREDPLAN_ID,
                OLD_WRITING_AGENT,
                NEW_WRITING_AGENT,
                OLD_SELLING_AGENT,
                NEW_SELLING_AGENT,
                OLD_ORIGINAL_SELLING_AGENT,
                NEW_ORIGINAL_SELLING_AGENT,
                OLD_RET_TYP_ID,
                NEW_RET_TYP_ID,
                OLD_ER_SKEY,
                NEW_ER_SKEY,
                OLD_DCM_INSURED_PLAN_ID,
                NEW_DCM_INSURED_PLAN_ID,
                OLD_DCM_INSURED_PLAN_EFF_DATE,
                NEW_DCM_INSURED_PLAN_EFF_DATE,
                OLD_DCM_PLAN_CD,
                NEW_DCM_PLAN_CD,
                OLD_DCM_SIGNATURE_DATE,
                NEW_DCM_SIGNATURE_DATE,
                OLD_DCM_WRITING_AGENT,
                NEW_DCM_WRITING_AGENT,
                OLD_DCM_DERIVED_COMPAS_AGENT,
                NEW_DCM_DERIVED_COMPAS_AGENT,
                OLD_AGT_WRT_SKEY,
                NEW_AGT_WRT_SKEY,
                OLD_AGT_SEL_ORIG_SKEY,
                NEW_AGT_SEL_ORIG_SKEY,
                OLD_AGT_SEL_SKEY,
                NEW_AGT_SEL_SKEY,
                OLD_AGT_DCM_WRT_SKEY,
                NEW_AGT_DCM_WRT_SKEY,
                O_D_DSCNT_ANNL_PAYR_SK,
                O_D_DSCNT_EFT_SK,
                O_D_DSCNT_ERLY_ENRL_SK,
                O_D_DSCNT_LNGVTY_SK,
                O_D_DSCNT_MULTI_INSD_SK,
                O_D_SURCHRG_TBCC_USER_SK,
                O_D_SURCHRG_TIER_SK,
                O_D_INSD_PLN_PRFL_SK,
                O_D_CALC_RT_SK,
                O_MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
                NVL (O_DSCNT_PD_ANNL_PAYR_AMT, 0) * -1
                    O_DSCNT_PD_ANNL_PAYR_AMT,
                NVL (O_DSCNT_PD_EFT_AMT, 0) * -1
                    O_DSCNT_PD_EFT_AMT,
                NVL (O_DSCNT_PD_ERLY_ENRL_AMT, 0) * -1
                    O_DSCNT_PD_ERLY_ENRL_AMT,
                NVL (O_DSCNT_PD_LNGVTY_AMT, 0) * -1
                    O_DSCNT_PD_LNGVTY_AMT,
                NVL (O_DSCNT_PD_MULTI_INSD_AMT, 0) * -1
                    O_DSCNT_PD_MULTI_INSD_AMT,
                NVL (O_SURCHRG_PD_TBCC_USER_AMT, 0) * -1
                    O_SURCHRG_PD_TBCC_USER_AMT,
                NVL (O_SURCHRG_PD_TIER_AMT, 0) * -1
                    O_SURCHRG_PD_TIER_AMT,
                NVL (O_DSCNT_DELQ_ANNL_PAYR_AMT, 0) * -1
                    O_DSCNT_DELQ_ANNL_PAYR_AMT,
                NVL (O_DSCNT_DELQ_EFT_AMT, 0) * -1
                    O_DSCNT_DELQ_EFT_AMT,
                NVL (O_DSCNT_DELQ_ERLY_ENRL_AMT, 0) * -1
                    O_DSCNT_DELQ_ERLY_ENRL_AMT,
                NVL (O_DSCNT_DELQ_LNGVTY_AMT, 0) * -1
                    O_DSCNT_DELQ_LNGVTY_AMT,
                NVL (O_DSCNT_DELQ_MULTI_INSD_AMT, 0) * -1
                    O_DSCNT_DELQ_MULTI_INSD_AMT,
                NVL (O_SURCHRG_DELQ_TBCC_USER_AMT, 0) * -1
                    O_SURCHRG_DELQ_TBCC_USER_AMT,
                NVL (O_SURCHRG_DELQ_TIER_AMT, 0) * -1
                    O_SURCHRG_DELQ_TIER_AMT,
                N_D_DSCNT_ANNL_PAYR_SK,
                N_D_DSCNT_EFT_SK,
                N_D_DSCNT_ERLY_ENRL_SK,
                N_D_DSCNT_LNGVTY_SK,
                N_D_DSCNT_MULTI_INSD_SK,
                N_D_SURCHRG_TBCC_USER_SK,
                N_D_SURCHRG_TIER_SK,
                N_D_INSD_PLN_PRFL_SK,
                N_D_CALC_RT_SK,
                N_MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
                N_DSCNT_PD_ANNL_PAYR_AMT,
                N_DSCNT_PD_EFT_AMT,
                N_DSCNT_PD_ERLY_ENRL_AMT,
                N_DSCNT_PD_LNGVTY_AMT,
                N_DSCNT_PD_MULTI_INSD_AMT,
                N_SURCHRG_PD_TBCC_USER_AMT,
                N_SURCHRG_PD_TIER_AMT,
                N_DSCNT_DELQ_ANNL_PAYR_AMT,
                N_DSCNT_DELQ_EFT_AMT,
                N_DSCNT_DELQ_ERLY_ENRL_AMT,
                N_DSCNT_DELQ_LNGVTY_AMT,
                N_DSCNT_DELQ_MULTI_INSD_AMT,
                N_SURCHRG_DELQ_TBCC_USER_AMT,
                N_SURCHRG_DELQ_TIER_AMT,
                O_ORIGINAL_REFERRAL_AGENT,
                N_ORIGINAL_REFERRAL_AGENT,
                O_REFERRAL_AGENT,
                N_REFERRAL_AGENT,
                O_AGT_REF_ORIG_D_AGT_SK,
                N_AGT_REF_ORIG_D_AGT_SK,
                O_AGT_REF_D_AGT_SK,
                N_AGT_REF_D_AGT_SK,
                O_D_MBR_INFO_SK,
                N_D_MBR_INFO_SK,
                O_D_PLN_BEN_MOD_SK,
                N_D_PLN_BEN_MOD_SK,
                O_RES_D_GEO_XREF_SK,
                N_RES_D_GEO_XREF_SK,
                O_PLN_ISS_D_GEO_XREF_SK,
                N_PLN_ISS_D_GEO_XREF_SK,
                O_D_RTNG_AREA_SK,
                N_D_RTNG_AREA_SK,
                O_F_APPL_TRANS_DAY_SK,
                N_F_APPL_TRANS_DAY_SK,
                O_CERT_SALE_CHNL_LVL_1,
                N_CERT_SALE_CHNL_LVL_1,
                O_CERT_SALE_CHNL_LVL_2,
                N_CERT_SALE_CHNL_LVL_2,
                O_CERT_SALE_CHNL_LVL_3,
                N_CERT_SALE_CHNL_LVL_3,
                O_PRDCT_SALE_CHNL_LVL_1,
                N_PRDCT_SALE_CHNL_LVL_1,
                O_PRDCT_SALE_CHNL_LVL_2,
                N_PRDCT_SALE_CHNL_LVL_2,
                O_PRDCT_SALE_CHNL_LVL_3,
                N_PRDCT_SALE_CHNL_LVL_3,
                O_D_NEW_TO_MEDCR_SK,
                NVL (O_DSCNT_PD_NEW_TO_MEDCR_AMT, 0) * -1
                    AS O_DSCNT_PD_NEW_TO_MEDCR_AMT,
                NVL (O_DSCNT_DLQNT_NEW_TO_MEDCR_AMT, 0) * -1
                    AS O_DSCNT_DLQNT_NEW_TO_MEDCR_AMT,
                N_D_NEW_TO_MEDCR_SK,
                N_DSCNT_PD_NEW_TO_MEDCR_AMT,
                N_DSCNT_DLQNT_NEW_TO_MEDCR_AMT,
                O_D_UNDWR_GUID_SK,
                N_D_UNDWR_GUID_SK,
                O_D_AGT_POL_SK,
                N_D_AGT_POL_SK,
                N_PRO_RATED_CREDIT,
                NVL (O_PRO_RATED_CREDIT, 0) * -1
                    AS O_PRO_RATED_CREDIT,
                N_ENT_AGE_EFFDT,
                O_ENT_AGE_EFFDT
           FROM BDR_DM.WRK_RIA_PREMIUM_DATA_CHANGE_TRANS
          WHERE     OLD_HOUSEHOLD_ID = NEW_HOUSEHOLD_ID
                AND ABS (OLD_PAID_CERT) = ABS (NEW_PAID_CERT)
                AND ABS (OLD_DEL_CERT) = ABS (NEW_DEL_CERT)
                AND ABS (OLD_TERM_CERT) = ABS (NEW_TERM_CERT)
                AND ABS (OLD_PAID_PREMIUM_AMT) = ABS (NEW_PAID_PREMIUM_AMT)
                AND ABS (OLD_DELINQUENT_PREMIUM_DUE_AMT) =
                    ABS (NEW_DELINQUENT_PREMIUM_DUE_AMT)
                AND OLD_PLAN_CD = NEW_PLAN_CD
                AND OLD_BENEFIT_MOD_CATEGORY_ID = NEW_BENEFIT_MOD_CATEGORY_ID
                AND NVL (OLD_INSURED_PLAN_EFF_DATE,
                         TO_DATE (''9999-12-31'', ''YYYY-MM-DD'')) =
                    NVL (NEW_INSURED_PLAN_EFF_DATE,
                         TO_DATE (''9999-12-31'', ''YYYY-MM-DD''))
                AND NVL (OLD_CERT_TERMINATION_DATE,
                         TO_DATE (''9999-12-31'', ''YYYY-MM-DD'')) =
                    NVL (NEW_CERT_TERMINATION_DATE,
                         TO_DATE (''9999-12-31'', ''YYYY-MM-DD''))
                AND SUBSTR (OLD_ZIP_CD, 1, 5) = SUBSTR (NEW_ZIP_CD, 1, 5)
                AND OLD_STATE_CD = NEW_STATE_CD
                AND OLD_COUNTRY_CD = NEW_COUNTRY_CD
                AND OLD_ISSUE_STATE = NEW_ISSUE_STATE
                AND OLD_ISSUE_COUNTRY_CD = NEW_ISSUE_COUNTRY_CD
                AND SUBSTR (OLD_ISSUE_ZIP_CD, 1, 5) =
                    SUBSTR (NEW_ISSUE_ZIP_CD, 1, 5)
                AND OLD_GENDER_CD = NEW_GENDER_CD
                AND OLD_DATE_OF_BIRTH = NEW_DATE_OF_BIRTH
                AND Old_CERT_ACQN_CHNL_LEVEL3 = New_CERT_ACQN_CHNL_LEVEL3
                AND OLD_ACCOUNT_NUMBER = NEW_ACCOUNT_NUMBER
                AND Old_CERT_ACTV_LVL_3_TXT = New_CERT_ACTV_LVL_3_TXT
                AND OLD_UNDWR_TAG_KEY = NEW_UNDWR_TAG_KEY
                AND NVL (OLD_PRDCT_EFF_DT,
                         TO_DATE (''9999-12-31'', ''YYYY-MM-DD'')) =
                    NVL (NEW_PRDCT_EFF_DT,
                         TO_DATE (''9999-12-31'', ''YYYY-MM-DD''))
                AND NVL (OLD_PRDCT_ACQN_CHNL_LEVEL3, ''NA'') =
                    NVL (NEW_PRDCT_ACQN_CHNL_LEVEL3, ''NA'')
                AND NVL (OLD_LEGAL_ENTITY_NAME, ''UNKNOWN'') =
                    NVL (NEW_LEGAL_ENTITY_NAME, ''UNKNOWN'')
                AND ABS (OLD_MBR_PD_PREM_AMT) = ABS (New_MBR_PD_PREM_AMT)
                AND ABS (OLD_MBR_DELQ_PREM_AMT) = ABS (NEW_MBR_DELQ_PREM_AMT)
                AND ABS (OLD_ER_PD_PREM_AMT) = ABS (New_ER_PD_PREM_AMT)
                AND ABS (OLD_ER_DELQ_PREM_AMT) = ABS (NEW_ER_DELQ_PREM_AMT)
                AND OLD_RET_TYP_ID = NEW_RET_TYP_ID
                AND OLD_ER_SKEY = NEW_ER_SKEY
                AND NVL (OLD_AGT_WRT_SKEY, -1) = NVL (NEW_AGT_WRT_SKEY, -1)
                AND NVL (OLD_AGT_SEL_ORIG_SKEY, -1) =
                    NVL (NEW_AGT_SEL_ORIG_SKEY, -1)
                AND NVL (OLD_AGT_SEL_SKEY, -1) = NVL (NEW_AGT_SEL_SKEY, -1)
                AND NVL (OLD_AGT_DCM_WRT_SKEY, -1) =
                    NVL (NEW_AGT_DCM_WRT_SKEY, -1)
                AND O_D_DSCNT_ANNL_PAYR_SK = N_D_DSCNT_ANNL_PAYR_SK
                AND O_D_DSCNT_EFT_SK = N_D_DSCNT_EFT_SK
                AND O_D_DSCNT_ERLY_ENRL_SK = N_D_DSCNT_ERLY_ENRL_SK
                AND O_D_DSCNT_LNGVTY_SK = N_D_DSCNT_LNGVTY_SK
                AND O_D_DSCNT_MULTI_INSD_SK = N_D_DSCNT_MULTI_INSD_SK
                AND O_D_SURCHRG_TBCC_USER_SK = N_D_SURCHRG_TBCC_USER_SK
                AND O_D_SURCHRG_TIER_SK = N_D_SURCHRG_TIER_SK
                AND O_D_INSD_PLN_PRFL_SK = N_D_INSD_PLN_PRFL_SK
                AND O_D_CALC_RT_SK = N_D_CALC_RT_SK
                AND O_MEDSUP_PLN_ENT_AGE_LOOK_FRAC =
                    N_MEDSUP_PLN_ENT_AGE_LOOK_FRAC
                AND ABS (O_DSCNT_PD_ANNL_PAYR_AMT) =
                    ABS (N_DSCNT_PD_ANNL_PAYR_AMT)
                AND ABS (O_DSCNT_PD_EFT_AMT) = ABS (N_DSCNT_PD_EFT_AMT)
                AND ABS (O_DSCNT_PD_ERLY_ENRL_AMT) =
                    ABS (N_DSCNT_PD_ERLY_ENRL_AMT)
                AND ABS (O_DSCNT_PD_LNGVTY_AMT) = ABS (N_DSCNT_PD_LNGVTY_AMT)
                AND ABS (O_DSCNT_PD_MULTI_INSD_AMT) =
                    ABS (N_DSCNT_PD_MULTI_INSD_AMT)
                AND ABS (O_SURCHRG_PD_TBCC_USER_AMT) =
                    ABS (N_SURCHRG_PD_TBCC_USER_AMT)
                AND ABS (O_SURCHRG_PD_TIER_AMT) = ABS (N_SURCHRG_PD_TIER_AMT)
                AND ABS (O_DSCNT_DELQ_ANNL_PAYR_AMT) =
                    ABS (N_DSCNT_DELQ_ANNL_PAYR_AMT)
                AND ABS (O_DSCNT_DELQ_EFT_AMT) = ABS (N_DSCNT_DELQ_EFT_AMT)
                AND ABS (O_DSCNT_DELQ_ERLY_ENRL_AMT) =
                    ABS (N_DSCNT_DELQ_ERLY_ENRL_AMT)
                AND ABS (O_DSCNT_DELQ_LNGVTY_AMT) =
                    ABS (N_DSCNT_DELQ_LNGVTY_AMT)
                AND ABS (O_DSCNT_DELQ_MULTI_INSD_AMT) =
                    ABS (N_DSCNT_DELQ_MULTI_INSD_AMT)
                AND ABS (O_SURCHRG_DELQ_TBCC_USER_AMT) =
                    ABS (N_SURCHRG_DELQ_TBCC_USER_AMT)
                AND ABS (O_SURCHRG_DELQ_TIER_AMT) =
                    ABS (N_SURCHRG_DELQ_TIER_AMT)
                AND NVL (O_AGT_REF_ORIG_D_AGT_SK, -2) =
                    NVL (N_AGT_REF_ORIG_D_AGT_SK, -2)
                AND NVL (O_AGT_REF_D_AGT_SK, -2) =
                    NVL (N_AGT_REF_D_AGT_SK, -2)
                AND NVL (O_D_MBR_INFO_SK, -1) = NVL (N_D_MBR_INFO_SK, -1)
                AND NVL (O_D_PLN_BEN_MOD_SK, -1) =
                    NVL (N_D_PLN_BEN_MOD_SK, -1)
                AND NVL (O_RES_D_GEO_XREF_SK, -1) =
                    NVL (N_RES_D_GEO_XREF_SK, -1)
                AND NVL (O_PLN_ISS_D_GEO_XREF_SK, -1) =
                    NVL (N_PLN_ISS_D_GEO_XREF_SK, -1)
                AND NVL (O_D_RTNG_AREA_SK, -1) = NVL (N_D_RTNG_AREA_SK, -1)
                AND NVL (O_F_APPL_TRANS_DAY_SK, -1) =
                    NVL (N_F_APPL_TRANS_DAY_SK, -1)
                AND NVL (O_CERT_SALE_CHNL_LVL_1, ''N/A'') =
                    NVL (N_CERT_SALE_CHNL_LVL_1, ''N/A'')
                AND NVL (O_CERT_SALE_CHNL_LVL_2, ''N/A'') =
                    NVL (N_CERT_SALE_CHNL_LVL_2, ''N/A'')
                AND NVL (O_CERT_SALE_CHNL_LVL_3, ''N/A'') =
                    NVL (N_CERT_SALE_CHNL_LVL_3, ''N/A'')
                AND NVL (O_PRDCT_SALE_CHNL_LVL_1, ''N/A'') =
                    NVL (N_PRDCT_SALE_CHNL_LVL_1, ''N/A'')
                AND NVL (O_PRDCT_SALE_CHNL_LVL_2, ''N/A'') =
                    NVL (N_PRDCT_SALE_CHNL_LVL_2, ''N/A'')
                AND NVL (O_PRDCT_SALE_CHNL_LVL_3, ''N/A'') =
                    NVL (N_PRDCT_SALE_CHNL_LVL_3, ''N/A'')
                AND O_D_NEW_TO_MEDCR_SK = N_D_NEW_TO_MEDCR_SK
                AND ABS (O_DSCNT_PD_NEW_TO_MEDCR_AMT) =
                    ABS (N_DSCNT_PD_NEW_TO_MEDCR_AMT)
                AND ABS (O_DSCNT_DLQNT_NEW_TO_MEDCR_AMT) =
                    ABS (N_DSCNT_DLQNT_NEW_TO_MEDCR_AMT)
                AND O_D_UNDWR_GUID_SK = N_D_UNDWR_GUID_SK
                AND O_D_AGT_POL_SK = N_D_AGT_POL_SK
                AND ABS (O_PRO_RATED_CREDIT) = ABS (N_PRO_RATED_CREDIT)
                AND NVL (O_ENT_AGE_EFFDT,
                         TO_DATE (''9999-12-31'', ''YYYY-MM-DD'')) =
                    NVL (N_ENT_AGE_EFFDT,
                         TO_DATE (''9999-12-31'', ''YYYY-MM-DD'')));
						 
						 
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

----------------Step3

V_STEP_NAME    := ''TARGET - TRUNCATE BDR_DM.TEMP_PREMDELTRANS'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;
 
  EXECUTE IMMEDIATE ''truncate table BDR_DM.TEMP_PREMDELTRANS'';
 
INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

----------------Step4

V_STEP_NAME    := ''TARGET - INSERT BDR_DM.TEMP_PREMDELTRANS'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;


INSERT INTO BDR_DM.TEMP_PREMDELTRANS (HOUSEHOLD_ID,
                                      INDIVIDUAL_ID,
                                      INS_PLAN_BILLING_BUCKET_ID,
                                      INSURED_PLAN_ID,
                                      HOUSEHOLD_ADDRESS_ID,
                                      PREMIUM_DUE_DATE,
                                      ACTIVITY_DATE,
                                      PAID_CERT,
                                      DEL_CERT,
                                      TERM_CERT,
                                      PAID_PREMIUM_AMT,
                                      DELINQUENT_PREMIUM_DUE_AMT,
                                      PLAN_CD,
                                      BENEFIT_MOD_CATEGORY_ID,
                                      INSURED_PLAN_EFFECTIVE_DATE,
                                      INSURED_PLAN_TERMINATION_DATE,
                                      CERT_TERMINATION_DATE,
                                      STATE_CD,
                                      ZIP_CD,
                                      COUNTRY_CD,
                                      ISSUE_STATE,
                                      ISSUE_COUNTRY_CD,
                                      ISSUE_ZIP_CD,
                                      GENDER_CD,
                                      DATE_OF_BIRTH,
                                      CERT_ACQN_CHNL_LEVEL3,
                                      ACCOUNT_NUMBER,
                                      CERT_ACTV_LVL_3_TXT,
                                      TERMINATION_REASON_NAME,
                                      CONSERVATION_REASON_NAME,
                                      PLAN_GROUP,
                                      PRODUCT_GROUP,
                                      UNDWR_TAG_KEY,
                                      PRDCT_EFF_DT,
                                      PRDCT_ACQN_CHNL_LEVEL3,
                                      LEGAL_ENTITY_NAME,
                                      MBR_PD_PREM_AMT,
                                      MBR_DELQ_PREM_AMT,
                                      ER_PD_PREM_AMT,
                                      ER_DELQ_PREM_AMT,
                                      CURRENT_SIGNATURE_DATE,
                                      ORIGINAL_SIGNATURE_DATE,
                                      ORIGINAL_INSUREDPLAN_ID,
                                      WRITING_AGENT,
                                      SELLING_AGENT,
                                      ORIGINAL_SELLING_AGENT,
                                      RET_TYP_ID,
                                      ER_SKEY,
                                      DCM_INSUREDPLAN_ID,
                                      DCM_INSURED_PLAN_EFF_DATE,
                                      DCM_PLAN_CD,
                                      DCM_SIGNATURE_DATE,
                                      DCM_WRITING_AGENT,
                                      DCM_DERIVED_COMPAS_AGENT,
                                      AGT_WRT_SKEY,
                                      AGT_SEL_ORIG_SKEY,
                                      AGT_SEL_SKEY,
                                      AGT_DCM_WRT_SKEY,
                                      TRANS_TYPE,
                                      D_DSCNT_ANNL_PAYR_SK,
                                      D_DSCNT_EFT_SK,
                                      D_DSCNT_ERLY_ENRL_SK,
                                      D_DSCNT_LNGVTY_SK,
                                      D_DSCNT_MULTI_INSD_SK,
                                      D_SURCHRG_TBCC_USER_SK,
                                      D_SURCHRG_TIER_SK,
                                      D_INSD_PLN_PRFL_SK,
                                      D_CALC_RT_SK,
                                      MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
                                      DSCNT_PD_ANNL_PAYR_AMT,
                                      DSCNT_PD_EFT_AMT,
                                      DSCNT_PD_ERLY_ENRL_AMT,
                                      DSCNT_PD_LNGVTY_AMT,
                                      DSCNT_PD_MULTI_INSD_AMT,
                                      SURCHRG_PD_TBCC_USER_AMT,
                                      SURCHRG_PD_TIER_AMT,
                                      DSCNT_DELQ_ANNL_PAYR_AMT,
                                      DSCNT_DELQ_EFT_AMT,
                                      DSCNT_DELQ_ERLY_ENRL_AMT,
                                      DSCNT_DELQ_LNGVTY_AMT,
                                      DSCNT_DELQ_MULTI_INSD_AMT,
                                      SURCHRG_DELQ_TBCC_USER_AMT,
                                      SURCHRG_DELQ_TIER_AMT,
                                      ORIGINAL_REFERRAL_AGENT,
                                      REFERRAL_AGENT,
                                      AGT_REF_ORIG_D_AGT_SK,
                                      AGT_REF_D_AGT_SK,
                                      D_MBR_INFO_SK,
                                      D_PLN_BEN_MOD_SK,
                                      RES_D_GEO_XREF_SK,
                                      PLN_ISS_D_GEO_XREF_SK,
                                      D_RTNG_AREA_SK,
                                      F_APPL_TRANS_DAY_SK,
                                      CERT_SALE_CHNL_LVL_1,
                                      CERT_SALE_CHNL_LVL_2,
                                      CERT_SALE_CHNL_LVL_3,
                                      PRDCT_SALE_CHNL_LVL_1,
                                      PRDCT_SALE_CHNL_LVL_2,
                                      PRDCT_SALE_CHNL_LVL_3,
                                      D_NEW_TO_MEDCR_SK,
                                      DSCNT_PD_NEW_TO_MEDCR_AMT,
                                      DSCNT_DLQNT_NEW_TO_MEDCR_AMT,
                                      D_UNDWR_GUID_SK,
                                      D_AGT_POL_SK,
                                      PRO_RATED_CREDIT,
                                      ENT_AGE_EFFDT)
        (SELECT OLD_HOUSEHOLD_ID,
                INDIVIDUAL_ID,
                OLD_INS_PLAN_BILLING_BUCKET_ID,
                INSURED_PLAN_ID,
                OLD_Household_Address_ID,
                PREMIUM_DUE_DATE,
                NEW_ACTIVITY_DATE,
                OLD_PAID_CERT,
                OLD_DEL_CERT,
                OLD_TERM_CERT,
                OLD_PAID_PREMIUM_AMT,
                OLD_DELINQUENT_PREMIUM_DUE_AMT,
                OLD_PLAN_CD,
                OLD_BENEFIT_MOD_CATEGORY_ID,
                OLD_INSURED_PLAN_EFF_DATE,
                OLD_INSURED_PLAN_TERM_DATE,
                OLD_CERT_TERMINATION_DATE,
                OLD_STATE_CD,
                OLD_ZIP_CD,
                OLD_COUNTRY_CD,
                OLD_ISSUE_STATE,
                OLD_ISSUE_COUNTRY_CD,
                OLD_ISSUE_ZIP_CD,
                OLD_GENDER_CD,
                OLD_DATE_OF_BIRTH,
                OLD_CERT_ACQN_CHNL_LEVEL3,
                OLD_ACCOUNT_NUMBER,
                OLD_CERT_ACTV_LVL_3_TXT,
                OLD_TERMINATION_REASON_NAME,
                OLD_CONSERVATION_REASON_NAME,
                OLD_PLAN_GROUP,
                OLD_PRODUCT_GROUP,
                OLD_UNDWR_TAG_KEY,
                OLD_PRDCT_EFF_DT,
                OLD_PRDCT_ACQN_CHNL_LEVEL3,
                OLD_LEGAL_ENTITY_NAME,
                OLD_MBR_PD_PREM_AMT,
                OLD_MBR_DELQ_PREM_AMT,
                OLD_ER_PD_PREM_AMT,
                OLD_ER_DELQ_PREM_AMT,
                OLD_CURRENT_SIGNATURE_DATE,
                OLD_ORIGINAL_SIGNATURE_DATE,
                OLD_ORIGINAL_INSUREDPLAN_ID,
                OLD_WRITING_AGENT,
                OLD_SELLING_AGENT,
                OLD_ORIGINAL_SELLING_AGENT,
                OLD_RET_TYP_ID,
                OLD_ER_SKEY,
                OLD_DCM_INSURED_PLAN_ID,
                OLD_DCM_INSURED_PLAN_EFF_DATE,
                OLD_DCM_PLAN_CD,
                OLD_DCM_SIGNATURE_DATE,
                OLD_DCM_WRITING_AGENT,
                OLD_DCM_DERIVED_COMPAS_AGENT,
                OLD_AGT_WRT_SKEY,
                OLD_AGT_SEL_ORIG_SKEY,
                OLD_AGT_SEL_SKEY,
                OLD_AGT_DCM_WRT_SKEY,
                ''O'',
                O_D_DSCNT_ANNL_PAYR_SK,
                O_D_DSCNT_EFT_SK,
                O_D_DSCNT_ERLY_ENRL_SK,
                O_D_DSCNT_LNGVTY_SK,
                O_D_DSCNT_MULTI_INSD_SK,
                O_D_SURCHRG_TBCC_USER_SK,
                O_D_SURCHRG_TIER_SK,
                O_D_INSD_PLN_PRFL_SK,
                O_D_CALC_RT_SK,
                O_MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
                O_DSCNT_PD_ANNL_PAYR_AMT,
                O_DSCNT_PD_EFT_AMT,
                O_DSCNT_PD_ERLY_ENRL_AMT,
                O_DSCNT_PD_LNGVTY_AMT,
                O_DSCNT_PD_MULTI_INSD_AMT,
                O_SURCHRG_PD_TBCC_USER_AMT,
                O_SURCHRG_PD_TIER_AMT,
                O_DSCNT_DELQ_ANNL_PAYR_AMT,
                O_DSCNT_DELQ_EFT_AMT,
                O_DSCNT_DELQ_ERLY_ENRL_AMT,
                O_DSCNT_DELQ_LNGVTY_AMT,
                O_DSCNT_DELQ_MULTI_INSD_AMT,
                O_SURCHRG_DELQ_TBCC_USER_AMT,
                O_SURCHRG_DELQ_TIER_AMT,
                O_ORIGINAL_REFERRAL_AGENT,
                O_REFERRAL_AGENT,
                O_AGT_REF_ORIG_D_AGT_SK,
                O_AGT_REF_D_AGT_SK,
                O_D_MBR_INFO_SK,
                O_D_PLN_BEN_MOD_SK,
                O_RES_D_GEO_XREF_SK,
                O_PLN_ISS_D_GEO_XREF_SK,
                O_D_RTNG_AREA_SK,
                O_F_APPL_TRANS_DAY_SK,
                O_CERT_SALE_CHNL_LVL_1,
                O_CERT_SALE_CHNL_LVL_2,
                O_CERT_SALE_CHNL_LVL_3,
                O_PRDCT_SALE_CHNL_LVL_1,
                O_PRDCT_SALE_CHNL_LVL_2,
                O_PRDCT_SALE_CHNL_LVL_3,
                O_D_NEW_TO_MEDCR_SK,
                O_DSCNT_PD_NEW_TO_MEDCR_AMT,
                O_DSCNT_DLQNT_NEW_TO_MEDCR_AMT,
                O_D_UNDWR_GUID_SK,
                O_D_AGT_POL_SK,
                O_PRO_RATED_CREDIT,
                O_ENT_AGE_EFFDT
           FROM BDR_DM.TEMP_DUPS_CHANGE_TRANS
         UNION
         SELECT NEW_HOUSEHOLD_ID,
                INDIVIDUAL_ID,
                NEW_INS_PLAN_BILLING_BUCKET_ID,
                INSURED_PLAN_ID,
                NEW_Household_Address_ID,
                PREMIUM_DUE_DATE,
                NEW_ACTIVITY_DATE,
                NEW_PAID_CERT,
                NEW_DEL_CERT,
                NEW_TERM_CERT,
                NEW_PAID_PREMIUM_AMT,
                NEW_DELINQUENT_PREMIUM_DUE_AMT,
                NEW_PLAN_CD,
                NEW_BENEFIT_MOD_CATEGORY_ID,
                NEW_INSURED_PLAN_EFF_DATE,
                NEW_INSURED_PLAN_TERM_DATE,
                NEW_CERT_TERMINATION_DATE,
                NEW_STATE_CD,
                NEW_ZIP_CD,
                NEW_COUNTRY_CD,
                NEW_ISSUE_STATE,
                NEW_ISSUE_COUNTRY_CD,
                NEW_ISSUE_ZIP_CD,
                NEW_GENDER_CD,
                NEW_DATE_OF_BIRTH,
                NEW_CERT_ACQN_CHNL_LEVEL3,
                NEW_ACCOUNT_NUMBER,
                NEW_CERT_ACTV_LVL_3_TXT,
                NEW_TERMINATION_REASON_NAME,
                NEW_CONSERVATION_REASON_NAME,
                NEW_PLAN_GROUP,
                NEW_PRODUCT_GROUP,
                NEW_UNDWR_TAG_KEY,
                NEW_PRDCT_EFF_DT,
                NEW_PRDCT_ACQN_CHNL_LEVEL3,
                NEW_LEGAL_ENTITY_NAME,
                NEW_MBR_PD_PREM_AMT,
                NEW_MBR_DELQ_PREM_AMT,
                NEW_ER_PD_PREM_AMT,
                NEW_ER_DELQ_PREM_AMT,
                NEW_CURRENT_SIGNATURE_DATE,
                NEW_ORIGINAL_SIGNATURE_DATE,
                NEW_ORIGINAL_INSUREDPLAN_ID,
                NEW_WRITING_AGENT,
                NEW_SELLING_AGENT,
                NEW_ORIGINAL_SELLING_AGENT,
                NEW_RET_TYP_ID,
                NEW_ER_SKEY,
                NEW_DCM_INSURED_PLAN_ID,
                NEW_DCM_INSURED_PLAN_EFF_DATE,
                NEW_DCM_PLAN_CD,
                NEW_DCM_SIGNATURE_DATE,
                NEW_DCM_WRITING_AGENT,
                NEW_DCM_DERIVED_COMPAS_AGENT,
                NEW_AGT_WRT_SKEY,
                NEW_AGT_SEL_ORIG_SKEY,
                NEW_AGT_SEL_SKEY,
                NEW_AGT_DCM_WRT_SKEY,
                ''N'',
                N_D_DSCNT_ANNL_PAYR_SK,
                N_D_DSCNT_EFT_SK,
                N_D_DSCNT_ERLY_ENRL_SK,
                N_D_DSCNT_LNGVTY_SK,
                N_D_DSCNT_MULTI_INSD_SK,
                N_D_SURCHRG_TBCC_USER_SK,
                N_D_SURCHRG_TIER_SK,
                N_D_INSD_PLN_PRFL_SK,
                N_D_CALC_RT_SK,
                N_MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
                N_DSCNT_PD_ANNL_PAYR_AMT,
                N_DSCNT_PD_EFT_AMT,
                N_DSCNT_PD_ERLY_ENRL_AMT,
                N_DSCNT_PD_LNGVTY_AMT,
                N_DSCNT_PD_MULTI_INSD_AMT,
                N_SURCHRG_PD_TBCC_USER_AMT,
                N_SURCHRG_PD_TIER_AMT,
                N_DSCNT_DELQ_ANNL_PAYR_AMT,
                N_DSCNT_DELQ_EFT_AMT,
                N_DSCNT_DELQ_ERLY_ENRL_AMT,
                N_DSCNT_DELQ_LNGVTY_AMT,
                N_DSCNT_DELQ_MULTI_INSD_AMT,
                N_SURCHRG_DELQ_TBCC_USER_AMT,
                N_SURCHRG_DELQ_TIER_AMT,
                N_ORIGINAL_REFERRAL_AGENT,
                N_REFERRAL_AGENT,
                N_AGT_REF_ORIG_D_AGT_SK,
                N_AGT_REF_D_AGT_SK,
                N_D_MBR_INFO_SK,
                N_D_PLN_BEN_MOD_SK,
                N_RES_D_GEO_XREF_SK,
                N_PLN_ISS_D_GEO_XREF_SK,
                N_D_RTNG_AREA_SK,
                N_F_APPL_TRANS_DAY_SK,
                N_CERT_SALE_CHNL_LVL_1,
                N_CERT_SALE_CHNL_LVL_2,
                N_CERT_SALE_CHNL_LVL_3,
                N_PRDCT_SALE_CHNL_LVL_1,
                N_PRDCT_SALE_CHNL_LVL_2,
                N_PRDCT_SALE_CHNL_LVL_3,
                N_D_NEW_TO_MEDCR_SK,
                N_DSCNT_PD_NEW_TO_MEDCR_AMT,
                N_DSCNT_DLQNT_NEW_TO_MEDCR_AMT,
                N_D_UNDWR_GUID_SK,
                N_D_AGT_POL_SK,
                N_PRO_RATED_CREDIT,
                N_ENT_AGE_EFFDT
           FROM BDR_DM.TEMP_DUPS_CHANGE_TRANS);


V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

----------------Step4

V_STEP_NAME    := ''TARGET - INSERT BDR_DM.WRK_RIA_PREMIUM_DATA_DEL_TRANS'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

INSERT INTO BDR_DM.WRK_RIA_PREMIUM_DATA_DEL_TRANS (
                    HOUSEHOLD_ID,
                    INDIVIDUAL_ID,
                    INS_PLAN_BILLING_BUCKET_ID,
                    INSURED_PLAN_ID,
                    HOUSEHOLD_ADDRESS_ID,
                    PREMIUM_DUE_DATE,
                    ACTIVITY_DATE,
                    PAID_CERT,
                    DEL_CERT,
                    TERM_CERT,
                    PAID_PREMIUM_AMT,
                    DELINQUENT_PREMIUM_DUE_AMT,
                    PLAN_CD,
                    BENEFIT_MOD_CATEGORY_ID,
                    INSURED_PLAN_EFFECTIVE_DATE,
                    INSURED_PLAN_TERMINATION_DATE,
                    CERT_TERMINATION_DATE,
                    STATE_CD,
                    ZIP_CD,
                    COUNTRY_CD,
                    ISSUE_STATE,
                    ISSUE_COUNTRY_CD,
                    ISSUE_ZIP_CD,
                    GENDER_CD,
                    DATE_OF_BIRTH,
                    TRANS_TYPE,
                    CERT_ACQN_CHNL_LEVEL3,
                    ACCOUNT_NUMBER,
                    CERT_ACTV_LVL_3_TXT,
                    TERMINATION_REASON_NAME,
                    CONSERVATION_REASON_NAME,
                    PLAN_GROUP,
                    PRODUCT_GROUP,
                    UNDWR_TAG_KEY,
                    PRDCT_EFF_DT,
                    PRDCT_ACQN_CHNL_LEVEL3,
                    LEGAL_ENTITY_NAME,
                    MBR_PD_PREM_AMT,
                    MBR_DELQ_PREM_AMT,
                    ER_PD_PREM_AMT,
                    ER_DELQ_PREM_AMT,
                    CURRENT_SIGNATURE_DATE,
                    ORIGINAL_SIGNATURE_DATE,
                    ORIGINAL_INSUREDPLAN_ID,
                    WRITING_AGENT,
                    SELLING_AGENT,
                    ORIGINAL_SELLING_AGENT,
                    DCM_INSUREDPLAN_ID,
                    DCM_INSURED_PLAN_EFF_DATE,
                    DCM_PLAN_CD,
                    DCM_SIGNATURE_DATE,
                    DCM_WRITING_AGENT,
                    DCM_DERIVED_COMPAS_AGENT,
                    RET_TYP_ID,
                    ER_SKEY,
                    AGT_WRT_SKEY,
                    AGT_SEL_ORIG_SKEY,
                    AGT_SEL_SKEY,
                    AGT_DCM_WRT_SKEY,
                    D_DSCNT_ANNL_PAYR_SK,
                    D_DSCNT_EFT_SK,
                    D_DSCNT_ERLY_ENRL_SK,
                    D_DSCNT_LNGVTY_SK,
                    D_DSCNT_MULTI_INSD_SK,
                    D_SURCHRG_TBCC_USER_SK,
                    D_SURCHRG_TIER_SK,
                    D_INSD_PLN_PRFL_SK,
                    D_CALC_RT_SK,
                    MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
                    DSCNT_PD_ANNL_PAYR_AMT,
                    DSCNT_PD_EFT_AMT,
                    DSCNT_PD_ERLY_ENRL_AMT,
                    DSCNT_PD_LNGVTY_AMT,
                    DSCNT_PD_MULTI_INSD_AMT,
                    SURCHRG_PD_TBCC_USER_AMT,
                    SURCHRG_PD_TIER_AMT,
                    DSCNT_DELQ_ANNL_PAYR_AMT,
                    DSCNT_DELQ_EFT_AMT,
                    DSCNT_DELQ_ERLY_ENRL_AMT,
                    DSCNT_DELQ_LNGVTY_AMT,
                    DSCNT_DELQ_MULTI_INSD_AMT,
                    SURCHRG_DELQ_TBCC_USER_AMT,
                    SURCHRG_DELQ_TIER_AMT,
                    ORIGINAL_REFERRAL_AGENT,
                    REFERRAL_AGENT,
                    AGT_REF_ORIG_D_AGT_SK,
                    AGT_REF_D_AGT_SK,
                    D_MBR_INFO_SK,
                    D_PLN_BEN_MOD_SK,
                    RES_D_GEO_XREF_SK,
                    PLN_ISS_D_GEO_XREF_SK,
                    D_RTNG_AREA_SK,
                    F_APPL_TRANS_DAY_SK,
                    CERT_SALE_CHNL_LVL_1,
                    CERT_SALE_CHNL_LVL_2,
                    CERT_SALE_CHNL_LVL_3,
                    PRDCT_SALE_CHNL_LVL_1,
                    PRDCT_SALE_CHNL_LVL_2,
                    PRDCT_SALE_CHNL_LVL_3,
                    D_NEW_TO_MEDCR_SK,
                    DSCNT_PD_NEW_TO_MEDCR_AMT,
                    DSCNT_DLQNT_NEW_TO_MEDCR_AMT,
                    D_UNDWR_GUID_SK,
                    D_AGT_POL_SK,
                    PRO_RATED_CREDIT,
                    ENT_AGE_EFFDT)
        (SELECT DISTINCT HOUSEHOLD_ID,
                         INDIVIDUAL_ID,
                         INS_PLAN_BILLING_BUCKET_ID,
                         INSURED_PLAN_ID,
                         HOUSEHOLD_ADDRESS_ID,
                         PREMIUM_DUE_DATE,
                         ACTIVITY_DATE,
                         PAID_CERT,
                         DEL_CERT,
                         TERM_CERT,
                         PAID_PREMIUM_AMT,
                         DELINQUENT_PREMIUM_DUE_AMT,
                         PLAN_CD,
                         BENEFIT_MOD_CATEGORY_ID,
                         INSURED_PLAN_EFFECTIVE_DATE,
                         INSURED_PLAN_TERMINATION_DATE,
                         CERT_TERMINATION_DATE,
                         STATE_CD,
                         ZIP_CD,
                         COUNTRY_CD,
                         ISSUE_STATE,
                         ISSUE_COUNTRY_CD,
                         ISSUE_ZIP_CD,
                         GENDER_CD,
                         DATE_OF_BIRTH,
                         TRANS_TYPE,
                         CERT_ACQN_CHNL_LEVEL3,
                         ACCOUNT_NUMBER,
                         CERT_ACTV_LVL_3_TXT,
                         TERMINATION_REASON_NAME,
                         CONSERVATION_REASON_NAME,
                         PLAN_GROUP,
                         PRODUCT_GROUP,
                         UNDWR_TAG_KEY,
                         PRDCT_EFF_DT,
                         PRDCT_ACQN_CHNL_LEVEL3,
                         LEGAL_ENTITY_NAME,
                         MBR_PD_PREM_AMT,
                         MBR_DELQ_PREM_AMT,
                         ER_PD_PREM_AMT,
                         ER_DELQ_PREM_AMT,
                         CURRENT_SIGNATURE_DATE,
                         ORIGINAL_SIGNATURE_DATE,
                         ORIGINAL_INSURED_PLAN_ID,
                         WRITING_AGENT,
                         SELLING_AGENT,
                         ORIGINAL_SELLING_AGENT,
                         DCM_INSURED_PLAN_ID,
                         DCM_INSURED_PLAN_EFF_DATE,
                         DCM_PLAN_CD,
                         DCM_SIGNATURE_DATE,
                         DCM_WRITING_AGENT,
                         DCM_DERIVED_COMPAS_AGENT,
                         RET_TYP_ID,
                         ER_SKEY,
                         AGT_WRT_SKEY,
                         AGT_SEL_ORIG_SKEY,
                         AGT_SEL_SKEY,
                         AGT_DCM_WRT_SKEY,
                         D_DSCNT_ANNL_PAYR_SK,
                         D_DSCNT_EFT_SK,
                         D_DSCNT_ERLY_ENRL_SK,
                         D_DSCNT_LNGVTY_SK,
                         D_DSCNT_MULTI_INSD_SK,
                         D_SURCHRG_TBCC_USER_SK,
                         D_SURCHRG_TIER_SK,
                         D_INSD_PLN_PRFL_SK,
                         D_CALC_RT_SK,
                         MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
                         DSCNT_PD_ANNL_PAYR_AMT,
                         DSCNT_PD_EFT_AMT,
                         DSCNT_PD_ERLY_ENRL_AMT,
                         DSCNT_PD_LNGVTY_AMT,
                         DSCNT_PD_MULTI_INSD_AMT,
                         SURCHRG_PD_TBCC_USER_AMT,
                         SURCHRG_PD_TIER_AMT,
                         DSCNT_DELQ_ANNL_PAYR_AMT,
                         DSCNT_DELQ_EFT_AMT,
                         DSCNT_DELQ_ERLY_ENRL_AMT,
                         DSCNT_DELQ_LNGVTY_AMT,
                         DSCNT_DELQ_MULTI_INSD_AMT,
                         SURCHRG_DELQ_TBCC_USER_AMT,
                         SURCHRG_DELQ_TIER_AMT,
                         ORIGINAL_REFERRAL_AGENT,
                         REFERRAL_AGENT,
                         AGT_REF_ORIG_D_AGT_SK,
                         AGT_REF_D_AGT_SK,
                         D_MBR_INFO_SK,
                         D_PLN_BEN_MOD_SK,
                         RES_D_GEO_XREF_SK,
                         PLN_ISS_D_GEO_XREF_SK,
                         D_RTNG_AREA_SK,
                         F_APPL_TRANS_DAY_SK,
                         CERT_SALE_CHNL_LVL_1,
                         CERT_SALE_CHNL_LVL_2,
                         CERT_SALE_CHNL_LVL_3,
                         PRDCT_SALE_CHNL_LVL_1,
                         PRDCT_SALE_CHNL_LVL_2,
                         PRDCT_SALE_CHNL_LVL_3,
                         D_NEW_TO_MEDCR_SK,
                         DSCNT_PD_NEW_TO_MEDCR_AMT,
                         DSCNT_DLQNT_NEW_TO_MEDCR_AMT,
                         D_UNDWR_GUID_SK,
                         D_AGT_POL_SK,
                         PRO_RATED_CREDIT,
                         ENT_AGE_EFFDT
           FROM BDR_DM.TEMP_RIA_DATA_TO_DEL_TRNS);
		   

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

--------FinalLogUpdate


UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''COMPLETE'', ERROR_MSG = null, BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
;
UPDATE  UTIL.ETL_BATCH_OBJECT_INCR_VALU SET INCR_COLUMN_VALUE = :V_BATCH_ID, LST_MOD_DT = CURRENT_TIMESTAMP() 
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID''
;

EXCEPTION

WHEN OTHER THEN

UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''ERROR'', ERROR_MSG = :SQLERRM,  BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
;

INSERT INTO  UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ERROR_MSG, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''ERROR'', :V_STEP_NAME, :V_STEP_SEQ, :SQLERRM, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() )
;



RAISE;

END;

';