USE SCHEMA BDR_DM; CREATE OR REPLACE PROCEDURE "SP_RIA_PREMIUM_INTERMEDIATE3_I_DATA_DEL_TRNS_D"("DB_NAME" VARCHAR(16777216), "APPLICATION" VARCHAR(16777216), "WORKFLOW_NAME" VARCHAR(16777216), "OBJECT_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '

-- Original workflow: wkf_RIA_Premium_Intermediate_IXL_TargetLoad3_D
-- Original mapping: m_RIA_Premium_Intermediate3_I_WrkPremiumDataDelTrans_D
-- Original folder: Premium
-- Original filename: wkf_RIA_Premium_Intermediate_IXL_TargetLoad3_D.XML

DECLARE


V_ROWS_INSERTED  INTEGER;
V_ROWS_UPDATED INTEGER;
V_ROWS_DELETED INTEGER;
V_LAST_QUERY_ID VARCHAR;

V_WH VARCHAR;
V_BATCH_ID INTEGER;


V_BATCH_OBJECT_START_TIME VARCHAR;
V_STEP_START_TIME    VARCHAR;
V_STEP_NAME VARCHAR;
V_STEP_SEQ INTEGER DEFAULT 0;
V_ETL_LST_BTCH_ID INTEGER;

BEGIN

EXECUTE IMMEDIATE ''USE DATABASE ''||:DB_NAME; 

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_BATCH_OBJECT_START_TIME := (SELECT CURRENT_TIMESTAMP());



LET res1 RESULTSET := 
(

SELECT 

WH ,
BATCH_ID
  
FROM UTIL.ETL_BATCH_OBJECT_CONTROL
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
FETCH FIRST 1 ROW ONLY

)
;


LET C1 CURSOR FOR res1;
open C1;
FETCH C1 into  V_WH,V_BATCH_ID ;
close C1;


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:V_WH;

USE SCHEMA BDR_DM;	  

INSERT INTO UTIL.ETL_BATCH_OBJECT_INCR_VALU (APPLICATION, WORKFLOW_NAME, OBJECT_NAME, INCR_COLUMN, INCR_COLUMN_VALUE )
SELECT * FROM (select :APPLICATION AS APPLICATION, :WORKFLOW_NAME AS WORKFLOW_NAME, :OBJECT_NAME AS OBJECT_NAME, ''ETL_LST_BTCH_ID'' AS INCR_COLUMN, -1 AS INCR_COLUMN_VALUE) A
WHERE NOT EXISTS (SELECT 1 FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU B WHERE B.APPLICATION = A.APPLICATION AND B.WORKFLOW_NAME = A.WORKFLOW_NAME AND B.OBJECT_NAME = A.OBJECT_NAME AND B.INCR_COLUMN = A.INCR_COLUMN)
;

V_ETL_LST_BTCH_ID :=(SELECT INCR_COLUMN_VALUE FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID'');

-----------------Step1

V_STEP_NAME    := ''TARGET - TRUNCATE TABLE BDR_DM.TEMP_RIA_DATA_TO_DEL_TRNS'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;
 
  EXECUTE IMMEDIATE ''truncate table BDR_DM.TEMP_RIA_DATA_TO_DEL_TRNS'';
 
INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

---------------Step2

V_STEP_NAME    := ''TARGET - TRUNCATE TABLE BDR_DM.WRK_RIA_PREMIUM_DATA_DEL_TRANS'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;
 

  EXECUTE IMMEDIATE ''truncate table BDR_DM.WRK_RIA_PREMIUM_DATA_DEL_TRANS'';

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

----------------Step3

V_STEP_NAME    := ''TARGET - INSERT BDR_DM.TEMP_RIA_DATA_TO_DEL_TRNS'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;


        INSERT
           INTO BDR_DM.TEMP_RIA_DATA_TO_DEL_TRNS (HOUSEHOLD_ID,
                                              INDIVIDUAL_ID,
                                              INS_PLAN_BILLING_BUCKET_ID,
                                              INSURED_PLAN_ID,
                                              HOUSEHOLD_ADDRESS_ID,
                                              PREMIUM_DUE_DATE,
                                              ACTIVITY_DATE,
                                              PAID_CERT,
                                              DEL_CERT,
                                              TERM_CERT,
                                              PAID_PREMIUM_AMT,
                                              DELINQUENT_PREMIUM_DUE_AMT,
                                              PLAN_CD,
                                              BENEFIT_MOD_CATEGORY_ID,
                                              INSURED_PLAN_EFFECTIVE_DATE,
                                              INSURED_PLAN_TERMINATION_DATE,
                                              CERT_TERMINATION_DATE,
                                              STATE_CD,
                                              ZIP_CD,
                                              COUNTRY_CD,
                                              ISSUE_STATE,
                                              ISSUE_COUNTRY_CD,
                                              ISSUE_ZIP_CD,
                                              GENDER_CD,
                                              DATE_OF_BIRTH,
                                              TRANS_TYPE,
                                              CERT_ACQN_CHNL_LEVEL3,
                                              ACCOUNT_NUMBER,
                                              TERMINATION_REASON_NAME,
                                              CONSERVATION_REASON_NAME,
                                              PLAN_GROUP,
                                              PRODUCT_GROUP,
                                              CERT_ACTV_LVL_3_TXT,
                                              UNDWR_TAG_KEY,
                                              PRDCT_EFF_DT,
                                              PRDCT_ACQN_CHNL_LEVEL3,
                                              LEGAL_ENTITY_NAME,
                                              MBR_PD_PREM_AMT,
                                              MBR_DELQ_PREM_AMT,
                                              ER_PD_PREM_AMT,
                                              ER_DELQ_PREM_AMT,
                                              CURRENT_SIGNATURE_DATE,
                                              ORIGINAL_SIGNATURE_DATE,
                                              ORIGINAL_INSURED_PLAN_ID,
                                              WRITING_AGENT,
                                              SELLING_AGENT,
                                              ORIGINAL_SELLING_AGENT,
                                              RET_TYP_ID,
                                              ER_SKEY,
                                              DCM_INSURED_PLAN_ID,
                                              DCM_INSURED_PLAN_EFF_DATE,
                                              DCM_PLAN_CD,
                                              DCM_SIGNATURE_DATE,
                                              DCM_WRITING_AGENT,
                                              DCM_DERIVED_COMPAS_AGENT,
                                              AGT_WRT_SKEY,
                                              AGT_SEL_ORIG_SKEY,
                                              AGT_SEL_SKEY,
                                              AGT_DCM_WRT_SKEY,
                                              D_DSCNT_ANNL_PAYR_SK,
                                              D_DSCNT_EFT_SK,
                                              D_DSCNT_ERLY_ENRL_SK,
                                              D_DSCNT_LNGVTY_SK,
                                              D_DSCNT_MULTI_INSD_SK,
                                              D_SURCHRG_TBCC_USER_SK,
                                              D_SURCHRG_TIER_SK,
                                              D_INSD_PLN_PRFL_SK,
                                              D_CALC_RT_SK,
                                              MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
                                              DSCNT_PD_ANNL_PAYR_AMT,
                                              DSCNT_PD_EFT_AMT,
                                              DSCNT_PD_ERLY_ENRL_AMT,
                                              DSCNT_PD_LNGVTY_AMT,
                                              DSCNT_PD_MULTI_INSD_AMT,
                                              SURCHRG_PD_TBCC_USER_AMT,
                                              SURCHRG_PD_TIER_AMT,
                                              DSCNT_DELQ_ANNL_PAYR_AMT,
                                              DSCNT_DELQ_EFT_AMT,
                                              DSCNT_DELQ_ERLY_ENRL_AMT,
                                              DSCNT_DELQ_LNGVTY_AMT,
                                              DSCNT_DELQ_MULTI_INSD_AMT,
                                              SURCHRG_DELQ_TBCC_USER_AMT,
                                              SURCHRG_DELQ_TIER_AMT,
                                              ORIGINAL_REFERRAL_AGENT,
                                              REFERRAL_AGENT,
                                              AGT_REF_ORIG_D_AGT_SK,
                                              AGT_REF_D_AGT_SK,
                                              D_MBR_INFO_SK,
                                              D_PLN_BEN_MOD_SK,
                                              RES_D_GEO_XREF_SK,
                                              PLN_ISS_D_GEO_XREF_SK,
                                              D_RTNG_AREA_SK,
                                              F_APPL_TRANS_DAY_SK,
                                              CERT_SALE_CHNL_LVL_1,
                                              CERT_SALE_CHNL_LVL_2,
                                              CERT_SALE_CHNL_LVL_3,
                                              PRDCT_SALE_CHNL_LVL_1,
                                              PRDCT_SALE_CHNL_LVL_2,
                                              PRDCT_SALE_CHNL_LVL_3,
                                              D_NEW_TO_MEDCR_SK,
                                              DSCNT_PD_NEW_TO_MEDCR_AMT,
                                              DSCNT_DLQNT_NEW_TO_MEDCR_AMT,
                                              D_UNDWR_GUID_SK,
                                              D_AGT_POL_SK,
                                              PRO_RATED_CREDIT,
                                              ENT_AGE_EFFDT)
        WITH
            INSURED_PLAN_DEL_ID
            AS
                (SELECT DISTINCT INSURED_PLAN_ID
                   FROM SRC_COMPAS_D.ADT_INSURED_PLAN
                  WHERE     ADT_ROW_CREAT_BY_BTCH_ID > v_etllastbatchid
                        AND ADT_TYP_CD = ''D''),
                      INS_PLAN_BILLING_BUCKET_DEL_ID
            AS 
                (SELECT DISTINCT ADT.INDIVIDUAL_ID,ADT.INSURED_PLAN_ID,CD.MONTHDATE AS PREMIUM_DUE_DATE FROM
SRC_RIA.ADT_PREM_BUCKET_FACT  ADT
JOIN BDR_DM.TEMP_RIA_MONTH_DATE CD
ON CD.MONTHDATE BETWEEN ADT.START_DATE AND ADT.END_DATE
LEFT JOIN SRC_RIA.PREM_BUCKET_FACT RIA
ON ADT.INDIVIDUAL_ID=SRC_RIA.INDIVIDUAL_ID AND ADT.INSURED_PLAN_ID=SRC_RIA.INSURED_PLAN_ID AND CD.MONTHDATE BETWEEN SRC_RIA.START_DATE AND SRC_RIA.END_DATE  AND SRC_RIA.ETL_LST_BTCH_ID > v_etllastbatchid
                  WHERE     ADT.ADT_ROW_CREAT_BY_BTCH_ID > v_etllastbatchid
                        AND ADT.ADT_TYP_CD = ''D''
						AND SRC_RIA.INDIVIDUAL_ID IS NULL),
            HOUSEHOLD_DEL_ID
            AS
                (SELECT DISTINCT HOUSEHOLD_ID
                   FROM SRC_COMPAS_D.ADT_HOUSEHOLD
                  WHERE     ADT_ROW_CREAT_BY_BTCH_ID > v_etllastbatchid
                        AND ADT_TYP_CD = ''D''),
            HOUSEHOLD_ADDRESS_DEL_ID
            AS
                (SELECT DISTINCT HOUSEHOLD_ADDRESS_ID
                   FROM SRC_COMPAS_D.ADT_HOUSEHOLD_ADDRESS
                  WHERE     ADT_ROW_CREAT_BY_BTCH_ID > v_etllastbatchid
                        AND ADT_TYP_CD = ''D''
                        AND ADDRESS_TYPE_ID = 1
                        AND NVL (DELETE_IND, ''N'') = ''N''),
            INDIVIDUAL_DEL_ID
            AS
                (SELECT DISTINCT INDIVIDUAL_ID
                   FROM SRC_COMPAS_D.ADT_INDIVIDUAL
                  WHERE     ADT_ROW_CREAT_BY_BTCH_ID > v_etllastbatchid
                        AND ADT_TYP_CD = ''D''),
            HOUSEHOLD_PROFILE_DEL_ID
            AS
                (SELECT DISTINCT HOUSEHOLD_ID
                   FROM SRC_COMPAS_D.ADT_HOUSEHOLD_PROFILE
                  WHERE     ADT_ROW_CREAT_BY_BTCH_ID > v_etllastbatchid
                        AND ADT_TYP_CD = ''D''),
            HOUSEHOLD_MEMBER_DEL_ID
            AS
                (SELECT DISTINCT HOUSEHOLD_ID
                   FROM SRC_COMPAS_D.ADT_HOUSEHOLD_MEMBER
                  WHERE     ADT_ROW_CREAT_BY_BTCH_ID > v_etllastbatchid
                        AND ADT_TYP_CD = ''D'')
            SELECT BL.HOUSEHOLD_ID,
                   BL.INDIVIDUAL_ID,
                   BL.INS_PLAN_BILLING_BUCKET_ID,
                   BL.INSURED_PLAN_ID,
                   BL.HOUSEHOLD_ADDRESS_ID,
                   BL.PREMIUM_DUE_DATE,
                   v_activitydate
                       AS ACTIVITY_DATE,
                   NVL (BL.PAID_CERT, 0) * -1
                       AS PAID_CERT,
                   NVL (BL.DEL_CERT, 0) * -1
                       AS DEL_CERT,
                   NVL (BL.TERM_CERT, 0) * -1
                       AS TERM_CERT,
                   NVL (BL.PAID_PREMIUM_AMT, 0) * -1
                       AS PAID_PREMIUM_AMT,
                   NVL (BL.DELINQUENT_PREMIUM_DUE_AMT, 0) * -1
                       AS DELINQUENT_PREMIUM_DUE_AMT,
                   BL.PLAN_CD,
                   BL.BENEFIT_MOD_CATEGORY_ID,
                   BL.INSURED_PLAN_EFFECTIVE_DATE,
                   BL.INSURED_PLAN_TERMINATION_DATE,
                   BL.CERT_TERMINATION_DATE,
                   BL.STATE_CD,
                   BL.ZIP_CD,
                   BL.COUNTRY_CD,
                   BL.ISSUE_STATE,
                   BL.ISSUE_COUNTRY_CD,
                   BL.ISSUE_ZIP_CD,
                   BL.GENDER_CD,
                   BL.DATE_OF_BIRTH,
                   ''O''
                       AS TRANS_TYPE,
                   BL.CERT_ACQN_CHNL_LEVEL3,
                   BL.ACCOUNT_NUMBER,
                   BL.TERMINATION_REASON_NAME,
                   BL.CONSERVATION_REASON_NAME,
                   BL.PLAN_GROUP,
                   BL.PRODUCT_GROUP,
                   BL.CERT_ACTV_LVL_3_TXT,
                   BL.UNDWR_TAG_KEY,
                   BL.PRDCT_EFF_DT,
                   BL.PRDCT_ACQN_CHNL_LEVEL3,
                   BL.LEGAL_ENTITY_NAME,
                   NVL (BL.MBR_PD_PREM_AMT, 0) * -1
                       AS MBR_PD_PREM_AMT,
                   NVL (BL.MBR_DELQ_PREM_AMT, 0) * -1
                       AS MBR_DELQ_PREM_AMT,
                   NVL (BL.ER_PD_PREM_AMT, 0) * -1
                       AS ER_PD_PREM_AMT,
                   NVL (BL.ER_DELQ_PREM_AMT, 0) * -1
                       AS ER_DELQ_PREM_AMT,
                   BL.CURRENT_SIGNATURE_DATE,
                   BL.ORIGINAL_SIGNATURE_DATE,
                   BL.ORIGINAL_INSURED_PLAN_ID,
                   BL.WRITING_AGENT,
                   BL.SELLING_AGENT,
                   BL.ORIGINAL_SELLING_AGENT,
                   BL.RET_TYP_ID,
                   BL.ER_SKEY,
                   BL.DCM_INSURED_PLAN_ID,
                   BL.DCM_INSURED_PLAN_EFF_DATE,
                   BL.DCM_PLAN_CD,
                   BL.DCM_SIGNATURE_DATE,
                   BL.DCM_WRITING_AGENT,
                   BL.DCM_DERIVED_COMPAS_AGENT,
                   BL.AGT_WRT_SKEY,
                   BL.AGT_SEL_ORIG_SKEY,
                   BL.AGT_SEL_SKEY,
                   BL.AGT_DCM_WRT_SKEY,
                   BL.D_DSCNT_ANNL_PAYR_SK,
                   BL.D_DSCNT_EFT_SK,
                   BL.D_DSCNT_ERLY_ENRL_SK,
                   BL.D_DSCNT_LNGVTY_SK,
                   BL.D_DSCNT_MULTI_INSD_SK,
                   BL.D_SURCHRG_TBCC_USER_SK,
                   BL.D_SURCHRG_TIER_SK,
                   BL.D_INSD_PLN_PRFL_SK,
                   BL.D_CALC_RT_SK,
                   BL.MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
                   NVL (BL.DSCNT_PD_ANNL_PAYR_AMT, 0) * -1
                       AS DSCNT_PD_ANNL_PAYR_AMT,
                   NVL (BL.DSCNT_PD_EFT_AMT, 0) * -1
                       AS DSCNT_PD_EFT_AMT,
                   NVL (BL.DSCNT_PD_ERLY_ENRL_AMT, 0) * -1
                       AS DSCNT_PD_ERLY_ENRL_AMT,
                   NVL (BL.DSCNT_PD_LNGVTY_AMT, 0) * -1
                       AS DSCNT_PD_LNGVTY_AMT,
                   NVL (BL.DSCNT_PD_MULTI_INSD_AMT, 0) * -1
                       AS DSCNT_PD_MULTI_INSD_AMT,
                   NVL (BL.SURCHRG_PD_TBCC_USER_AMT, 0) * -1
                       AS SURCHRG_PD_TBCC_USER_AMT,
                   NVL (BL.SURCHRG_PD_TIER_AMT, 0) * -1
                       AS SURCHRG_PD_TIER_AMT,
                   NVL (BL.DSCNT_DELQ_ANNL_PAYR_AMT, 0) * -1
                       AS DSCNT_DELQ_ANNL_PAYR_AMT,
                   NVL (BL.DSCNT_DELQ_EFT_AMT, 0) * -1
                       AS DSCNT_DELQ_EFT_AMT,
                   NVL (BL.DSCNT_DELQ_ERLY_ENRL_AMT, 0) * -1
                       AS DSCNT_DELQ_ERLY_ENRL_AMT,
                   NVL (BL.DSCNT_DELQ_LNGVTY_AMT, 0) * -1
                       AS DSCNT_DELQ_LNGVTY_AMT,
                   NVL (BL.DSCNT_DELQ_MULTI_INSD_AMT, 0) * -1
                       AS DSCNT_DELQ_MULTI_INSD_AMT,
                   NVL (BL.SURCHRG_DELQ_TBCC_USER_AMT, 0) * -1
                       AS SURCHRG_DELQ_TBCC_USER_AMT,
                   NVL (BL.SURCHRG_DELQ_TIER_AMT, 0) * -1
                       AS SURCHRG_DELQ_TIER_AMT,
                   BL.ORIGINAL_REFERRAL_AGENT,
                   BL.REFERRAL_AGENT,
                   BL.AGT_REF_ORIG_D_AGT_SK,
                   BL.AGT_REF_D_AGT_SK,
                   BL.D_MBR_INFO_SK,
                   BL.D_PLN_BEN_MOD_SK,
                   BL.RES_D_GEO_XREF_SK,
                   BL.PLN_ISS_D_GEO_XREF_SK,
                   BL.D_RTNG_AREA_SK,
                   BL.F_APPL_TRANS_DAY_SK,
                   BL.CERT_SALE_CHNL_LVL_1,
                   BL.CERT_SALE_CHNL_LVL_2,
                   BL.CERT_SALE_CHNL_LVL_3,
                   BL.PRDCT_SALE_CHNL_LVL_1,
                   BL.PRDCT_SALE_CHNL_LVL_2,
                   BL.PRDCT_SALE_CHNL_LVL_3,
                   BL.D_NEW_TO_MEDCR_SK,
                   NVL (BL.DSCNT_PD_NEW_TO_MEDCR_AMT, 0) * -1
                       AS DSCNT_PD_NEW_TO_MEDCR_AMT,
                   NVL (BL.DSCNT_DLQNT_NEW_TO_MEDCR_AMT, 0) * -1
                       AS DSCNT_DLQNT_NEW_TO_MEDCR_AMT,
                   BL.D_UNDWR_GUID_SK,
                   BL.D_AGT_POL_SK,
                   NVL (BL.PRO_RATED_CREDIT, 0) * -1
                       AS PRO_RATED_CREDIT,
                   BL.ENT_AGE_EFFDT
              FROM BDR_DM.WRK_PREMIUM_DATA_BASELINE  BL
                   INNER JOIN INSURED_PLAN_DEL_ID IP
                       ON BL.INSURED_PLAN_ID = IP.INSURED_PLAN_ID
            UNION
            SELECT BL.HOUSEHOLD_ID,
                   BL.INDIVIDUAL_ID,
                   BL.INS_PLAN_BILLING_BUCKET_ID,
                   BL.INSURED_PLAN_ID,
                   BL.HOUSEHOLD_ADDRESS_ID,
                   BL.PREMIUM_DUE_DATE,
                   v_activitydate
                       AS ACTIVITY_DATE,
                   NVL (BL.PAID_CERT, 0) * -1
                       AS PAID_CERT,
                   NVL (BL.DEL_CERT, 0) * -1
                       AS DEL_CERT,
                   NVL (BL.TERM_CERT, 0) * -1
                       AS TERM_CERT,
                   NVL (BL.PAID_PREMIUM_AMT, 0) * -1
                       AS PAID_PREMIUM_AMT,
                   NVL (BL.DELINQUENT_PREMIUM_DUE_AMT, 0) * -1
                       AS DELINQUENT_PREMIUM_DUE_AMT,
                   BL.PLAN_CD,
                   BL.BENEFIT_MOD_CATEGORY_ID,
                   BL.INSURED_PLAN_EFFECTIVE_DATE,
                   BL.INSURED_PLAN_TERMINATION_DATE,
                   BL.CERT_TERMINATION_DATE,
                   BL.STATE_CD,
                   BL.ZIP_CD,
                   BL.COUNTRY_CD,
                   BL.ISSUE_STATE,
                   BL.ISSUE_COUNTRY_CD,
                   BL.ISSUE_ZIP_CD,
                   BL.GENDER_CD,
                   BL.DATE_OF_BIRTH,
                   ''O''
                       AS TRANS_TYPE,
                   BL.CERT_ACQN_CHNL_LEVEL3,
                   BL.ACCOUNT_NUMBER,
                   BL.TERMINATION_REASON_NAME,
                   BL.CONSERVATION_REASON_NAME,
                   BL.PLAN_GROUP,
                   BL.PRODUCT_GROUP,
                   BL.CERT_ACTV_LVL_3_TXT,
                   BL.UNDWR_TAG_KEY,
                   BL.PRDCT_EFF_DT,
                   BL.PRDCT_ACQN_CHNL_LEVEL3,
                   BL.LEGAL_ENTITY_NAME,
                   NVL (BL.MBR_PD_PREM_AMT, 0) * -1
                       AS MBR_PD_PREM_AMT,
                   NVL (BL.MBR_DELQ_PREM_AMT, 0) * -1
                       AS MBR_DELQ_PREM_AMT,
                   NVL (BL.ER_PD_PREM_AMT, 0) * -1
                       AS ER_PD_PREM_AMT,
                   NVL (BL.ER_DELQ_PREM_AMT, 0) * -1
                       AS ER_DELQ_PREM_AMT,
                   BL.CURRENT_SIGNATURE_DATE,
                   BL.ORIGINAL_SIGNATURE_DATE,
                   BL.ORIGINAL_INSURED_PLAN_ID,
                   BL.WRITING_AGENT,
                   BL.SELLING_AGENT,
                   BL.ORIGINAL_SELLING_AGENT,
                   BL.RET_TYP_ID,
                   BL.ER_SKEY,
                   BL.DCM_INSURED_PLAN_ID,
                   BL.DCM_INSURED_PLAN_EFF_DATE,
                   BL.DCM_PLAN_CD,
                   BL.DCM_SIGNATURE_DATE,
                   BL.DCM_WRITING_AGENT,
                   BL.DCM_DERIVED_COMPAS_AGENT,
                   BL.AGT_WRT_SKEY,
                   BL.AGT_SEL_ORIG_SKEY,
                   BL.AGT_SEL_SKEY,
                   BL.AGT_DCM_WRT_SKEY,
                   BL.D_DSCNT_ANNL_PAYR_SK,
                   BL.D_DSCNT_EFT_SK,
                   BL.D_DSCNT_ERLY_ENRL_SK,
                   BL.D_DSCNT_LNGVTY_SK,
                   BL.D_DSCNT_MULTI_INSD_SK,
                   BL.D_SURCHRG_TBCC_USER_SK,
                   BL.D_SURCHRG_TIER_SK,
                   BL.D_INSD_PLN_PRFL_SK,
                   BL.D_CALC_RT_SK,
                   BL.MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
                   NVL (BL.DSCNT_PD_ANNL_PAYR_AMT, 0) * -1
                       AS DSCNT_PD_ANNL_PAYR_AMT,
                   NVL (BL.DSCNT_PD_EFT_AMT, 0) * -1
                       AS DSCNT_PD_EFT_AMT,
                   NVL (BL.DSCNT_PD_ERLY_ENRL_AMT, 0) * -1
                       AS DSCNT_PD_ERLY_ENRL_AMT,
                   NVL (BL.DSCNT_PD_LNGVTY_AMT, 0) * -1
                       AS DSCNT_PD_LNGVTY_AMT,
                   NVL (BL.DSCNT_PD_MULTI_INSD_AMT, 0) * -1
                       AS DSCNT_PD_MULTI_INSD_AMT,
                   NVL (BL.SURCHRG_PD_TBCC_USER_AMT, 0) * -1
                       AS SURCHRG_PD_TBCC_USER_AMT,
                   NVL (BL.SURCHRG_PD_TIER_AMT, 0) * -1
                       AS SURCHRG_PD_TIER_AMT,
                   NVL (BL.DSCNT_DELQ_ANNL_PAYR_AMT, 0) * -1
                       AS DSCNT_DELQ_ANNL_PAYR_AMT,
                   NVL (BL.DSCNT_DELQ_EFT_AMT, 0) * -1
                       AS DSCNT_DELQ_EFT_AMT,
                   NVL (BL.DSCNT_DELQ_ERLY_ENRL_AMT, 0) * -1
                       AS DSCNT_DELQ_ERLY_ENRL_AMT,
                   NVL (BL.DSCNT_DELQ_LNGVTY_AMT, 0) * -1
                       AS DSCNT_DELQ_LNGVTY_AMT,
                   NVL (BL.DSCNT_DELQ_MULTI_INSD_AMT, 0) * -1
                       AS DSCNT_DELQ_MULTI_INSD_AMT,
                   NVL (BL.SURCHRG_DELQ_TBCC_USER_AMT, 0) * -1
                       AS SURCHRG_DELQ_TBCC_USER_AMT,
                   NVL (BL.SURCHRG_DELQ_TIER_AMT, 0) * -1
                       AS SURCHRG_DELQ_TIER_AMT,
                   BL.ORIGINAL_REFERRAL_AGENT,
                   BL.REFERRAL_AGENT,
                   BL.AGT_REF_ORIG_D_AGT_SK,
                   BL.AGT_REF_D_AGT_SK,
                   BL.D_MBR_INFO_SK,
                   BL.D_PLN_BEN_MOD_SK,
                   BL.RES_D_GEO_XREF_SK,
                   BL.PLN_ISS_D_GEO_XREF_SK,
                   BL.D_RTNG_AREA_SK,
                   BL.F_APPL_TRANS_DAY_SK,
                   BL.CERT_SALE_CHNL_LVL_1,
                   BL.CERT_SALE_CHNL_LVL_2,
                   BL.CERT_SALE_CHNL_LVL_3,
                   BL.PRDCT_SALE_CHNL_LVL_1,
                   BL.PRDCT_SALE_CHNL_LVL_2,
                   BL.PRDCT_SALE_CHNL_LVL_3,
                   BL.D_NEW_TO_MEDCR_SK,
                   NVL (BL.DSCNT_PD_NEW_TO_MEDCR_AMT, 0) * -1
                       AS DSCNT_PD_NEW_TO_MEDCR_AMT,
                   NVL (BL.DSCNT_DLQNT_NEW_TO_MEDCR_AMT, 0) * -1
                       AS DSCNT_DLQNT_NEW_TO_MEDCR_AMT,
                   BL.D_UNDWR_GUID_SK,
                   BL.D_AGT_POL_SK,
                   NVL (BL.PRO_RATED_CREDIT, 0) * -1
                       AS PRO_RATED_CREDIT,
                   BL.ENT_AGE_EFFDT
              FROM BDR_DM.WRK_PREMIUM_DATA_BASELINE  BL
                  

                   INNER JOIN INS_PLAN_BILLING_BUCKET_DEL_ID IPBB 
                       ON     BL.INDIVIDUAL_ID = IPBB.INDIVIDUAL_ID
                          AND BL.INSURED_PLAN_ID = IPBB.INSURED_PLAN_ID
                          AND BL.PREMIUM_DUE_DATE = IPBB.PREMIUM_DUE_DATE
						  AND BL.CERT_TERMINATION_DATE <> IPBB.PREMIUM_DUE_DATE    
            UNION
            SELECT BL.HOUSEHOLD_ID,
                   BL.INDIVIDUAL_ID,
                   BL.INS_PLAN_BILLING_BUCKET_ID,
                   BL.INSURED_PLAN_ID,
                   BL.HOUSEHOLD_ADDRESS_ID,
                   BL.PREMIUM_DUE_DATE,
                   v_activitydate
                       AS ACTIVITY_DATE,
                   NVL (BL.PAID_CERT, 0) * -1
                       AS PAID_CERT,
                   NVL (BL.DEL_CERT, 0) * -1
                       AS DEL_CERT,
                   NVL (BL.TERM_CERT, 0) * -1
                       AS TERM_CERT,
                   NVL (BL.PAID_PREMIUM_AMT, 0) * -1
                       AS PAID_PREMIUM_AMT,
                   NVL (BL.DELINQUENT_PREMIUM_DUE_AMT, 0) * -1
                       AS DELINQUENT_PREMIUM_DUE_AMT,
                   BL.PLAN_CD,
                   BL.BENEFIT_MOD_CATEGORY_ID,
                   BL.INSURED_PLAN_EFFECTIVE_DATE,
                   BL.INSURED_PLAN_TERMINATION_DATE,
                   BL.CERT_TERMINATION_DATE,
                   BL.STATE_CD,
                   BL.ZIP_CD,
                   BL.COUNTRY_CD,
                   BL.ISSUE_STATE,
                   BL.ISSUE_COUNTRY_CD,
                   BL.ISSUE_ZIP_CD,
                   BL.GENDER_CD,
                   BL.DATE_OF_BIRTH,
                   ''O''
                       AS TRANS_TYPE,
                   BL.CERT_ACQN_CHNL_LEVEL3,
                   BL.ACCOUNT_NUMBER,
                   BL.TERMINATION_REASON_NAME,
                   BL.CONSERVATION_REASON_NAME,
                   BL.PLAN_GROUP,
                   BL.PRODUCT_GROUP,
                   BL.CERT_ACTV_LVL_3_TXT,
                   BL.UNDWR_TAG_KEY,
                   BL.PRDCT_EFF_DT,
                   BL.PRDCT_ACQN_CHNL_LEVEL3,
                   BL.LEGAL_ENTITY_NAME,
                   NVL (BL.MBR_PD_PREM_AMT, 0) * -1
                       AS MBR_PD_PREM_AMT,
                   NVL (BL.MBR_DELQ_PREM_AMT, 0) * -1
                       AS MBR_DELQ_PREM_AMT,
                   NVL (BL.ER_PD_PREM_AMT, 0) * -1
                       AS ER_PD_PREM_AMT,
                   NVL (BL.ER_DELQ_PREM_AMT, 0) * -1
                       AS ER_DELQ_PREM_AMT,
                   BL.CURRENT_SIGNATURE_DATE,
                   BL.ORIGINAL_SIGNATURE_DATE,
                   BL.ORIGINAL_INSURED_PLAN_ID,
                   BL.WRITING_AGENT,
                   BL.SELLING_AGENT,
                   BL.ORIGINAL_SELLING_AGENT,
                   BL.RET_TYP_ID,
                   BL.ER_SKEY,
                   BL.DCM_INSURED_PLAN_ID,
                   BL.DCM_INSURED_PLAN_EFF_DATE,
                   BL.DCM_PLAN_CD,
                   BL.DCM_SIGNATURE_DATE,
                   BL.DCM_WRITING_AGENT,
                   BL.DCM_DERIVED_COMPAS_AGENT,
                   BL.AGT_WRT_SKEY,
                   BL.AGT_SEL_ORIG_SKEY,
                   BL.AGT_SEL_SKEY,
                   BL.AGT_DCM_WRT_SKEY,
                   BL.D_DSCNT_ANNL_PAYR_SK,
                   BL.D_DSCNT_EFT_SK,
                   BL.D_DSCNT_ERLY_ENRL_SK,
                   BL.D_DSCNT_LNGVTY_SK,
                   BL.D_DSCNT_MULTI_INSD_SK,
                   BL.D_SURCHRG_TBCC_USER_SK,
                   BL.D_SURCHRG_TIER_SK,
                   BL.D_INSD_PLN_PRFL_SK,
                   BL.D_CALC_RT_SK,
                   BL.MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
                   NVL (BL.DSCNT_PD_ANNL_PAYR_AMT, 0) * -1
                       AS DSCNT_PD_ANNL_PAYR_AMT,
                   NVL (BL.DSCNT_PD_EFT_AMT, 0) * -1
                       AS DSCNT_PD_EFT_AMT,
                   NVL (BL.DSCNT_PD_ERLY_ENRL_AMT, 0) * -1
                       AS DSCNT_PD_ERLY_ENRL_AMT,
                   NVL (BL.DSCNT_PD_LNGVTY_AMT, 0) * -1
                       AS DSCNT_PD_LNGVTY_AMT,
                   NVL (BL.DSCNT_PD_MULTI_INSD_AMT, 0) * -1
                       AS DSCNT_PD_MULTI_INSD_AMT,
                   NVL (BL.SURCHRG_PD_TBCC_USER_AMT, 0) * -1
                       AS SURCHRG_PD_TBCC_USER_AMT,
                   NVL (BL.SURCHRG_PD_TIER_AMT, 0) * -1
                       AS SURCHRG_PD_TIER_AMT,
                   NVL (BL.DSCNT_DELQ_ANNL_PAYR_AMT, 0) * -1
                       AS DSCNT_DELQ_ANNL_PAYR_AMT,
                   NVL (BL.DSCNT_DELQ_EFT_AMT, 0) * -1
                       AS DSCNT_DELQ_EFT_AMT,
                   NVL (BL.DSCNT_DELQ_ERLY_ENRL_AMT, 0) * -1
                       AS DSCNT_DELQ_ERLY_ENRL_AMT,
                   NVL (BL.DSCNT_DELQ_LNGVTY_AMT, 0) * -1
                       AS DSCNT_DELQ_LNGVTY_AMT,
                   NVL (BL.DSCNT_DELQ_MULTI_INSD_AMT, 0) * -1
                       AS DSCNT_DELQ_MULTI_INSD_AMT,
                   NVL (BL.SURCHRG_DELQ_TBCC_USER_AMT, 0) * -1
                       AS SURCHRG_DELQ_TBCC_USER_AMT,
                   NVL (BL.SURCHRG_DELQ_TIER_AMT, 0) * -1
                       AS SURCHRG_DELQ_TIER_AMT,
                   BL.ORIGINAL_REFERRAL_AGENT,
                   BL.REFERRAL_AGENT,
                   BL.AGT_REF_ORIG_D_AGT_SK,
                   BL.AGT_REF_D_AGT_SK,
                   BL.D_MBR_INFO_SK,
                   BL.D_PLN_BEN_MOD_SK,
                   BL.RES_D_GEO_XREF_SK,
                   BL.PLN_ISS_D_GEO_XREF_SK,
                   BL.D_RTNG_AREA_SK,
                   BL.F_APPL_TRANS_DAY_SK,
                   BL.CERT_SALE_CHNL_LVL_1,
                   BL.CERT_SALE_CHNL_LVL_2,
                   BL.CERT_SALE_CHNL_LVL_3,
                   BL.PRDCT_SALE_CHNL_LVL_1,
                   BL.PRDCT_SALE_CHNL_LVL_2,
                   BL.PRDCT_SALE_CHNL_LVL_3,
                   BL.D_NEW_TO_MEDCR_SK,
                   NVL (BL.DSCNT_PD_NEW_TO_MEDCR_AMT, 0) * -1
                       AS DSCNT_PD_NEW_TO_MEDCR_AMT,
                   NVL (BL.DSCNT_DLQNT_NEW_TO_MEDCR_AMT, 0) * -1
                       AS DSCNT_DLQNT_NEW_TO_MEDCR_AMT,
                   BL.D_UNDWR_GUID_SK,
                   BL.D_AGT_POL_SK,
                   NVL (BL.PRO_RATED_CREDIT, 0) * -1
                       AS PRO_RATED_CREDIT,
                   BL.ENT_AGE_EFFDT
              FROM BDR_DM.WRK_PREMIUM_DATA_BASELINE  BL
                   INNER JOIN HOUSEHOLD_DEL_ID H
                       ON BL.HOUSEHOLD_ID = H.HOUSEHOLD_ID
            UNION
            SELECT BL.HOUSEHOLD_ID,
                   BL.INDIVIDUAL_ID,
                   BL.INS_PLAN_BILLING_BUCKET_ID,
                   BL.INSURED_PLAN_ID,
                   BL.HOUSEHOLD_ADDRESS_ID,
                   BL.PREMIUM_DUE_DATE,
                   v_activitydate
                       AS ACTIVITY_DATE,
                   NVL (BL.PAID_CERT, 0) * -1
                       AS PAID_CERT,
                   NVL (BL.DEL_CERT, 0) * -1
                       AS DEL_CERT,
                   NVL (BL.TERM_CERT, 0) * -1
                       AS TERM_CERT,
                   NVL (BL.PAID_PREMIUM_AMT, 0) * -1
                       AS PAID_PREMIUM_AMT,
                   NVL (BL.DELINQUENT_PREMIUM_DUE_AMT, 0) * -1
                       AS DELINQUENT_PREMIUM_DUE_AMT,
                   BL.PLAN_CD,
                   BL.BENEFIT_MOD_CATEGORY_ID,
                   BL.INSURED_PLAN_EFFECTIVE_DATE,
                   BL.INSURED_PLAN_TERMINATION_DATE,
                   BL.CERT_TERMINATION_DATE,
                   BL.STATE_CD,
                   BL.ZIP_CD,
                   BL.COUNTRY_CD,
                   BL.ISSUE_STATE,
                   BL.ISSUE_COUNTRY_CD,
                   BL.ISSUE_ZIP_CD,
                   BL.GENDER_CD,
                   BL.DATE_OF_BIRTH,
                   ''O''
                       AS TRANS_TYPE,
                   BL.CERT_ACQN_CHNL_LEVEL3,
                   BL.ACCOUNT_NUMBER,
                   BL.TERMINATION_REASON_NAME,
                   BL.CONSERVATION_REASON_NAME,
                   BL.PLAN_GROUP,
                   BL.PRODUCT_GROUP,
                   BL.CERT_ACTV_LVL_3_TXT,
                   BL.UNDWR_TAG_KEY,
                   BL.PRDCT_EFF_DT,
                   BL.PRDCT_ACQN_CHNL_LEVEL3,
                   BL.LEGAL_ENTITY_NAME,
                   NVL (BL.MBR_PD_PREM_AMT, 0) * -1
                       AS MBR_PD_PREM_AMT,
                   NVL (BL.MBR_DELQ_PREM_AMT, 0) * -1
                       AS MBR_DELQ_PREM_AMT,
                   NVL (BL.ER_PD_PREM_AMT, 0) * -1
                       AS ER_PD_PREM_AMT,
                   NVL (BL.ER_DELQ_PREM_AMT, 0) * -1
                       AS ER_DELQ_PREM_AMT,
                   BL.CURRENT_SIGNATURE_DATE,
                   BL.ORIGINAL_SIGNATURE_DATE,
                   BL.ORIGINAL_INSURED_PLAN_ID,
                   BL.WRITING_AGENT,
                   BL.SELLING_AGENT,
                   BL.ORIGINAL_SELLING_AGENT,
                   BL.RET_TYP_ID,
                   BL.ER_SKEY,
                   BL.DCM_INSURED_PLAN_ID,
                   BL.DCM_INSURED_PLAN_EFF_DATE,
                   BL.DCM_PLAN_CD,
                   BL.DCM_SIGNATURE_DATE,
                   BL.DCM_WRITING_AGENT,
                   BL.DCM_DERIVED_COMPAS_AGENT,
                   BL.AGT_WRT_SKEY,
                   BL.AGT_SEL_ORIG_SKEY,
                   BL.AGT_SEL_SKEY,
                   BL.AGT_DCM_WRT_SKEY,
                   BL.D_DSCNT_ANNL_PAYR_SK,
                   BL.D_DSCNT_EFT_SK,
                   BL.D_DSCNT_ERLY_ENRL_SK,
                   BL.D_DSCNT_LNGVTY_SK,
                   BL.D_DSCNT_MULTI_INSD_SK,
                   BL.D_SURCHRG_TBCC_USER_SK,
                   BL.D_SURCHRG_TIER_SK,
                   BL.D_INSD_PLN_PRFL_SK,
                   BL.D_CALC_RT_SK,
                   BL.MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
                   NVL (BL.DSCNT_PD_ANNL_PAYR_AMT, 0) * -1
                       AS DSCNT_PD_ANNL_PAYR_AMT,
                   NVL (BL.DSCNT_PD_EFT_AMT, 0) * -1
                       AS DSCNT_PD_EFT_AMT,
                   NVL (BL.DSCNT_PD_ERLY_ENRL_AMT, 0) * -1
                       AS DSCNT_PD_ERLY_ENRL_AMT,
                   NVL (BL.DSCNT_PD_LNGVTY_AMT, 0) * -1
                       AS DSCNT_PD_LNGVTY_AMT,
                   NVL (BL.DSCNT_PD_MULTI_INSD_AMT, 0) * -1
                       AS DSCNT_PD_MULTI_INSD_AMT,
                   NVL (BL.SURCHRG_PD_TBCC_USER_AMT, 0) * -1
                       AS SURCHRG_PD_TBCC_USER_AMT,
                   NVL (BL.SURCHRG_PD_TIER_AMT, 0) * -1
                       AS SURCHRG_PD_TIER_AMT,
                   NVL (BL.DSCNT_DELQ_ANNL_PAYR_AMT, 0) * -1
                       AS DSCNT_DELQ_ANNL_PAYR_AMT,
                   NVL (BL.DSCNT_DELQ_EFT_AMT, 0) * -1
                       AS DSCNT_DELQ_EFT_AMT,
                   NVL (BL.DSCNT_DELQ_ERLY_ENRL_AMT, 0) * -1
                       AS DSCNT_DELQ_ERLY_ENRL_AMT,
                   NVL (BL.DSCNT_DELQ_LNGVTY_AMT, 0) * -1
                       AS DSCNT_DELQ_LNGVTY_AMT,
                   NVL (BL.DSCNT_DELQ_MULTI_INSD_AMT, 0) * -1
                       AS DSCNT_DELQ_MULTI_INSD_AMT,
                   NVL (BL.SURCHRG_DELQ_TBCC_USER_AMT, 0) * -1
                       AS SURCHRG_DELQ_TBCC_USER_AMT,
                   NVL (BL.SURCHRG_DELQ_TIER_AMT, 0) * -1
                       AS SURCHRG_DELQ_TIER_AMT,
                   BL.ORIGINAL_REFERRAL_AGENT,
                   BL.REFERRAL_AGENT,
                   BL.AGT_REF_ORIG_D_AGT_SK,
                   BL.AGT_REF_D_AGT_SK,
                   BL.D_MBR_INFO_SK,
                   BL.D_PLN_BEN_MOD_SK,
                   BL.RES_D_GEO_XREF_SK,
                   BL.PLN_ISS_D_GEO_XREF_SK,
                   BL.D_RTNG_AREA_SK,
                   BL.F_APPL_TRANS_DAY_SK,
                   BL.CERT_SALE_CHNL_LVL_1,
                   BL.CERT_SALE_CHNL_LVL_2,
                   BL.CERT_SALE_CHNL_LVL_3,
                   BL.PRDCT_SALE_CHNL_LVL_1,
                   BL.PRDCT_SALE_CHNL_LVL_2,
                   BL.PRDCT_SALE_CHNL_LVL_3,
                   BL.D_NEW_TO_MEDCR_SK,
                   NVL (BL.DSCNT_PD_NEW_TO_MEDCR_AMT, 0) * -1
                       AS DSCNT_PD_NEW_TO_MEDCR_AMT,
                   NVL (BL.DSCNT_DLQNT_NEW_TO_MEDCR_AMT, 0) * -1
                       AS DSCNT_DLQNT_NEW_TO_MEDCR_AMT,
                   BL.D_UNDWR_GUID_SK,
                   BL.D_AGT_POL_SK,
                   NVL (BL.PRO_RATED_CREDIT, 0) * -1
                       AS PRO_RATED_CREDIT,
                   BL.ENT_AGE_EFFDT
              FROM BDR_DM.WRK_PREMIUM_DATA_BASELINE  BL
                   INNER JOIN HOUSEHOLD_ADDRESS_DEL_ID HA
                       ON BL.HOUSEHOLD_ADDRESS_ID = HA.HOUSEHOLD_ADDRESS_ID
            UNION
            SELECT BL.HOUSEHOLD_ID,
                   BL.INDIVIDUAL_ID,
                   BL.INS_PLAN_BILLING_BUCKET_ID,
                   BL.INSURED_PLAN_ID,
                   BL.HOUSEHOLD_ADDRESS_ID,
                   BL.PREMIUM_DUE_DATE,
                   v_activitydate
                       AS ACTIVITY_DATE,
                   NVL (BL.PAID_CERT, 0) * -1
                       AS PAID_CERT,
                   NVL (BL.DEL_CERT, 0) * -1
                       AS DEL_CERT,
                   NVL (BL.TERM_CERT, 0) * -1
                       AS TERM_CERT,
                   NVL (BL.PAID_PREMIUM_AMT, 0) * -1
                       AS PAID_PREMIUM_AMT,
                   NVL (BL.DELINQUENT_PREMIUM_DUE_AMT, 0) * -1
                       AS DELINQUENT_PREMIUM_DUE_AMT,
                   BL.PLAN_CD,
                   BL.BENEFIT_MOD_CATEGORY_ID,
                   BL.INSURED_PLAN_EFFECTIVE_DATE,
                   BL.INSURED_PLAN_TERMINATION_DATE,
                   BL.CERT_TERMINATION_DATE,
                   BL.STATE_CD,
                   BL.ZIP_CD,
                   BL.COUNTRY_CD,
                   BL.ISSUE_STATE,
                   BL.ISSUE_COUNTRY_CD,
                   BL.ISSUE_ZIP_CD,
                   BL.GENDER_CD,
                   BL.DATE_OF_BIRTH,
                   ''O''
                       AS TRANS_TYPE,
                   BL.CERT_ACQN_CHNL_LEVEL3,
                   BL.ACCOUNT_NUMBER,
                   BL.TERMINATION_REASON_NAME,
                   BL.CONSERVATION_REASON_NAME,
                   BL.PLAN_GROUP,
                   BL.PRODUCT_GROUP,
                   BL.CERT_ACTV_LVL_3_TXT,
                   BL.UNDWR_TAG_KEY,
                   BL.PRDCT_EFF_DT,
                   BL.PRDCT_ACQN_CHNL_LEVEL3,
                   BL.LEGAL_ENTITY_NAME,
                   NVL (BL.MBR_PD_PREM_AMT, 0) * -1
                       AS MBR_PD_PREM_AMT,
                   NVL (BL.MBR_DELQ_PREM_AMT, 0) * -1
                       AS MBR_DELQ_PREM_AMT,
                   NVL (BL.ER_PD_PREM_AMT, 0) * -1
                       AS ER_PD_PREM_AMT,
                   NVL (BL.ER_DELQ_PREM_AMT, 0) * -1
                       AS ER_DELQ_PREM_AMT,
                   BL.CURRENT_SIGNATURE_DATE,
                   BL.ORIGINAL_SIGNATURE_DATE,
                   BL.ORIGINAL_INSURED_PLAN_ID,
                   BL.WRITING_AGENT,
                   BL.SELLING_AGENT,
                   BL.ORIGINAL_SELLING_AGENT,
                   BL.RET_TYP_ID,
                   BL.ER_SKEY,
                   BL.DCM_INSURED_PLAN_ID,
                   BL.DCM_INSURED_PLAN_EFF_DATE,
                   BL.DCM_PLAN_CD,
                   BL.DCM_SIGNATURE_DATE,
                   BL.DCM_WRITING_AGENT,
                   BL.DCM_DERIVED_COMPAS_AGENT,
                   BL.AGT_WRT_SKEY,
                   BL.AGT_SEL_ORIG_SKEY,
                   BL.AGT_SEL_SKEY,
                   BL.AGT_DCM_WRT_SKEY,
                   BL.D_DSCNT_ANNL_PAYR_SK,
                   BL.D_DSCNT_EFT_SK,
                   BL.D_DSCNT_ERLY_ENRL_SK,
                   BL.D_DSCNT_LNGVTY_SK,
                   BL.D_DSCNT_MULTI_INSD_SK,
                   BL.D_SURCHRG_TBCC_USER_SK,
                   BL.D_SURCHRG_TIER_SK,
                   BL.D_INSD_PLN_PRFL_SK,
                   BL.D_CALC_RT_SK,
                   BL.MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
                   NVL (BL.DSCNT_PD_ANNL_PAYR_AMT, 0) * -1
                       AS DSCNT_PD_ANNL_PAYR_AMT,
                   NVL (BL.DSCNT_PD_EFT_AMT, 0) * -1
                       AS DSCNT_PD_EFT_AMT,
                   NVL (BL.DSCNT_PD_ERLY_ENRL_AMT, 0) * -1
                       AS DSCNT_PD_ERLY_ENRL_AMT,
                   NVL (BL.DSCNT_PD_LNGVTY_AMT, 0) * -1
                       AS DSCNT_PD_LNGVTY_AMT,
                   NVL (BL.DSCNT_PD_MULTI_INSD_AMT, 0) * -1
                       AS DSCNT_PD_MULTI_INSD_AMT,
                   NVL (BL.SURCHRG_PD_TBCC_USER_AMT, 0) * -1
                       AS SURCHRG_PD_TBCC_USER_AMT,
                   NVL (BL.SURCHRG_PD_TIER_AMT, 0) * -1
                       AS SURCHRG_PD_TIER_AMT,
                   NVL (BL.DSCNT_DELQ_ANNL_PAYR_AMT, 0) * -1
                       AS DSCNT_DELQ_ANNL_PAYR_AMT,
                   NVL (BL.DSCNT_DELQ_EFT_AMT, 0) * -1
                       AS DSCNT_DELQ_EFT_AMT,
                   NVL (BL.DSCNT_DELQ_ERLY_ENRL_AMT, 0) * -1
                       AS DSCNT_DELQ_ERLY_ENRL_AMT,
                   NVL (BL.DSCNT_DELQ_LNGVTY_AMT, 0) * -1
                       AS DSCNT_DELQ_LNGVTY_AMT,
                   NVL (BL.DSCNT_DELQ_MULTI_INSD_AMT, 0) * -1
                       AS DSCNT_DELQ_MULTI_INSD_AMT,
                   NVL (BL.SURCHRG_DELQ_TBCC_USER_AMT, 0) * -1
                       AS SURCHRG_DELQ_TBCC_USER_AMT,
                   NVL (BL.SURCHRG_DELQ_TIER_AMT, 0) * -1
                       AS SURCHRG_DELQ_TIER_AMT,
                   BL.ORIGINAL_REFERRAL_AGENT,
                   BL.REFERRAL_AGENT,
                   BL.AGT_REF_ORIG_D_AGT_SK,
                   BL.AGT_REF_D_AGT_SK,
                   BL.D_MBR_INFO_SK,
                   BL.D_PLN_BEN_MOD_SK,
                   BL.RES_D_GEO_XREF_SK,
                   BL.PLN_ISS_D_GEO_XREF_SK,
                   BL.D_RTNG_AREA_SK,
                   BL.F_APPL_TRANS_DAY_SK,
                   BL.CERT_SALE_CHNL_LVL_1,
                   BL.CERT_SALE_CHNL_LVL_2,
                   BL.CERT_SALE_CHNL_LVL_3,
                   BL.PRDCT_SALE_CHNL_LVL_1,
                   BL.PRDCT_SALE_CHNL_LVL_2,
                   BL.PRDCT_SALE_CHNL_LVL_3,
                   BL.D_NEW_TO_MEDCR_SK,
                   NVL (BL.DSCNT_PD_NEW_TO_MEDCR_AMT, 0) * -1
                       AS DSCNT_PD_NEW_TO_MEDCR_AMT,
                   NVL (BL.DSCNT_DLQNT_NEW_TO_MEDCR_AMT, 0) * -1
                       AS DSCNT_DLQNT_NEW_TO_MEDCR_AMT,
                   BL.D_UNDWR_GUID_SK,
                   BL.D_AGT_POL_SK,
                   NVL (BL.PRO_RATED_CREDIT, 0) * -1
                       AS PRO_RATED_CREDIT,
                   BL.ENT_AGE_EFFDT
              FROM BDR_DM.WRK_PREMIUM_DATA_BASELINE  BL
                   INNER JOIN INDIVIDUAL_DEL_ID I
                       ON BL.INDIVIDUAL_ID = I.INDIVIDUAL_ID
            UNION
            SELECT BL.HOUSEHOLD_ID,
                   BL.INDIVIDUAL_ID,
                   BL.INS_PLAN_BILLING_BUCKET_ID,
                   BL.INSURED_PLAN_ID,
                   BL.HOUSEHOLD_ADDRESS_ID,
                   BL.PREMIUM_DUE_DATE,
                   v_activitydate
                       AS ACTIVITY_DATE,
                   NVL (BL.PAID_CERT, 0) * -1
                       AS PAID_CERT,
                   NVL (BL.DEL_CERT, 0) * -1
                       AS DEL_CERT,
                   NVL (BL.TERM_CERT, 0) * -1
                       AS TERM_CERT,
                   NVL (BL.PAID_PREMIUM_AMT, 0) * -1
                       AS PAID_PREMIUM_AMT,
                   NVL (BL.DELINQUENT_PREMIUM_DUE_AMT, 0) * -1
                       AS DELINQUENT_PREMIUM_DUE_AMT,
                   BL.PLAN_CD,
                   BL.BENEFIT_MOD_CATEGORY_ID,
                   BL.INSURED_PLAN_EFFECTIVE_DATE,
                   BL.INSURED_PLAN_TERMINATION_DATE,
                   BL.CERT_TERMINATION_DATE,
                   BL.STATE_CD,
                   BL.ZIP_CD,
                   BL.COUNTRY_CD,
                   BL.ISSUE_STATE,
                   BL.ISSUE_COUNTRY_CD,
                   BL.ISSUE_ZIP_CD,
                   BL.GENDER_CD,
                   BL.DATE_OF_BIRTH,
                   ''O''
                       AS TRANS_TYPE,
                   BL.CERT_ACQN_CHNL_LEVEL3,
                   BL.ACCOUNT_NUMBER,
                   BL.TERMINATION_REASON_NAME,
                   BL.CONSERVATION_REASON_NAME,
                   BL.PLAN_GROUP,
                   BL.PRODUCT_GROUP,
                   BL.CERT_ACTV_LVL_3_TXT,
                   BL.UNDWR_TAG_KEY,
                   BL.PRDCT_EFF_DT,
                   BL.PRDCT_ACQN_CHNL_LEVEL3,
                   BL.LEGAL_ENTITY_NAME,
                   NVL (BL.MBR_PD_PREM_AMT, 0) * -1
                       AS MBR_PD_PREM_AMT,
                   NVL (BL.MBR_DELQ_PREM_AMT, 0) * -1
                       AS MBR_DELQ_PREM_AMT,
                   NVL (BL.ER_PD_PREM_AMT, 0) * -1
                       AS ER_PD_PREM_AMT,
                   NVL (BL.ER_DELQ_PREM_AMT, 0) * -1
                       AS ER_DELQ_PREM_AMT,
                   BL.CURRENT_SIGNATURE_DATE,
                   BL.ORIGINAL_SIGNATURE_DATE,
                   BL.ORIGINAL_INSURED_PLAN_ID,
                   BL.WRITING_AGENT,
                   BL.SELLING_AGENT,
                   BL.ORIGINAL_SELLING_AGENT,
                   BL.RET_TYP_ID,
                   BL.ER_SKEY,
                   BL.DCM_INSURED_PLAN_ID,
                   BL.DCM_INSURED_PLAN_EFF_DATE,
                   BL.DCM_PLAN_CD,
                   BL.DCM_SIGNATURE_DATE,
                   BL.DCM_WRITING_AGENT,
                   BL.DCM_DERIVED_COMPAS_AGENT,
                   BL.AGT_WRT_SKEY,
                   BL.AGT_SEL_ORIG_SKEY,
                   BL.AGT_SEL_SKEY,
                   BL.AGT_DCM_WRT_SKEY,
                   BL.D_DSCNT_ANNL_PAYR_SK,
                   BL.D_DSCNT_EFT_SK,
                   BL.D_DSCNT_ERLY_ENRL_SK,
                   BL.D_DSCNT_LNGVTY_SK,
                   BL.D_DSCNT_MULTI_INSD_SK,
                   BL.D_SURCHRG_TBCC_USER_SK,
                   BL.D_SURCHRG_TIER_SK,
                   BL.D_INSD_PLN_PRFL_SK,
                   BL.D_CALC_RT_SK,
                   BL.MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
                   NVL (BL.DSCNT_PD_ANNL_PAYR_AMT, 0) * -1
                       AS DSCNT_PD_ANNL_PAYR_AMT,
                   NVL (BL.DSCNT_PD_EFT_AMT, 0) * -1
                       AS DSCNT_PD_EFT_AMT,
                   NVL (BL.DSCNT_PD_ERLY_ENRL_AMT, 0) * -1
                       AS DSCNT_PD_ERLY_ENRL_AMT,
                   NVL (BL.DSCNT_PD_LNGVTY_AMT, 0) * -1
                       AS DSCNT_PD_LNGVTY_AMT,
                   NVL (BL.DSCNT_PD_MULTI_INSD_AMT, 0) * -1
                       AS DSCNT_PD_MULTI_INSD_AMT,
                   NVL (BL.SURCHRG_PD_TBCC_USER_AMT, 0) * -1
                       AS SURCHRG_PD_TBCC_USER_AMT,
                   NVL (BL.SURCHRG_PD_TIER_AMT, 0) * -1
                       AS SURCHRG_PD_TIER_AMT,
                   NVL (BL.DSCNT_DELQ_ANNL_PAYR_AMT, 0) * -1
                       AS DSCNT_DELQ_ANNL_PAYR_AMT,
                   NVL (BL.DSCNT_DELQ_EFT_AMT, 0) * -1
                       AS DSCNT_DELQ_EFT_AMT,
                   NVL (BL.DSCNT_DELQ_ERLY_ENRL_AMT, 0) * -1
                       AS DSCNT_DELQ_ERLY_ENRL_AMT,
                   NVL (BL.DSCNT_DELQ_LNGVTY_AMT, 0) * -1
                       AS DSCNT_DELQ_LNGVTY_AMT,
                   NVL (BL.DSCNT_DELQ_MULTI_INSD_AMT, 0) * -1
                       AS DSCNT_DELQ_MULTI_INSD_AMT,
                   NVL (BL.SURCHRG_DELQ_TBCC_USER_AMT, 0) * -1
                       AS SURCHRG_DELQ_TBCC_USER_AMT,
                   NVL (BL.SURCHRG_DELQ_TIER_AMT, 0) * -1
                       AS SURCHRG_DELQ_TIER_AMT,
                   BL.ORIGINAL_REFERRAL_AGENT,
                   BL.REFERRAL_AGENT,
                   BL.AGT_REF_ORIG_D_AGT_SK,
                   BL.AGT_REF_D_AGT_SK,
                   BL.D_MBR_INFO_SK,
                   BL.D_PLN_BEN_MOD_SK,
                   BL.RES_D_GEO_XREF_SK,
                   BL.PLN_ISS_D_GEO_XREF_SK,
                   BL.D_RTNG_AREA_SK,
                   BL.F_APPL_TRANS_DAY_SK,
                   BL.CERT_SALE_CHNL_LVL_1,
                   BL.CERT_SALE_CHNL_LVL_2,
                   BL.CERT_SALE_CHNL_LVL_3,
                   BL.PRDCT_SALE_CHNL_LVL_1,
                   BL.PRDCT_SALE_CHNL_LVL_2,
                   BL.PRDCT_SALE_CHNL_LVL_3,
                   BL.D_NEW_TO_MEDCR_SK,
                   NVL (BL.DSCNT_PD_NEW_TO_MEDCR_AMT, 0) * -1
                       AS DSCNT_PD_NEW_TO_MEDCR_AMT,
                   NVL (BL.DSCNT_DLQNT_NEW_TO_MEDCR_AMT, 0) * -1
                       AS DSCNT_DLQNT_NEW_TO_MEDCR_AMT,
                   BL.D_UNDWR_GUID_SK,
                   BL.D_AGT_POL_SK,
                   NVL (BL.PRO_RATED_CREDIT, 0) * -1
                       AS PRO_RATED_CREDIT,
                   BL.ENT_AGE_EFFDT
              FROM BDR_DM.WRK_PREMIUM_DATA_BASELINE  BL
                   INNER JOIN HOUSEHOLD_PROFILE_DEL_ID HP
                       ON BL.HOUSEHOLD_ID = HP.HOUSEHOLD_ID
            UNION
            SELECT BL.HOUSEHOLD_ID,
                   BL.INDIVIDUAL_ID,
                   BL.INS_PLAN_BILLING_BUCKET_ID,
                   BL.INSURED_PLAN_ID,
                   BL.HOUSEHOLD_ADDRESS_ID,
                   BL.PREMIUM_DUE_DATE,
                   v_activitydate
                       AS ACTIVITY_DATE,
                   NVL (BL.PAID_CERT, 0) * -1
                       AS PAID_CERT,
                   NVL (BL.DEL_CERT, 0) * -1
                       AS DEL_CERT,
                   NVL (BL.TERM_CERT, 0) * -1
                       AS TERM_CERT,
                   NVL (BL.PAID_PREMIUM_AMT, 0) * -1
                       AS PAID_PREMIUM_AMT,
                   NVL (BL.DELINQUENT_PREMIUM_DUE_AMT, 0) * -1
                       AS DELINQUENT_PREMIUM_DUE_AMT,
                   BL.PLAN_CD,
                   BL.BENEFIT_MOD_CATEGORY_ID,
                   BL.INSURED_PLAN_EFFECTIVE_DATE,
                   BL.INSURED_PLAN_TERMINATION_DATE,
                   BL.CERT_TERMINATION_DATE,
                   BL.STATE_CD,
                   BL.ZIP_CD,
                   BL.COUNTRY_CD,
                   BL.ISSUE_STATE,
                   BL.ISSUE_COUNTRY_CD,
                   BL.ISSUE_ZIP_CD,
                   BL.GENDER_CD,
                   BL.DATE_OF_BIRTH,
                   ''O''
                       AS TRANS_TYPE,
                   BL.CERT_ACQN_CHNL_LEVEL3,
                   BL.ACCOUNT_NUMBER,
                   BL.TERMINATION_REASON_NAME,
                   BL.CONSERVATION_REASON_NAME,
                   BL.PLAN_GROUP,
                   BL.PRODUCT_GROUP,
                   BL.CERT_ACTV_LVL_3_TXT,
                   BL.UNDWR_TAG_KEY,
                   BL.PRDCT_EFF_DT,
                   BL.PRDCT_ACQN_CHNL_LEVEL3,
                   BL.LEGAL_ENTITY_NAME,
                   NVL (BL.MBR_PD_PREM_AMT, 0) * -1
                       AS MBR_PD_PREM_AMT,
                   NVL (BL.MBR_DELQ_PREM_AMT, 0) * -1
                       AS MBR_DELQ_PREM_AMT,
                   NVL (BL.ER_PD_PREM_AMT, 0) * -1
                       AS ER_PD_PREM_AMT,
                   NVL (BL.ER_DELQ_PREM_AMT, 0) * -1
                       AS ER_DELQ_PREM_AMT,
                   BL.CURRENT_SIGNATURE_DATE,
                   BL.ORIGINAL_SIGNATURE_DATE,
                   BL.ORIGINAL_INSURED_PLAN_ID,
                   BL.WRITING_AGENT,
                   BL.SELLING_AGENT,
                   BL.ORIGINAL_SELLING_AGENT,
                   BL.RET_TYP_ID,
                   BL.ER_SKEY,
                   BL.DCM_INSURED_PLAN_ID,
                   BL.DCM_INSURED_PLAN_EFF_DATE,
                   BL.DCM_PLAN_CD,
                   BL.DCM_SIGNATURE_DATE,
                   BL.DCM_WRITING_AGENT,
                   BL.DCM_DERIVED_COMPAS_AGENT,
                   BL.AGT_WRT_SKEY,
                   BL.AGT_SEL_ORIG_SKEY,
                   BL.AGT_SEL_SKEY,
                   BL.AGT_DCM_WRT_SKEY,
                   BL.D_DSCNT_ANNL_PAYR_SK,
                   BL.D_DSCNT_EFT_SK,
                   BL.D_DSCNT_ERLY_ENRL_SK,
                   BL.D_DSCNT_LNGVTY_SK,
                   BL.D_DSCNT_MULTI_INSD_SK,
                   BL.D_SURCHRG_TBCC_USER_SK,
                   BL.D_SURCHRG_TIER_SK,
                   BL.D_INSD_PLN_PRFL_SK,
                   BL.D_CALC_RT_SK,
                   BL.MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
                   NVL (BL.DSCNT_PD_ANNL_PAYR_AMT, 0) * -1
                       AS DSCNT_PD_ANNL_PAYR_AMT,
                   NVL (BL.DSCNT_PD_EFT_AMT, 0) * -1
                       AS DSCNT_PD_EFT_AMT,
                   NVL (BL.DSCNT_PD_ERLY_ENRL_AMT, 0) * -1
                       AS DSCNT_PD_ERLY_ENRL_AMT,
                   NVL (BL.DSCNT_PD_LNGVTY_AMT, 0) * -1
                       AS DSCNT_PD_LNGVTY_AMT,
                   NVL (BL.DSCNT_PD_MULTI_INSD_AMT, 0) * -1
                       AS DSCNT_PD_MULTI_INSD_AMT,
                   NVL (BL.SURCHRG_PD_TBCC_USER_AMT, 0) * -1
                       AS SURCHRG_PD_TBCC_USER_AMT,
                   NVL (BL.SURCHRG_PD_TIER_AMT, 0) * -1
                       AS SURCHRG_PD_TIER_AMT,
                   NVL (BL.DSCNT_DELQ_ANNL_PAYR_AMT, 0) * -1
                       AS DSCNT_DELQ_ANNL_PAYR_AMT,
                   NVL (BL.DSCNT_DELQ_EFT_AMT, 0) * -1
                       AS DSCNT_DELQ_EFT_AMT,
                   NVL (BL.DSCNT_DELQ_ERLY_ENRL_AMT, 0) * -1
                       AS DSCNT_DELQ_ERLY_ENRL_AMT,
                   NVL (BL.DSCNT_DELQ_LNGVTY_AMT, 0) * -1
                       AS DSCNT_DELQ_LNGVTY_AMT,
                   NVL (BL.DSCNT_DELQ_MULTI_INSD_AMT, 0) * -1
                       AS DSCNT_DELQ_MULTI_INSD_AMT,
                   NVL (BL.SURCHRG_DELQ_TBCC_USER_AMT, 0) * -1
                       AS SURCHRG_DELQ_TBCC_USER_AMT,
                   NVL (BL.SURCHRG_DELQ_TIER_AMT, 0) * -1
                       AS SURCHRG_DELQ_TIER_AMT,
                   BL.ORIGINAL_REFERRAL_AGENT,
                   BL.REFERRAL_AGENT,
                   BL.AGT_REF_ORIG_D_AGT_SK,
                   BL.AGT_REF_D_AGT_SK,
                   BL.D_MBR_INFO_SK,
                   BL.D_PLN_BEN_MOD_SK,
                   BL.RES_D_GEO_XREF_SK,
                   BL.PLN_ISS_D_GEO_XREF_SK,
                   BL.D_RTNG_AREA_SK,
                   BL.F_APPL_TRANS_DAY_SK,
                   BL.CERT_SALE_CHNL_LVL_1,
                   BL.CERT_SALE_CHNL_LVL_2,
                   BL.CERT_SALE_CHNL_LVL_3,
                   BL.PRDCT_SALE_CHNL_LVL_1,
                   BL.PRDCT_SALE_CHNL_LVL_2,
                   BL.PRDCT_SALE_CHNL_LVL_3,
                   BL.D_NEW_TO_MEDCR_SK,
                   NVL (BL.DSCNT_PD_NEW_TO_MEDCR_AMT, 0) * -1
                       AS DSCNT_PD_NEW_TO_MEDCR_AMT,
                   NVL (BL.DSCNT_DLQNT_NEW_TO_MEDCR_AMT, 0) * -1
                       AS DSCNT_DLQNT_NEW_TO_MEDCR_AMT,
                   BL.D_UNDWR_GUID_SK,
                   BL.D_AGT_POL_SK,
                   NVL (BL.PRO_RATED_CREDIT, 0) * -1
                       AS PRO_RATED_CREDIT,
                   BL.ENT_AGE_EFFDT
              FROM BDR_DM.WRK_PREMIUM_DATA_BASELINE  BL
                   INNER JOIN HOUSEHOLD_MEMBER_DEL_ID HM
                       ON BL.HOUSEHOLD_ID = HM.HOUSEHOLD_ID;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

----------------Step4

V_STEP_NAME    := ''TARGET - INSERT BDR_DM.TEMP_RIA_DATA_TO_DEL_TRNS'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;


INSERT INTO BDR_DM.TEMP_RIA_DATA_TO_DEL_TRNS
        SELECT BL.HOUSEHOLD_ID,
               BL.INDIVIDUAL_ID,
               BL.INS_PLAN_BILLING_BUCKET_ID,
               BL.INSURED_PLAN_ID,
               BL.HOUSEHOLD_ADDRESS_ID,
               BL.PREMIUM_DUE_DATE,
               v_activitydate
                   AS ACTIVITY_DATE,
               NVL (BL.PAID_CERT, 0) * -1
                   AS PAID_CERT,
               NVL (BL.DEL_CERT, 0) * -1
                   AS DEL_CERT,
               NVL (BL.TERM_CERT, 0) * -1
                   AS TERM_CERT,
               NVL (BL.PAID_PREMIUM_AMT, 0) * -1
                   AS PAID_PREMIUM_AMT,
               NVL (BL.DELINQUENT_PREMIUM_DUE_AMT, 0) * -1
                   AS DELINQUENT_PREMIUM_DUE_AMT,
               BL.PLAN_CD,
               BL.BENEFIT_MOD_CATEGORY_ID,
               BL.INSURED_PLAN_EFFECTIVE_DATE,
               BL.INSURED_PLAN_TERMINATION_DATE,
               BL.CERT_TERMINATION_DATE,
               BL.STATE_CD,
               BL.ZIP_CD,
               BL.COUNTRY_CD,
               BL.ISSUE_STATE,
               BL.ISSUE_COUNTRY_CD,
               BL.ISSUE_ZIP_CD,
               BL.GENDER_CD,
               BL.DATE_OF_BIRTH,
               ''O''
                   AS TRANS_TYPE,
               BL.CERT_ACQN_CHNL_LEVEL3,
               BL.ACCOUNT_NUMBER,
               BL.TERMINATION_REASON_NAME,
               BL.CONSERVATION_REASON_NAME,
               BL.PLAN_GROUP,
               BL.PRODUCT_GROUP,
               BL.CERT_ACTV_LVL_3_TXT,
               BL.UNDWR_TAG_KEY,
               BL.PRDCT_EFF_DT,
               BL.PRDCT_ACQN_CHNL_LEVEL3,
               BL.LEGAL_ENTITY_NAME,
               NVL (BL.MBR_PD_PREM_AMT, 0) * -1
                   AS MBR_PD_PREM_AMT,
               NVL (BL.MBR_DELQ_PREM_AMT, 0) * -1
                   AS MBR_DELQ_PREM_AMT,
               NVL (BL.ER_PD_PREM_AMT, 0) * -1
                   AS ER_PD_PREM_AMT,
               NVL (BL.ER_DELQ_PREM_AMT, 0) * -1
                   AS ER_DELQ_PREM_AMT,
               BL.CURRENT_SIGNATURE_DATE,
               BL.ORIGINAL_SIGNATURE_DATE,
               BL.ORIGINAL_INSURED_PLAN_ID,
               BL.WRITING_AGENT,
               BL.SELLING_AGENT,
               BL.ORIGINAL_SELLING_AGENT,
               BL.RET_TYP_ID,
               BL.ER_SKEY,
               BL.DCM_INSURED_PLAN_ID,
               BL.DCM_INSURED_PLAN_EFF_DATE,
               BL.DCM_PLAN_CD,
               BL.DCM_SIGNATURE_DATE,
               BL.DCM_WRITING_AGENT,
               BL.DCM_DERIVED_COMPAS_AGENT,
               BL.AGT_WRT_SKEY,
               BL.AGT_SEL_ORIG_SKEY,
               BL.AGT_SEL_SKEY,
               BL.AGT_DCM_WRT_SKEY,
               BL.D_DSCNT_ANNL_PAYR_SK,
               BL.D_DSCNT_EFT_SK,
               BL.D_DSCNT_ERLY_ENRL_SK,
               BL.D_DSCNT_LNGVTY_SK,
               BL.D_DSCNT_MULTI_INSD_SK,
               BL.D_SURCHRG_TBCC_USER_SK,
               BL.D_SURCHRG_TIER_SK,
               BL.D_INSD_PLN_PRFL_SK,
               BL.D_CALC_RT_SK,
               BL.MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
               NVL (BL.DSCNT_PD_ANNL_PAYR_AMT, 0) * -1
                   AS DSCNT_PD_ANNL_PAYR_AMT,
               NVL (BL.DSCNT_PD_EFT_AMT, 0) * -1
                   AS DSCNT_PD_EFT_AMT,
               NVL (BL.DSCNT_PD_ERLY_ENRL_AMT, 0) * -1
                   AS DSCNT_PD_ERLY_ENRL_AMT,
               NVL (BL.DSCNT_PD_LNGVTY_AMT, 0) * -1
                   AS DSCNT_PD_LNGVTY_AMT,
               NVL (BL.DSCNT_PD_MULTI_INSD_AMT, 0) * -1
                   AS DSCNT_PD_MULTI_INSD_AMT,
               NVL (BL.SURCHRG_PD_TBCC_USER_AMT, 0) * -1
                   AS SURCHRG_PD_TBCC_USER_AMT,
               NVL (BL.SURCHRG_PD_TIER_AMT, 0) * -1
                   AS SURCHRG_PD_TIER_AMT,
               NVL (BL.DSCNT_DELQ_ANNL_PAYR_AMT, 0) * -1
                   AS DSCNT_DELQ_ANNL_PAYR_AMT,
               NVL (BL.DSCNT_DELQ_EFT_AMT, 0) * -1
                   AS DSCNT_DELQ_EFT_AMT,
               NVL (BL.DSCNT_DELQ_ERLY_ENRL_AMT, 0) * -1
                   AS DSCNT_DELQ_ERLY_ENRL_AMT,
               NVL (BL.DSCNT_DELQ_LNGVTY_AMT, 0) * -1
                   AS DSCNT_DELQ_LNGVTY_AMT,
               NVL (BL.DSCNT_DELQ_MULTI_INSD_AMT, 0) * -1
                   AS DSCNT_DELQ_MULTI_INSD_AMT,
               NVL (BL.SURCHRG_DELQ_TBCC_USER_AMT, 0) * -1
                   AS SURCHRG_DELQ_TBCC_USER_AMT,
               NVL (BL.SURCHRG_DELQ_TIER_AMT, 0) * -1
                   AS SURCHRG_DELQ_TIER_AMT,
               BL.ORIGINAL_REFERRAL_AGENT,
               BL.REFERRAL_AGENT,
               BL.AGT_REF_ORIG_D_AGT_SK,
               BL.AGT_REF_D_AGT_SK,
               BL.D_MBR_INFO_SK,
               BL.D_PLN_BEN_MOD_SK,
               BL.RES_D_GEO_XREF_SK,
               BL.PLN_ISS_D_GEO_XREF_SK,
               BL.D_RTNG_AREA_SK,
               BL.F_APPL_TRANS_DAY_SK,
               BL.CERT_SALE_CHNL_LVL_1,
               BL.CERT_SALE_CHNL_LVL_2,
               BL.CERT_SALE_CHNL_LVL_3,
               BL.PRDCT_SALE_CHNL_LVL_1,
               BL.PRDCT_SALE_CHNL_LVL_2,
               BL.PRDCT_SALE_CHNL_LVL_3,
               BL.D_NEW_TO_MEDCR_SK,
               NVL (BL.DSCNT_PD_NEW_TO_MEDCR_AMT, 0) * -1
                   AS DSCNT_PD_NEW_TO_MEDCR_AMT,
               NVL (BL.DSCNT_DLQNT_NEW_TO_MEDCR_AMT, 0) * -1
                   AS DSCNT_DLQNT_NEW_TO_MEDCR_AMT,
               BL.D_UNDWR_GUID_SK,
               BL.D_AGT_POL_SK,
               NVL (BL.PRO_RATED_CREDIT, 0) * -1
                   AS PRO_RATED_CREDIT,
               BL.ENT_AGE_EFFDT
          FROM BDR_DM.WRK_RIA_PREMIUM_DATA_CHANGE_TRANS  TODEL
               JOIN BDR_DM.WRK_PREMIUM_DATA_BASELINE BL
                   ON     TODEL.INSURED_PLAN_ID = BL.INSURED_PLAN_ID
                      AND BL.PREMIUM_DUE_DATE >=
                          TODEL.NEW_CERT_TERMINATION_DATE
                      AND TODEL.NEW_TERM_FLAG = ''Y'';


V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

----------------Step5

V_STEP_NAME    := ''TARGET - INSERT BDR_DM.WRK_RIA_PREMIUM_DATA_DEL_TRANS'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

INSERT INTO BDR_DM.WRK_RIA_PREMIUM_DATA_DEL_TRANS (
                    HOUSEHOLD_ID,
                    INDIVIDUAL_ID,
                    INS_PLAN_BILLING_BUCKET_ID,
                    INSURED_PLAN_ID,
                    HOUSEHOLD_ADDRESS_ID,
                    PREMIUM_DUE_DATE,
                    ACTIVITY_DATE,
                    PAID_CERT,
                    DEL_CERT,
                    TERM_CERT,
                    PAID_PREMIUM_AMT,
                    DELINQUENT_PREMIUM_DUE_AMT,
                    PLAN_CD,
                    BENEFIT_MOD_CATEGORY_ID,
                    INSURED_PLAN_EFFECTIVE_DATE,
                    INSURED_PLAN_TERMINATION_DATE,
                    CERT_TERMINATION_DATE,
                    STATE_CD,
                    ZIP_CD,
                    COUNTRY_CD,
                    ISSUE_STATE,
                    ISSUE_COUNTRY_CD,
                    ISSUE_ZIP_CD,
                    GENDER_CD,
                    DATE_OF_BIRTH,
                    TRANS_TYPE,
                    CERT_ACQN_CHNL_LEVEL3,
                    ACCOUNT_NUMBER,
                    CERT_ACTV_LVL_3_TXT,
                    TERMINATION_REASON_NAME,
                    CONSERVATION_REASON_NAME,
                    PLAN_GROUP,
                    PRODUCT_GROUP,
                    UNDWR_TAG_KEY,
                    PRDCT_EFF_DT,
                    PRDCT_ACQN_CHNL_LEVEL3,
                    LEGAL_ENTITY_NAME,
                    MBR_PD_PREM_AMT,
                    MBR_DELQ_PREM_AMT,
                    ER_PD_PREM_AMT,
                    ER_DELQ_PREM_AMT,
                    CURRENT_SIGNATURE_DATE,
                    ORIGINAL_SIGNATURE_DATE,
                    ORIGINAL_INSUREDPLAN_ID,
                    WRITING_AGENT,
                    SELLING_AGENT,
                    ORIGINAL_SELLING_AGENT,
                    DCM_INSUREDPLAN_ID,
                    DCM_INSURED_PLAN_EFF_DATE,
                    DCM_PLAN_CD,
                    DCM_SIGNATURE_DATE,
                    DCM_WRITING_AGENT,
                    DCM_DERIVED_COMPAS_AGENT,
                    RET_TYP_ID,
                    ER_SKEY,
                    AGT_WRT_SKEY,
                    AGT_SEL_ORIG_SKEY,
                    AGT_SEL_SKEY,
                    AGT_DCM_WRT_SKEY,
                    D_DSCNT_ANNL_PAYR_SK,
                    D_DSCNT_EFT_SK,
                    D_DSCNT_ERLY_ENRL_SK,
                    D_DSCNT_LNGVTY_SK,
                    D_DSCNT_MULTI_INSD_SK,
                    D_SURCHRG_TBCC_USER_SK,
                    D_SURCHRG_TIER_SK,
                    D_INSD_PLN_PRFL_SK,
                    D_CALC_RT_SK,
                    MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
                    DSCNT_PD_ANNL_PAYR_AMT,
                    DSCNT_PD_EFT_AMT,
                    DSCNT_PD_ERLY_ENRL_AMT,
                    DSCNT_PD_LNGVTY_AMT,
                    DSCNT_PD_MULTI_INSD_AMT,
                    SURCHRG_PD_TBCC_USER_AMT,
                    SURCHRG_PD_TIER_AMT,
                    DSCNT_DELQ_ANNL_PAYR_AMT,
                    DSCNT_DELQ_EFT_AMT,
                    DSCNT_DELQ_ERLY_ENRL_AMT,
                    DSCNT_DELQ_LNGVTY_AMT,
                    DSCNT_DELQ_MULTI_INSD_AMT,
                    SURCHRG_DELQ_TBCC_USER_AMT,
                    SURCHRG_DELQ_TIER_AMT,
                    ORIGINAL_REFERRAL_AGENT,
                    REFERRAL_AGENT,
                    AGT_REF_ORIG_D_AGT_SK,
                    AGT_REF_D_AGT_SK,
                    D_MBR_INFO_SK,
                    D_PLN_BEN_MOD_SK,
                    RES_D_GEO_XREF_SK,
                    PLN_ISS_D_GEO_XREF_SK,
                    D_RTNG_AREA_SK,
                    F_APPL_TRANS_DAY_SK,
                    CERT_SALE_CHNL_LVL_1,
                    CERT_SALE_CHNL_LVL_2,
                    CERT_SALE_CHNL_LVL_3,
                    PRDCT_SALE_CHNL_LVL_1,
                    PRDCT_SALE_CHNL_LVL_2,
                    PRDCT_SALE_CHNL_LVL_3,
                    D_NEW_TO_MEDCR_SK,
                    DSCNT_PD_NEW_TO_MEDCR_AMT,
                    DSCNT_DLQNT_NEW_TO_MEDCR_AMT,
                    D_UNDWR_GUID_SK,
                    D_AGT_POL_SK,
                    PRO_RATED_CREDIT,
                    ENT_AGE_EFFDT)
        (SELECT DISTINCT HOUSEHOLD_ID,
                         INDIVIDUAL_ID,
                         INS_PLAN_BILLING_BUCKET_ID,
                         INSURED_PLAN_ID,
                         HOUSEHOLD_ADDRESS_ID,
                         PREMIUM_DUE_DATE,
                         ACTIVITY_DATE,
                         PAID_CERT,
                         DEL_CERT,
                         TERM_CERT,
                         PAID_PREMIUM_AMT,
                         DELINQUENT_PREMIUM_DUE_AMT,
                         PLAN_CD,
                         BENEFIT_MOD_CATEGORY_ID,
                         INSURED_PLAN_EFFECTIVE_DATE,
                         INSURED_PLAN_TERMINATION_DATE,
                         CERT_TERMINATION_DATE,
                         STATE_CD,
                         ZIP_CD,
                         COUNTRY_CD,
                         ISSUE_STATE,
                         ISSUE_COUNTRY_CD,
                         ISSUE_ZIP_CD,
                         GENDER_CD,
                         DATE_OF_BIRTH,
                         TRANS_TYPE,
                         CERT_ACQN_CHNL_LEVEL3,
                         ACCOUNT_NUMBER,
                         CERT_ACTV_LVL_3_TXT,
                         TERMINATION_REASON_NAME,
                         CONSERVATION_REASON_NAME,
                         PLAN_GROUP,
                         PRODUCT_GROUP,
                         UNDWR_TAG_KEY,
                         PRDCT_EFF_DT,
                         PRDCT_ACQN_CHNL_LEVEL3,
                         LEGAL_ENTITY_NAME,
                         MBR_PD_PREM_AMT,
                         MBR_DELQ_PREM_AMT,
                         ER_PD_PREM_AMT,
                         ER_DELQ_PREM_AMT,
                         CURRENT_SIGNATURE_DATE,
                         ORIGINAL_SIGNATURE_DATE,
                         ORIGINAL_INSURED_PLAN_ID,
                         WRITING_AGENT,
                         SELLING_AGENT,
                         ORIGINAL_SELLING_AGENT,
                         DCM_INSURED_PLAN_ID,
                         DCM_INSURED_PLAN_EFF_DATE,
                         DCM_PLAN_CD,
                         DCM_SIGNATURE_DATE,
                         DCM_WRITING_AGENT,
                         DCM_DERIVED_COMPAS_AGENT,
                         RET_TYP_ID,
                         ER_SKEY,
                         AGT_WRT_SKEY,
                         AGT_SEL_ORIG_SKEY,
                         AGT_SEL_SKEY,
                         AGT_DCM_WRT_SKEY,
                         D_DSCNT_ANNL_PAYR_SK,
                         D_DSCNT_EFT_SK,
                         D_DSCNT_ERLY_ENRL_SK,
                         D_DSCNT_LNGVTY_SK,
                         D_DSCNT_MULTI_INSD_SK,
                         D_SURCHRG_TBCC_USER_SK,
                         D_SURCHRG_TIER_SK,
                         D_INSD_PLN_PRFL_SK,
                         D_CALC_RT_SK,
                         MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
                         DSCNT_PD_ANNL_PAYR_AMT,
                         DSCNT_PD_EFT_AMT,
                         DSCNT_PD_ERLY_ENRL_AMT,
                         DSCNT_PD_LNGVTY_AMT,
                         DSCNT_PD_MULTI_INSD_AMT,
                         SURCHRG_PD_TBCC_USER_AMT,
                         SURCHRG_PD_TIER_AMT,
                         DSCNT_DELQ_ANNL_PAYR_AMT,
                         DSCNT_DELQ_EFT_AMT,
                         DSCNT_DELQ_ERLY_ENRL_AMT,
                         DSCNT_DELQ_LNGVTY_AMT,
                         DSCNT_DELQ_MULTI_INSD_AMT,
                         SURCHRG_DELQ_TBCC_USER_AMT,
                         SURCHRG_DELQ_TIER_AMT,
                         ORIGINAL_REFERRAL_AGENT,
                         REFERRAL_AGENT,
                         AGT_REF_ORIG_D_AGT_SK,
                         AGT_REF_D_AGT_SK,
                         D_MBR_INFO_SK,
                         D_PLN_BEN_MOD_SK,
                         RES_D_GEO_XREF_SK,
                         PLN_ISS_D_GEO_XREF_SK,
                         D_RTNG_AREA_SK,
                         F_APPL_TRANS_DAY_SK,
                         CERT_SALE_CHNL_LVL_1,
                         CERT_SALE_CHNL_LVL_2,
                         CERT_SALE_CHNL_LVL_3,
                         PRDCT_SALE_CHNL_LVL_1,
                         PRDCT_SALE_CHNL_LVL_2,
                         PRDCT_SALE_CHNL_LVL_3,
                         D_NEW_TO_MEDCR_SK,
                         DSCNT_PD_NEW_TO_MEDCR_AMT,
                         DSCNT_DLQNT_NEW_TO_MEDCR_AMT,
                         D_UNDWR_GUID_SK,
                         D_AGT_POL_SK,
                         PRO_RATED_CREDIT,
                         ENT_AGE_EFFDT
           FROM BDR_DM.TEMP_RIA_DATA_TO_DEL_TRNS);
		   

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

--------FinalLogUpdate


UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''COMPLETE'', ERROR_MSG = null, BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
;
UPDATE  UTIL.ETL_BATCH_OBJECT_INCR_VALU SET INCR_COLUMN_VALUE = :V_BATCH_ID, LST_MOD_DT = CURRENT_TIMESTAMP() 
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID''
;

EXCEPTION

WHEN OTHER THEN

UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''ERROR'', ERROR_MSG = :SQLERRM,  BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
;

INSERT INTO  UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ERROR_MSG, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''ERROR'', :V_STEP_NAME, :V_STEP_SEQ, :SQLERRM, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() )
;



RAISE;

END;

';