USE SCHEMA BDR_DM; CREATE OR REPLACE PROCEDURE "SP_CLAIMS_IXL_CLAIMBILLLINEHISTDAILY_D"("DB_NAME" VARCHAR(16777216), "APPLICATION" VARCHAR(16777216), "WORKFLOW_NAME" VARCHAR(16777216), "OBJECT_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '

-- Original workflow: wkf_Claims_Fact_IXL_TargetLoad2_D
-- Original mapping: m_Claims_IXL_ClaimBillLineHistDaily_D
-- Original folder: Claims
-- Original filename: wkf_Claims_Fact_IXL_TargetLoad2_D.XML

DECLARE


V_ROWS_INSERTED  INTEGER;
V_ROWS_UPDATED INTEGER;
V_ROWS_DELETED INTEGER;
V_LAST_QUERY_ID VARCHAR;

V_WH VARCHAR;
V_BATCH_ID INTEGER;


V_BATCH_OBJECT_START_TIME        VARCHAR;
V_STEP_START_TIME    VARCHAR;
V_STEP_NAME VARCHAR;
V_STEP_SEQ INTEGER DEFAULT 0;
V_ETL_LST_BTCH_ID INTEGER;

BenSKeyH2Z1	INTEGER;
BenSKeyH2Z2	INTEGER;
BenSKeyH2Z3 INTEGER;
BenSKeyH245N INTEGER;
BenSKeyH2ZLtrN INTEGER;
BenSKeyH245NotN	INTEGER;
BenSKeyH2ZLtrNotN INTEGER;
BenSKeyW0Z6	INTEGER;
BenSKeyW0Z7	INTEGER;
BenSKeyW0Z8	INTEGER;
BenSKeyW1Z6	INTEGER;
BenSKeyW1Z7	INTEGER;
BenSKeyW1Z8	INTEGER;
BenSKeyW2Z6	INTEGER;
BenSKeyW2Z7	INTEGER;
BenSKeyW2Z8	INTEGER;
BenSKeyW4Z6	INTEGER;
BenSKeyW4Z7	INTEGER;
BenSKeyW4Z8	INTEGER;
BenSKeyW5Z6	INTEGER;
BenSKeyW5Z7	INTEGER;
BenSKeyW5Z8	INTEGER;
BenSKeyW6Z6	INTEGER;
BenSKeyW6Z7	INTEGER;
BenSKeyW6Z8	INTEGER;
BenSKeyH2D INTEGER;
BenSKeyW0D INTEGER;
BenSKeyW1D INTEGER;
BenSKeyW2D INTEGER;
BenSKeyW4D INTEGER;
BenSKeyW5D INTEGER;
BenSKeyW6D INTEGER;
v_DateRangeStart VARCHAR;
v_DateRangeEnd   VARCHAR;
V_LE_SK_FOR_DUP INTEGER;
V_LE_NAME VARCHAR;


BEGIN

EXECUTE IMMEDIATE ''USE DATABASE ''||:DB_NAME; 

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_BATCH_OBJECT_START_TIME := (SELECT CURRENT_TIMESTAMP());



LET res1 RESULTSET := 
(

SELECT 

WH ,
BATCH_ID
  
FROM UTIL.ETL_BATCH_OBJECT_CONTROL
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
FETCH FIRST 1 ROW ONLY

)
;


LET C1 CURSOR FOR res1;
open C1;
FETCH C1 into  V_WH,V_BATCH_ID ;
close C1;


LET res2 RESULTSET := 

(

WITH PARAMETERS (LE_NAME, LE_SK_FOR_DUP) AS
(
  
SELECT * 
FROM  
(SELECT PARAMETER_NAME, PARAMETER_VALUE  FROM UTIL.ETL_OBJECT_PARAMETER_VALUE 
WHERE 1 = 1
AND APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
AND ACTIVE_FLG = ''Y''  
  
UNION ALL       

SELECT PARAMETER_NAME, PARAMETER_VALUE  FROM UTIL.ETL_GLOBAL_PARAMETER_VALUE WHERE PAR_GLOBAL_TYPE = ''PARGLOBAL_OPREPORTS'' AND ACTIVE_FLG = ''Y''
AND PARAMETER_NAME NOT IN  (
SELECT PARAMETER_NAME  FROM UTIL.ETL_OBJECT_PARAMETER_VALUE WHERE 1 = 1
AND APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
AND ACTIVE_FLG = ''Y''   ))
 
PIVOT(MAX(PARAMETER_VALUE) FOR PARAMETER_NAME IN (''LE_NAME'', ''LE_SK_FOR_DUP'')) 

 
)  
SELECT * FROM PARAMETERS 
)  
  
;


LET C2 CURSOR FOR res2;
open C2;
FETCH C2 into  V_LE_NAME, V_LE_SK_FOR_DUP; 
close C2;



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:V_WH;
USE SCHEMA BDR_DM;	--OAS ADD


INSERT INTO UTIL.ETL_BATCH_OBJECT_INCR_VALU (APPLICATION, WORKFLOW_NAME, OBJECT_NAME, INCR_COLUMN, INCR_COLUMN_VALUE )
SELECT * FROM (select :APPLICATION AS APPLICATION, :WORKFLOW_NAME AS WORKFLOW_NAME, :OBJECT_NAME AS OBJECT_NAME, ''ETL_LST_BTCH_ID'' AS INCR_COLUMN, -1 AS INCR_COLUMN_VALUE) A
WHERE NOT EXISTS (SELECT 1 FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU B WHERE B.APPLICATION = A.APPLICATION AND B.WORKFLOW_NAME = A.WORKFLOW_NAME AND B.OBJECT_NAME = A.OBJECT_NAME AND B.INCR_COLUMN = A.INCR_COLUMN)
;

V_ETL_LST_BTCH_ID :=(SELECT INCR_COLUMN_VALUE FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID'');

--COMMENTED BY OAS--
/*
CREATE OR REPLACE PROCEDURE BDR_DM."SP_CLAIMS_FCLMBILLNHIST_D"(
   P_ToStart               IN  NUMBER,
   P_ToContinueStatus      OUT VARCHAR2,
   P_ErrorYNFlg            OUT VARCHAR2,
   P_ErrorStr              OUT VARCHAR2)

---------------------------------------------------------------------------
--Purpose         : This procedure populates ClaimBillLineHistory fact table
--
--Application Ref : Program Global Dashboard
--Called From     :
--Author          : By CTS    Inital Date : 06/01/2017
--Change History
---------------------------------------------------------------------------
--    Date             Who Changed             What Changed
--
--
---------------------------------------------------------------------------
AS

   -- variables for    Benifit Key
   BenSKeyH2Z1		INT;
   BenSKeyH2Z2		INT;
   BenSKeyH2Z3		INT;
   BenSKeyH245N		INT;
   BenSKeyH2ZLtrN		INT;
   BenSKeyH245NotN	INT;
   BenSKeyH2ZLtrNotN	INT;
   BenSKeyW0Z6		INT;
   BenSKeyW0Z7		INT;
   BenSKeyW0Z8		INT;
   BenSKeyW1Z6		INT;
   BenSKeyW1Z7		INT;
   BenSKeyW1Z8		INT;
   BenSKeyW2Z6		INT;
   BenSKeyW2Z7		INT;
   BenSKeyW2Z8		INT;
   BenSKeyW4Z6		INT;
   BenSKeyW4Z7		INT;
   BenSKeyW4Z8		INT;
   BenSKeyW5Z6		INT;
   BenSKeyW5Z7		INT;
   BenSKeyW5Z8		INT;
   BenSKeyW6Z6		INT;
   BenSKeyW6Z7		INT;
   BenSKeyW6Z8		INT;
   BenSKeyH2D			INT;
   BenSKeyW0D			INT;
   BenSKeyW1D			INT;
   BenSKeyW2D			INT;
   BenSKeyW4D			INT;
   BenSKeyW5D			INT;
   BenSKeyW6D			INT;

v_DateRangeStart VARCHAR2(8) ;
v_DateRangeEnd   VARCHAR2(8) ;
V_PROC_NAME         VARCHAR(50):=''SP_CLAIMS_FCLMBILLNHIST_D'';
V_ROWS_AFFTD        NUMBER(20) :=0;
V_BTCH_ID           NUMBER(10);
V_LE_SK_FOR_DUP NUMBER(10);
V_LE_NAME VARCHAR2(20);

BEGIN


SELECT MAX(BATCH_ID) INTO V_BTCH_ID FROM ETL.ETL_BATCH_LOG WHERE APPLICATION=''CDC'' AND BATCH_STATUS=''COMPLETE'';

 INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''FACT_CLAIMS'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''START'',
      ''PROCEDURE STARTS'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );

    --commit;

IF (P_ToStart = 1)
THEN
BEGIN
*/
--COMMENTED BY OAS--
  SELECT TO_CHAR(MIN(CD.DT_VAL),''YYYYMMDD''),TO_CHAR(MAX(CD.DT_VAL),''YYYYMMDD'') INTO v_DateRangeStart,v_DateRangeEnd FROM BDR_CONF.D_CAL_DT CD WHERE EXTRACT(YEAR FROM CD.DT_VAL) != ''9999'';
------------------------------------------------------Get d_ben_sk based on given criteria------------------------------




   SELECT NVL(MAX(d_ben_sk),-1) INTO BenSKeyH2Z1 FROM bdr_conf.d_ben WHERE prdct = ''Med Supp'' AND ben_tos_cd = ''H2'' AND ben_id = 5;
   SELECT NVL(MAX(d_ben_sk),-1) INTO BenSKeyH2Z2 FROM bdr_conf.d_ben WHERE prdct = ''Med Supp'' AND ben_tos_cd = ''H2'' AND ben_id = 6;
   SELECT NVL(MAX(d_ben_sk),-1) INTO BenSKeyH2Z3 FROM bdr_conf.d_ben WHERE prdct = ''Med Supp'' AND ben_tos_cd = ''H2'' AND ben_id = 7;
   SELECT NVL(MAX(d_ben_sk),-1) INTO BenSKeyH245N FROM bdr_conf.d_ben WHERE prdct = ''Med Supp'' AND ben_tos_cd = ''H2'' AND ben_id = 8;
   SELECT NVL(MAX(d_ben_sk),-1) INTO BenSKeyH2ZLtrN FROM bdr_conf.d_ben WHERE prdct = ''Med Supp'' AND ben_tos_cd = ''H2'' AND ben_id = 8;
   SELECT NVL(MAX(d_ben_sk),-1) INTO BenSKeyH245NotN FROM bdr_conf.d_ben WHERE prdct = ''Med Supp'' AND ben_tos_cd = ''H2'' AND ben_id = 9;
   SELECT NVL(MAX(d_ben_sk),-1) INTO BenSKeyH2ZLtrNotN FROM bdr_conf.d_ben WHERE prdct = ''Med Supp'' AND ben_tos_cd = ''H2'' AND ben_id = 9;
   SELECT NVL(MAX(d_ben_sk),-1) INTO BenSKeyW0Z6 FROM bdr_conf.d_ben WHERE prdct = ''Med Supp'' AND ben_tos_cd = ''W0'' AND ben_id = 11;
   SELECT NVL(MAX(d_ben_sk),-1) INTO BenSKeyW0Z7 FROM bdr_conf.d_ben WHERE prdct = ''Med Supp'' AND ben_tos_cd = ''W0'' AND ben_id = 12;
   SELECT NVL(MAX(d_ben_sk),-1) INTO BenSKeyW0Z8 FROM bdr_conf.d_ben WHERE prdct = ''Med Supp'' AND ben_tos_cd = ''W0'' AND ben_id = 13;
   SELECT NVL(MAX(d_ben_sk),-1) INTO BenSKeyW1Z6 FROM bdr_conf.d_ben WHERE prdct = ''Med Supp'' AND ben_tos_cd = ''W1'' AND ben_id = 11;
   SELECT NVL(MAX(d_ben_sk),-1) INTO BenSKeyW1Z7 FROM bdr_conf.d_ben WHERE prdct = ''Med Supp'' AND ben_tos_cd = ''W1'' AND ben_id = 12;
   SELECT NVL(MAX(d_ben_sk),-1) INTO BenSKeyW1Z8 FROM bdr_conf.d_ben WHERE prdct = ''Med Supp'' AND ben_tos_cd = ''W1'' AND ben_id = 13 ;
   SELECT NVL(MAX(d_ben_sk),-1) INTO BenSKeyW2Z6 FROM bdr_conf.d_ben WHERE prdct = ''Med Supp'' AND ben_tos_cd = ''W2'' AND ben_id = 11;
   SELECT NVL(MAX(d_ben_sk),-1) INTO BenSKeyW2Z7 FROM bdr_conf.d_ben WHERE prdct = ''Med Supp'' AND ben_tos_cd = ''W2'' AND ben_id = 12;
   SELECT NVL(MAX(d_ben_sk),-1) INTO BenSKeyW2Z8 FROM bdr_conf.d_ben WHERE prdct = ''Med Supp'' AND ben_tos_cd = ''W2'' AND ben_id = 13;
   SELECT NVL(MAX(d_ben_sk),-1) INTO BenSKeyW4Z6 FROM bdr_conf.d_ben WHERE prdct = ''Med Supp'' AND ben_tos_cd = ''W4'' AND ben_id = 11;
   SELECT NVL(MAX(d_ben_sk),-1) INTO BenSKeyW4Z7 FROM bdr_conf.d_ben WHERE prdct = ''Med Supp'' AND ben_tos_cd = ''W4'' AND ben_id = 12;
   SELECT NVL(MAX(d_ben_sk),-1) INTO BenSKeyW4Z8 FROM bdr_conf.d_ben WHERE prdct = ''Med Supp'' AND ben_tos_cd = ''W4'' AND ben_id = 13 ;
   SELECT NVL(MAX(d_ben_sk),-1) INTO BenSKeyW5Z6 FROM bdr_conf.d_ben WHERE prdct = ''Med Supp'' AND ben_tos_cd = ''W5'' AND ben_id = 11;
   SELECT NVL(MAX(d_ben_sk),-1) INTO BenSKeyW5Z7 FROM bdr_conf.d_ben WHERE prdct = ''Med Supp'' AND ben_tos_cd = ''W5'' AND ben_id = 12;
   SELECT NVL(MAX(d_ben_sk),-1) INTO BenSKeyW5Z8 FROM bdr_conf.d_ben WHERE prdct = ''Med Supp'' AND ben_tos_cd = ''W5'' AND ben_id = 13;
   SELECT NVL(MAX(d_ben_sk),-1) INTO BenSKeyW6Z6 FROM bdr_conf.d_ben WHERE prdct = ''Med Supp'' AND ben_tos_cd = ''W6'' AND ben_id = 11;
   SELECT NVL(MAX(d_ben_sk),-1) INTO BenSKeyW6Z7 FROM bdr_conf.d_ben WHERE prdct = ''Med Supp'' AND ben_tos_cd = ''W6'' AND ben_id = 12;
   SELECT NVL(MAX(d_ben_sk),-1) INTO BenSKeyW6Z8 FROM bdr_conf.d_ben WHERE prdct = ''Med Supp'' AND ben_tos_cd = ''W6'' AND ben_id = 13 ;
   SELECT NVL(MAX(d_ben_sk),-1) INTO BenSKeyH2D FROM bdr_conf.d_ben WHERE prdct = ''Med Supp'' AND ben_tos_cd = ''H2'' AND ben_id = 39;
   SELECT NVL(MAX(d_ben_sk),-1) INTO BenSKeyW0D FROM bdr_conf.d_ben WHERE prdct = ''Med Supp'' AND ben_tos_cd = ''W0'' AND ben_id = 40;
   SELECT NVL(MAX(d_ben_sk),-1) INTO BenSKeyW1D FROM bdr_conf.d_ben WHERE prdct = ''Med Supp'' AND ben_tos_cd = ''W1'' AND ben_id = 41;
   SELECT NVL(MAX(d_ben_sk),-1) INTO BenSKeyW2D FROM bdr_conf.d_ben WHERE prdct = ''Med Supp'' AND ben_tos_cd = ''W2'' AND ben_id = 42;
   SELECT NVL(MAX(d_ben_sk),-1) INTO BenSKeyW4D FROM bdr_conf.d_ben WHERE prdct = ''Med Supp'' AND ben_tos_cd = ''W4'' AND ben_id = 43;
   SELECT NVL(MAX(d_ben_sk),-1) INTO BenSKeyW5D FROM bdr_conf.d_ben WHERE prdct = ''Med Supp'' AND ben_tos_cd = ''W5'' AND ben_id = 44;
   SELECT NVL(MAX(d_ben_sk),-1) INTO BenSKeyW6D FROM bdr_conf.d_ben WHERE prdct = ''Med Supp'' AND ben_tos_cd = ''W6'' AND ben_id = 45;

------------------------------------------------------Get d_ben_sk based on given criteria------------------------------

DELETE FROM BDR_DM.F_CLM_BIL_LN_HIST WHERE BATCH_ID = :V_BATCH_ID;  --for restart--
--------------------------------

V_STEP_NAME    := ''TRUNCATE - WRK_BIL_LN'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

EXECUTE IMMEDIATE ''TRUNCATE TABLE BDR_DM.WRK_BIL_LN'';

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );


--EXECUTE IMMEDIATE ''ALTER TABLE BDR_DM.WRK_BIL_LN NOLOGGING'';		--OAS DELETE

--DBMS_STATS.GATHER_TABLE_STATS (OWNNAME => ''DM'',TABNAME => ''WRK_UCPS_CLAIM_HISTORY'',PARTNAME => NULL,ESTIMATE_PERCENT => 10, DEGREE => 4, GRANULARITY => ''ALL'', METHOD_OPT => ''FOR ALL COLUMNS SIZE 1'',CASCADE => TRUE);
/* BDR_DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''WRK_UCPS_CLAIM_HISTORY''); -- Adding stats 02/01/2018
BDR_DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''WRK_BIL_LN''); --SB : */		--OAS DELETE

V_STEP_NAME    := ''INSERT - WRK_BIL_LN'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

INSERT /*+ ENABLE_PARALLEL_DML APPEND */  INTO BDR_DM.WRK_BIL_LN
   (ROW_NUMBER,F_CLM_HIST_SK,BILL_LN_NUM,SRVC_FROM_DT_ID,SRVC_TO_DT_ID,MCARE_APRV_AMT,BEN_AMT,MCARE_PAID_AMT,PCT_PD,SUBMITTED_CHRG,CHRG_AMT,CVRD_XPNCE_AMT,
   CHRG_TBL_IND,BL_PROV_KEY,REND_PRV_NPI,MCARE_ASGN_IND,ASGN_IND,PRE_EXIST_IND,D_CPT_LOOK_SK,D_CPT_MOD_LOOK_SK1,D_CPT_MOD_LOOK_SK2,D_CPT_MOD_LOOK_SK3,
   D_CPT_MOD_LOOK_SK4,AARP_DED_AMT,PARTB_DED_AMT,DAILY_BEN_AMT,HSP_SNF_DAYS_IND,PLAN_CD,ADJUSTBENEFITAMT,PLAN_IND,D_CLM_PLN_SK,ACCT_NBR,ETL_LST_BTCH_ID,
   CLAIMTYPEIND,CH_ACCT_PART_NUM,CH_KEY,PAY_ADJ_AMT,ASSGN_ADJ_AMT,BLH_KEY,CLM_STAT,SRV_CD,D_BEN_SK,TOSCODE,PRDCT,COMPAS_PLN_CD,PLANCODEBENMOD,HOSP_CHRG_KEY,
   SNF_PROCESS_IND,CLM_NBR,CLM_PD_DT_ID,TEMP_CLM_PD_DT_ID,CMPL_DT_ID,D_MBR_INFO_SK,ISID,SRV_ACCUM1,SRV_ACCUM2,BEN_PERD_DAYS,BEN_PRD_NBR,BIL_D_PROV_SK,
D_TOS_SK,OOP_AMT,AARP_COPAY_AMT,BL_NO_PAY_IND,RNDR_PROV_NM,D_DSCNT_ANNL_PAYR_SK,D_DSCNT_EFT_SK,D_DSCNT_ERLY_ENRL_SK,D_DSCNT_LNGVTY_SK,D_DSCNT_MULTI_INSD_SK,
D_SURCHRG_TIER_SK,D_SURCHRG_TBCC_USER_SK,D_INSD_PLN_PRFL_SK,D_CALC_RT_SK,MEDSUP_PLN_ENT_AGE_LOOK_FRAC,CERT_EFF_AGE_LOOK_FRAC,D_LGL_ENTY_SK,SRVC_DT_D_GEO_XREF_SK)
   SELECT /*+ PARALLEL(8) */ ROW_NUMBER() OVER (PARTITION BY B.ch_acct_part_num, B.ch_key,
     CASE
       WHEN B.asgn_ind = ''Y''
       THEN ''Y''
       ELSE ''N''
     END ORDER BY B.ch_acct_part_num, B.ch_key,B.BIL_LN_NUM) ROW_NUMBER,
     CF.f_clm_hist_sk,
     B.BIL_LN_NUM,
     CASE
       WHEN B.srv_from_dt = TO_TIMESTAMP(''9999-01-01 00:00:00.0000000'',''YYYY-MM-DD HH24:MI:SS.FF'')
       OR (B.srv_from_dt BETWEEN to_TIMESTAMP(:v_DateRangeEnd,''YYYYMMDD'') AND TO_TIMESTAMP(''9998-12-31 00:00:00.0000000'',''YYYY-MM-DD HH24:MI:SS.FF'')
       OR B.srv_from_dt < to_TIMESTAMP (:v_DateRangeStart,''YYYYMMDD''))
       THEN -1 ---0
       WHEN B.srv_from_dt IS NULL
       THEN CF.srvc_from_dt_id
       ELSE CAST(TO_CHAR(B.srv_from_dt,''YYYYMMDD'') AS NUMBER)
     END srvc_from_dt_id,
     CASE
       WHEN B.srv_to_dt  IS NULL
       AND B.srv_from_dt IS NULL
       THEN CF.srvc_from_dt_id
       WHEN B.srv_to_dt IS NULL
               AND ((B.srv_from_dt BETWEEN to_TIMESTAMP (:v_DateRangeStart,''YYYYMMDD'') AND to_TIMESTAMP(:v_DateRangeEnd,''YYYYMMDD''))
       OR TO_CHAR(B.srv_from_dt,''YYYYMMDD'') = ''99991231'')
       THEN CAST(TO_CHAR(B.srv_from_dt,''YYYYMMDD'') AS NUMBER)
       WHEN B.srv_to_dt   IS NULL
       AND ( B.srv_from_dt = TO_TIMESTAMP(''9999-01-01 00:00:00.0000000'',''YYYY-MM-DD HH24:MI:SS.FF'')
       OR (B.srv_from_dt BETWEEN to_TIMESTAMP(:v_DateRangeEnd,''YYYYMMDD'') AND TO_TIMESTAMP(''9998-12-31 00:00:00.0000000'',''YYYY-MM-DD HH24:MI:SS.FF'')
       OR B.srv_from_dt < to_TIMESTAMP (:v_DateRangeStart,''YYYYMMDD'')))
       THEN -1
       WHEN ( B.srv_to_dt = TO_TIMESTAMP(''9999-01-01 00:00:00.0000000'',''YYYY-MM-DD HH24:MI:SS.FF'')
       OR (B.srv_to_dt BETWEEN to_TIMESTAMP(:v_DateRangeEnd,''YYYYMMDD'') AND TO_TIMESTAMP(''9998-12-31 00:00:00.0000000'',''YYYY-MM-DD HH24:MI:SS.FF'')
       OR B.srv_to_dt < to_TIMESTAMP (:v_DateRangeStart,''YYYYMMDD'')))
       THEN -1
       ELSE CAST(TO_CHAR(B.srv_to_dt,''YYYYMMDD'') AS NUMBER)
       END srvc_to_dt_id,
       NVL(B.mcare_aprvd_amt,0.00) mcare_aprvd_amt,
       NVL(B.ben_amt,0.00) ben_amt,
       ABS(NVL(B.MCARE_PD_AMT,0.00)) mcare_paid_amt,
       B.pct_pd,
       B.SBMT_CHRG,
       NVL(B.chrg_amt,0.00) chrg_amt,
       NVL(B.cvrd_xpnce_amt,0.00) cvrd_xpnce_amt,
     CASE
       WHEN B.chrg_tbl_ind IN (''D'',''P'',''H'')
       THEN B.chrg_tbl_ind
       ELSE ''Z''
     END chrg_tbl_ind,
       B.bl_prov_key,
       NVL(B.rend_prv_npi,-1) rend_prv_npi, -------------Confirm with Business
     CASE
       WHEN B.Mcare_asgn_ind = ''Y''
       THEN ''Y''
       WHEN B.Mcare_asgn_ind = ''N''
       THEN ''N''
       ELSE ''Z''
     END Mcare_asgn_ind,
     CASE
       WHEN B.asgn_ind = ''Y''
       THEN ''Y''
       WHEN B.asgn_ind = ''N''
       THEN ''N''
       ELSE ''Z''
     END asgn_ind,
     CASE
       WHEN B.PRE_XST_IND = ''Y''
       THEN ''Y''
       WHEN B.PRE_XST_IND = ''N''
       THEN ''N''
       ELSE ''Z''
     END pre_exist_ind,
     --NVL(TOS.TOSLkupSKey,1)  TOSLkupSKey,
     NVL(CPT.d_cpt_look_sk,     -1) d_cpt_look_sk,
     NVL(Mod1.d_cpt_mod_look_sk,-1) d_cpt_mod_look_sk1,
     NVL(Mod2.d_cpt_mod_look_sk,-1) d_cpt_mod_look_sk2,
     NVL(Mod3.d_cpt_mod_look_sk,-1) d_cpt_mod_look_sk3,
     NVL(Mod4.d_cpt_mod_look_sk,-1) d_cpt_mod_look_sk4,
     NVL(B.aarp_ded_amt,0.00) aarp_ded_amt,
     NVL(B.partb_ded_amt,0.00) partb_ded_amt,
     NVL(B.DAY_BEN_AMT,0.00) daily_ben_amt,
     --REPLACE(REPLACE(B.HSP_SNF_DAY_IND,'' '',''Z''),''0'',''Z'') hsp_snf_days_ind,
     CASE
       WHEN LTRIM(RTRIM(B.HSP_SNF_DAY_IND)) BETWEEN ''1'' AND ''8''
       THEN CAST(B.HSP_SNF_DAY_IND AS VARCHAR(1))
       ELSE ''Z''
     END hsp_snf_days_ind,
     NVL(B.PLN_CD,''  '') PLN_CD,
     0.00 AdjustBenefitAmt,
     NVL(B.PLN_IND,'' ''),
     -1 d_clm_pln_sk,
     CF.acct_nbr acct_nbr,
     B.etl_lst_btch_id etl_lst_btch_id,
     1 ClaimTypeInd,
     B.ch_acct_part_num,
     B.ch_key,
     NVL(C.pay_adj_amt,0) pay_adj_amt ,
     NVL(C.assgn_adj_amt,0) assgn_adj_amt,
     B.blh_key,
     C.clm_stat,
     B.srv_cd,
     -1 d_ben_sk,
     TRIM(NVL(TO_CHAR(B.srv_cd), '''')||NVL(TO_CHAR(B.TYP_CD), '''')) TOSCode,
     CAST(NULL AS VARCHAR(20)) prdct,
     CAST(NULL AS VARCHAR(10)) compas_pln_cd,
     CAST(NULL AS VARCHAR(10)) PlanCodeBenMod,
     chrg_key hosp_chrg_key,
     CAST(NULL AS INTEGER) snf_process_ind,
     --CF.acct_nbr,
     CF.clm_nbr,
     CF.clm_pd_dt_id,
     CF.temp_clm_pd_dt_id,
     CF.cmpl_dt_id,
     -1 d_mbr_info_sk,
     -1 isid,
     NVL(B.SRV_ACCUM1,0)	AS SRV_ACCUM1,
     NVL(B.SRV_ACCUM2,0)	AS SRV_ACCUM2,
     NVL(B.BEN_PERD_DAY,0) AS BEN_PERD_DAYS,
	 NVL(B.BEN_PERD_NUM,0)  AS BEN_PRD_NBR,
	CASE WHEN B.BL_PROV_KEY = 0
		 THEN -2
		 ELSE NVL(PRV.D_PROV_SK,-1)
		 END		    AS BIL_D_PROV_SK,
	NVL(T.D_TOS_SK,-1)			AS D_TOS_SK,
	NVL(OOP.OOP_AMT,0.00) OOP_AMT,
    CASE WHEN CHRG_TBL_IND = ''P'' THEN NVL(PRF.AARP_COPAY_AMT,0.00)
         ELSE 0.00
         END AARP_COPAY_AMT,
    CASE WHEN CHRG_TBL_IND = ''D'' THEN NVL(D.BL_NO_PAY_IND,''U'')
         WHEN CHRG_TBL_IND = ''H'' THEN NVL(HSP.BL_NO_PAY_IND,''U'')
         WHEN CHRG_TBL_IND = ''P'' THEN NVL(PRF.BL_NO_PAY_IND,''U'')
         ELSE ''U''
         END BL_NO_PAY_IND,
    NVL(TRIM(B.REND_PRV_NM),''UNKNOWN'') AS RNDR_PROV_NM,
	-1					AS D_DSCNT_ANNL_PAYR_SK,
	-1					AS D_DSCNT_EFT_SK,
	-1					AS D_DSCNT_ERLY_ENRL_SK,
	-1					AS D_DSCNT_LNGVTY_SK,
	-1					AS D_DSCNT_MULTI_INSD_SK,
	-1					AS D_SURCHRG_TIER_SK,
	-1					AS D_SURCHRG_TBCC_USER_SK,
	-1					AS D_INSD_PLN_PRFL_SK,
	-1					AS D_CALC_RT_SK,
	999.99				AS MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
	999.99				AS CERT_EFF_AGE_LOOK_FRAC,
	-1                              D_LGL_ENTY_SK,
        -1                              SRVC_DT_D_GEO_XREF_SK
FROM BDR_DM.wrk_ucps_claim_history C
INNER JOIN SRC_FOX_D.BIL_LN_HIST2 B    ON C.ch_acct_part_num = B.ch_acct_part_num AND C.ch_key = B.ch_key
INNER JOIN BDR_DM.f_clm_hist CF          ON C.clm_num = CF.clm_nbr
                                     and C.DT_CMPLTD_V = CF.CMPL_DT_ID ---SB - 01/17/2017 : Added condition to avoid dups due to Claim reusability (after 10 years)
LEFT JOIN BDR_DM.d_cpt_look CPT          ON B.cpt_cd = CPT.cpt_cd
LEFT JOIN BDR_DM.d_cpt_mod_look Mod1	 ON B.proc_mod1 = Mod1.cpt_mod_cd
LEFT JOIN BDR_DM.d_cpt_mod_look Mod2	 ON B.proc_mod2 = Mod2.cpt_mod_cd
LEFT JOIN BDR_DM.d_cpt_mod_look Mod3     ON B.proc_mod3 = Mod3.cpt_mod_cd
LEFT JOIN BDR_DM.d_cpt_mod_look Mod4	 ON B.proc_mod4 = Mod4.cpt_mod_cd
LEFT JOIN BDR_CONF.D_PROV PRV			 ON B.BL_PROV_KEY = UCPS_PROV_ID
LEFT JOIN BDR_DM.D_TOS T				 ON TRIM(NVL(TO_CHAR(B.SRV_CD), '''')||NVL(TO_CHAR(B.TYP_CD), '''')) = T.TOS_CD
LEFT JOIN SRC_FOX_D.RX_CHRG D ON B.CH_ACCT_PART_NUM = D.CH_ACCT_PART_NUM AND B.CHRG_KEY = D.RX_CHRG_KEY
LEFT JOIN SRC_FOX_D.HOSP_CHRG HSP ON B.CH_ACCT_PART_NUM = HSP.CH_ACCT_PART_NUM AND B.CHRG_KEY = HSP.HOSP_CHRG_KEY
LEFT JOIN SRC_FOX_D.PROF_CHRG PRF ON B.CH_ACCT_PART_NUM = PRF.CH_ACCT_PART_NUM AND B.CHRG_KEY = PRF.PROF_CHRG_KEY
LEFT JOIN SRC_FOX_D.OOP_BIL_LN OOP ON B.CH_ACCT_PART_NUM = OOP.CH_ACCT_PART_NUM AND B.BLH_KEY = OOP.BLH_KEY
WHERE (C.maintance_claim_ind = 0
AND   trim(NVL(TO_CHAR(B.SRV_CD), '''')||NVL(TO_CHAR(B.TYP_CD), '''')) NOT  IN (''Y1'',''Y2'',''Y3'',''Y4'',''Z''))
ORDER BY CF.f_clm_hist_sk,
         B.ch_key,
         B.BIL_LN_NUM;
  --commit;
  
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );
     
	 
	 --COMMENTED BY OAS--
	 /*V_ROWS_AFFTD:=SQL%ROWCOUNT;

INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''FACT_CLAIMS'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''INSERT'',
      ''Insert into temp table WRK_BIL_LN'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );

--commit;
--DBMS_STATS.GATHER_TABLE_STATS (OWNNAME => ''DM'',TABNAME => ''WRK_BIL_LN'',PARTNAME => NULL,ESTIMATE_PERCENT => 10, DEGREE => 4, GRANULARITY => ''ALL'', METHOD_OPT => ''FOR ALL COLUMNS SIZE 1'',CASCADE => TRUE);

BDR_DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''WRK_BIL_LN''); -- Adding stats 02/01/2018*/
--COMMENTED BY OAS--


V_STEP_NAME    := ''MERGE - WRK_BIL_LN'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

MERGE /*+ enable_parallel_dml */ INTO  BDR_DM.WRK_BIL_LN TGT  USING
(
        SELECT  /*+ parallel(8) */ WBL.WRK_BIL_LN_SK, L.D_LGL_ENTY_SK
        FROM            BDR_DM.WRK_BIL_LN WBL
        INNER JOIN      (SELECT CLM_NBR,MAX(NVL(LE_FINC_CD,'''')) LE_FINC_CD FROM SRC_FOX_D.TMEMB2_CLAIM2_NUM2 WHERE CLM_STS_CD IN (''D'',''R'') GROUP BY CLM_NBR)  TMEM ON WBL.CLM_NBR = TO_NUMBER(NULLIF((NVL(TO_CHAR(SUBSTR(LPAD(TMEM.CLM_NBR, 12, ''0''),4,9)), '''')||NVL(TO_CHAR(SUBSTR(LPAD(TMEM.CLM_NBR, 12, ''0''),1,3)), '''')), ''''))
        INNER JOIN  BDR_CONF.D_LGL_ENTY L ON UPPER(TRIM(NVL(TMEM.LE_FINC_CD,''NULL''))) = UPPER(TRIM(REPLACE(LGL_ENTY_NM,'' '','''')))
) SRC   ON (SRC.WRK_BIL_LN_SK=TGT.WRK_BIL_LN_SK)
WHEN MATCHED THEN UPDATE
SET TGT.D_LGL_ENTY_SK = NVL(SRC.D_LGL_ENTY_SK,-1);
	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

--commit;

/* BDR_DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''WRK_BIL_LN''); --SB : Added Legal entty change


------------Update SRVC_DT_D_GEO_XREF_SK using OPREC_CLAIM daily------------------

BDR_DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''WRK_BIL_LN''); -- Adding stats 02/01/2018 */		--OAS DELETE

V_STEP_NAME    := ''MERGE - WRK_BIL_LN'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

MERGE /*+ enable_parallel_dml */ INTO  BDR_DM.WRK_BIL_LN TGT  USING
(
        SELECT  /*+ parallel(8) */ WBL.WRK_BIL_LN_SK, WBL.D_LGL_ENTY_SK, MAX(L.D_GEO_XREF_SK) AS D_GEO_XREF_SK
        FROM            BDR_DM.WRK_BIL_LN WBL
        INNER JOIN      /*FF_OPREC_CLAIMS*/ BDR_DM.STG_OPREC_CLAIMS OPBL ON WBL.CLM_NBR = OPBL.CLAIM_NUMBER
                                                     AND WBL.CMPL_DT_ID = OPBL.PROCESS_DATE
        INNER JOIN      BDR_CONF.D_GEO_XREF L ON OPBL.INSURED_ZIP = L.ZIP_CD AND OPBL.INSURED_STATE = L.D_ST_CD
        GROUP BY WBL.WRK_BIL_LN_SK, WBL.D_LGL_ENTY_SK
) SRC   ON (SRC.WRK_BIL_LN_SK=TGT.WRK_BIL_LN_SK)
WHEN MATCHED THEN UPDATE
SET TGT.SRVC_DT_D_GEO_XREF_SK = NVL(SRC.D_GEO_XREF_SK,-1);
--commit;
	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

--BDR_DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''WRK_BIL_LN'');		--OAS DELETE

-------------- Fetch the Accounts from isid_xref --------------



/*
   MERGE INTO BDR_DM.wrk_bil_ln bln USING
   (SELECT bln2.wrk_bil_ln_sk,
     CASE
       WHEN CP.prdct IN (''Med Supp'',''Indemnity'')
       THEN CP.prdct
       ELSE ''Default''
     END prdct,
     CAST(CP.compas_pln_cd AS VARCHAR(5)) compas_pln_cd,
     NVL(CP.d_clm_pln_sk,                       -1) d_clm_pln_sk,
     NVL(NVL(M1.d_mbr_info_sk,M2.d_mbr_info_sk),-1) d_mbr_info_sk,
     NVL(NVL(M1.isid,M2.isid),                  -1) isid
   FROM BDR_DM.wrk_bil_ln bln2
   LEFT OUTER JOIN BDR_DM.d_clm_pln CP
   ON (bln2.plan_cd = CP.ucps_pln_cd
   AND
     CASE
       WHEN LTRIM(RTRIM(bln2.plan_ind)) IN (''1'','''')
       THEN LTRIM(RTRIM(bln2.plan_ind))
       ELSE ''0''
     END = CP.UCPS_pln_ind )
   LEFT JOIN
     (SELECT indv_id,
       acct_nbr,
       isid,
       isid_xref_strt_dt,
       isid_xref_end_dt,
       COUNT(DISTINCT indv_id) OVER (PARTITION BY acct_nbr) cnt
     FROM
       ( SELECT DISTINCT indv_id,
         acct_nbr,
         isid,
         isid_xref_strt_dt,
         isid_xref_end_dt
       FROM isid.isid_xref
       WHERE data_src_id                <> ''CDW/ACCOUNT''
       AND addr_typ_id                   = 1
       AND NVL(hsehld_prfl_del_ind,''N'') <> ''Y''
       AND acct_nbr NOT LIKE ''000000000%''
       )
     ) isidDtl
   ON bln2.acct_nbr = isidDtl.acct_nbr
   AND (
     CASE
       WHEN isidDtl.cnt = 1
       THEN 1
       WHEN isidDtl.cnt > 1
       AND TO_DATE(bln2.cmpl_dt_id,''YYYYMMDD'') BETWEEN isidDtl.isid_xref_strt_dt AND isidDtl.isid_xref_end_dt
       THEN 1
       ELSE 0
     END)=1
   LEFT JOIN conf.d_mbr_info M1
   ON isidDtl.indv_id = M1.indv_id
   LEFT JOIN conf.d_mbr_info M2
   ON M1.isid                = M2.isid
   )blnDtl ON (blnDtl.wrk_bil_ln_sk=bln.wrk_bil_ln_sk)
   WHEN MATCHED THEN
     UPDATE
     SET bln.prdct       = blnDtl.prdct,
       bln.compas_pln_cd = blnDtl.compas_pln_cd,
       bln.d_clm_pln_sk  = blnDtl.d_clm_pln_sk,
       bln.d_mbr_info_sk = blnDtl.d_mbr_info_sk,
       bln.isid          = blnDtl.isid;
 */

--SELECT METADATA_VALUE INTO V_LE_NAME FROM ETL.ETL_APPLICATION_METADATA WHERE METADATA_TYPE=''LE_NAME'';	--OAS DELETE

V_STEP_NAME    := ''MERGE - WRK_BIL_LN'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

 MERGE /*+ ENABLE_PARALLEL_DML */ INTO BDR_DM.wrk_bil_ln bln USING
   (SELECT
   /*+ parallel(8) */
   bln2.wrk_bil_ln_sk,
     CASE
       WHEN MIN(CP.prdct) IN (''Med Supp'',''Indemnity'')
       THEN MIN(CP.prdct)
       ELSE ''Default''
     END prdct,
     CAST(MIN(CP.compas_pln_cd) AS VARCHAR(50)) compas_pln_cd,
     --NVL(MIN(CP.d_clm_pln_sk),                       -1) d_clm_pln_sk,
	 CASE
     WHEN MIN(DLE.LGL_ENTY_NM) in (:V_LE_NAME)
          THEN NVL(MIN(CP_NLE.d_clm_pln_sk),-1)
     ELSE NVL(MIN(CP.d_clm_pln_sk),-1) end d_clm_pln_sk,
     NVL(NVL(M1.d_mbr_info_sk,M2.d_mbr_info_sk),-1) d_mbr_info_sk,
     NVL(NVL(M1.isid,M2.isid),                  -1) isid
     , row_number () over(partition by BLN2.WRK_BIL_LN_SK order by NVL(NVL(M1.D_MBR_INFO_SK,M2.D_MBR_INFO_SK),-1) desc,  NVL(NVL(M1.ISID,M2.ISID), -1) desc) rn --Added rn to eliminate multiple isid matching for same acc_nbr
   FROM BDR_DM.wrk_bil_ln bln2
   LEFT OUTER JOIN BDR_CONF.D_LGL_ENTY dle on dle.D_LGL_ENTY_SK = bln2.D_LGL_ENTY_SK
     LEFT OUTER JOIN BDR_DM.d_clm_pln CP
   ON (TRIM(bln2.plan_cd) = TRIM(CP.ucps_pln_cd) --New Condition added to meet ''E ''(''E(SPACE)'')
   AND
     (CASE
       WHEN ( LTRIM(RTRIM(bln2.plan_ind)) IN (''1'',''''))
       THEN LTRIM(RTRIM(bln2.plan_ind))
       WHEN ( LTRIM(RTRIM(bln2.plan_ind)) = '''' OR  LTRIM(RTRIM(bln2.plan_ind)) IS NULL ) --New Condition added to Meet CHR(0) by Jibin
       THEN ''''
       ELSE ''0''
     END) = NVL(CP.UCPS_pln_ind,'''') )
	 LEFT OUTER JOIN (select * from BDR_DM.d_clm_pln where COMPAS_PLN_CD in (''NS2'',''N02'',''L02'',''K02'',''GS2'',''G02'',''FS2'',''F02'',''D02'',''CS2'',''C02'',''B02'',''A02'')) CP_nle
   ON ((TRIM(bln2.plan_cd) = TRIM(CP_nle.ucps_pln_cd))
   AND
     (CASE
       WHEN ( LTRIM(RTRIM(bln2.plan_ind)) IN (''1'',''''))
       THEN LTRIM(RTRIM(bln2.plan_ind))
       WHEN ( LTRIM(RTRIM(bln2.plan_ind)) = '''' OR  LTRIM(RTRIM(bln2.plan_ind)) IS NULL ) --New Condition added to Meet CHR(0) by Jibin
       THEN ''''
       ELSE ''0''
     END) = NVL(CP_nle.UCPS_pln_ind,'''')
	 )
   LEFT JOIN
     (select distinct
 indv_id,
       acct_nbr,
       isid,
       case when cnt =1 then trunc(CURRENT_DATE, ''DD'') else isid_xref_strt_dt end isid_xref_strt_dt,
       case when cnt =1 then trunc(CURRENT_DATE, ''DD'') else isid_xref_end_dt end isid_xref_end_dt,
       cnt from (
SELECT indv_id,
       acct_nbr,
       isid,
       isid_xref_strt_dt,
       isid_xref_end_dt,
       COUNT(DISTINCT indv_id) OVER (PARTITION BY acct_nbr) cnt
     FROM
       ( SELECT DISTINCT indv_id,
         acct_nbr,
         isid,
         isid_xref_strt_dt,
         isid_xref_end_dt
       FROM BDR_ISID.isid_xref
       WHERE data_src_id                <> ''CDW/ACCOUNT''
       AND addr_typ_id                   = 1
       AND NVL(hsehld_prfl_del_ind,''N'') <> ''Y''
       AND acct_nbr NOT LIKE ''000000000%''
       ))
     ) isidDtl
   ON bln2.acct_nbr = isidDtl.acct_nbr
   AND (
     CASE
       WHEN isidDtl.cnt = 1
       THEN 1
       WHEN isidDtl.cnt > 1
       AND TO_DATE(TO_CHAR(bln2.cmpl_dt_id),''YYYYMMDD'') BETWEEN isidDtl.isid_xref_strt_dt AND isidDtl.isid_xref_end_dt
       THEN 1
       ELSE 0
     END)=1
   LEFT JOIN BDR_CONF.d_mbr_info M1
   ON isidDtl.indv_id = M1.indv_id
   LEFT JOIN BDR_CONF.d_mbr_info M2
   ON M1.isid                = M2.isid

   GROUP BY  bln2.wrk_bil_ln_sk,
   NVL(NVL(M1.d_mbr_info_sk,M2.d_mbr_info_sk),-1), NVL(NVL(M1.isid,M2.isid),-1)

   )blnDtl ON (blnDtl.wrk_bil_ln_sk=bln.wrk_bil_ln_sk and rn=1) --Added condition rn=1 to avoid multiple isid matching for same acc_nbr
   WHEN MATCHED THEN
     UPDATE
     SET bln.prdct       = blnDtl.prdct,
       bln.compas_pln_cd = blnDtl.compas_pln_cd,
       bln.d_clm_pln_sk  = blnDtl.d_clm_pln_sk,
       bln.d_mbr_info_sk = blnDtl.d_mbr_info_sk,
       bln.isid          = blnDtl.isid;
	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

--COMMENTED BY OAS--
/*V_ROWS_AFFTD:=SQL%ROWCOUNT;
--commit;

INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''FACT_CLAIMS'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''MERGE1'',
      ''Merge into temp table WRK_BIL_LN'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );*/
	
--commit;
--COMMENTED BY OAS--
------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------Start of derive d_ben_sk logic----------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------

-----------------------Added ehancement logic to avoid daily failure---FOX is not updating Hsp SNF for No pay duplicate claims

V_STEP_NAME    := ''MERGE - WRK_BIL_LN'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

MERGE /*+ enable_parallel_dml */ INTO  BDR_DM.WRK_BIL_LN TGT  USING
(
		SELECT 	/*+ PARALLEL(8) */ DISTINCT B.WRK_BIL_LN_SK,B.BLH_KEY,C.CLM_NUM,C.CLM_STAT,C.DT_CMPLTD_V,C.CH_KEY,B.HOSP_CHRG_KEY,C.TOT_BEN,B.BEN_AMT,
		                          C.NO_PAY_IND,BL_DUP_IND,HSP.SRV_DAY,HSP.MCARE_HSP_IHD,HSP.MCARE_HSP_DAYS1,HSP.MCARE_HSP_DAYS2,HSP.MCARE_HSP_DAYS3,MAINTANCE_CLAIM_IND,
		                          UCPS_PLN_CD,UCPS_PLN_IND,CP.PRDCT,B.TOSCODE,B.HSP_SNF_DAYS_IND,
		                          CASE WHEN SRV_DAY BETWEEN  1 AND 60 THEN 2
		                               WHEN SRV_DAY BETWEEN 61 AND 90 THEN 3
		                               WHEN SRV_DAY > 91 THEN 4
		                               END DER_HSP_SNF_DAYS_IND
		FROM 	BDR_DM.WRK_UCPS_CLAIM_HISTORY C
		JOIN 	BDR_DM.WRK_BIL_LN B    ON C.CH_ACCT_PART_NUM = B.CH_ACCT_PART_NUM AND C.CH_KEY = B.CH_KEY
		JOIN 	SRC_FOX_D.HOSP_CHRG HSP ON B.CH_ACCT_PART_NUM = HSP.CH_ACCT_PART_NUM AND B.HOSP_CHRG_KEY = HSP.HOSP_CHRG_KEY
		JOIN 	BDR_DM.D_CLM_PLN CP ON  (TRIM(B.PLAN_CD) = TRIM(CP.UCPS_PLN_CD) --NEW CONDITION ADDED TO MEET ''E ''(''E(SPACE)'')
		   						AND (CASE WHEN ( LTRIM(RTRIM(B.PLAN_IND)) IN (''1'',''''))
		       							  THEN LTRIM(RTRIM(B.PLAN_IND))
		       							  WHEN ( LTRIM(RTRIM(B.PLAN_IND)) = '''' OR  LTRIM(RTRIM(B.PLAN_IND)) IS NULL ) --NEW CONDITION ADDED TO MEET CHR(0) BY JIBIN
		       							  THEN ''''
		       							  ELSE ''0''
		     							  END) = NVL(CP.UCPS_PLN_IND,'''') )
		WHERE 	C.MAINTANCE_CLAIM_IND = 0
		AND   	B.TOSCODE = ''H2'' AND NO_PAY_IND = ''Y'' AND CP.PRDCT = ''Med Supp''
		AND    (HSP.MCARE_HSP_DAYS1 > 0 OR HSP.MCARE_HSP_DAYS2 > 0 OR HSP.MCARE_HSP_DAYS3 > 0)  AND HSP.MCARE_HSP_IHD = '' ''
) SRC   ON     (SRC.WRK_BIL_LN_SK=TGT.WRK_BIL_LN_SK)
WHEN MATCHED THEN UPDATE
SET TGT.HSP_SNF_DAYS_IND = DER_HSP_SNF_DAYS_IND;
	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

--COMMENTED BY OAS--
/*V_ROWS_AFFTD:=SQL%ROWCOUNT;

INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''FACT_CLAIMS'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''MERGE'',
      ''Update HSP_SNF_DAYS_IND for No pay claims'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );*/
--commit;
--COMMENTED BY OAS--
------------------------------------------------------------------------------------------------------------------------------------


   --Derive d_ben_sk where there is no business rule(Straigt mapping)

  /*
   UPDATE BDR_DM.wrk_bil_ln bl
   SET d_ben_sk = NVL(
     (SELECT NVL(B.d_ben_sk,-1)
     FROM BDR_CONF.d_ben B
     WHERE BL.prdct       = B.prdct
     AND BL.TOSCode       = B.ben_tos_cd
     AND (BL.TOSCode NOT IN (''H2'',''W0'',''W1'',''W2'',''W4'',''W5'',''W6''))
       OR (BL.TOSCode      IN (''H2'',''W0'',''W1'',''W2'',''W3'',''W4'',''W5'',''W6'')   AND BL.prdct         = ''Indemnity'')
     ),                   -1)
   WHERE (BL.TOSCode NOT IN (''H2'',''W0'',''W1'',''W2'',''W4'',''W5'',''W6''))
   OR (BL.TOSCode        IN (''H2'',''W0'',''W1'',''W2'',''W3'',''W4'',''W5'',''W6'')
   AND BL.prdct           = ''Indemnity'');*/

V_STEP_NAME    := ''MERGE - WRK_BIL_LN'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

    MERGE /*+ enable_parallel_dml */ INTO  BDR_DM.wrk_bil_ln TGT  USING
   (
     SELECT /*+ parallel(8) */ MAX(NVL(B.d_ben_sk,-1)) d_ben_sk,bli.WRK_BIL_LN_SK
     FROM BDR_DM.wrk_bil_ln bli  LEFT OUTER JOIN BDR_CONF.d_ben B
     ON bli.prdct       = B.prdct AND bli.TOSCode       = TRIM(B.ben_tos_cd)
     WHERE ((bli.TOSCode NOT IN (''H2'',''W0'',''W1'',''W2'',''W4'',''W5'',''W6''))
     OR (bli.TOSCode      IN (''H2'',''W0'',''W1'',''W2'',''W3'',''W4'',''W5'',''W6'')
     AND bli.prdct         = ''Indemnity''))  GROUP BY bli.WRK_BIL_LN_SK
    ) SRC
   ON (SRC.WRK_BIL_LN_SK=TGT.WRK_BIL_LN_SK)
   WHEN MATCHED THEN UPDATE
   SET TGT.d_ben_sk=SRC.d_ben_sk;
	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

 --COMMENTED BY OAS--
 /*V_ROWS_AFFTD:=SQL%ROWCOUNT;

 --commit;


INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''FACT_CLAIMS'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''MERGE2'',
      ''Merge into temp table WRK_BIL_LN'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );*/

--commit;
--COMMENTED BY OAS--
  --Derive d_ben_sk where TOSCODE IN (''N1'',''N2'',''N3'',''N4'') irrespective of prdct and there is no business rule(Straigt mapping)

V_STEP_NAME    := ''MERGE - WRK_BIL_LN'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

   MERGE  INTO BDR_DM.wrk_bil_ln bl
   USING (SELECT B.prdct,TRIM(B.ben_tos_cd) ben_tos_cd,B.d_ben_sk
            FROM BDR_CONF.d_ben B
           WHERE TRIM(B.ben_tos_cd) IN (''N1'',''N2'',''N3'',''N4'')) B
   ON (BL.TOSCode = TRIM(B.ben_tos_cd) AND BL.TOSCode IN (''N1'',''N2'',''N3'',''N4''))  --Changed by Jibin(BL.prdct = B.prdct AND   BL.TOSCode = B.ben_tos_cd AND BL.TOSCode IN (''N1'',''N2'',''N3'',''N4''))
   WHEN MATCHED THEN
   UPDATE SET BL.d_ben_sk = B.d_ben_sk;
	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

 --COMMENTED BY OAS--
 /*V_ROWS_AFFTD:=SQL%ROWCOUNT;

--commit;
INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''FACT_CLAIMS'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''MERGE3'',
      ''Merge into temp table WRK_BIL_LN'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );*/

--commit;
--COMMENTED BY OAS--

   --Derive d_ben_sk with business rule(Straigt mapping) where HspSNFInd is populated between 1 and 8

  /* MERGE INTO BDR_DM.wrk_bil_ln bln
   USING (SELECT bl.wrk_bil_ln_sk,
             CASE WHEN BL.TOSCode = ''H2'' AND BL.hsp_snf_days_ind = ''1''
								  THEN BenSKeyH2Z1
								  WHEN BL.TOSCode = ''H2'' AND BL.hsp_snf_days_ind = ''2''
								  THEN BenSKeyH2Z2
								  WHEN BL.TOSCode = ''H2'' AND BL.hsp_snf_days_ind = ''3''
								  THEN BenSKeyH2Z3
								  WHEN BL.TOSCode = ''H2'' AND BL.hsp_snf_days_ind IN (''4'',''5'') AND Hsp.mcare_hsp_ltr_optn =
''N''
								  THEN BenSKeyH245N
								  WHEN BL.TOSCode = ''H2'' AND BL.hsp_snf_days_ind IN (''4'',''5'') AND Hsp.mcare_hsp_ltr_optn <>
''N''
								  THEN BenSKeyH245NotN
								  WHEN BL.TOSCode = ''W0'' AND BL.hsp_snf_days_ind = ''6''
								  THEN BenSKeyW0Z6
								  WHEN BL.TOSCode = ''W0'' AND BL.hsp_snf_days_ind = ''7''
								  THEN BenSKeyW0Z7
								  WHEN BL.TOSCode = ''W0'' AND BL.hsp_snf_days_ind = ''8''
								  THEN BenSKeyW0Z8
								  WHEN BL.TOSCode = ''W1'' AND BL.hsp_snf_days_ind = ''6''
								  THEN BenSKeyW1Z6
								  WHEN BL.TOSCode = ''W1'' AND BL.hsp_snf_days_ind = ''7''
								  THEN BenSKeyW1Z7
								  WHEN BL.TOSCode = ''W1'' AND BL.hsp_snf_days_ind = ''8''
								  THEN BenSKeyW1Z8
								  WHEN BL.TOSCode = ''W2'' AND BL.hsp_snf_days_ind = ''6''
								  THEN BenSKeyW2Z6
								  WHEN BL.TOSCode = ''W2'' AND BL.hsp_snf_days_ind = ''7''
								  THEN BenSKeyW2Z7
								  WHEN BL.TOSCode = ''W2'' AND BL.hsp_snf_days_ind = ''8''
								  THEN BenSKeyW2Z8
								  WHEN BL.TOSCode = ''W4'' AND BL.hsp_snf_days_ind = ''6''
								  THEN BenSKeyW4Z6
								  WHEN BL.TOSCode = ''W4'' AND BL.hsp_snf_days_ind = ''7''
								  THEN BenSKeyW4Z7
								  WHEN BL.TOSCode = ''W4'' AND BL.hsp_snf_days_ind = ''8''
								  THEN BenSKeyW4Z8
								  WHEN BL.TOSCode = ''W5'' AND BL.hsp_snf_days_ind = ''6''
								  THEN BenSKeyW5Z6
								  WHEN BL.TOSCode = ''W5'' AND BL.hsp_snf_days_ind = ''7''
								  THEN BenSKeyW5Z7
								  WHEN BL.TOSCode = ''W5'' AND BL.hsp_snf_days_ind = ''8''
								  THEN BenSKeyW5Z8
								  WHEN BL.TOSCode = ''W6'' AND BL.hsp_snf_days_ind = ''6''
								  THEN BenSKeyW6Z6
								  WHEN BL.TOSCode = ''W6'' AND BL.hsp_snf_days_ind = ''7''
								  THEN BenSKeyW6Z7
								  WHEN BL.TOSCode = ''W6'' AND BL.hsp_snf_days_ind = ''8''
								  THEN BenSKeyW6Z8
								  ELSE B.d_ben_sk
								  END d_ben_sk
						FROM BDR_DM.wrk_bil_ln bl
            LEFT  JOIN  SRC_FOX_D.HOSP_CHRG Hsp
              ON			BL.ch_acct_part_num = Hsp.ch_acct_part_num AND BL.ch_key = Hsp.ch_key AND BL.hosp_chrg_key = Hsp.hosp_chrg_key
            INNER JOIN	BDR_CONF.d_ben B
              ON			BL.prdct = B.prdct AND BL.TOSCode = B.ben_tos_cd
            WHERE		(BL.hsp_snf_days_ind BETWEEN ''1'' AND ''8'')  AND (BL.TOScode IN (''H2'',''W0'',''W1'',''W2'',''W4'',''W5'',''W6'')))blDtl
         ON(blDtl.wrk_bil_ln_sk = bln.wrk_bil_ln_sk)
         WHEN MATCHED THEN
         UPDATE SET bln.d_ben_sk=blDtl.d_ben_sk
                   ,bln.snf_process_ind = 1;*/



V_STEP_NAME    := ''MERGE - WRK_BIL_LN'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

   MERGE  INTO BDR_DM.wrk_bil_ln bln
   USING (SELECT  bl.wrk_bil_ln_sk,
             CASE WHEN BL.TOSCode = ''H2'' AND BL.hsp_snf_days_ind = ''1''
								  THEN :BenSKeyH2Z1
								  WHEN BL.TOSCode = ''H2'' AND BL.hsp_snf_days_ind = ''2''
								  THEN :BenSKeyH2Z2
								  WHEN BL.TOSCode = ''H2'' AND BL.hsp_snf_days_ind = ''3''
								  THEN :BenSKeyH2Z3
								  WHEN BL.TOSCode = ''H2'' AND BL.hsp_snf_days_ind IN (''4'',''5'') AND Hsp.mcare_hsp_ltr_optn = ''N''
								  THEN :BenSKeyH245N
								  WHEN BL.TOSCode = ''H2'' AND BL.hsp_snf_days_ind IN (''4'',''5'') AND NVL(Hsp.mcare_hsp_ltr_optn,'' '') <> ''N''
								  THEN :BenSKeyH245NotN
								  WHEN BL.TOSCode = ''W0'' AND BL.hsp_snf_days_ind = ''6''
								  THEN :BenSKeyW0Z6
								  WHEN BL.TOSCode = ''W0'' AND BL.hsp_snf_days_ind = ''7''
								  THEN :BenSKeyW0Z7
								  WHEN BL.TOSCode = ''W0'' AND BL.hsp_snf_days_ind = ''8''
								  THEN :BenSKeyW0Z8
								  WHEN BL.TOSCode = ''W1'' AND BL.hsp_snf_days_ind = ''6''
								  THEN :BenSKeyW1Z6
								  WHEN BL.TOSCode = ''W1'' AND BL.hsp_snf_days_ind = ''7''
								  THEN :BenSKeyW1Z7
								  WHEN BL.TOSCode = ''W1'' AND BL.hsp_snf_days_ind = ''8''
								  THEN :BenSKeyW1Z8
								  WHEN BL.TOSCode = ''W2'' AND BL.hsp_snf_days_ind = ''6''
								  THEN :BenSKeyW2Z6
								  WHEN BL.TOSCode = ''W2'' AND BL.hsp_snf_days_ind = ''7''
								  THEN :BenSKeyW2Z7
								  WHEN BL.TOSCode = ''W2'' AND BL.hsp_snf_days_ind = ''8''
								  THEN :BenSKeyW2Z8
								  WHEN BL.TOSCode = ''W4'' AND BL.hsp_snf_days_ind = ''6''
								  THEN :BenSKeyW4Z6
								  WHEN BL.TOSCode = ''W4'' AND BL.hsp_snf_days_ind = ''7''
								  THEN :BenSKeyW4Z7
								  WHEN BL.TOSCode = ''W4'' AND BL.hsp_snf_days_ind = ''8''
								  THEN :BenSKeyW4Z8
								  WHEN BL.TOSCode = ''W5'' AND BL.hsp_snf_days_ind = ''6''
								  THEN :BenSKeyW5Z6
								  WHEN BL.TOSCode = ''W5'' AND BL.hsp_snf_days_ind = ''7''
								  THEN :BenSKeyW5Z7
								  WHEN BL.TOSCode = ''W5'' AND BL.hsp_snf_days_ind = ''8''
								  THEN :BenSKeyW5Z8
								  WHEN BL.TOSCode = ''W6'' AND BL.hsp_snf_days_ind = ''6''
								  THEN :BenSKeyW6Z6
								  WHEN BL.TOSCode = ''W6'' AND BL.hsp_snf_days_ind = ''7''
								  THEN :BenSKeyW6Z7
								  WHEN BL.TOSCode = ''W6'' AND BL.hsp_snf_days_ind = ''8''
								  THEN :BenSKeyW6Z8
								  ELSE -1
								  END d_ben_sk
						FROM BDR_DM.wrk_bil_ln bl
            LEFT  JOIN  SRC_FOX_D.HOSP_CHRG Hsp
              ON			BL.ch_acct_part_num = Hsp.ch_acct_part_num AND BL.ch_key = Hsp.ch_key AND BL.hosp_chrg_key = Hsp.hosp_chrg_key
            --INNER JOIN	BDR_CONF.d_ben B
             -- ON			BL.prdct = B.prdct AND BL.TOSCode = TRIM(B.ben_tos_cd)
            WHERE		(BL.hsp_snf_days_ind BETWEEN ''1'' AND ''8'')  AND (BL.TOScode IN (''H2'',''W0'',''W1'',''W2'',''W4'',''W5'',''W6''))
            GROUP BY bl.wrk_bil_ln_sk,BL.TOSCode,BL.hsp_snf_days_ind,Hsp.mcare_hsp_ltr_optn
            )blDtl
         ON(blDtl.wrk_bil_ln_sk = bln.wrk_bil_ln_sk)
         WHEN MATCHED THEN
         UPDATE SET bln.d_ben_sk=blDtl.d_ben_sk
                   ,bln.snf_process_ind = 1;
	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

 --COMMENTED BY OAS--
 /*V_ROWS_AFFTD:=SQL%ROWCOUNT;
--commit;
INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''FACT_CLAIMS'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''MERGE4'',
      ''Merge into temp table WRK_BIL_LN'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );*/
--commit;
--COMMENTED BY OAS--

   /*

WITH CTE_ToUnPivot
AS
(
SELECT		CH_ACCT_PART_NUM, CH_Key, Hosp_Chrg_Key, TOSCode, PRDCT, Hsp_Snf_Days_Ind, PLAN_CD,
			CASE
            WHEN TOScode = ''W0'' AND Mcare_Snf_Days1 IS NOT NULL THEN ''@Ben_SKey_W0Z6@''
            WHEN TOScode = ''W1'' AND Mcare_Snf_Days1 IS NOT NULL THEN ''@Ben_SKey_W1Z6@''
            WHEN TOScode = ''W2'' AND Mcare_Snf_Days1 IS NOT NULL THEN ''@Ben_SKey_W2Z6@''
            WHEN TOScode = ''W4'' AND Mcare_Snf_Days1 IS NOT NULL THEN ''@Ben_SKey_W4Z6@''
            WHEN TOScode = ''W5'' AND Mcare_Snf_Days1 IS NOT NULL THEN ''@Ben_SKey_W5Z6@''
            WHEN TOScode = ''W6'' AND Mcare_Snf_Days1 IS NOT NULL THEN ''@Ben_SKey_W6Z6@''
            ELSE ''-1'' END DRN1,
			CASE
            WHEN TOScode = ''W0'' AND Mcare_Snf_Days2 IS NOT NULL THEN ''@Ben_SKey_W0Z7@''
            WHEN TOScode = ''W1'' AND Mcare_Snf_Days2 IS NOT NULL THEN ''@Ben_SKey_W1Z7@''
            WHEN TOScode = ''W2'' AND Mcare_Snf_Days2 IS NOT NULL THEN ''@Ben_SKey_W2Z7@''
            WHEN TOScode = ''W4'' AND Mcare_Snf_Days2 IS NOT NULL THEN ''@Ben_SKey_W4Z7@''
            WHEN TOScode = ''W5'' AND Mcare_Snf_Days2 IS NOT NULL THEN ''@Ben_SKey_W5Z7@''
            WHEN TOScode = ''W6'' AND Mcare_Snf_Days2 IS NOT NULL THEN ''@Ben_SKey_W6Z7@''
            ELSE ''-1'' END DRN2,
			CASE
            WHEN TOScode = ''W0'' AND Mcare_Snf_Days3 IS NOT NULL THEN ''@Ben_SKey_W0Z8@''
            WHEN TOScode = ''W1'' AND Mcare_Snf_Days3 IS NOT NULL THEN ''@Ben_SKey_W1Z8@''
            WHEN TOScode = ''W2'' AND Mcare_Snf_Days3 IS NOT NULL THEN ''@Ben_SKey_W2Z8@''
            WHEN TOScode = ''W4'' AND Mcare_Snf_Days3 IS NOT NULL THEN ''@Ben_SKey_W4Z8@''
            WHEN TOScode = ''W5'' AND Mcare_Snf_Days3 IS NOT NULL THEN ''@Ben_SKey_W5Z8@''
            WHEN TOScode = ''W6'' AND Mcare_Snf_Days3 IS NOT NULL THEN ''@Ben_SKey_W6Z8@''
            ELSE ''-1'' END DRN3
			,''-1'' DRN4,''-1'' DRN5 FROM (SELECT DISTINCT BL.CH_ACCT_PART_NUM, BL.CH_Key, BL.Hosp_Chrg_Key, BL.TOSCode, BL.PRDCT,
BL.Hsp_Snf_Days_Ind, BL.PLAN_CD,
			Hsp.Mcare_Hsp_Ihd,Hsp.Mcare_Hsp_Days1,Hsp.Mcare_Hsp_Days2,Hsp.Mcare_Hsp_Days3,Hsp.Mcare_Hsp_Ltr_Optn,
			Hsp.Mcare_Snf_Days1,Hsp.Mcare_Snf_Days2,Hsp.Mcare_Snf_Days3
FROM BDR_DM.WRK_BIL_LN BL
LEFT  JOIN  SRC_FOX_D.HOSP_CHRG Hsp
ON			BL.CH_ACCT_PART_NUM = Hsp.CH_ACCT_PART_NUM AND BL.Hosp_Chrg_Key = Hsp.Hosp_Chrg_Key
WHERE		BL.Hsp_Snf_Days_Ind = ''Z''  AND BL.TOSCODE IN (''W0'',''W1'',''W2'',''W4'',''W5'',''W6'') AND BL.PRDCT = ''Med Supp''
ORDER BY	BL.CH_ACCT_PART_NUM,BL.CH_Key,BL.TOSCODE,BL.Hosp_Chrg_Key)
)
,CTE_UnPivot
AS
(
SELECT		CH_ACCT_PART_NUM, CH_Key, Hosp_Chrg_Key, TOSCode, PRDCT, Hsp_Snf_Days_Ind, PLAN_CD ,DRN,d_ben_sk
FROM
(
			SELECT		CH_ACCT_PART_NUM, CH_Key, Hosp_Chrg_Key, TOSCode, PRDCT, Hsp_Snf_Days_Ind, PLAN_CD,DRN1,DRN2,DRN3,DRN4,DRN5
			FROM		CTE_ToUnPivot
) UNPIVOT  ( d_ben_sk FOR DRN IN (DRN1,DRN2,DRN3,DRN4,DRN5) )
)
SELECT	CH_ACCT_PART_NUM, CH_Key, Hosp_Chrg_Key, TOSCode, PRDCT, Hsp_Snf_Days_Ind,ROW_NUMBER() OVER (PARTITION BY CH_ACCT_PART_NUM, CH_Key, Hosp_Chrg_Key,
TOSCode,Plan_CD ORDER BY d_ben_sk) ROW_NUMBER,d_ben_sk,Plan_CD
--INTO	#CTE_Un_Pivot
FROM	CTE_UnPivot
WHERE	d_ben_sk <> -1;

--<queries needs to be added>*/


V_STEP_NAME    := ''MERGE - WRK_BIL_LN'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

MERGE INTO BDR_DM.WRK_BIL_LN TGT
USING
(
WITH CTE_BLTblHspDIndZ
AS
(
SELECT /* ROWID */WRK_BIL_LN_SK RID, ROW_NUMBER() OVER(PARTITION BY CH_ACCT_PART_NUM,CH_KEY,HOSP_CHRG_KEY,TOSCODE,PLAN_CD ORDER BY CH_ACCT_PART_NUM,CH_KEY,BILL_LN_NUM) ROW_NUMBER,
D_BEN_SK,CH_ACCT_PART_NUM,CH_KEY,HOSP_CHRG_KEY,TOSCODE,PRDCT,HSP_SNF_DAYS_IND,PLAN_CD,SNF_PROCESS_IND FROM BDR_DM.WRK_BIL_LN
WHERE		Hsp_Snf_Days_Ind = ''Z''  AND TOSCODE IN (''W0'',''W1'',''W2'',''W4'',''W5'',''W6'') AND PRDCT = ''Med Supp''
)
SELECT CTE_UnPivot.D_BEN_SK,
       1 AS SNF_PROCESS_IND,
       BL.RID
FROM CTE_BLTblHspDIndZ BL
INNER JOIN
(WITH CTE_ToUnPivot
AS
(
SELECT		CH_ACCT_PART_NUM, CH_Key, Hosp_Chrg_Key, TOSCode, PRDCT, Hsp_Snf_Days_Ind, PLAN_CD,
			CASE
            WHEN TOScode = ''W0'' AND Mcare_Snf_Days1 IS NOT NULL THEN :BenSKeyW0Z6
            WHEN TOScode = ''W1'' AND Mcare_Snf_Days1 IS NOT NULL THEN :BenSKeyW1Z6
            WHEN TOScode = ''W2'' AND Mcare_Snf_Days1 IS NOT NULL THEN :BenSKeyW2Z6
            WHEN TOScode = ''W4'' AND Mcare_Snf_Days1 IS NOT NULL THEN :BenSKeyW4Z6
            WHEN TOScode = ''W5'' AND Mcare_Snf_Days1 IS NOT NULL THEN :BenSKeyW5Z6
            WHEN TOScode = ''W6'' AND Mcare_Snf_Days1 IS NOT NULL THEN :BenSKeyW6Z6
            ELSE -1 END DRN1,
			CASE
            WHEN TOScode = ''W0'' AND Mcare_Snf_Days2 IS NOT NULL THEN :BenSKeyW0Z7
            WHEN TOScode = ''W1'' AND Mcare_Snf_Days2 IS NOT NULL THEN :BenSKeyW1Z7
            WHEN TOScode = ''W2'' AND Mcare_Snf_Days2 IS NOT NULL THEN :BenSKeyW2Z7
            WHEN TOScode = ''W4'' AND Mcare_Snf_Days2 IS NOT NULL THEN :BenSKeyW4Z7
            WHEN TOScode = ''W5'' AND Mcare_Snf_Days2 IS NOT NULL THEN :BenSKeyW5Z7
            WHEN TOScode = ''W6'' AND Mcare_Snf_Days2 IS NOT NULL THEN :BenSKeyW6Z7
            ELSE -1 END DRN2,
			CASE
            WHEN TOScode = ''W0'' AND Mcare_Snf_Days3 IS NOT NULL THEN :BenSKeyW0Z8
            WHEN TOScode = ''W1'' AND Mcare_Snf_Days3 IS NOT NULL THEN :BenSKeyW1Z8
            WHEN TOScode = ''W2'' AND Mcare_Snf_Days3 IS NOT NULL THEN :BenSKeyW2Z8
            WHEN TOScode = ''W4'' AND Mcare_Snf_Days3 IS NOT NULL THEN :BenSKeyW4Z8
            WHEN TOScode = ''W5'' AND Mcare_Snf_Days3 IS NOT NULL THEN :BenSKeyW5Z8
            WHEN TOScode = ''W6'' AND Mcare_Snf_Days3 IS NOT NULL THEN :BenSKeyW6Z8
            ELSE -1 END DRN3
			,-1 DRN4,-1 DRN5 FROM (SELECT DISTINCT BL.CH_ACCT_PART_NUM, BL.CH_Key, BL.Hosp_Chrg_Key, BL.TOSCode, BL.PRDCT, BL.Hsp_Snf_Days_Ind, BL.PLAN_CD,
			Hsp.Mcare_Hsp_Ihd,Hsp.Mcare_Hsp_Days1,Hsp.Mcare_Hsp_Days2,Hsp.Mcare_Hsp_Days3,Hsp.Mcare_Hsp_Ltr_Optn,
			Hsp.Mcare_Snf_Days1,Hsp.Mcare_Snf_Days2,Hsp.Mcare_Snf_Days3
FROM BDR_DM.WRK_BIL_LN BL
LEFT  JOIN  SRC_FOX_D.HOSP_CHRG Hsp
ON			BL.CH_ACCT_PART_NUM = Hsp.CH_ACCT_PART_NUM AND BL.Hosp_Chrg_Key = Hsp.Hosp_Chrg_Key
WHERE		BL.Hsp_Snf_Days_Ind = ''Z''  AND BL.TOSCODE IN (''W0'',''W1'',''W2'',''W4'',''W5'',''W6'') AND BL.PRDCT = ''Med Supp''
ORDER BY	BL.CH_ACCT_PART_NUM,BL.CH_Key,BL.TOSCODE,BL.Hosp_Chrg_Key)
)
,CTE_UnPivot
AS
(
SELECT		CH_ACCT_PART_NUM, CH_Key, Hosp_Chrg_Key, TOSCode, PRDCT, Hsp_Snf_Days_Ind, PLAN_CD ,DRN,d_ben_sk
FROM
(
			SELECT		CH_ACCT_PART_NUM, CH_Key, Hosp_Chrg_Key, TOSCode, PRDCT, Hsp_Snf_Days_Ind, PLAN_CD,DRN1,DRN2,DRN3,CAST(DRN4 AS INTEGER) AS DRN4,CAST(DRN5 AS INTEGER) AS DRN5
			FROM		CTE_ToUnPivot
) UNPIVOT  ( d_ben_sk FOR DRN IN (DRN1,DRN2,DRN3,DRN4,DRN5) )
)
SELECT	CH_ACCT_PART_NUM, CH_Key, Hosp_Chrg_Key, TOSCode, PRDCT, Hsp_Snf_Days_Ind,ROW_NUMBER() OVER (PARTITION BY CH_ACCT_PART_NUM, CH_Key, Hosp_Chrg_Key, TOSCode,Plan_CD ORDER BY d_ben_sk) ROW_NUMBER,d_ben_sk,Plan_CD
--INTO	#CTE_Un_Pivot
FROM	CTE_UnPivot
WHERE	d_ben_sk <> -1) CTE_UnPivot
ON  BL.CH_ACCT_PART_NUM = CTE_UnPivot.CH_ACCT_PART_NUM AND BL.CH_Key = CTE_UnPivot.CH_Key AND BL.Hosp_Chrg_Key = CTE_UnPivot.Hosp_Chrg_Key AND BL.PRDCT = CTE_UnPivot.PRDCT AND BL.TOSCODE = CTE_UnPivot.TOSCODE AND BL.Plan_CD = CTE_UnPivot.Plan_CD AND BL.ROW_NUMBER = CTE_UnPivot.ROW_NUMBER
) SRC
ON (TGT./*ROWID*/WRK_BIL_LN_SK = SRC.RID)
WHEN MATCHED THEN UPDATE
SET TGT.D_BEN_SK = SRC.D_BEN_SK , TGT.SNF_PROCESS_IND = 1;
	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

 --COMMENTED BY OAS--
 /*V_ROWS_AFFTD:=SQL%ROWCOUNT;
--commit;
INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''FACT_CLAIMS'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''MERGE5'',
      ''Merge into temp table WRK_BIL_LN'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );*/
--COMMENTED BY OAS--
--commit;
--------------------------------------------Assign Default bucket for SNF defaulted Claims

V_STEP_NAME    := ''UPDATE - WRK_BIL_LN'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

UPDATE		BDR_DM.wrk_bil_ln bln
SET			d_ben_sk = CASE WHEN TOScode = ''W0'' AND d_ben_sk = -1 AND prdct = ''Med Supp''
							   THEN :BenSKeyW0D
						       WHEN TOScode = ''W1'' AND d_ben_sk = -1 AND prdct = ''Med Supp''
							   THEN :BenSKeyW1D
							   WHEN TOScode = ''W2'' AND d_ben_sk = -1 AND prdct = ''Med Supp''
							   THEN :BenSKeyW2D
							   WHEN TOScode = ''W4'' AND d_ben_sk = -1 AND prdct = ''Med Supp''
							   THEN :BenSKeyW4D
							   WHEN TOScode = ''W5'' AND d_ben_sk = -1 AND prdct = ''Med Supp''
							   THEN :BenSKeyW5D
							   WHEN TOScode = ''W6'' AND d_ben_sk = -1 AND prdct = ''Med Supp''
							   THEN :BenSKeyW6D
							   END
WHERE		TOScode IN (''W0'',''W1'',''W2'',''W4'',''W5'',''W6'') AND d_ben_sk = -1 AND prdct = ''Med Supp'';
	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

 --COMMENTED BY OAS--
 /*V_ROWS_AFFTD:=SQL%ROWCOUNT;
--commit;
INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''FACT_CLAIMS'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''MERGE6'',
      ''Merge into temp table WRK_BIL_LN'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );*/
--commit;
--COMMENTED BY OAS--
--<queries needs to be added>

V_STEP_NAME    := ''TRUNCATE - WRK_BIL_LN_ALL'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

EXECUTE IMMEDIATE ''TRUNCATE TABLE BDR_DM.WRK_BIL_LN_ALL'';

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );


V_STEP_NAME    := ''INSERT - WRK_BIL_LN_ALL'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

--''BLTbl2''
INSERT INTO BDR_DM.WRK_BIL_LN_ALL
(ROW_NUMBER,CH_ACCT_PART_NUM,CH_KEY,HOSP_CHRG_KEY,BILL_LN_NUM,TOSCODE,PRDCT,HSP_SNF_DAYS_IND,SRV_ACCUM1,SRV_ACCUM2,BEN_PERD_DAYS,MCARE_HSP_IHD,D_BEN_SK,PLAN_CD,TABLE_NAME)
SELECT ROW_NUMBER,CH_ACCT_PART_NUM,CH_KEY,HOSP_CHRG_KEY,BILL_LN_NUM,TOSCODE,PRDCT,HSP_SNF_DAYS_IND,SRV_ACCUM1,SRV_ACCUM2,BEN_PERD_DAYS,MCARE_HSP_IHD,
CASE
WHEN MCARE_HSP_IHD IN (''Y'',''1'') AND ROW_NUMBER = 1 THEN :BenSKeyH2Z1
ELSE
D_BEN_SK
END AS D_BEN_SK,PLAN_CD,''BLTbl2'' as TABLE_NAME
from
(SELECT  ROW_NUMBER() OVER (PARTITION BY bl.CH_ACCT_PART_NUM,bl.CH_KEY,bl.HOSP_CHRG_KEY,bl.PLAN_CD ORDER BY bl.CH_ACCT_PART_NUM,bl.CH_KEY,bl.HOSP_CHRG_KEY,bl.BILL_LN_NUM) ROW_NUMBER,
        bl.CH_ACCT_PART_NUM,bl.CH_KEY,bl.HOSP_CHRG_KEY,bl.BILL_LN_NUM,bl.TOSCODE,bl.PRDCT,bl.HSP_SNF_DAYS_IND,
        bl.SRV_ACCUM1,bl.SRV_ACCUM2,bl.BEN_PERD_DAYS,hsp.MCARE_HSP_IHD,bl.D_BEN_SK,bl.PLAN_CD
FROM
BDR_DM.WRK_BIL_LN bl
INNER JOIN
SRC_FOX_D.HOSP_CHRG hsp
ON	bl.CH_ACCT_PART_NUM = hsp.CH_ACCT_PART_NUM
AND bl.HOSP_CHRG_KEY = hsp.HOSP_CHRG_KEY
WHERE		PRDCT = ''Med Supp''
AND			TOSCODE = ''H2''
AND			bl.HSP_SNF_DAYS_IND = ''Z''
ORDER BY 2,3,4,5);
	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

--COMMENTED BY OAS--
/*V_ROWS_AFFTD:=SQL%ROWCOUNT;
--commit;
INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''FACT_CLAIMS'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''INSERT1'',
      ''Insert into temp table WRK_BIL_LN_ALL'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );*/
--commit;
--COMMENTED BY OAS--

V_STEP_NAME    := ''INSERT - WRK_BIL_LN_ALL'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

--''BLTbl4''
INSERT INTO BDR_DM.WRK_BIL_LN_ALL
(ROW_NUMBER,CH_ACCT_PART_NUM,CH_KEY,HOSP_CHRG_KEY,BILL_LN_NUM,SRV_ACCUM1,SRV_ACCUM2,D_BEN_SK,PLAN_CD,TABLE_NAME)
SELECT DENSE_RANK() OVER (PARTITION BY CH_ACCT_PART_NUM,CH_KEY,HOSP_CHRG_KEY,PLAN_CD ORDER BY CH_ACCT_PART_NUM,CH_KEY,HOSP_CHRG_KEY,SRV_ACCUM2) ROW_NUMBER,
			 CH_ACCT_PART_NUM,CH_KEY,HOSP_CHRG_KEY,BILL_LN_NUM,SRV_ACCUM1,SRV_ACCUM2,-1 D_BEN_SK,PLAN_CD,''BLTbl4'' TABLE_NAME
FROM		BDR_DM.WRK_BIL_LN_ALL
WHERE		TABLE_NAME = ''BLTbl2'' AND (D_BEN_SK = -1 or MCARE_HSP_IHD IS NULL )
ORDER BY	2,3,4,5;
	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

--COMMENTED BY OAS--
/*V_ROWS_AFFTD:=SQL%ROWCOUNT;
--commit;
INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''FACT_CLAIMS'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''INSERT2'',
      ''Insert into temp table WRK_BIL_LN_ALL'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );*/
--commit;
--COMMENTED BY OAS--
--''BLTbl5''


V_STEP_NAME    := ''INSERT - WRK_BIL_LN_ALL'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

INSERT INTO BDR_DM.WRK_BIL_LN_ALL
(ROW_NUMBER,CH_ACCT_PART_NUM,CH_KEY,HOSP_CHRG_KEY,SRV_ACCUM1,D_BEN_SK,PLAN_CD,TABLE_NAME)

SELECT	BLTbl5.ROW_NUMBER,BLTbl5.CH_ACCT_PART_NUM,BLTbl5.CH_KEY,BLTbl5.HOSP_CHRG_KEY,BLTbl5.SRV_ACCUM1,
CASE
WHEN MCAREDAYS=''McareHspDays1'' THEN :BenSKeyH2Z2
WHEN MCAREDAYS=''McareHspDays2'' THEN :BenSKeyH2Z3
WHEN MCAREDAYS=''McareHspDays3'' AND MCARE_HSP_LTR_OPTN = ''N'' THEN :BenSKeyH2ZLtrN
WHEN MCAREDAYS=''McareHspDays3'' AND NVL(MCARE_HSP_LTR_OPTN,''Z'') <> ''N'' THEN :BenSKeyH2ZLtrNotN
END AS D_BEN_SK,BLTbl5.PLAN_CD,BLTbl5.TABLE_NAME FROM
(SELECT	ROW_NUMBER,CH_ACCT_PART_NUM,CH_KEY,HOSP_CHRG_KEY,SUM(SRV_ACCUM1)SRV_ACCUM1,-1 D_BEN_SK,PLAN_CD,''BLTbl5'' TABLE_NAME
FROM		BDR_DM.WRK_BIL_LN_ALL
WHERE		TABLE_NAME = ''BLTbl4''
GROUP BY ROW_NUMBER,CH_ACCT_PART_NUM,CH_KEY,HOSP_CHRG_KEY,PLAN_CD) BLTbl5
INNER JOIN
(
SELECT 1 ROW_NUMBER,bl.CH_ACCT_PART_NUM,bl.CH_KEY,bl.HOSP_CHRG_KEY,hsp.MCARE_HSP_IHD,''McareHspDays1'' MCAREDAYS,hsp.MCARE_HSP_DAYS1 MCAREHSPDAYS,hsp.MCARE_HSP_LTR_OPTN
FROM
BDR_DM.WRK_BIL_LN_ALL bl
INNER JOIN
SRC_FOX_D.HOSP_CHRG hsp
ON	bl.CH_ACCT_PART_NUM = hsp.CH_ACCT_PART_NUM
AND bl.HOSP_CHRG_KEY = hsp.HOSP_CHRG_KEY
AND bl.TABLE_NAME = ''BLTbl2''
WHERE hsp.MCARE_HSP_DAYS1 IS NOT NULL
UNION
SELECT 2 ROW_NUMBER,bl.CH_ACCT_PART_NUM,bl.CH_KEY,bl.HOSP_CHRG_KEY,hsp.MCARE_HSP_IHD,''McareHspDays2'' MCAREDAYS,hsp.MCARE_HSP_DAYS2,hsp.MCARE_HSP_LTR_OPTN
FROM
BDR_DM.WRK_BIL_LN_ALL bl
INNER JOIN
SRC_FOX_D.HOSP_CHRG hsp
ON	bl.CH_ACCT_PART_NUM = hsp.CH_ACCT_PART_NUM
AND bl.HOSP_CHRG_KEY = hsp.HOSP_CHRG_KEY
AND bl.TABLE_NAME = ''BLTbl2''
WHERE hsp.MCARE_HSP_DAYS2 IS NOT NULL
UNION
SELECT 3 ROW_NUMBER,bl.CH_ACCT_PART_NUM,bl.CH_KEY,bl.HOSP_CHRG_KEY,hsp.MCARE_HSP_IHD,''McareHspDays3'' MCAREDAYS,hsp.MCARE_HSP_DAYS3,hsp.MCARE_HSP_LTR_OPTN
FROM
BDR_DM.WRK_BIL_LN_ALL bl
INNER JOIN
SRC_FOX_D.HOSP_CHRG hsp
ON	bl.CH_ACCT_PART_NUM = hsp.CH_ACCT_PART_NUM
AND bl.HOSP_CHRG_KEY = hsp.HOSP_CHRG_KEY
AND bl.TABLE_NAME = ''BLTbl2''
WHERE hsp.MCARE_HSP_DAYS3 IS NOT NULL
) Hsp
ON	BLTbl5.CH_ACCT_PART_NUM = Hsp.CH_ACCT_PART_NUM 	AND BLTbl5.HOSP_CHRG_KEY = Hsp.HOSP_CHRG_KEY AND BLTbl5.SRV_ACCUM1 = Hsp.MCAREHSPDAYS;
	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

--COMMENTED BY OAS--/*V_ROWS_AFFTD:=SQL%ROWCOUNT;
--commit;
--DBMS_STATS.GATHER_TABLE_STATS (OWNNAME => ''DM'',TABNAME => ''WRK_BIL_LN_ALL'',PARTNAME => NULL,ESTIMATE_PERCENT => 10, DEGREE => 4, GRANULARITY => ''ALL'', METHOD_OPT => ''FOR ALL COLUMNS SIZE 1'',CASCADE => TRUE);

--COMMENTED BY OAS--
/*
BDR_DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''WRK_BIL_LN_ALL''); -- Adding stats 02/01/2018


INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''FACT_CLAIMS'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''INSERT3'',
      ''Insert into temp table WRK_BIL_LN_ALL'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );*/
--COMMENTED BY OAS--
--commit;

/*
--''BLTbl5''
INSERT INTO BDR_DM.WRK_BIL_LN_ALL
(ROW_NUMBER,CH_ACCT_PART_NUM,CH_KEY,HOSP_CHRG_KEY,SRV_ACCUM1,D_BEN_SK,PLAN_CD,TABLE_NAME)
SELECT	ROW_NUMBER,CH_ACCT_PART_NUM,CH_KEY,HOSP_CHRG_KEY,SUM(SRV_ACCUM1)SRV_ACCUM1,-1 D_BEN_SK,PLAN_CD,''BLTbl5'' TABLE_NAME
FROM		BDR_DM.WRK_BIL_LN_ALL
WHERE		TABLE_NAME = ''BLTbl4''
GROUP BY ROW_NUMBER,CH_ACCT_PART_NUM,CH_KEY,HOSP_CHRG_KEY,PLAN_CD;
--commit;
-- HspChrgTbl2 WITH UNPIVOT LOGIC

SELECT
CASE MCAREDAYS
WHEN ''McareHspDays1'' THEN 1
WHEN ''McareHspDays2'' THEN 2
WHEN ''McareHspDays3'' THEN 3
ELSE -1 END AS ROW_NUMBER,CH_ACCT_PART_NUM,CH_KEY,HOSP_CHRG_KEY,MCARE_HSP_IHD,MCAREDAYS,MCAREHSPDAYS,MCARE_HSP_LTR_OPTN
FROM
(SELECT bl.CH_ACCT_PART_NUM,bl.CH_KEY,bl.HOSP_CHRG_KEY,hsp.MCARE_HSP_IHD,hsp.MCARE_HSP_DAYS1,hsp.MCARE_HSP_DAYS2,hsp.MCARE_HSP_DAYS3,hsp.MCARE_HSP_LTR_OPTN
FROM
BDR_DM.WRK_BIL_LN_ALL bl
INNER JOIN
SRC_FOX_D.HOSP_CHRG hsp
ON	bl.CH_ACCT_PART_NUM = hsp.CH_ACCT_PART_NUM
AND bl.HOSP_CHRG_KEY = hsp.HOSP_CHRG_KEY
AND bl.TABLE_NAME = ''BLTbl2'')
unpivot (MCAREHSPDAYS FOR MCAREDAYS IN (MCARE_HSP_DAYS1 as ''McareHspDays1'',MCARE_HSP_DAYS2 as ''McareHspDays2'',MCARE_HSP_DAYS3 as ''McareHspDays3''))
*/


V_STEP_NAME    := ''MERGE - WRK_BIL_LN_ALL'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

--- BLTbl4 Update

MERGE INTO  BDR_DM.WRK_BIL_LN_ALL bl4
USING
(SELECT bl5.CH_ACCT_PART_NUM,bl5.CH_KEY,bl5.HOSP_CHRG_KEY,bl5.BILL_LN_NUM,bl5.D_BEN_SK,bl5.PLAN_CD,bl5.ROW_NUMBER FROM BDR_DM.WRK_BIL_LN_ALL bl5 WHERE TABLE_NAME = ''BLTbl5'') bl5
ON (bl5.CH_ACCT_PART_NUM = bl4.CH_ACCT_PART_NUM and bl5.CH_KEY=bl4.CH_KEY and bl5.HOSP_CHRG_KEY=bl4.HOSP_CHRG_KEY and bl5.ROW_NUMBER=bl4.ROW_NUMBER and bl5.PLAN_CD=bl4.PLAN_CD  and bl4.TABLE_NAME=''BLTbl4'')
WHEN MATCHED THEN UPDATE
SET bl4.D_BEN_SK = BL5.D_BEN_SK;
	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

 --COMMENTED BY OAS--
 /*V_ROWS_AFFTD:=SQL%ROWCOUNT;
--commit;
INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''FACT_CLAIMS'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''MERGE1'',
      ''Merge into temp table WRK_BIL_LN_ALL'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );*/
--COMMENTED BY OAS--
--commit;

--- BLTbl2 Update

V_STEP_NAME    := ''MERGE - WRK_BIL_LN_ALL'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

MERGE INTO  BDR_DM.WRK_BIL_LN_ALL bl2
USING
(SELECT distinct bl4.CH_ACCT_PART_NUM,bl4.CH_KEY,bl4.HOSP_CHRG_KEY,bl4.BILL_LN_NUM,bl4.D_BEN_SK FROM BDR_DM.WRK_BIL_LN_ALL bl4 WHERE TABLE_NAME = ''BLTbl4'') bl4
ON (bl4.CH_ACCT_PART_NUM = bl2.CH_ACCT_PART_NUM and bl4.CH_KEY=bl2.CH_KEY and bl4.HOSP_CHRG_KEY=bl2.HOSP_CHRG_KEY and bl4.BILL_LN_NUM=bl2.BILL_LN_NUM and bl2.TABLE_NAME=''BLTbl2'' 
and bl2.D_BEN_SK=-1		--OAS ADD
)
WHEN MATCHED THEN UPDATE
SET bl2.D_BEN_SK = bl4.D_BEN_SK ;
--where bl2.D_BEN_SK=-1;		--OAS DELETE
	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

--COMMENTED BY OAS--
/*V_ROWS_AFFTD:=SQL%ROWCOUNT;
--commit;
INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''FACT_CLAIMS'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''MERGE2'',
      ''Merge into temp table WRK_BIL_LN_ALL'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );*/
    --commit;
--COMMENTED BY OAS--

--- HspChrgrTbl3 And BLTbl2 Update

V_STEP_NAME    := ''MERGE - WRK_BIL_LN_ALL'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

MERGE INTO BDR_DM.WRK_BIL_LN_ALL BLTbl2 USING
(
SELECT CASE
WHEN hsp3.MCAREDAYS = ''McareHspDays1'' THEN :BenSKeyH2Z2

WHEN hsp3.MCAREDAYS = ''McareHspDays2'' THEN :BenSKeyH2Z3

WHEN hsp3.MCAREDAYS = ''McareHspDays3'' AND hsp3.MCARE_HSP_LTR_OPTN = ''N'' THEN :BenSKeyH2ZLtrN

WHEN hsp3.MCAREDAYS = ''McareHspDays3'' AND NVL(hsp3.MCARE_HSP_LTR_OPTN,''Z'') <> ''N'' THEN :BenSKeyH2ZLtrNotN
ELSE -1 END as D_BEN_SK,bl2.WRK_BIL_LN_ALL_SK/* ROWID */ RID FROM
(
SELECT DISTINCT hsp2.ROW_NUMBER,hsp2.CH_ACCT_PART_NUM,hsp2.CH_KEY,hsp2.HOSP_CHRG_KEY,hsp2.MCARE_HSP_IHD,hsp2.MCAREDAYS,hsp2.MCAREHSPDAYS,hsp2.MCARE_HSP_LTR_OPTN FROM
(
SELECT 1 ROW_NUMBER,bl.CH_ACCT_PART_NUM,bl.CH_KEY,bl.HOSP_CHRG_KEY,hsp.MCARE_HSP_IHD,''McareHspDays1'' MCAREDAYS,hsp.MCARE_HSP_DAYS1 MCAREHSPDAYS,hsp.MCARE_HSP_LTR_OPTN
FROM
BDR_DM.WRK_BIL_LN_ALL bl
INNER JOIN
SRC_FOX_D.HOSP_CHRG hsp
ON	bl.CH_ACCT_PART_NUM = hsp.CH_ACCT_PART_NUM
AND bl.HOSP_CHRG_KEY = hsp.HOSP_CHRG_KEY
AND bl.TABLE_NAME = ''BLTbl2''
WHERE hsp.MCARE_HSP_DAYS1 IS NOT NULL
UNION
SELECT 2 ROW_NUMBER,bl.CH_ACCT_PART_NUM,bl.CH_KEY,bl.HOSP_CHRG_KEY,hsp.MCARE_HSP_IHD,''McareHspDays2'' MCAREDAYS,hsp.MCARE_HSP_DAYS2,hsp.MCARE_HSP_LTR_OPTN
FROM
BDR_DM.WRK_BIL_LN_ALL bl
INNER JOIN
SRC_FOX_D.HOSP_CHRG hsp
ON	bl.CH_ACCT_PART_NUM = hsp.CH_ACCT_PART_NUM
AND bl.HOSP_CHRG_KEY = hsp.HOSP_CHRG_KEY
AND bl.TABLE_NAME = ''BLTbl2''
WHERE hsp.MCARE_HSP_DAYS2 IS NOT NULL
UNION
SELECT 3 ROW_NUMBER,bl.CH_ACCT_PART_NUM,bl.CH_KEY,bl.HOSP_CHRG_KEY,hsp.MCARE_HSP_IHD,''McareHspDays3'' MCAREDAYS,hsp.MCARE_HSP_DAYS3,hsp.MCARE_HSP_LTR_OPTN
FROM
BDR_DM.WRK_BIL_LN_ALL bl
INNER JOIN
SRC_FOX_D.HOSP_CHRG hsp
ON	bl.CH_ACCT_PART_NUM = hsp.CH_ACCT_PART_NUM
AND bl.HOSP_CHRG_KEY = hsp.HOSP_CHRG_KEY
AND bl.TABLE_NAME = ''BLTbl2''
WHERE hsp.MCARE_HSP_DAYS3 IS NOT NULL
)hsp2
INNER JOIN
BDR_DM.WRK_BIL_LN_ALL bl2
ON  bl2.CH_ACCT_PART_NUM = hsp2.CH_ACCT_PART_NUM
AND bl2.HOSP_CHRG_KEY = hsp2.HOSP_CHRG_KEY
AND bl2.TABLE_NAME = ''BLTbl2''
WHERE bl2.D_BEN_SK = -1 and TRIM(hsp2.MCARE_HSP_IHD) IS NULL AND MCAREDAYS IN (''McareHspDays1'',''McareHspDays2'',''McareHspDays3'')
) hsp3
INNER JOIN
BDR_DM.WRK_BIL_LN_ALL bl2
ON  bl2.CH_ACCT_PART_NUM = hsp3.CH_ACCT_PART_NUM
AND bl2.HOSP_CHRG_KEY = hsp3.HOSP_CHRG_KEY
AND bl2.SRV_ACCUM1 = hsp3.MCAREHSPDAYS
AND bl2.ROW_NUMBER = hsp3.ROW_NUMBER
AND bl2.TABLE_NAME = ''BLTbl2''
WHERE bl2.D_BEN_Sk=-1
) hsp3updt
ON (hsp3updt.RID = BLTbl2.WRK_BIL_LN_ALL_SK/* ROWID */)
WHEN MATCHED THEN UPDATE
SET BLTbl2.D_BEN_SK = hsp3updt.D_BEN_SK;
	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

 --COMMENTED BY OAS--
 /*V_ROWS_AFFTD:=SQL%ROWCOUNT;
--commit;
INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''FACT_CLAIMS'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''MERGE3'',
      ''Merge into temp table WRK_BIL_LN_ALL'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );*/
--commit;
--COMMENTED BY OAS--
----------------------------------------------Update RowNumber where benefitSkey = -1
-- Reorder ROW_NUMBER based on updated BillLineNm

V_STEP_NAME    := ''MERGE - WRK_BIL_LN_ALL'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

MERGE INTO BDR_DM.WRK_BIL_LN_ALL bl2 USING
(
SELECT	WRK_BIL_LN_ALL_SK/* ROWID */ RID,ROW_NUMBER() OVER (PARTITION BY CH_ACCT_PART_NUM,CH_KEY,HOSP_CHRG_KEY,PLAN_CD ORDER BY CH_ACCT_PART_NUM,CH_KEY,HOSP_CHRG_KEY,BILL_LN_NUM) RN1
FROM		BDR_DM.WRK_BIL_LN_ALL bl2
WHERE		D_BEN_SK = -1 and TABLE_NAME = ''BLTbl2''
) RRN
ON (BL2.WRK_BIL_LN_ALL_SK/* ROWID */ = RRN.RID)
WHEN MATCHED THEN UPDATE
SET	bl2.ROW_NUMBER = RRN.RN1;
--commit;
	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );


V_STEP_NAME    := ''MERGE - WRK_BIL_LN_ALL'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

MERGE INTO BDR_DM.WRK_BIL_LN_ALL BLTbl2 USING
(
SELECT CASE
WHEN hsp2.MCAREDAYS = ''McareHspDays1'' THEN :BenSKeyH2Z2

WHEN hsp2.MCAREDAYS = ''McareHspDays2'' THEN :BenSKeyH2Z3

WHEN hsp2.MCAREDAYS = ''McareHspDays3'' AND hsp2.MCARE_HSP_LTR_OPTN = ''N'' THEN :BenSKeyH2ZLtrN

WHEN hsp2.MCAREDAYS = ''McareHspDays3'' AND NVL(hsp2.MCARE_HSP_LTR_OPTN,''Z'') <> ''N'' THEN :BenSKeyH2ZLtrNotN
ELSE -1 END as D_BEN_SK,bl2.WRK_BIL_LN_ALL_SK/* ROWID */ RID FROM
(SELECT 1 ROW_NUMBER,bl.CH_ACCT_PART_NUM,bl.CH_KEY,bl.HOSP_CHRG_KEY,hsp.MCARE_HSP_IHD,''McareHspDays1'' MCAREDAYS,hsp.MCARE_HSP_DAYS1 MCAREHSPDAYS,hsp.MCARE_HSP_LTR_OPTN
FROM
BDR_DM.WRK_BIL_LN_ALL bl
INNER JOIN
SRC_FOX_D.HOSP_CHRG hsp
ON	bl.CH_ACCT_PART_NUM = hsp.CH_ACCT_PART_NUM
AND bl.HOSP_CHRG_KEY = hsp.HOSP_CHRG_KEY
AND bl.TABLE_NAME = ''BLTbl2''
WHERE hsp.MCARE_HSP_DAYS1 IS NOT NULL
UNION
SELECT 2 ROW_NUMBER,bl.CH_ACCT_PART_NUM,bl.CH_KEY,bl.HOSP_CHRG_KEY,hsp.MCARE_HSP_IHD,''McareHspDays2'' MCAREDAYS,hsp.MCARE_HSP_DAYS2,hsp.MCARE_HSP_LTR_OPTN
FROM
BDR_DM.WRK_BIL_LN_ALL bl
INNER JOIN
SRC_FOX_D.HOSP_CHRG hsp
ON	bl.CH_ACCT_PART_NUM = hsp.CH_ACCT_PART_NUM
AND bl.HOSP_CHRG_KEY = hsp.HOSP_CHRG_KEY
AND bl.TABLE_NAME = ''BLTbl2''
WHERE hsp.MCARE_HSP_DAYS2 IS NOT NULL
UNION
SELECT 3 ROW_NUMBER,bl.CH_ACCT_PART_NUM,bl.CH_KEY,bl.HOSP_CHRG_KEY,hsp.MCARE_HSP_IHD,''McareHspDays3'' MCAREDAYS,hsp.MCARE_HSP_DAYS3,hsp.MCARE_HSP_LTR_OPTN
FROM
BDR_DM.WRK_BIL_LN_ALL bl
INNER JOIN
SRC_FOX_D.HOSP_CHRG hsp
ON	bl.CH_ACCT_PART_NUM = hsp.CH_ACCT_PART_NUM
AND bl.HOSP_CHRG_KEY = hsp.HOSP_CHRG_KEY
AND bl.TABLE_NAME = ''BLTbl2''
WHERE hsp.MCARE_HSP_DAYS3 IS NOT NULL) hsp2
INNER JOIN
BDR_DM.WRK_BIL_LN_ALL bl2
ON  bl2.CH_ACCT_PART_NUM = hsp2.CH_ACCT_PART_NUM
AND bl2.HOSP_CHRG_KEY = hsp2.HOSP_CHRG_KEY
AND bl2.SRV_ACCUM1 = hsp2.MCAREHSPDAYS
AND bl2.ROW_NUMBER = hsp2.ROW_NUMBER
AND bl2.TABLE_NAME = ''BLTbl2''
WHERE bl2.D_BEN_SK = -1
) updbl2
ON (BLTbl2.WRK_BIL_LN_ALL_SK/* ROWID */ = updbl2.RID)
WHEN MATCHED THEN UPDATE
SET BLTbl2.D_BEN_SK = updbl2.D_BEN_SK ;
	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

--COMMENTED BY OAS--
/*V_ROWS_AFFTD:=SQL%ROWCOUNT;
--commit;
INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''FACT_CLAIMS'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''MERGE4'',
      ''Merge into temp table WRK_BIL_LN_ALL'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );*/
--commit;
--COMMENTED BY OAS--

-- Reorder ROW_NUMBER based on updated BillLineNm

V_STEP_NAME    := ''MERGE - WRK_BIL_LN_ALL'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

MERGE INTO BDR_DM.WRK_BIL_LN_ALL bl2 USING
(
SELECT		WRK_BIL_LN_ALL_SK/* ROWID */ RID,ROW_NUMBER() OVER (PARTITION BY CH_ACCT_PART_NUM,CH_KEY,HOSP_CHRG_KEY,PLAN_CD ORDER BY CH_ACCT_PART_NUM,CH_KEY,HOSP_CHRG_KEY,BILL_LN_NUM) RN1
FROM		BDR_DM.WRK_BIL_LN_ALL bl2
WHERE		D_BEN_SK = -1 and TABLE_NAME = ''BLTbl2''
) RRN
ON (BL2.WRK_BIL_LN_ALL_SK/* ROWID */ = RRN.RID)
WHEN MATCHED THEN UPDATE
SET			bl2.ROW_NUMBER = RRN.RN1;
	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

 --COMMENTED BY OAS--
 /*V_ROWS_AFFTD:=SQL%ROWCOUNT;
--commit;
INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''FACT_CLAIMS'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''MERGE5'',
      ''Merge into temp table WRK_BIL_LN_ALL'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );
*/
    --commit;
--COMMENTED BY OAS--

--HsptlChrg4 and Update without SRVACCUM1

V_STEP_NAME    := ''MERGE - WRK_BIL_LN_ALL'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

MERGE INTO BDR_DM.WRK_BIL_LN_ALL BLTbl2 USING
(
SELECT CASE
WHEN hsp4.MCAREDAYS = ''McareHspDays1'' THEN :BenSKeyH2Z2

WHEN hsp4.MCAREDAYS = ''McareHspDays2'' THEN :BenSKeyH2Z3

WHEN hsp4.MCAREDAYS = ''McareHspDays3'' AND hsp4.MCARE_HSP_LTR_OPTN = ''N'' THEN :BenSKeyH2ZLtrN

WHEN hsp4.MCAREDAYS = ''McareHspDays3'' AND NVL(hsp4.MCARE_HSP_LTR_OPTN,''Z'') <> ''N'' THEN :BenSKeyH2ZLtrNotN
ELSE -1 END as D_BEN_SK,bl2.WRK_BIL_LN_ALL_SK/* ROWID */ RID FROM
(
SELECT DISTINCT
hsp2.ROW_NUMBER,hsp2.CH_ACCT_PART_NUM,hsp2.CH_KEY,hsp2.HOSP_CHRG_KEY,hsp2.MCARE_HSP_IHD,hsp2.MCAREDAYS,hsp2.MCAREHSPDAYS,hsp2.MCARE_HSP_LTR_OPTN FROM
(
SELECT 1 ROW_NUMBER,bl.CH_ACCT_PART_NUM,bl.CH_KEY,bl.HOSP_CHRG_KEY,hsp.MCARE_HSP_IHD,''McareHspDays1'' MCAREDAYS,hsp.MCARE_HSP_DAYS1 MCAREHSPDAYS,hsp.MCARE_HSP_LTR_OPTN
FROM
BDR_DM.WRK_BIL_LN_ALL bl
INNER JOIN
SRC_FOX_D.HOSP_CHRG hsp
ON	bl.CH_ACCT_PART_NUM = hsp.CH_ACCT_PART_NUM
AND bl.HOSP_CHRG_KEY = hsp.HOSP_CHRG_KEY
AND bl.TABLE_NAME = ''BLTbl2''
WHERE hsp.MCARE_HSP_DAYS1 IS NOT NULL
UNION
SELECT 2 ROW_NUMBER,bl.CH_ACCT_PART_NUM,bl.CH_KEY,bl.HOSP_CHRG_KEY,hsp.MCARE_HSP_IHD,''McareHspDays2'' MCAREDAYS,hsp.MCARE_HSP_DAYS2,hsp.MCARE_HSP_LTR_OPTN
FROM
BDR_DM.WRK_BIL_LN_ALL bl
INNER JOIN
SRC_FOX_D.HOSP_CHRG hsp
ON	bl.CH_ACCT_PART_NUM = hsp.CH_ACCT_PART_NUM
AND bl.HOSP_CHRG_KEY = hsp.HOSP_CHRG_KEY
AND bl.TABLE_NAME = ''BLTbl2''
WHERE hsp.MCARE_HSP_DAYS2 IS NOT NULL
UNION
SELECT 3 ROW_NUMBER,bl.CH_ACCT_PART_NUM,bl.CH_KEY,bl.HOSP_CHRG_KEY,hsp.MCARE_HSP_IHD,''McareHspDays3'' MCAREDAYS,hsp.MCARE_HSP_DAYS3,hsp.MCARE_HSP_LTR_OPTN
FROM
BDR_DM.WRK_BIL_LN_ALL bl
INNER JOIN
SRC_FOX_D.HOSP_CHRG hsp
ON	bl.CH_ACCT_PART_NUM = hsp.CH_ACCT_PART_NUM
AND bl.HOSP_CHRG_KEY = hsp.HOSP_CHRG_KEY
AND bl.TABLE_NAME = ''BLTbl2''
WHERE hsp.MCARE_HSP_DAYS3 IS NOT NULL
)hsp2
INNER JOIN
BDR_DM.WRK_BIL_LN_ALL bl2
ON  bl2.CH_ACCT_PART_NUM = hsp2.CH_ACCT_PART_NUM
AND bl2.HOSP_CHRG_KEY = hsp2.HOSP_CHRG_KEY
AND bl2.TABLE_NAME = ''BLTbl2''
WHERE bl2.D_BEN_SK = -1
--and TRIM(hsp2.MCARE_HSP_IHD) IS NULL //changed as part of UAT fix
AND MCAREDAYS IN (''McareHspDays1'',''McareHspDays2'',''McareHspDays3'')
) hsp4
INNER JOIN
BDR_DM.WRK_BIL_LN_ALL bl2
ON  bl2.CH_ACCT_PART_NUM = hsp4.CH_ACCT_PART_NUM
AND bl2.HOSP_CHRG_KEY = hsp4.HOSP_CHRG_KEY
AND bl2.ROW_NUMBER = hsp4.ROW_NUMBER
AND bl2.TABLE_NAME = ''BLTbl2''
WHERE bl2.D_BEN_Sk=-1
) hsp3updt
ON (hsp3updt.RID = BLTbl2.WRK_BIL_LN_ALL_SK/* ROWID */)
WHEN MATCHED THEN UPDATE
SET BLTbl2.D_BEN_SK = hsp3updt.D_BEN_SK;
	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );


 --COMMENTED BY OAS--
/*V_ROWS_AFFTD:=SQL%ROWCOUNT;
--commit;
INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''FACT_CLAIMS'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''MERGE6'',
      ''Merge into temp table WRK_BIL_LN_ALL'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );*/
--COMMENTED BY OAS--
    --commit;

---------------------------------------------Final update w/o matching ROW_NUMBER and w/o matching SrvAccum for defaulted BenefitSkey


V_STEP_NAME    := ''MERGE - WRK_BIL_LN_ALL'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

MERGE INTO BDR_DM.WRK_BIL_LN_ALL BLTbl2 USING
(
SELECT CASE
WHEN hsp4.MCAREDAYS = ''McareHspDays1'' THEN :BenSKeyH2Z2

WHEN hsp4.MCAREDAYS = ''McareHspDays2'' THEN :BenSKeyH2Z3

WHEN hsp4.MCAREDAYS = ''McareHspDays3'' AND hsp4.MCARE_HSP_LTR_OPTN = ''N'' THEN :BenSKeyH2ZLtrN

WHEN hsp4.MCAREDAYS = ''McareHspDays3'' AND NVL(hsp4.MCARE_HSP_LTR_OPTN,''Z'') <> ''N'' THEN :BenSKeyH2ZLtrNotN
ELSE -1 END as D_BEN_SK,bl2.WRK_BIL_LN_ALL_SK/* ROWID */ RID FROM
(
SELECT DISTINCT
hsp2.ROW_NUMBER,hsp2.CH_ACCT_PART_NUM,hsp2.CH_KEY,hsp2.HOSP_CHRG_KEY,hsp2.MCARE_HSP_IHD,hsp2.MCAREDAYS,hsp2.MCAREHSPDAYS,hsp2.MCARE_HSP_LTR_OPTN FROM
(
SELECT 1 ROW_NUMBER,
      bl.CH_ACCT_PART_NUM,
      bl.CH_KEY,
      bl.HOSP_CHRG_KEY,
      hsp.MCARE_HSP_IHD,
      ''McareHspDays1'' MCAREDAYS,
      hsp.MCARE_HSP_DAYS1 MCAREHSPDAYS,
      hsp.MCARE_HSP_LTR_OPTN
    FROM BDR_DM.WRK_BIL_LN_ALL bl
    INNER JOIN SRC_FOX_D.HOSP_CHRG hsp
    ON bl.CH_ACCT_PART_NUM     = hsp.CH_ACCT_PART_NUM
    AND bl.HOSP_CHRG_KEY       = hsp.HOSP_CHRG_KEY
    AND bl.TABLE_NAME          = ''BLTbl2''
    WHERE hsp.MCARE_HSP_DAYS1 IS NOT NULL
    UNION
    SELECT 2 ROW_NUMBER,
      bl.CH_ACCT_PART_NUM,
      bl.CH_KEY,
      bl.HOSP_CHRG_KEY,
      hsp.MCARE_HSP_IHD,
      ''McareHspDays2'' MCAREDAYS,
      hsp.MCARE_HSP_DAYS2,
      hsp.MCARE_HSP_LTR_OPTN
    FROM BDR_DM.WRK_BIL_LN_ALL bl
    INNER JOIN SRC_FOX_D.HOSP_CHRG hsp
    ON bl.CH_ACCT_PART_NUM     = hsp.CH_ACCT_PART_NUM
    AND bl.HOSP_CHRG_KEY       = hsp.HOSP_CHRG_KEY
    AND bl.TABLE_NAME          = ''BLTbl2''
    WHERE hsp.MCARE_HSP_DAYS2 IS NOT NULL
    AND hsp.MCARE_HSP_DAYS1 IS NULL
    UNION
    SELECT 3 ROW_NUMBER,
      bl.CH_ACCT_PART_NUM,
      bl.CH_KEY,
      bl.HOSP_CHRG_KEY,
      hsp.MCARE_HSP_IHD,
      ''McareHspDays3'' MCAREDAYS,
      hsp.MCARE_HSP_DAYS3,
      hsp.MCARE_HSP_LTR_OPTN
    FROM BDR_DM.WRK_BIL_LN_ALL bl
    INNER JOIN SRC_FOX_D.HOSP_CHRG hsp
    ON bl.CH_ACCT_PART_NUM     = hsp.CH_ACCT_PART_NUM
    AND bl.HOSP_CHRG_KEY       = hsp.HOSP_CHRG_KEY
    AND bl.TABLE_NAME          = ''BLTbl2''
    WHERE hsp.MCARE_HSP_DAYS3 IS NOT NULL
    AND hsp.MCARE_HSP_LTR_OPTN = ''N''
    AND hsp.MCARE_HSP_DAYS1 IS NULL
    AND hsp.MCARE_HSP_DAYS2 IS NULL
    UNION
    SELECT 4 ROW_NUMBER,
      bl.CH_ACCT_PART_NUM,
      bl.CH_KEY,
      bl.HOSP_CHRG_KEY,
      hsp.MCARE_HSP_IHD,
      ''McareHspDays3'' MCAREDAYS,
      hsp.MCARE_HSP_DAYS3,
      hsp.MCARE_HSP_LTR_OPTN
    FROM BDR_DM.WRK_BIL_LN_ALL bl
    INNER JOIN SRC_FOX_D.HOSP_CHRG hsp
    ON bl.CH_ACCT_PART_NUM     = hsp.CH_ACCT_PART_NUM
    AND bl.HOSP_CHRG_KEY       = hsp.HOSP_CHRG_KEY
    AND bl.TABLE_NAME          = ''BLTbl2''
    WHERE hsp.MCARE_HSP_DAYS3 IS NOT NULL
    AND NVL(hsp.MCARE_HSP_LTR_OPTN,''Z'') <> ''N''
    AND hsp.MCARE_HSP_DAYS1 IS NULL
    AND hsp.MCARE_HSP_DAYS2 IS NULL
    ORDER BY 1
)hsp2
INNER JOIN
BDR_DM.WRK_BIL_LN_ALL bl2
ON  bl2.CH_ACCT_PART_NUM = hsp2.CH_ACCT_PART_NUM
AND bl2.HOSP_CHRG_KEY = hsp2.HOSP_CHRG_KEY
AND bl2.TABLE_NAME = ''BLTbl2''
WHERE bl2.D_BEN_SK = -1
--and TRIM(hsp2.MCARE_HSP_IHD) IS NULL //changed as part of UAT fix
AND MCAREDAYS IN (''McareHspDays1'',''McareHspDays2'',''McareHspDays3'')
) hsp4
INNER JOIN
BDR_DM.WRK_BIL_LN_ALL bl2
ON  bl2.CH_ACCT_PART_NUM = hsp4.CH_ACCT_PART_NUM
AND bl2.HOSP_CHRG_KEY = hsp4.HOSP_CHRG_KEY
AND bl2.TABLE_NAME = ''BLTbl2''
WHERE bl2.D_BEN_Sk = -1
) hsp3updt
ON (hsp3updt.RID = BLTbl2.WRK_BIL_LN_ALL_SK/* ROWID */)
WHEN MATCHED THEN UPDATE
SET BLTbl2.D_BEN_SK = hsp3updt.D_BEN_SK;
	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

 --COMMENTED BY OAS--
/*V_ROWS_AFFTD:=SQL%ROWCOUNT;
--commit;
INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''FACT_CLAIMS'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''MERGE7'',
      ''Merge into temp table WRK_BIL_LN_ALL'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );*/
--COMMENTED BY OAS--
    --commit;
---------------------------------------------update BenefitSkey to default bucket for H2 MedSupp

V_STEP_NAME    := ''UPDATE - WRK_CLAIM_BILLLINE_INCURRAL'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

UPDATE		BDR_DM.WRK_CLAIM_BILLLINE_INCURRAL
SET			benefit_skey = :BenSKeyH2D
WHERE		tos_code = ''H2'' AND benefit_skey = -1 AND product = ''Med Supp'';
	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );


 --COMMENTED BY OAS--
/*V_ROWS_AFFTD:=SQL%ROWCOUNT;
--commit;
INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''FACT_CLAIMS'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''MERGE'',
      ''Merge into  table WRK_CLAIM_BILLLINE_INCURRAL'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );*/
--COMMENTED BY OAS--
--commit;
---------------------------------------------update BenefitSkey OF #BLTbl

--Update BenefitSKey to -1 if still find BenefitSKey -1

V_STEP_NAME    := ''MERGE - WRK_BIL_LN'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

MERGE INTO BDR_DM.WRK_BIL_LN BL USING
(select BL2.CH_ACCT_PART_NUM,BL2.CH_KEY,MAX(BL2.D_BEN_SK) D_BEN_SK,BL2.BILL_LN_NUM
  FROM BDR_DM.WRK_BIL_LN_ALL BL2
  WHERE BL2.TABLE_NAME = ''BLTbl2''
  AND BL2.TOSCODE = ''H2'' AND BL2.HSP_SNF_DAYS_IND = ''Z'' AND BL2.PRDCT = ''Med Supp''
  GROUP BY  BL2.CH_ACCT_PART_NUM,BL2.CH_KEY,BL2.BILL_LN_NUM
  ) BL2
ON ( BL2.CH_ACCT_PART_NUM = BL.CH_ACCT_PART_NUM
AND BL2.CH_KEY = BL.CH_KEY AND BL2.BILL_LN_NUM = BL.BILL_LN_NUM AND BL.TOSCODE = ''H2'' AND BL.HSP_SNF_DAYS_IND = ''Z'' AND BL.PRDCT = ''Med Supp'')
WHEN MATCHED THEN UPDATE
SET BL.D_BEN_SK = BL2.D_BEN_SK;
	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

 --COMMENTED BY OAS--
/*V_ROWS_AFFTD:=SQL%ROWCOUNT;
--commit;
INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''FACT_CLAIMS'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''MERGE'',
      ''Merge into  temp table WRK_BIL_LN'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );*/
--COMMENTED BY OAS--
--commit;
------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------End of derive d_ben_sk logic-----------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------

V_STEP_NAME    := ''INSERT - WRK_CLAIM_BILLLINE_INCURRAL'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

INSERT INTO BDR_DM.WRK_CLAIM_BILLLINE_INCURRAL (
    isid,
    account_number,
    ch_acct_part_num,
    ch_key,
    hosp_chrg_key,
    claim_no,
    bill_line_no,
    product,
    tos_code,
    service_frm_dt,
    service_to_dt,
    service_dt_cert_eff_dt,
    incurral_dt_id,
    cmpl_dt_id,
    claim_type_ind,
    incurral_dt_update_ind,
    adj_incurral_dt_update_ind,
    srv_accum1,
    srv_accum2,
    ben_perd_days,
    hsp_snf_days_ind,
    benefit_skey,
    plan_cd,
    etl_lst_btch_id
) ( SELECT
    isid,
    bl.acct_nbr,
    ch_acct_part_num,
    ch_key,
    hosp_chrg_key,
    clm_nbr,
    bill_ln_num,
    prdct,
    toscode,
        CASE WHEN
            bl.srvc_from_dt_id =-1
        THEN
            TO_DATE(''9999-01-01'',''YYYY-MM-DD'')
        WHEN
            bl.srvc_from_dt_id = 99991231
        THEN
            TO_DATE(''9999-12-30'',''YYYY-MM-DD'')
        ELSE
            TO_DATE(TO_CHAR(bl.srvc_from_dt_id),''YYYYMMDD'')
        END
    servicefrmdt,
        CASE WHEN
            bl.srvc_to_dt_id =-1
        THEN
            TO_DATE(''9999-01-01'',''YYYY-MM-DD'')
        WHEN
            bl.srvc_to_dt_id = 99991231
        THEN
            TO_DATE(''9999-12-30'',''YYYY-MM-DD'')
        ELSE
            TO_DATE(TO_CHAR(bl.srvc_to_dt_id),''YYYYMMDD'')
        END
    servicetodt,
    TO_DATE(''18991231'',''YYYYMMDD'') servicedtcerteffdt,
    -1 incurraldtid,
    cmpl_dt_id,
    1 claimtypeind,
    0 incurraldtupdateind,
    0 adjincurraldtupdateind,
    srv_accum1,
    srv_accum2,
    ben_perd_days,
    hsp_snf_days_ind,
    d_ben_sk,
    plan_cd,
    bl.etl_lst_btch_id
FROM
    BDR_DM.wrk_bil_ln bl
WHERE
    toscode IN (
        ''H2'',''W0'',''W1'',''W2'',''W4'',''W5'',''W6''
    )
AND
    prdct = ''Med Supp''
);
	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

--COMMENTED BY OAS--
/*V_ROWS_AFFTD:=SQL%ROWCOUNT;
--commit;
INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''FACT_CLAIMS'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''INSERT'',
      ''Insert into  table WRK_CLAIM_BILLLINE_INCURRAL'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );*/
--COMMENTED BY OAS--

    --commit;
--------------------------------------------------- HIP Claims------------------------------------------------


V_STEP_NAME    := ''INSERT - WRK_CLAIM_BILLLINE_INCURRAL'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

INSERT INTO BDR_DM.WRK_CLAIM_BILLLINE_INCURRAL (
    isid,
    account_number,
    ch_acct_part_num,
    ch_key,
    hosp_chrg_key,
    claim_no,
    bill_line_no,
    product,
    tos_code,
    service_frm_dt,
    service_to_dt,
    service_dt_cert_eff_dt,
    incurral_dt_id,
    cmpl_dt_id,
    claim_type_ind,
    incurral_dt_update_ind,
    adj_incurral_dt_update_ind,
    srv_accum1,
    srv_accum2,
    ben_perd_days,
    hsp_snf_days_ind,
    benefit_skey,
    plan_cd,
    etl_lst_btch_id
) ( SELECT
    bl.isid,
    bl.acct_nbr,
    ch_acct_part_num,
    ch_key,
    hosp_chrg_key,
    clm_nbr,
    bill_ln_num,
    bl.prdct,
    CASE WHEN bl.toscode=''Q0'' THEN ''H'' ELSE bl.toscode END AS tos_code,
        CASE WHEN
            bl.srvc_from_dt_id =-1
        THEN
            TO_DATE(''9999-01-01'',''YYYY-MM-DD'')
        WHEN
            bl.srvc_from_dt_id = 99991231
        THEN
            TO_DATE(''9999-12-30'',''YYYY-MM-DD'')
        ELSE
            TO_DATE(TO_CHAR(bl.srvc_from_dt_id),''YYYYMMDD'')
        END
    servicefrmdt,
        CASE WHEN
            bl.srvc_to_dt_id =-1
        THEN
            TO_DATE(''9999-01-01'',''YYYY-MM-DD'')
        WHEN
            bl.srvc_to_dt_id = 99991231
        THEN
            TO_DATE(''9999-12-30'',''YYYY-MM-DD'')
        ELSE
            TO_DATE(TO_CHAR(bl.srvc_to_dt_id),''YYYYMMDD'')
        END
    servicetodt,
    TO_DATE(''18991231'',''YYYYMMDD'') servicedtcerteffdt,
    -1 incurraldtid,
    bl.cmpl_dt_id,
    1 claimtypeind,
    0 incurraldtupdateind,
    0 adjincurraldtupdateind,
    bl.srv_accum1,
    bl.srv_accum2,
    bl.ben_perd_days,
    bl.hsp_snf_days_ind,
    bl.d_ben_sk,
    bl.plan_cd,
    bl.etl_lst_btch_id
FROM
    BDR_DM.wrk_bil_ln bl
join   BDR_DM.D_CLM_PLN b on bl.D_CLM_PLN_SK = b.D_CLM_PLN_SK
join   BDR_CONF.D_MBR_INFO c on bl.D_MBR_INFO_SK = c.D_MBR_INFO_SK
WHERE  bl.TOSCoDe IN (''H1'',''H2'',''H3'',''H4'',''H9'',''Q0'',''W0'',''W1'',''W2'',''W3'',''W4'',''W5'')
AND    b.COMPAS_PLN_CD IN
(
select distinct COMPAS_PLN_CD from BDR_CONF.D_PLN_BEN_MOD a
WHERE a.PLN_LVL     IN (''B1'', ''BA'', ''BB'', ''BC'', ''CB'', ''D1'', ''DH'', ''GC'', ''HB'', ''HD'', ''HF'', ''HH'', ''HP'', ''JB'', ''JC'', ''JE'', ''JG'', ''JH'', ''JI'', ''JJ'', ''JK'', ''KB'', ''ND'', ''RV'', ''T1'', ''UVW'', ''X0'', ''X1'', ''X8'', ''Y0'', ''Y1'', ''Y8'', ''Z0'', ''Z1'', ''Z8'')
)) ;
	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

--COMMENTED BY OAS--
/*V_ROWS_AFFTD:=SQL%ROWCOUNT;

--commit;
INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''FACT_CLAIMS'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''INSERT'',
      ''Insert HIP Claims WRK_CLAIM_BILLLINE_INCURRAL'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );*/
--COMMENTED BY OAS--
--commit;

------------------------------------------------------------------------------------------------------------------------------------
-- SCR 74746 - Update D_LGL_ENTY_SK for claims with dupliacte LE
------------------------------------------------------------------------------------------------------------------------------------

--SELECT  METADATA_VALUE INTO V_LE_SK_FOR_DUP FROM ETL.ETL_APPLICATION_METADATA WHERE APPLICATION=''CLAIMS'' AND METADATA_TYPE=''DEFAULT_LE_FOR_DUPS'';	--OAS DELETE

V_STEP_NAME    := ''MERGE - WRK_BIL_LN'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

MERGE /*+ enable_parallel_dml */ INTO  BDR_DM.WRK_BIL_LN TGT  USING
(
        SELECT  /*+ parallel(8) */ WBL.WRK_BIL_LN_SK
        FROM            BDR_DM.WRK_BIL_LN WBL
        INNER JOIN      (SELECT CLM_NBR,MAX(NVL(LE_FINC_CD,'''')) LE_FINC_CD FROM SRC_FOX_D.TMEMB2_CLAIM2_NUM2 WHERE CLM_STS_CD IN (''D'',''R'') GROUP BY CLM_NBR HAVING COUNT(1)>1)  TMEM
		ON WBL.CLM_NBR = TO_NUMBER(NULLIF((NVL(TO_CHAR(SUBSTR(LPAD(TMEM.CLM_NBR, 12, ''0''),4,9)), '''')||NVL(TO_CHAR(SUBSTR(LPAD(TMEM.CLM_NBR, 12, ''0''),1,3)), '''')), ''''))
) SRC   ON (SRC.WRK_BIL_LN_SK=TGT.WRK_BIL_LN_SK)
WHEN MATCHED THEN UPDATE
SET TGT.D_LGL_ENTY_SK = :V_LE_SK_FOR_DUP;
	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );



V_STEP_NAME    := ''INSERT - F_CLM_BIL_LN_HIST'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

insert into BDR_DM.F_CLM_BIL_LN_HIST
(F_CLM_HIST_SK,
BIL_LN_NBR,
SRVC_FROM_DT_ID,
SRVC_TO_DT_ID,
MEDCR_APRV_AMT,
BEN_AMT,
MEDCR_PD_AMT,
PCT_PD,
SBMT_CHRG_AMT,
CHRG_AMT,
COV_EXPN_AMT,
D_CHRG_TYP_IND,
BIL_PROV_KEY,
RNDR_PROV_NPI,
MEDCR_ASGN_IND,
CLM_ASGN_IND,
PRE_XST_IND,
D_CPT_LOOK_SK,
D_CPT_LOOK_SK_1,
D_CPT_LOOK_SK_2,
D_CPT_LOOK_SK_3,
D_CPT_LOOK_SK_4,
AARP_DED_AMT,
PART_B_DED_AMT,
HOSP_DAY_BEN_AMT,
D_HOSP_SNF_DAY_IND,
ADJ_BEN_AMT,
UCPS_PLN_IND,
D_CLM_PLN_SK,
ETL_LST_BTCH_ID,
D_CLM_TYP_IND,
D_BEN_SK,
CERT_EFF_DT_ID,
CH_ACCT_PART_NBR,
D_GDR_ID_SK,
INCUR_DT_ID,
D_MBR_INFO_SK,
D_PLN_BEN_MOD_SK,
PLN_ISS_D_GEO_XREF_SK,
PREM_DUE_AGE_ID,
D_RTNG_AREA_SK,
RES_D_GEO_XREF_SK,
SRVC_DT_D_GEO_XREF_SK,
TEMP_CERT_EFF_DT_ID,
TEMP_D_CLM_PLN_SK,
TEMP_INCUR_DT_ID,
TEMP_D_PLN_BEN_MOD_SK,
TEMP_D_RTNG_AREA_SK,
TEMP_RES_D_GEO_XREF_SK,
CLM_PD_DT_ID,
ACCT_NBR,
SRVC_DT_PLN_SK,
SRVC_CERT_EFF_DT_ID,
CLM_NBR,
CLM_CDW_LNK_KEY,
CLM_PREM_LNK_KEY,
TEMP_CLM_PD_DT_ID,
CMPL_DT_ID,
TOS_CD,
CERT_D_ACQN_CHNL_SK,
PRDCT_D_ACQN_CHNL_SK,
MBR_D_ACQN_CHNL_SK,
D_UNDWR_TAG_SK,
BLH_KEY,
BIL_D_PROV_SK,
D_TOS_SK,
OOP_AMT,
AARP_COPAY_AMT,
BL_NO_PAY_IND,
RNDR_PROV_NM,
SRVC_ACCUM_1_NBR,
SRVC_ACCUM_2_NBR,
BEN_PRD_NBR,
BEN_PRD_DAY,
D_DSCNT_ANNL_PAYR_SK,
D_DSCNT_EFT_SK,
D_DSCNT_ERLY_ENRL_SK,
D_DSCNT_LNGVTY_SK,
D_DSCNT_MULTI_INSD_SK,
D_SURCHRG_TIER_SK,
D_SURCHRG_TBCC_USER_SK,
D_INSD_PLN_PRFL_SK,
D_CALC_RT_SK,
MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
CERT_EFF_AGE_LOOK_FRAC,
D_LGL_ENTY_SK,
BATCH_ID
)
SELECT * FROM
-----------------------------------------------------------------------------------------
--Allocate pay_adj_amt for asgn_ind <> Y and Add remaining amount to assgn_adj_amt
-----------------------------------------------------------------------------------------
(WITH CTE_Alloc_NotY (ROW_NUMBER,
						bill_ln_num,
						ch_acct_part_num,
						ch_key,
						asgn_ind,
						pay_adj_amt,
						assgn_adj_amt,
						ben_amt, PaidAmt, PayRemain, Newassgn_adj_amt )
AS
(
			SELECT		ROW_NUMBER,
						bill_ln_num,
						ch_acct_part_num,
						ch_key,
						asgn_ind,
						pay_adj_amt,
						assgn_adj_amt,
						ben_amt,
						CASE WHEN pay_adj_amt - ben_amt >= 0
							 THEN CAST(ben_amt AS DECIMAL(19,2))
							 ELSE CAST((pay_adj_amt) AS DECIMAL(19,2))
							 END  PaidAmt,
						CASE WHEN pay_adj_amt - ben_amt > 0.00
							 THEN CAST((pay_adj_amt - ben_amt) AS DECIMAL(19,2))
							 ELSE 0.00
							 END  PayRemain,
						CASE WHEN pay_adj_amt - ben_amt > 0.00
							 THEN assgn_adj_amt+CAST((pay_adj_amt - ben_amt) AS DECIMAL(19,2))
							 ELSE assgn_adj_amt+0.00
							 END  Newassgn_adj_amt
			FROM		(SELECT		*
FROM		BDR_DM.WRK_BIL_LN B
WHERE		(B.assgn_adj_amt > 0.00 OR B.pay_adj_amt > 0.00)
AND			B.srv_cd <> ''Y'')
			WHERE       asgn_ind <> ''Y''
			AND			ROW_NUMBER = 1

			UNION ALL

			SELECT      B.ROW_NUMBER,
						B.bill_ln_num,
						B.ch_acct_part_num,
						B.ch_key,
						B.asgn_ind,
						B.pay_adj_amt,
						B.assgn_adj_amt,
						B.ben_amt,
						CASE WHEN t.PayRemain - B.ben_amt > 0.00
							 THEN CAST(B.ben_amt AS DECIMAL(19,2))
							 ELSE CAST(t.PayRemain AS DECIMAL(19,2))
							 END  PaidAmt,
						CASE WHEN t.PayRemain - B.ben_amt > 0.00
							 THEN CAST((t.PayRemain - B.ben_amt) AS DECIMAL(19,2))
							 ELSE 0.00
							 END  PayRemain,
						CASE WHEN t.PayRemain - B.ben_amt > 0.00
							 THEN B.assgn_adj_amt+CAST((t.PayRemain - B.ben_amt) AS DECIMAL(19,2))
							 ELSE B.assgn_adj_amt+0.00
							 END  Newassgn_adj_amt
			FROM		CTE_Alloc_NotY t
			INNER JOIN	(SELECT		*
FROM		BDR_DM.wrk_bil_ln B
WHERE		(B.assgn_adj_amt > 0.00 OR B.pay_adj_amt > 0.00)
AND			B.srv_cd <> ''Y'') B		ON	t.ch_acct_part_num = B.ch_acct_part_num
									AND t.ch_key = B.ch_key
									AND B.ROW_NUMBER = t.ROW_NUMBER + 1
			AND			B.asgn_ind <> ''Y''
),
Alloc_NotY1 as
(SELECT		B.ROW_NUMBER,
			B.bill_ln_num,
			B.ch_acct_part_num,
			B.ch_key,
			B.asgn_ind,
			B.pay_adj_amt,
			B.assgn_adj_amt,
			B.ben_amt,
			b.PaidAmt,
			b.PayRemain,
			b.Newassgn_adj_amt,
			b.ben_amt - b.PaidAmt AdjustBenefitAmt,
			(SELECT MIN(Newassgn_adj_amt) FROM CTE_Alloc_NotY a WHERE a.ch_acct_part_num = b.ch_acct_part_num AND a.ch_key = b.ch_key) AdjAssgnAmt
FROM		CTE_Alloc_NotY b),

-----------------------------------------------------------------------------------------------------------------------------------
--Allocate assgn_adj_amt for asgn_ind = Y and Insert the Adjusted Ben Amount to BillLine Fact table
-----------------------------------------------------------------------------------------------------------------------------------

Alloc_Y AS (
SELECT		DISTINCT b.ROW_NUMBER,
			b.ch_acct_part_num,
			b.ch_key,
			b.bill_ln_num,
			b.asgn_ind,
			b.assgn_adj_amt,
			a.AdjAssgnAmt,
			b.pay_adj_amt,
			CASE WHEN a.AdjAssgnAmt IS NULL
			     THEN b.assgn_adj_amt
			     ELSE a.AdjAssgnAmt
			     END  AdjAssgnAmt1,
			b.ben_amt
FROM		(SELECT		*
FROM		BDR_DM.wrk_bil_ln B
WHERE		(B.assgn_adj_amt > 0.00 OR B.pay_adj_amt > 0.00)
AND			B.srv_cd <> ''Y'') b
LEFT JOIN	Alloc_NotY1 a			ON	a.ch_acct_part_num = B.ch_acct_part_num
									AND a.ch_key = B.ch_key
WHERE		b.asgn_ind = ''Y''
),
CTE_Alloc_Y1 (ROW_NUMBER,
						bill_ln_num,
						ch_acct_part_num,
						ch_key,
						asgn_ind,
						pay_adj_amt,
						assgn_adj_amt,
						AdjAssgnAmt1,
						ben_amt,
						PaidAmt,
						PayRemain )
AS
(
			SELECT		ROW_NUMBER,
						bill_ln_num,
						ch_acct_part_num,
						ch_key,
						asgn_ind,
						pay_adj_amt,
						assgn_adj_amt,
						AdjAssgnAmt1,
						ben_amt,
						CASE WHEN AdjAssgnAmt1 - ben_amt >= 0
							 THEN CAST(ben_amt AS DECIMAL(19,2))
							 ELSE CAST((AdjAssgnAmt1) AS DECIMAL(19,2))
							 END  PaidAmt,
						CASE WHEN AdjAssgnAmt1 - ben_amt > 0.00
							 THEN CAST((AdjAssgnAmt1 - ben_amt) AS DECIMAL(19,2))
							 ELSE 0.00
							 END  PayRemain
			FROM		Alloc_Y
			WHERE		ROW_NUMBER = 1

			UNION ALL

			SELECT      B.ROW_NUMBER,
						B.bill_ln_num,
						B.ch_acct_part_num,
						B.ch_key,
						B.asgn_ind,
						B.pay_adj_amt,
						B.assgn_adj_amt,
						B.AdjAssgnAmt1,
						B.ben_amt,
						CASE WHEN t.PayRemain - B.ben_amt > 0.00
							 THEN CAST(B.ben_amt AS DECIMAL(19,2))
							 ELSE CAST(t.PayRemain AS DECIMAL(19,2))
							 END  PaidAmt,
							 CASE WHEN t.PayRemain - B.ben_amt > 0.00
							 THEN CAST((t.PayRemain - B.ben_amt) AS decimal(19,2))
							 ELSE 0.00
							 END  PayRemain
			FROM		CTE_Alloc_Y1 t
			INNER JOIN	Alloc_Y B			ON	t.ch_acct_part_num = B.ch_acct_part_num
											AND t.ch_key = B.ch_key
											AND B.ROW_NUMBER = t.ROW_NUMBER + 1
)
------------------------------------------------------------------------------------------------------------------------------------
--Insert Allocated pay_adj_amt for asgn_ind <> Y into BillLine Fact table
------------------------------------------------------------------------------------------------------------------------------------

SELECT
			B.f_clm_hist_sk
			,B.bill_ln_num
			,B.srvc_from_dt_id
			,B.srvc_to_dt_id
			,B.mcare_aprv_amt
			,B.ben_amt
			,B.mcare_paid_amt
			,B.pct_pd
			,B.submitted_chrg
			,B.chrg_amt
			,B.cvrd_xpnce_amt
			,B.chrg_tbl_ind
			,B.bl_prov_key
			,B.rend_prv_npi
			,B.Mcare_asgn_ind
			,B.asgn_ind
			,B.pre_exist_ind
			,B.d_cpt_look_sk
			,B.d_cpt_mod_look_sk1
			,B.d_cpt_mod_look_sk2
			,B.d_cpt_mod_look_sk3
			,B.d_cpt_mod_look_sk4
			,B.aarp_ded_amt
			,B.partb_ded_amt
			,B.daily_ben_amt
			,B.hsp_snf_days_ind
			,A.AdjustBenefitAmt
			,B.plan_ind
			,B.d_clm_pln_sk
			,B.etl_lst_btch_id
			,B.ClaimTypeInd
			,B.d_ben_sk
			,-1						CertEffectiveDateID
			,B.ch_acct_part_num						ch_acct_part_num
			,-1						GenderID
			,CASE WHEN B.prdct <> ''Med Supp'' THEN B.srvc_from_dt_id ELSE -1 END IncurralDateID
			,d_mbr_info_sk
			,-1						PlanBenModSKey
			,-1						PlanIssueGeographySKey
			,999.99						PremiumDueAgeID
			,-1						RatingAreaSKey
			,-1						ResidentGeographySKey
			,B.SRVC_DT_D_GEO_XREF_SK  			ServiceDtGeographySKey
			,-1						TempCertEffectiveDateID
			,B.d_clm_pln_sk						Tempd_clm_pln_sk
			,CASE WHEN B.prdct <> ''Med Supp'' THEN B.srvc_from_dt_id ELSE -1 END TempIncurralDateID
			,-1						TempPlanBenModSKey
			,-1						TempRatingAreaSKey
			,-1						TempResidentGeographySKey
			,B.clm_pd_dt_id
			,B.acct_nbr
			,-1						ServiceDtPlanSKey
			,-1						ServiceCertEffDtID
			,clm_nbr
			,0						CLM_CDW_LNK_KEY
			,0						CLM_PREM_LNK_KEY
			,B.temp_clm_pd_dt_id
			,B.cmpl_dt_id
			,B.TOSCode
			,-1						CERT_ACQN_CHNL_KEY
			,-1						PRDCT_ACQN_CHNL_KEY
			,-1						MBR_ACQN_CHNL_KEY
			,-1						UNDWR_TAG_KEY
			,BLH_KEY
			,BIL_D_PROV_SK
			,D_TOS_SK
			,OOP_AMT
			,AARP_COPAY_AMT
			,BL_NO_PAY_IND
			,RNDR_PROV_NM
			,SRV_ACCUM1
			,SRV_ACCUM2
			,BEN_PRD_NBR
			,BEN_PERD_DAYS
			,D_DSCNT_ANNL_PAYR_SK
			,D_DSCNT_EFT_SK
			,D_DSCNT_ERLY_ENRL_SK
			,D_DSCNT_LNGVTY_SK
			,D_DSCNT_MULTI_INSD_SK
			,D_SURCHRG_TIER_SK
			,D_SURCHRG_TBCC_USER_SK
			,D_INSD_PLN_PRFL_SK
			,D_CALC_RT_SK
			,MEDSUP_PLN_ENT_AGE_LOOK_FRAC
			,CERT_EFF_AGE_LOOK_FRAC
			,D_LGL_ENTY_SK
			,:V_BATCH_ID AS BATCH_ID
FROM		Alloc_NotY1 A
INNER JOIN	(select * FROM BDR_DM.wrk_bil_ln B
WHERE		(B.assgn_adj_amt > 0.00 OR B.pay_adj_amt > 0.00)
AND			B.srv_cd <> ''Y'') B			ON	A.ch_acct_part_num = B.ch_acct_part_num
							AND A.ch_key = B.ch_key
							AND A.bill_ln_num = B.bill_ln_num
union -- Changed to UNION ALL after confirmation
------------------------------------------------------------------------------------------------------------------------------------
--Insert Allocated pay_adj_amt for asgn_ind = Y into BillLine Fact table
------------------------------------------------------------------------------------------------------------------------------------
SELECT
			B.f_clm_hist_sk
			,B.bill_ln_num
			,B.srvc_from_dt_id
			,B.srvc_to_dt_id
			,B.mcare_aprv_amt
			,B.ben_amt
			,B.mcare_paid_amt
			,B.pct_pd
			,B.submitted_chrg
			,B.chrg_amt
			,B.cvrd_xpnce_amt
			,B.chrg_tbl_ind
			,B.bl_prov_key
			,B.rend_prv_npi
			,B.Mcare_asgn_ind
			,B.asgn_ind
			,B.pre_exist_ind
			,B.d_cpt_look_sk
			,B.d_cpt_mod_look_sk1
			,B.d_cpt_mod_look_sk2
			,B.d_cpt_mod_look_sk3
			,B.d_cpt_mod_look_sk4
			,B.aarp_ded_amt
			,B.partb_ded_amt
			,B.daily_ben_amt
			,B.hsp_snf_days_ind
			,A.ben_amt - A.PaidAmt		AdjustBenefitAmt
			,B.plan_ind
			,B.d_clm_pln_sk
			,B.etl_lst_btch_id
			,B.ClaimTypeInd
			,B.d_ben_sk
			,-1						CertEffectiveDateID
			,B.ch_acct_part_num						ch_acct_part_num
			,-1						GenderID
			,CASE WHEN B.prdct <> ''Med Supp'' THEN B.srvc_from_dt_id ELSE -1 END IncurralDateID
			,d_mbr_info_sk
			,-1						PlanBenModSKey
			,-1						PlanIssueGeographySKey
			,999.99						PremiumDueAgeID
			,-1						RatingAreaSKey
			,-1						ResidentGeographySKey
			,B.SRVC_DT_D_GEO_XREF_SK 			ServiceDtGeographySKey
			,-1						TempCertEffectiveDateID
			,B.d_clm_pln_sk						Tempd_clm_pln_sk
			,CASE WHEN B.prdct <> ''Med Supp'' THEN B.srvc_from_dt_id ELSE -1 END TempIncurralDateID
			,-1						TempPlanBenModSKey
			,-1						TempRatingAreaSKey
			,-1						TempResidentGeographySKey
			,B.clm_pd_dt_id
			,B.acct_nbr
			,-1						ServiceDtPlanSKey
			,-1						ServiceCertEffDtID
			,clm_nbr
			,0						CLM_CDW_LNK_KEY
			,0						CLM_PREM_LNK_KEY
			,B.temp_clm_pd_dt_id
			,B.cmpl_dt_id
			,B.TOSCode
			,-1						CERT_ACQN_CHNL_KEY
			,-1						PRDCT_ACQN_CHNL_KEY
			,-1						MBR_ACQN_CHNL_KEY
			,-1						UNDWR_TAG_KEY
			,BLH_KEY
			,BIL_D_PROV_SK
			,D_TOS_SK
			,OOP_AMT
			,AARP_COPAY_AMT
			,BL_NO_PAY_IND
			,RNDR_PROV_NM
			,SRV_ACCUM1
			,SRV_ACCUM2
			,BEN_PRD_NBR
			,BEN_PERD_DAYS
			,D_DSCNT_ANNL_PAYR_SK
			,D_DSCNT_EFT_SK
			,D_DSCNT_ERLY_ENRL_SK
			,D_DSCNT_LNGVTY_SK
			,D_DSCNT_MULTI_INSD_SK
			,D_SURCHRG_TIER_SK
			,D_SURCHRG_TBCC_USER_SK
			,D_INSD_PLN_PRFL_SK
			,D_CALC_RT_SK
			,MEDSUP_PLN_ENT_AGE_LOOK_FRAC
			,CERT_EFF_AGE_LOOK_FRAC
			,D_LGL_ENTY_SK
			,:V_BATCH_ID AS BATCH_ID
FROM		CTE_Alloc_Y1 A
INNER JOIN	(select * FROM		BDR_DM.wrk_bil_ln  B
WHERE		(B.assgn_adj_amt > 0.00 OR B.pay_adj_amt > 0.00)
AND			B.srv_cd <> ''Y'') B	ON	A.ch_acct_part_num = B.ch_acct_part_num
							AND A.ch_key = B.ch_key
							AND A.bill_ln_num = B.bill_ln_num);
	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

--COMMENTED BY OAS--
/*V_ROWS_AFFTD:=SQL%ROWCOUNT;
--commit;
INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''FACT_CLAIMS'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''INSERT1'',
      ''Insert into  table F_CLM_BIL_LN_HIST'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );*/
--COMMENTED BY OAS--
    --commit;

------------------------------------------------------------------------------------------------------------------------------------
--Insert BillLine records which does not require allocation into BillLine Fact table
------------------------------------------------------------------------------------------------------------------------------------

V_STEP_NAME    := ''INSERT - F_CLM_BIL_LN_HIST'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

insert into BDR_DM.F_CLM_BIL_LN_HIST
(F_CLM_HIST_SK,
BIL_LN_NBR,
SRVC_FROM_DT_ID,
SRVC_TO_DT_ID,
MEDCR_APRV_AMT,
BEN_AMT,
MEDCR_PD_AMT,
PCT_PD,
SBMT_CHRG_AMT,
CHRG_AMT,
COV_EXPN_AMT,
D_CHRG_TYP_IND,
BIL_PROV_KEY,
RNDR_PROV_NPI,
MEDCR_ASGN_IND,
CLM_ASGN_IND,
PRE_XST_IND,
D_CPT_LOOK_SK,
D_CPT_LOOK_SK_1,
D_CPT_LOOK_SK_2,
D_CPT_LOOK_SK_3,
D_CPT_LOOK_SK_4,
AARP_DED_AMT,
PART_B_DED_AMT,
HOSP_DAY_BEN_AMT,
D_HOSP_SNF_DAY_IND,
ADJ_BEN_AMT,
UCPS_PLN_IND,
D_CLM_PLN_SK,
ETL_LST_BTCH_ID,
D_CLM_TYP_IND,
D_BEN_SK,
CERT_EFF_DT_ID,
CH_ACCT_PART_NBR,
D_GDR_ID_SK,
INCUR_DT_ID,
D_MBR_INFO_SK,
D_PLN_BEN_MOD_SK,
PLN_ISS_D_GEO_XREF_SK,
PREM_DUE_AGE_ID,
D_RTNG_AREA_SK,
RES_D_GEO_XREF_SK,
SRVC_DT_D_GEO_XREF_SK,
TEMP_CERT_EFF_DT_ID,
TEMP_D_CLM_PLN_SK,
TEMP_INCUR_DT_ID,
TEMP_D_PLN_BEN_MOD_SK,
TEMP_D_RTNG_AREA_SK,
TEMP_RES_D_GEO_XREF_SK,
CLM_PD_DT_ID,
ACCT_NBR,
SRVC_DT_PLN_SK,
SRVC_CERT_EFF_DT_ID,
CLM_NBR,
CLM_CDW_LNK_KEY,
CLM_PREM_LNK_KEY,
TEMP_CLM_PD_DT_ID,
CMPL_DT_ID,
TOS_CD,
CERT_D_ACQN_CHNL_SK,
PRDCT_D_ACQN_CHNL_SK,
MBR_D_ACQN_CHNL_SK,
D_UNDWR_TAG_SK,
BLH_KEY,
BIL_D_PROV_SK,
D_TOS_SK,
OOP_AMT,
AARP_COPAY_AMT,
BL_NO_PAY_IND,
RNDR_PROV_NM,
SRVC_ACCUM_1_NBR,
SRVC_ACCUM_2_NBR,
BEN_PRD_NBR,
BEN_PRD_DAY,
D_DSCNT_ANNL_PAYR_SK,
D_DSCNT_EFT_SK,
D_DSCNT_ERLY_ENRL_SK,
D_DSCNT_LNGVTY_SK,
D_DSCNT_MULTI_INSD_SK,
D_SURCHRG_TIER_SK,
D_SURCHRG_TBCC_USER_SK,
D_INSD_PLN_PRFL_SK,
D_CALC_RT_SK,
MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
CERT_EFF_AGE_LOOK_FRAC,
D_LGL_ENTY_SK,
BATCH_ID
)
SELECT
			B.f_clm_hist_sk
			,B.bill_ln_num
			,B.srvc_from_dt_id
			,B.srvc_to_dt_id
			,B.mcare_aprv_amt
			,B.ben_amt
			,B.mcare_paid_amt
			,B.pct_pd
			,B.submitted_chrg
			,B.chrg_amt
			,B.cvrd_xpnce_amt
			,B.chrg_tbl_ind
			,B.bl_prov_key
			,B.rend_prv_npi
			,B.Mcare_asgn_ind
			,B.asgn_ind
			,B.pre_exist_ind
			,B.d_cpt_look_sk
			,B.d_cpt_mod_look_sk1
			,B.d_cpt_mod_look_sk2
			,B.d_cpt_mod_look_sk3
			,B.d_cpt_mod_look_sk4
			,B.aarp_ded_amt
			,B.partb_ded_amt
			,B.daily_ben_amt
			,B.hsp_snf_days_ind
			,B.ben_amt				AdjustBenefitAmt
			,B.plan_ind
			,B.d_clm_pln_sk
			,B.etl_lst_btch_id
			,B.ClaimTypeInd
			,B.d_ben_sk
			,-1						CertEffectiveDateID
			,B.ch_acct_part_num						ch_acct_part_num
			,-1						GenderID
			,CASE WHEN B.prdct <> ''Med Supp'' THEN B.srvc_from_dt_id ELSE -1 END IncurralDateID
			,d_mbr_info_sk
			,-1						PlanBenModSKey
			,-1						PlanIssueGeographySKey
			,999.99						PremiumDueAgeID
			,-1						RatingAreaSKey
			,-1						ResidentGeographySKey
			,B.SRVC_DT_D_GEO_XREF_SK 			ServiceDtGeographySKey
			,-1						TempCertEffectiveDateID
			,B.d_clm_pln_sk						Tempd_clm_pln_sk
			,CASE WHEN B.prdct <> ''Med Supp'' THEN B.srvc_from_dt_id ELSE -1 END TempIncurralDateID
			,-1						TempPlanBenModSKey
			,-1						TempRatingAreaSKey
			,-1						TempResidentGeographySKey
			,clm_pd_dt_id
			,B.acct_nbr
			,-1						ServiceDtPlanSKey
			,-1						ServiceCertEffDtID
			,clm_nbr
			,0						CLM_CDW_LNK_KEY
			,0						CLM_PREM_LNK_KEY
			,B.temp_clm_pd_dt_id
			,B.cmpl_dt_id
			,B.TOSCode
			,-1						CERT_ACQN_CHNL_KEY
			,-1						PRDCT_ACQN_CHNL_KEY
			,-1						MBR_ACQN_CHNL_KEY
			,-1						UNDWR_TAG_KEY
			,BLH_KEY
			,BIL_D_PROV_SK
			,D_TOS_SK
			,OOP_AMT
			,AARP_COPAY_AMT
			,BL_NO_PAY_IND
			,RNDR_PROV_NM
			,SRV_ACCUM1
			,SRV_ACCUM2
			,BEN_PRD_NBR
			,BEN_PERD_DAYS
			,D_DSCNT_ANNL_PAYR_SK
			,D_DSCNT_EFT_SK
			,D_DSCNT_ERLY_ENRL_SK
			,D_DSCNT_LNGVTY_SK
			,D_DSCNT_MULTI_INSD_SK
			,D_SURCHRG_TIER_SK
			,D_SURCHRG_TBCC_USER_SK
			,D_INSD_PLN_PRFL_SK
			,D_CALC_RT_SK
			,MEDSUP_PLN_ENT_AGE_LOOK_FRAC
			,CERT_EFF_AGE_LOOK_FRAC
			,D_LGL_ENTY_SK
			,:V_BATCH_ID AS BATCH_ID
FROM	BDR_DM.wrk_bil_ln B
WHERE	NOT exists
		(select blh_key FROM BDR_DM.wrk_bil_ln  A
WHERE	(A.assgn_adj_amt > 0.00 OR A.pay_adj_amt > 0.00) AND A.srv_cd <> ''Y'' AND A.blh_key=b.blh_key);
	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

--COMMENTED BY OAS--
/*V_ROWS_AFFTD:=SQL%ROWCOUNT;

--commit;
INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''FACT_CLAIMS'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''INSERT2'',
      ''Insert into  table F_CLM_BIL_LN_HIST'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );
    --commit;

V_ROWS_AFFTD:=SQL%ROWCOUNT;

	INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''FACT_CLAIMS'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''END'',
      ''PROCEDURE ENDS'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );

    --commit;


   --Returns the result set
   P_ToContinueStatus := ''Y'';
   P_ErrorYNFlg := ''N'';
   P_ErrorStr := '''';*/
/*EXCEPTION
   WHEN OTHERS
   THEN
      P_ErrorStr :=
            ''ERROR: ''
         || SQLCODE
         || ''-''
         || SQLERRM
         || ''-''
         || DBMS_UTILITY.FORMAT_ERROR_STACK ();
      P_ToContinueStatus := ''N'';
      P_ErrorYNFlg := ''Y'';
      ROLLBACK;
      */
/*END;

END IF;
END;
/*/
--COMMENTED BY OAS--


CALL UTIL.SP_ETL_CHECK_CONSTRAINTS(:DB_NAME , :APPLICATION , :WORKFLOW_NAME , :OBJECT_NAME , :V_BATCH_ID );		---------OAS ADD


UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''COMPLETE'', ERROR_MSG = null, BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
;
UPDATE  UTIL.ETL_BATCH_OBJECT_INCR_VALU SET INCR_COLUMN_VALUE = :V_BATCH_ID, LST_MOD_DT = CURRENT_TIMESTAMP() 
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID''
;

EXCEPTION

WHEN OTHER THEN

UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''ERROR'', ERROR_MSG = :SQLERRM,  BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
;

INSERT INTO  UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ERROR_MSG, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''ERROR'', :V_STEP_NAME, :V_STEP_SEQ, :SQLERRM, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() )
;



RAISE;

END;

';