USE SCHEMA BDR_DM; CREATE OR REPLACE PROCEDURE "SP_PREMIUM_INTERMEDIATE2_IXL_WRKCOMPASDEMOGRAPHICDATA_D"("DB_NAME" VARCHAR(16777216), "APPLICATION" VARCHAR(16777216), "WORKFLOW_NAME" VARCHAR(16777216), "OBJECT_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '

-- Original workflow: wkf_RIA_Premium_Intermediate_IXL_TargetLoad2_D
-- Original mapping: m_Premium_Intermediate2_IXL_WrkCompasDemographicData_D 
-- Original folder: Premium
-- Original filename: wkf_RIA_Premium_Intermediate_IXL_TargetLoad2_D.XML

DECLARE


V_ROWS_INSERTED  INTEGER;
V_ROWS_UPDATED INTEGER;
V_ROWS_DELETED INTEGER;
V_LAST_QUERY_ID VARCHAR;

V_WH VARCHAR;
V_BATCH_ID INTEGER;


V_BATCH_OBJECT_START_TIME VARCHAR;
V_STEP_START_TIME    VARCHAR;
V_STEP_NAME VARCHAR;
V_STEP_SEQ INTEGER DEFAULT 0;
V_ETL_LST_BTCH_ID INTEGER;
V_DEMOGRAPHIC_DATE VARCHAR;

--COMMENTED BY OAS--
/* CREATE OR REPLACE PROCEDURE DM.SP_PREMIUM_DEMOGRAPHICDATA_D (
    iv_dummy             IN VARCHAR2,
    p_tocontinuestatus   OUT VARCHAR2,
    p_errorynflg         OUT VARCHAR2,
    p_errorstr           OUT VARCHAR2
) AS

    v_proc_name         VARCHAR(50) := ''''SP_PREMIUM_DEMOGRAPHICDATA_D'''';
    v_rows_afftd        NUMBER(20) := 0;
    v_btch_id           NUMBER(10);
    v_demographicdate   DATE; */
--COMMENTED BY OAS--
 
BEGIN 
EXECUTE IMMEDIATE ''USE DATABASE '' || :DB_NAME;

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_BATCH_OBJECT_START_TIME := (SELECT CURRENT_TIMESTAMP());

LET res1 RESULTSET := (
    SELECT
        WH,
        BATCH_ID
    FROM
        UTIL.ETL_BATCH_OBJECT_CONTROL
    WHERE
        APPLICATION = :APPLICATION
        AND WORKFLOW_NAME = :WORKFLOW_NAME
        AND OBJECT_NAME = :OBJECT_NAME
    FETCH FIRST
        1 ROW ONLY
);

LET C1 CURSOR FOR res1;
open C1;
FETCH C1 into V_WH,V_BATCH_ID;
close C1;


LET res2 RESULTSET := 

(

WITH PARAMETERS (DEMOGRAPHIC_DATE) AS
(
  
SELECT * 
FROM  
(SELECT PARAMETER_NAME, PARAMETER_VALUE  FROM UTIL.ETL_OBJECT_PARAMETER_VALUE 
WHERE 1 = 1
AND APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
AND ACTIVE_FLG = ''Y''  
  
UNION ALL       

SELECT PARAMETER_NAME, PARAMETER_VALUE  FROM UTIL.ETL_GLOBAL_PARAMETER_VALUE WHERE PAR_GLOBAL_TYPE = ''PARGLOBAL_OPREPORTS'' AND ACTIVE_FLG = ''Y'' AND PARAMETER_NAME NOT IN  (
SELECT PARAMETER_NAME  FROM UTIL.ETL_OBJECT_PARAMETER_VALUE WHERE 1 = 1
AND APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
AND ACTIVE_FLG = ''Y''   ))
 
PIVOT(MAX(PARAMETER_VALUE) FOR PARAMETER_NAME IN (''DEMOGRAPHIC_DATE'')) 

)  
SELECT * FROM PARAMETERS 
);



LET C2 CURSOR FOR res2;
open C2;
FETCH C2 into  V_DEMOGRAPHIC_DATE; 
close C2;

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:V_WH;

USE SCHEMA BDR_DM;	  

INSERT INTO UTIL.ETL_BATCH_OBJECT_INCR_VALU (APPLICATION, WORKFLOW_NAME, OBJECT_NAME, INCR_COLUMN, INCR_COLUMN_VALUE )
SELECT * FROM (select :APPLICATION AS APPLICATION, :WORKFLOW_NAME AS WORKFLOW_NAME, :OBJECT_NAME AS OBJECT_NAME, ''ETL_LST_BTCH_ID'' AS INCR_COLUMN, -1 AS INCR_COLUMN_VALUE) A
WHERE NOT EXISTS (SELECT 1 FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU B WHERE B.APPLICATION = A.APPLICATION AND B.WORKFLOW_NAME = A.WORKFLOW_NAME AND B.OBJECT_NAME = A.OBJECT_NAME AND B.INCR_COLUMN = A.INCR_COLUMN)
;

V_ETL_LST_BTCH_ID :=(SELECT INCR_COLUMN_VALUE FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID'');

V_DEMOGRAPHIC_DATE := (SELECT TO_DATE(:V_DEMOGRAPHIC_DATE, ''YYYYMMDD''));



V_STEP_NAME := ''TRUNCATE - WRK_COMPAS_DEMOGRAPHICDATA'';

V_STEP_SEQ := V_STEP_SEQ + 1;

V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());

V_ROWS_INSERTED := null;

V_ROWS_UPDATED := null;

V_ROWS_DELETED := null;

TRUNCATE TABLE BDR_DM.WRK_COMPAS_DEMOGRAPHICDATA;

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );


V_STEP_NAME := ''INSERT - WRK_COMPAS_DEMOGRAPHICDATA'';

V_STEP_SEQ := V_STEP_SEQ + 1;

V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());

V_ROWS_INSERTED := null;

V_ROWS_UPDATED := null;

V_ROWS_DELETED := null;

INSERT
    /*+ enable_parallel_dml APPEND */
    INTO BDR_DM.wrk_compas_demographicdata (
        insplan_billingbucket_id,
        household_id,
        insuredplan_id,
        individual_id,
        plan_cd,
        insuredplan_effectivedate,
        insuredplan_terminationdate,
        der_insuredplan_term_date,
        premium_dueamt,
        billingbucket_startdate,
        billingbucket_stopdate,
        der_billingbucket_stopdate,
        issue_state,
        issue_country_cd,
        issue_zip_cd,
        individual_profile_startdate,
        individual_profile_stopdate,
        gender_cd,
        date_of_birth,
        ipb_etl_lst_btch_id,
        ip_etl_lst_btch_id,
        ind_etl_lst_btch_id,
        bba_etl_lst_btch_id,
        cert_acqn_chnl_level3,
        termination_reason_name,
        conservation_reason_name,
        mbr_prem_amt,
        er_prem_amt,
        ret_typ_id,
        d_dscnt_annl_payr_sk,
        d_dscnt_erly_enrl_sk,
        d_dscnt_lngvty_sk,
        d_dscnt_multi_insd_sk,
        d_surchrg_tbcc_user_sk,
        d_surchrg_tier_sk,
        d_calc_rt_sk,
        rdc_id,
        smoker_ind,
        sale_chnl_lvl_1,
        sale_chnl_lvl_2,
        sale_chnl_lvl_3,
        d_new_to_medcr_sk
    )
SELECT
    /*+ parallel(8)  */
    ipb.ins_plan_billing_bucket_id,
    ipb.household_id,
    ipb.insured_plan_id,
    iip.individual_id,
    iip.plan_cd,
    iip.insured_plan_effective_date,
    iip.insured_plan_termination_date,
    CASE
        nvl(
            iip.insured_plan_termination_date,
            TO_DATE(''12/31/9999'', ''MM/DD/YYYY'')
        )
        WHEN TO_DATE(''12/31/9999'', ''MM/DD/YYYY'') THEN TO_DATE(''12/31/9999'', ''MM/DD/YYYY'')
        ELSE add_months(
            (
                trunc(iip.insured_plan_termination_date, ''month'')
            ),
            + 1
        )
    END AS derinsuredplanterminationdate,
    ipb.premium_due_amt + nvl(abs(sub.adjustment_amount), 0) AS premiumdueamt,
    ipb.billing_bucket_start_date,
    ipb.billing_bucket_stop_date,
    CASE
        WHEN (
            iip.insured_plan_termination_date BETWEEN ipb.billing_bucket_start_date
            AND ipb.billing_bucket_stop_date
            AND iip.insured_plan_termination_date IS NOT NULL
        ) THEN add_months(
            (
                trunc(iip.insured_plan_termination_date, ''month'')
            ),
            + 1
        )
        ELSE CASE
            WHEN add_months(
                (trunc(ipb.billing_bucket_stop_date, ''month'')),
                + 1
            ) = susp.individual_profile_startdate THEN susp.individual_profile_startdate
            ELSE ipb.billing_bucket_stop_date
        END
    END AS derbillingbucketstopdate,
    nvl(ha.state_cd, ''ZZ'') AS issuestate,
    nvl(ha.country_cd, ''ZZ'') AS issuecountrycd,
    nvl(ha.zip_cd, ''99999'') AS issuezipcd,
    susp.individual_profile_startdate,
    susp.individual_profile_stopdate,
    ind.gender_cd,
    ind.date_of_birth,
    ipb.etl_lst_btch_id AS ipblastbatchid,
    iip.etl_lst_btch_id AS ipetllastbatchid,
    ind.etl_lst_btch_id AS indetllastbatchid,
    sub.bba_etl_lst_btch_id AS bbaetllastbatchid,
    nvl(ipac.acquisitionchannel, ''UNKNOWN''),
    tr.termination_reason_name,
    cr.conservation_reason_name,
    ipb.premium_due_amt mbr_prem_amt,
    nvl(abs(sub.adjustment_amount), 0) AS er_prem_amt,
    nvl(rt.ret_typ_id, -1) AS ret_typ_id,
    CASE
        WHEN bba_ap.adjustment_type_id = 10 THEN 2
        ELSE 1
    END AS d_dscnt_annl_payr_sk,
    nvl(deed.d_dscnt_erly_enrl_sk, 1) AS d_dscnt_erly_enrl_sk,
    CASE
        WHEN bba_l.raw_adjustment_amount = 2 THEN 2
        WHEN bba_l.raw_adjustment_amount = 5 THEN 3
        ELSE 1
    END AS d_dscnt_lngvty_sk,
    CASE
        WHEN bba_mi.adjustment_type_id IN (
            3,
            13,
            15,
            16
        ) THEN 2
        WHEN bba_mi.adjustment_type_id IN (
            17
        ) THEN 3
        ELSE 1
    END AS d_dscnt_multi_insd_sk,
    -- Added Employer Multi Insured Discount
    CASE
        WHEN bba_tu.adjustment_type_id = 12 THEN 2
        ELSE 1
    END AS d_surchrg_tbcc_user_sk,
    nvl(dts.d_surchrg_tier_sk, 1) AS d_surchrg_tier_sk,
    nvl(dcr.d_calc_rt_sk, -1) AS d_calc_rt_sk,
    ccr.rdc_id rdc_id,
    -- SCR61587 28Jun2018
    ccr.smoker_ind,
    -- SCR61587 28Jun2018
    ipac1.sale_chnl_lvl_1,
    ipac1.sale_chnl_lvl_2,
    ipac1.sale_chnl_lvl_3,
    CASE
        WHEN bba_nt.adjustment_type_id = 18 THEN 2
        ELSE 1
    END AS d_new_to_medcr_sk
FROM
    SRC_COMPAS_D.ins_plan_billing_bucket ipb
    INNER JOIN SRC_COMPAS_D.insured_plan iip ON ipb.insured_plan_id = iip.insured_plan_id
    INNER JOIN SRC_COMPAS_D.individual ind ON iip.individual_id = ind.individual_id
    LEFT OUTER JOIN SRC_COMPAS_D.household_address ha ON ipb.household_id = ha.household_id
    AND (
        ha.address_type_id = 1
        AND nvl(ha.delete_ind, ''N'') = ''N''
    )
    AND iip.insured_plan_effective_date BETWEEN ha.hhold_addr_start_date
    AND ha.hhold_addr_stop_date
    LEFT OUTER JOIN BDR_DM.wrk_prem_bbaemp_subsidy sub ON ipb.ins_plan_billing_bucket_id = sub.insplan_billingbucket_id
    LEFT JOIN (
        SELECT
            DISTINCT susp.insuredplan_id,
            susp.individual_profile_startdate,
            susp.individual_profile_stopdate,
            ipb.billing_bucket_start_date sus_billing_bucket_start_date
        FROM
            BDR_DM.wrk_suspended_medsupp_plans susp
            INNER JOIN SRC_COMPAS_D.ins_plan_billing_bucket ipb ON ipb.insured_plan_id = susp.insuredplan_id
            AND (
                add_months(trunc(ipb.billing_bucket_stop_date, ''month''), + 1) = susp.individual_profile_startdate
                OR (
                    ipb.billing_bucket_start_date BETWEEN susp.individual_profile_startdate
                    AND susp.individual_profile_stopdate
                )
                OR ipb.billing_bucket_stop_date BETWEEN susp.individual_profile_startdate
                AND susp.individual_profile_stopdate
                OR (
                    ipb.billing_bucket_start_date <= susp.individual_profile_startdate
                    AND ipb.billing_bucket_stop_date >= susp.individual_profile_stopdate
                )
            )
            AND ipb.billing_bucket_stop_date >= :V_DEMOGRAPHIC_DATE
    ) susp ON iip.insured_plan_id = susp.insuredplan_id
    AND ipb.billing_bucket_start_date = susp.sus_billing_bucket_start_date
    LEFT JOIN BDR_DM.wrk_ipacquisitionchannel ipac ON iip.insured_plan_id = ipac.insuredplanid
    LEFT OUTER JOIN BDR_DM.wrk_ip_sale_channel ipac1 ON iip.insured_plan_id = ipac1.insuredplanid
    LEFT JOIN SRC_COMPAS_D.termination_reason tr ON iip.termination_reason_id = tr.termination_reason_id
    LEFT JOIN SRC_COMPAS_D.conservation_reason cr ON iip.conservation_reason_id = cr.conservation_reason_id
    LEFT JOIN BDR_CONF.d_ret_typ rt ON nvl(ind.subsidy_type_id, -2) = rt.ret_typ_id
    LEFT JOIN SRC_COMPAS_D.billing_bucket_adjustment bba_ap ON ipb.ins_plan_billing_bucket_id = bba_ap.ins_plan_billing_bucket_id
    AND bba_ap.adjustment_type_id IN (10)
    LEFT JOIN SRC_COMPAS_D.billing_bucket_adjustment bba_nt ON ipb.ins_plan_billing_bucket_id = bba_nt.ins_plan_billing_bucket_id
    AND bba_nt.adjustment_type_id IN (18) -- US105931 CA NTM 18
    LEFT JOIN SRC_COMPAS_D.billing_bucket_adjustment bba_mi ON ipb.ins_plan_billing_bucket_id = bba_mi.ins_plan_billing_bucket_id
    AND bba_mi.adjustment_type_id IN (
        3,
        13,
        15,
        16,
        17
    ) --Added Employer Multi Insured Discount
    --  LEFT JOIN SRC_COMPAS_D.ADJUSTMENT MIA
    --ON BBA_MI.ADJUSTMENT_ID = MIA.ADJUSTMENT_ID
    LEFT JOIN SRC_COMPAS_D.billing_bucket_adjustment bba_tu ON ipb.ins_plan_billing_bucket_id = bba_tu.ins_plan_billing_bucket_id
    AND bba_tu.adjustment_type_id = 12
    LEFT JOIN SRC_COMPAS_D.billing_bucket_adjustment bba_l ON ipb.ins_plan_billing_bucket_id = bba_l.ins_plan_billing_bucket_id
    AND bba_l.adjustment_type_id = 5
    LEFT JOIN SRC_COMPAS_D.billing_bucket_adjustment bba_ts ON ipb.ins_plan_billing_bucket_id = bba_ts.ins_plan_billing_bucket_id
    AND bba_ts.adjustment_type_id = 2
    LEFT JOIN SRC_COMPAS_D.adjustment a ON bba_ts.adjustment_id = a.adjustment_id
    LEFT JOIN BDR_DM.d_surchrg_tier dts ON a.rate_determination_code_id = dts.rt_dtrm_cd_id
    LEFT JOIN BDR_CONF.d_calc_rt dcr ON dcr.COMPAS_SRC_CALC_RT_ID = ipb.calculated_rate_id
    LEFT JOIN SRC_COMPAS_D.calculated_rate ccr -- SCR61587 28Jun2018
    ON ipb.calculated_rate_id = ccr.calculated_rate_id
    LEFT JOIN SRC_COMPAS_D.state_plan_billing spb ON ccr.state_plan_billing_id = spb.state_plan_billing_id
    LEFT JOIN SRC_COMPAS_D.billing_bucket_adjustment bba_eed ON ipb.ins_plan_billing_bucket_id = bba_eed.ins_plan_billing_bucket_id
    AND bba_eed.adjustment_type_id = 4
    LEFT JOIN SRC_COMPAS_D.adjustment adj ON bba_eed.adjustment_id = adj.adjustment_id
    LEFT JOIN BDR_DM.d_dscnt_erly_enrl deed ON adj.loyalty_program_id = deed.dscnt_erly_enrl_pgm_id
    AND adj.loyalty_year = deed.dscnt_erly_enrl_yr
    AND adj.adjustment_amount = deed.dscnt_erly_enrl_adj_amt
    AND deed.dscnt_erly_enrl_st_cd = (
        CASE
            WHEN spb.state_cd = ''WI''
            AND dscnt_erly_enrl_pgm_id = 21 THEN spb.state_cd
            ELSE ''ED''
        END
    )
WHERE
    billing_bucket_stop_date >= :V_DEMOGRAPHIC_DATE
    AND nvl(
        iip.insured_plan_termination_date,
        TO_DATE(''12/31/9999'', ''MM/DD/YYYY'')
    ) >= billing_bucket_start_date;



V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );


INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

CALL UTIL.SP_ETL_CHECK_CONSTRAINTS(:DB_NAME , :APPLICATION , :WORKFLOW_NAME , :OBJECT_NAME , :V_BATCH_ID );


UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''COMPLETE'', ERROR_MSG = null, BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
; 


UPDATE  UTIL.ETL_BATCH_OBJECT_INCR_VALU SET INCR_COLUMN_VALUE = :V_BATCH_ID, LST_MOD_DT = CURRENT_TIMESTAMP() WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID''; 

EXCEPTION

WHEN OTHER THEN



UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''ERROR'', ERROR_MSG = :SQLERRM,  BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
;

INSERT INTO  UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ERROR_MSG, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''ERROR'', :V_STEP_NAME, :V_STEP_SEQ, :SQLERRM, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() )
;

RAISE;

END;

';