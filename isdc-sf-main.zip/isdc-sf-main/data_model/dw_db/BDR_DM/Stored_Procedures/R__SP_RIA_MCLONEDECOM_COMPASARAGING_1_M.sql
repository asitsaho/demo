USE SCHEMA BDR_DM; CREATE OR REPLACE PROCEDURE "SP_RIA_MCLONEDECOM_COMPASARAGING_1_M"("DB_NAME" VARCHAR(16777216), "APPLICATION" VARCHAR(16777216), "WORKFLOW_NAME" VARCHAR(16777216), "OBJECT_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '

-- Original workflow: wkf_RIA_MCloneDecom_CompasARAging_M
-- Original mapping: m_RIA_MCloneDecom_CompasARAging_1_M
-- Original folder: Compas_Reports
-- Original filename: wkf_RIA_MCloneDecom_CompasARAging_M.XML

DECLARE


V_ROWS_INSERTED  INTEGER;
V_ROWS_UPDATED INTEGER;
V_ROWS_DELETED INTEGER;
V_LAST_QUERY_ID VARCHAR;

V_WH VARCHAR;
V_BATCH_ID INTEGER;


V_BATCH_OBJECT_START_TIME        VARCHAR;
V_STEP_START_TIME    VARCHAR;
V_STEP_NAME VARCHAR;
V_STEP_SEQ INTEGER DEFAULT 0;
V_ETL_LST_BTCH_ID INTEGER;

v_report_date     TIMESTAMP;
v_delinquent_date TIMESTAMP;
V_DAY INTEGER;

lv_n_count NUMBER := 0;
lv_y_count NUMBER := 0;
lv_completed_ind VARCHAR;

v_current_month_premium     NUMBER(38, 2) := 0;
v_two_month_prior_premium   NUMBER(38, 2) := 0;
v_three_month_prior_premium NUMBER(38, 2) := 0;
v_four_month_prior_premium  NUMBER(38, 2) := 0;
v_five_month_prior_premium  NUMBER(38, 2) := 0;
v_six_month_prior_premium   NUMBER(38, 2) := 0;
v_one_month_prior_premium   NUMBER(38, 2) := 0;
v_delinquent_premium        NUMBER(38, 2) := 0;


BEGIN

EXECUTE IMMEDIATE ''USE DATABASE ''||:DB_NAME; 

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_BATCH_OBJECT_START_TIME := (SELECT CURRENT_TIMESTAMP());



LET res1 RESULTSET := 
(

SELECT 

WH ,
BATCH_ID
  
FROM UTIL.ETL_BATCH_OBJECT_CONTROL
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
FETCH FIRST 1 ROW ONLY

)
;


LET C1 CURSOR FOR res1;
open C1;
FETCH C1 into  V_WH,V_BATCH_ID ;
close C1;


LET res2 RESULTSET := 

(

WITH PARAMETERS (DAY) AS
(
  
SELECT * 
FROM  
(SELECT PARAMETER_NAME, PARAMETER_VALUE  FROM UTIL.ETL_OBJECT_PARAMETER_VALUE 
WHERE 1 = 1
AND APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
AND ACTIVE_FLG = ''Y''  
  
UNION ALL       

SELECT PARAMETER_NAME, PARAMETER_VALUE  FROM UTIL.ETL_GLOBAL_PARAMETER_VALUE WHERE PAR_GLOBAL_TYPE = ''PARGLOBAL_OPREPORTS'' AND ACTIVE_FLG = ''Y''
AND PARAMETER_NAME NOT IN  (
SELECT PARAMETER_NAME  FROM UTIL.ETL_OBJECT_PARAMETER_VALUE WHERE 1 = 1
AND APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
AND ACTIVE_FLG = ''Y''   ))
 
PIVOT(MAX(PARAMETER_VALUE) FOR PARAMETER_NAME IN (''DAY'')) 

 
)  
SELECT * FROM PARAMETERS 
)   
;


LET C2 CURSOR FOR res2;
open C2;
FETCH C2 into V_DAY; 
close C2;



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:V_WH;
USE SCHEMA BDR_DM;	------------OAS ADD


INSERT INTO UTIL.ETL_BATCH_OBJECT_INCR_VALU (APPLICATION, WORKFLOW_NAME, OBJECT_NAME, INCR_COLUMN, INCR_COLUMN_VALUE )
SELECT * FROM (select :APPLICATION AS APPLICATION, :WORKFLOW_NAME AS WORKFLOW_NAME, :OBJECT_NAME AS OBJECT_NAME, ''ETL_LST_BTCH_ID'' AS INCR_COLUMN, -1 AS INCR_COLUMN_VALUE) A
WHERE NOT EXISTS (SELECT 1 FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU B WHERE B.APPLICATION = A.APPLICATION AND B.WORKFLOW_NAME = A.WORKFLOW_NAME AND B.OBJECT_NAME = A.OBJECT_NAME AND B.INCR_COLUMN = A.INCR_COLUMN)
;

V_ETL_LST_BTCH_ID :=(SELECT INCR_COLUMN_VALUE FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID'');


						----------------CODE FOR MAIN PROCEDURE ETL.SP_ETL_MCLONE_DECOM_M BEGINS------------------------

--------COMMENTED BY OAS--------
/*
CREATE OR REPLACE PROCEDURE ETL."SP_ETL_MCLONE_DECOM_M"(
    p_etlname IN VARCHAR2,
    p_etlseq  IN NUMBER,
    p_tocontinuestatus OUT VARCHAR2,
    p_errorynflg OUT VARCHAR2,
    p_errorstr OUT VARCHAR2)
AS

BEGIN

		SELECT MIN(proc_launch_order)			------RESULT WILL BE 1
          INTO lv_min_order
          FROM ETL.ETL_MCLONE_DECOM_PROC_LIST
          WHERE etl_name = p_etlname	-----''COMPAS_AR_AGING''
          AND etl_seq    = p_etlseq		-----1
          AND active_ind = ''Y'';
		

          SELECT MAX(proc_launch_order)		----------2
          INTO lv_max_order
          FROM ETL.ETL_MCLONE_DECOM_PROC_LIST
          WHERE etl_name = p_etlname	-----''COMPAS_AR_AGING''
          AND etl_seq    = p_etlseq		-----1
          AND active_ind = ''Y'';

          SELECT MAX(batch_id)
          INTO lv_batch_id
          FROM etl.etl_batch_log
          WHERE application = ''COMPAS_REPORTS''
          AND batch_status != ''COMPLETE'';

          UPDATE ETL.ETL_MCLONE_DECOM_PROC_LIST
          SET batch_id   = lv_batch_id
          WHERE etl_name = p_etlname
          AND etl_seq    = p_etlseq
          AND active_ind = ''Y'';
          COMMIT;

          --Find Next Row to Process
          WHILE lv_min_order < (lv_max_order + 1 )		-----------1< 2+1 for 1st iteration,  2<2+1 for next iteration --- 
          LOOP

                    --dbms_output.put_line(''Min Loop Start'' || lv_min_order);
                    --dbms_output.put_line(''Max Loop Start'' || lv_max_order);

                    lv_next_rec_found      := ''Y'';

                    WHILE lv_next_rec_found = ''Y''
                    LOOP
                              BEGIN
                                      lv_proc_name := NULL;

                                      -- Get the Proc Name
                                      SELECT proc_name,
                                        batch_id		
                                      INTO lv_proc_name,	
                                        lv_batch_id
                                      FROM
                                        (SELECT proc_name,
                                          batch_id
                                        FROM ETL.ETL_MCLONE_DECOM_PROC_LIST
                                        WHERE run_status      in (''READY'',''ERROR'')
                                        AND proc_launch_order = lv_min_order	--------------1 for 1st iteration, 2 for next iteration
                                        AND active_ind = ''Y''
                                        )
                                      WHERE ROWNUM = 1;

                                      --Proc Found
                                      IF lv_proc_name IS NOT NULL THEN

                                                SELECT SYSDATE INTO lv_etl_start_time FROM dual;

                                                UPDATE ETL.ETL_MCLONE_DECOM_PROC_LIST
                                                SET run_status        = ''INPROCESS'',
                                                  etl_start_time      = lv_etl_start_time
                                                WHERE batch_id        = lv_batch_id
                                                AND proc_name         = lv_proc_name
                                                AND proc_launch_order = lv_min_order;

                                                --Continue, if no records updated
                                                lv_row_aff_by_upd   := SQL % rowcount;

                                                IF lv_row_aff_by_upd = 0 THEN
                                                  ROLLBACK;
                                                  CONTINUE;
                                                ELSE
                                                  COMMIT;
                                                END IF;
                                      END IF;

                                      --Execute Procedure
                                      BEGIN
                                                lv_proc_final := ''begin '' || lv_proc_name || '' end;'';

                                                EXECUTE IMMEDIATE (lv_proc_final);		-------OAS - FOR 1ST ITERATION IT WILL CALL COMPAS_MO.SP_RIA_AR_AGING_PREP();
*/
--------COMMENTED BY OAS--------

									-------------1ST ITERATION OF WHILE LOOP - CODE FOR COMPAS_MO.SP_RIA_AR_AGING_PREP(); BEGINS---------------

--------COMMENTED BY OAS--------
		/*
		CREATE OR REPLACE procedure COMPAS_MO.SP_RIA_AR_AGING_PREP
		as
		V_ERROR NUMBER;
		BEGIN
		COMPAS_MO.PKG_RIA_ADW_AR_AGING_REPORT.PR_ADW_AR_AGING_PREP(V_ERROR);
		*/
		--------COMMENTED BY OAS--------
		
								-------------CODE FOR COMPAS_MO.PKG_RIA_ADW_AR_AGING_REPORT.PR_ADW_AR_AGING_PREP(); BEGINS---------------
		
		--------COMMENTED BY OAS--------
		/*						
		PROCEDURE pr_adw_ar_aging_prep (
				p_error       OUT NUMBER )
		IS
		
		v_report_date           DATE;
		v_delinquent_date       DATE;
		v_job                   NUMBER;
		v_what                  VARCHAR2(100);
		
		v_any_jobs              NUMBER;
		
		v_ddl_exception         EXCEPTION;
		
		BEGIN
		
			p_error := 0; -- SUCCESS
		
		
			/* The report date is the end of the month. The delinquent date is the 1st of the month.
			The delinquent date in ar_RIA_aging_adw_summary is the report_date.
			*/
		
			--v_report_date := COMPAS_MO.fn_get_last_day_of_month;		-----------OAS DELETE
			
			/* 						-------------CODE FOR FUNCTION - COMPAS_MO.fn_get_last_day_of_month BEGINS---------------
			
			create or replace FUNCTION           fn_get_last_day_of_month RETURN DATE
			IS
			v_last_day DATE;
			v_current_user VARCHAR2(30);
			v_day NUMBER;
			BEGIN
			SELECT UPPER(sys_context(''USERENV'',''SESSION_USER'')) into v_current_user from dual;
			SELECT metadata_value into v_day from etl.etl_application_metadata where application = ''COMPAS_REPORTS''  and metadata_type = ''REPORT_MONTH_DAYVALUE'';
			IF v_current_user = ''MSOAREAD'' THEN
				v_last_day := LAST_DAY(ADD_MONTHS(SYSDATE, -1));
			ELSE
				IF extract ( day FROM SYSDATE) <= v_day THEN
				v_last_day := LAST_DAY(ADD_MONTHS(SYSDATE, -1));
			ELSE
				v_last_day := LAST_DAY(SYSDATE);
				END IF ;
			END IF;
			RETURN TRUNC(v_last_day);
			
			END;
			*/	
									-------------CODE FOR FUNCTION - COMPAS_MO.fn_get_last_day_of_month; ENDS---------------
			
			v_report_date := (SELECT TRUNC(TO_TIMESTAMP(CASE WHEN extract(day FROM CURRENT_TIMESTAMP) <= :V_DAY THEN
								LAST_DAY(ADD_MONTHS(CURRENT_TIMESTAMP, -1))
							ELSE
								LAST_DAY(CURRENT_TIMESTAMP) END), ''DD''));
		
			--temporarily assign to report date for the delete performed on the summary table
			--v_delinquent_date := TRUNC(:v_report_date, ''DD'');	--OAS DELETE
		
			V_STEP_NAME    := ''DELETE - AR_RIA_AGING_ADW_SUMMARY'';
			V_STEP_SEQ     :=  V_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;
			
				DELETE FROM BDR_DM.ar_RIA_aging_adw_summary
				WHERE  delinquent_date = TRUNC(:v_report_date, ''DD'');
					
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;
			
			V_ROWS_DELETED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );
			
			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );
		
			-- Get the 1st of the month
			v_delinquent_date := (SELECT DATEADD(''DD'', 1, LAST_DAY(ADD_MONTHS(TRUNC(:v_report_date, ''DD''), -1))));
		
			--EXECUTE IMMEDIATE '' TRUNCATE TABLE ar_aging_adw_summary_stage '';
		
		--------COMMENTED BY OAS-------- 
		/*
			p_error := COMPAS_MO.truncate_table(''AR_RIA_AGING_ADW_SUMMARY_STAGE'');
			IF (p_error <> 0) THEN
			RAISE v_ddl_exception;
			END IF;
		
		*/
		--------COMMENTED BY OAS--------
		
			V_STEP_NAME    := ''TRUNCATE - AR_RIA_AGING_ADW_SUMMARY_STAGE'';
			V_STEP_SEQ     :=  V_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;
			
			TRUNCATE TABLE BDR_DM.AR_RIA_AGING_ADW_SUMMARY_STAGE;
			
			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );
		
			-- pr_populate_ppo_stage;		------------OAS DELETE
			
								-------------CODE FOR pr_populate_ppo_stage BEGINS---------------
		--------COMMENTED BY OAS--------
		/*
			PROCEDURE pr_populate_ppo_stage
			IS
			
			p_ddl_error             NUMBER := 0;
			v_ddl_exception         EXCEPTION;
			
			BEGIN
			
				--EXECUTE IMMEDIATE ''TRUNCATE TABLE ar_ppo_stage'';
				p_ddl_error := COMPAS_MO.truncate_table(''ar_RIA_ppo_stage'');
			
				IF p_ddl_error <> 0 THEN
				RAISE v_ddl_exception;
				END IF;
		*/
		--------COMMENTED BY OAS-------- 
			
			V_STEP_NAME    := ''TRUNCATE - AR_RIA_PPO_STAGE'';
			V_STEP_SEQ     :=  V_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;
			
				TRUNCATE TABLE BDR_DM.AR_RIA_PPO_STAGE;
			
			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );
			
			V_STEP_NAME    := ''INSERT - AR_RIA_PPO_STAGE'';
			V_STEP_SEQ     :=  V_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;
			
				INSERT INTO BDR_DM.AR_RIA_PPO_STAGE
				SELECT  DISTINCT hm.individual_id
				FROM    SRC_COMPAS_M.plan_type pt, SRC_COMPAS_M.PLAN p, SRC_COMPAS_M.insured_plan ip, SRC_COMPAS_M.household_member hm
				WHERE   pt.plan_category_id = 4
				AND     p.plan_type_id = pt.plan_type_id
				AND     ip.plan_cd = p.plan_cd
				AND     hm.individual_id = ip.individual_id;
					
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;
			
			V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );
			
			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );
		
		--------COMMENTED BY OAS--------
		/*
				COMMIT;
			
				-- EXECUTE IMMEDIATE ''ANALYZE TABLE ar_ppo_stage COMPUTE STATISTICS '';
				COMPAS_MO.PR_GATHER_TABLE_STATS(''COMPAS_MO'', ''ar_RIA_ppo_stage'');
			
			EXCEPTION
				WHEN v_ddl_exception THEN
				RAISE;
			END;
		*/
		--------COMMENTED BY OAS--------
								-------------CODE FOR pr_populate_ppo_stage ENDS---------------
								
			/* This part assumes that the ar_staging table is divided into 10 partations
			Each partition is named AR_PART(n) */
		
		
			V_STEP_NAME    := ''INSERT - AR_RIA_AGING_ADW_SUMMARY_STAGE'';
			V_STEP_SEQ     :=  V_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;
			
					INSERT INTO BDR_DM.AR_RIA_AGING_ADW_SUMMARY_STAGE  ( job_id, report_date, delinquent_date, completed_ind, status )
					VALUES ( 1, trunc(:v_report_date, ''DD''), :v_delinquent_date, ''N'', ''Not Started'' );
					
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;
			
			V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );
			
			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );
		
		--------COMMENTED BY OAS--------
		/*
				COMMIT;
			
			
			EXCEPTION
				WHEN v_ddl_exception THEN
				RAISE;
				WHEN OTHERS THEN
				p_error := SQLCODE;
			
			
			END pr_adw_ar_aging_prep;
							-------------CODE FOR COMPAS_MO.PKG_RIA_ADW_AR_AGING_REPORT.PR_ADW_AR_AGING_PREP(); ENDS---------------
			END;
			/
		*/
		--------COMMENTED BY OAS--------
							-------------1ST ITERATION OF WHILE LOOP - CODE FOR COMPAS_MO.SP_RIA_AR_AGING_PREP(); ENDS---------------
								
						
						
						
						-------------2ND ITERATION OF WHILE LOOP - CODE FOR COMPAS_MO.SP_RIA_COMPAS_ARAGING_DELINQ_PART(); BEGINS---------------
		--------COMMENTED BY OAS--------	
		/*
		CREATE OR REPLACE PROCEDURE COMPAS_MO.SP_RIA_COMPAS_ARAGING_DELINQ_PART
		AS
		jno NUMBER;
		lv_n_count NUMBER := 0;
		lv_y_count NUMBER := 0;
		lv_completed_ind VARCHAR2(1);
		BEGIN
		*/
		--------COMMENTED BY OAS--------

			SELECT COUNT(*) INTO lv_n_count FROM BDR_DM.ar_ria_aging_adw_summary_stage
			where completed_ind = ''N'';
			
			begin
					select distinct completed_ind
					into lv_completed_ind
					from BDR_DM.ar_ria_aging_adw_summary_stage
					where job_id = 1;
					
					IF ((:lv_completed_ind is null) or (:lv_completed_ind = ''Y'')) THEN
						NULL;
					ELSE
					BEGIN
						--SYS.DBMS_JOB.SUBMIT(JNO,''COMPAS_MO.PKG_RIA_ADW_AR_AGING_REPORT.PR_CALC_DELINQUENT_JOB(1);'',SYSDATE, NULL);
						
						--COMPAS_MO.PKG_RIA_ADW_AR_AGING_REPORT.PR_CALC_DELINQUENT_JOB(1);		--------OAS DELETE
						
					-------------CODE FOR COMPAS_MO.PKG_RIA_ADW_AR_AGING_REPORT.PR_CALC_DELINQUENT_JOB BEGINS---------------
					
					--------COMMENTED BY OAS--------
					/*
						PROCEDURE pr_calc_delinquent_job ( p_job_id IN NUMBER )
						IS
						
							v_delinquent_date              DATE;
							
							v_current_month_premium        NUMBER := 0;
							v_one_month_prior_premium      NUMBER := 0;
							v_two_month_prior_premium      NUMBER := 0;
							v_three_month_prior_premium    NUMBER := 0;
							v_four_month_prior_premium     NUMBER := 0;
							v_five_month_prior_premium     NUMBER := 0;
							v_six_month_prior_premium      NUMBER := 0;
							
							v_delinquent_premium           NUMBER := 0;
							
							v_partition                    VARCHAR2(30);
							p_results                      sys_refcursor;
							
							BEGIN
						*/
						--------COMMENTED BY OAS--------
										
							V_STEP_NAME    := ''UPDATE - AR_RIA_AGING_ADW_SUMMARY_STAGE'';
							V_STEP_SEQ     :=  V_STEP_SEQ+1;
							V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
							V_ROWS_INSERTED := null;
							V_ROWS_UPDATED := null;
							V_ROWS_DELETED := null;

							UPDATE BDR_DM.AR_RIA_AGING_ADW_SUMMARY_STAGE
							SET    status = ''In the procedure 0 of 7''
							WHERE  job_id = 1;
							--COMMIT;
						
							V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;
							
							V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );
							
							INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
							VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );
											
							V_STEP_NAME    := ''UPDATE - AR_RIA_AGING_ADW_SUMMARY_STAGE'';
							V_STEP_SEQ     :=  V_STEP_SEQ+1;
							V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
							V_ROWS_INSERTED := null;
							V_ROWS_UPDATED := null;
							V_ROWS_DELETED := null;
					
							-- Get the Delinquent date for which this job is to be run
							SELECT delinquent_date
							INTO   v_delinquent_date
							FROM   BDR_DM.AR_RIA_AGING_ADW_SUMMARY_STAGE
							WHERE  job_id = 1 ;
						
							-- Derive the partition name
							--v_partition := ''AR_PART'' || TO_CHAR(p_job_id);	---OAS DELETE -- NOT NEEDED
						
							UPDATE BDR_DM.AR_RIA_AGING_ADW_SUMMARY_STAGE
							SET    --partition_name = v_partition,		---OAS DELETE -- NOT NEEDED
									status = ''Started Current Month Calculation 1 of 7''
							WHERE  job_id = 1;
							--COMMIT;
											
							V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;
							
							V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );
							
							INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
							VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );
																
							V_STEP_NAME    := ''UPDATE - AR_RIA_AGING_ADW_SUMMARY_STAGE'';
							V_STEP_SEQ     :=  V_STEP_SEQ+1;
							V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
							V_ROWS_INSERTED := null;
							V_ROWS_UPDATED := null;
							V_ROWS_DELETED := null;
	
							-- Get the Current months premium
							v_current_month_premium := BDR_DM.fn_query_delinquents (
									p_delinquent_date   => :v_delinquent_date,
						--           p_partition         => v_partition,  -- AOP De-Scope
									p_date_clause       => ''='');
						
							v_delinquent_premium := BDR_DM.fn_query_ppo_delinquents (
									p_delinquent_date   => :v_delinquent_date
						--           p_partition         => v_partition   -- AOP De-Scope
									);
						
							UPDATE BDR_DM.AR_RIA_AGING_ADW_SUMMARY_STAGE
							SET    premium_current_month = :v_current_month_premium,
									ppo_current_month = :v_delinquent_premium,
									status = ''Started One Month Calculation 2/7''
							WHERE  job_id = 1;
							--COMMIT;
											
							V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;
							
							V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );
							
							INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
							VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );
																
							V_STEP_NAME    := ''UPDATE - AR_RIA_AGING_ADW_SUMMARY_STAGE'';
							V_STEP_SEQ     :=  V_STEP_SEQ+1;
							V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
							V_ROWS_INSERTED := null;
							V_ROWS_UPDATED := null;
							V_ROWS_DELETED := null;
						
							-- Get the Prior one months premium
							v_one_month_prior_premium := BDR_DM.fn_query_delinquents (
									p_delinquent_date   => ADD_MONTHS(:v_delinquent_date,-1),
						--           p_partition         => v_partition,  -- AOP De-Scope
									p_date_clause       => ''='');
						
							v_delinquent_premium := BDR_DM.fn_query_ppo_delinquents (
									p_delinquent_date   => ADD_MONTHS(:v_delinquent_date,-1)
						--           p_partition         => v_partition  -- AOP De-Scope
									);
						
							UPDATE BDR_DM.AR_RIA_AGING_ADW_SUMMARY_STAGE
							SET    premium_prior_one_month = :v_one_month_prior_premium,
									ppo_prior_one_month = :v_delinquent_premium,
									status = ''Started Two Month Calculation 3 of 7''
							WHERE  job_id = 1;
							--COMMIT;
												
							V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;
							
							V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );
							
							INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
							VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );
															
							V_STEP_NAME    := ''UPDATE - AR_RIA_AGING_ADW_SUMMARY_STAGE'';
							V_STEP_SEQ     :=  V_STEP_SEQ+1;
							V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
							V_ROWS_INSERTED := null;
							V_ROWS_UPDATED := null;
							V_ROWS_DELETED := null;
	
							-- Get the Prior two months premium
							v_two_month_prior_premium := BDR_DM.fn_query_delinquents (
									p_delinquent_date   => ADD_MONTHS(:v_delinquent_date,-2),
						--           p_partition         => v_partition,  -- AOP De-Scope
									p_date_clause       => ''='');
						
							v_delinquent_premium := BDR_DM.fn_query_ppo_delinquents (
									p_delinquent_date   => ADD_MONTHS(:v_delinquent_date,-2)
						--           p_partition         => v_partition -- AOP De-Scope
									);
						
							UPDATE BDR_DM.AR_RIA_AGING_ADW_SUMMARY_STAGE
							SET    premium_prior_two_month = :v_two_month_prior_premium,
									ppo_prior_two_month = :v_delinquent_premium,
									status = ''Started Three Month Calculation 4 of 7''
							WHERE  job_id = 1;
							--COMMIT;
													
							V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;
							
							V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );
							
							INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
							VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );
															
							V_STEP_NAME    := ''UPDATE - AR_RIA_AGING_ADW_SUMMARY_STAGE'';
							V_STEP_SEQ     :=  V_STEP_SEQ+1;
							V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
							V_ROWS_INSERTED := null;
							V_ROWS_UPDATED := null;
							V_ROWS_DELETED := null;
						
							-- Get the Prior three months premium
							v_three_month_prior_premium := BDR_DM.fn_query_delinquents (
									p_delinquent_date   => ADD_MONTHS(:v_delinquent_date,-3),
						--           p_partition         => v_partition,  -- AOP De-Scope
									p_date_clause       => ''='');
						
						
							v_delinquent_premium := BDR_DM.fn_query_ppo_delinquents (
									p_delinquent_date   => ADD_MONTHS(:v_delinquent_date,-3)
						--           p_partition         => v_partition  -- AOP De-Scope
									);
						
						
							UPDATE BDR_DM.AR_RIA_AGING_ADW_SUMMARY_STAGE
							SET    premium_prior_three_month = :v_three_month_prior_premium,
									ppo_prior_three_month = :v_delinquent_premium,
									status = ''Started Four Month Calculation 5 of 7''
							WHERE  job_id = 1;
							--COMMIT;
												
							V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;
							
							V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );
							
							INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
							VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );
						
																
							V_STEP_NAME    := ''UPDATE - AR_RIA_AGING_ADW_SUMMARY_STAGE'';
							V_STEP_SEQ     :=  V_STEP_SEQ+1;
							V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
							V_ROWS_INSERTED := null;
							V_ROWS_UPDATED := null;
							V_ROWS_DELETED := null;

							-- Get the Prior four  months premium
							v_four_month_prior_premium := BDR_DM.fn_query_delinquents (
									p_delinquent_date   => ADD_MONTHS(:v_delinquent_date,-4),
						--           p_partition         => v_partition,  -- AOP De-Scope
									p_date_clause       => ''='');
						
						
							v_delinquent_premium := BDR_DM.fn_query_ppo_delinquents (
									p_delinquent_date   => ADD_MONTHS(:v_delinquent_date,-4)
						--           p_partition         => v_partition  -- AOP De-Scope
									);
						
						
							UPDATE BDR_DM.AR_RIA_AGING_ADW_SUMMARY_STAGE
							SET    premium_prior_four_month = :v_four_month_prior_premium,
									ppo_prior_four_month = :v_delinquent_premium,
									status = ''Started Five Month Calculation 6 of 7''
							WHERE  job_id = 1;
							--COMMIT;
													
							V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;
							
							V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );
							
							INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
							VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );
															
							V_STEP_NAME    := ''UPDATE - AR_RIA_AGING_ADW_SUMMARY_STAGE'';
							V_STEP_SEQ     :=  V_STEP_SEQ+1;
							V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
							V_ROWS_INSERTED := null;
							V_ROWS_UPDATED := null;
							V_ROWS_DELETED := null;

							-- Get the Prior five months premium
							v_five_month_prior_premium := BDR_DM.fn_query_delinquents (
									p_delinquent_date   => ADD_MONTHS(:v_delinquent_date,-5),
						--           p_partition         => v_partition,  -- AOP De-Scope
									p_date_clause       => ''='');
						
						
							v_delinquent_premium := BDR_DM.fn_query_ppo_delinquents (
									p_delinquent_date   => ADD_MONTHS(:v_delinquent_date,-5)
						--           p_partition         => v_partition  -- AOP De-Scope
									);
						
						
							UPDATE BDR_DM.AR_RIA_AGING_ADW_SUMMARY_STAGE
							SET    premium_prior_five_month = :v_five_month_prior_premium,
									ppo_prior_five_month = :v_delinquent_premium,
									status = ''Started Six Month Calculation 7 of 7''
							WHERE  job_id = 1;
							--COMMIT;
													
							V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;
							
							V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );
							
							INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
							VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );
															
							V_STEP_NAME    := ''UPDATE - AR_RIA_AGING_ADW_SUMMARY_STAGE'';
							V_STEP_SEQ     :=  V_STEP_SEQ+1;
							V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
							V_ROWS_INSERTED := null;
							V_ROWS_UPDATED := null;
							V_ROWS_DELETED := null;

							-- Get the Prior six months premium
							v_six_month_prior_premium := BDR_DM.fn_query_delinquents (
									p_delinquent_date   => ADD_MONTHS(:v_delinquent_date,-6),
						--           p_partition         => v_partition,  -- AOP De-Scope
									p_date_clause       => ''<='');
						
						
							v_delinquent_premium := BDR_DM.fn_query_early_ppo_delinquents (
									p_delinquent_date   => ADD_MONTHS(:v_delinquent_date,-6)
						--           p_partition         => v_partition  -- AOP De-Scope
									);
						
						
							UPDATE BDR_DM.AR_RIA_AGING_ADW_SUMMARY_STAGE
							SET    premium_prior_six_month = :v_six_month_prior_premium,
									ppo_prior_six_month = :v_delinquent_premium,
									status = ''Done'',
									completed_ind = ''Y''
							WHERE  job_id = 1;
							--COMMIT;
												
							V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;
							
							V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );
							
							INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
							VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );
						
							--COMMIT;
						
						EXCEPTION
								WHEN other THEN
																		
									V_STEP_NAME    := ''UPDATE - AR_RIA_AGING_ADW_SUMMARY_STAGE'';
									V_STEP_SEQ     :=  V_STEP_SEQ+1;
									V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
									V_ROWS_INSERTED := null;
									V_ROWS_UPDATED := null;
									V_ROWS_DELETED := null;

									UPDATE BDR_DM.AR_RIA_AGING_ADW_SUMMARY_STAGE
									SET    completed_ind = ''E''
									WHERE  job_id = 1;
												
									V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;
									
									V_ROWS_UPDATED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );
									
									INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
									VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );
						
									/*COMMIT;
						
									IF p_results%ISOPEN THEN
										CLOSE p_results;
									END IF;
						
						END pr_calc_delinquent_job;
						
					-------------CODE FOR COMPAS_MO.PKG_RIA_ADW_AR_AGING_REPORT.PR_CALC_DELINQUENT_JOB ENDS---------------	
					
						COMMIT;	*/		--------OAS DELETE
						END;
					end if;
					/*exception when no_data_found
					then null;*/		--------OAS DELETE
			end;
		
		
		LOOP
			SELECT COUNT(*) INTO lv_y_count FROM BDR_DM.ar_ria_aging_adw_summary_stage
			where completed_ind = ''Y'';
			IF ((:lv_y_count = :lv_n_count) or (:lv_y_count > :lv_n_count)) THEN
				BREAK;
			END IF;
		END LOOP;
		---------------COMMENTED BY OAS-----------------
		/*
		END;
		/
		-------------2ND ITERATION OF WHILE LOOP - CODE FOR COMPAS_MO.SP_RIA_COMPAS_ARAGING_DELINQ_PART(); ENDS---------------	
		
		
                                                EXCEPTION
                                                WHEN OTHERS THEN

                                                        lv_error_msg := SUBSTR(SQLERRM, 1, 250);
                                                        SELECT SYSDATE INTO lv_etl_end_time FROM dual;

                                                        UPDATE ETL.ETL_MCLONE_DECOM_PROC_LIST
                                                        SET run_status  = ''ERROR'',
                                                          etl_end_time  = lv_etl_end_time,
                                                          etl_error_msg = lv_error_msg
                                                        WHERE proc_name = lv_proc_name;
                                                        COMMIT;

                                                        SELECT SYSDATE INTO lv_etl_end_time FROM dual;

                                                        UPDATE ETL.ETL_MCLONE_DECOM_PROC_LIST
                                                        SET etl_time_taken = round((cast(etl_end_time as date) - cast(etl_start_time as date)) * 24 * 60 * 60)
                                                        WHERE proc_name    = lv_proc_name;

                                                        COMMIT;

                                                        lv_exception := ''Y'';
                                                        RAISE;
                                      END;

                                      IF lv_exception = ''Y'' THEN
                                      --DBMS_OUTPUT.PUT_LINE(''lv_exception'');
                                        EXIT;
                                      END IF;

                                      SELECT SYSDATE INTO lv_etl_end_time FROM dual;

                                      UPDATE ETL.ETL_MCLONE_DECOM_PROC_LIST
                                      SET run_status  = ''COMPLETE'',
                                      etl_end_time  = lv_etl_end_time
                                      WHERE proc_name = lv_proc_name;

                                      COMMIT;

                                      UPDATE ETL.ETL_MCLONE_DECOM_PROC_LIST
                                      SET etl_time_taken = round((cast(etl_end_time as date) - cast(etl_start_time as date)) * 24 * 60 * 60)
                                      WHERE proc_name    = lv_proc_name;

                                      COMMIT;


                              END;
                              BEGIN

                                        SELECT proc_name
                                        INTO lv_proc_name
                                        FROM
                                        (SELECT proc_name
                                        FROM ETL.ETL_MCLONE_DECOM_PROC_LIST
                                        WHERE run_status      IN (''READY'',''ERROR'')
                                        AND proc_launch_order = lv_min_order
                                        AND active_ind = ''Y''
                                        )
                                        WHERE ROWNUM = 1;

                                        EXCEPTION WHEN NO_DATA_FOUND THEN
                                        lv_next_rec_found := ''N'';
                                        --dbms_output.put_line(''Exception'');
                              END;

                              --lv_proc_final := '''';
                              --lv_proc_name := '''';
                    END LOOP;

                    SELECT LISTAGG(run_status , '''') WITHIN GROUP (
                    ORDER BY run_status)
                    INTO lv_flag
                    FROM
                      (SELECT DISTINCT run_status
                      FROM ETL.ETL_MCLONE_DECOM_PROC_LIST
                      WHERE proc_launch_order = lv_min_order
                      AND active_ind = ''Y''
                      );

                    IF lv_flag      = ''COMPLETE'' OR (lv_min_order = lv_max_order) THEN
                      lv_min_order := lv_min_order + 1;		--------------------8+1 => WILL GO FOR 2ND ITERATION, 9+1 => FALSE FOR NEXT ITERATION
                    END IF;

          END LOOP;

          --Returns the result set
          P_ToContinueStatus := ''Y'';
          P_ErrorYNFlg       := ''N'';
          P_ErrorStr         := '''';

          EXCEPTION WHEN OTHERS THEN
            P_ErrorStr         := ''ERROR: '' || SQLCODE || ''-'' || SQLERRM || ''-'' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE()|| Chr(10)||DBMS_UTILITY.FORMAT_ERROR_STACK();
            P_ToContinueStatus := ''N'';
            P_ErrorYNFlg       := ''Y'';
            ROLLBACK;
END;
/
*/
---------------COMMENTED BY OAS-----------------

						----------------CODE FOR MAIN PROCEDURE ETL.SP_ETL_MCLONE_DECOM_M BEGINS------------------------
						

CALL UTIL.SP_ETL_CHECK_CONSTRAINTS(:DB_NAME , :APPLICATION , :WORKFLOW_NAME , :OBJECT_NAME , :V_BATCH_ID );		---------OAS ADD

UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''COMPLETE'', ERROR_MSG = null, BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
;
UPDATE  UTIL.ETL_BATCH_OBJECT_INCR_VALU SET INCR_COLUMN_VALUE = :V_BATCH_ID, LST_MOD_DT = CURRENT_TIMESTAMP() 
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID''
;



EXCEPTION

WHEN OTHER THEN

UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''ERROR'', ERROR_MSG = :SQLERRM,  BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
;

INSERT INTO  UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ERROR_MSG, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''ERROR'', :V_STEP_NAME, :V_STEP_SEQ, :SQLERRM, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() )
;



RAISE;

END;

';