USE SCHEMA BDR_DM; CREATE OR REPLACE PROCEDURE "SP_RIA_PREMIUM_DERIVATIVE2_IXL_WRKDCMWRITINGAGENT_D"("DB_NAME" VARCHAR(16777216), "APPLICATION" VARCHAR(16777216), "WORKFLOW_NAME" VARCHAR(16777216), "OBJECT_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '

-- Original workflow: wkf_RIA_Premium_Derivative_IXL_TargetLoad2_D
-- Original mapping: m_RIA_Premium_Derivative2_IXL_WrkDcmWritingAgent_D
-- Original folder: Premium
-- Original filename: wkf_RIA_Premium_Derivative_IXL_TargetLoad2_D.XML

DECLARE 

V_ROWS_INSERTED INTEGER;

V_ROWS_UPDATED INTEGER;

V_ROWS_DELETED INTEGER;

V_LAST_QUERY_ID VARCHAR;

V_WH VARCHAR;

V_BATCH_ID INTEGER;

V_BATCH_OBJECT_START_TIME VARCHAR;

V_STEP_START_TIME VARCHAR;

V_STEP_NAME VARCHAR;

V_STEP_SEQ INTEGER DEFAULT 0;

V_ETL_LST_BTCH_ID INTEGER;

BEGIN EXECUTE IMMEDIATE ''USE DATABASE '' || :DB_NAME;

ALTER SESSION
SET
  TIMEZONE = ''America/Chicago'';

V_BATCH_OBJECT_START_TIME := (
  SELECT
    CURRENT_TIMESTAMP()
);

LET res1 RESULTSET := (
  SELECT
    WH,
    BATCH_ID
  FROM
    UTIL.ETL_BATCH_OBJECT_CONTROL
  WHERE
    APPLICATION = :APPLICATION
    AND WORKFLOW_NAME = :WORKFLOW_NAME
    AND OBJECT_NAME = :OBJECT_NAME
  FETCH FIRST
    1 ROW ONLY
);

LET C1 CURSOR FOR res1;

open C1;

FETCH C1 into V_WH,
V_BATCH_ID;

close C1;

EXECUTE IMMEDIATE ''USE WAREHOUSE '' || :V_WH;

USE SCHEMA BDR_DM;

INSERT INTO
  UTIL.ETL_BATCH_OBJECT_INCR_VALU (
    APPLICATION,
    WORKFLOW_NAME,
    OBJECT_NAME,
    INCR_COLUMN,
    INCR_COLUMN_VALUE
  )
SELECT
  *
FROM
  (
    select
      :APPLICATION AS APPLICATION,
      :WORKFLOW_NAME AS WORKFLOW_NAME,
      :OBJECT_NAME AS OBJECT_NAME,
      ''ETL_LST_BTCH_ID'' AS INCR_COLUMN,
      -1 AS INCR_COLUMN_VALUE
  ) A
WHERE
  NOT EXISTS (
    SELECT
      1
    FROM
      UTIL.ETL_BATCH_OBJECT_INCR_VALU B
    WHERE
      B.APPLICATION = A.APPLICATION
      AND B.WORKFLOW_NAME = A.WORKFLOW_NAME
      AND B.OBJECT_NAME = A.OBJECT_NAME
      AND B.INCR_COLUMN = A.INCR_COLUMN
  );

V_ETL_LST_BTCH_ID :=(
  SELECT
    INCR_COLUMN_VALUE
  FROM
    UTIL.ETL_BATCH_OBJECT_INCR_VALU
  WHERE
    APPLICATION = :APPLICATION
    AND WORKFLOW_NAME = :WORKFLOW_NAME
    AND OBJECT_NAME = :OBJECT_NAME
    AND INCR_COLUMN = ''ETL_LST_BTCH_ID''
);
--
---------------------------OAS ADD------------------------------

---------------------------OAS DELETE---------------------------
--
/*
 CREATE OR REPLACE PROCEDURE DM.SP_RIA_PREMIUM_WRKDCMWRITINGAGT_D
 (
 iv_Dummy                IN VARCHAR2,
 P_ToContinueStatus OUT VARCHAR2,
 P_ErrorYNFlg OUT VARCHAR2,
 P_ErrorStr OUT VARCHAR2)
 AS
 V_PROC_NAME         VARCHAR(50):=''SP_RIA_PREMIUM_WRKDCMWRITINGAGT_D'';
 V_ROWS_AFFTD        NUMBER(20) :=0;
 V_BTCH_ID           NUMBER(10);
 BEGIN
 
 SELECT MAX(BATCH_ID) INTO V_BTCH_ID FROM ETL.ETL_BATCH_LOG WHERE APPLICATION=''CDC'' AND BATCH_STATUS=''COMPLETE'';
 
 INSERT
 INTO ETL.ETL_DETAIL_LOAD_INFO
 (
 APPLICATION ,
 ETL_BATCH_ID,
 ETL_PROC_NAME ,
 ACTION ,
 STEP_INFO ,
 ROWS_AFFECTED ,
 ETL_DATETIME
 )
 VALUES
 (
 ''DERIVATIVE PREMIUM 2'',
 V_BTCH_ID,
 V_PROC_NAME,
 ''START'',
 ''PROCEDURE STARTS'',
 V_ROWS_AFFTD,
 SYSTIMESTAMP
 );
 */
--
---------------------------OAS DELETE---------------------------

---------------------------OAS ADD------------------------------
--
V_STEP_NAME := ''TARGET - TRUNCATE TEMP_RIA_BL_REBUILD_DCM_WRT_AGT'';

V_STEP_SEQ := V_STEP_SEQ + 1;

V_STEP_START_TIME := (
  SELECT
    CURRENT_TIMESTAMP()
);

V_ROWS_INSERTED := null;

V_ROWS_UPDATED := null;

V_ROWS_DELETED := null;
--
---------------------------OAS ADD------------------------------

EXECUTE IMMEDIATE ''TRUNCATE TABLE BDR_DM.TEMP_RIA_BL_REBUILD_DCM_WRT_AGT'';

---------------------------OAS ADD------------------------------
--
INSERT INTO
  UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (
    APPLICATION,
    WORKFLOW_NAME,
    TABLE_NAME,
    BATCH_ID,
    STATUS,
    STEP,
    SEQ,
    ROWS_INSERTED,
    ROWS_UPDATED,
    ROWS_DELETED,
    STEP_START_DATETIME,
    STEP_END_DATETIME
  )
VALUES
  (
    :APPLICATION,
    :WORKFLOW_NAME,
    :OBJECT_NAME,
    :V_BATCH_ID,
    ''COMPLETE'',
    :V_STEP_NAME,
    :V_STEP_SEQ,
    :V_ROWS_INSERTED,
    :V_ROWS_UPDATED,
    :V_ROWS_DELETED,
    :V_STEP_START_TIME,
    CURRENT_TIMESTAMP()
  );
--
---------------------------OAS ADD------------------------------

---------------------------OAS ADD------------------------------
--
V_STEP_NAME := ''TARGET - TRUNCATE TEMP_RIA_BL_REBUILD_FILTERED'';

V_STEP_SEQ := V_STEP_SEQ + 1;

V_STEP_START_TIME := (
  SELECT
    CURRENT_TIMESTAMP()
);

V_ROWS_INSERTED := null;

V_ROWS_UPDATED := null;

V_ROWS_DELETED := null;
--
---------------------------OAS ADD------------------------------

EXECUTE IMMEDIATE ''TRUNCATE TABLE BDR_DM.TEMP_RIA_BL_REBUILD_FILTERED'';

---------------------------OAS ADD------------------------------
--
INSERT INTO
  UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (
    APPLICATION,
    WORKFLOW_NAME,
    TABLE_NAME,
    BATCH_ID,
    STATUS,
    STEP,
    SEQ,
    ROWS_INSERTED,
    ROWS_UPDATED,
    ROWS_DELETED,
    STEP_START_DATETIME,
    STEP_END_DATETIME
  )
VALUES
  (
    :APPLICATION,
    :WORKFLOW_NAME,
    :OBJECT_NAME,
    :V_BATCH_ID,
    ''COMPLETE'',
    :V_STEP_NAME,
    :V_STEP_SEQ,
    :V_ROWS_INSERTED,
    :V_ROWS_UPDATED,
    :V_ROWS_DELETED,
    :V_STEP_START_TIME,
    CURRENT_TIMESTAMP()
  );
--
---------------------------OAS ADD------------------------------

---------------------------OAS ADD------------------------------
--
V_STEP_NAME := ''TARGET - TRUNCATE TEMP_RIA_DCM_WORK_TBL'';

V_STEP_SEQ := V_STEP_SEQ + 1;

V_STEP_START_TIME := (
  SELECT
    CURRENT_TIMESTAMP()
);

V_ROWS_INSERTED := null;

V_ROWS_UPDATED := null;

V_ROWS_DELETED := null;
--
---------------------------OAS ADD------------------------------

EXECUTE IMMEDIATE ''TRUNCATE TABLE BDR_DM.TEMP_RIA_DCM_WORK_TBL'';

---------------------------OAS ADD------------------------------
--
INSERT INTO
  UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (
    APPLICATION,
    WORKFLOW_NAME,
    TABLE_NAME,
    BATCH_ID,
    STATUS,
    STEP,
    SEQ,
    ROWS_INSERTED,
    ROWS_UPDATED,
    ROWS_DELETED,
    STEP_START_DATETIME,
    STEP_END_DATETIME
  )
VALUES
  (
    :APPLICATION,
    :WORKFLOW_NAME,
    :OBJECT_NAME,
    :V_BATCH_ID,
    ''COMPLETE'',
    :V_STEP_NAME,
    :V_STEP_SEQ,
    :V_ROWS_INSERTED,
    :V_ROWS_UPDATED,
    :V_ROWS_DELETED,
    :V_STEP_START_TIME,
    CURRENT_TIMESTAMP()
  );
--
---------------------------OAS ADD------------------------------

---------------------------OAS ADD------------------------------
--
V_STEP_NAME := ''TARGET - TRUNCATE TEMP_AGT'';

V_STEP_SEQ := V_STEP_SEQ + 1;

V_STEP_START_TIME := (
  SELECT
    CURRENT_TIMESTAMP()
);

V_ROWS_INSERTED := null;

V_ROWS_UPDATED := null;

V_ROWS_DELETED := null;
--
---------------------------OAS ADD------------------------------

EXECUTE IMMEDIATE ''TRUNCATE TABLE BDR_DM.TEMP_AGT'';

---------------------------OAS ADD------------------------------
--
INSERT INTO
  UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (
    APPLICATION,
    WORKFLOW_NAME,
    TABLE_NAME,
    BATCH_ID,
    STATUS,
    STEP,
    SEQ,
    ROWS_INSERTED,
    ROWS_UPDATED,
    ROWS_DELETED,
    STEP_START_DATETIME,
    STEP_END_DATETIME
  )
VALUES
  (
    :APPLICATION,
    :WORKFLOW_NAME,
    :OBJECT_NAME,
    :V_BATCH_ID,
    ''COMPLETE'',
    :V_STEP_NAME,
    :V_STEP_SEQ,
    :V_ROWS_INSERTED,
    :V_ROWS_UPDATED,
    :V_ROWS_DELETED,
    :V_STEP_START_TIME,
    CURRENT_TIMESTAMP()
  );
--
---------------------------OAS ADD------------------------------

---------------------------OAS ADD------------------------------
--
V_STEP_NAME := ''TARGET - TRUNCATE TEMP_RIA_DCM'';

V_STEP_SEQ := V_STEP_SEQ + 1;

V_STEP_START_TIME := (
  SELECT
    CURRENT_TIMESTAMP()
);

V_ROWS_INSERTED := null;

V_ROWS_UPDATED := null;

V_ROWS_DELETED := null;
--
---------------------------OAS ADD------------------------------

EXECUTE IMMEDIATE ''TRUNCATE TABLE BDR_DM.TEMP_RIA_DCM'';

---------------------------OAS ADD------------------------------
--
INSERT INTO
  UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (
    APPLICATION,
    WORKFLOW_NAME,
    TABLE_NAME,
    BATCH_ID,
    STATUS,
    STEP,
    SEQ,
    ROWS_INSERTED,
    ROWS_UPDATED,
    ROWS_DELETED,
    STEP_START_DATETIME,
    STEP_END_DATETIME
  )
VALUES
  (
    :APPLICATION,
    :WORKFLOW_NAME,
    :OBJECT_NAME,
    :V_BATCH_ID,
    ''COMPLETE'',
    :V_STEP_NAME,
    :V_STEP_SEQ,
    :V_ROWS_INSERTED,
    :V_ROWS_UPDATED,
    :V_ROWS_DELETED,
    :V_STEP_START_TIME,
    CURRENT_TIMESTAMP()
  );
--
---------------------------OAS ADD------------------------------

---------------------------OAS ADD------------------------------
--
V_STEP_NAME := ''TARGET - TRUNCATE WRK_RIA_DCM_WRITING_AGENT'';

V_STEP_SEQ := V_STEP_SEQ + 1;

V_STEP_START_TIME := (
  SELECT
    CURRENT_TIMESTAMP()
);

V_ROWS_INSERTED := null;

V_ROWS_UPDATED := null;

V_ROWS_DELETED := null;
--
---------------------------OAS ADD------------------------------

EXECUTE IMMEDIATE ''TRUNCATE TABLE BDR_DM.WRK_RIA_DCM_WRITING_AGENT'';

---------------------------OAS ADD------------------------------
--
INSERT INTO
  UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (
    APPLICATION,
    WORKFLOW_NAME,
    TABLE_NAME,
    BATCH_ID,
    STATUS,
    STEP,
    SEQ,
    ROWS_INSERTED,
    ROWS_UPDATED,
    ROWS_DELETED,
    STEP_START_DATETIME,
    STEP_END_DATETIME
  )
VALUES
  (
    :APPLICATION,
    :WORKFLOW_NAME,
    :OBJECT_NAME,
    :V_BATCH_ID,
    ''COMPLETE'',
    :V_STEP_NAME,
    :V_STEP_SEQ,
    :V_ROWS_INSERTED,
    :V_ROWS_UPDATED,
    :V_ROWS_DELETED,
    :V_STEP_START_TIME,
    CURRENT_TIMESTAMP()
  );

--
---------------------------OAS ADD------------------------------

---------------------------OAS ADD------------------------------
--
V_STEP_NAME := ''TARGET - DELETE WRK_RIA_ORIGINAL_SELLING_AGENT'';

V_STEP_SEQ := V_STEP_SEQ + 1;

V_STEP_START_TIME := (
  SELECT
    CURRENT_TIMESTAMP()
);

V_ROWS_INSERTED := null;

V_ROWS_UPDATED := null;

V_ROWS_DELETED := null;
--
---------------------------OAS ADD------------------------------

DELETE
/*+ enable_parallel_dml parallel(8) */
FROM
  BDR_DM.WRK_RIA_ORIGINAL_SELLING_AGENT
WHERE
  (BLR_RN, AGT_SEL_ORIG_SKEY) IN (
    SELECT
      DISTINCT BLR_RN,
      AGT_SEL_ORIG_SKEY
    FROM
      (
        SELECT
          /*+ parallel(8) */
          BLR_RN,
          ORIGINAL_SELLING_AGENT,
          ORIGINAL_SIGNATURE_DATE,
          AGT_SEL_ORIG_SKEY,
          ROW_NUMBER() OVER(
            PARTITION BY BLR_RN,
            ORIGINAL_SELLING_AGENT,
            ORIGINAL_SIGNATURE_DATE
            ORDER BY
              AGT_SEL_ORIG_SKEY DESC
          ) RN
        FROM
          BDR_DM.WRK_RIA_ORIGINAL_SELLING_AGENT
      )
    WHERE
      RN > 1
  );

---------------------------OAS ADD------------------------------
--
V_LAST_QUERY_ID := (
  SELECT
    LAST_QUERY_ID()
);

V_ROWS_DELETED := (
  SELECT
    *
  FROM
    TABLE (RESULT_SCAN (:V_LAST_QUERY_ID))
);

INSERT INTO
  UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (
    APPLICATION,
    WORKFLOW_NAME,
    TABLE_NAME,
    BATCH_ID,
    STATUS,
    STEP,
    SEQ,
    ROWS_INSERTED,
    ROWS_UPDATED,
    ROWS_DELETED,
    STEP_START_DATETIME,
    STEP_END_DATETIME
  )
VALUES
  (
    :APPLICATION,
    :WORKFLOW_NAME,
    :OBJECT_NAME,
    :V_BATCH_ID,
    ''COMPLETE'',
    :V_STEP_NAME,
    :V_STEP_SEQ,
    :V_ROWS_INSERTED,
    :V_ROWS_UPDATED,
    :V_ROWS_DELETED,
    :V_STEP_START_TIME,
    CURRENT_TIMESTAMP()
  );
--
---------------------------OAS ADD------------------------------

---------------------------OAS DELETE---------------------------
--
/*
 V_ROWS_AFFTD:=SQL%ROWCOUNT;
 commit;
 */
--
---------------------------OAS DELETE---------------------------

---------------------------OAS ADD------------------------------
--
V_STEP_NAME := ''TARGET - DELETE WRK_RIA_ORIG_REFERRAL_AGENT'';

V_STEP_SEQ := V_STEP_SEQ + 1;

V_STEP_START_TIME := (
  SELECT
    CURRENT_TIMESTAMP()
);

V_ROWS_INSERTED := null;

V_ROWS_UPDATED := null;

V_ROWS_DELETED := null;
--
---------------------------OAS ADD------------------------------

DELETE
/*+ enable_parallel_dml parallel(8) */
FROM
  BDR_DM.WRK_RIA_ORIG_REFERRAL_AGENT
WHERE
  (BLR_RN, AGT_REF_ORIG_D_AGT_SK) IN (
    SELECT
      DISTINCT BLR_RN,
      AGT_REF_ORIG_D_AGT_SK
    FROM
      (
        SELECT
          /*+ parallel(8) */
          BLR_RN,
          ORIGINAL_REFERRAL_AGENT,
          ORIGINAL_SIGNATURE_DATE,
          AGT_REF_ORIG_D_AGT_SK,
          ROW_NUMBER() OVER(
            PARTITION BY BLR_RN,
            ORIGINAL_REFERRAL_AGENT,
            ORIGINAL_SIGNATURE_DATE
            ORDER BY
              AGT_REF_ORIG_D_AGT_SK DESC
          ) RN
        FROM
          BDR_DM.WRK_RIA_ORIG_REFERRAL_AGENT
      )
    WHERE
      RN > 1
  );

---------------------------OAS ADD------------------------------
--
V_LAST_QUERY_ID := (
  SELECT
    LAST_QUERY_ID()
);

V_ROWS_DELETED := (
  SELECT
    *
  FROM
    TABLE (RESULT_SCAN (:V_LAST_QUERY_ID))
);

INSERT INTO
  UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (
    APPLICATION,
    WORKFLOW_NAME,
    TABLE_NAME,
    BATCH_ID,
    STATUS,
    STEP,
    SEQ,
    ROWS_INSERTED,
    ROWS_UPDATED,
    ROWS_DELETED,
    STEP_START_DATETIME,
    STEP_END_DATETIME
  )
VALUES
  (
    :APPLICATION,
    :WORKFLOW_NAME,
    :OBJECT_NAME,
    :V_BATCH_ID,
    ''COMPLETE'',
    :V_STEP_NAME,
    :V_STEP_SEQ,
    :V_ROWS_INSERTED,
    :V_ROWS_UPDATED,
    :V_ROWS_DELETED,
    :V_STEP_START_TIME,
    CURRENT_TIMESTAMP()
  );
--
---------------------------OAS ADD------------------------------

---------------------------OAS DELETE---------------------------
--
/*
 V_ROWS_AFFTD:=SQL%ROWCOUNT;
 commit;
 */
--
---------------------------OAS DELETE---------------------------

--    delete /*+ enable_parallel_dml parallel(8) */ FROM  DM.WRK_ORIGINAL_SELLING_AGENT
--    WHERE AGT_SEL_ORIG_SKEY IN ( SELECT AGT_SEL_ORIG_SKEY FROM(SELECT /*+ parallel(8) */  BLR_RN,ORIGINAL_SELLING_AGENT,ORIGINAL_SIGNATURE_DATE,AGT_SEL_ORIG_SKEY,ROW_NUMBER() OVER(PARTITION BY BLR_RN,ORIGINAL_SELLING_AGENT,ORIGINAL_SIGNATURE_DATE
--              ORDER BY AGT_SEL_ORIG_SKEY DESC) RN FROM  DM.WRK_ORIGINAL_SELLING_AGENT) WHERE RN>1);
--              V_ROWS_AFFTD:=SQL%ROWCOUNT;
--              commit;
--
--    delete /*+ enable_parallel_dml parallel(8) */  FROM DM.WRK_ORIG_REFERRAL_AGENT WHERE AGT_REF_ORIG_D_AGT_SK in
--    (SELECT AGT_REF_ORIG_D_AGT_SK FROM(SELECT /*+ parallel(8) */  BLR_RN, ORIGINAL_REFERRAL_AGENT, ORIGINAL_SIGNATURE_DATE, AGT_REF_ORIG_D_AGT_SK, ROW_NUMBER() OVER(PARTITION BY BLR_RN, ORIGINAL_REFERRAL_AGENT, ORIGINAL_SIGNATURE_DATE
--              ORDER BY AGT_REF_ORIG_D_AGT_SK DESC) RN FROM  DM.WRK_ORIG_REFERRAL_AGENT) WHERE RN>1);
--              V_ROWS_AFFTD:=SQL%ROWCOUNT;
--              commit;

---------------------------OAS ADD------------------------------
--
V_STEP_NAME := ''TARGET - INSERT TEMP_AGT'';

V_STEP_SEQ := V_STEP_SEQ + 1;

V_STEP_START_TIME := (
  SELECT
    CURRENT_TIMESTAMP()
);

V_ROWS_INSERTED := null;

V_ROWS_UPDATED := null;

V_ROWS_DELETED := null;
--
---------------------------OAS ADD------------------------------

INSERT
  /*+ ENABLE_PARALLEL_DML APPEND */
  INTO BDR_DM.TEMP_AGT WITH OVERLAPS AS (
    SELECT
      A1.*
    FROM
      BDR_CONF.D_AGT a1
      INNER JOIN BDR_CONF.D_AGT a2 ON a1.PTY_ID = a2.PTY_ID
      AND a1.AGT_ID = a2.AGT_ID
      AND a1.AGT_WRT_STRT_DT_ID <= a2.AGT_WRT_END_DT_ID
      AND a1.AGT_WRT_END_DT_ID >= a2.AGT_WRT_STRT_DT_ID
      AND a1.AGT_WRT_STRT_DT_ID != a2.AGT_WRT_STRT_DT_ID
  ),
  --SELECT * FROM overlaps
  OVERLAPS_TEMP AS (
    SELECT
      LAG(AGT_WRT_STRT_DT_ID, 1, NULL) OVER (
        PARTITION BY PTY_ID,
        AGT_ID
        ORDER BY
          ROW_EFF_STRT_DT DESC,
          AGT_WRT_STRT_DT_ID,
          D_AGT_SK
      ) AS PREV_AGT_WRT_STRT_DT_ID,
      LAG(AGT_WRT_END_DT_ID, 1, NULL) OVER (
        PARTITION BY PTY_ID,
        AGT_ID
        ORDER BY
          ROW_EFF_STRT_DT DESC,
          AGT_WRT_STRT_DT_ID,
          D_AGT_SK
      ) AS PREV_AGT_WRT_END_DT_ID,
      LAG(ROW_EFF_STRT_DT, 1, NULL) OVER (
        PARTITION BY PTY_ID,
        AGT_ID
        ORDER BY
          ROW_EFF_STRT_DT DESC,
          AGT_WRT_STRT_DT_ID,
          D_AGT_SK
      ) AS PREV_ROW_EFF_STRT_DT,
      LEAD(AGT_WRT_STRT_DT_ID, 1, NULL) OVER (
        PARTITION BY PTY_ID,
        AGT_ID
        ORDER BY
          ROW_EFF_STRT_DT DESC,
          AGT_WRT_STRT_DT_ID,
          D_AGT_SK
      ) AS NEXT_AGT_WRT_STRT_DT_ID,
      LEAD(AGT_WRT_END_DT_ID, 1, NULL) OVER (
        PARTITION BY PTY_ID,
        AGT_ID
        ORDER BY
          ROW_EFF_STRT_DT DESC,
          AGT_WRT_STRT_DT_ID,
          D_AGT_SK
      ) AS NEXT_AGT_WRT_END_DT_ID,
      LEAD(ROW_EFF_STRT_DT, 1, NULL) OVER (
        PARTITION BY PTY_ID,
        AGT_ID
        ORDER BY
          ROW_EFF_STRT_DT DESC,
          AGT_WRT_STRT_DT_ID,
          D_AGT_SK
      ) AS NEXT_ROW_EFF_STRT_DT,
      D_AGT_SK,
      PTY_ID,
      PTY_TYP,
      NAT_INS_PROD_RGST_NBR,
      AGT_ID,
      AGT_WRT_STRT_DT_ID,
      AGT_WRT_END_DT_ID,
      AGT_STS,
      AGT_TYP,
      AGT_NM_FST,
      AGT_NM_MIDL,
      AGT_NM_LST,
      BUS_NM,
      AGT_TEL,
      AGT_ADDR_LN_1,
      AGT_ADDR_LN_2,
      AGT_ADDR_LN_3,
      AGT_CTY,
      AGT_ST,
      AGT_ZIP_CD,
      EALLIANCE_FLG,
      EALLIANCE_PREF_NM,
      ROW_EFF_STRT_DT,
      ROW_EFF_END_DT,
      ROW_CURR_FLG,
      ETL_LST_BTCH_ID
    FROM
      OVERLAPS
    ORDER BY
      PTY_ID,
      AGT_ID,
      ROW_EFF_STRT_DT DESC
  ),
  --SELECT * FROM OVERLAPS_TEMP
  AGT_1 AS (
    SELECT
      D_AGT_SK,
      PTY_ID,
      PTY_TYP,
      NAT_INS_PROD_RGST_NBR,
      AGT_ID,
      CASE
        WHEN PREV_AGT_WRT_STRT_DT_ID < AGT_WRT_STRT_DT_ID THEN CASE
          WHEN PREV_AGT_WRT_END_DT_ID = 99991231 THEN PREV_AGT_WRT_END_DT_ID
          ELSE TO_NUMBER(
            TO_CHAR(
              (DATEADD(''DD'', 1, TO_DATE(TO_CHAR(PREV_AGT_WRT_END_DT_ID), ''YYYYMMDD''))),
              ''YYYYMMDD''
            )
          )
        END
        ELSE AGT_WRT_STRT_DT_ID
      END AS AGT_WRT_STRT_DT_ID,
      CASE
        WHEN NEXT_ROW_EFF_STRT_DT = ROW_EFF_STRT_DT THEN CASE
          WHEN NEXT_AGT_WRT_STRT_DT_ID BETWEEN AGT_WRT_STRT_DT_ID
          AND AGT_WRT_END_DT_ID THEN TO_NUMBER(
            TO_CHAR(
              (DATEADD(''DD'', -1, TO_DATE(TO_CHAR(NEXT_AGT_WRT_STRT_DT_ID), ''YYYYMMDD''))),
              ''YYYYMMDD''
            )
          )
        END
        WHEN PREV_ROW_EFF_STRT_DT > ROW_EFF_STRT_DT THEN CASE
          WHEN PREV_AGT_WRT_STRT_DT_ID BETWEEN AGT_WRT_STRT_DT_ID
          AND AGT_WRT_END_DT_ID THEN TO_NUMBER(
            TO_CHAR(
              (DATEADD(''DD'', -1, TO_DATE(TO_CHAR(PREV_AGT_WRT_STRT_DT_ID), ''YYYYMMDD''))),
              ''YYYYMMDD''
            )
          )
        END
        ELSE AGT_WRT_END_DT_ID
      END AS AGT_WRT_END_DT_ID,
      AGT_STS,
      AGT_TYP,
      AGT_NM_FST,
      AGT_NM_MIDL,
      AGT_NM_LST,
      BUS_NM,
      AGT_TEL,
      AGT_ADDR_LN_1,
      AGT_ADDR_LN_2,
      AGT_ADDR_LN_3,
      AGT_CTY,
      AGT_ST,
      AGT_ZIP_CD,
      EALLIANCE_FLG,
      EALLIANCE_PREF_NM,
      ROW_EFF_STRT_DT,
      ROW_EFF_END_DT,
      ROW_CURR_FLG,
      ETL_LST_BTCH_ID
    FROM
      OVERLAPS_TEMP
    UNION
    SELECT
      D_AGT_SK,
      PTY_ID,
      PTY_TYP,
      NAT_INS_PROD_RGST_NBR,
      AGT_ID,
      AGT_WRT_STRT_DT_ID,
      AGT_WRT_END_DT_ID,
      AGT_STS,
      AGT_TYP,
      AGT_NM_FST,
      AGT_NM_MIDL,
      AGT_NM_LST,
      BUS_NM,
      AGT_TEL,
      AGT_ADDR_LN_1,
      AGT_ADDR_LN_2,
      AGT_ADDR_LN_3,
      AGT_CTY,
      AGT_ST,
      AGT_ZIP_CD,
      EALLIANCE_FLG,
      EALLIANCE_PREF_NM,
      ROW_EFF_STRT_DT,
      ROW_EFF_END_DT,
      ROW_CURR_FLG,
      ETL_LST_BTCH_ID
    FROM
      BDR_CONF.D_AGT
    WHERE
      D_AGT_SK NOT IN (
        SELECT
          D_AGT_SK
        FROM
          OVERLAPS
      )
  ),
  --SELECT * FROM AGT_1
  AGT_2 AS (
    SELECT
      D_AGT_SK,
      PTY_ID,
      PTY_TYP,
      NAT_INS_PROD_RGST_NBR,
      AGT_ID,
      CASE
        WHEN AGT_WRT_STRT_DT_ID IN (-1, -2) THEN 19000101
        ELSE AGT_WRT_STRT_DT_ID
      END AS AGT_WRT_STRT_DT_ID,
      CASE
        WHEN AGT_WRT_END_DT_ID IN (-1, -2) THEN 99991231
        ELSE AGT_WRT_END_DT_ID
      END AS AGT_WRT_END_DT_ID,
      AGT_STS,
      AGT_TYP,
      AGT_NM_FST,
      AGT_NM_MIDL,
      AGT_NM_LST,
      BUS_NM,
      AGT_TEL,
      AGT_ADDR_LN_1,
      AGT_ADDR_LN_2,
      AGT_ADDR_LN_3,
      AGT_CTY,
      AGT_ST,
      AGT_ZIP_CD,
      EALLIANCE_FLG,
      EALLIANCE_PREF_NM,
      ROW_EFF_STRT_DT,
      ROW_EFF_END_DT,
      ROW_CURR_FLG,
      ETL_LST_BTCH_ID
    FROM
      AGT_1
  )
SELECT
  /*+ parallel(8) */
  TEMP.*
FROM
  (
    SELECT
      ROW_NUMBER() OVER (
        PARTITION BY AGT_ID,
        AGT_WRT_STRT_DT_ID,
        AGT_WRT_END_DT_ID
        ORDER BY
          ROW_EFF_STRT_DT DESC
      ) AS RN,
      D_AGT_SK,
      PTY_ID,
      PTY_TYP,
      NAT_INS_PROD_RGST_NBR,
      AGT_ID,
      AGT_WRT_STRT_DT_ID,
      AGT_WRT_END_DT_ID,
      AGT_STS,
      AGT_TYP,
      AGT_NM_FST,
      AGT_NM_MIDL,
      AGT_NM_LST,
      BUS_NM,
      AGT_TEL,
      AGT_ADDR_LN_1,
      AGT_ADDR_LN_2,
      AGT_ADDR_LN_3,
      AGT_CTY,
      AGT_ST,
      AGT_ZIP_CD,
      EALLIANCE_FLG,
      EALLIANCE_PREF_NM,
      ROW_EFF_STRT_DT,
      ROW_EFF_END_DT,
      ROW_CURR_FLG,
      ETL_LST_BTCH_ID
    FROM
      AGT_2
  ) TEMP
WHERE
  TEMP.RN = 1;

---------------------------OAS ADD------------------------------
--
V_LAST_QUERY_ID := (
  SELECT
    LAST_QUERY_ID()
);

V_ROWS_INSERTED := (
  SELECT
    *
  FROM
    TABLE (RESULT_SCAN (:V_LAST_QUERY_ID))
);

INSERT INTO
  UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (
    APPLICATION,
    WORKFLOW_NAME,
    TABLE_NAME,
    BATCH_ID,
    STATUS,
    STEP,
    SEQ,
    ROWS_INSERTED,
    ROWS_UPDATED,
    ROWS_DELETED,
    STEP_START_DATETIME,
    STEP_END_DATETIME
  )
VALUES
  (
    :APPLICATION,
    :WORKFLOW_NAME,
    :OBJECT_NAME,
    :V_BATCH_ID,
    ''COMPLETE'',
    :V_STEP_NAME,
    :V_STEP_SEQ,
    :V_ROWS_INSERTED,
    :V_ROWS_UPDATED,
    :V_ROWS_DELETED,
    :V_STEP_START_TIME,
    CURRENT_TIMESTAMP()
  );
--
---------------------------OAS ADD------------------------------

---------------------------OAS DELETE---------------------------
--
/*
 V_ROWS_AFFTD := SQL % ROWCOUNT;
 
 COMMIT;
 
 DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'', ''TEMP_AGT'');
 
 --DBMS_STATS.GATHER_TABLE_STATS (ownname => ''DM'',tabname => ''TEMP_AGT'',partname => NULL,estimate_percent => 10, DEGREE => 4, granularity => ''ALL'', method_opt => ''FOR ALL COLUMNS SIZE 1'',CASCADE => TRUE);
 INSERT INTO
 ETL.ETL_DETAIL_LOAD_INFO (
 APPLICATION,
 ETL_BATCH_ID,
 ETL_PROC_NAME,
 ACTION,
 STEP_INFO,
 ROWS_AFFECTED,
 ETL_DATETIME
 )
 VALUES
 (
 ''DERIVATIVE PREMIUM 2'',
 V_BTCH_ID,
 V_PROC_NAME,
 ''INSERT'',
 ''INSERT INTO TEMP_AGT '',
 V_ROWS_AFFTD,
 SYSTIMESTAMP
 );
 
 COMMIT;
 */
--
---------------------------OAS DELETE---------------------------

---------------------------OAS ADD------------------------------
--
V_STEP_NAME := ''TARGET - INSERT TEMP_RIA_BL_REBUILD_DCM_WRT_AGT'';

V_STEP_SEQ := V_STEP_SEQ + 1;

V_STEP_START_TIME := (
  SELECT
    CURRENT_TIMESTAMP()
);

V_ROWS_INSERTED := null;

V_ROWS_UPDATED := null;

V_ROWS_DELETED := null;
--
---------------------------OAS ADD------------------------------

INSERT
  /*+ ENABLE_PARALLEL_DML APPEND */
  INTO BDR_DM.TEMP_RIA_BL_REBUILD_DCM_WRT_AGT
SELECT
  /*+ parallel(8) */
  BL.BLR_RN,
  BL.INDIVIDUAL_ID,
  BL.INSURED_PLAN_ID,
  BL.PRODUCT_GROUP,
  BL.PLAN_GROUP,
  BL.PLAN_CD,
  BL.INSURED_PLAN_EFFECTIVE_DATE,
  BL.CERT_ACQN_CHNL_LEVEL3,
  BL.DCM_SIGNATURE_DATE,
  BL.DCM_WRITING_AGENT,
  BL.CERT_ACTV_LVL_3_TXT,
  BL.PREMIUM_DUE_DATE,
  PRD.PRDCT_EFF_DT,
  PRD.PRDCT_ACQN_CHNL_LEVEL3,
  SEL.SELLING_AGENT
FROM
  BDR_DM.WRK_RIA_PREMIUM_DATA_BL_REBUILD BL
  LEFT OUTER JOIN BDR_DM.WRK_RIA_PRDCT_EFF_DT_CHNL PRD ON BL.BLR_RN = PRD.BLR_RN
  LEFT OUTER JOIN BDR_DM.WRK_RIA_SELLING_AGENT SEL ON BL.BLR_RN = SEL.BLR_RN;

---------------------------OAS ADD------------------------------
--
V_LAST_QUERY_ID := (
  SELECT
    LAST_QUERY_ID()
);

V_ROWS_INSERTED := (
  SELECT
    *
  FROM
    TABLE (RESULT_SCAN (:V_LAST_QUERY_ID))
);

INSERT INTO
  UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (
    APPLICATION,
    WORKFLOW_NAME,
    TABLE_NAME,
    BATCH_ID,
    STATUS,
    STEP,
    SEQ,
    ROWS_INSERTED,
    ROWS_UPDATED,
    ROWS_DELETED,
    STEP_START_DATETIME,
    STEP_END_DATETIME
  )
VALUES
  (
    :APPLICATION,
    :WORKFLOW_NAME,
    :OBJECT_NAME,
    :V_BATCH_ID,
    ''COMPLETE'',
    :V_STEP_NAME,
    :V_STEP_SEQ,
    :V_ROWS_INSERTED,
    :V_ROWS_UPDATED,
    :V_ROWS_DELETED,
    :V_STEP_START_TIME,
    CURRENT_TIMESTAMP()
  );

--
---------------------------OAS ADD------------------------------

---------------------------OAS DELETE---------------------------
--
/*
 V_ROWS_AFFTD := SQL % ROWCOUNT;
 
 COMMIT;
 
 DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'', ''TEMP_RIA_BL_REBUILD_DCM_WRT_AGT'');
 
 INSERT INTO
 ETL.ETL_DETAIL_LOAD_INFO (
 APPLICATION,
 ETL_BATCH_ID,
 ETL_PROC_NAME,
 ACTION,
 STEP_INFO,
 ROWS_AFFECTED,
 ETL_DATETIME
 )
 VALUES
 (
 ''DERIVATIVE PREMIUM 2'',
 V_BTCH_ID,
 V_PROC_NAME,
 ''INSERT'',
 ''INSERT INTO TEMP_RIA_BL_REBUILD_DCM_WRT_AGT'',
 V_ROWS_AFFTD,
 SYSTIMESTAMP
 );
 
 COMMIT;
 */
--
---------------------------OAS DELETE---------------------------

---------------------------OAS ADD------------------------------
--
V_STEP_NAME := ''TARGET - INSERT TEMP_RIA_BL_REBUILD_FILTERED'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;
--
---------------------------OAS ADD------------------------------

INSERT
  /*+ ENABLE_PARALLEL_DML APPEND */
  INTO BDR_DM.TEMP_RIA_BL_REBUILD_FILTERED
SELECT
  BL.INDIVIDUAL_ID,
  BL.INSURED_PLAN_ID,
  BL.PRODUCT_GROUP,
  BL.PLAN_GROUP,
  BL.PLAN_CD,
  BL.INSURED_PLAN_EFFECTIVE_DATE,
  BL.CERT_ACQN_CHNL_LEVEL3,
  BL.PRDCT_EFF_DT,
  BL.PRDCT_ACQN_CHNL_LEVEL3,
  BL.SELLING_AGENT
FROM
  (
    SELECT
      /*+ PARALLEL(8) */
      BL.INDIVIDUAL_ID,
      BL.INSURED_PLAN_ID,
      BL.PRODUCT_GROUP,
      BL.PLAN_GROUP,
      BL.PLAN_CD,
      BL.INSURED_PLAN_EFFECTIVE_DATE,
      BL.CERT_ACQN_CHNL_LEVEL3,
      PRD.PRDCT_EFF_DT,
      PRD.PRDCT_ACQN_CHNL_LEVEL3,
      BL.SELLING_AGENT,
      ROW_NUMBER() OVER(
        PARTITION BY bl.INDIVIDUAL_ID,
        bl.PRODUCT_GROUP,
        bl.INSURED_PLAN_EFFECTIVE_DATE
        ORDER BY
          bl.INSURED_PLAN_EFFECTIVE_DATE
      ) AS RN
    FROM
      (
        SELECT
          *
        FROM
          BDR_DM.TEMP_RIA_BL_REBUILD_DCM_WRT_AGT bl
        WHERE
          UPPER(BL.CERT_ACTV_LVL_3_TXT) IN (
            SELECT
              DISTINCT UPPER(CERT_ACTV_LVL_3_TXT) AS CERT_ACTV_LVL_3_TXT
            FROM
              BDR_CONF.D_CERT_ACTV
            WHERE
              UPPER(CERT_ACTV_LVL_3_TXT) NOT LIKE ''PLAN TERM (TERM DT EQ EFF DT%''
              AND UPPER(CERT_ACTV_LVL_3_TXT) <> ''UNKNOWN''
          )
          AND BL.PRODUCT_GROUP = ''Med Supp''
          AND BL.PLAN_GROUP IN (
            SELECT
              DISTINCT PLN_GRP
            FROM
              BDR_CONF.D_PLN_BEN_MOD
            WHERE
              PLN_GRP NOT LIKE ''%Rider%''
              AND PLN_GRP <> ''Default''
          )
      ) BL
      LEFT OUTER JOIN BDR_DM.WRK_RIA_PRDCT_EFF_DT_CHNL PRD ON BL.BLR_RN = PRD.BLR_RN
    WHERE
      BL.INSURED_PLAN_EFFECTIVE_DATE = PRD.PRDCT_EFF_DT
  ) BL
WHERE
  RN = 1;

---------------------------OAS ADD------------------------------
--
V_LAST_QUERY_ID := (
    SELECT
        LAST_QUERY_ID()
);

V_ROWS_INSERTED := (
    SELECT
        *
    FROM
        TABLE (RESULT_SCAN (:V_LAST_QUERY_ID))
);

INSERT INTO
    UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (
        APPLICATION,
        WORKFLOW_NAME,
        TABLE_NAME,
        BATCH_ID,
        STATUS,
        STEP,
        SEQ,
        ROWS_INSERTED,
        ROWS_UPDATED,
        ROWS_DELETED,
        STEP_START_DATETIME,
        STEP_END_DATETIME
    )
VALUES
    (
        :APPLICATION,
        :WORKFLOW_NAME,
        :OBJECT_NAME,
        :V_BATCH_ID,
        ''COMPLETE'',
        :V_STEP_NAME,
        :V_STEP_SEQ,
        :V_ROWS_INSERTED,
        :V_ROWS_UPDATED,
        :V_ROWS_DELETED,
        :V_STEP_START_TIME,
        CURRENT_TIMESTAMP()
    );
--
---------------------------OAS ADD------------------------------

---------------------------OAS DELETE---------------------------
--
/*
 V_ROWS_AFFTD := SQL % ROWCOUNT;
 
 COMMIT;
 
 DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'', ''TEMP_RIA_BL_REBUILD_FILTERED'');
 
 INSERT INTO
 ETL.ETL_DETAIL_LOAD_INFO (
 APPLICATION,
 ETL_BATCH_ID,
 ETL_PROC_NAME,
 ACTION,
 STEP_INFO,
 ROWS_AFFECTED,
 ETL_DATETIME
 )
 VALUES
 (
 ''DERIVATIVE PREMIUM 2'',
 V_BTCH_ID,
 V_PROC_NAME,
 ''INSERT'',
 ''INSERT INTO TEMP_RIA_BL_REBUILD_FILTERED'',
 V_ROWS_AFFTD,
 SYSTIMESTAMP
 );
 
 COMMIT;
 */
--
---------------------------OAS DELETE---------------------------

---------------------------OAS ADD------------------------------
--
V_STEP_NAME := ''TARGET - INSERT TEMP_RIA_DCM_WORK_TBL'';

V_STEP_SEQ := V_STEP_SEQ + 1;

V_STEP_START_TIME := (
    SELECT
        CURRENT_TIMESTAMP()
);

V_ROWS_INSERTED := null;

V_ROWS_UPDATED := null;

V_ROWS_DELETED := null;
--
---------------------------OAS ADD------------------------------

INSERT
  /*+ ENABLE_PARALLEL_DML APPEND */
  INTO BDR_DM.TEMP_RIA_DCM_WORK_TBL
SELECT
  /*+ PARALLEL(8) */
  BL.BLR_RN,
  BL.PRDCT_EFF_DT,
  BL.INSURED_PLAN_EFFECTIVE_DATE,
  BL.DCM_SIGNATURE_DATE,
  BL.INDIVIDUAL_ID,
  BL.PREMIUM_DUE_DATE,
  BL.INSURED_PLAN_ID,
  CASE
    WHEN ORIG_INSPLAN.INSURED_PLAN_ID IS NULL THEN BL.INSURED_PLAN_ID
    ELSE ORIG_INSPLAN.INSURED_PLAN_ID
  END AS DCM_INSUREDPLANID,
  CASE
    WHEN ORIG_INSPLAN.INSURED_PLAN_ID IS NULL THEN BL.INSURED_PLAN_EFFECTIVE_DATE
    ELSE ORIG_INSPLAN.INSURED_PLAN_EFFECTIVE_DATE
  END AS DCM_INSUREDPLANEFFECTIVEDATE,
  CASE
    WHEN ORIG_INSPLAN.INSURED_PLAN_ID IS NULL THEN BL.PLAN_CD
    ELSE ORIG_INSPLAN.PLAN_CD
  END AS DCM_PLANCD,
  CASE
    WHEN ORIG_INSPLAN.INSURED_PLAN_ID IS NULL THEN BL.SELLING_AGENT
    ELSE ORIG_INSPLAN.SELLING_AGENT
  END AS DCM_DERIVED_COMPAS_AGENT,
  CASE
    WHEN BL.PRODUCT_GROUP <> ''Med Supp'' THEN ''-2''
    WHEN BL.PRODUCT_GROUP = ''Med Supp''
    AND BL.PLAN_GROUP LIKE ''%Rider%'' THEN ''-2''
    ELSE BL.DCM_WRITING_AGENT
  END AS DCM_WRITING_AGENT
FROM
  BDR_DM.TEMP_RIA_BL_REBUILD_DCM_WRT_AGT BL
  LEFT OUTER JOIN BDR_DM.TEMP_RIA_BL_REBUILD_FILTERED ORIG_INSPLAN ON BL.INDIVIDUAL_ID = ORIG_INSPLAN.INDIVIDUAL_ID
  AND bl.PRDCT_EFF_DT = ORIG_INSPLAN.PRDCT_EFF_DT
  AND BL.PRODUCT_GROUP = ORIG_INSPLAN.PRODUCT_GROUP;

---------------------------OAS ADD------------------------------
--
V_LAST_QUERY_ID := (
    SELECT
        LAST_QUERY_ID()
);

V_ROWS_INSERTED := (
    SELECT
        *
    FROM
        TABLE (RESULT_SCAN (:V_LAST_QUERY_ID))
);

INSERT INTO
    UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (
        APPLICATION,
        WORKFLOW_NAME,
        TABLE_NAME,
        BATCH_ID,
        STATUS,
        STEP,
        SEQ,
        ROWS_INSERTED,
        ROWS_UPDATED,
        ROWS_DELETED,
        STEP_START_DATETIME,
        STEP_END_DATETIME
    )
VALUES
    (
        :APPLICATION,
        :WORKFLOW_NAME,
        :OBJECT_NAME,
        :V_BATCH_ID,
        ''COMPLETE'',
        :V_STEP_NAME,
        :V_STEP_SEQ,
        :V_ROWS_INSERTED,
        :V_ROWS_UPDATED,
        :V_ROWS_DELETED,
        :V_STEP_START_TIME,
        CURRENT_TIMESTAMP()
    );
--
---------------------------OAS ADD------------------------------

---------------------------OAS DELETE---------------------------
--
/*
V_ROWS_AFFTD := SQL % ROWCOUNT;

COMMIT;

DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'', ''TEMP_RIA_DCM_WORK_TBL'');

--DBMS_STATS.GATHER_TABLE_STATS (ownname => ''DM'',tabname => ''TEMP_RIA_DCM_WORK_TBL'',partname => NULL,estimate_percent => 10, DEGREE => 4, granularity => ''ALL'', method_opt => ''FOR ALL COLUMNS SIZE 1'',CASCADE => TRUE);
INSERT INTO
  ETL.ETL_DETAIL_LOAD_INFO (
    APPLICATION,
    ETL_BATCH_ID,
    ETL_PROC_NAME,
    ACTION,
    STEP_INFO,
    ROWS_AFFECTED,
    ETL_DATETIME
  )
VALUES
  (
    ''DERIVATIVE PREMIUM 2'',
    V_BTCH_ID,
    V_PROC_NAME,
    ''INSERT'',
    ''INSERT INTO TEMP_RIA_DCM_WORK_TBL'',
    V_ROWS_AFFTD,
    SYSTIMESTAMP
  );

COMMIT;

BEGIN EXECUTE IMMEDIATE ''CREATE INDEX INDX_WRK_RIA_PREMIUM_DATA_A01 ON WRK_RIA_PREMIUM_DATA_BL_REBUILD (PRODUCT_GROUP,CERT_ACTV_LVL_3_TXT) PARALLEL 16'';

EXECUTE IMMEDIATE ''ALTER INDEX INDX_WRK_RIA_PREMIUM_DATA_A01 NOPARALLEL'';

EXCEPTION
WHEN OTHERS THEN null;

END;
*/
--
---------------------------OAS DELETE---------------------------

---------------------------OAS ADD------------------------------
--
V_STEP_NAME := ''TARGET - MERGE TEMP_RIA_DCM_WORK_TBL'';

V_STEP_SEQ := V_STEP_SEQ + 1;

V_STEP_START_TIME := (
    SELECT
        CURRENT_TIMESTAMP()
);

V_ROWS_INSERTED := null;

V_ROWS_UPDATED := null;

V_ROWS_DELETED := null;
--
---------------------------OAS ADD------------------------------

MERGE
/*+ ENABLE_PARALLEL_DML PARALLEL(8) */
INTO BDR_DM.TEMP_RIA_DCM_WORK_TBL BL USING (
    SELECT
        /*+ parallel(8) */
        NVL(SEL.SELLING_AGENT, ''-1'') AS WRITING_AGENT,
        SEL.CURRENT_SIGNATURE_DATE,
        PBL.INSURED_PLAN_ID,
        PBL.INSURED_PLAN_EFFECTIVE_DATE,
        PBL.PLAN_CD,
        SEL.SELLING_AGENT,
        PBL.BLR_RN
    FROM
        (
            SELECT
                INSURED_PLAN_EFFECTIVE_DATE,
                PLAN_CD,
                BLR_RN,
                INSURED_PLAN_ID
            FROM
                BDR_DM.WRK_RIA_PREMIUM_DATA_BL_REBUILD PBL1
            WHERE
                INSURED_PLAN_ID IN (
                    SELECT
                        INSURED_PLAN_ID
                    FROM
                        BDR_DM.WRK_RIA_PREMIUM_DATA_BL_REBUILD PBL12
                    WHERE
                        PRODUCT_GROUP = ''Med Supp''
                        AND CERT_ACTV_LVL_3_TXT = ''PLAN CHANGE ADD''
                        AND PLAN_GROUP IN (
                            SELECT
                                DISTINCT PLN_GRP
                            FROM
                                BDR_CONF.D_PLN_BEN_MOD
                            WHERE
                                PLN_GRP NOT LIKE ''%Rider%''
                                AND PLN_GRP <> ''Default''
                        )
                        AND INSURED_PLAN_EFFECTIVE_DATE < TO_DATE(''01/01/2013'', ''MM/DD/YYYY'')
                )
        ) PBL
        LEFT OUTER JOIN BDR_DM.WRK_RIA_SELLING_AGENT SEL ON PBL.BLR_RN = SEL.BLR_RN
) INNER_QUERY ON (INNER_QUERY.BLR_RN = BL.BLR_RN)
WHEN MATCHED THEN
UPDATE
SET
    DCM_WRITING_AGENT = INNER_QUERY.WRITING_AGENT,
    DCM_SIGNATURE_DATE = INNER_QUERY.CURRENT_SIGNATURE_DATE,
    DCM_INSUREDPLANID = INNER_QUERY.INSURED_PLAN_ID,
    DCM_INSUREDPLANEFFECTIVEDATE = INNER_QUERY.INSURED_PLAN_EFFECTIVE_DATE,
    DCM_PLANCD = INNER_QUERY.PLAN_CD,
    DCM_DERIVED_COMPAS_AGENT = INNER_QUERY.SELLING_AGENT;

---------------------------OAS ADD------------------------------
--
V_LAST_QUERY_ID := (
    SELECT
        LAST_QUERY_ID()
);

V_ROWS_UPDATED := (
    SELECT
        $1
    FROM
        TABLE (RESULT_SCAN (:V_LAST_QUERY_ID))
);

INSERT INTO
    UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (
        APPLICATION,
        WORKFLOW_NAME,
        TABLE_NAME,
        BATCH_ID,
        STATUS,
        STEP,
        SEQ,
        ROWS_INSERTED,
        ROWS_UPDATED,
        ROWS_DELETED,
        STEP_START_DATETIME,
        STEP_END_DATETIME
    )
VALUES
    (
        :APPLICATION,
        :WORKFLOW_NAME,
        :OBJECT_NAME,
        :V_BATCH_ID,
        ''COMPLETE'',
        :V_STEP_NAME,
        :V_STEP_SEQ,
        :V_ROWS_INSERTED,
        :V_ROWS_UPDATED,
        :V_ROWS_DELETED,
        :V_STEP_START_TIME,
        CURRENT_TIMESTAMP()
    );
--
---------------------------OAS ADD------------------------------

---------------------------OAS DELETE---------------------------
--
/*
V_ROWS_AFFTD := SQL % ROWCOUNT;

COMMIT;

INSERT INTO
  ETL.ETL_DETAIL_LOAD_INFO (
    APPLICATION,
    ETL_BATCH_ID,
    ETL_PROC_NAME,
    ACTION,
    STEP_INFO,
    ROWS_AFFECTED,
    ETL_DATETIME
  )
VALUES
  (
    ''DERIVATIVE PREMIUM 2'',
    V_BTCH_ID,
    V_PROC_NAME,
    ''MERGE'',
    ''MERGE INTO TEMP_RIA_DCM_WORK_TBL '',
    V_ROWS_AFFTD,
    SYSTIMESTAMP
  );

COMMIT;
*/
--
---------------------------OAS DELETE---------------------------

---------------------------OAS ADD------------------------------
--
V_STEP_NAME := ''TARGET - MERGE TEMP_RIA_DCM_WORK_TBL'';

V_STEP_SEQ := V_STEP_SEQ + 1;

V_STEP_START_TIME := (
    SELECT
        CURRENT_TIMESTAMP()
);

V_ROWS_INSERTED := null;

V_ROWS_UPDATED := null;

V_ROWS_DELETED := null;
--
---------------------------OAS ADD------------------------------

MERGE
/*+ ENABLE_PARALLEL_DML PARALLEL(8) */
INTO BDR_DM.TEMP_RIA_DCM_WORK_TBL BL USING (
  WITH PLANGROUP AS (
    SELECT
      DISTINCT PLN_GRP
    FROM
      BDR_CONF.D_PLN_BEN_MOD
    WHERE
      PLN_GRP NOT LIKE ''%Rider%''
      AND PLN_GRP <> ''Default''
  ),
  PLANCHANGEADD AS (
    SELECT
      *
    FROM
      BDR_DM.WRK_RIA_PREMIUM_DATA_BL_REBUILD BL
    WHERE
      PRODUCT_GROUP = ''Med Supp''
      AND CERT_ACTV_LVL_3_TXT = ''PLAN CHANGE ADD''
      AND PLAN_GROUP IN (
        SELECT
          DISTINCT PLN_GRP
        FROM
          PLANGROUP
      )
      AND INSURED_PLAN_EFFECTIVE_DATE < TO_DATE(''01/01/2013'', ''MM/DD/YYYY'')
  ),
  TEMP1 AS (
    SELECT
      LAG(SEL.SELLING_AGENT, 1, ORG.ORIGINAL_SELLING_AGENT) OVER (
        PARTITION BY INDIVIDUAL_ID
        ORDER BY
          INSURED_PLAN_EFFECTIVE_DATE
      ) AS PREV_SELLING_AGENT,
      PCA.INDIVIDUAL_ID,
      PCA.INSURED_PLAN_ID,
      PCA.INSURED_PLAN_EFFECTIVE_DATE,
      PCA.PLAN_CD,
      SEL.SELLING_AGENT,
      ORG.ORIGINAL_SELLING_AGENT
    FROM
      PLANCHANGEADD PCA
      LEFT OUTER JOIN BDR_DM.WRK_RIA_SELLING_AGENT SEL ON PCA.BLR_RN = SEL.BLR_RN
      LEFT OUTER JOIN BDR_DM.WRK_RIA_ORIGINAL_SELLING_AGENT ORG ON PCA.BLR_RN = ORG.BLR_RN
  ),
  --SELECT * FROM TEMP1
  TEMP2 AS (
    SELECT
      PREV_SELLING_AGENT,
      INDIVIDUAL_ID,
      INSURED_PLAN_ID,
      INSURED_PLAN_EFFECTIVE_DATE,
      PLAN_CD,
      SELLING_AGENT,
      ORIGINAL_SELLING_AGENT,
      ROW_NUMBER() OVER (
        PARTITION BY INDIVIDUAL_ID
        ORDER BY
          INSURED_PLAN_EFFECTIVE_DATE DESC
      ) AS RN
    FROM
      TEMP1
    WHERE
      SELLING_AGENT <> PREV_SELLING_AGENT
  ),
  --SELECT * FROM TEMP2
  LATEST_PLANCHANGE AS (
    SELECT
      *
    FROM
      TEMP2
    WHERE
      RN = 1
  )
  SELECT
    /*+ parallel(8) */
    L.INSURED_PLAN_ID,
    L.INSURED_PLAN_EFFECTIVE_DATE,
    L.PLAN_CD,
    L.SELLING_AGENT,
    L.INDIVIDUAL_ID
  FROM
    LATEST_PLANCHANGE L
) L ON (
  BL.INDIVIDUAL_ID = L.INDIVIDUAL_ID
  AND BL.PRDCT_EFF_DT < TO_DATE(''1/1/2013'', ''MM/DD/YYYY'')
  AND BL.INSURED_PLAN_EFFECTIVE_DATE >= TO_DATE(''1/1/2013'', ''MM/DD/YYYY'')
  AND BL.DCM_WRITING_AGENT IS NULL
)
WHEN MATCHED THEN
UPDATE
SET
  BL.DCM_INSUREDPLANID = L.INSURED_PLAN_ID,
  BL.DCM_INSUREDPLANEFFECTIVEDATE = L.INSURED_PLAN_EFFECTIVE_DATE,
  BL.DCM_PLANCD = L.PLAN_CD,
  BL.DCM_DERIVED_COMPAS_AGENT = L.SELLING_AGENT;

---------------------------OAS ADD------------------------------
--
V_LAST_QUERY_ID := (
    SELECT
        LAST_QUERY_ID()
);

V_ROWS_UPDATED := (
    SELECT
        $1
    FROM
        TABLE (RESULT_SCAN (:V_LAST_QUERY_ID))
);

INSERT INTO
    UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (
        APPLICATION,
        WORKFLOW_NAME,
        TABLE_NAME,
        BATCH_ID,
        STATUS,
        STEP,
        SEQ,
        ROWS_INSERTED,
        ROWS_UPDATED,
        ROWS_DELETED,
        STEP_START_DATETIME,
        STEP_END_DATETIME
    )
VALUES
    (
        :APPLICATION,
        :WORKFLOW_NAME,
        :OBJECT_NAME,
        :V_BATCH_ID,
        ''COMPLETE'',
        :V_STEP_NAME,
        :V_STEP_SEQ,
        :V_ROWS_INSERTED,
        :V_ROWS_UPDATED,
        :V_ROWS_DELETED,
        :V_STEP_START_TIME,
        CURRENT_TIMESTAMP()
    );
--
---------------------------OAS ADD------------------------------

---------------------------OAS DELETE---------------------------
--
/*
V_ROWS_AFFTD := SQL % ROWCOUNT;

COMMIT;

INSERT INTO
  ETL.ETL_DETAIL_LOAD_INFO (
    APPLICATION,
    ETL_BATCH_ID,
    ETL_PROC_NAME,
    ACTION,
    STEP_INFO,
    ROWS_AFFECTED,
    ETL_DATETIME
  )
VALUES
  (
    ''DERIVATIVE PREMIUM 2'',
    V_BTCH_ID,
    V_PROC_NAME,
    ''MERGE'',
    ''MERGE INTO TEMP_RIA_DCM_WORK_TBL '',
    V_ROWS_AFFTD,
    SYSTIMESTAMP
  );

COMMIT;
*/
--
---------------------------OAS DELETE---------------------------

---------------------------OAS ADD------------------------------
--
V_STEP_NAME := ''TARGET - INSERT TEMP_RIA_DCM'';

V_STEP_SEQ := V_STEP_SEQ + 1;

V_STEP_START_TIME := (
    SELECT
        CURRENT_TIMESTAMP()
);

V_ROWS_INSERTED := null;

V_ROWS_UPDATED := null;

V_ROWS_DELETED := null;
--
---------------------------OAS ADD------------------------------

INSERT
  /*+ ENABLE_PARALLEL_DML APPEND */
  INTO BDR_DM.TEMP_RIA_DCM WITH AARP_MS AS (
    SELECT
      TRANS_ID,
      MBR_POL_ID,
      M_R_PRDCT,
      M_R_PRDCT_CATGY,
      MBR_APPL_SGN_DT,
      MBR_POL_EFF_DT,
      ADD_MONTHS(MBR_POL_REN_DT, -1) AS MBR_POL_REN_DT,
      AGT_COMM_CR,
      AGT_COMM_AMT,
      WRT_AGT_ID,
      -- added 12/7/2016
      AGT_HIER_LVL,
      LGR_ITM_AGT_ID,
      AGT_COMM_PAY_PTY_ID,
      AGT_GRNH_IND,
      TRANS_DT,
      LGR_ITM_DT,
      PAY_ACCT_UPDT_DT,
      RLSE_PAY_DT,
      POL_PLN_CD
    FROM
      BDR_DCM.DCM_COMM_PD DCM
      INNER JOIN SRC_COMPAS_D.POLICY P ON DCM.MBR_POL_ID = P.POLICY_NUMBER
    WHERE
      DCM.M_R_PRDCT_CATGY IN (''AARP MS'', ''MS'')
      AND POL_TRANS_TYP IN (''New'', ''Premium'', ''Renewal'')
      AND P.INDIVIDUAL_ID IN (
        SELECT
          DISTINCT INDIVIDUAL_ID
        FROM
          BDR_DM.TEMP_RIA_DCM_WORK_TBL
        WHERE
          DCM_WRITING_AGENT IS NULL
      )
  ),
  --SELECT * FROM aarp_ms
  DCM_AGGREGATE1 AS (
    SELECT
      TRANS_ID
    FROM
      AARP_MS
    GROUP BY
      TRANS_ID
    HAVING
      SUM(AGT_COMM_CR) <> 0
  ),
  --SELECT * FROM DCM_AGGREGATE1
  DCM_AGGREGATE2 AS (
    SELECT
      AARP_MS.MBR_POL_ID,
      AARP_MS.MBR_POL_EFF_DT,
      AARP_MS.POL_PLN_CD,
      AARP_MS.MBR_POL_REN_DT,
      MIN(
        CASE
          WHEN AARP_MS.AGT_HIER_LVL IN (
            ''-1'',
            ''1'',
            ''20'',
            ''30'',
            ''40'',
            ''50'',
            ''60'',
            ''70'',
            ''80'',
            ''90''
          ) THEN AARP_MS.AGT_HIER_LVL
          ELSE ''0''
        END
      ) AS MIN_AGT_HIER_LVL
    FROM
      DCM_AGGREGATE1 DCM_1
      INNER JOIN AARP_MS AARP_MS ON AARP_MS.TRANS_ID = DCM_1.TRANS_ID
    GROUP BY
      AARP_MS.MBR_POL_ID,
      AARP_MS.MBR_POL_EFF_DT,
      AARP_MS.POL_PLN_CD,
      AARP_MS.MBR_POL_REN_DT
  ),
  --SELECT * FROM DCM_AGGREGATE2
  DCM_AGGREGATE2_1 AS (
    SELECT
      AARP_MS.MBR_POL_ID,
      AARP_MS.M_R_PRDCT,
      AARP_MS.M_R_PRDCT_CATGY,
      AARP_MS.MBR_APPL_SGN_DT,
      AARP_MS.MBR_POL_EFF_DT,
      AARP_MS.POL_PLN_CD,
      AARP_MS.MBR_POL_REN_DT,
      AARP_MS.WRT_AGT_ID,
      AARP_MS.TRANS_DT,
      AARP_MS.TRANS_ID
    FROM
      DCM_AGGREGATE2 DCM_AGG2
      INNER JOIN AARP_MS AARP_MS ON DCM_AGG2.MBR_POL_ID = AARP_MS.MBR_POL_ID
      AND DCM_AGG2.MBR_POL_EFF_DT = AARP_MS.MBR_POL_EFF_DT
      AND DCM_AGG2.POL_PLN_CD = AARP_MS.POL_PLN_CD
      AND DCM_AGG2.MBR_POL_REN_DT = AARP_MS.MBR_POL_REN_DT
      AND DCM_AGG2.MIN_AGT_HIER_LVL = (
        CASE
          WHEN AARP_MS.AGT_HIER_LVL IN (
            ''-1'',
            ''1'',
            ''20'',
            ''30'',
            ''40'',
            ''50'',
            ''60'',
            ''70'',
            ''80'',
            ''90''
          ) THEN AARP_MS.AGT_HIER_LVL
          ELSE ''0''
        END
      )
      INNER JOIN DCM_AGGREGATE1 DCM_AGG1 ON DCM_AGG1.TRANS_ID = AARP_MS.TRANS_ID
  ),
  --SELECT * FROM DCM_AGGREGATE2_1
  DCM_AGGREGATE2_2 AS (
    SELECT
      MBR_POL_ID,
      M_R_PRDCT,
      M_R_PRDCT_CATGY,
      MBR_APPL_SGN_DT,
      MBR_POL_EFF_DT,
      POL_PLN_CD,
      MBR_POL_REN_DT,
      WRT_AGT_ID,
      TRANS_DT,
      TRANS_ID,
      ROW_NUMBER () OVER (
        PARTITION BY MBR_POL_ID,
        MBR_POL_EFF_DT,
        POL_PLN_CD,
        -- Added 12/7/2016
        MBR_POL_REN_DT
        ORDER BY
          TRANS_DT DESC
      ) AS R_NUM
    FROM
      DCM_AGGREGATE2_1
  )
SELECT
  /*+ parallel(8) */
  *
FROM
  DCM_AGGREGATE2_2
WHERE
  R_NUM = 1;

---------------------------OAS ADD------------------------------
--
V_LAST_QUERY_ID := (
    SELECT
        LAST_QUERY_ID()
);

V_ROWS_INSERTED := (
    SELECT
        *
    FROM
        TABLE (RESULT_SCAN (:V_LAST_QUERY_ID))
);

INSERT INTO
    UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (
        APPLICATION,
        WORKFLOW_NAME,
        TABLE_NAME,
        BATCH_ID,
        STATUS,
        STEP,
        SEQ,
        ROWS_INSERTED,
        ROWS_UPDATED,
        ROWS_DELETED,
        STEP_START_DATETIME,
        STEP_END_DATETIME
    )
VALUES
    (
        :APPLICATION,
        :WORKFLOW_NAME,
        :OBJECT_NAME,
        :V_BATCH_ID,
        ''COMPLETE'',
        :V_STEP_NAME,
        :V_STEP_SEQ,
        :V_ROWS_INSERTED,
        :V_ROWS_UPDATED,
        :V_ROWS_DELETED,
        :V_STEP_START_TIME,
        CURRENT_TIMESTAMP()
    );
--
---------------------------OAS ADD------------------------------

---------------------------OAS DELETE---------------------------
--
/*
V_ROWS_AFFTD := SQL % ROWCOUNT;

COMMIT;

DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'', ''TEMP_RIA_DCM'');

--DBMS_STATS.GATHER_TABLE_STATS (ownname => ''DM'',tabname => ''TEMP_RIA_DCM'',partname => NULL,estimate_percent => 10, DEGREE => 4, granularity => ''ALL'', method_opt => ''FOR ALL COLUMNS SIZE 1'',CASCADE => TRUE);
INSERT INTO
  ETL.ETL_DETAIL_LOAD_INFO (
    APPLICATION,
    ETL_BATCH_ID,
    ETL_PROC_NAME,
    ACTION,
    STEP_INFO,
    ROWS_AFFECTED,
    ETL_DATETIME
  )
VALUES
  (
    ''DERIVATIVE PREMIUM 2'',
    V_BTCH_ID,
    V_PROC_NAME,
    ''INSERT'',
    ''INSERT INTO TEMP_RIA_DCM '',
    V_ROWS_AFFTD,
    SYSTIMESTAMP
  );

COMMIT;
*/
--
---------------------------OAS DELETE---------------------------

---------------------------OAS ADD------------------------------
--
V_STEP_NAME := ''TARGET - MERGE TEMP_RIA_DCM'';

V_STEP_SEQ := V_STEP_SEQ + 1;

V_STEP_START_TIME := (
    SELECT
        CURRENT_TIMESTAMP()
);

V_ROWS_INSERTED := null;

V_ROWS_UPDATED := null;

V_ROWS_DELETED := null;
--
---------------------------OAS ADD------------------------------

--SELECT * FROM DM.TEMP_RIA_DCM
MERGE
/*+ ENABLE_PARALLEL_DML PARALLEL(8) */
INTO BDR_DM.TEMP_RIA_DCM DCM USING (
  WITH AARP_MS AS (
    SELECT
      TRANS_ID,
      MBR_POL_ID,
      M_R_PRDCT,
      M_R_PRDCT_CATGY,
      MBR_APPL_SGN_DT,
      MBR_POL_EFF_DT,
      ADD_MONTHS(MBR_POL_REN_DT, -1) AS MBR_POL_REN_DT,
      AGT_COMM_CR,
      AGT_COMM_AMT,
      WRT_AGT_ID,
      -- added 12/7/2016
      AGT_HIER_LVL,
      LGR_ITM_AGT_ID,
      AGT_COMM_PAY_PTY_ID,
      AGT_GRNH_IND,
      TRANS_DT,
      LGR_ITM_DT,
      PAY_ACCT_UPDT_DT,
      RLSE_PAY_DT,
      POL_PLN_CD
    FROM
      BDR_DCM.DCM_COMM_PD DCM
      INNER JOIN SRC_COMPAS_D.POLICY P ON DCM.MBR_POL_ID = P.POLICY_NUMBER
    WHERE
      DCM.M_R_PRDCT_CATGY IN (''AARP MS'', ''MS'')
      AND POL_TRANS_TYP IN (''New'', ''Premium'', ''Renewal'')
      AND P.INDIVIDUAL_ID IN (
        SELECT
          DISTINCT INDIVIDUAL_ID
        FROM
          BDR_DM.TEMP_RIA_DCM_WORK_TBL
        WHERE
          DCM_WRITING_AGENT IS NULL
      )
  ),
  --SELECT * FROM aarp_ms
  DCM_AGGREGATE1 AS (
    SELECT
      TRANS_ID
    FROM
      AARP_MS
    GROUP BY
      TRANS_ID
    HAVING
      SUM(AGT_COMM_CR) <> 0
  ),
  --SELECT * FROM DCM_AGGREGATE1
  DCM_AGGREGATE2 AS (
    SELECT
      AARP_MS.MBR_POL_ID,
      AARP_MS.MBR_POL_EFF_DT,
      AARP_MS.POL_PLN_CD,
      AARP_MS.MBR_POL_REN_DT,
      MIN(
        CASE
          WHEN AARP_MS.AGT_HIER_LVL IN (
            ''-1'',
            ''1'',
            ''20'',
            ''30'',
            ''40'',
            ''50'',
            ''60'',
            ''70'',
            ''80'',
            ''90''
          ) THEN AARP_MS.AGT_HIER_LVL
          ELSE ''0''
        END
      ) AS MIN_AGT_HIER_LVL
    FROM
      DCM_AGGREGATE1 DCM_1
      INNER JOIN AARP_MS AARP_MS ON AARP_MS.TRANS_ID = DCM_1.TRANS_ID
    GROUP BY
      AARP_MS.MBR_POL_ID,
      AARP_MS.MBR_POL_EFF_DT,
      AARP_MS.POL_PLN_CD,
      AARP_MS.MBR_POL_REN_DT
  ),
  --SELECT * FROM DCM_AGGREGATE2
  DCM_AGGREGATE2_1 AS (
    SELECT
      AARP_MS.MBR_POL_ID,
      AARP_MS.M_R_PRDCT,
      AARP_MS.M_R_PRDCT_CATGY,
      AARP_MS.MBR_APPL_SGN_DT,
      AARP_MS.MBR_POL_EFF_DT,
      AARP_MS.POL_PLN_CD,
      AARP_MS.MBR_POL_REN_DT,
      AARP_MS.WRT_AGT_ID,
      AARP_MS.TRANS_DT,
      AARP_MS.TRANS_ID
    FROM
      DCM_AGGREGATE2 DCM_AGG2
      INNER JOIN AARP_MS AARP_MS ON DCM_AGG2.MBR_POL_ID = AARP_MS.MBR_POL_ID
      AND DCM_AGG2.MBR_POL_EFF_DT = AARP_MS.MBR_POL_EFF_DT
      AND DCM_AGG2.POL_PLN_CD = AARP_MS.POL_PLN_CD
      AND DCM_AGG2.MBR_POL_REN_DT = AARP_MS.MBR_POL_REN_DT
      AND DCM_AGG2.MIN_AGT_HIER_LVL = (
        CASE
          WHEN AARP_MS.AGT_HIER_LVL IN (
            ''-1'',
            ''1'',
            ''20'',
            ''30'',
            ''40'',
            ''50'',
            ''60'',
            ''70'',
            ''80'',
            ''90''
          ) THEN AARP_MS.AGT_HIER_LVL
          ELSE ''0''
        END
      )
      INNER JOIN DCM_AGGREGATE1 DCM_AGG1 ON DCM_AGG1.TRANS_ID = AARP_MS.TRANS_ID
  ),
  --SELECT * FROM DCM_AGGREGATE2_1
  DCM_AGGREGATE2_2 AS (
    SELECT
      MBR_POL_ID,
      M_R_PRDCT,
      M_R_PRDCT_CATGY,
      MBR_APPL_SGN_DT,
      MBR_POL_EFF_DT,
      POL_PLN_CD,
      MBR_POL_REN_DT,
      WRT_AGT_ID,
      TRANS_DT,
      TRANS_ID,
      ROW_NUMBER () OVER (
        PARTITION BY MBR_POL_ID,
        MBR_POL_EFF_DT,
        POL_PLN_CD,
        -- Added 12/7/2016
        MBR_POL_REN_DT
        ORDER BY
          TRANS_DT DESC
      ) AS R_NUM
    FROM
      DCM_AGGREGATE2_1
  ),
  --SELECT * FROM DCM_AGGREGATE2_2
  DCM_AGGREGATE3_2 AS (
    SELECT
      *
    FROM
      DCM_AGGREGATE2_2
    WHERE
      R_NUM = 2
  ),
  DCM_AGGREGATE3_3 AS (
    SELECT
      DCM.MBR_POL_ID,
      DCM.M_R_PRDCT,
      DCM.M_R_PRDCT_CATGY,
      DCM.MBR_APPL_SGN_DT,
      DCM.MBR_POL_EFF_DT,
      DCM.POL_PLN_CD,
      DCM.MBR_POL_REN_DT,
      DCM.WRT_AGT_ID,
      DCM.TRANS_DT,
      DCM.TRANS_ID,
      DCM.R_NUM,
      DCM_2.WRT_AGT_ID AS UPD_DCM_WRT_AGT_ID,
      DCM_2.MBR_APPL_SGN_DT AS UPD_DCM_MBR_APPL_SGN_DT,
      DCM_2.R_NUM AS RN2
    FROM
      BDR_DM.TEMP_RIA_DCM DCM
      INNER JOIN DCM_AGGREGATE3_2 DCM_3 ON DCM.MBR_POL_ID = DCM_3.MBR_POL_ID
      AND DCM.MBR_POL_EFF_DT = DCM_3.MBR_POL_EFF_DT
      AND DCM.POL_PLN_CD = DCM_3.POL_PLN_CD
      AND DCM.MBR_POL_REN_DT = DCM_3.MBR_POL_REN_DT
      INNER JOIN DCM_AGGREGATE2_2 DCM_2 ON DCM.MBR_POL_ID = DCM_2.MBR_POL_ID
      AND DCM.MBR_POL_EFF_DT = DCM_2.MBR_POL_EFF_DT
      AND DCM.POL_PLN_CD = DCM_2.POL_PLN_CD
      AND DCM.MBR_POL_REN_DT = DCM_2.MBR_POL_REN_DT
      AND DCM.TRANS_DT = DCM_2.TRANS_DT
  ),
  --SELECT * FROM DCM_AGGREGATE3_3
  CTE AS (
    SELECT
      COUNT (DISTINCT UPD_DCM_WRT_AGT_ID) AS COUNT_WRT_AGT_ID,
      COUNT(DISTINCT UPD_DCM_MBR_APPL_SGN_DT) AS COUNT_MBR_APPL_SGN_DT,
      MBR_POL_ID,
      MBR_POL_EFF_DT,
      POL_PLN_CD,
      MBR_POL_REN_DT
    FROM
      DCM_AGGREGATE3_3
    GROUP BY
      MBR_APPL_SGN_DT,
      MBR_POL_ID,
      MBR_POL_EFF_DT,
      POL_PLN_CD,
      MBR_POL_REN_DT
  ),
  UPD_DCM_AGGREGATE AS (
    SELECT
      *
    FROM
      CTE
    WHERE
      COUNT_WRT_AGT_ID > 1
      OR COUNT_MBR_APPL_SGN_DT > 1
  )
  SELECT
    /*+ parallel(8) */
    *
  FROM
    UPD_DCM_AGGREGATE
) UPD ON (
  DCM.MBR_POL_ID = UPD.MBR_POL_ID
  AND DCM.POL_PLN_CD = UPD.POL_PLN_CD
  AND DCM.MBR_POL_EFF_DT = UPD.MBR_POL_EFF_DT
  AND DCM.MBR_POL_REN_DT = UPD.MBR_POL_REN_DT
)
WHEN MATCHED THEN
UPDATE
SET
  DCM.WRT_AGT_ID = ''-1'',
  DCM.MBR_APPL_SGN_DT = TO_DATE(''12/31/9999'', ''MM/DD/YYYY'');

---------------------------OAS ADD------------------------------
--
V_LAST_QUERY_ID := (
    SELECT
        LAST_QUERY_ID()
);

V_ROWS_UPDATED := (
    SELECT
        $1
    FROM
        TABLE (RESULT_SCAN (:V_LAST_QUERY_ID))
);

INSERT INTO
    UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (
        APPLICATION,
        WORKFLOW_NAME,
        TABLE_NAME,
        BATCH_ID,
        STATUS,
        STEP,
        SEQ,
        ROWS_INSERTED,
        ROWS_UPDATED,
        ROWS_DELETED,
        STEP_START_DATETIME,
        STEP_END_DATETIME
    )
VALUES
    (
        :APPLICATION,
        :WORKFLOW_NAME,
        :OBJECT_NAME,
        :V_BATCH_ID,
        ''COMPLETE'',
        :V_STEP_NAME,
        :V_STEP_SEQ,
        :V_ROWS_INSERTED,
        :V_ROWS_UPDATED,
        :V_ROWS_DELETED,
        :V_STEP_START_TIME,
        CURRENT_TIMESTAMP()
    );
--
---------------------------OAS ADD------------------------------

---------------------------OAS DELETE---------------------------
--
/*
V_ROWS_AFFTD := SQL % ROWCOUNT;

COMMIT;

INSERT INTO
  ETL.ETL_DETAIL_LOAD_INFO (
    APPLICATION,
    ETL_BATCH_ID,
    ETL_PROC_NAME,
    ACTION,
    STEP_INFO,
    ROWS_AFFECTED,
    ETL_DATETIME
  )
VALUES
  (
    ''DERIVATIVE PREMIUM 2'',
    V_BTCH_ID,
    V_PROC_NAME,
    ''MERGE'',
    ''MERGE INTO TEMP_RIA_DCM '',
    V_ROWS_AFFTD,
    SYSTIMESTAMP
  );

COMMIT;
*/
--
---------------------------OAS DELETE---------------------------

---------------------------OAS ADD------------------------------
--
V_STEP_NAME := ''TARGET - INSERT WRK_RIA_DCM_WRITING_AGENT'';

V_STEP_SEQ := V_STEP_SEQ + 1;

V_STEP_START_TIME := ( SELECT CURRENT_TIMESTAMP());

V_ROWS_INSERTED := null;

V_ROWS_UPDATED := null;

V_ROWS_DELETED := null;
--
---------------------------OAS ADD------------------------------

INSERT
  /*+ ENABLE_PARALLEL_DML APPEND */
  INTO BDR_DM.WRK_RIA_DCM_WRITING_AGENT (
    BLR_RN,
    DCM_WRITING_AGENT,
    DCM_SIGNATURE_DATE,
    AGT_DCM_WRT_SKEY
  ) WITH DCM1 AS (
    SELECT
      MBR_POL_ID,
      M_R_PRDCT_CATGY,
      MBR_APPL_SGN_DT,
      MBR_POL_EFF_DT,
      POL_PLN_CD,
      MBR_POL_REN_DT,
      WRT_AGT_ID,
      ROW_NUMBER() OVER(
        PARTITION BY MBR_POL_ID,
        MBR_POL_EFF_DT,
        POL_PLN_CD
        ORDER BY
          MBR_POL_REN_DT DESC
      ) AS RN
    FROM
      BDR_DM.TEMP_RIA_DCM
  ),
  --SELECT * FROM DCM1
  DCM2 AS (
    SELECT
      *
    FROM
      DCM1
    WHERE
      RN = 1
  ),
  --SELECT * FROM DCM2
  MATCHED AS (
    SELECT
      BL.BLR_RN,
      DCM.WRT_AGT_ID,
      DCM.MBR_APPL_SGN_DT,
      BL.INSURED_PLAN_ID,
      BL.PREMIUM_DUE_DATE
    FROM
      BDR_DM.TEMP_RIA_DCM_WORK_TBL BL
      INNER JOIN SRC_COMPAS_D.POLICY P ON BL.INDIVIDUAL_ID = P.INDIVIDUAL_ID
      INNER JOIN BDR_DM.TEMP_RIA_DCM DCM ON P.POLICY_NUMBER = DCM.MBR_POL_ID
      AND BL.DCM_PLANCD = DCM.POL_PLN_CD
      AND BL.PREMIUM_DUE_DATE = DCM.MBR_POL_REN_DT
      AND BL.DCM_INSUREDPLANEFFECTIVEDATE = DCM.MBR_POL_EFF_DT
    WHERE
      BL.DCM_WRITING_AGENT IS NULL
  ),
  --SELECT * FROM MATCHED
  COMMISSIONED AS (
    SELECT
      BL.BLR_RN,
      DCM.WRT_AGT_ID,
      DCM.MBR_APPL_SGN_DT,
      BL.INSURED_PLAN_ID,
      BL.PREMIUM_DUE_DATE
    FROM
      BDR_DM.TEMP_RIA_DCM_WORK_TBL BL
      INNER JOIN SRC_COMPAS_D.POLICY P ON BL.INDIVIDUAL_ID = P.INDIVIDUAL_ID
      INNER JOIN DCM2 DCM ON P.POLICY_NUMBER = DCM.MBR_POL_ID
      AND BL.DCM_PLANCD = DCM.POL_PLN_CD
      AND BL.PREMIUM_DUE_DATE > DCM.MBR_POL_REN_DT
      AND BL.DCM_INSUREDPLANEFFECTIVEDATE = DCM.MBR_POL_EFF_DT
      LEFT OUTER JOIN MATCHED M ON BL.BLR_RN = M.BLR_RN
    WHERE
      BL.DCM_WRITING_AGENT IS NULL
      AND M.BLR_RN IS NULL
  ),
  --SELECT * FROM COMMISSIONED
  NOT_FOUND_DCM AS (
    SELECT
      BL.BLR_RN,
      CASE
        WHEN NVL(DCM_DERIVED_COMPAS_AGENT, ''-1'') <> ''-1'' THEN ''-2''
        ELSE ''-1''
      END AS DCM_AGENT,
      BL.INSURED_PLAN_ID,
      BL.PREMIUM_DUE_DATE
    FROM
      BDR_DM.TEMP_RIA_DCM_WORK_TBL BL
      LEFT OUTER JOIN MATCHED B ON BL.BLR_RN = B.BLR_RN
      LEFT OUTER JOIN COMMISSIONED C ON BL.BLR_RN = C.BLR_RN
      LEFT OUTER JOIN SRC_COMPAS_D.POLICY P ON BL.INDIVIDUAL_ID = P.INDIVIDUAL_ID
      LEFT OUTER JOIN BDR_DM.TEMP_RIA_DCM DCM ON P.POLICY_NUMBER = DCM.MBR_POL_ID
      AND BL.DCM_PLANCD = DCM.POL_PLN_CD
      AND BL.PREMIUM_DUE_DATE = DCM.MBR_POL_REN_DT
      AND BL.DCM_INSUREDPLANEFFECTIVEDATE = DCM.MBR_POL_EFF_DT
    WHERE
      BL.DCM_WRITING_AGENT IS NULL
      AND B.BLR_RN IS NULL
      AND C.BLR_RN IS NULL
  ),
  --SELECT * FROM NOT_FOUND_DCM
  DCM_FINAL AS (
    SELECT
      BLR_RN,
      DCM_WRITING_AGENT,
      DCM_SIGNATURE_DATE,
      INSURED_PLAN_ID,
      PREMIUM_DUE_DATE
    FROM
      BDR_DM.TEMP_RIA_DCM_WORK_TBL
    WHERE
      DCM_WRITING_AGENT IS NOT NULL
    UNION
    ALL
    SELECT
      BLR_RN,
      WRT_AGT_ID,
      MBR_APPL_SGN_DT,
      INSURED_PLAN_ID,
      PREMIUM_DUE_DATE
    FROM
      MATCHED
    UNION
    ALL
    SELECT
      BLR_RN,
      WRT_AGT_ID,
      MBR_APPL_SGN_DT,
      INSURED_PLAN_ID,
      PREMIUM_DUE_DATE
    FROM
      COMMISSIONED
    UNION
    ALL
    SELECT
      BLR_RN,
      DCM_AGENT,
      NULL,
      INSURED_PLAN_ID,
      PREMIUM_DUE_DATE
    FROM
      NOT_FOUND_DCM
  ),
  --SELECT * FROM DCM_FINAL
  UPDATE_DCM_Agent_Temp AS (
    SELECT
      BLR.BLR_RN,
      DCM_AGT.D_AGT_SK,
      BLR.INSURED_PLAN_ID,
      BLR.PREMIUM_DUE_DATE,
      BLR.DCM_WRITING_AGENT,
      BLR.DCM_SIGNATURE_DATE,
      DCM_AGT.ROW_EFF_STRT_DT,
      DCM_AGT.AGT_WRT_STRT_DT_ID,
      DCM_AGT.AGT_ID,
      CASE
        -- Removed +1 due to issue found during PAT 20Mar2018
        --      WHEN (BLR.DCM_SIGNATURE_DATE+1) BETWEEN TO_DATE(DCM_AGT.AGT_WRT_STRT_DT_ID,''YYYYMMDD'') AND TO_DATE(DCM_AGT.AGT_WRT_END_DT_ID,''YYYYMMDD'')
        WHEN (BLR.DCM_SIGNATURE_DATE) BETWEEN TO_DATE(TO_CHAR(DCM_AGT.AGT_WRT_STRT_DT_ID), ''YYYYMMDD'')
        AND TO_DATE(TO_CHAR(DCM_AGT.AGT_WRT_END_DT_ID), ''YYYYMMDD'') THEN 1
        ELSE 0
      END AS SIGNATURE_DT_MATCH_FL
    FROM
      DCM_FINAL BLR
      LEFT OUTER JOIN BDR_DM.TEMP_AGT DCM_AGT ON BLR.DCM_WRITING_AGENT = DCM_AGT.AGT_ID
    WHERE
      DCM_WRITING_AGENT NOT IN(''-2'', ''-1'')
  ),
  --SELECT * FROM UPDATE_DCM_Agent_Temp
  Matched_DCM_WRT_Agent AS (
    SELECT
      BLR_RN,
      BLR.DCM_WRITING_AGENT,
      BLR.DCM_SIGNATURE_DATE,
      D_AGT_SK AS AGT_DCM_WRT_SKEY
    FROM
      UPDATE_DCM_Agent_Temp BLR
    WHERE
      SIGNATURE_DT_MATCH_FL = 1
  ),
  --SELECT * FROM Matched_DCM_WRT_Agent
  UnMatched_DCM_WRT_Agent AS (
    SELECT
      BLR.BLR_RN,
      BLR.INSURED_PLAN_ID,
      BLR.PREMIUM_DUE_DATE,
      BLR.DCM_WRITING_AGENT,
      BLR.DCM_SIGNATURE_DATE,
      BLR.D_AGT_SK AS AGT_DCM_WRT_SKEY,
      BLR.AGT_WRT_STRT_DT_ID,
      BLR.ROW_EFF_STRT_DT
    FROM
      UPDATE_DCM_Agent_Temp BLR
      LEFT OUTER JOIN Matched_DCM_WRT_Agent WR2 ON BLR.BLR_RN = WR2.BLR_RN
    WHERE
      WR2.BLR_RN IS NULL
  ),
  --SELECT * FROM UnMatched_DCM_WRT_Agent
  CLOSEST_DCM_WRT AS (
    SELECT
      DCM_WRT.BLR_RN,
      DCM_WRT.DCM_WRITING_AGENT,
      DCM_WRT.DCM_SIGNATURE_DATE,
      --ROW_NUMBER() OVER (PARTITION BY DCM_WRT.InsuredPlanID, DCM_WRT.PremiumDueDate, DCM_WRT.DCM_WRITING_AGENT, DCM_WRT.DCM_SIGNATURE_DATE
      ROW_NUMBER() OVER (
        PARTITION BY BLR_RN
        ORDER BY
          ABS(
            DATEDIFF(''DD'', TO_TIMESTAMP(TO_CHAR(DCM_WRT.AGT_WRT_STRT_DT_ID), ''YYYYMMDD''), DCM_WRT.DCM_SIGNATURE_DATE)
          ),
          DCM_WRT.ROW_EFF_STRT_DT DESC
      ) AS RN,
      AGT_DCM_WRT_SKEY
    FROM
      UnMatched_DCM_WRT_Agent DCM_WRT
  ) -- SELECT * FROM CLOSEST_DCM_WRT
  -- INSERT INTO TARGET TABLE
SELECT
  /*+ parallel(8) */
  BLR_RN,
  DCM_WRITING_AGENT,
  DCM_SIGNATURE_DATE,
  NVL(AGT_DCM_WRT_SKEY, -1) AGT_DCM_WRT_SKEY
FROM
  CLOSEST_DCM_WRT
WHERE
  RN = 1
UNION
ALL
SELECT
  BLR_RN,
  DCM_WRITING_AGENT,
  DCM_SIGNATURE_DATE,
  AGT_DCM_WRT_SKEY
FROM
  Matched_DCM_WRT_Agent
UNION
ALL
SELECT
  BLR_RN,
  DCM_WRITING_AGENT,
  DCM_SIGNATURE_DATE,
  TO_NUMBER(DCM_WRITING_AGENT)
FROM
  DCM_FINAL
WHERE
  DCM_WRITING_AGENT IN (''-1'', ''-2'');

---------------------------OAS ADD------------------------------
--
V_LAST_QUERY_ID := (
    SELECT
        LAST_QUERY_ID()
);

V_ROWS_INSERTED := (
    SELECT
        *
    FROM
        TABLE (RESULT_SCAN (:V_LAST_QUERY_ID))
);

INSERT INTO
    UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (
        APPLICATION,
        WORKFLOW_NAME,
        TABLE_NAME,
        BATCH_ID,
        STATUS,
        STEP,
        SEQ,
        ROWS_INSERTED,
        ROWS_UPDATED,
        ROWS_DELETED,
        STEP_START_DATETIME,
        STEP_END_DATETIME
    )
VALUES
    (
        :APPLICATION,
        :WORKFLOW_NAME,
        :OBJECT_NAME,
        :V_BATCH_ID,
        ''COMPLETE'',
        :V_STEP_NAME,
        :V_STEP_SEQ,
        :V_ROWS_INSERTED,
        :V_ROWS_UPDATED,
        :V_ROWS_DELETED,
        :V_STEP_START_TIME,
        CURRENT_TIMESTAMP()
    );
--
---------------------------OAS ADD------------------------------

---------------------------OAS DELETE---------------------------
--
/*
V_ROWS_AFFTD := SQL % ROWCOUNT;

commit;

DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'', ''WRK_RIA_DCM_WRITING_AGENT'');
*/
--
---------------------------OAS DELETE---------------------------

---------------------------OAS ADD------------------------------
--
V_STEP_NAME := ''TARGET - DELETE WRK_RIA_DCM_WRITING_AGENT'';

V_STEP_SEQ := V_STEP_SEQ + 1;

V_STEP_START_TIME := (
    SELECT
        CURRENT_TIMESTAMP()
);

V_ROWS_INSERTED := null;

V_ROWS_UPDATED := null;

V_ROWS_DELETED := null;
--
---------------------------OAS ADD------------------------------

DELETE
/*+ enable_parallel_dml parallel(8) */
FROM
  BDR_DM.WRK_RIA_DCM_WRITING_AGENT
WHERE
  (BLR_RN, AGT_DCM_WRT_SKEY) in (
    SELECT
      DISTINCT BLR_RN,
      AGT_DCM_WRT_SKEY
    FROM
      (
        SELECT
          /*+ parallel(8) */
          BLR_RN,
          DCM_WRITING_AGENT,
          DCM_SIGNATURE_DATE,
          AGT_DCM_WRT_SKEY,
          ROW_NUMBER() OVER(
            PARTITION BY BLR_RN,
            DCM_WRITING_AGENT,
            DCM_SIGNATURE_DATE
            ORDER BY
              AGT_DCM_WRT_SKEY DESC
          ) RN
        FROM
          BDR_DM.WRK_RIA_DCM_WRITING_AGENT
      )
    WHERE
      RN > 1
  );

---------------------------OAS ADD------------------------------
--
V_LAST_QUERY_ID := (
    SELECT
        LAST_QUERY_ID()
);

V_ROWS_DELETED := (
    SELECT
        *
    FROM
        TABLE (RESULT_SCAN (:V_LAST_QUERY_ID))
);

INSERT INTO
    UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (
        APPLICATION,
        WORKFLOW_NAME,
        TABLE_NAME,
        BATCH_ID,
        STATUS,
        STEP,
        SEQ,
        ROWS_INSERTED,
        ROWS_UPDATED,
        ROWS_DELETED,
        STEP_START_DATETIME,
        STEP_END_DATETIME
    )
VALUES
    (
        :APPLICATION,
        :WORKFLOW_NAME,
        :OBJECT_NAME,
        :V_BATCH_ID,
        ''COMPLETE'',
        :V_STEP_NAME,
        :V_STEP_SEQ,
        :V_ROWS_INSERTED,
        :V_ROWS_UPDATED,
        :V_ROWS_DELETED,
        :V_STEP_START_TIME,
        CURRENT_TIMESTAMP()
    );
--
---------------------------OAS ADD------------------------------

---------------------------OAS DELETE---------------------------
--
/*
V_ROWS_AFFTD := SQL % ROWCOUNT;

commit;
*/
--
---------------------------OAS DELETE---------------------------

--delete /*+ enable_parallel_dml parallel(8) */ FROM DM.WRK_RIA_DCM_WRITING_AGENT
--   WHERE AGT_DCM_WRT_SKEY in (
--    SELECT AGT_DCM_WRT_SKEY FROM(SELECT /*+ parallel(8) */ BLR_RN,DCM_WRITING_AGENT,DCM_SIGNATURE_DATE,AGT_DCM_WRT_SKEY ,ROW_NUMBER() OVER(PARTITION BY BLR_RN,DCM_WRITING_AGENT,DCM_SIGNATURE_DATE
--              ORDER BY AGT_DCM_WRT_SKEY DESC) RN FROM  DM.WRK_RIA_DCM_WRITING_AGENT) WHERE RN>1);
--              V_ROWS_AFFTD:=SQL%ROWCOUNT;
--              commit;
--DBMS_STATS.GATHER_TABLE_STATS (ownname => ''DM'',tabname => ''WRK_RIA_DCM_WRITING_AGENT'',partname => NULL,estimate_percent => 10, DEGREE => 4, granularity => ''ALL'', method_opt => ''FOR ALL COLUMNS SIZE 1'',CASCADE => TRUE);

---------------------------OAS DELETE---------------------------
--
/*
BEGIN EXECUTE IMMEDIATE ''DROP INDEX INDX_WRK_RIA_PREMIUM_DATA_A01'';

EXCEPTION
WHEN OTHERS THEN null;

END;

INSERT INTO
  ETL.ETL_DETAIL_LOAD_INFO (
    APPLICATION,
    ETL_BATCH_ID,
    ETL_PROC_NAME,
    ACTION,
    STEP_INFO,
    ROWS_AFFECTED,
    ETL_DATETIME
  )
VALUES
  (
    ''DERIVATIVE PREMIUM 2'',
    V_BTCH_ID,
    V_PROC_NAME,
    ''INSERT'',
    ''INSERT INTO WRK_RIA_DCM_WRITING_AGENT '',
    V_ROWS_AFFTD,
    SYSTIMESTAMP
  );

INSERT INTO
  ETL.ETL_DETAIL_LOAD_INFO (
    APPLICATION,
    ETL_BATCH_ID,
    ETL_PROC_NAME,
    ACTION,
    STEP_INFO,
    ROWS_AFFECTED,
    ETL_DATETIME
  )
VALUES
  (
    ''DERIVATIVE PREMIUM 2'',
    V_BTCH_ID,
    V_PROC_NAME,
    ''END'',
    ''PROCEDURE ENDS '',
    V_ROWS_AFFTD,
    SYSTIMESTAMP
  );

COMMIT;

--Returns the result set
P_ToContinueStatus := ''Y'';

P_ErrorYNFlg := ''N'';

P_ErrorStr := '''';

EXCEPTION
WHEN OTHERS THEN P_ErrorStr := ''ERROR: '' || SQLCODE || ''-'' || SQLERRM || ''-'' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE() || Chr(10) || DBMS_UTILITY.FORMAT_ERROR_STACK();

P_ToContinueStatus := ''N'';

P_ErrorYNFlg := ''Y'';

ROLLBACK;

END;

/
*/
--
---------------------------OAS DELETE---------------------------

---------------------------OAS ADD------------------------------
--

CALL UTIL.SP_ETL_CHECK_CONSTRAINTS(:DB_NAME , :APPLICATION , :WORKFLOW_NAME , :OBJECT_NAME , :V_BATCH_ID );

UPDATE
    UTIL.ETL_BATCH_OBJECT_CONTROL
SET
    STATUS = ''COMPLETE'',
    ERROR_MSG = null,
    BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME,
    BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE
    APPLICATION = :APPLICATION
    AND WORKFLOW_NAME = :WORKFLOW_NAME
    AND OBJECT_NAME = :OBJECT_NAME;

UPDATE
    UTIL.ETL_BATCH_OBJECT_INCR_VALU
SET
    INCR_COLUMN_VALUE = :V_BATCH_ID,
    LST_MOD_DT = CURRENT_TIMESTAMP()
WHERE
    APPLICATION = :APPLICATION
    AND WORKFLOW_NAME = :WORKFLOW_NAME
    AND OBJECT_NAME = :OBJECT_NAME
    AND INCR_COLUMN = ''ETL_LST_BTCH_ID'';

EXCEPTION
WHEN OTHER THEN
UPDATE
    UTIL.ETL_BATCH_OBJECT_CONTROL
SET
    STATUS = ''ERROR'',
    ERROR_MSG = :SQLERRM,
    BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME,
    BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE
    APPLICATION = :APPLICATION
    AND WORKFLOW_NAME = :WORKFLOW_NAME
    AND OBJECT_NAME = :OBJECT_NAME;

INSERT INTO
    UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (
        APPLICATION,
        WORKFLOW_NAME,
        TABLE_NAME,
        BATCH_ID,
        STATUS,
        STEP,
        SEQ,
        ERROR_MSG,
        STEP_START_DATETIME,
        STEP_END_DATETIME
    )
VALUES
    (
        :APPLICATION,
        :WORKFLOW_NAME,
        :OBJECT_NAME,
        :V_BATCH_ID,
        ''ERROR'',
        :V_STEP_NAME,
        :V_STEP_SEQ,
        :SQLERRM,
        :V_STEP_START_TIME,
        CURRENT_TIMESTAMP()
    );

RAISE;

END;
--
---------------------------OAS ADD------------------------------
';