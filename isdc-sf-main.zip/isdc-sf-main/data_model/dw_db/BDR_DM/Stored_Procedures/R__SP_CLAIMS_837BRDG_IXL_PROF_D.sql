USE SCHEMA BDR_DM; CREATE OR REPLACE PROCEDURE "SP_CLAIMS_837BRDG_IXL_PROF_D"("DB_NAME" VARCHAR(16777216), "APPLICATION" VARCHAR(16777216), "WORKFLOW_NAME" VARCHAR(16777216), "OBJECT_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '

-- Original workflow: wkf_Claims_837Brdg_IXL_Data_D
-- Original mapping: m_Claims_837Brdg_IXL_Prof_D
-- Original folder: Claims
-- Original filename: wkf_Claims_837Brdg_IXL_Data_D.XML

DECLARE


V_ROWS_INSERTED  INTEGER;
V_ROWS_UPDATED INTEGER;
V_ROWS_DELETED INTEGER;
V_LAST_QUERY_ID VARCHAR;

V_WH VARCHAR;
V_BATCH_ID INTEGER;


V_BATCH_OBJECT_START_TIME        VARCHAR;
V_STEP_START_TIME    VARCHAR;
V_STEP_NAME VARCHAR;
V_STEP_SEQ INTEGER DEFAULT 0;
V_ETL_LST_BTCH_ID INTEGER;


V_CURRENT_DATE DATE;


BEGIN

EXECUTE IMMEDIATE ''USE DATABASE ''||:DB_NAME; 

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_BATCH_OBJECT_START_TIME := (SELECT CURRENT_TIMESTAMP());



LET res1 RESULTSET := 
(

SELECT 

WH ,
BATCH_ID
  
FROM UTIL.ETL_BATCH_OBJECT_CONTROL
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
FETCH FIRST 1 ROW ONLY

)
;


LET C1 CURSOR FOR res1;
open C1;
FETCH C1 into  V_WH,V_BATCH_ID ;
close C1;

LET res2 RESULTSET := 

(

WITH PARAMETERS ( CURR_DATE) AS
(
  
SELECT * 
FROM  
(SELECT PARAMETER_NAME, PARAMETER_VALUE  FROM UTIL.ETL_OBJECT_PARAMETER_VALUE 
WHERE 1 = 1
AND APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
AND ACTIVE_FLG = ''Y''  
  
UNION ALL       

SELECT PARAMETER_NAME, PARAMETER_VALUE  FROM UTIL.ETL_GLOBAL_PARAMETER_VALUE WHERE PAR_GLOBAL_TYPE = ''PARGLOBAL_OPREPORTS'' AND ACTIVE_FLG = ''Y''
AND PARAMETER_NAME NOT IN  (
SELECT PARAMETER_NAME  FROM UTIL.ETL_OBJECT_PARAMETER_VALUE WHERE 1 = 1
AND APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
AND ACTIVE_FLG = ''Y''   ))
 
PIVOT(MAX(PARAMETER_VALUE) FOR PARAMETER_NAME IN ( ''CURR_DATE'')) 

 
)  
SELECT * FROM PARAMETERS 
)  
  
;


LET C2 CURSOR FOR res2;
open C2;
FETCH C2 into   V_CURRENT_DATE; 
close C2; 



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:V_WH;
USE SCHEMA BDR_DM;		-----------OAS ADD


INSERT INTO UTIL.ETL_BATCH_OBJECT_INCR_VALU (APPLICATION, WORKFLOW_NAME, OBJECT_NAME, INCR_COLUMN, INCR_COLUMN_VALUE )
SELECT * FROM (select :APPLICATION AS APPLICATION, :WORKFLOW_NAME AS WORKFLOW_NAME, :OBJECT_NAME AS OBJECT_NAME, ''ETL_LST_BTCH_ID'' AS INCR_COLUMN, -1 AS INCR_COLUMN_VALUE) A
WHERE NOT EXISTS (SELECT 1 FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU B WHERE B.APPLICATION = A.APPLICATION AND B.WORKFLOW_NAME = A.WORKFLOW_NAME AND B.OBJECT_NAME = A.OBJECT_NAME AND B.INCR_COLUMN = A.INCR_COLUMN)
;

V_ETL_LST_BTCH_ID :=(SELECT INCR_COLUMN_VALUE FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID'');



--pre node line Pre SQL for Shortcut_to_FF_PROF_CLM_837
V_STEP_NAME    := ''Pre_SQL - DELETE STG_PROF_CLM_837'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

-- Component Shortcut_to_FF_PROF_CLM_837, Type Pre SQL 
DELETE FROM BDR_DM.STG_PROF_CLM_837 
WHERE BATCH_ID = :V_BATCH_ID;	------------OAS ADD
--WHERE BATCH_ID = (SELECT MAX(BATCH_ID) FROM UTIL.ETL_BATCH_LOG WHERE APPLICATION = ''CLAIMS'');		-----------OAS DELETE

--COMMIT;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_DELETED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );


INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );


-- Component SC_LKP_CURRENTBATCHID, Type Prerequisite Lookup Object 

---------------COMMENTED BY OAS-----------------
/*
CREATE OR REPLACE TEMPORARY TABLE SC_LKP_CURRENTBATCHID AS
(
SELECT MAX(BATCH_ID) as BATCH_ID, 
APPLICATION as APPLICATION 
FROM UTIL.ETL_BATCH_LOG
WHERE BATCH_STATUS != ''COMPLETE''
GROUP BY APPLICATION
);*/
---------------COMMENTED BY OAS-----------------


--pre node line TARGET for Shortcut_to_FF_PROF_CLM_837
V_STEP_NAME    := ''TARGET - INSERT STG_PROF_CLM_837'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

-- Component SQ_Shortcut_to_final_prof_837_bridge, Type IMPORT_DATA Importing Data
CREATE OR REPLACE TEMPORARY TABLE SQ_Shortcut_to_final_prof_837_bridge AS
(
SELECT SRC.*, row_number() over (order by 1) AS source_record_id FROM (
SELECT
    DISTINCT isdwimp.clm_num as clm_num,
    clm.transact_type_code,
    healthcareservice_location,
    health_care_code_info,
    product_service_id_qlfr,
    sv_clm_payment_remark_code,
    measurement_unit,
    service_unit_count,
    cas_adj_group_code,
    cas_adj_reason_code,
    cas_adj_amt,
    hc_condition_codes as HC_Condition_Code,
    vendor_cd,
    health_care_additional_code_info,
    diagnosis_code_pointers
FROM
    SRC_EDI_837.PROF_CLAIM_PART clm
    INNER JOIN SRC_EDI_837.PROF_SUBSCRIBER sub ON (
        sub.grp_control_no = clm.grp_control_no
        AND sub.trancactset_cntl_no = clm.trancactset_cntl_no
        AND sub.subscriber_hl_no = clm.subscriber_hl_no
        AND sub.transactset_create_date = clm.transactset_create_date
        AND sub.xml_md5 = clm.xml_md5
    )
    INNER JOIN LZ_ISDW.BRDG_SOLN_ISDW_IMPORT isdwimp ON (
        isdwimp.medcr_clm_ctl_nbr = clm.payer_clm_ctrl_num
        AND isdwimp.orig_mbr_nbr = sub.subscriber_id --this join is mandatory for CMS records
    )
where
    isdwimp.medcr_clm_ctl_nbr IS NOT NULL
    AND clm.vendor_cd = ''CMS''
    AND isdwimp.clm_stat in (''D'', ''R'')
    AND SUBSTR(isdwimp.CLM_NUM, 12, 1) <> ''0''
    AND clm.transactset_create_date BETWEEN TO_VARCHAR(DATEADD(month, -6, NVL(TO_DATE(:V_CURRENT_DATE), CURRENT_DATE)),''YYYYMMDD'') AND to_varchar(DATEADD(''DD'', 1, NVL(TO_DATE(:V_CURRENT_DATE), CURRENT_DATE)),''YYYYMMDD'')
UNION
SELECT
    DISTINCT isdwimp.clm_num as clm_num,
    transact_type_code,
    healthcareservice_location,
    health_care_code_info,
    product_service_id_qlfr,
    sv_clm_payment_remark_code,
    measurement_unit,
    service_unit_count,
    cas_adj_group_code,
    cas_adj_reason_code,
    cas_adj_amt,
    hc_condition_codes as HC_Condition_Code,
    vendor_cd,
    health_care_additional_code_info,
    diagnosis_code_pointers
FROM
    SRC_EDI_837.PROF_CLAIM_PART clm
    INNER JOIN LZ_ISDW.BRDG_SOLN_ISDW_IMPORT isdwimp ON (isdwimp.clh_trk_id = clm.network_trace_number)
where
    isdwimp.clh_trk_id NOT LIKE ''null''
    AND isdwimp.clh_trk_id IS NOT NULL
    AND clm.vendor_cd = ''CH''
    AND isdwimp.clm_stat in (''D'', ''R'')
    AND SUBSTR(isdwimp.CLM_NUM, 12, 1) <> ''0''
    AND clm.transactset_create_date BETWEEN TO_VARCHAR(DATEADD(month, -6, NVL(TO_DATE(:V_CURRENT_DATE), CURRENT_DATE)),''YYYYMMDD'') AND to_varchar(DATEADD(''DD'', 1, NVL(TO_DATE(:V_CURRENT_DATE), CURRENT_DATE)),''YYYYMMDD'')
UNION
SELECT
    DISTINCT isdwimp.clm_num as clm_num,
    transact_type_code,
    healthcareservice_location,
    health_care_code_info,
    product_service_id_qlfr,
    sv_clm_payment_remark_code,
    measurement_unit,
    service_unit_count,
    cas_adj_group_code,
    cas_adj_reason_code,
    cas_adj_amt,
    hc_condition_codes as HC_Condition_Code,
    vendor_cd,
    health_care_additional_code_info,
    diagnosis_code_pointers
FROM
    SRC_EDI_837.PROF_CLAIM_PART clm
    INNER JOIN LZ_ISDW.BRDG_SOLN_ISDW_IMPORT isdwimp ON (
        isdwimp.doc_ctl_nbr = TRIM(
            SUBSTR(split(clm.clm_billing_note_text, '' '') [1], 3, 12)
        )
        AND (clm.app_sender_code = ''EXELA'')
        AND (
            isdwimp.doc_ctl_nbr NOT LIKE ''null''
            AND isdwimp.doc_ctl_nbr IS NOT NULL
        )
        AND isdwimp.clm_stat in (''D'', ''R'')
    )
WHERE
    SUBSTR(isdwimp.CLM_NUM, 12, 1) <> ''0''
    AND clm.transactset_create_date BETWEEN TO_VARCHAR(DATEADD(month, -6, NVL(TO_DATE(:V_CURRENT_DATE), CURRENT_DATE)),''YYYYMMDD'') 
		AND to_varchar(DATEADD(''DD'', 1, NVL(TO_DATE(:V_CURRENT_DATE), CURRENT_DATE)),''YYYYMMDD'')
)SRC
);


-- Component EXP_ECC_CLAIMS, Type EXPRESSION 
CREATE OR REPLACE TEMPORARY TABLE EXP_ECC_CLAIMS AS
(
SELECT
CURRENT_TIMESTAMP as var_CURRENT_DT,
''ISDCETL'' as var_CURRENT_USER,
var_CURRENT_DT as out_CREATE_DT,
var_CURRENT_USER as out_CREATE_USER,
var_CURRENT_DT as out_LAST_UPDATE,
var_CURRENT_USER as out_UPDATE_USER,
--LKP_1.BATCH_ID /* replaced lookup SC_LKP_CURRENTBATCHID */ as var_BATCH_ID,	-----------OAS DELETE
:V_BATCH_ID /* replaced lookup SC_LKP_CURRENTBATCHID */ as var_BATCH_ID,	-----------OAS ADD
IFF(var_BATCH_ID IS NULL, - 1, var_BATCH_ID) as out_BATCH_ID,
SQ_Shortcut_to_final_prof_837_bridge.clm_num as clm_num,
SQ_Shortcut_to_final_prof_837_bridge.transact_type_code as transact_type_code,
SQ_Shortcut_to_final_prof_837_bridge.healthcareservice_location as healthcareservice_location,
SQ_Shortcut_to_final_prof_837_bridge.health_care_code_info as health_care_code_info,
SQ_Shortcut_to_final_prof_837_bridge.product_service_id_qlfr as product_service_id_qlfr,
SQ_Shortcut_to_final_prof_837_bridge.sv_clm_payment_remark_code as sv_clm_payment_remark_code,
SQ_Shortcut_to_final_prof_837_bridge.measurement_unit as measurement_unit,
SQ_Shortcut_to_final_prof_837_bridge.service_unit_count as service_unit_count,
SQ_Shortcut_to_final_prof_837_bridge.cas_adj_group_code as cas_adj_group_code,
SQ_Shortcut_to_final_prof_837_bridge.cas_adj_reason_code as cas_adj_reason_code,
rtrim ( ltrim ( SQ_Shortcut_to_final_prof_837_bridge.cas_adj_amt ) ) as o_cas_adj_amt,
SQ_Shortcut_to_final_prof_837_bridge.HC_Condition_Code as HC_Condition_Code,
SQ_Shortcut_to_final_prof_837_bridge.vendor_cd as vendor_cd,
SQ_Shortcut_to_final_prof_837_bridge.Health_Care_Additional_Code_Info as Health_Care_Additional_Code_Info,
SQ_Shortcut_to_final_prof_837_bridge.diagnosis_code_pointers as diagnosis_code_pointers,
SQ_Shortcut_to_final_prof_837_bridge.source_record_id,
row_number() over (partition by SQ_Shortcut_to_final_prof_837_bridge.source_record_id order by SQ_Shortcut_to_final_prof_837_bridge.source_record_id) as RNK
FROM
SQ_Shortcut_to_final_prof_837_bridge
--LEFT JOIN SC_LKP_CURRENTBATCHID LKP_1 ON LKP_1.APPLICATION = $MP_CLAIMS_APPLICATION	-----------OAS DELETE
QUALIFY row_number() over (partition by SQ_Shortcut_to_final_prof_837_bridge.source_record_id order by SQ_Shortcut_to_final_prof_837_bridge.source_record_id) = 1
);



-- Component Shortcut_to_FF_PROF_CLM_837, Type TARGET 
INSERT INTO BDR_DM.STG_PROF_CLM_837
(
CLAIM_NUMBER,
TRANSACT_TYPE_CODE,
HEALTHCARESERVICE_LOCATION,
HEALTH_CARE_CODE_INFO,
PRODUCT_SERVICE_ID_QLFR,
SV_CLM_PAYMENT_REMARK_CODE,
MEASUREMENT_UNIT,
SERVICE_UNIT_COUNT,
CAS_ADJ_GROUP_CODE,
CAS_ADJ_REASON_CODE,
CAS_ADJ_AMT,
HC_CONDITION_CODE,
VENDOR_CD,
HEALTH_CARE_ADDITIONAL_CODE_INFO,
DIAGNOSIS_CODE_POINTERS,
CREATED_DATE,
CREATE_USER,
LAST_MODIFIED_DATE,
LAST_MODIFIED_BY,
BATCH_ID
)
SELECT
EXP_ECC_CLAIMS.clm_num /* CLAIM_NUMBER */,
EXP_ECC_CLAIMS.transact_type_code /* TRANSACT_TYPE_CODE */,
EXP_ECC_CLAIMS.healthcareservice_location /* HEALTHCARESERVICE_LOCATION */,
EXP_ECC_CLAIMS.health_care_code_info /* HEALTH_CARE_CODE_INFO */,
EXP_ECC_CLAIMS.product_service_id_qlfr /* PRODUCT_SERVICE_ID_QLFR */,
EXP_ECC_CLAIMS.sv_clm_payment_remark_code /* SV_CLM_PAYMENT_REMARK_CODE */,
EXP_ECC_CLAIMS.measurement_unit /* MEASUREMENT_UNIT */,
EXP_ECC_CLAIMS.service_unit_count /* SERVICE_UNIT_COUNT */,
EXP_ECC_CLAIMS.cas_adj_group_code /* CAS_ADJ_GROUP_CODE */,
EXP_ECC_CLAIMS.cas_adj_reason_code /* CAS_ADJ_REASON_CODE */,
EXP_ECC_CLAIMS.o_cas_adj_amt /* CAS_ADJ_AMT */,
EXP_ECC_CLAIMS.HC_Condition_Code /* HC_CONDITION_CODE */,
EXP_ECC_CLAIMS.vendor_cd /* VENDOR_CD */,
EXP_ECC_CLAIMS.Health_Care_Additional_Code_Info /* HEALTH_CARE_ADDITIONAL_CODE_INFO */,
EXP_ECC_CLAIMS.diagnosis_code_pointers /* DIAGNOSIS_CODE_POINTERS */,
EXP_ECC_CLAIMS.out_CREATE_DT /* CREATED_DATE */,
EXP_ECC_CLAIMS.out_CREATE_USER /* CREATE_USER */,
EXP_ECC_CLAIMS.out_LAST_UPDATE /* LAST_MODIFIED_DATE */,
EXP_ECC_CLAIMS.out_UPDATE_USER /* LAST_MODIFIED_BY */,
EXP_ECC_CLAIMS.out_BATCH_ID /* BATCH_ID */
FROM
EXP_ECC_CLAIMS;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );


INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );


-- Component Shortcut_to_FF_PROF_CLM_837, Type Post SQL 
--CALL $Param_FOXISDWSchema.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''$Param_FOXISDWSchema'',''FF_PROF_CLM_837'');		-----------OAS DELETE


CALL UTIL.SP_ETL_CHECK_CONSTRAINTS(:DB_NAME , :APPLICATION , :WORKFLOW_NAME , :OBJECT_NAME , :V_BATCH_ID );		---------OAS ADD


UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''COMPLETE'', ERROR_MSG = null, BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
;
UPDATE  UTIL.ETL_BATCH_OBJECT_INCR_VALU SET INCR_COLUMN_VALUE = :V_BATCH_ID, LST_MOD_DT = CURRENT_TIMESTAMP() 
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID''
;

EXCEPTION

WHEN OTHER THEN

UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''ERROR'', ERROR_MSG = :SQLERRM,  BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
;

INSERT INTO  UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ERROR_MSG, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''ERROR'', :V_STEP_NAME, :V_STEP_SEQ, :SQLERRM, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() )
;



RAISE;

END;

';