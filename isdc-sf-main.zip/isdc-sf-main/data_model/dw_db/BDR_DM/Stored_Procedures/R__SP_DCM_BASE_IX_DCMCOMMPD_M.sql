USE SCHEMA BDR_DM; CREATE OR REPLACE PROCEDURE "SP_DCM_BASE_IX_DCMCOMMPD_M"("DB_NAME" VARCHAR(16777216), "APPLICATION" VARCHAR(16777216), "WORKFLOW_NAME" VARCHAR(16777216), "OBJECT_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '

-- Original workflow: wkf_Dcm_IX_BaseLoad_M
-- Original mapping: m_Dcm_Base_IX_DcmCommPd_M
-- Original folder: DCM
-- Original filename: wkf_Dcm_IX_BaseLoad_M.XML

DECLARE


V_ROWS_INSERTED  INTEGER;
V_ROWS_UPDATED INTEGER;
V_ROWS_DELETED INTEGER;
V_LAST_QUERY_ID VARCHAR;

V_WH VARCHAR;
V_BATCH_ID INTEGER;


V_BATCH_OBJECT_START_TIME        VARCHAR;
V_STEP_START_TIME    VARCHAR;
V_STEP_NAME VARCHAR;
V_STEP_SEQ INTEGER DEFAULT 0;
V_ETL_LST_BTCH_ID INTEGER;
V_MP_DCM_BASE_DCMCOMMPD_LOAD VARCHAR :=''Y'';
V_MAX_Ledger_Item_Date VARCHAR;


BEGIN

EXECUTE IMMEDIATE ''USE DATABASE ''||:DB_NAME; 

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_BATCH_OBJECT_START_TIME := (SELECT CURRENT_TIMESTAMP());



LET res1 RESULTSET := 
(

SELECT 

WH ,
BATCH_ID
  
FROM UTIL.ETL_BATCH_OBJECT_CONTROL
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
FETCH FIRST 1 ROW ONLY

)
;


LET C1 CURSOR FOR res1;
open C1;
FETCH C1 into  V_WH,V_BATCH_ID ;
close C1;





EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:V_WH;

USE SCHEMA BDR_DCM;

INSERT INTO UTIL.ETL_BATCH_OBJECT_INCR_VALU (APPLICATION, WORKFLOW_NAME, OBJECT_NAME, INCR_COLUMN, INCR_COLUMN_VALUE )
SELECT * FROM (select :APPLICATION AS APPLICATION, :WORKFLOW_NAME AS WORKFLOW_NAME, :OBJECT_NAME AS OBJECT_NAME, ''ETL_LST_BTCH_ID'' AS INCR_COLUMN, -1 AS INCR_COLUMN_VALUE) A
WHERE NOT EXISTS (SELECT 1 FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU B WHERE B.APPLICATION = A.APPLICATION AND B.WORKFLOW_NAME = A.WORKFLOW_NAME AND B.OBJECT_NAME = A.OBJECT_NAME AND B.INCR_COLUMN = A.INCR_COLUMN)
;

V_ETL_LST_BTCH_ID :=(SELECT INCR_COLUMN_VALUE FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID'');

V_MAX_Ledger_Item_Date :=(SELECT MAX(LGR_ITM_DT) FROM BDR_DCM.DCM_COMM_PD);

--pre node line TARGET for tgt_DcmCommPd
V_STEP_NAME    := ''TARGET - SQ and INSERT DCM_COMM_PD'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;



-- Component SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM, Type SOURCE 
CREATE OR REPLACE TEMPORARY TABLE SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM AS
(
SELECT SRC.*, row_number() over (order by 1) AS source_record_id FROM (
SELECT
ME_ISDW_SRC_Commission_Paid_DCM.id_SRC_Commission_Paid_DCM,
ME_ISDW_SRC_Commission_Paid_DCM.Transaction_Id,
ME_ISDW_SRC_Commission_Paid_DCM.Original_Transaction_Id,
ME_ISDW_SRC_Commission_Paid_DCM.Policy_Id,
ME_ISDW_SRC_Commission_Paid_DCM.HIC,
ME_ISDW_SRC_Commission_Paid_DCM.Last_Name,
ME_ISDW_SRC_Commission_Paid_DCM.First_Name,
ME_ISDW_SRC_Commission_Paid_DCM.Product,
ME_ISDW_SRC_Commission_Paid_DCM.Product_Category,
ME_ISDW_SRC_Commission_Paid_DCM.State,
ME_ISDW_SRC_Commission_Paid_DCM.Application_Sign_Date,
ME_ISDW_SRC_Commission_Paid_DCM.Effective_Date,
ME_ISDW_SRC_Commission_Paid_DCM.Renewal_Date,
ME_ISDW_SRC_Commission_Paid_DCM.Premium,
ME_ISDW_SRC_Commission_Paid_DCM.Advance_Indicator,
ME_ISDW_SRC_Commission_Paid_DCM.Credit,
ME_ISDW_SRC_Commission_Paid_DCM.Initial_UAD,
ME_ISDW_SRC_Commission_Paid_DCM.Commission_Amount,
ME_ISDW_SRC_Commission_Paid_DCM.Recovery_Amount,
ME_ISDW_SRC_Commission_Paid_DCM.Cash_Paid_Amount,
ME_ISDW_SRC_Commission_Paid_DCM.Writing_Agent_Id,
ME_ISDW_SRC_Commission_Paid_DCM.Allocation_Agent_Id,
ME_ISDW_SRC_Commission_Paid_DCM.Agent_Level,
ME_ISDW_SRC_Commission_Paid_DCM.Ledger_Item_Agent_Id,
ME_ISDW_SRC_Commission_Paid_DCM.Assignee_Indicator,
ME_ISDW_SRC_Commission_Paid_DCM.Assignee_Agent_Id,
ME_ISDW_SRC_Commission_Paid_DCM.Payment_Party_Id,
ME_ISDW_SRC_Commission_Paid_DCM.Garnishment_Indicator,
ME_ISDW_SRC_Commission_Paid_DCM.Transaction_Date,
ME_ISDW_SRC_Commission_Paid_DCM.Ledger_Item_Date,
ME_ISDW_SRC_Commission_Paid_DCM.Payment_Account_Update_Date,
ME_ISDW_SRC_Commission_Paid_DCM.Release_Pay_Date,
ME_ISDW_SRC_Commission_Paid_DCM.Original_Cycle_Date,
ME_ISDW_SRC_Commission_Paid_DCM.Transaction_Type,
ME_ISDW_SRC_Commission_Paid_DCM.Transaction_Sub_Type,
ME_ISDW_SRC_Commission_Paid_DCM.Payment_Type,
ME_ISDW_SRC_Commission_Paid_DCM.Payment_Account_Source,
ME_ISDW_SRC_Commission_Paid_DCM.Debit_Item_Type,
ME_ISDW_SRC_Commission_Paid_DCM.Balance_Type,
ME_ISDW_SRC_Commission_Paid_DCM.Rate_Level,
ME_ISDW_SRC_Commission_Paid_DCM.Plan_Code,
ME_ISDW_SRC_Commission_Paid_DCM.Member_Lifestyle_Factor,
ME_ISDW_SRC_Commission_Paid_DCM.Replacement_Indicator,
ME_ISDW_SRC_Commission_Paid_DCM.Submission_Type,
ME_ISDW_SRC_Commission_Paid_DCM.Last_Oracle_Refresh_Date,
ME_ISDW_SRC_Commission_Paid_DCM.Create_Date,
ME_ISDW_SRC_Commission_Paid_DCM.Source_View,
ME_ISDW_SRC_Commission_Paid_DCM.Trueup_Indicator,
ME_ISDW_SRC_Commission_Paid_DCM.FMO_Id_Derived,
ME_ISDW_SRC_Commission_Paid_DCM.Enrollment_Year,
ME_ISDW_SRC_Commission_Paid_DCM.Disability_Indicator,
ME_ISDW_SRC_Commission_Paid_DCM.Application_Type,
ME_ISDW_SRC_Commission_Paid_DCM.Months_On_Plan,
ME_ISDW_SRC_Commission_Paid_DCM.Term_Date,
ME_ISDW_SRC_Commission_Paid_DCM.Term_Reason,
ME_ISDW_SRC_Commission_Paid_DCM.GI_Commission_Rate,
ME_ISDW_SRC_Commission_Paid_DCM.Commission_Tier,
ME_ISDW_SRC_Commission_Paid_DCM.Sales_Performance
FROM SRC_ICM.ME_ISDW_SRC_Commission_Paid_DCM
WHERE ME_ISDW_SRC_Commission_Paid_DCM.Ledger_Item_Date > :V_MAX_Ledger_Item_Date --MAX(ME_ISDW_SRC_Commission_Paid_DCM.Ledger_Item_Date)
AND :V_MP_DCM_BASE_DCMCOMMPD_LOAD = ''Y''
----AND $MP_DCM_BASE_DCMCOMMPD_LOAD = ''Y'' --MRIS comment "In case if we want to stop, we can mark as N. Please use it as parameter"  
) SRC
);


-- Component exp_PassThru, Type EXPRESSION 
CREATE OR REPLACE TEMPORARY TABLE exp_PassThru AS
(
SELECT
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.id_SRC_Commission_Paid_DCM as id_SRC_Commission_Paid_DCM,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Transaction_Id as Transaction_Id,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Original_Transaction_Id as Original_Transaction_Id,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Policy_Id as Policy_Id,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.HIC as HIC,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Last_Name as Last_Name,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.First_Name as First_Name,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Product as Product,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Product_Category as Product_Category,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.State as State,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Application_Sign_Date as Application_Sign_Date,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Effective_Date as Effective_Date,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Renewal_Date as Renewal_Date,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Premium as Premium,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Advance_Indicator as Advance_Indicator,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Credit as Credit,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Initial_UAD as Initial_UAD,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Commission_Amount as Commission_Amount,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Recovery_Amount as Recovery_Amount,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Cash_Paid_Amount as Cash_Paid_Amount,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Writing_Agent_Id as Writing_Agent_Id,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Allocation_Agent_Id as Allocation_Agent_Id,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Agent_Level as Agent_Level,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Ledger_Item_Agent_Id as Ledger_Item_Agent_Id,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Assignee_Indicator as Assignee_Indicator,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Assignee_Agent_Id as Assignee_Agent_Id,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Payment_Party_Id as Payment_Party_Id,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Garnishment_Indicator as Garnishment_Indicator,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Transaction_Date as Transaction_Date,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Ledger_Item_Date as Ledger_Item_Date,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Payment_Account_Update_Date as Payment_Account_Update_Date,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Release_Pay_Date as Release_Pay_Date,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Original_Cycle_Date as Original_Cycle_Date,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Transaction_Type as Transaction_Type,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Transaction_Sub_Type as Transaction_Sub_Type,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Payment_Type as Payment_Type,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Payment_Account_Source as Payment_Account_Source,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Debit_Item_Type as Debit_Item_Type,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Balance_Type as Balance_Type,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Rate_Level as Rate_Level,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Plan_Code as Plan_Code,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Member_Lifestyle_Factor as Member_Lifestyle_Factor,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Replacement_Indicator as Replacement_Indicator,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Submission_Type as Submission_Type,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Last_Oracle_Refresh_Date as Last_Oracle_Refresh_Date,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Create_Date as Create_Date,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Source_View as Source_View,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Trueup_Indicator as Trueup_Indicator,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.FMO_Id_Derived as FMO_Id_Derived,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Enrollment_Year as Enrollment_Year,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Disability_Indicator as Disability_Indicator,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Application_Type as Application_Type,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Months_On_Plan as Months_On_Plan,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Term_Date as Term_Date,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Term_Reason as Term_Reason,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.GI_Commission_Rate as GI_Commission_Rate,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Commission_Tier as Commission_Tier,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.Sales_Performance as Sales_Performance,
0 as out_batch_id,
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM.source_record_id
FROM
SQ_sc_ME_ISDW_SRC_Commission_Paid_DCM
);

-- Component tgt_DcmCommPd, Type TARGET 
INSERT INTO BDR_DCM.DCM_COMM_PD
(
DCM_COMM_PD_KEY,
TRANS_ID,
ORIG_TRANS_ID,
MBR_POL_ID,
HICN,
MBR_LST_NM,
MBR_FST_NM,
M_R_PRDCT,
M_R_PRDCT_CATGY,
MBR_ST_CD,
MBR_APPL_SGN_DT,
MBR_POL_EFF_DT,
MBR_POL_REN_DT,
MBR_PD_PREM,
AGT_COMM_ADV_IND,
AGT_COMM_CR,
AGT_INIT_UAD,
AGT_COMM_AMT,
AGT_RECOV_AMT,
CSH_PD_AMT_TO_AGT,
WRT_AGT_ID,
ALLOC_AGT_ID,
AGT_HIER_LVL,
LGR_ITM_AGT_ID,
AGT_COMM_ASSIGNEE_IND,
AGT_COMM_ASSIGNEE_AGT_ID,
AGT_COMM_PAY_PTY_ID,
AGT_GRNH_IND,
TRANS_DT,
LGR_ITM_DT,
PAY_ACCT_UPDT_DT,
RLSE_PAY_DT,
ORIG_CYC_DT,
POL_TRANS_TYP,
POL_TRANS_SUB_TYP,
POL_PAY_TYP,
POL_PAY_ACCT_SRC,
DR_ITM_TYP,
BAL_TYP,
RT_LVL,
POL_PLN_CD,
MBR_LFSTL_FCT,
MBR_PLN_COV_REPL_IND,
APPL_SBMT_TYP,
LST_ORCL_RFRSH_DT,
CREAT_DT,
SRC_VIEW,
TRUE_IND_BIT,
AGT_FLD_MKT_ORG_ID_DERIV,
POL_ENRL_YR,
MBR_DSBL_IND,
AGT_APPL_TYP,
MO_ON_PLN,
POL_TERM_DT,
POL_TERM_RSN,
AGT_GI_COMM_RT,
AGT_COMM_TIER,
AGT_SALE_PRFRM,
ETL_LST_BTCH_ID
)
SELECT
exp_PassThru.id_SRC_Commission_Paid_DCM /* DCM_COMM_PD_KEY */,
exp_PassThru.Transaction_Id /* TRANS_ID */,
exp_PassThru.Original_Transaction_Id /* ORIG_TRANS_ID */,
exp_PassThru.Policy_Id /* MBR_POL_ID */,
exp_PassThru.HIC /* HICN */,
exp_PassThru.Last_Name /* MBR_LST_NM */,
exp_PassThru.First_Name /* MBR_FST_NM */,
exp_PassThru.Product /* M_R_PRDCT */,
exp_PassThru.Product_Category /* M_R_PRDCT_CATGY */,
exp_PassThru.State /* MBR_ST_CD */,
exp_PassThru.Application_Sign_Date /* MBR_APPL_SGN_DT */,
exp_PassThru.Effective_Date /* MBR_POL_EFF_DT */,
exp_PassThru.Renewal_Date /* MBR_POL_REN_DT */,
exp_PassThru.Premium /* MBR_PD_PREM */,
exp_PassThru.Advance_Indicator /* AGT_COMM_ADV_IND */,
exp_PassThru.Credit /* AGT_COMM_CR */,
exp_PassThru.Initial_UAD /* AGT_INIT_UAD */,
exp_PassThru.Commission_Amount /* AGT_COMM_AMT */,
exp_PassThru.Recovery_Amount /* AGT_RECOV_AMT */,
exp_PassThru.Cash_Paid_Amount /* CSH_PD_AMT_TO_AGT */,
exp_PassThru.Writing_Agent_Id /* WRT_AGT_ID */,
exp_PassThru.Allocation_Agent_Id /* ALLOC_AGT_ID */,
exp_PassThru.Agent_Level /* AGT_HIER_LVL */,
exp_PassThru.Ledger_Item_Agent_Id /* LGR_ITM_AGT_ID */,
exp_PassThru.Assignee_Indicator /* AGT_COMM_ASSIGNEE_IND */,
exp_PassThru.Assignee_Agent_Id /* AGT_COMM_ASSIGNEE_AGT_ID */,
exp_PassThru.Payment_Party_Id /* AGT_COMM_PAY_PTY_ID */,
exp_PassThru.Garnishment_Indicator /* AGT_GRNH_IND */,
exp_PassThru.Transaction_Date /* TRANS_DT */,
exp_PassThru.Ledger_Item_Date /* LGR_ITM_DT */,
exp_PassThru.Payment_Account_Update_Date /* PAY_ACCT_UPDT_DT */,
exp_PassThru.Release_Pay_Date /* RLSE_PAY_DT */,
exp_PassThru.Original_Cycle_Date /* ORIG_CYC_DT */,
exp_PassThru.Transaction_Type /* POL_TRANS_TYP */,
exp_PassThru.Transaction_Sub_Type /* POL_TRANS_SUB_TYP */,
exp_PassThru.Payment_Type /* POL_PAY_TYP */,
exp_PassThru.Payment_Account_Source /* POL_PAY_ACCT_SRC */,
exp_PassThru.Debit_Item_Type /* DR_ITM_TYP */,
exp_PassThru.Balance_Type /* BAL_TYP */,
exp_PassThru.Rate_Level /* RT_LVL */,
exp_PassThru.Plan_Code /* POL_PLN_CD */,
exp_PassThru.Member_Lifestyle_Factor /* MBR_LFSTL_FCT */,
exp_PassThru.Replacement_Indicator /* MBR_PLN_COV_REPL_IND */,
exp_PassThru.Submission_Type /* APPL_SBMT_TYP */,
exp_PassThru.Last_Oracle_Refresh_Date /* LST_ORCL_RFRSH_DT */,
exp_PassThru.Create_Date /* CREAT_DT */,
exp_PassThru.Source_View /* SRC_VIEW */,
exp_PassThru.Trueup_Indicator /* TRUE_IND_BIT */,
exp_PassThru.FMO_Id_Derived /* AGT_FLD_MKT_ORG_ID_DERIV */,
exp_PassThru.Enrollment_Year /* POL_ENRL_YR */,
exp_PassThru.Disability_Indicator /* MBR_DSBL_IND */,
exp_PassThru.Application_Type /* AGT_APPL_TYP */,
exp_PassThru.Months_On_Plan /* MO_ON_PLN */,
exp_PassThru.Term_Date /* POL_TERM_DT */,
exp_PassThru.Term_Reason /* POL_TERM_RSN */,
exp_PassThru.GI_Commission_Rate /* AGT_GI_COMM_RT */,
exp_PassThru.Commission_Tier /* AGT_COMM_TIER */,
exp_PassThru.Sales_Performance /* AGT_SALE_PRFRM */,
exp_PassThru.out_batch_id /* ETL_LST_BTCH_ID */
FROM
exp_PassThru;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );


INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );


-- Component tgt_DcmCommPd, Type Post SQL 
/* CALL DCM.PKG_DB_UTIL.SP_DBUTIL_CONFIG_D(''DCM'',''DCM_COMM_PD'',''POSTSQL'',''s_Dcm_Base_IX_DcmCommPd_M''); */

--BEGIN DBMS_STATS.GATHER_TABLE_STATS (ownname => ''DCM'',tabname => ''DCM_COMM_PD'',partname => NULL,estimate_percent => 10,DEGREE => 4,granularity => ''ALL'',method_opt =>''FOR ALL COLUMNS SIZE 1'',CASCADE => TRUE);END; 




UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''COMPLETE'', ERROR_MSG = null, BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
;
UPDATE  UTIL.ETL_BATCH_OBJECT_INCR_VALU SET INCR_COLUMN_VALUE = :V_BATCH_ID, LST_MOD_DT = CURRENT_TIMESTAMP() 
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID''
;

EXCEPTION

WHEN OTHER THEN

UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''ERROR'', ERROR_MSG = :SQLERRM,  BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
;

INSERT INTO  UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ERROR_MSG, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''ERROR'', :V_STEP_NAME, :V_STEP_SEQ, :SQLERRM, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() )
;



RAISE;

END;

';