USE SCHEMA BDR_DM; CREATE OR REPLACE PROCEDURE "SP_CLAIMS_PURGE_PROCESS_STEP3"("DB_NAME" VARCHAR(16777216), "APPLICATION" VARCHAR(16777216), "WORKFLOW_NAME" VARCHAR(16777216), "OBJECT_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '

-- Original workflow: wkf_Claims_Purge_Process
-- Original mapping: m_Claims_Purge_Process_step3
-- Original folder: CLAIMS
-- Original filename: wkf_Claims_Purge_Process.XML

DECLARE


V_ROWS_INSERTED  INTEGER;
V_ROWS_UPDATED INTEGER;
V_ROWS_DELETED INTEGER;
V_LAST_QUERY_ID VARCHAR;

V_WH VARCHAR;
V_BATCH_ID INTEGER;


V_BATCH_OBJECT_START_TIME        VARCHAR;
V_STEP_START_TIME    VARCHAR;
V_STEP_NAME VARCHAR;
V_STEP_SEQ INTEGER DEFAULT 0;
V_ETL_LST_BTCH_ID INTEGER;
V_PURGE_YR VARCHAR;
V_STAT_CD VARCHAR;


BEGIN

EXECUTE IMMEDIATE ''USE DATABASE ''||:DB_NAME; 

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_BATCH_OBJECT_START_TIME := (SELECT CURRENT_TIMESTAMP());



LET res1 RESULTSET := 
(

SELECT 

WH ,
BATCH_ID
  
FROM UTIL.ETL_BATCH_OBJECT_CONTROL
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
FETCH FIRST 1 ROW ONLY

)
;


LET C1 CURSOR FOR res1;
open C1;
FETCH C1 into  V_WH,V_BATCH_ID ;
close C1;


LET res2 RESULTSET := 

(

WITH PARAMETERS (STAT_CD) AS
(
  
SELECT * 
FROM  
(SELECT PARAMETER_NAME, PARAMETER_VALUE  FROM UTIL.ETL_OBJECT_PARAMETER_VALUE 
WHERE 1 = 1
AND APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
AND ACTIVE_FLG = ''Y''  
  
UNION ALL       

SELECT PARAMETER_NAME, PARAMETER_VALUE  FROM UTIL.ETL_GLOBAL_PARAMETER_VALUE WHERE PAR_GLOBAL_TYPE = ''PARGLOBAL_OPREPORTS'' AND ACTIVE_FLG = ''Y''
AND PARAMETER_NAME NOT IN  (
SELECT PARAMETER_NAME  FROM UTIL.ETL_OBJECT_PARAMETER_VALUE WHERE 1 = 1
AND APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
AND ACTIVE_FLG = ''Y''   ))
 
PIVOT(MAX(PARAMETER_VALUE) FOR PARAMETER_NAME IN (''STAT_CD'')) 

 
)  
SELECT * FROM PARAMETERS 
)  
  
;


LET C2 CURSOR FOR res2;
open C2;
FETCH C2 into  V_STAT_CD; 
close C2;



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:V_WH;
USE SCHEMA BDR_DM;	------------OAS ADD


INSERT INTO UTIL.ETL_BATCH_OBJECT_INCR_VALU (APPLICATION, WORKFLOW_NAME, OBJECT_NAME, INCR_COLUMN, INCR_COLUMN_VALUE )
SELECT * FROM (select :APPLICATION AS APPLICATION, :WORKFLOW_NAME AS WORKFLOW_NAME, :OBJECT_NAME AS OBJECT_NAME, ''ETL_LST_BTCH_ID'' AS INCR_COLUMN, -1 AS INCR_COLUMN_VALUE) A
WHERE NOT EXISTS (SELECT 1 FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU B WHERE B.APPLICATION = A.APPLICATION AND B.WORKFLOW_NAME = A.WORKFLOW_NAME AND B.OBJECT_NAME = A.OBJECT_NAME AND B.INCR_COLUMN = A.INCR_COLUMN)
;

V_ETL_LST_BTCH_ID :=(SELECT INCR_COLUMN_VALUE FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID'');

SELECT CASE
                           WHEN EXTRACT (MONTH FROM CURRENT_DATE) BETWEEN 7 AND 12
                           THEN
                               EXTRACT (YEAR FROM CURRENT_DATE) - 9
                           ELSE
                               EXTRACT (YEAR FROM CURRENT_DATE) - 10
                       END
                       INTO V_PURGE_YR
               					
                  FROM DUAL;





---------------COMMENTED BY OAS-----------------
/*
CREATE OR REPLACE PROCEDURE DM.CLAIM_PURGE_STEP3
AS
    V_STAT_CD   VARCHAR2 (1);
BEGIN
    SELECT METADATA_VALUE
      INTO V_STAT_CD
      FROM ETL.ETL_APPLICATION_METADATA
     WHERE METADATA_DESC = ''CLAIM_PURGE_STEP3'';
*/
---------------COMMENTED BY OAS-----------------

    IF (:V_STAT_CD = ''Y'')
    THEN
        BEGIN
            ----------(Parent table) : Create ClaimHist temp table with all the Skeys you want to delete
---------------COMMENTED BY OAS-----------------
/*
            DECLARE
                v_rows_inserted   NUMBER;
                v_PURGE_YR        NUMBER (10);
            BEGIN
                SELECT CASE
                           WHEN EXTRACT (MONTH FROM SYSDATE) BETWEEN 7 AND 12
                           THEN
                               EXTRACT (YEAR FROM SYSDATE) - 9
                           ELSE
                               EXTRACT (YEAR FROM SYSDATE) - 10
                       END
                  INTO v_PURGE_YR					------OAS DELETE - NOT NEEDED
                  FROM DUAL;

                INSERT INTO ETL.ETL_DETAIL_LOAD_INFO (APPLICATION,
                                                      ETL_BATCH_ID,
                                                      ETL_PROC_NAME,
                                                      ACTION,
                                                      STEP_INFO,
                                                      ROWS_AFFECTED,
                                                      ETL_DATETIME)
                     VALUES (''CLAIMS'',
                             1,
                             ''CLAIMPURGE_STEP3_'' || v_PURGE_YR,
                             ''LOAD START'',
                             ''Temp_PartA  TABLE'',
                             0,
                             SYSTIMESTAMP);

                COMMIT;
*/
---------------COMMENTED BY OAS-----------------
  
			V_STEP_NAME    := :V_PURGE_YR||''_''||''INSERT - Temp_PartA'';
			V_STEP_SEQ     :=  V_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

                INSERT INTO BDR_DM.Temp_PartA (D_EC_PART_A_SK)
                    SELECT /*+ parallel(8) */
                           A.D_EC_PART_A_SK
                      FROM BDR_DM.Temp_ClaimHist  T
                           JOIN BDR_DM.F_CLM_HIST F
                               ON T.F_CLM_HIST_SK = F.F_CLM_HIST_SK
                           JOIN BDR_DM.D_EC_PART_A A
                               ON F.D_EC_PART_A_SK = A.D_EC_PART_A_SK
                     WHERE A.D_EC_PART_A_SK > 0;
    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;
			
			V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );
			
			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

---------------COMMENTED BY OAS-----------------
/*
                v_rows_inserted := SQL%ROWCOUNT;

                COMMIT;


                INSERT INTO ETL.ETL_DETAIL_LOAD_INFO (APPLICATION,
                                                      ETL_BATCH_ID,
                                                      ETL_PROC_NAME,
                                                      ACTION,
                                                      STEP_INFO,
                                                      ROWS_AFFECTED,
                                                      ETL_DATETIME)
                     VALUES (''CLAIMS'',
                             1,
                             ''CLAIMPURGE_STEP3_'' || v_PURGE_YR,
                             ''LOAD END'',
                             ''Temp_PartA  TABLE'',
                             v_rows_inserted,
                             SYSTIMESTAMP);

                COMMIT;

                DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS (''DM'', ''Temp_PartA'');

                ----------------

                INSERT INTO ETL.ETL_DETAIL_LOAD_INFO (APPLICATION,
                                                      ETL_BATCH_ID,
                                                      ETL_PROC_NAME,
                                                      ACTION,
                                                      STEP_INFO,
                                                      ROWS_AFFECTED,
                                                      ETL_DATETIME)
                     VALUES (''CLAIMS'',
                             1,
                             ''CLAIMPURGE_STEP3_'' || v_PURGE_YR,
                             ''LOAD START'',
                             ''Temp_PartB  TABLE'',
                             0,
                             SYSTIMESTAMP);

                COMMIT;
*/
---------------COMMENTED BY OAS-----------------
  
			V_STEP_NAME    := :V_PURGE_YR||''_''||''INSERT - Temp_PartB'';
			V_STEP_SEQ     :=  V_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

                INSERT INTO BDR_DM.Temp_PartB (D_EC_PART_B_SK)
                    SELECT /*+ parallel(8) */
                           A.D_EC_PART_B_SK
                      FROM BDR_DM.Temp_ClaimHist  T
                           JOIN BDR_DM.F_CLM_HIST F
                               ON T.F_CLM_HIST_SK = F.F_CLM_HIST_SK
                           JOIN BDR_DM.D_EC_PART_B A
                               ON F.D_EC_PART_B_SK = A.D_EC_PART_B_SK
                     WHERE A.D_EC_PART_B_SK > 0;
    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;
			
			V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );
			
			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

---------------COMMENTED BY OAS-----------------
/*
                v_rows_inserted := SQL%ROWCOUNT;

                COMMIT;


                INSERT INTO ETL.ETL_DETAIL_LOAD_INFO (APPLICATION,
                                                      ETL_BATCH_ID,
                                                      ETL_PROC_NAME,
                                                      ACTION,
                                                      STEP_INFO,
                                                      ROWS_AFFECTED,
                                                      ETL_DATETIME)
                     VALUES (''CLAIMS'',
                             1,
                             ''CLAIMPURGE_STEP3_'' || v_PURGE_YR,
                             ''LOAD END'',
                             ''Temp_PartB  TABLE'',
                             v_rows_inserted,
                             SYSTIMESTAMP);

                COMMIT;

                DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS (''DM'', ''Temp_PartB'');

                --------------------------------------


                INSERT INTO ETL.ETL_DETAIL_LOAD_INFO (APPLICATION,
                                                      ETL_BATCH_ID,
                                                      ETL_PROC_NAME,
                                                      ACTION,
                                                      STEP_INFO,
                                                      ROWS_AFFECTED,
                                                      ETL_DATETIME)
                     VALUES (''CLAIMS'',
                             1,
                             ''CLAIMPURGE_STEP3_'' || v_PURGE_YR,
                             ''LOAD START'',
                             ''Temp_PartRX  TABLE'',
                             0,
                             SYSTIMESTAMP);

                COMMIT;
*/
---------------COMMENTED BY OAS-----------------
  
			V_STEP_NAME    := :V_PURGE_YR||''_''||''INSERT - Temp_PartRX'';
			V_STEP_SEQ     :=  V_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

                INSERT INTO BDR_DM.Temp_PartRX (D_EC_RX_SK)
                    SELECT /*+ parallel(8) */
                           A.D_EC_RX_SK
                      FROM BDR_DM.Temp_ClaimHist  T
                           JOIN BDR_DM.F_CLM_HIST F
                               ON T.F_CLM_HIST_SK = F.F_CLM_HIST_SK
                           JOIN BDR_DM.D_EC_RX A ON F.D_EC_RX_SK = A.D_EC_RX_SK
                     WHERE A.D_EC_RX_SK > 0;
    	
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;
			
			V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );
			
			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

---------------COMMENTED BY OAS-----------------
/*
                v_rows_inserted := SQL%ROWCOUNT;

                COMMIT;


                INSERT INTO ETL.ETL_DETAIL_LOAD_INFO (APPLICATION,
                                                      ETL_BATCH_ID,
                                                      ETL_PROC_NAME,
                                                      ACTION,
                                                      STEP_INFO,
                                                      ROWS_AFFECTED,
                                                      ETL_DATETIME)
                     VALUES (''CLAIMS'',
                             1,
                             ''CLAIMPURGE_STEP3_'' || v_PURGE_YR,
                             ''LOAD END'',
                             ''Temp_PartRX  TABLE'',
                             v_rows_inserted,
                             SYSTIMESTAMP);

                COMMIT;

                DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS (''DM'', ''Temp_PartRX'');
*/
---------------COMMENTED BY OAS-----------------
  
			V_STEP_NAME    := :V_PURGE_YR||''_''||''DELETE - D_EC_PART_A_BL'';
			V_STEP_SEQ     :=  V_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

 
                DELETE /*+ parallel(8) */
                       FROM
                    BDR_DM.D_EC_PART_A_BL
                      WHERE D_EC_PART_A_SK IN
                                (SELECT D_EC_PART_A_SK FROM BDR_DM.Temp_PartA);
										
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;
			
			V_ROWS_DELETED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );
			
			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );
 
---------------COMMENTED BY OAS-----------------
/*
                v_rows_inserted := SQL%ROWCOUNT;

                COMMIT;


                INSERT INTO ETL.ETL_DETAIL_LOAD_INFO (APPLICATION,
                                                      ETL_BATCH_ID,
                                                      ETL_PROC_NAME,
                                                      ACTION,
                                                      STEP_INFO,
                                                      ROWS_AFFECTED,
                                                      ETL_DATETIME)
                     VALUES (''CLAIMS'',
                             1,
                             ''CLAIMPURGE_STEP3_'' || v_PURGE_YR,
                             ''DELETE'',
                             ''DELETE FROM PARTABL'',
                             v_rows_inserted,
                             SYSTIMESTAMP);

                COMMIT;
*/
---------------COMMENTED BY OAS-----------------
  
			V_STEP_NAME    := :V_PURGE_YR||''_''||''DELETE - D_EC_PART_B_BL'';
			V_STEP_SEQ     :=  V_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

                DELETE /*+ parallel(8) */
                       FROM
                    BDR_DM.D_EC_PART_B_BL
                      WHERE D_EC_PART_B_SK IN
                                (SELECT D_EC_PART_B_SK FROM BDR_DM.Temp_PartB);
										
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;
			
			V_ROWS_DELETED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );
			
			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );
 
---------------COMMENTED BY OAS-----------------
/*
                v_rows_inserted := SQL%ROWCOUNT;

                COMMIT;


                INSERT INTO ETL.ETL_DETAIL_LOAD_INFO (APPLICATION,
                                                      ETL_BATCH_ID,
                                                      ETL_PROC_NAME,
                                                      ACTION,
                                                      STEP_INFO,
                                                      ROWS_AFFECTED,
                                                      ETL_DATETIME)
                     VALUES (''CLAIMS'',
                             1,
                             ''CLAIMPURGE_STEP3_'' || v_PURGE_YR,
                             ''DELETE'',
                             ''DELETE FROM PARTBBL'',
                             v_rows_inserted,
                             SYSTIMESTAMP);

                COMMIT;
*/
---------------COMMENTED BY OAS-----------------

  
			V_STEP_NAME    := :V_PURGE_YR||''_''||''DELETE - D_EC_RX_BL'';
			V_STEP_SEQ     :=  V_STEP_SEQ+1;
			V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
			V_ROWS_INSERTED := null;
			V_ROWS_UPDATED := null;
			V_ROWS_DELETED := null;

 
                DELETE /*+ parallel(8) */
                       FROM
                    BDR_DM.D_EC_RX_BL
                      WHERE D_EC_RX_SK IN
                                (SELECT D_EC_RX_SK FROM BDR_DM.Temp_PartRX);
										
			V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;
			
			V_ROWS_DELETED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );
			
			INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
			VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );
 
--                COMMIT;

---------------COMMENTED BY OAS-----------------
/*
                v_rows_inserted := SQL%ROWCOUNT;

                COMMIT;


                INSERT INTO ETL.ETL_DETAIL_LOAD_INFO (APPLICATION,
                                                      ETL_BATCH_ID,
                                                      ETL_PROC_NAME,
                                                      ACTION,
                                                      STEP_INFO,
                                                      ROWS_AFFECTED,
                                                      ETL_DATETIME)
                     VALUES (''CLAIMS'',
                             1,
                             ''CLAIMPURGE_STEP3_'' || v_PURGE_YR,
                             ''DELETE'',
                             ''DELETE FROM PARTRXBL'',
                             v_rows_inserted,
                             SYSTIMESTAMP);

                COMMIT;
            END;
*/
---------------COMMENTED BY OAS-----------------
		END;
	END IF;
--			END;
--			/




UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''COMPLETE'', ERROR_MSG = null, BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
;
UPDATE  UTIL.ETL_BATCH_OBJECT_INCR_VALU SET INCR_COLUMN_VALUE = :V_BATCH_ID, LST_MOD_DT = CURRENT_TIMESTAMP() 
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID''
;


EXCEPTION

WHEN OTHER THEN

UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''ERROR'', ERROR_MSG = :SQLERRM,  BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
;

INSERT INTO  UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ERROR_MSG, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''ERROR'', :V_STEP_NAME, :V_STEP_SEQ, :SQLERRM, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() )
;



RAISE;

END;

';