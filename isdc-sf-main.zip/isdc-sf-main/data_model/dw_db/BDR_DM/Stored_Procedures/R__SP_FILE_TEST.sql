USE SCHEMA BDR_DM; CREATE OR REPLACE PROCEDURE "SP_FILE_TEST"("DB_NAME" VARCHAR(16777216), "APPLICATION" VARCHAR(16777216), "WORKFLOW_NAME" VARCHAR(16777216), "OBJECT_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '

-- Original workflow: wkf_OptumHealthFeed_I_CreateFFOutputs_M
-- Original mapping: m_OPTUMHEALTH_FF_CreateOutputFiles_M
-- Original folder: Claims
-- Original filename: wkf_OptumHealthFeed_I_CreateFFOutputs_M.XML

DECLARE



V_WH VARCHAR;
V_BATCH_ID INTEGER;



V_STAGE VARCHAR DEFAULT ''@UTIL.STAGE_AZURE_ISDC''; 
V_OUTBOX_DIR VARCHAR  DEFAULT ''@UTIL.STAGE_AZURE_ISDC'';

V_STAGE_QUERY2 VARCHAR;



BEGIN

EXECUTE IMMEDIATE ''USE DATABASE ''||:DB_NAME; 

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_BATCH_OBJECT_START_TIME := (SELECT CURRENT_TIMESTAMP());



LET res1 RESULTSET := 
(

SELECT 

''UBLIA_PRD_ETL_XS_WH'' as WH,
-1 as BATCH_ID
  


)
;


LET C1 CURSOR FOR res1;
open C1;
FETCH C1 into  V_WH,V_BATCH_ID ;
close C1;


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:V_WH;

USE SCHEMA BDR_DM;	



  
    V_STAGE_QUERY2 := ''COPY INTO ''||:V_STAGE||:V_OUTBOX_DIR||''IGX2_SHIP_MEMBER_2_'' || (SELECT TO_CHAR(ADD_MONTHS(CURRENT_DATE, -1), ''YYYYMM'')) ||''.txt'' || ''
    FROM (
        SELECT 1
    )
    file_format = (type = ''''CSV'''',
                   field_delimiter = '''','''',
                   compression = NONE
                  )
    HEADER = FALSE
    OVERWRITE = TRUE
    MAX_FILE_SIZE = 4900000000
    SINGLE = TRUE;''  ;



                                 
execute immediate  :V_STAGE_QUERY2;  



EXCEPTION

WHEN OTHER THEN


RAISE;

END;

';