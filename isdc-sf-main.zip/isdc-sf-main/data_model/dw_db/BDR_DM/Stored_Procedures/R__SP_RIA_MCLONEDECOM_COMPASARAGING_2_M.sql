USE SCHEMA BDR_DM; CREATE OR REPLACE PROCEDURE "SP_RIA_MCLONEDECOM_COMPASARAGING_2_M"("DB_NAME" VARCHAR(16777216), "APPLICATION" VARCHAR(16777216), "WORKFLOW_NAME" VARCHAR(16777216), "OBJECT_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '

-- Original workflow: wkf_RIA_MCloneDecom_CompasARAging_M
-- Original mapping: m_RIA_MCloneDecom_CompasARAging_2_M
-- Original folder: Compas_Reports
-- Original filename: wkf_RIA_MCloneDecom_CompasARAging_M.XML

DECLARE


V_ROWS_INSERTED  INTEGER;
V_ROWS_UPDATED INTEGER;
V_ROWS_DELETED INTEGER;
V_LAST_QUERY_ID VARCHAR;

V_WH VARCHAR;
V_BATCH_ID INTEGER;


V_BATCH_OBJECT_START_TIME        VARCHAR;
V_STEP_START_TIME    VARCHAR;
V_STEP_NAME VARCHAR;
V_STEP_SEQ INTEGER DEFAULT 0;
V_ETL_LST_BTCH_ID INTEGER;

v_any_jobs     NUMBER;


BEGIN

EXECUTE IMMEDIATE ''USE DATABASE ''||:DB_NAME; 

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_BATCH_OBJECT_START_TIME := (SELECT CURRENT_TIMESTAMP());



LET res1 RESULTSET := 
(

SELECT 

WH ,
BATCH_ID
  
FROM UTIL.ETL_BATCH_OBJECT_CONTROL
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
FETCH FIRST 1 ROW ONLY

)
;


LET C1 CURSOR FOR res1;
open C1;
FETCH C1 into  V_WH,V_BATCH_ID ;
close C1;



EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:V_WH;
USE SCHEMA BDR_DM;	------------OAS ADD


INSERT INTO UTIL.ETL_BATCH_OBJECT_INCR_VALU (APPLICATION, WORKFLOW_NAME, OBJECT_NAME, INCR_COLUMN, INCR_COLUMN_VALUE )
SELECT * FROM (select :APPLICATION AS APPLICATION, :WORKFLOW_NAME AS WORKFLOW_NAME, :OBJECT_NAME AS OBJECT_NAME, ''ETL_LST_BTCH_ID'' AS INCR_COLUMN, -1 AS INCR_COLUMN_VALUE) A
WHERE NOT EXISTS (SELECT 1 FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU B WHERE B.APPLICATION = A.APPLICATION AND B.WORKFLOW_NAME = A.WORKFLOW_NAME AND B.OBJECT_NAME = A.OBJECT_NAME AND B.INCR_COLUMN = A.INCR_COLUMN)
;

V_ETL_LST_BTCH_ID :=(SELECT INCR_COLUMN_VALUE FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID'');


-------------------------------COMMENTED BY OAS-------------------------------

/*----------------CODE FOR MAIN PROCEDURE ETL."SP_ETL_MCLONE_DECOM_M"------------------------

CREATE OR REPLACE PROCEDURE ETL."SP_ETL_MCLONE_DECOM_M"(
    p_etlname IN VARCHAR2,
    p_etlseq  IN NUMBER,
    p_tocontinuestatus OUT VARCHAR2,
    p_errorynflg OUT VARCHAR2,
    p_errorstr OUT VARCHAR2)
AS

BEGIN

		SELECT MIN(proc_launch_order)			------3
          INTO lv_min_order
          FROM ETL.ETL_MCLONE_DECOM_PROC_LIST
          WHERE etl_name = p_etlname	-----''COMPAS_AR_AGING''
          AND etl_seq    = p_etlseq		-----2
          AND active_ind = ''Y'';
		

          SELECT MAX(proc_launch_order)		----------3
          INTO lv_max_order
          FROM ETL.ETL_MCLONE_DECOM_PROC_LIST
          WHERE etl_name = p_etlname	-----''COMPAS_AR_AGING''
          AND etl_seq    = p_etlseq		-----2
          AND active_ind = ''Y'';

          SELECT MAX(batch_id)
          INTO lv_batch_id
          FROM etl.etl_batch_log
          WHERE application = ''COMPAS_REPORTS''
          AND batch_status != ''COMPLETE'';

          UPDATE ETL.ETL_MCLONE_DECOM_PROC_LIST
          SET batch_id   = lv_batch_id
          WHERE etl_name = p_etlname
          AND etl_seq    = p_etlseq
          AND active_ind = ''Y'';
          COMMIT;

          --Find Next Row to Process
          WHILE lv_min_order < (lv_max_order + 1 )		-----------3< 3+1 for 1st iteration => TRUE,  4<3+1 for next iteration => FALSE --- 
          LOOP

                    --dbms_output.put_line(''Min Loop Start'' || lv_min_order);
                    --dbms_output.put_line(''Max Loop Start'' || lv_max_order);

                    lv_next_rec_found      := ''Y'';

                    WHILE lv_next_rec_found = ''Y''
                    LOOP
                              BEGIN
                                      lv_proc_name := NULL;

                                      -- Get the Proc Name
                                      SELECT proc_name,
                                        batch_id		
                                      INTO lv_proc_name,		----------------PROC_NAME IS COMPAS_MO.PKG_RIA_ADW_AR_AGING_REPORT.PR_AR_SUMMARIZE_AND_CLEANUP();
                                        lv_batch_id
                                      FROM
                                        (SELECT proc_name,
                                          batch_id
                                        FROM ETL.ETL_MCLONE_DECOM_PROC_LIST
                                        WHERE run_status      in (''READY'',''ERROR'')
                                        AND proc_launch_order = lv_min_order	--------------3
                                        AND active_ind = ''Y''
                                        )
                                      WHERE ROWNUM = 1;

                                      --Proc Found
                                      IF lv_proc_name IS NOT NULL THEN

                                                SELECT SYSDATE INTO lv_etl_start_time FROM dual;

                                                UPDATE ETL.ETL_MCLONE_DECOM_PROC_LIST
                                                SET run_status        = ''INPROCESS'',
                                                  etl_start_time      = lv_etl_start_time
                                                WHERE batch_id        = lv_batch_id
                                                AND proc_name         = lv_proc_name
                                                AND proc_launch_order = lv_min_order;

                                                --Continue, if no records updated
                                                lv_row_aff_by_upd   := SQL % rowcount;

                                                IF lv_row_aff_by_upd = 0 THEN
                                                  ROLLBACK;
                                                  CONTINUE;
                                                ELSE
                                                  COMMIT;
                                                END IF;
                                      END IF;

                                      --Execute Procedure
                                      BEGIN
                                                lv_proc_final := ''begin '' || lv_proc_name || '' end;'';

                                                EXECUTE IMMEDIATE (lv_proc_final);	---------THIS WILL EXCUTE COMPAS_MO.PKG_RIA_ADW_AR_AGING_REPORT.PR_AR_SUMMARIZE_AND_CLEANUP();
												
				-------------CODE FOR PROCEDURE COMPAS_MO.PKG_RIA_ADW_AR_AGING_REPORT.PR_AR_SUMMARIZE_AND_CLEANUP(); BEGINS-------------
				
		PROCEDURE pr_ar_summarize_and_cleanup
			IS
			
			v_any_jobs     NUMBER;
			v_job_id       NUMBER;
			v_what         VARCHAR2(100) := ''%PR_AR_SUMMARIZE_AND_CLEANUP%'';
			
			BEGIN
			*/
			-------------COMMENTED BY OAS-------------
			
				SELECT COUNT(*)       -- All done ?
				INTO   v_any_jobs
				FROM   BDR_DM.AR_RIA_AGING_ADW_SUMMARY_STAGE
				WHERE  completed_ind = ''N'';
			
				IF (:v_any_jobs = 0) THEN
			
					V_STEP_NAME    := ''INSERT - AR_RIA_AGING_ADW_SUMMARY'';
					V_STEP_SEQ     :=  V_STEP_SEQ+1;
					V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
					V_ROWS_INSERTED := null;
					V_ROWS_UPDATED := null;
					V_ROWS_DELETED := null;
			
						-- All righty now, back to business, lets sum and be outta here
						INSERT INTO BDR_DM.AR_RIA_AGING_ADW_SUMMARY
						( delinquent_date, premium_current_month, premium_prior_one_month,
						premium_prior_two_month,premium_prior_three_month, premium_prior_four_month,
						premium_prior_five_month, premium_prior_six_month,
						ppo_current_month, ppo_prior_one_month,
						ppo_prior_two_month, ppo_prior_three_month,
						ppo_prior_four_month,ppo_prior_five_month,
						ppo_prior_six_month )
						SELECT report_date, SUM(premium_current_month), SUM(premium_prior_one_month),   SUM(premium_prior_two_month),
								SUM(premium_prior_three_month), SUM(premium_prior_four_month),
								SUM(premium_prior_five_month),  SUM(premium_prior_six_month),
								SUM(ppo_current_month), SUM(ppo_prior_one_month),
						SUM(ppo_prior_two_month), SUM(ppo_prior_three_month),
						SUM(ppo_prior_four_month),SUM(ppo_prior_five_month),
						SUM(ppo_prior_six_month)
						FROM BDR_DM.AR_RIA_AGING_ADW_SUMMARY_STAGE
						GROUP BY report_date     ;
						
						-- COMMIT;
						
					V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;
					
					V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );
					
					INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
					VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );
						
					--pkg_utility.pr_write_status(''adw_ar_summary_status'');
			
				END IF;
					
			-------------COMMENTED BY OAS-------------
			/*
			END;
			-------------CODE FOR PROCEDURE COMPAS_MO.PKG_RIA_ADW_AR_AGING_REPORT.PR_AR_SUMMARIZE_AND_CLEANUP(); ENDS-------------

                                                EXCEPTION
                                                WHEN OTHERS THEN

                                                        lv_error_msg := SUBSTR(SQLERRM, 1, 250);
                                                        SELECT SYSDATE INTO lv_etl_end_time FROM dual;

                                                        UPDATE ETL.ETL_MCLONE_DECOM_PROC_LIST
                                                        SET run_status  = ''ERROR'',
                                                          etl_end_time  = lv_etl_end_time,
                                                          etl_error_msg = lv_error_msg
                                                        WHERE proc_name = lv_proc_name;
                                                        COMMIT;

                                                        SELECT SYSDATE INTO lv_etl_end_time FROM dual;

                                                        UPDATE ETL.ETL_MCLONE_DECOM_PROC_LIST
                                                        SET etl_time_taken = round((cast(etl_end_time as date) - cast(etl_start_time as date)) * 24 * 60 * 60)
                                                        WHERE proc_name    = lv_proc_name;

                                                        COMMIT;

                                                        lv_exception := ''Y'';
                                                        RAISE;
                                      END;

                                      IF lv_exception = ''Y'' THEN
                                      --DBMS_OUTPUT.PUT_LINE(''lv_exception'');
                                        EXIT;
                                      END IF;

                                      SELECT SYSDATE INTO lv_etl_end_time FROM dual;

                                      UPDATE ETL.ETL_MCLONE_DECOM_PROC_LIST
                                      SET run_status  = ''COMPLETE'',
                                      etl_end_time  = lv_etl_end_time
                                      WHERE proc_name = lv_proc_name;

                                      COMMIT;

                                      UPDATE ETL.ETL_MCLONE_DECOM_PROC_LIST
                                      SET etl_time_taken = round((cast(etl_end_time as date) - cast(etl_start_time as date)) * 24 * 60 * 60)
                                      WHERE proc_name    = lv_proc_name;

                                      COMMIT;


                              END;
                              BEGIN

                                        SELECT proc_name
                                        INTO lv_proc_name
                                        FROM
                                        (SELECT proc_name
                                        FROM ETL.ETL_MCLONE_DECOM_PROC_LIST
                                        WHERE run_status      IN (''READY'',''ERROR'')
                                        AND proc_launch_order = lv_min_order
                                        AND active_ind = ''Y''
                                        )
                                        WHERE ROWNUM = 1;

                                        EXCEPTION WHEN NO_DATA_FOUND THEN
                                        lv_next_rec_found := ''N'';
                                        --dbms_output.put_line(''Exception'');
                              END;

                              --lv_proc_final := '''';
                              --lv_proc_name := '''';
                    END LOOP;

                    SELECT LISTAGG(run_status , '''') WITHIN GROUP (
                    ORDER BY run_status)
                    INTO lv_flag
                    FROM
                      (SELECT DISTINCT run_status
                      FROM ETL.ETL_MCLONE_DECOM_PROC_LIST
                      WHERE proc_launch_order = lv_min_order
                      AND active_ind = ''Y''
                      );

                    IF lv_flag      = ''COMPLETE'' OR (lv_min_order = lv_max_order) THEN
                      lv_min_order := lv_min_order + 1;			--------------------3+1 WILL BECOME FALSE FOR NEXT ITERATION
                    END IF;

          END LOOP;

          --Returns the result set
          P_ToContinueStatus := ''Y'';
          P_ErrorYNFlg       := ''N'';
          P_ErrorStr         := '''';

          EXCEPTION WHEN OTHERS THEN
            P_ErrorStr         := ''ERROR: '' || SQLCODE || ''-'' || SQLERRM || ''-'' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE()|| Chr(10)||DBMS_UTILITY.FORMAT_ERROR_STACK();
            P_ToContinueStatus := ''N'';
            P_ErrorYNFlg       := ''Y'';
            ROLLBACK;
END;
/
*/
---------------COMMENTED BY OAS-----------------

CALL UTIL.SP_ETL_CHECK_CONSTRAINTS(:DB_NAME , :APPLICATION , :WORKFLOW_NAME , :OBJECT_NAME , :V_BATCH_ID );		---------OAS ADD

UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''COMPLETE'', ERROR_MSG = null, BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
;
UPDATE  UTIL.ETL_BATCH_OBJECT_INCR_VALU SET INCR_COLUMN_VALUE = :V_BATCH_ID, LST_MOD_DT = CURRENT_TIMESTAMP() 
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID''
;



EXCEPTION

WHEN OTHER THEN

UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''ERROR'', ERROR_MSG = :SQLERRM,  BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
;

INSERT INTO  UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ERROR_MSG, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''ERROR'', :V_STEP_NAME, :V_STEP_SEQ, :SQLERRM, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() )
;



RAISE;

END;

';