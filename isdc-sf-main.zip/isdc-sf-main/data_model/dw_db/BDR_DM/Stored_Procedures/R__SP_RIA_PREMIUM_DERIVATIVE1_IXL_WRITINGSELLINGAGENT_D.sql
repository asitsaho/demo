USE SCHEMA BDR_DM; CREATE OR REPLACE PROCEDURE "SP_RIA_PREMIUM_DERIVATIVE1_IXL_WRITINGSELLINGAGENT_D"("DB_NAME" VARCHAR(16777216), "APPLICATION" VARCHAR(16777216), "WORKFLOW_NAME" VARCHAR(16777216), "OBJECT_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '

-- Original workflow: wkf_RIA_Premium_Derivative_IXL_TargetLoad1_D
-- Original mapping: m_RIA_Premium_Derivative1_IXL_WritingSellingAgent_D
-- Original folder: Premium
-- Original filename: wkf_RIA_Premium_Derivative_IXL_TargetLoad1_D.XML

DECLARE

V_ROWS_INSERTED INTEGER;
V_ROWS_INSERTED1 INTEGER;
V_ROWS_INSERTED2 INTEGER;
V_ROWS_UPDATED INTEGER;
V_ROWS_DELETED INTEGER;
V_LAST_QUERY_ID VARCHAR;

V_WH VARCHAR;
V_BATCH_ID INTEGER;

V_BATCH_OBJECT_START_TIME VARCHAR;
V_STEP_START_TIME VARCHAR;
V_STEP_NAME VARCHAR;
V_STEP_SEQ INTEGER DEFAULT 0;
V_ETL_LST_BTCH_ID INTEGER;

BEGIN

EXECUTE IMMEDIATE ''USE DATABASE ''||:DB_NAME; 

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_BATCH_OBJECT_START_TIME := (SELECT CURRENT_TIMESTAMP());

LET res1 RESULTSET := 
(
SELECT 
WH ,
BATCH_ID
FROM UTIL.ETL_BATCH_OBJECT_CONTROL
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
FETCH FIRST 1 ROW ONLY
);

LET C1 CURSOR FOR res1;
open C1;
FETCH C1 into  V_WH,V_BATCH_ID ;
close C1;

EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:V_WH;
USE SCHEMA BDR_DM;

INSERT INTO UTIL.ETL_BATCH_OBJECT_INCR_VALU (APPLICATION, WORKFLOW_NAME, OBJECT_NAME, INCR_COLUMN, INCR_COLUMN_VALUE )
SELECT * FROM (select :APPLICATION AS APPLICATION, :WORKFLOW_NAME AS WORKFLOW_NAME, :OBJECT_NAME AS OBJECT_NAME, ''ETL_LST_BTCH_ID'' AS INCR_COLUMN, -1 AS INCR_COLUMN_VALUE) A
WHERE NOT EXISTS (SELECT 1 FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU B WHERE B.APPLICATION = A.APPLICATION AND B.WORKFLOW_NAME = A.WORKFLOW_NAME AND B.OBJECT_NAME = A.OBJECT_NAME AND B.INCR_COLUMN = A.INCR_COLUMN);

V_ETL_LST_BTCH_ID :=(SELECT INCR_COLUMN_VALUE FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID'');

--
---------------------------OAS ADD------------------------------

---------------------------OAS DELETE---------------------------
--
/*
 CREATE OR REPLACE PROCEDURE DM.SP_RIA_PREMIUM_WRITINGSELLINGAGT_D
 (
 iv_Dummy                IN VARCHAR2,
 P_ToContinueStatus OUT VARCHAR2,
 P_ErrorYNFlg OUT VARCHAR2,
 P_ErrorStr OUT VARCHAR2)
 AS
 
 V_PROC_NAME         VARCHAR(50):=''SP_RIA_PREMIUM_WRITINGSELLINGAGT_D'';
 V_ROWS_AFFTD        NUMBER(20) :=0;
 V_BTCH_ID           NUMBER(10);
 
 BEGIN
 
 SELECT MAX(BATCH_ID) INTO V_BTCH_ID FROM ETL.ETL_BATCH_LOG WHERE APPLICATION=''CDC'' AND BATCH_STATUS=''COMPLETE'';
 INSERT
 INTO ETL.ETL_DETAIL_LOAD_INFO
 (
 APPLICATION ,
 ETL_BATCH_ID,
 ETL_PROC_NAME ,
 ACTION ,
 STEP_INFO ,
 ROWS_AFFECTED ,
 ETL_DATETIME
 )
 VALUES
 (
 ''DERIVATIVE PREMIUM1'',
 V_BTCH_ID,
 V_PROC_NAME,
 ''START'',
 ''PROCEDURE STARTS'',
 V_ROWS_AFFTD,
 SYSTIMESTAMP
 );
 */
--
---------------------------OAS DELETE---------------------------

/*  AOP De-scope (MR)
 EXECUTE IMMEDIATE ''TRUNCATE TABLE DM.WRK_WRITING_AGENT'';
 EXECUTE IMMEDIATE ''TRUNCATE TABLE DM.WRK_SELLING_AGENT'';
 EXECUTE IMMEDIATE ''TRUNCATE TABLE DM.WRK_REFERRAL_AGENT'';
 */
-- AOP Scope (MR)

---------------------------OAS ADD------------------------------
--
V_STEP_NAME := ''TARGET - TRUNCATE WRK_RIA_WRITING_AGENT'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

--
---------------------------OAS ADD------------------------------

EXECUTE IMMEDIATE ''TRUNCATE TABLE BDR_DM.WRK_RIA_WRITING_AGENT'';

---------------------------OAS ADD------------------------------
--

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

--
---------------------------OAS ADD------------------------------

---------------------------OAS ADD------------------------------
--
V_STEP_NAME := ''TARGET - TRUNCATE WRK_RIA_SELLING_AGENT'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;
--
---------------------------OAS ADD------------------------------

EXECUTE IMMEDIATE ''TRUNCATE TABLE BDR_DM.WRK_RIA_SELLING_AGENT'';

---------------------------OAS ADD------------------------------
--
INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );
--
---------------------------OAS ADD------------------------------

---------------------------OAS ADD------------------------------
--
V_STEP_NAME := ''TARGET - TRUNCATE WRK_RIA_REFERRAL_AGENT'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;
--
---------------------------OAS ADD------------------------------

EXECUTE IMMEDIATE ''TRUNCATE TABLE BDR_DM.WRK_RIA_REFERRAL_AGENT'';

---------------------------OAS ADD------------------------------
--
INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );
--
---------------------------OAS ADD------------------------------

---------------------------OAS ADD------------------------------
--
V_STEP_NAME := ''TARGET - INSERT WRK_RIA_WRITING_AGENT'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;
--
---------------------------OAS ADD------------------------------

INSERT
  ALL
  WHEN ACTIONFLG = ''ZOTHERSWRITING''
  OR ACTIONFLG = ''MATCHEDWRITING''
  OR ACTIONFLG = ''AGENTWRITING'' THEN
  /*+ enable_parallel_dml APPEND */
  INTO BDR_DM.WRK_RIA_WRITING_AGENT
VALUES
  (BLR_RN, AGENT_ID, CURRENT_SIGNATURE_DATE, D_AGT_SK)
  WHEN ACTIONFLG = ''ZOTHERSSELLING''
  OR ACTIONFLG = ''MATCHEDSELLING''
  OR ACTIONFLG = ''AGENTSELLING'' THEN
  /*+ enable_parallel_dml APPEND */
  INTO BDR_DM.WRK_RIA_SELLING_AGENT
VALUES
  (BLR_RN, AGENT_ID, CURRENT_SIGNATURE_DATE, D_AGT_SK)
  WHEN ACTIONFLG = ''ZOTHERSREFERRAL''
  OR ACTIONFLG = ''MATCHEDREFERRAL''
  OR ACTIONFLG = ''AGENTREFERRAL'' THEN
  /*+ enable_parallel_dml APPEND */
  INTO BDR_DM.WRK_RIA_REFERRAL_AGENT
VALUES
  (
    BLR_RN,
    AGENT_ID,
    CURRENT_SIGNATURE_DATE,
    D_AGT_SK
  )
SELECT
  *
FROM
  (
    WITH TMP_WRITING_SELLING_REFERRAL AS (
      SELECT
        /*+MATERIALIZE*/
        *
      FROM
        (
          SELECT
            CAST (
              CASE
                WHEN BLR.AGENT_ID NOT IN (''-1'', ''-2'')
                AND (
                  REPLACE(
                    TO_CHAR(BLR.CURRENT_SIGNATURE_DATE, ''YYYYMMDD''),
                    ''-'',
                    ''''
                  ) BETWEEN WR_SEL_REF_AGT.AGT_WRT_STRT_DT_ID
                  AND WR_SEL_REF_AGT.AGT_WRT_END_DT_ID
                )
                AND BLR.AGENT_TYPE_ID = 1 THEN ''MATCHEDWRITING''
                WHEN BLR.AGENT_ID NOT IN (''-1'', ''-2'')
                AND (
                  REPLACE(
                    TO_CHAR(BLR.CURRENT_SIGNATURE_DATE, ''YYYYMMDD''),
                    ''-'',
                    ''''
                  ) BETWEEN WR_SEL_REF_AGT.AGT_WRT_STRT_DT_ID
                  AND WR_SEL_REF_AGT.AGT_WRT_END_DT_ID
                )
                AND BLR.AGENT_TYPE_ID = 2 THEN ''MATCHEDSELLING''
                WHEN BLR.AGENT_ID NOT IN (''-1'', ''-2'')
                AND (
                  REPLACE(
                    TO_CHAR(BLR.CURRENT_SIGNATURE_DATE, ''YYYYMMDD''),
                    ''-'',
                    ''''
                  ) BETWEEN WR_SEL_REF_AGT.AGT_WRT_STRT_DT_ID
                  AND WR_SEL_REF_AGT.AGT_WRT_END_DT_ID
                )
                AND BLR.AGENT_TYPE_ID = 5 THEN ''MATCHEDREFERRAL''
                WHEN BLR.AGENT_ID IN (''-1'', ''-2'')
                AND BLR.AGENT_TYPE_ID = 1 THEN ''AGENTWRITING''
                WHEN BLR.AGENT_ID IN (''-1'', ''-2'')
                AND BLR.AGENT_TYPE_ID = 2 THEN ''AGENTSELLING''
                WHEN BLR.AGENT_ID IN (''-1'', ''-2'')
                AND BLR.AGENT_TYPE_ID = 5 THEN ''AGENTREFERRAL''
                WHEN BLR.AGENT_TYPE_ID = 1 THEN ''ZOTHERSWRITING''
                WHEN BLR.AGENT_TYPE_ID = 2 THEN ''ZOTHERSSELLING''
                WHEN BLR.AGENT_TYPE_ID = 5 THEN ''ZOTHERSREFERRAL''
                ELSE ''ZOTHERS''
              END AS VARCHAR(50)
            ) AS ACTIONFLG,
            BLR.BLR_RN,
            WR_SEL_REF_AGT.D_AGT_SK,
            BLR.INSURED_PLAN_ID,
            BLR.PREMIUM_DUE_DATE,
            BLR.AGENT_ID,
            BLR.AGENT_TYPE_ID,
            BLR.CURRENT_SIGNATURE_DATE,
            WR_SEL_REF_AGT.ROW_EFF_STRT_DT,
            WR_SEL_REF_AGT.AGT_WRT_STRT_DT_ID,
            WR_SEL_REF_AGT.AGT_ID
          FROM
            (
              SELECT
                BL.BLR_RN,
                BL.INSURED_PLAN_ID,
                BL.PREMIUM_DUE_DATE,
                CASE
                  WHEN APP.APPL_SIGNATURE_DATE IS NULL
                  OR (
                    APP.APPL_SIGNATURE_DATE > IP.INSURED_PLAN_EFFECTIVE_DATE
                  ) THEN CASE
                    WHEN APP.APPL_RECEIPT_DATE IS NULL
                    OR (
                      APP.APPL_RECEIPT_DATE > IP.INSURED_PLAN_EFFECTIVE_DATE
                    ) THEN CASE
                      WHEN APP.CREATION_DATE > IP.INSURED_PLAN_EFFECTIVE_DATE THEN IP.INSURED_PLAN_EFFECTIVE_DATE
                      ELSE APP.CREATION_DATE
                    END
                    ELSE APP.APPL_RECEIPT_DATE
                  END
                  ELSE APP.APPL_SIGNATURE_DATE
                END AS CURRENT_SIGNATURE_DATE,
                CASE
                  WHEN BL.PRODUCT_GROUP <> ''Med Supp'' THEN ''-2''
                  WHEN BL.PRODUCT_GROUP = ''Med Supp''
                  AND CHL.ACQN_CHNL_LVL_3 IS NOT NULL THEN ''-2''
                  WHEN AGENT_TYPE_ID IS NULL THEN ''-1''
                  ELSE NVL(AAG_WR.AGENT_ID, ''-1'')
                END AS AGENT_ID,
                nvl(agent_type_id, 1) AGENT_TYPE_ID -- AOP De-Scope (MR)
                --FROM          DM.WRK_PREMIUM_DATA_BL_REBUILD BL
                -- AOP Scope (MR)
              FROM
                BDR_DM.WRK_RIA_PREMIUM_DATA_BL_REBUILD BL
                LEFT JOIN SRC_COMPAS_D.INSURED_PLAN IP ON BL.INSURED_PLAN_ID = IP.INSURED_PLAN_ID
                LEFT JOIN SRC_COMPAS_D.APPLICATION APP ON IP.APPLICATION_ID = APP.APPLICATION_ID
                LEFT JOIN SRC_COMPAS_D.APPLICATION_AGENT AAG_WR ON (
                  (
                    APP.APPLICATION_ID = AAG_WR.APPLICATION_ID
                    and AAG_WR.AGENT_TYPE_ID = 1
                  )
                )
                LEFT JOIN (
                  SELECT
                    DISTINCT ACQN_CHNL_LVL_3
                  FROM
                    BDR_CONF.D_ACQN_CHNL
                  WHERE
                    ACQN_CHNL_LVL_1 NOT IN (''Aggregator'', ''Agent'')
                ) CHL ON BL.CERT_ACQN_CHNL_LEVEL3 = CHL.ACQN_CHNL_LVL_3
              UNION
              SELECT
                BL.BLR_RN,
                BL.INSURED_PLAN_ID,
                BL.PREMIUM_DUE_DATE,
                CASE
                  WHEN APP.APPL_SIGNATURE_DATE IS NULL
                  OR (
                    APP.APPL_SIGNATURE_DATE > IP.INSURED_PLAN_EFFECTIVE_DATE
                  ) THEN CASE
                    WHEN APP.APPL_RECEIPT_DATE IS NULL
                    OR (
                      APP.APPL_RECEIPT_DATE > IP.INSURED_PLAN_EFFECTIVE_DATE
                    ) THEN CASE
                      WHEN APP.CREATION_DATE > IP.INSURED_PLAN_EFFECTIVE_DATE THEN IP.INSURED_PLAN_EFFECTIVE_DATE
                      ELSE APP.CREATION_DATE
                    END
                    ELSE APP.APPL_RECEIPT_DATE
                  END
                  ELSE APP.APPL_SIGNATURE_DATE
                END AS CURRENT_SIGNATURE_DATE,
                CASE
                  WHEN BL.PRODUCT_GROUP <> ''Med Supp'' THEN ''-2''
                  WHEN BL.PRODUCT_GROUP = ''Med Supp''
                  AND CHL.ACQN_CHNL_LVL_3 IS NOT NULL THEN ''-2''
                  WHEN AGENT_TYPE_ID IS NULL THEN ''-1''
                  ELSE NVL(AAG_WR.AGENT_ID, ''-1'')
                END AS AGENT_ID,
                nvl(agent_type_id, 2) AGENT_TYPE_ID -- AOP De-Scope (MR)
                --FROM          DM.WRK_PREMIUM_DATA_BL_REBUILD BL
                -- AOP Scope (MR)
              FROM
                BDR_DM.WRK_RIA_PREMIUM_DATA_BL_REBUILD BL
                LEFT JOIN SRC_COMPAS_D.INSURED_PLAN IP ON BL.INSURED_PLAN_ID = IP.INSURED_PLAN_ID
                LEFT JOIN SRC_COMPAS_D.APPLICATION APP ON IP.APPLICATION_ID = APP.APPLICATION_ID
                LEFT JOIN SRC_COMPAS_D.APPLICATION_AGENT AAG_WR ON (
                  (
                    APP.APPLICATION_ID = AAG_WR.APPLICATION_ID
                    and AAG_WR.AGENT_TYPE_ID = 2
                  )
                )
                LEFT JOIN (
                  SELECT
                    DISTINCT ACQN_CHNL_LVL_3
                  FROM
                    BDR_CONF.D_ACQN_CHNL
                  WHERE
                    ACQN_CHNL_LVL_1 NOT IN (''Aggregator'', ''Agent'')
                ) CHL ON BL.CERT_ACQN_CHNL_LEVEL3 = CHL.ACQN_CHNL_LVL_3
              UNION
              SELECT
                BL.BLR_RN,
                BL.INSURED_PLAN_ID,
                BL.PREMIUM_DUE_DATE,
                CASE
                  WHEN APP.APPL_SIGNATURE_DATE IS NULL
                  OR (
                    APP.APPL_SIGNATURE_DATE > IP.INSURED_PLAN_EFFECTIVE_DATE
                  ) THEN CASE
                    WHEN APP.APPL_RECEIPT_DATE IS NULL
                    OR (
                      APP.APPL_RECEIPT_DATE > IP.INSURED_PLAN_EFFECTIVE_DATE
                    ) THEN CASE
                      WHEN APP.CREATION_DATE > IP.INSURED_PLAN_EFFECTIVE_DATE THEN IP.INSURED_PLAN_EFFECTIVE_DATE
                      ELSE APP.CREATION_DATE
                    END
                    ELSE APP.APPL_RECEIPT_DATE
                  END
                  ELSE APP.APPL_SIGNATURE_DATE
                END AS CURRENT_SIGNATURE_DATE,
                CASE
                  WHEN BL.PRODUCT_GROUP <> ''Med Supp'' THEN ''-2''
                  WHEN BL.PRODUCT_GROUP = ''Med Supp''
                  AND CHL.ACQN_CHNL_LVL_3 IS NOT NULL THEN ''-2''
                  WHEN AGENT_TYPE_ID IS NULL THEN ''-2''
                  ELSE NVL(AAG_WR.AGENT_ID, ''-1'')
                END AS AGENT_ID,
                nvl(agent_type_id, 5) AGENT_TYPE_ID -- AOP De-Scope (MR)
                --FROM          DM.WRK_PREMIUM_DATA_BL_REBUILD BL
                -- AOP Scope (MR)
              FROM
                BDR_DM.WRK_RIA_PREMIUM_DATA_BL_REBUILD BL
                LEFT JOIN SRC_COMPAS_D.INSURED_PLAN IP ON BL.INSURED_PLAN_ID = IP.INSURED_PLAN_ID
                LEFT JOIN SRC_COMPAS_D.APPLICATION APP ON IP.APPLICATION_ID = APP.APPLICATION_ID
                LEFT JOIN SRC_COMPAS_D.APPLICATION_AGENT AAG_WR ON (
                  (
                    APP.APPLICATION_ID = AAG_WR.APPLICATION_ID
                    and AAG_WR.AGENT_TYPE_ID = 5
                  )
                )
                LEFT JOIN (
                  SELECT
                    DISTINCT ACQN_CHNL_LVL_3
                  FROM
                    BDR_CONF.D_ACQN_CHNL
                  WHERE
                    ACQN_CHNL_LVL_1 NOT IN (''Aggregator'', ''Agent'')
                ) CHL ON BL.CERT_ACQN_CHNL_LEVEL3 = CHL.ACQN_CHNL_LVL_3
            ) BLR
            LEFT JOIN BDR_DM.TEMP_AGT_ORG_SELLING_WRITING WR_SEL_REF_AGT ON BLR.AGENT_ID = WR_SEL_REF_AGT.AGT_ID
        )
    )
    SELECT
      /*+ Parallel (8)*/
      ACTIONFLG,
      BLR_RN,
      AGENT_ID,
      CURRENT_SIGNATURE_DATE,
      NVL(D_AGT_SK, -1) AS D_AGT_SK
    FROM
      (
        SELECT
          ALT.ACTIONFLG,
          ALT.BLR_RN,
          ALT.D_AGT_SK,
          ALT.INSURED_PLAN_ID,
          ALT.PREMIUM_DUE_DATE,
          ALT.AGENT_ID,
          ALT.AGENT_TYPE_ID,
          ALT.CURRENT_SIGNATURE_DATE,
          ALT.ROW_EFF_STRT_DT,
          ALT.AGT_WRT_STRT_DT_ID,
          ALT.AGT_ID,
          ROW_NUMBER () OVER(
            PARTITION BY ALT.BLR_RN
            ORDER BY
			--ABS(ALT.CURRENT_SIGNATURE_DATE - TO_DATE(ALT.AGT_WRT_STRT_DT_ID,''YYYYMMDD'')), ALT.ROW_EFF_STRT_DT DESC) AS RN		---------OAS DELETE
              ABS(
                DATEDIFF(''DD'', TO_DATE(TO_CHAR(ALT.AGT_WRT_STRT_DT_ID), ''YYYYMMDD''), ALT.CURRENT_SIGNATURE_DATE)
              ),
              ALT.ROW_EFF_STRT_DT DESC
          ) AS RN		------------------OAS ADD
        FROM
          (
            SELECT
              *
            FROM
              TMP_WRITING_SELLING_REFERRAL
            WHERE
              ACTIONFLG = ''ZOTHERSWRITING''
          ) ALT
          LEFT JOIN TMP_WRITING_SELLING_REFERRAL MTCH ON MTCH.BLR_RN = ALT.BLR_RN
          AND MTCH.ACTIONFLG = ''MATCHEDWRITING''
        WHERE
          MTCH.BLR_RN IS NULL
        UNION
        SELECT
          ALT.ACTIONFLG,
          ALT.BLR_RN,
          ALT.D_AGT_SK,
          ALT.INSURED_PLAN_ID,
          ALT.PREMIUM_DUE_DATE,
          ALT.AGENT_ID,
          ALT.AGENT_TYPE_ID,
          ALT.CURRENT_SIGNATURE_DATE,
          ALT.ROW_EFF_STRT_DT,
          ALT.AGT_WRT_STRT_DT_ID,
          ALT.AGT_ID,
          ROW_NUMBER() OVER(
            PARTITION BY ALT.BLR_RN
            ORDER BY
			--ABS(ALT.CURRENT_SIGNATURE_DATE - TO_DATE(ALT.AGT_WRT_STRT_DT_ID,''YYYYMMDD'')),ALT.ROW_EFF_STRT_DT DESC)  RN	---------------OAS DELETE
              ABS(
                DATEDIFF(''DD'', TO_DATE(TO_CHAR(ALT.AGT_WRT_STRT_DT_ID), ''YYYYMMDD''), ALT.CURRENT_SIGNATURE_DATE)
              ),
              ALT.ROW_EFF_STRT_DT DESC
          ) RN		-----------------OAS ADD
        FROM
          (
            SELECT
              *
            FROM
              TMP_WRITING_SELLING_REFERRAL
            WHERE
              ACTIONFLG = ''ZOTHERSSELLING''
          ) ALT
          LEFT JOIN TMP_WRITING_SELLING_REFERRAL MTCH ON MTCH.BLR_RN = ALT.BLR_RN
          AND MTCH.ACTIONFLG = ''MATCHEDSELLING''
        WHERE
          MTCH.BLR_RN IS NULL
        UNION
        SELECT
          ALT.ACTIONFLG,
          ALT.BLR_RN,
          ALT.D_AGT_SK,
          ALT.INSURED_PLAN_ID,
          ALT.PREMIUM_DUE_DATE,
          ALT.AGENT_ID,
          ALT.AGENT_TYPE_ID,
          ALT.CURRENT_SIGNATURE_DATE,
          ALT.ROW_EFF_STRT_DT,
          ALT.AGT_WRT_STRT_DT_ID,
          ALT.AGT_ID,
          ROW_NUMBER () OVER(
            PARTITION BY ALT.BLR_RN
            ORDER BY
			--ABS(ALT.CURRENT_SIGNATURE_DATE - TO_DATE(ALT.AGT_WRT_STRT_DT_ID,''YYYYMMDD'')), ALT.ROW_EFF_STRT_DT DESC) AS RN			----------------OAS DELETE
              ABS(
                DATEDIFF(''DD'', TO_DATE(TO_CHAR(ALT.AGT_WRT_STRT_DT_ID), ''YYYYMMDD''), ALT.CURRENT_SIGNATURE_DATE)
              ),
              ALT.ROW_EFF_STRT_DT DESC
          ) AS RN		------------------OAS ADD
        FROM
          (
            SELECT
              *
            FROM
              TMP_WRITING_SELLING_REFERRAL
            WHERE
              ACTIONFLG = ''ZOTHERSREFERRAL''
          ) ALT
          LEFT JOIN TMP_WRITING_SELLING_REFERRAL MTCH ON MTCH.BLR_RN = ALT.BLR_RN
          AND MTCH.ACTIONFLG = ''MATCHEDREFERRAL''
        WHERE
          MTCH.BLR_RN IS NULL
      )
    WHERE
      RN = 1
    UNION ALL
    SELECT
      /*+ Parallel (8)*/
      ACTIONFLG,
      BLR_RN,
      AGENT_ID,
      CURRENT_SIGNATURE_DATE,
      D_AGT_SK
    FROM
      TMP_WRITING_SELLING_REFERRAL
    WHERE
      ACTIONFLG IN (
        ''MATCHEDSELLING'',
        ''MATCHEDWRITING'',
        ''MATCHEDREFERRAL''
      )
    UNION ALL
    SELECT
      /*+ Parallel (8)*/
      ACTIONFLG,
      BLR_RN,
      AGENT_ID,
      CURRENT_SIGNATURE_DATE,
      CAST(AGENT_ID AS INT) AS D_AGT_SK
    FROM
      TMP_WRITING_SELLING_REFERRAL
    WHERE
      ACTIONFLG IN (''AGENTSELLING'', ''AGENTWRITING'', ''AGENTREFERRAL'')
  );

---------------------------OAS ADD------------------------------
--
    	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

V_ROWS_INSERTED1 := (SELECT $2 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

V_ROWS_INSERTED2 := (SELECT $3 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

V_STEP_NAME := ''TARGET - INSERT ALL WRK_RIA_SELLING_AGENT'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED1, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

V_STEP_NAME := ''TARGET - INSERT ALL WRK_RIA_REFERRAL_AGENT'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED2, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

--
---------------------------OAS ADD------------------------------

---------------------------OAS DELETE---------------------------
--
/*
V_ROWS_AFFTD := SQL % ROWCOUNT;

commit;

INSERT INTO
  ETL.ETL_DETAIL_LOAD_INFO (
    APPLICATION,
    ETL_BATCH_ID,
    ETL_PROC_NAME,
    ACTION,
    STEP_INFO,
    ROWS_AFFECTED,
    ETL_DATETIME
  )
VALUES
  (
    ''DERIVATIVE PREMIUM2'',
    V_BTCH_ID,
    V_PROC_NAME,
    ''INSERT'',
    ''INSERT INTO WRK_RIA_SELLING_AGENT AND WRK_RIA_WRITING_AGENT'',
    V_ROWS_AFFTD,
    SYSTIMESTAMP
  );
  */
--
---------------------------OAS DELETE---------------------------

/* DM.PKG_DB_UTIL.SP_DBUTIL_CONFIG_D(
  ''DM'',
  ''WRK_RIA_SELLING_AGENT'',
  ''POSTSQL'',
  ''s_m_Premium_Derivative1_IXL_WritingSellingAgent_D''
); */		---OAS DELETE

---BEGIN DBMS_STATS.GATHER_TABLE_STATS (ownname => ''DM'',tabname => ''WRK_RIA_SELLING_AGENT'',partname => NULL,estimate_percent => 10,DEGREE => 4,granularity => ''ALL'',method_opt =>''FOR ALL COLUMNS SIZE 1'',CASCADE => TRUE);END; 		--POST SQL FROM SP_DBUTIL_CONFIG_D	----OAS DELETE



/*DM.PKG_DB_UTIL.SP_DBUTIL_CONFIG_D(
  ''DM'',
  ''WRK_RIA_WRITING_AGENT'',
  ''POSTSQL'',
  ''s_m_Premium_Derivative1_IXL_WritingSellingAgent_D''
);*/		---OAS DELETE

---BEGIN DBMS_STATS.GATHER_TABLE_STATS (ownname => ''DM'',tabname => ''WRK_RIA_SELLING_AGENT'',partname => NULL,estimate_percent => 10,DEGREE => 4,granularity => ''ALL'',method_opt =>''FOR ALL COLUMNS SIZE 1'',CASCADE => TRUE);END; 		--POST SQL FROM SP_DBUTIL_CONFIG_D	----OAS DELETE

--DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'', ''WRK_RIA_REFERRAL_AGENT'');		-------------OAS DELETE


---------------------------OAS ADD------------------------------
--
V_STEP_NAME := ''TARGET - DELETE WRK_RIA_SELLING_AGENT'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;
--
---------------------------OAS ADD------------------------------

-- AOP Scope (MR)
DELETE
/*+ enable_parallel_dml parallel(8) */
FROM
  BDR_DM.WRK_RIA_SELLING_AGENT
WHERE
  (BLR_RN, AGT_SEL_SKEY) IN (
    SELECT
      DISTINCT BLR_RN,
      AGT_SEL_SKEY
    FROM
(
        SELECT
          /*+ parallel(8) */
          BLR_RN,
          SELLING_AGENT,
          CURRENT_SIGNATURE_DATE,
          AGT_SEL_SKEY,
          ROW_NUMBER() OVER(
            PARTITION BY BLR_RN,
            SELLING_AGENT,
            CURRENT_SIGNATURE_DATE
            ORDER BY
              AGT_SEL_SKEY DESC
          ) RN
        FROM
          BDR_DM.WRK_RIA_SELLING_AGENT
      )
    WHERE
      RN > 1
  );

---------------------------OAS ADD------------------------------
--
V_LAST_QUERY_ID := (
  SELECT
    LAST_QUERY_ID()
);

V_ROWS_DELETED := (
  SELECT
    *
  FROM
    TABLE (RESULT_SCAN (:V_LAST_QUERY_ID))
);

INSERT INTO
  UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (
    APPLICATION,
    WORKFLOW_NAME,
    TABLE_NAME,
    BATCH_ID,
    STATUS,
    STEP,
    SEQ,
    ROWS_INSERTED,
    ROWS_UPDATED,
    ROWS_DELETED,
    STEP_START_DATETIME,
    STEP_END_DATETIME
  )
VALUES
  (
    :APPLICATION,
    :WORKFLOW_NAME,
    :OBJECT_NAME,
    :V_BATCH_ID,
    ''COMPLETE'',
    :V_STEP_NAME,
    :V_STEP_SEQ,
    :V_ROWS_INSERTED,
    :V_ROWS_UPDATED,
    :V_ROWS_DELETED,
    :V_STEP_START_TIME,
    CURRENT_TIMESTAMP()
  );
--
---------------------------OAS ADD------------------------------

---------------------------OAS DELETE---------------------------
--
/*
V_ROWS_AFFTD := SQL % ROWCOUNT;

commit;
*/
--
---------------------------OAS DELETE---------------------------

---------------------------OAS ADD------------------------------
--
V_STEP_NAME := ''TARGET - DELETE WRK_RIA_WRITING_AGENT'';

V_STEP_SEQ := V_STEP_SEQ + 1;

V_STEP_START_TIME := (
  SELECT
    CURRENT_TIMESTAMP()
);

V_ROWS_INSERTED := null;

V_ROWS_UPDATED := null;

V_ROWS_DELETED := null;
--
---------------------------OAS ADD------------------------------

DELETE
/*+ enable_parallel_dml parallel(8) */
FROM
  BDR_DM.WRK_RIA_WRITING_AGENT
WHERE
  (BLR_RN, AGT_WRT_SKEY) IN (
    SELECT
      DISTINCT BLR_RN,
      AGT_WRT_SKEY
    FROM
(
        SELECT
          /*+ parallel(8) */
          BLR_RN,
          WRITING_AGENT,
          CURRENT_SIGNATURE_DATE,
          AGT_WRT_SKEY,
          ROW_NUMBER() OVER(
            PARTITION BY BLR_RN,
            WRITING_AGENT,
            CURRENT_SIGNATURE_DATE
            ORDER BY
              AGT_WRT_SKEY DESC
          ) RN
        FROM
          BDR_DM.WRK_RIA_WRITING_AGENT
      )
    WHERE
      RN > 1
  );

---------------------------OAS ADD------------------------------
--
V_LAST_QUERY_ID := (
  SELECT
    LAST_QUERY_ID()
);

V_ROWS_DELETED := (
  SELECT
    *
  FROM
    TABLE (RESULT_SCAN (:V_LAST_QUERY_ID))
);

INSERT INTO
  UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (
    APPLICATION,
    WORKFLOW_NAME,
    TABLE_NAME,
    BATCH_ID,
    STATUS,
    STEP,
    SEQ,
    ROWS_INSERTED,
    ROWS_UPDATED,
    ROWS_DELETED,
    STEP_START_DATETIME,
    STEP_END_DATETIME
  )
VALUES
  (
    :APPLICATION,
    :WORKFLOW_NAME,
    :OBJECT_NAME,
    :V_BATCH_ID,
    ''COMPLETE'',
    :V_STEP_NAME,
    :V_STEP_SEQ,
    :V_ROWS_INSERTED,
    :V_ROWS_UPDATED,
    :V_ROWS_DELETED,
    :V_STEP_START_TIME,
    CURRENT_TIMESTAMP()
  );
--
---------------------------OAS ADD------------------------------

---------------------------OAS DELETE---------------------------
--
/*
V_ROWS_AFFTD := SQL % ROWCOUNT;

commit;
*/
--
---------------------------OAS DELETE---------------------------

---------------------------OAS ADD------------------------------
--
V_STEP_NAME := ''TARGET - DELETE WRK_RIA_REFERRAL_AGENT'';

V_STEP_SEQ := V_STEP_SEQ + 1;

V_STEP_START_TIME := (
  SELECT
    CURRENT_TIMESTAMP()
);

V_ROWS_INSERTED := null;

V_ROWS_UPDATED := null;

V_ROWS_DELETED := null;
--
---------------------------OAS ADD------------------------------

DELETE
/*+ enable_parallel_dml parallel(8) */
FROM
  BDR_DM.WRK_RIA_REFERRAL_AGENT
WHERE
  (BLR_RN, AGT_REF_SKEY) IN (
    SELECT
      DISTINCT BLR_RN,
      AGT_REF_SKEY
    FROM
(
        SELECT
          /*+ parallel(8) */
          BLR_RN,
          REFERRAL_AGENT,
          CURRENT_SIGNATURE_DATE,
          AGT_REF_SKEY,
          ROW_NUMBER() OVER(
            PARTITION BY BLR_RN,
            REFERRAL_AGENT,
            CURRENT_SIGNATURE_DATE
            ORDER BY
              AGT_REF_SKEY DESC
          ) RN
        FROM
          BDR_DM.WRK_RIA_REFERRAL_AGENT
      )
    WHERE
      RN > 1
  );

---------------------------OAS ADD------------------------------
--
V_LAST_QUERY_ID := (
  SELECT
    LAST_QUERY_ID()
);

V_ROWS_DELETED := (
  SELECT
    *
  FROM
    TABLE (RESULT_SCAN (:V_LAST_QUERY_ID))
);

INSERT INTO
  UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (
    APPLICATION,
    WORKFLOW_NAME,
    TABLE_NAME,
    BATCH_ID,
    STATUS,
    STEP,
    SEQ,
    ROWS_INSERTED,
    ROWS_UPDATED,
    ROWS_DELETED,
    STEP_START_DATETIME,
    STEP_END_DATETIME
  )
VALUES
  (
    :APPLICATION,
    :WORKFLOW_NAME,
    :OBJECT_NAME,
    :V_BATCH_ID,
    ''COMPLETE'',
    :V_STEP_NAME,
    :V_STEP_SEQ,
    :V_ROWS_INSERTED,
    :V_ROWS_UPDATED,
    :V_ROWS_DELETED,
    :V_STEP_START_TIME,
    CURRENT_TIMESTAMP()
  );
--
---------------------------OAS ADD------------------------------

---------------------------OAS DELETE---------------------------
--
/*
V_ROWS_AFFTD := SQL % ROWCOUNT;

commit;
*/
--
---------------------------OAS DELETE---------------------------

--  DELETE /*+ enable_parallel_dml parallel(8) */  FROM DM.WRK_RIA_SELLING_AGENT WHERE AGT_SEL_SKEY in
--  (SELECT AGT_SEL_SKEY FROM(SELECT /*+ parallel(8) */  BLR_RN,SELLING_AGENT,CURRENT_SIGNATURE_DATE,AGT_SEL_SKEY, ROW_NUMBER() OVER(PARTITION BY BLR_RN,SELLING_AGENT,CURRENT_SIGNATURE_DATE
--              ORDER BY AGT_SEL_SKEY DESC) RN FROM  DM.WRK_RIA_SELLING_AGENT) WHERE RN>1);
--              V_ROWS_AFFTD:=SQL%ROWCOUNT;
--              commit;
--
--  DELETE /*+ enable_parallel_dml parallel(8) */  FROM DM.WRK_RIA_WRITING_AGENT WHERE AGT_WRT_SKEY in
--    (SELECT AGT_WRT_SKEY FROM(SELECT /*+ parallel(8) */  BLR_RN,WRITING_AGENT,CURRENT_SIGNATURE_DATE,AGT_WRT_SKEY ,ROW_NUMBER() OVER(PARTITION BY BLR_RN,WRITING_AGENT,CURRENT_SIGNATURE_DATE
--              ORDER BY AGT_WRT_SKEY DESC) RN FROM  DM.WRK_RIA_WRITING_AGENT) WHERE RN>1);
--              V_ROWS_AFFTD:=SQL%ROWCOUNT;
--              commit;
--
--   DELETE /*+ enable_parallel_dml parallel(8) */  FROM DM.WRK_RIA_REFERRAL_AGENT WHERE AGT_REF_SKEY in
--    (SELECT AGT_REF_SKEY FROM(SELECT /*+ parallel(8) */  BLR_RN, REFERRAL_AGENT, CURRENT_SIGNATURE_DATE, AGT_REF_SKEY, ROW_NUMBER() OVER(PARTITION BY BLR_RN, REFERRAL_AGENT, CURRENT_SIGNATURE_DATE
--              ORDER BY AGT_REF_SKEY DESC) RN FROM  DM.WRK_RIA_REFERRAL_AGENT) WHERE RN>1);
--              V_ROWS_AFFTD:=SQL%ROWCOUNT;
--              commit;

---------------------------OAS DELETE---------------------------
--
/*
INSERT INTO
  ETL.ETL_DETAIL_LOAD_INFO (
    APPLICATION,
    ETL_BATCH_ID,
    ETL_PROC_NAME,
    ACTION,
    STEP_INFO,
    ROWS_AFFECTED,
    ETL_DATETIME
  )
VALUES
  (
    ''DERIVATIVE PREMIUM2'',
    V_BTCH_ID,
    V_PROC_NAME,
    ''END'',
    ''PROCEDURE END'',
    V_ROWS_AFFTD,
    SYSTIMESTAMP
  );

P_ToContinueStatus := ''Y'';

P_ErrorYNFlg := ''N'';

P_ErrorStr := '''';

COMMIT;

EXCEPTION
WHEN OTHERS THEN P_ErrorStr := ''ERROR: '' || SQLCODE || ''-'' || SQLERRM || ''-'' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE() || Chr(10) || DBMS_UTILITY.FORMAT_ERROR_STACK();

P_ToContinueStatus := ''N'';

P_ErrorYNFlg := ''Y'';

ROLLBACK;

END;

/
*/
--
---------------------------OAS DELETE---------------------------

---------------------------OAS ADD------------------------------
--
CALL UTIL.SP_ETL_CHECK_CONSTRAINTS(:DB_NAME , :APPLICATION , :WORKFLOW_NAME , :OBJECT_NAME , :V_BATCH_ID );


UPDATE
    UTIL.ETL_BATCH_OBJECT_CONTROL
SET
    STATUS = ''COMPLETE'',
    ERROR_MSG = null,
    BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME,
    BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE
    APPLICATION = :APPLICATION
    AND WORKFLOW_NAME = :WORKFLOW_NAME
    AND OBJECT_NAME = :OBJECT_NAME;

UPDATE
    UTIL.ETL_BATCH_OBJECT_INCR_VALU
SET
    INCR_COLUMN_VALUE = :V_BATCH_ID,
    LST_MOD_DT = CURRENT_TIMESTAMP()
WHERE
    APPLICATION = :APPLICATION
    AND WORKFLOW_NAME = :WORKFLOW_NAME
    AND OBJECT_NAME = :OBJECT_NAME
    AND INCR_COLUMN = ''ETL_LST_BTCH_ID'';

EXCEPTION
WHEN OTHER THEN
UPDATE
    UTIL.ETL_BATCH_OBJECT_CONTROL
SET
    STATUS = ''ERROR'',
    ERROR_MSG = :SQLERRM,
    BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME,
    BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE
    APPLICATION = :APPLICATION
    AND WORKFLOW_NAME = :WORKFLOW_NAME
    AND OBJECT_NAME = :OBJECT_NAME;

INSERT INTO
    UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (
        APPLICATION,
        WORKFLOW_NAME,
        TABLE_NAME,
        BATCH_ID,
        STATUS,
        STEP,
        SEQ,
        ERROR_MSG,
        STEP_START_DATETIME,
        STEP_END_DATETIME
    )
VALUES
    (
        :APPLICATION,
        :WORKFLOW_NAME,
        :OBJECT_NAME,
        :V_BATCH_ID,
        ''ERROR'',
        :V_STEP_NAME,
        :V_STEP_SEQ,
        :SQLERRM,
        :V_STEP_START_TIME,
        CURRENT_TIMESTAMP()
    );

RAISE;

END;
--
---------------------------OAS ADD------------------------------
';