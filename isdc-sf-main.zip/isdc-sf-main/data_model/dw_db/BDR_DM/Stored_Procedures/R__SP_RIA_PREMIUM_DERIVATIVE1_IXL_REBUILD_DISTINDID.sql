USE SCHEMA BDR_DM; CREATE OR REPLACE PROCEDURE "SP_RIA_PREMIUM_DERIVATIVE1_IXL_REBUILD_DISTINDID"("DB_NAME" VARCHAR(16777216), "APPLICATION" VARCHAR(16777216), "WORKFLOW_NAME" VARCHAR(16777216), "OBJECT_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '

-- Original workflow: wkf_RIA_Premium_Derivative_IXL_TargetLoad1_D
-- Original mapping: m_RIA_Premium_Derivative1_IXL_REBUILD_DISTINDID
-- Original folder: Premium
-- Original filename: wkf_RIA_Premium_Derivative_IXL_TargetLoad1_D.XML

DECLARE


V_ROWS_INSERTED  INTEGER;
V_ROWS_UPDATED INTEGER;
V_ROWS_DELETED INTEGER;
V_LAST_QUERY_ID VARCHAR;

V_WH VARCHAR;
V_BATCH_ID INTEGER;


V_BATCH_OBJECT_START_TIME        VARCHAR;
V_STEP_START_TIME    VARCHAR;
V_STEP_NAME VARCHAR;
V_STEP_SEQ INTEGER DEFAULT 0;
V_ETL_LST_BTCH_ID INTEGER;

V_ETLLASTDCMPROCESSDATE VARCHAR;
V_AOP_LIVE_DATE VARCHAR;
V_UNDWR_ETL_LST_BTCH_ID INTEGER;


BEGIN

EXECUTE IMMEDIATE ''USE DATABASE ''||:DB_NAME; 

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_BATCH_OBJECT_START_TIME := (SELECT CURRENT_TIMESTAMP());



LET res1 RESULTSET := 
(

SELECT 

WH ,
BATCH_ID
  
FROM UTIL.ETL_BATCH_OBJECT_CONTROL
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
FETCH FIRST 1 ROW ONLY

)
;


LET C1 CURSOR FOR res1;
open C1;
FETCH C1 into  V_WH,V_BATCH_ID ;
close C1;


LET res2 RESULTSET := 

(

WITH PARAMETERS (AOP_LIVE_DATE) AS
(
  
SELECT * 
FROM  
(SELECT PARAMETER_NAME, PARAMETER_VALUE  FROM UTIL.ETL_OBJECT_PARAMETER_VALUE 
WHERE 1 = 1
AND APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
AND ACTIVE_FLG = ''Y''  
  
UNION ALL       

SELECT PARAMETER_NAME, PARAMETER_VALUE  FROM UTIL.ETL_GLOBAL_PARAMETER_VALUE WHERE PAR_GLOBAL_TYPE = ''PARGLOBAL_OPREPORTS'' AND ACTIVE_FLG = ''Y''
AND PARAMETER_NAME NOT IN  (
SELECT PARAMETER_NAME  FROM UTIL.ETL_OBJECT_PARAMETER_VALUE WHERE 1 = 1
AND APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
AND ACTIVE_FLG = ''Y''   ))
 
PIVOT(MAX(PARAMETER_VALUE) FOR PARAMETER_NAME IN (''AOP_LIVE_DATE'')) 

 
)  
SELECT * FROM PARAMETERS 
)  
  
;


LET C2 CURSOR FOR res2;
open C2;
FETCH C2 into  V_AOP_LIVE_DATE; 
close C2;




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:V_WH;
USE SCHEMA BDR_DM;	--OAS ADD


INSERT INTO UTIL.ETL_BATCH_OBJECT_INCR_VALU (APPLICATION, WORKFLOW_NAME, OBJECT_NAME, INCR_COLUMN, INCR_COLUMN_VALUE )
SELECT * FROM (select :APPLICATION AS APPLICATION, :WORKFLOW_NAME AS WORKFLOW_NAME, :OBJECT_NAME AS OBJECT_NAME, ''ETL_LST_BTCH_ID'' AS INCR_COLUMN, -1 AS INCR_COLUMN_VALUE) A
WHERE NOT EXISTS (SELECT 1 FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU B WHERE B.APPLICATION = A.APPLICATION AND B.WORKFLOW_NAME = A.WORKFLOW_NAME AND B.OBJECT_NAME = A.OBJECT_NAME AND B.INCR_COLUMN = A.INCR_COLUMN)
;

V_ETL_LST_BTCH_ID :=(SELECT INCR_COLUMN_VALUE FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID'');


V_UNDWR_ETL_LST_BTCH_ID :=(SELECT INCR_COLUMN_VALUE FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''UNDWR_ETL_LST_BTCH_ID'');





V_ETLLASTDCMPROCESSDATE := (SELECT MAX(LGR_ITM_DT) FROM  BDR_DCM.DCM_COMM_PD);    

V_AOP_LIVE_DATE         := (SELECT TO_DATE(:V_AOP_LIVE_DATE,''YYYYMMDD'')  FROM DUAL);		
 
  
V_STEP_NAME    := ''TRUNCATE - TEMP_BASELINE_REBULD_DISTINDID'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

	EXECUTE IMMEDIATE ''TRUNCATE TABLE BDR_DM.TEMP_BASELINE_REBULD_DISTINDID'';

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

  
V_STEP_NAME    := ''INSERT - TEMP_BASELINE_REBULD_DISTINDID'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

  INSERT														
    /*+ ENABLE_PARALLEL_DML PARALLEL APPEND */
  INTO BDR_DM.TEMP_BASELINE_REBULD_DISTINDID
    (SELECT demo.individual_id
      FROM BDR_DM.WRK_RIA_COMPAS_DEMOGRAPHICDATA demo
	  ---------------------------------OAS DELETE-----------------------------------------
     /*  WHERE demo.ipb_etl_lst_btch_id > v_etllastbatchid  ------ AOP Scope - MB/MC Premium Fact
      OR demo.ip_etl_lst_btch_id     > v_etllastbatchid  ------ AOP Scope - MB/MC Premium Fact
      OR demo.ind_etl_lst_btch_id    > v_etllastbatchid  ------ AOP Scope - MB/MC Premium Fact */
	  ---------------------------------OAS DELETE-----------------------------------------
	  
	  ---------------------------------OAS ADD-----------------------------------------
	  WHERE demo.ipb_etl_lst_btch_id > :V_ETL_LST_BTCH_ID  ------ AOP Scope - MB/MC Premium Fact
      OR demo.ip_etl_lst_btch_id     > :V_ETL_LST_BTCH_ID  ------ AOP Scope - MB/MC Premium Fact
      OR demo.ind_etl_lst_btch_id    > :V_ETL_LST_BTCH_ID  ------ AOP Scope - MB/MC Premium Fact
	  ---------------------------------OAS ADD-----------------------------------------
    --OR demo.bba_etl_lst_btch_id    > v_etllastbatchid  ------ AOP Scope - MB/MC Premium Fact
	UNION

	SELECT demo.individual_id
      FROM BDR_DM.WRK_COMPAS_DEMOGRAPHICDATA demo
	  ---------------------------------OAS DELETE-----------------------------------------
      /* WHERE demo.ipb_etl_lst_btch_id > v_etllastbatchid  ------ AOP Scope - MB/MC Premium Fact
      OR demo.ip_etl_lst_btch_id     > v_etllastbatchid  ------ AOP Scope - MB/MC Premium Fact
      OR demo.ind_etl_lst_btch_id    > v_etllastbatchid  ------ AOP Scope - MB/MC Premium Fact
	  OR demo.bba_etl_lst_btch_id    > v_etllastbatchid  ------ AOP Scope - MB/MC Premium Fact ----- AOP Scope 05/22/2024 */
	  ---------------------------------OAS DELETE-----------------------------------------
	  
	  ---------------------------------OAS ADD-----------------------------------------
	  WHERE demo.ipb_etl_lst_btch_id > :V_ETL_LST_BTCH_ID  ------ AOP Scope - MB/MC Premium Fact
      OR demo.ip_etl_lst_btch_id     > :V_ETL_LST_BTCH_ID  ------ AOP Scope - MB/MC Premium Fact
      OR demo.ind_etl_lst_btch_id    > :V_ETL_LST_BTCH_ID  ------ AOP Scope - MB/MC Premium Fact
	  OR demo.bba_etl_lst_btch_id    > :V_ETL_LST_BTCH_ID  ------ AOP Scope - MB/MC Premium Fact ----- AOP Scope 05/22/2024
	  ---------------------------------OAS ADD-----------------------------------------

       UNION
      SELECT demo.individual_id
      FROM SRC_COMPAS_D.insured_plan ip
      JOIN BDR_DM.WRK_RIA_COMPAS_DEMOGRAPHICDATA demo
      ON ip.insured_plan_id       = demo.insuredplan_id
      JOIN BDR_DM.f_appl_trans_day f
      ON ip.application_id = f.APPL_ID
      WHERE CURR_ROW_FLG = ''Y'' and
      -- f.etl_lst_btch_id > v_etlapplbatchid		------------OAS DELETE
      f.etl_lst_btch_id > :V_ETL_LST_BTCH_ID		------------OAS ADD

	 UNION
      SELECT demo.individual_id
      FROM SRC_COMPAS_D.insured_plan ip
      JOIN BDR_DM.WRK_COMPAS_DEMOGRAPHICDATA demo
      ON ip.insured_plan_id       = demo.insuredplan_id
      JOIN BDR_DM.f_appl_trans_day f
      ON ip.application_id = f.APPL_ID
      WHERE CURR_ROW_FLG = ''Y'' and
      -- f.etl_lst_btch_id > v_etlapplbatchid		------------OAS DELETE
      f.etl_lst_btch_id > :V_ETL_LST_BTCH_ID		------------OAS ADD


	  UNION   --------AOP De-Scope - MB/MC Premium Fact
      SELECT demo.individual_id
      FROM SRC_COMPAS_D.account_receivable ar
      JOIN BDR_DM.WRK_COMPAS_DEMOGRAPHICDATA demo
      ON ar.household_id       = demo.household_id
      --WHERE ar.etl_lst_btch_id > v_etllastbatchid		-------------OAS DELETE
	    WHERE ar.etl_lst_btch_id > :V_ETL_LST_BTCH_ID		-------------OAS ADD
	  AND AR.DUE_DATE < :V_AOP_LIVE_DATE

	  UNION    --------AOP Scope - MB/MC Premium Fact
      SELECT demo.individual_id
      FROM SRC_RIA.AR_FACT AR
      JOIN BDR_DM.WRK_RIA_COMPAS_DEMOGRAPHICDATA demo
      ON AR.individual_id       = demo.individual_id
      --WHERE AR.ETL_LST_BTCH_ID > v_etllastbatchid		---------------OAS DELETE
	  WHERE AR.ETL_LST_BTCH_ID > :V_ETL_LST_BTCH_ID	-------------OAS ADD

	  UNION    --------AOP Scope - MB/MC Premium Fact
      SELECT demo.individual_id
      FROM SRC_RIA.AR_RETRO_FACT AR
      JOIN BDR_DM.WRK_RIA_COMPAS_DEMOGRAPHICDATA demo
      ON AR.household_id       = demo.household_id
      --WHERE AR.ETL_LST_BTCH_ID > v_etllastbatchid		---------------OAS DELETE
	  WHERE AR.ETL_LST_BTCH_ID > :V_ETL_LST_BTCH_ID	-------------OAS ADD

	  UNION
      SELECT demo.individual_id
      FROM SRC_RIA.AR_RETRO_FACT AR
      JOIN BDR_DM.WRK_COMPAS_DEMOGRAPHICDATA demo
      ON AR.household_id       = demo.household_id
      --WHERE AR.ETL_LST_BTCH_ID > v_etllastbatchid		---------------OAS DELETE
	  WHERE AR.ETL_LST_BTCH_ID > :V_ETL_LST_BTCH_ID	-------------OAS ADD

	  UNION
	  SELECT demo.individual_id
	  FROM SRC_RIA.ADT_AR_FACT ADTAR
	  JOIN BDR_DM.WRK_RIA_COMPAS_DEMOGRAPHICDATA demo  ON demo.INDIVIDUAL_ID   = ADTAR.INDIVIDUAL_ID
	  --WHERE ADTAR.adt_row_creat_by_btch_id > v_etllastbatchid		---------------OAS DELETE
	  WHERE ADTAR.adt_row_creat_by_btch_id > :V_ETL_LST_BTCH_ID	-------------OAS ADD
	  AND ADTAR.adt_typ_cd = ''D''

      UNION
	  SELECT demo.individual_id
      FROM SRC_COMPAS_D.household_address ha
      JOIN BDR_DM.WRK_RIA_COMPAS_DEMOGRAPHICDATA demo
      ON ha.household_id       = demo.household_id
      --WHERE ha.etl_lst_btch_id > v_etllastbatchid		---------------OAS DELETE
	  WHERE ha.etl_lst_btch_id > :V_ETL_LST_BTCH_ID	-------------OAS ADD

	   UNION
	  SELECT demo.individual_id
      FROM SRC_COMPAS_D.household_address ha
      JOIN BDR_DM.WRK_COMPAS_DEMOGRAPHICDATA demo
      ON ha.household_id       = demo.household_id
      --WHERE ha.etl_lst_btch_id > v_etllastbatchid		---------------OAS DELETE
	  WHERE ha.etl_lst_btch_id > :V_ETL_LST_BTCH_ID	-------------OAS ADD


      UNION
      SELECT demo.individual_id
      FROM SRC_COMPAS_D.insured_plan_benefit_mod benmod
      JOIN BDR_DM.WRK_RIA_COMPAS_DEMOGRAPHICDATA demo
      ON benmod.insured_plan_id    = demo.insuredplan_id
      --WHERE benmod.etl_lst_btch_id > v_etllastbatchid		---------------OAS DELETE
	  WHERE benmod.etl_lst_btch_id > :V_ETL_LST_BTCH_ID	-------------OAS ADD

	  UNION
      SELECT demo.individual_id
      FROM SRC_COMPAS_D.insured_plan_benefit_mod benmod
      JOIN BDR_DM.WRK_COMPAS_DEMOGRAPHICDATA demo
      ON benmod.insured_plan_id    = demo.insuredplan_id
      --WHERE benmod.etl_lst_btch_id > v_etllastbatchid		---------------OAS DELETE
	  WHERE benmod.etl_lst_btch_id > :V_ETL_LST_BTCH_ID	-------------OAS ADD


      UNION
      SELECT demo.individual_id
      FROM SRC_COMPAS_D.individual_profile iprof
      JOIN BDR_DM.WRK_RIA_COMPAS_DEMOGRAPHICDATA demo
      ON iprof.individual_id      = demo.individual_id
      --WHERE iprof.etl_lst_btch_id > v_etllastbatchid		---------------OAS DELETE
	  WHERE iprof.etl_lst_btch_id > :V_ETL_LST_BTCH_ID	-------------OAS ADD

	  UNION
      SELECT demo.individual_id
      FROM SRC_COMPAS_D.individual_profile iprof
      JOIN BDR_DM.WRK_COMPAS_DEMOGRAPHICDATA demo
      ON iprof.individual_id      = demo.individual_id
      --WHERE iprof.etl_lst_btch_id > v_etllastbatchid		---------------OAS DELETE
	  WHERE iprof.etl_lst_btch_id > :V_ETL_LST_BTCH_ID	-------------OAS ADD

      UNION
      SELECT demo.individual_id
      FROM SRC_COMPAS_D.household_profile hp -- ACCT_NBR
      JOIN BDR_DM.WRK_RIA_COMPAS_DEMOGRAPHICDATA demo
      ON hp.household_id       = demo.household_id
      --WHERE hp.etl_lst_btch_id > v_etllastbatchid		---------------OAS DELETE
	  WHERE hp.etl_lst_btch_id > :V_ETL_LST_BTCH_ID	-------------OAS ADD

	  UNION
      SELECT demo.individual_id
      FROM SRC_COMPAS_D.household_profile hp -- ACCT_NBR
      JOIN BDR_DM.WRK_COMPAS_DEMOGRAPHICDATA demo
      ON hp.household_id       = demo.household_id
      --WHERE hp.etl_lst_btch_id > v_etllastbatchid		---------------OAS DELETE
	  WHERE hp.etl_lst_btch_id > :V_ETL_LST_BTCH_ID	-------------OAS ADD


      UNION
      SELECT demo.individual_id
      FROM SRC_COMPAS_D.household_member hm -- ACCT_NBR
      JOIN BDR_DM.WRK_RIA_COMPAS_DEMOGRAPHICDATA demo
      ON hm.household_id       = demo.household_id
      --WHERE hm.etl_lst_btch_id > v_etllastbatchid		---------------OAS DELETE
	  WHERE hm.etl_lst_btch_id > :V_ETL_LST_BTCH_ID	-------------OAS ADD

	  UNION
      SELECT demo.individual_id
      FROM SRC_COMPAS_D.household_member hm -- ACCT_NBR
      JOIN BDR_DM.WRK_COMPAS_DEMOGRAPHICDATA demo
      ON hm.household_id       = demo.household_id
      --WHERE hm.etl_lst_btch_id > v_etllastbatchid		---------------OAS DELETE
	  WHERE hm.etl_lst_btch_id > :V_ETL_LST_BTCH_ID	-------------OAS ADD


      UNION
      SELECT demo.individual_id
      FROM BDR_UNDWR.f_undwr fuw -- UNDWR Tags 9/9/2015 JS
      JOIN BDR_DM.WRK_RIA_COMPAS_DEMOGRAPHICDATA demo
      ON fuw.insd_pln_id        = demo.insuredplan_id
      --WHERE fuw.etl_lst_btch_id > v_uw_lastetlbatchid		---------------OAS DELETE
	  WHERE fuw.etl_lst_btch_id > :V_UNDWR_ETL_LST_BTCH_ID	-------------OAS ADD

	  UNION
      SELECT demo.individual_id
      FROM BDR_UNDWR.f_undwr fuw -- UNDWR Tags 9/9/2015 JS
      JOIN BDR_DM.WRK_COMPAS_DEMOGRAPHICDATA demo
      ON fuw.insd_pln_id        = demo.insuredplan_id
      --WHERE fuw.etl_lst_btch_id > v_uw_lastetlbatchid		---------------OAS DELETE
	  WHERE fuw.etl_lst_btch_id > :V_UNDWR_ETL_LST_BTCH_ID	-------------OAS ADD


      UNION
      SELECT demo.individual_id
      FROM BDR_UNDWR.f_undwr fuw -- UNDWR Tags 9/9/2015 JS
      JOIN BDR_DM.WRK_RIA_COMPAS_DEMOGRAPHICDATA demo
      ON fuw.indv_id            = demo.individual_id
      --WHERE fuw.etl_lst_btch_id > v_uw_lastetlbatchid		---------------OAS DELETE
	  WHERE fuw.etl_lst_btch_id > :V_UNDWR_ETL_LST_BTCH_ID	-------------OAS ADD

	  UNION
      SELECT demo.individual_id
      FROM BDR_UNDWR.f_undwr fuw -- UNDWR Tags 9/9/2015 JS
      JOIN BDR_DM.WRK_COMPAS_DEMOGRAPHICDATA demo
      ON fuw.indv_id            = demo.individual_id
      --WHERE fuw.etl_lst_btch_id > v_uw_lastetlbatchid		---------------OAS DELETE
	  WHERE fuw.etl_lst_btch_id > :V_UNDWR_ETL_LST_BTCH_ID	-------------OAS ADD

      UNION
      SELECT demo.individual_id -- Added for Legal Entity 04/19/2016
      FROM SRC_COMPAS_D.insured_plan_profile ipp
      JOIN BDR_DM.WRK_RIA_COMPAS_DEMOGRAPHICDATA demo
      ON ipp.insured_plan_id    = demo.insuredplan_id
      --WHERE ipp.etl_lst_btch_id > v_etllastbatchid		---------------OAS DELETE
	  WHERE ipp.etl_lst_btch_id > :V_ETL_LST_BTCH_ID	-------------OAS ADD

	  UNION
      SELECT demo.individual_id -- Added for Legal Entity 04/19/2016
      FROM SRC_COMPAS_D.insured_plan_profile ipp
      JOIN BDR_DM.WRK_COMPAS_DEMOGRAPHICDATA demo
      ON ipp.insured_plan_id    = demo.insuredplan_id
      --WHERE ipp.etl_lst_btch_id > v_etllastbatchid		---------------OAS DELETE
	  WHERE ipp.etl_lst_btch_id > :V_ETL_LST_BTCH_ID	-------------OAS ADD


      UNION
      SELECT demo.individual_id -- Added for Compas D_AGE_LOOK_FRACnt
      FROM SRC_COMPAS_D.insured_plan ip
      JOIN SRC_COMPAS_D.application a
      ON ip.application_id = a.application_id
      JOIN BDR_DM.WRK_RIA_COMPAS_DEMOGRAPHICDATA demo
      ON ip.insured_plan_id   = demo.insuredplan_id
      --WHERE a.etl_lst_btch_id > v_etllastbatchid		---------------OAS DELETE
	  WHERE a.etl_lst_btch_id > :V_ETL_LST_BTCH_ID	-------------OAS ADD

	  UNION
      SELECT demo.individual_id -- Added for Compas D_AGE_LOOK_FRACnt
      FROM SRC_COMPAS_D.insured_plan ip
      JOIN SRC_COMPAS_D.application a
      ON ip.application_id = a.application_id
      JOIN BDR_DM.WRK_COMPAS_DEMOGRAPHICDATA demo
      ON ip.insured_plan_id   = demo.insuredplan_id
      --WHERE a.etl_lst_btch_id > v_etllastbatchid		---------------OAS DELETE
	  WHERE a.etl_lst_btch_id > :V_ETL_LST_BTCH_ID	-------------OAS ADD


      UNION
      SELECT demo.individual_id -- Added for Compas D_AGE_LOOK_FRACnt
      FROM SRC_COMPAS_D.insured_plan ip
      JOIN SRC_COMPAS_D.application a
      ON ip.application_id = a.application_id
      JOIN SRC_COMPAS_D.application_agent ag
      ON a.application_id = ag.application_id
      JOIN BDR_DM.WRK_RIA_COMPAS_DEMOGRAPHICDATA demo
      ON ip.insured_plan_id    = demo.insuredplan_id
      --WHERE ag.etl_lst_btch_id > v_etllastbatchid		---------------OAS DELETE
	  WHERE ag.etl_lst_btch_id > :V_ETL_LST_BTCH_ID	-------------OAS ADD

	  UNION
      SELECT demo.individual_id -- Added for Compas D_AGE_LOOK_FRACnt
      FROM SRC_COMPAS_D.insured_plan ip
      JOIN SRC_COMPAS_D.application a
      ON ip.application_id = a.application_id
      JOIN SRC_COMPAS_D.application_agent ag
      ON a.application_id = ag.application_id
      JOIN BDR_DM.WRK_COMPAS_DEMOGRAPHICDATA demo
      ON ip.insured_plan_id    = demo.insuredplan_id
      --WHERE ag.etl_lst_btch_id > v_etllastbatchid		---------------OAS DELETE
	  WHERE ag.etl_lst_btch_id > :V_ETL_LST_BTCH_ID	-------------OAS ADD


      UNION
      SELECT demo.individual_id
      FROM SRC_COMPAS_D.employer_household eh
      JOIN BDR_DM.WRK_RIA_COMPAS_DEMOGRAPHICDATA demo
      ON eh.household_id       = demo.household_id
      --WHERE eh.etl_lst_btch_id > v_etllastbatchid		---------------OAS DELETE
	  WHERE eh.etl_lst_btch_id > :V_ETL_LST_BTCH_ID	-------------OAS ADD

	  UNION
      SELECT demo.individual_id
      FROM SRC_COMPAS_D.employer_household eh
      JOIN BDR_DM.WRK_COMPAS_DEMOGRAPHICDATA demo
      ON eh.household_id       = demo.household_id
      --WHERE eh.etl_lst_btch_id > v_etllastbatchid		---------------OAS DELETE
	  WHERE eh.etl_lst_btch_id > :V_ETL_LST_BTCH_ID	-------------OAS ADD

      UNION
      SELECT demo.individual_id --- added 1 11 2018
      FROM SRC_COMPAS_D.household_billing_profile hbp
      JOIN BDR_DM.WRK_RIA_COMPAS_DEMOGRAPHICDATA demo
      ON hbp.household_id       = demo.household_id
      --WHERE hbp.etl_lst_btch_id > v_etllastbatchid		---------------OAS DELETE
	  WHERE hbp.etl_lst_btch_id > :V_ETL_LST_BTCH_ID	-------------OAS ADD

	  UNION
      SELECT demo.individual_id --- added 1 11 2018
      FROM SRC_COMPAS_D.household_billing_profile hbp
      JOIN BDR_DM.WRK_COMPAS_DEMOGRAPHICDATA demo
      ON hbp.household_id       = demo.household_id
      --WHERE hbp.etl_lst_btch_id > v_etllastbatchid		---------------OAS DELETE
	  WHERE hbp.etl_lst_btch_id > :V_ETL_LST_BTCH_ID	-------------OAS ADD



      UNION						--------AOP De-Scope - MB/MC Premium Fact -- No Replacement
      SELECT demo.individual_id --- added 1 11 2018
      FROM SRC_COMPAS_D.billing_bucket_adjustment bbad
      JOIN BDR_DM.WRK_COMPAS_DEMOGRAPHICDATA demo
      ON bbad.household_id       = demo.household_id
      --WHERE bbad.etl_lst_btch_id > v_etllastbatchid		---------------OAS DELETE
	  WHERE bbad.etl_lst_btch_id > :V_ETL_LST_BTCH_ID	-------------OAS ADD


	  UNION  						--------AOP De-Scope - MB/MC Premium Fact  -- No Replacement
      SELECT demo.individual_id --- added 1 11 2018
      FROM SRC_COMPAS_D.adjustment adj
      JOIN SRC_COMPAS_D.billing_bucket_adjustment bbadj
      ON adj.adjustment_id = bbadj.adjustment_id
      JOIN BDR_DM.WRK_COMPAS_DEMOGRAPHICDATA demo
      ON bbadj.household_id     = demo.household_id
      --WHERE adj.etl_lst_btch_id > v_etllastbatchid		---------------OAS DELETE
	  WHERE adj.etl_lst_btch_id > :V_ETL_LST_BTCH_ID	-------------OAS ADD

/*	  UNION			-------AOP Scope - MB/MC Premium Fact
	  SELECT demo.individual_id
	  FROM DM.WRK_RIA_COMPAS_DEMOGRAPHICDATA demo
	  WHERE demo.APD_BCHG_BID > v_etllastbatchid OR
	        demo.EFT_BCHG_BID > v_etllastbatchid OR
			demo.LOG_BCHG_BID > v_etllastbatchid OR
			demo.LOY_BCHG_BID > v_etllastbatchid OR
			demo.MULINS_BCHG_BID > v_etllastbatchid OR
			demo.TIER_BCHG_BID   > v_etllastbatchid OR
			demo.CUSTMEM_BID     > v_etllastbatchid OR
			demo.MEM_CUST_BID    > v_etllastbatchid OR
			demo.MEM_PRICE_ITEM_BID > v_etllastbatchid OR
			demo.D_NEW_TO_MEDCR_BID > v_etllastbatchid
*/
/*    UNION						--------AOP De-Scope - MB/MC Premium Fact
      SELECT demo.individual_id --- added 1 11 2018
      FROM COMPAS.calculated_rate cal
      JOIN COMPAS.ins_plan_billing_bucket ipbbt
      ON cal.calculated_rate_id = ipbbt.calculated_rate_id
      JOIN DM.WRK_COMPAS_DEMOGRAPHICDATA demo
      ON ipbbt.household_id     = demo.household_id
      WHERE cal.etl_lst_btch_id > v_etllastbatchid */

	  UNION
      SELECT demo.individual_id --- added 1 11 2018
      FROM SRC_RIA.PRICE_RULE_DIM PRD
      JOIN BDR_CONF.D_CALC_RT CR                       ON PRD.PRICING_RULE_ID = CR.SRC_CALC_RT_ID AND SRC_DEL_FLG=''N''
      JOIN BDR_DM.WRK_RIA_COMPAS_DEMOGRAPHICDATA demo  ON demo.D_CALC_RT_SK   = CR.D_CALC_RT_SK
      --WHERE PRD.etl_lst_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE PRD.etl_lst_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD


      UNION
      SELECT demo.individual_id
      FROM BDR_DM.WRK_RIA_COMPAS_DEMOGRAPHICDATA demo
      JOIN SRC_COMPAS_D.policy p
      ON demo.individual_id = p.individual_id
      INNER JOIN
        ( SELECT DISTINCT mbr_pol_id
        FROM BDR_DCM.dcm_comm_pd
        WHERE m_r_prdct_catgy IN (
                        ''AARP MS'',
                        ''MS''
                    )
        AND lgr_itm_dt        > :V_ETLLASTDCMPROCESSDATE--()@ETLLastDCMPROCESS_DATE
        ) dcm
      ON p.policy_number = dcm.mbr_pol_id


	  UNION
      SELECT demo.individual_id
      FROM BDR_DM.WRK_COMPAS_DEMOGRAPHICDATA demo
      JOIN SRC_COMPAS_D.policy p
      ON demo.individual_id = p.individual_id
      INNER JOIN
        ( SELECT DISTINCT mbr_pol_id
        FROM BDR_DCM.dcm_comm_pd
        WHERE m_r_prdct_catgy IN (
                        ''AARP MS'',
                        ''MS''
                    )
        AND lgr_itm_dt        > :V_ETLLASTDCMPROCESSDATE--()@ETLLastDCMPROCESS_DATE
        ) dcm
      ON p.policy_number = dcm.mbr_pol_id


      UNION  -----------AOP De-Scope - MB/MC Premium Fact
      SELECT demo.individual_id
      FROM SRC_COMPAS_D.adt_account_receivable adtar  ------ AOP Scope - MB/MC Premium Fact -- No Delete concept for AR in ISB and hence Replacement
      JOIN BDR_DM.WRK_COMPAS_DEMOGRAPHICDATA demo
      ON adtar.household_id          = demo.household_id
      --WHERE adt_row_creat_by_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE adt_row_creat_by_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD
      AND adt_typ_cd                 = ''D''
      AND acct_receivable_type_id    = 2
      AND responsible_party_type_id IN ( 1,2 )
	  AND adtar.DUE_DATE < :V_AOP_LIVE_DATE

      UNION
      SELECT demo.individual_id
      FROM SRC_COMPAS_D.adt_insured_plan_benefit_mod adtbenmod
      JOIN BDR_DM.WRK_RIA_COMPAS_DEMOGRAPHICDATA demo
      ON adtbenmod.insured_plan_id   = demo.insuredplan_id
      --WHERE adt_row_creat_by_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE adt_row_creat_by_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD
      AND benefit_mod_type_id       <= 6
      AND adt_typ_cd                 = ''D''

	  UNION
      SELECT demo.individual_id
      FROM SRC_COMPAS_D.adt_insured_plan_benefit_mod adtbenmod
      JOIN BDR_DM.WRK_COMPAS_DEMOGRAPHICDATA demo
      ON adtbenmod.insured_plan_id   = demo.insuredplan_id
      --WHERE adt_row_creat_by_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE adt_row_creat_by_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD
      AND benefit_mod_type_id       <= 6
      AND adt_typ_cd                 = ''D''

      UNION
      SELECT demo.individual_id
      FROM SRC_COMPAS_D.adt_individual_profile adtipprof
      JOIN BDR_DM.WRK_RIA_COMPAS_DEMOGRAPHICDATA demo
      ON adtipprof.individual_id     = demo.individual_id
      --WHERE adt_row_creat_by_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE adt_row_creat_by_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD
      AND adt_typ_cd  = ''D''

      UNION
      SELECT demo.individual_id
      FROM SRC_COMPAS_D.adt_individual_profile adtipprof
      JOIN BDR_DM.WRK_COMPAS_DEMOGRAPHICDATA demo
      ON adtipprof.individual_id     = demo.individual_id
      --WHERE adt_row_creat_by_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE adt_row_creat_by_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD
      AND adt_typ_cd  = ''D''


      UNION  --------AOP De-Scope - MB/MC Premium Fact
      SELECT demo.individual_id
      FROM SRC_COMPAS_D.adt_billing_bucket_adjustment adtbba--billingbucket
      JOIN BDR_DM.WRK_COMPAS_DEMOGRAPHICDATA demo
      ON adtbba.ins_plan_billing_bucket_id = demo.insplan_billingbucket_id
      --WHERE adt_row_creat_by_btch_id       > v_etllastbatchid             ---------------OAS DELETE
	  WHERE adt_row_creat_by_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD
      AND adt_typ_cd                       = ''D''

      UNION		--------AOP Scope - MB/MC Premium Fact
	  SELECT demo.INDIVIDUAL_ID
	  FROM SRC_RIA.ADT_CM_RATE_ADJ_DTL_VW ADTADJ
	  JOIN SRC_RIA.ADT_PRICE_RULE_DIM ADTPRD ON ADTPRD.PRICING_RULE_ID=ADTADJ.PRICING_RULE_ID AND ADTPRD.ADT_TYP_CD=''D''
	  JOIN BDR_CONF.D_CALC_RT CR                       ON ADTPRD.PRICING_RULE_ID = CR.SRC_CALC_RT_ID AND CR.SRC_DEL_FLG=''Y''
      JOIN BDR_DM.WRK_RIA_COMPAS_DEMOGRAPHICDATA demo  ON demo.D_CALC_RT_SK   = CR.D_CALC_RT_SK
      --WHERE ADTADJ.adt_row_creat_by_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE ADTADJ.adt_row_creat_by_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD
	  AND ADTADJ.adt_typ_cd = ''D''

      UNION --- -- Adding Cert Channel 8/4/2015
      SELECT demo.individual_id
      FROM BDR_DM.WRK_RIA_COMPAS_DEMOGRAPHICDATA demo
      INNER JOIN BDR_DM.wrk_ipacqchannel_chg ipac
      ON demo.insuredplan_id = ipac.insuredplanid

	  UNION --- -- Adding Cert Channel 8/4/2015
      SELECT demo.individual_id
      FROM BDR_DM.WRK_COMPAS_DEMOGRAPHICDATA demo
      INNER JOIN BDR_DM.wrk_ipacqchannel_chg ipac
      ON demo.insuredplan_id = ipac.insuredplanid


      UNION
      SELECT demo.individual_id
      FROM SRC_COMPAS_D.adt_household_profile adthp -- added for ACCT_NBR
      JOIN BDR_DM.WRK_RIA_COMPAS_DEMOGRAPHICDATA demo
      ON adthp.household_id          = demo.household_id
      --WHERE adt_row_creat_by_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE adt_row_creat_by_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD
      AND adt_typ_cd                 = ''D''

      UNION
      SELECT demo.individual_id
      FROM SRC_COMPAS_D.adt_household_profile adthp -- added for ACCT_NBR
      JOIN BDR_DM.WRK_COMPAS_DEMOGRAPHICDATA demo
      ON adthp.household_id          = demo.household_id
      --WHERE adt_row_creat_by_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE adt_row_creat_by_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD
      AND adt_typ_cd                 = ''D''


      UNION
      SELECT demo.individual_id
      FROM SRC_COMPAS_D.adt_household_member adthm -- added for ACCT_NBR
      JOIN BDR_DM.WRK_RIA_COMPAS_DEMOGRAPHICDATA demo
      ON adthm.household_id          = demo.household_id
      --WHERE adt_row_creat_by_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE adt_row_creat_by_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD
      AND adt_typ_cd                 = ''D''

	  UNION
      SELECT demo.individual_id
      FROM SRC_COMPAS_D.adt_household_member adthm -- added for ACCT_NBR
      JOIN BDR_DM.WRK_COMPAS_DEMOGRAPHICDATA demo
      ON adthm.household_id          = demo.household_id
      --WHERE adt_row_creat_by_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE adt_row_creat_by_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD
      AND adt_typ_cd                 = ''D''


      UNION
      SELECT demo.individual_id ----  Added for Legal Entity 04/19/2016
      FROM SRC_COMPAS_D.adt_insured_plan_profile adtipp
      JOIN BDR_DM.WRK_RIA_COMPAS_DEMOGRAPHICDATA demo
      ON adtipp.insured_plan_id      = demo.insuredplan_id
      --WHERE adt_row_creat_by_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE adt_row_creat_by_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD
      AND adt_typ_cd                 = ''D''

	  UNION
      SELECT demo.individual_id ----  Added for Legal Entity 04/19/2016
      FROM SRC_COMPAS_D.adt_insured_plan_profile adtipp
      JOIN BDR_DM.WRK_COMPAS_DEMOGRAPHICDATA demo
      ON adtipp.insured_plan_id      = demo.insuredplan_id
      --WHERE adt_row_creat_by_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE adt_row_creat_by_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD
      AND adt_typ_cd                 = ''D''



      UNION
      SELECT demo.individual_id --- added 1 11 2018
      FROM SRC_COMPAS_D.adt_household_billing_profile adthbp
      JOIN BDR_DM.WRK_RIA_COMPAS_DEMOGRAPHICDATA demo
      ON adthbp.household_id         = demo.household_id
      --WHERE adt_row_creat_by_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE adt_row_creat_by_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD
      AND adt_typ_cd                 = ''D''

	  UNION
      SELECT demo.individual_id --- added 1 11 2018
      FROM SRC_COMPAS_D.adt_household_billing_profile adthbp
      JOIN BDR_DM.WRK_COMPAS_DEMOGRAPHICDATA demo
      ON adthbp.household_id         = demo.household_id
      --WHERE adt_row_creat_by_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE adt_row_creat_by_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD
      AND adt_typ_cd                 = ''D''

      UNION  --------AOP De-Scope - MB/MC Premium Fact	  -- No Replacement
      SELECT demo.individual_id --- added 1 11 2018
      FROM SRC_COMPAS_D.adt_billing_bucket_adjustment adtbbad
      JOIN BDR_DM.WRK_COMPAS_DEMOGRAPHICDATA demo
      ON adtbbad.household_id        = demo.household_id
      --WHERE adt_row_creat_by_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE adt_row_creat_by_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD
      AND adt_typ_cd                 = ''D''


      UNION  ----------AOP De-Scope - MB/MC Premium Fact	 -- No Replacement
      SELECT demo.individual_id --- added 1 11 2018
      FROM SRC_COMPAS_D.adt_adjustment adtadj
      JOIN SRC_COMPAS_D.adt_billing_bucket_adjustment adtbbadj
      ON adtadj.adjustment_id = adtbbadj.adjustment_id
      JOIN BDR_DM.WRK_COMPAS_DEMOGRAPHICDATA demo
      ON adtbbadj.household_id              = demo.household_id
      --WHERE adtadj.adt_row_creat_by_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE adtadj.adt_row_creat_by_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD
      AND adtadj.adt_typ_cd                 = ''D''


/*    UNION     ----------AOP De-Scope - MB/MC Premium Fact
      SELECT demo.individual_id --- added 1 11 2018
      FROM ADT_COMPAS.adt_calculated_rate adtcal
      JOIN ADT_COMPAS.adt_ins_plan_billing_bucket adtipbbt
      ON adtcal.calculated_rate_id = adtipbbt.calculated_rate_id
      JOIN DM.WRK_COMPAS_DEMOGRAPHICDATA demo
      ON adtipbbt.household_id              = demo.household_id
      WHERE adtcal.adt_row_creat_by_btch_id > v_etllastbatchid
      AND adtcal.adt_typ_cd                 = ''D'' */

      UNION     ----------AOP Scope - MB/MC Premium Fact
      SELECT demo.individual_id --- added 1 11 2018
      FROM SRC_RIA.ADT_PRICE_RULE_DIM ADTPRD
      JOIN BDR_CONF.D_CALC_RT CR                       ON ADTPRD.PRICING_RULE_ID = CR.SRC_CALC_RT_ID AND CR.SRC_DEL_FLG=''Y''
      JOIN BDR_DM.WRK_RIA_COMPAS_DEMOGRAPHICDATA demo  ON demo.D_CALC_RT_SK   = CR.D_CALC_RT_SK
	  --WHERE ADTPRD.adt_row_creat_by_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE ADTPRD.adt_row_creat_by_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD
      AND ADTPRD.adt_typ_cd = ''D''

	  UNION
	  SELECT demo.individual_id   ----- AOP Scope 05/22/2024
      FROM BDR_CONF.D_CALC_RT CR
      JOIN SRC_RIA.ADT_PREM_BUCKET_FACT ADTPBF   ON ADTPBF.PREM_PRC_RULE_ID = CR.SRC_CALC_RT_ID AND CR.SRC_DEL_FLG=''Y''
      JOIN BDR_DM.WRK_RIA_COMPAS_DEMOGRAPHICDATA demo  ON demo.INDIVIDUAL_ID   = ADTPBF.INDIVIDUAL_ID
      --WHERE CR.etl_lst_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE CR.etl_lst_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD

	  UNION
	  SELECT demo.individual_id  ----- AOP Scope 05/22/2024
	  FROM SRC_RIA.ADT_PREM_BUCKET_FACT ADTPBF
	  JOIN BDR_DM.WRK_RIA_COMPAS_DEMOGRAPHICDATA demo  ON demo.INDIVIDUAL_ID   = ADTPBF.INDIVIDUAL_ID
	  --WHERE ADTPBF.adt_row_creat_by_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE ADTPBF.adt_row_creat_by_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD
	  AND ADTPBF.adt_typ_cd = ''D''

      UNION
      SELECT demo.individual_id ----  Added for D_AGE_LOOK_FRACnt
      FROM SRC_COMPAS_D.insured_plan ip
      JOIN SRC_COMPAS_D.adt_application adta
      ON ip.application_id = adta.application_id
      JOIN BDR_DM.WRK_RIA_COMPAS_DEMOGRAPHICDATA demo
      ON ip.insured_plan_id          = demo.insuredplan_id
      --WHERE adt_row_creat_by_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE adt_row_creat_by_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD
      AND adt_typ_cd                 = ''D''

	  UNION
      SELECT demo.individual_id ----  Added for D_AGE_LOOK_FRACnt
      FROM SRC_COMPAS_D.insured_plan ip
      JOIN SRC_COMPAS_D.adt_application adta
      ON ip.application_id = adta.application_id
      JOIN BDR_DM.WRK_COMPAS_DEMOGRAPHICDATA demo
      ON ip.insured_plan_id          = demo.insuredplan_id
      --WHERE adt_row_creat_by_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE adt_row_creat_by_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD
      AND adt_typ_cd                 = ''D''


      UNION
      SELECT demo.individual_id ----  Added for D_AGE_LOOK_FRACnt
      FROM SRC_COMPAS_D.insured_plan ip
      JOIN SRC_COMPAS_D.application a
      ON ip.application_id = a.application_id
      JOIN SRC_COMPAS_D.adt_application_agent adtag
      ON a.application_id = adtag.application_id
      JOIN BDR_DM.WRK_RIA_COMPAS_DEMOGRAPHICDATA demo
      ON ip.insured_plan_id          = demo.insuredplan_id
      --WHERE adt_row_creat_by_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE adt_row_creat_by_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD
      AND adt_typ_cd                 = ''D''

	  UNION
      SELECT demo.individual_id ----  Added for D_AGE_LOOK_FRACnt
      FROM SRC_COMPAS_D.insured_plan ip
      JOIN SRC_COMPAS_D.application a
      ON ip.application_id = a.application_id
      JOIN SRC_COMPAS_D.adt_application_agent adtag
      ON a.application_id = adtag.application_id
      JOIN BDR_DM.WRK_COMPAS_DEMOGRAPHICDATA demo
      ON ip.insured_plan_id          = demo.insuredplan_id
      --WHERE adt_row_creat_by_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE adt_row_creat_by_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD
      AND adt_typ_cd                 = ''D''

      UNION
      SELECT tna.individual_id
      FROM SRC_COMPAS_D.insured_plan ip
      INNER JOIN BDR_DM.WRK_RIA_PREMIUM_DATABASELINE_TNA tna
      ON ip.insured_plan_id    = tna.insuredplan_id
      --WHERE ip.etl_lst_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE ip.etl_lst_btch_id  > :V_ETL_LST_BTCH_ID            -------------------OAS ADD

	  UNION
      SELECT tna.individual_id
      FROM SRC_COMPAS_D.insured_plan ip
      INNER JOIN BDR_DM.WRK_PREMIUM_DATABASELINE_TNA tna
      ON ip.insured_plan_id    = tna.insuredplan_id
      --WHERE ip.etl_lst_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE ip.etl_lst_btch_id  > :V_ETL_LST_BTCH_ID            -------------------OAS ADD


        UNION
      SELECT tna.individual_id
      FROM SRC_COMPAS_D.insured_plan ip
      JOIN BDR_DM.WRK_RIA_PREMIUM_DATABASELINE_TNA tna
      ON ip.insured_plan_id       = tna.insuredplan_id
      JOIN BDR_DM.f_appl_trans_day f
      ON ip.application_id = f.APPL_ID
      WHERE CURR_ROW_FLG = ''Y'' and
      -- f.etl_lst_btch_id > v_etlapplbatchid       ---------------OAS DELETE
	  f.etl_lst_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD

        UNION
      SELECT tna.individual_id
      FROM SRC_COMPAS_D.insured_plan ip
      JOIN BDR_DM.WRK_PREMIUM_DATABASELINE_TNA tna
      ON ip.insured_plan_id       = tna.insuredplan_id
      JOIN BDR_DM.f_appl_trans_day f
      ON ip.application_id = f.APPL_ID
      WHERE CURR_ROW_FLG = ''Y'' and
      --f.etl_lst_btch_id > v_etlapplbatchid       ---------------OAS DELETE
	  f.etl_lst_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD

       UNION
      SELECT tna.individual_id
      FROM SRC_COMPAS_D.individual ind
      INNER JOIN BDR_DM.WRK_RIA_PREMIUM_DATABASELINE_TNA tna
      ON ind.individual_id      = tna.individual_id
      --WHERE ind.etl_lst_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE ind.etl_lst_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD

	  UNION
      SELECT tna.individual_id
      FROM SRC_COMPAS_D.individual ind
      INNER JOIN BDR_DM.WRK_PREMIUM_DATABASELINE_TNA tna
      ON ind.individual_id      = tna.individual_id
      --WHERE ind.etl_lst_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE ind.etl_lst_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD



      UNION  ----------AOP De-Scope - MB/MC Premium Fact
      SELECT tna.individual_id
      FROM SRC_COMPAS_D.account_receivable ar
	  INNER JOIN BDR_DM.WRK_PREMIUM_DATABASELINE_TNA tna
      ON ar.household_id       = tna.household_id
	  --WHERE ar.etl_lst_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE ar.etl_lst_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD
	  AND AR.DUE_DATE < :V_AOP_LIVE_DATE


	  UNION  ----------AOP Scope - MB/MC Premium Fact
      SELECT tna.individual_id
      FROM SRC_RIA.AR_FACT AR
	  INNER JOIN BDR_DM.WRK_RIA_PREMIUM_DATABASELINE_TNA tna
      ON AR.individual_id       = tna.individual_id
	  --WHERE AR.ETL_LST_BTCH_ID > v_etllastbatchid             ---------------OAS DELETE
	  WHERE AR.ETL_LST_BTCH_ID > :V_ETL_LST_BTCH_ID            -------------------OAS ADD


	  UNION  ----------AOP Scope - MB/MC Premium Fact
      SELECT tna.individual_id
      FROM SRC_RIA.AR_RETRO_FACT AR
	  INNER JOIN BDR_DM.WRK_RIA_PREMIUM_DATABASELINE_TNA tna
      ON AR.individual_id       = tna.individual_id
	  --WHERE AR.ETL_LST_BTCH_ID > v_etllastbatchid             ---------------OAS DELETE
	  WHERE AR.ETL_LST_BTCH_ID > :V_ETL_LST_BTCH_ID            -------------------OAS ADD


	  UNION  ----------AOP Scope - MB/MC Premium Fact
	  SELECT tna.individual_id
	  FROM SRC_RIA.ADT_AR_FACT ADTAR
	  JOIN BDR_DM.WRK_RIA_PREMIUM_DATABASELINE_TNA tna  ON tna.INDIVIDUAL_ID   = ADTAR.INDIVIDUAL_ID
	  --WHERE ADTAR.adt_row_creat_by_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE ADTAR.adt_row_creat_by_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD
	  AND ADTAR.adt_typ_cd = ''D''

      UNION
      SELECT tna.individual_id
      FROM SRC_COMPAS_D.household_address ha
      INNER JOIN BDR_DM.WRK_RIA_PREMIUM_DATABASELINE_TNA tna
      ON ha.household_id       = tna.household_id
      --WHERE ha.etl_lst_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE ha.etl_lst_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD

	  UNION
      SELECT tna.individual_id
      FROM SRC_COMPAS_D.household_address ha
      INNER JOIN BDR_DM.WRK_PREMIUM_DATABASELINE_TNA tna
      ON ha.household_id       = tna.household_id
      --WHERE ha.etl_lst_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE ha.etl_lst_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD


      UNION
      SELECT tna.individual_id
      FROM SRC_COMPAS_D.insured_plan_benefit_mod benmod
      INNER JOIN BDR_DM.WRK_RIA_PREMIUM_DATABASELINE_TNA tna
      ON benmod.insured_plan_id    = tna.insuredplan_id
      --WHERE benmod.etl_lst_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE benmod.etl_lst_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD

	  UNION
      SELECT tna.individual_id
      FROM SRC_COMPAS_D.insured_plan_benefit_mod benmod
      INNER JOIN BDR_DM.WRK_PREMIUM_DATABASELINE_TNA tna
      ON benmod.insured_plan_id    = tna.insuredplan_id
      --WHERE benmod.etl_lst_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE benmod.etl_lst_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD


      UNION
      SELECT tna.individual_id --- added 1 11 2018
      FROM SRC_COMPAS_D.household_billing_profile hbp
      JOIN BDR_DM.WRK_RIA_PREMIUM_DATABASELINE_TNA tna
      ON hbp.household_id       = tna.household_id
      --WHERE hbp.etl_lst_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE hbp.etl_lst_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD

	  UNION
      SELECT tna.individual_id --- added 1 11 2018
      FROM SRC_COMPAS_D.household_billing_profile hbp
      JOIN BDR_DM.WRK_PREMIUM_DATABASELINE_TNA tna
      ON hbp.household_id       = tna.household_id
      --WHERE hbp.etl_lst_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE hbp.etl_lst_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD


	  UNION			 --------AOP De-Scope - MB/MC Premium Fact
      SELECT tna.individual_id --- added 1 11 2018
      FROM SRC_COMPAS_D.billing_bucket_adjustment bbad
      JOIN BDR_DM.WRK_PREMIUM_DATABASELINE_TNA tna
      ON bbad.household_id       = tna.household_id
      --WHERE bbad.etl_lst_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE bbad.etl_lst_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD

      UNION		--------AOP Scope - MB/MC Premium Fact
	  SELECT tna.INDIVIDUAL_ID
	  FROM SRC_RIA.CM_RATE_ADJ_DTL_VW ADJ
	  JOIN SRC_RIA.PRICE_RULE_DIM PRD ON PRD.PRICING_RULE_ID=ADJ.PRICING_RULE_ID
      JOIN SRC_RIA.BCHG_FACT BF ON BF.PRICING_RULE_ID=PRD.PRICING_RULE_ID
      JOIN SRC_RIA.CONTRACT_DIM CD ON CD.SRC_SA_ID=BF.SRC_SA_ID
      JOIN SRC_RIA.CUSTOMER_DIM CUSTD ON CUSTD.SRC_CUST_ID=CD.CUST_ID  AND CUSTD.ID_TYPE_CD = ''INDID''
      JOIN BDR_DM.WRK_RIA_PREMIUM_DATABASELINE_TNA tna ON TO_CHAR(CUSTD.ID_VAL)=TO_CHAR(tna.INDIVIDUAL_ID)
      --WHERE BF.etl_lst_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE BF.etl_lst_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD


      UNION               --------AOP De-Scope - MB/MC Premium Fact   -- No Replacement
      SELECT tna.individual_id --- added 1 11 2018
      FROM SRC_COMPAS_D.adjustment adj
      JOIN SRC_COMPAS_D.billing_bucket_adjustment bbadj
      ON adj.adjustment_id = bbadj.adjustment_id
      JOIN BDR_DM.WRK_PREMIUM_DATABASELINE_TNA tna
      ON bbadj.household_id     = tna.household_id
      --WHERE adj.etl_lst_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE adj.etl_lst_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD


/*    UNION          --------AOP De-Scope - MB/MC Premium Fact
      SELECT tna.individual_id --- added 1 11 2018
      FROM COMPAS.calculated_rate cal
      JOIN COMPAS.ins_plan_billing_bucket ipbbt
      ON cal.calculated_rate_id = ipbbt.calculated_rate_id
      JOIN DM.WRK_PREMIUM_DATABASELINE_TNA tna
      ON ipbbt.household_id     = tna.household_id
      WHERE cal.etl_lst_btch_id > v_etllastbatchid */

      UNION          --------AOP Scope - MB/MC Premium Fact
      SELECT tna.individual_id --- added 1 11 2018
      FROM SRC_RIA.PRICE_RULE_DIM PRD
      JOIN SRC_RIA.BCHG_FACT BF          ON PRD.PRICING_RULE_ID=BF.PRICING_RULE_ID
	  INNER JOIN SRC_RIA.CONTRACT_DIM CD ON CD.SRC_SA_ID = BF.SRC_SA_ID
      INNER JOIN SRC_RIA.CUSTOMER_DIM CUSTD ON CUSTD.SRC_CUST_ID = CD.CUST_ID  AND CUSTD.ID_TYPE_CD = ''INDID''
	  JOIN BDR_DM.WRK_RIA_PREMIUM_DATABASELINE_TNA tna   ON TO_CHAR(CUSTD.ID_VAL)     = TO_CHAR(tna.INDIVIDUAL_ID)
      --WHERE PRD.etl_lst_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE PRD.etl_lst_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD


      UNION
      SELECT tna.individual_id
      FROM SRC_COMPAS_D.individual_profile iprof
      INNER JOIN BDR_DM.WRK_RIA_PREMIUM_DATABASELINE_TNA tna
      ON iprof.individual_id      = tna.individual_id
      --WHERE iprof.etl_lst_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE iprof.etl_lst_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD

	   UNION
      SELECT tna.individual_id
      FROM SRC_COMPAS_D.individual_profile iprof
      INNER JOIN BDR_DM.WRK_PREMIUM_DATABASELINE_TNA tna
      ON iprof.individual_id      = tna.individual_id
      --WHERE iprof.etl_lst_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE iprof.etl_lst_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD


      UNION
      SELECT tna.individual_id
      FROM SRC_COMPAS_D.employer_household eh
      JOIN BDR_DM.WRK_RIA_PREMIUM_DATABASELINE_TNA tna
      ON eh.household_id       = tna.household_id
      --WHERE eh.etl_lst_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE eh.etl_lst_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD

      UNION
      SELECT tna.individual_id
      FROM SRC_COMPAS_D.employer_household eh
      JOIN BDR_DM.WRK_PREMIUM_DATABASELINE_TNA tna
      ON eh.household_id       = tna.household_id
      --WHERE eh.etl_lst_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE eh.etl_lst_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD


      UNION
      SELECT tna.individual_id
      FROM BDR_DM.WRK_RIA_PREMIUM_DATABASELINE_TNA tna
      JOIN SRC_COMPAS_D.policy p
      ON tna.individual_id = p.individual_id
      INNER JOIN
        ( SELECT DISTINCT mbr_pol_id
        FROM BDR_DCM.dcm_comm_pd
        WHERE     m_r_prdct_catgy IN (
                        ''AARP MS'',
                        ''MS''
                    )
        AND lgr_itm_dt        > :v_etllastdcmprocessdate--()@ETLLastDCMPROCESS_DATE
        ) dcm
      ON p.policy_number = dcm.mbr_pol_id

	  UNION
      SELECT tna.individual_id
      FROM BDR_DM.WRK_PREMIUM_DATABASELINE_TNA tna
      JOIN SRC_COMPAS_D.policy p
      ON tna.individual_id = p.individual_id
      INNER JOIN
        ( SELECT DISTINCT mbr_pol_id
        FROM BDR_DCM.dcm_comm_pd
        WHERE     m_r_prdct_catgy IN (
                        ''AARP MS'',
                        ''MS''
                    )
        AND lgr_itm_dt        > :v_etllastdcmprocessdate--()@ETLLastDCMPROCESS_DATE
        ) dcm
      ON p.policy_number = dcm.mbr_pol_id

      UNION
      SELECT tna.individual_id
      FROM SRC_COMPAS_D.adt_account_receivable adtar  ------ AOP Scope - MB/MC Premium Fact -- No Delete concept for AR in ISB and hence Replacement
      INNER JOIN BDR_DM.WRK_PREMIUM_DATABASELINE_TNA tna
      ON adtar.household_id          = tna.household_id
      --WHERE adt_row_creat_by_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE adt_row_creat_by_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD
      AND adt_typ_cd                 = ''D''
      AND acct_receivable_type_id    = 2
      AND responsible_party_type_id IN ( 1,2 )
	  AND adtar.DUE_DATE < :V_AOP_LIVE_DATE

      UNION
      SELECT tna.individual_id
      FROM SRC_COMPAS_D.adt_insured_plan_benefit_mod adtbenmod
      INNER JOIN BDR_DM.WRK_RIA_PREMIUM_DATABASELINE_TNA tna
      ON adtbenmod.insured_plan_id   = tna.insuredplan_id
      --WHERE adt_row_creat_by_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE adt_row_creat_by_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD
      AND benefit_mod_type_id       <= 6
      AND adt_typ_cd                 = ''D''

      UNION
      SELECT tna.individual_id
      FROM SRC_COMPAS_D.adt_insured_plan_benefit_mod adtbenmod
      INNER JOIN BDR_DM.WRK_PREMIUM_DATABASELINE_TNA tna
      ON adtbenmod.insured_plan_id   = tna.insuredplan_id
      --WHERE adt_row_creat_by_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE adt_row_creat_by_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD
      AND benefit_mod_type_id       <= 6
      AND adt_typ_cd                 = ''D''


      UNION
      SELECT tna.individual_id
      FROM SRC_COMPAS_D.adt_individual_profile adtipprof
      INNER JOIN BDR_DM.WRK_RIA_PREMIUM_DATABASELINE_TNA tna
      ON adtipprof.individual_id     = tna.individual_id
      --WHERE adt_row_creat_by_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE adt_row_creat_by_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD
      AND adt_typ_cd                 = ''D''

      UNION
      SELECT tna.individual_id
      FROM SRC_COMPAS_D.adt_individual_profile adtipprof
      INNER JOIN BDR_DM.WRK_PREMIUM_DATABASELINE_TNA tna
      ON adtipprof.individual_id     = tna.individual_id
      --WHERE adt_row_creat_by_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE adt_row_creat_by_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD
      AND adt_typ_cd                 = ''D''


      UNION
      SELECT tna.individual_id
      FROM SRC_COMPAS_D.household_profile hp -- ACCT_NBR
      JOIN BDR_DM.WRK_RIA_PREMIUM_DATABASELINE_TNA tna
      ON hp.household_id       = tna.household_id
      --WHERE hp.etl_lst_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE hp.etl_lst_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD

      UNION
      SELECT tna.individual_id
      FROM SRC_COMPAS_D.household_profile hp -- ACCT_NBR
      JOIN BDR_DM.WRK_PREMIUM_DATABASELINE_TNA tna
      ON hp.household_id       = tna.household_id
      --WHERE hp.etl_lst_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE hp.etl_lst_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD


      UNION
      SELECT tna.individual_id
      FROM SRC_COMPAS_D.household_member hm -- ACCT_NBR
      JOIN BDR_DM.WRK_RIA_PREMIUM_DATABASELINE_TNA tna
      ON hm.household_id       = tna.household_id
      --WHERE hm.etl_lst_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE hm.etl_lst_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD

      UNION
      SELECT tna.individual_id
      FROM SRC_COMPAS_D.household_member hm -- ACCT_NBR
      JOIN BDR_DM.WRK_PREMIUM_DATABASELINE_TNA tna
      ON hm.household_id       = tna.household_id
      --WHERE hm.etl_lst_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE hm.etl_lst_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD


      UNION
      SELECT tna.individual_id
      FROM BDR_UNDWR.f_undwr fuw -- UNDWR Tags 9/9/2015 JS
      JOIN BDR_DM.WRK_RIA_PREMIUM_DATABASELINE_TNA tna
      ON fuw.indv_id            = tna.individual_id
      --WHERE fuw.etl_lst_btch_id > v_uw_lastetlbatchid        ---------------OAS DELETE
	  WHERE fuw.etl_lst_btch_id > :V_UNDWR_ETL_LST_BTCH_ID            -------------------OAS ADD

      UNION
      SELECT tna.individual_id
      FROM BDR_UNDWR.f_undwr fuw -- UNDWR Tags 9/9/2015 JS
      JOIN BDR_DM.WRK_PREMIUM_DATABASELINE_TNA tna
      ON fuw.indv_id            = tna.individual_id
      --WHERE fuw.etl_lst_btch_id > v_uw_lastetlbatchid        ---------------OAS DELETE
	  WHERE fuw.etl_lst_btch_id > :V_UNDWR_ETL_LST_BTCH_ID            -------------------OAS ADD

      UNION
      SELECT tna.individual_id
      FROM BDR_UNDWR.f_undwr fuw -- UNDWR Tags 9/9/2015 JS
      JOIN BDR_DM.WRK_RIA_PREMIUM_DATABASELINE_TNA tna
      ON fuw.insd_pln_id        = tna.insuredplan_id
      --WHERE fuw.etl_lst_btch_id > v_uw_lastetlbatchid        ---------------OAS DELETE
	  WHERE fuw.etl_lst_btch_id > :V_UNDWR_ETL_LST_BTCH_ID            -------------------OAS ADD

	  UNION
      SELECT tna.individual_id
      FROM BDR_UNDWR.f_undwr fuw -- UNDWR Tags 9/9/2015 JS
      JOIN BDR_DM.WRK_PREMIUM_DATABASELINE_TNA tna
      ON fuw.insd_pln_id        = tna.insuredplan_id
      --WHERE fuw.etl_lst_btch_id > v_uw_lastetlbatchid        ---------------OAS DELETE
	  WHERE fuw.etl_lst_btch_id > :V_UNDWR_ETL_LST_BTCH_ID            -------------------OAS ADD


      UNION --- Adding Cert Channel 8/05/2015
      SELECT tna.individual_id
      FROM BDR_DM.WRK_RIA_PREMIUM_DATABASELINE_TNA tna
      INNER JOIN BDR_DM.wrk_ipacqchannel_chg ipac
      ON tna.insuredplan_id = ipac.insuredplanid

	  UNION --- Adding Cert Channel 8/05/2015
      SELECT tna.individual_id
      FROM BDR_DM.WRK_PREMIUM_DATABASELINE_TNA tna
      INNER JOIN BDR_DM.wrk_ipacqchannel_chg ipac
      ON tna.insuredplan_id = ipac.insuredplanid

      UNION
      SELECT tna.individual_id
      FROM SRC_COMPAS_D.adt_household_profile adthp -- added for ACCT_NBR
      JOIN BDR_DM.WRK_RIA_PREMIUM_DATABASELINE_TNA tna
      ON adthp.household_id          = tna.household_id
      --WHERE adt_row_creat_by_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE adt_row_creat_by_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD
      AND adt_typ_cd                 = ''D''

	  UNION
      SELECT tna.individual_id
      FROM SRC_COMPAS_D.adt_household_profile adthp -- added for ACCT_NBR
      JOIN BDR_DM.WRK_PREMIUM_DATABASELINE_TNA tna
      ON adthp.household_id          = tna.household_id
      --WHERE adt_row_creat_by_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE adt_row_creat_by_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD
      AND adt_typ_cd                 = ''D''


      UNION
      SELECT tna.individual_id --- added 1 11 2018
      FROM SRC_COMPAS_D.adt_household_billing_profile adthbp
      JOIN BDR_DM.WRK_RIA_PREMIUM_DATABASELINE_TNA tna
      ON adthbp.household_id         = tna.household_id
      --WHERE adt_row_creat_by_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE adt_row_creat_by_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD
      AND adt_typ_cd                 = ''D''


	  UNION
      SELECT tna.individual_id --- added 1 11 2018
      FROM SRC_COMPAS_D.adt_household_billing_profile adthbp
      JOIN BDR_DM.WRK_PREMIUM_DATABASELINE_TNA tna
      ON adthbp.household_id         = tna.household_id
      --WHERE adt_row_creat_by_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE adt_row_creat_by_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD
      AND adt_typ_cd                 = ''D''



    UNION  --------AOP De-Scope - MB/MC Premium Fact
      SELECT tna.individual_id --- added 1 11 2018
      FROM SRC_COMPAS_D.adt_billing_bucket_adjustment adtbbad
      JOIN BDR_DM.WRK_PREMIUM_DATABASELINE_TNA tna
      ON adtbbad.household_id        = tna.household_id
      --WHERE adt_row_creat_by_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE adt_row_creat_by_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD
      AND adt_typ_cd                 = ''D''

      UNION		--------AOP Scope - MB/MC Premium Fact
	  SELECT tna.INDIVIDUAL_ID FROM
	  (SELECT NVL(CD.CUST_ID,ADTCD.CUST_ID) AS CUST_ID
	  FROM SRC_RIA.ADT_CM_RATE_ADJ_DTL_VW ADTADJ
	  JOIN SRC_RIA.ADT_PRICE_RULE_DIM ADTPRD ON ADTPRD.PRICING_RULE_ID=ADTADJ.PRICING_RULE_ID AND ADTPRD.ADT_TYP_CD=''D''

	  LEFT JOIN SRC_RIA.BCHG_FACT BF ON BF.PRICING_RULE_ID=ADTPRD.PRICING_RULE_ID
	  LEFT JOIN SRC_RIA.ADT_BCHG_FACT ADTBF ON ADTBF.PRICING_RULE_ID=ADTPRD.PRICING_RULE_ID AND ADTBF.ADT_TYP_CD=''D''

	  LEFT JOIN SRC_RIA.CONTRACT_DIM       CD        ON CD.SRC_SA_ID    = BF.SRC_SA_ID
	  LEFT JOIN SRC_RIA.ADT_CONTRACT_DIM ADTCD ON ADTCD.SRC_SA_ID = ADTBF.SRC_SA_ID AND ADTCD.ADT_TYP_CD=''D''
      --WHERE ADTADJ.adt_row_creat_by_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE ADTADJ.adt_row_creat_by_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD  
	  AND ADTADJ.adt_typ_cd = ''D''	) A
	  LEFT JOIN SRC_RIA.CUSTOMER_DIM CUSTD ON NVL(CUSTD.SRC_CUST_ID,''UNKNOWN'') = NVL(A.CUST_ID,''UNKNOWN'')  AND CUSTD.ID_TYPE_CD = ''INDID''
	  LEFT JOIN SRC_RIA.ADT_CUSTOMER_DIM ADTCUSTD ON NVL(ADTCUSTD.SRC_CUST_ID,''UNKNOWN'') = NVL(A.CUST_ID,''UNKNOWN'')  AND ADTCUSTD.ID_TYPE_CD = ''INDID'' AND ADTCUSTD.ADT_TYP_CD=''D''
	  JOIN BDR_DM.WRK_RIA_PREMIUM_DATABASELINE_TNA tna ON NVL(NVL(CUSTD.ID_VAL,ADTCUSTD.ID_VAL),''UNKNOWN'')=NVL(TO_CHAR(tna.INDIVIDUAL_ID),''UNKNOWN'')
      UNION  --------AOP De-Scope - MB/MC Premium Fact   -- No Replacement
      SELECT tna.individual_id --- added 1 11 2018
      FROM SRC_COMPAS_D.adt_adjustment adtadj
      JOIN SRC_COMPAS_D.adt_billing_bucket_adjustment adtbbadj
      ON adtadj.adjustment_id = adtbbadj.adjustment_id
      JOIN BDR_DM.WRK_PREMIUM_DATABASELINE_TNA tna
      ON adtbbadj.household_id              = tna.household_id
      --WHERE adtadj.adt_row_creat_by_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE adtadj.adt_row_creat_by_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD
      AND adtadj.adt_typ_cd                 = ''D''


/*    UNION   --------AOP De-Scope - MB/MC Premium Fact
      SELECT tna.individual_id --- added 1 11 2018
      FROM ADT_COMPAS.adt_calculated_rate adtcal
      JOIN ADT_COMPAS.adt_ins_plan_billing_bucket adtipbbt
      ON adtcal.calculated_rate_id = adtipbbt.calculated_rate_id
      JOIN DM.WRK_PREMIUM_DATABASELINE_TNA tna
      ON adtipbbt.household_id              = tna.household_id
      WHERE adtcal.adt_row_creat_by_btch_id > v_etllastbatchid
      AND adtcal.adt_typ_cd                 = ''D'' */

      UNION     ----------AOP Scope - MB/MC Premium Fact
	  SELECT tna.INDIVIDUAL_ID FROM
	  (
	  SELECT NVL(CD.CUST_ID,ADTCD.CUST_ID) AS CUST_ID
	  FROM SRC_RIA.ADT_PRICE_RULE_DIM ADTPRD
	  LEFT JOIN SRC_RIA.BCHG_FACT BF ON BF.PRICING_RULE_ID=ADTPRD.PRICING_RULE_ID
	  LEFT JOIN SRC_RIA.ADT_BCHG_FACT ADTBF ON ADTBF.PRICING_RULE_ID=ADTPRD.PRICING_RULE_ID AND ADTBF.ADT_TYP_CD=''D''

	  LEFT JOIN SRC_RIA.CONTRACT_DIM       CD        ON CD.SRC_SA_ID    = BF.SRC_SA_ID
	  LEFT JOIN SRC_RIA.ADT_CONTRACT_DIM ADTCD ON ADTCD.SRC_SA_ID = ADTBF.SRC_SA_ID AND ADTCD.ADT_TYP_CD=''D''
      --WHERE ADTPRD.adt_row_creat_by_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE ADTPRD.adt_row_creat_by_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD  
	  AND ADTPRD.adt_typ_cd = ''D''	) A

	  LEFT JOIN SRC_RIA.CUSTOMER_DIM CUSTD ON NVL(CUSTD.SRC_CUST_ID,''UNKNOWN'') = NVL(A.CUST_ID,''UNKNOWN'')  AND CUSTD.ID_TYPE_CD = ''INDID''
	  LEFT JOIN SRC_RIA.ADT_CUSTOMER_DIM ADTCUSTD ON NVL(ADTCUSTD.SRC_CUST_ID,''UNKNOWN'') = NVL(A.CUST_ID,''UNKNOWN'')  AND ADTCUSTD.ID_TYPE_CD = ''INDID'' AND ADTCUSTD.ADT_TYP_CD=''D''
	  JOIN BDR_DM.WRK_RIA_PREMIUM_DATABASELINE_TNA tna ON NVL(NVL(CUSTD.ID_VAL,ADTCUSTD.ID_VAL),''UNKNOWN'')=NVL(TO_CHAR(tna.INDIVIDUAL_ID),''UNKNOWN'')
 

	  UNION
      SELECT tna.individual_id
      FROM SRC_COMPAS_D.adt_household_member adthm -- added for ACCT_NBR
      JOIN BDR_DM.WRK_RIA_PREMIUM_DATABASELINE_TNA tna
      ON adthm.household_id          = tna.household_id
      --WHERE adt_row_creat_by_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE adt_row_creat_by_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD
      AND adt_typ_cd                 = ''D''

		UNION         ----- AOP Scope 05/22/2024
		SELECT tna.individual_id FROM (
		SELECT ADTMPB.PER_ID AS CUST_ID FROM
		SRC_RIA.ADT_MEMBERSHIP_DIM ADTMD
		LEFT JOIN  SRC_RIA.ADT_MEMBERSHIP_PER_BRIDGE ADTMPB
		ON ADTMPB.SRC_MEMBERSHIP_ID=ADTMD.SRC_MEMBERSHIP_ID AND ADTMPB.ADT_TYP_CD=''D''
		--WHERE  ADTMD.adt_row_creat_by_btch_id > v_etllastbatchid             ---------------OAS DELETE
		WHERE ADTMD.adt_row_creat_by_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD 
		AND   ADTMD.adt_typ_cd = ''D'') A
		LEFT JOIN SRC_RIA.CUSTOMER_DIM           CUSTD
		ON NVL(CUSTD.SRC_CUST_ID,''UNKNOWN'')    = NVL(A.CUST_ID,''UNKNOWN'')  AND CUSTD.ID_TYPE_CD    = ''INDID''
		LEFT JOIN SRC_RIA.ADT_CUSTOMER_DIM ADTCUSTD
		ON NVL(ADTCUSTD.SRC_CUST_ID,''UNKNOWN'') =NVL(A.CUST_ID,''UNKNOWN'') AND ADTCUSTD.ID_TYPE_CD = ''INDID'' AND ADTCUSTD.adt_typ_cd = ''D''
		JOIN BDR_DM.WRK_RIA_PREMIUM_DATABASELINE_TNA tna   ON NVL(NVL(CUSTD.ID_VAL,ADTCUSTD.ID_VAL),''UNKNOWN'') = NVL(TO_CHAR(tna.INDIVIDUAL_ID),''UNKNOWN'')


      UNION
      SELECT tna.individual_id
      FROM SRC_COMPAS_D.adt_household_member adthm -- added for ACCT_NBR
      JOIN BDR_DM.WRK_PREMIUM_DATABASELINE_TNA tna
      ON adthm.household_id          = tna.household_id
      --WHERE adt_row_creat_by_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE adt_row_creat_by_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD
      AND adt_typ_cd                 = ''D''


      UNION
      SELECT tna.individual_id-- Added for Legal Entity 04/19/2016
      FROM SRC_COMPAS_D.insured_plan_profile ipp
      INNER JOIN BDR_DM.WRK_RIA_PREMIUM_DATABASELINE_TNA tna
      ON ipp.insured_plan_id    = tna.insuredplan_id
      --WHERE ipp.etl_lst_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE ipp.etl_lst_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD

	  UNION
      SELECT tna.individual_id-- Added for Legal Entity 04/19/2016
      FROM SRC_COMPAS_D.insured_plan_profile ipp
      INNER JOIN BDR_DM.WRK_PREMIUM_DATABASELINE_TNA tna
      ON ipp.insured_plan_id    = tna.insuredplan_id
      --WHERE ipp.etl_lst_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE ipp.etl_lst_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD

      UNION
      SELECT tna.individual_id-- Added for Legal Entity 04/19/2016
      FROM SRC_COMPAS_D.adt_insured_plan_profile adtipp
      INNER JOIN BDR_DM.WRK_RIA_PREMIUM_DATABASELINE_TNA tna
      ON adtipp.insured_plan_id    = tna.insuredplan_id
      --WHERE adtipp.etl_lst_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE adtipp.etl_lst_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD

      UNION
      SELECT tna.individual_id-- Added for Legal Entity 04/19/2016
      FROM SRC_COMPAS_D.adt_insured_plan_profile adtipp
      INNER JOIN BDR_DM.WRK_PREMIUM_DATABASELINE_TNA tna
      ON adtipp.insured_plan_id    = tna.insuredplan_id
      --WHERE adtipp.etl_lst_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE adtipp.etl_lst_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD


      UNION
      SELECT tna.individual_id -- Added for Compas D_AGE_LOOK_FRACnt
      FROM SRC_COMPAS_D.insured_plan ip
      JOIN SRC_COMPAS_D.application a
      ON ip.application_id = a.application_id
      JOIN BDR_DM.WRK_RIA_PREMIUM_DATABASELINE_TNA tna
      ON ip.insured_plan_id   = tna.insuredplan_id
      --WHERE a.etl_lst_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE a.etl_lst_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD

	   UNION
      SELECT tna.individual_id -- Added for Compas D_AGE_LOOK_FRACnt
      FROM SRC_COMPAS_D.insured_plan ip
      JOIN SRC_COMPAS_D.application a
      ON ip.application_id = a.application_id
      JOIN BDR_DM.WRK_PREMIUM_DATABASELINE_TNA tna
      ON ip.insured_plan_id   = tna.insuredplan_id
      --WHERE a.etl_lst_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE a.etl_lst_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD


      UNION
      SELECT tna.individual_id -- Added for Compas D_AGE_LOOK_FRACnt
      FROM SRC_COMPAS_D.insured_plan ip
      JOIN SRC_COMPAS_D.application a
      ON ip.application_id = a.application_id
      JOIN SRC_COMPAS_D.application_agent ag
      ON a.application_id = ag.application_id
      JOIN BDR_DM.WRK_RIA_PREMIUM_DATABASELINE_TNA tna
      ON ip.insured_plan_id    = tna.insuredplan_id
      --WHERE ag.etl_lst_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE ag.etl_lst_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD

	  UNION
      SELECT tna.individual_id -- Added for Compas D_AGE_LOOK_FRACnt
      FROM SRC_COMPAS_D.insured_plan ip
      JOIN SRC_COMPAS_D.application a
      ON ip.application_id = a.application_id
      JOIN SRC_COMPAS_D.application_agent ag
      ON a.application_id = ag.application_id
      JOIN BDR_DM.WRK_PREMIUM_DATABASELINE_TNA tna
      ON ip.insured_plan_id    = tna.insuredplan_id
      --WHERE ag.etl_lst_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE ag.etl_lst_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD


      UNION
      SELECT tna.individual_id ----  Added for Compas D_AGE_LOOK_FRACnt
      FROM SRC_COMPAS_D.insured_plan ip
      JOIN SRC_COMPAS_D.adt_application adta
      ON ip.application_id = adta.application_id
      JOIN BDR_DM.WRK_RIA_PREMIUM_DATABASELINE_TNA tna
      ON ip.insured_plan_id          = tna.insuredplan_id
     -- WHERE adt_row_creat_by_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE adt_row_creat_by_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD
      AND adt_typ_cd                 = ''D''

      UNION
      SELECT tna.individual_id ----  Added for Compas D_AGE_LOOK_FRACnt
      FROM SRC_COMPAS_D.insured_plan ip
      JOIN SRC_COMPAS_D.adt_application adta
      ON ip.application_id = adta.application_id
      JOIN BDR_DM.WRK_PREMIUM_DATABASELINE_TNA tna
      ON ip.insured_plan_id          = tna.insuredplan_id
      --WHERE adt_row_creat_by_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE adt_row_creat_by_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD
      AND adt_typ_cd                 = ''D''


      UNION
      SELECT tna.individual_id ----  Added for Compas D_AGE_LOOK_FRACnt
      FROM SRC_COMPAS_D.insured_plan ip
      JOIN SRC_COMPAS_D.application a
      ON ip.application_id = a.application_id
      JOIN SRC_COMPAS_D.adt_application_agent adtag
      ON a.application_id = adtag.application_id
      JOIN BDR_DM.WRK_RIA_PREMIUM_DATABASELINE_TNA tna
      ON ip.insured_plan_id          = tna.insuredplan_id
      --WHERE adt_row_creat_by_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE adt_row_creat_by_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD
      AND adt_typ_cd                 = ''D''


      UNION
      SELECT tna.individual_id ----  Added for Compas D_AGE_LOOK_FRACnt
      FROM SRC_COMPAS_D.insured_plan ip
      JOIN SRC_COMPAS_D.application a
      ON ip.application_id = a.application_id
      JOIN SRC_COMPAS_D.adt_application_agent adtag
      ON a.application_id = adtag.application_id
      JOIN BDR_DM.WRK_PREMIUM_DATABASELINE_TNA tna
      ON ip.insured_plan_id          = tna.insuredplan_id
      --WHERE adt_row_creat_by_btch_id > v_etllastbatchid             ---------------OAS DELETE
	  WHERE adt_row_creat_by_btch_id > :V_ETL_LST_BTCH_ID            -------------------OAS ADD
      AND adt_typ_cd                 = ''D''

	);	
    	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );


  
V_STEP_NAME    := ''TRUNCATE - WRK_INSD_PLN_PRFL_OVRLP_TMP'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

  EXECUTE IMMEDIATE ''truncate table BDR_DM.WRK_INSD_PLN_PRFL_OVRLP_TMP'';

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );
   
V_STEP_NAME    := ''TRUNCATE - WRK_INSD_PLN_PRFL_OVRLP_TMP2'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

  EXECUTE IMMEDIATE ''truncate table BDR_DM.WRK_INSD_PLN_PRFL_OVRLP_TMP2'';

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

V_STEP_NAME    := ''TRUNCATE - WRK_INSD_PLN_PRFL_OVRLP_TMP3'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

  EXECUTE IMMEDIATE ''truncate table BDR_DM.WRK_INSD_PLN_PRFL_OVRLP_TMP3'';

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

    
V_STEP_NAME    := ''TRUNCATE - WRK_INSD_PLN_PRFL_TMP'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

  EXECUTE IMMEDIATE ''truncate table BDR_DM.WRK_INSD_PLN_PRFL_TMP'';

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

  
V_STEP_NAME    := ''INSERT - WRK_INSD_PLN_PRFL_OVRLP_TMP'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

INSERT /*+ append */
  INTO BDR_DM.WRK_INSD_PLN_PRFL_OVRLP_TMP
  SELECT
    /*+ Parallel (8)*/
    DISTINCT a1.*
  FROM BDR_CONF.D_INSD_PLN_PRFL a1
  JOIN BDR_CONF.D_INSD_PLN_PRFL a2
  ON a1.SRC_INSD_PLN_ID         = a2.SRC_INSD_PLN_ID
  AND a1.SRC_DEL_FLG            = a2.SRC_DEL_FLG
  AND a1.INSD_PLN_PRFL_STRT_DT <= a2.INSD_PLN_PRFL_STOP_DT
  AND a1.INSD_PLN_PRFL_STOP_DT >= a2.INSD_PLN_PRFL_STRT_DT
  AND a1.INSD_PLN_PRFL_STRT_DT != a2.INSD_PLN_PRFL_STRT_DT;
--  COMMIT;
    	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );


V_STEP_NAME    := ''INSERT - WRK_INSD_PLN_PRFL_OVRLP_TMP2'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

  INSERT /*+ append */
  INTO BDR_DM.WRK_INSD_PLN_PRFL_OVRLP_TMP2
  SELECT
    /*+ Parallel (8)*/
    *
  FROM
    (SELECT D_INSD_PLN_PRFL_SK,
      INSD_PLN_PRFL_STOP_DT,
      INSD_PLN_PRFL_STRT_DT,
      SRC_INSD_PLN_ID,
      SRC_DEL_FLG,
      ENT_AGE,
      ROW_NUMBER () OVER (PARTITION BY SRC_INSD_PLN_ID ORDER BY INSD_PLN_PRFL_STOP_DT DESC, INSD_PLN_PRFL_STRT_DT DESC) AS RN,
      SRC_INSD_PLN_PRFL_ID
    FROM BDR_DM.WRK_INSD_PLN_PRFL_OVRLP_TMP
    )
  WHERE RN = 1;
 -- COMMIT;
     	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );


V_STEP_NAME    := ''INSERT - WRK_INSD_PLN_PRFL_OVRLP_TMP3'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

  INSERT /*+ append */
  INTO BDR_DM.WRK_INSD_PLN_PRFL_OVRLP_TMP3
  SELECT
    /*+ Parallel (8)*/
    D_INSD_PLN_PRFL_SK,
    INSD_PLN_PRFL_STOP_DT,
    INSD_PLN_PRFL_STRT_DT,
    SRC_INSD_PLN_ID,
    SRC_DEL_FLG,
    ENT_AGE,
    SRC_INSD_PLN_PRFL_ID
  FROM BDR_DM.WRK_INSD_PLN_PRFL_OVRLP_TMP2
  UNION
  SELECT D_INSD_PLN_PRFL_SK,
    INSD_PLN_PRFL_STOP_DT,
    INSD_PLN_PRFL_STRT_DT,
    SRC_INSD_PLN_ID,
    SRC_DEL_FLG,
    ENT_AGE,
    SRC_INSD_PLN_PRFL_ID
  FROM BDR_CONF.D_INSD_PLN_PRFL
  WHERE D_INSD_PLN_PRFL_SK NOT IN
    ( SELECT D_INSD_PLN_PRFL_SK FROM BDR_DM.WRK_INSD_PLN_PRFL_OVRLP_TMP
    );
 -- COMMIT;
     	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );


  
V_STEP_NAME    := ''INSERT - WRK_INSD_PLN_PRFL_TMP'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

  INSERT /*+ append */
  INTO BDR_DM.WRK_INSD_PLN_PRFL_TMP
  SELECT
    /*+ Parallel (8)*/
    D_INSD_PLN_PRFL_SK,
    INSD_PLN_PRFL_STOP_DT,
    INSD_PLN_PRFL_STRT_DT,
    SRC_INSD_PLN_ID,
    SRC_DEL_FLG,
    ENT_AGE,
    ROW_NUMBER () OVER (PARTITION BY SRC_INSD_PLN_ID, INSD_PLN_PRFL_STOP_DT, INSD_PLN_PRFL_STRT_DT ORDER BY SRC_DEL_FLG) AS R,
    SRC_INSD_PLN_PRFL_ID
  FROM BDR_DM.WRK_INSD_PLN_PRFL_OVRLP_TMP3;
 -- COMMIT;
     	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );




CALL UTIL.SP_ETL_CHECK_CONSTRAINTS(:DB_NAME , :APPLICATION , :WORKFLOW_NAME , :OBJECT_NAME , :V_BATCH_ID );



UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''COMPLETE'', ERROR_MSG = null, BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
;

UPDATE  UTIL.ETL_BATCH_OBJECT_INCR_VALU SET INCR_COLUMN_VALUE = (select max(BATCH_ID) FROM UTIL.ETL_BATCH_LOG WHERE APPLICATION = ''UNDERWRITING'' AND BATCH_STATUS = ''COMPLETE''), LST_MOD_DT = CURRENT_TIMESTAMP() 
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''UNDWR_ETL_LST_BTCH_ID''
;



UPDATE  UTIL.ETL_BATCH_OBJECT_INCR_VALU SET INCR_COLUMN_VALUE = :V_BATCH_ID, LST_MOD_DT = CURRENT_TIMESTAMP() 
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID''
;


EXCEPTION

WHEN OTHER THEN

UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''ERROR'', ERROR_MSG = :SQLERRM,  BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
;

INSERT INTO  UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ERROR_MSG, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''ERROR'', :V_STEP_NAME, :V_STEP_SEQ, :SQLERRM, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() )
;



RAISE;

END;

';