USE SCHEMA BDR_DM; CREATE OR REPLACE PROCEDURE "SP_PREMIUM_IXL_COMPASARAGING_PPODELQ_RPT_M"("DB_NAME" VARCHAR(16777216), "APPLICATION" VARCHAR(16777216), "WORKFLOW_NAME" VARCHAR(16777216), "OBJECT_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '

-- Original workflow: wkf_RIA_Premium_FactLoad_IXL_TargetLoad_M
-- Original mapping: m_Premium_IXL_CompasARAging_PPODelq_RPT_M
-- Original folder: Premium
-- Original filename: wkf_RIA_Premium_FactLoad_IXL_TargetLoad_M.XML

DECLARE


V_ROWS_INSERTED  INTEGER;
V_ROWS_UPDATED INTEGER;
V_ROWS_DELETED INTEGER;
V_LAST_QUERY_ID VARCHAR;

V_WH VARCHAR;
V_BATCH_ID INTEGER;


V_BATCH_OBJECT_START_TIME        VARCHAR;
V_STEP_START_TIME    VARCHAR;
V_STEP_NAME VARCHAR;
V_STEP_SEQ INTEGER DEFAULT 0;
V_ETL_LST_BTCH_ID INTEGER;

V_ROWS_LOADED              INTEGER; 
V_STAGE_QUERY1              VARCHAR;
V_STAGE_QUERY2              VARCHAR;
V_AOP_LIVE_DATE VARCHAR;


BEGIN

EXECUTE IMMEDIATE ''USE DATABASE ''||:DB_NAME; 

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_BATCH_OBJECT_START_TIME := (SELECT CURRENT_TIMESTAMP());



LET res1 RESULTSET := 
(

SELECT 

WH ,
BATCH_ID
  
FROM UTIL.ETL_BATCH_OBJECT_CONTROL
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
FETCH FIRST 1 ROW ONLY

)
;


LET C1 CURSOR FOR res1;
open C1;
FETCH C1 into  V_WH,V_BATCH_ID ;
close C1;


LET res2 RESULTSET := 

(

WITH PARAMETERS ( AOP_LIVE_DATE) AS
(
  
SELECT * 
FROM  
(SELECT PARAMETER_NAME, PARAMETER_VALUE  FROM UTIL.ETL_OBJECT_PARAMETER_VALUE 
WHERE 1 = 1
AND APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
AND ACTIVE_FLG = ''Y''  
  
UNION ALL       

SELECT PARAMETER_NAME, PARAMETER_VALUE  FROM UTIL.ETL_GLOBAL_PARAMETER_VALUE WHERE PAR_GLOBAL_TYPE = ''PARGLOBAL_OPREPORTS'' AND ACTIVE_FLG = ''Y''
AND PARAMETER_NAME NOT IN  (
SELECT PARAMETER_NAME  FROM UTIL.ETL_OBJECT_PARAMETER_VALUE WHERE 1 = 1
AND APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
AND ACTIVE_FLG = ''Y''   ))
 
PIVOT(MAX(PARAMETER_VALUE) FOR PARAMETER_NAME IN ( ''AOP_LIVE_DATE'')) 

 
)  
SELECT * FROM PARAMETERS 
)  
  
;


LET C2 CURSOR FOR res2;
open C2;
FETCH C2 into   V_AOP_LIVE_DATE; 
close C2;


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:V_WH;
USE SCHEMA BDR_DM;	--OAS ADD



INSERT INTO UTIL.ETL_BATCH_OBJECT_INCR_VALU (APPLICATION, WORKFLOW_NAME, OBJECT_NAME, INCR_COLUMN, INCR_COLUMN_VALUE )
SELECT * FROM (select :APPLICATION AS APPLICATION, :WORKFLOW_NAME AS WORKFLOW_NAME, :OBJECT_NAME AS OBJECT_NAME, ''ETL_LST_BTCH_ID'' AS INCR_COLUMN, -1 AS INCR_COLUMN_VALUE) A
WHERE NOT EXISTS (SELECT 1 FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU B WHERE B.APPLICATION = A.APPLICATION AND B.WORKFLOW_NAME = A.WORKFLOW_NAME AND B.OBJECT_NAME = A.OBJECT_NAME AND B.INCR_COLUMN = A.INCR_COLUMN)
;

V_ETL_LST_BTCH_ID :=(SELECT INCR_COLUMN_VALUE FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID'');


-- Component SQ_sc_D_PLN_BEN_MOD, Type SOURCE 
CREATE OR REPLACE TEMPORARY TABLE BDR_DM.SQ_sc_D_PLN_BEN_MOD AS
(
SELECT SRC.*, row_number() over (order by 1) AS source_record_id FROM (
WITH
    summary_totals AS
    (   SELECT
            CASE
                WHEN c.dt_val = add_months(TRUNC(CURRENT_DATE,''month''),-1)
                THEN ''0''
                WHEN c.dt_val = add_months(TRUNC(CURRENT_DATE,''month''),-2)
                THEN ''1''
                WHEN c.dt_val = add_months(TRUNC(CURRENT_DATE,''month''),-3)
                THEN ''2''
                WHEN c.dt_val = add_months(TRUNC(CURRENT_DATE,''month''),-4)
                THEN ''3''
                WHEN c.dt_val = add_months(TRUNC(CURRENT_DATE,''month''),-5)
                THEN ''4''
                WHEN c.dt_val = add_months(TRUNC(CURRENT_DATE,''month''),-6)
                THEN ''5''
                WHEN c.dt_val <= add_months(TRUNC(CURRENT_DATE,''month''),-7)
                THEN ''6''
                ELSE NULL
            END                  AS category,
            SUM(a.DELQ_PREM_AMT) AS delq_prem_amt
        FROM
            BDR_DM.F_PREM_TRANS_DAY a
        JOIN
            BDR_CONF.D_PLN_BEN_MOD b
        ON
            a.d_pln_ben_mod_sk = b.d_pln_ben_mod_sk
        JOIN
            BDR_CONF.D_CAL_DT c
        ON
            a.PREM_DUE_DT_ID = c.D_CAL_DT_ID
        JOIN
            BDR_CONF.D_CAL_DT d
        ON
            a.actv_dt_id = d.d_cal_dt_id
        WHERE
d.DT_VAL <= last_day(add_months(TRUNC(CURRENT_DATE,''month''),-1)) 

 AND c.D_CAL_DT_ID < :V_AOP_LIVE_DATE
/* Added condtion FOR retro DATA Premium Due < AOP live date */
AND b.COMPAS_PLN_CATGY_ID = 4 /*  PHIP plan category */
        GROUP BY
            CASE
                WHEN c.dt_val = add_months ( TRUNC(CURRENT_DATE,''month''), -1 )
                THEN ''0''
                WHEN c.dt_val = add_months ( TRUNC(CURRENT_DATE,''month''), -2 )
                THEN ''1''
                WHEN c.dt_val = add_months ( TRUNC(CURRENT_DATE,''month''), -3 )
                THEN ''2''
                WHEN c.dt_val = add_months ( TRUNC(CURRENT_DATE,''month''), -4 )
                THEN ''3''
                WHEN c.dt_val = add_months ( TRUNC(CURRENT_DATE,''month''), -5 )
                THEN ''4''
                WHEN c.dt_val = add_months ( TRUNC(CURRENT_DATE,''month''), -6 )
                THEN ''5''
                WHEN c.dt_val <= add_months ( TRUNC(CURRENT_DATE,''month''), -7 )
                THEN ''6''
                ELSE NULL
            END 
    ) 
    , 
    mapping_data AS
    (   SELECT
            ''0''               AS category,
            ''Current Month'' AS category_desc
        FROM
            dual
        
        UNION ALL
        
        SELECT
            ''1''           AS category,
            ''One Month'' AS category_desc
        FROM
            dual
        
        UNION ALL
        
        SELECT
            ''2''           AS category,
            ''Two Months'' AS category_desc
        FROM
            dual
        
        UNION ALL
        
        SELECT
            ''3''             AS category,
            ''Three Months'' AS category_desc
        FROM
            dual
        
        UNION ALL
        
        SELECT
            ''4''             AS category,
            ''Four Months'' AS category_desc
        FROM
            dual
        
        UNION ALL
        
        SELECT
            ''5''             AS category,
            ''Five Months'' AS category_desc
        FROM
            dual
        
        UNION ALL
        
        SELECT
            ''6''                   AS category,
            ''Six or More Months'' AS category_desc
        FROM
            dual 
    ) 
    , 
    result_set AS
    (   
       SELECT
            b.category,
            b.category_desc,
            delq_prem_amt
        FROM
            mapping_data b
        LEFT JOIN
            summary_totals a
        ON
            b.category = a.category
        
        UNION ALL
        
        SELECT
            ''5.5''                             AS category,
            ''Current Plus Five Month Total'' AS category_desc,
            SUM(delq_prem_amt)              AS delq_prem_amt
        FROM
            summary_totals a
        WHERE
            a.category <= 5
        
        UNION ALL
        
        SELECT
            ''7''                 AS category ,
            ''Total All Months'' AS category_desc,
            SUM(delq_prem_amt) AS delq_prem_amt
        FROM
            summary_totals
    )
SELECT
    category_desc as COMPAS_PLN_TYP_DESC, ---OAS ADD
    NVL(delq_prem_amt,0) AS COMPAS_PLN_CATGY_ID ---"PHIP Plans"
FROM
    result_set
ORDER BY
    category
) SRC
);


-- Component sc_adw_ar_summary_compas, Type TARGET_EXPORT_PREPARE Stage data before exporting
CREATE OR REPLACE TEMPORARY TABLE BDR_DM.sc_adw_ar_summary_compas AS
(
SELECT
SQ_sc_D_PLN_BEN_MOD.COMPAS_PLN_TYP_DESC /* CATEGORY_DESC */,
SQ_sc_D_PLN_BEN_MOD.COMPAS_PLN_CATGY_ID /* PHIP_Plans */
FROM
BDR_DM.SQ_sc_D_PLN_BEN_MOD
);


-- Component sc_adw_ar_summary_compas, Type EXPORT_DATA Exporting data

V_ROWS_LOADED := (select count(1) from BDR_DM.sc_adw_ar_summary_compas);

V_STEP_NAME := ''Generate ADW_AR_SUMMARY_COMPAS.csv''; 
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());


-- Component sc_FF_V_D_ACQN_CHNL, Type EXPORT_DATA Exporting data
V_STAGE_QUERY1 := ''COPY INTO @UTIL.STAGE_AZURE_ISDC/premium/outbox/ADW_AR_SUMMARY_COMPAS_''||
(SELECT TO_CHAR(CURRENT_DATE, ''MMYY''))||'' FROM (
            SELECT * FROM BDR_DM.sc_adw_ar_summary_compas
               )
file_format = (type = ''''CSV''''
               field_delimiter = '''',''''
               compression = None
              )
HEADER = TRUE
OVERWRITE = True
MAX_FILE_SIZE = 4900000000
SINGLE = False''
;


V_STAGE_QUERY2 := ''COPY INTO @UTIL.STAGE_AZURE_ISDC/premium/outbox/ADW_AR_SUMMARY_COMPAS_''||(SELECT TO_CHAR(CURRENT_DATE, ''MMYY''))||'' FROM (
            SELECT ''''COMPAS_PLN_TYP_DESC'''',
				''''COMPAS_PLN_CATGY_ID'''',
				''''ETL_LST_BTCH_ID''''
               )
file_format = (type = ''''CSV'''' 
               field_delimiter = '''',''''
               
               compression = None
              )
HEADER = FALSE
OVERWRITE = True
MAX_FILE_SIZE = 4900000000
SINGLE = TRUE''
;


IF (V_ROWS_LOADED > 0) THEN 

execute immediate ''USE SCHEMA ''|| ''BDR_DM'';                                  
execute immediate  :V_STAGE_QUERY1;  

ELSEIF (V_ROWS_LOADED = 0) THEN 

execute immediate ''USE SCHEMA ''|| ''BDR_DM'';                                  
execute immediate  :V_STAGE_QUERY2;  


END IF;  



UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''COMPLETE'', ERROR_MSG = null, BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
;
UPDATE  UTIL.ETL_BATCH_OBJECT_INCR_VALU SET INCR_COLUMN_VALUE = :V_BATCH_ID, LST_MOD_DT = CURRENT_TIMESTAMP() 
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID''
;

EXCEPTION

WHEN OTHER THEN

UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''ERROR'', ERROR_MSG = :SQLERRM,  BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
;

INSERT INTO  UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ERROR_MSG, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''ERROR'', :V_STEP_NAME, :V_STEP_SEQ, :SQLERRM, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() )
;



RAISE;

END;

';