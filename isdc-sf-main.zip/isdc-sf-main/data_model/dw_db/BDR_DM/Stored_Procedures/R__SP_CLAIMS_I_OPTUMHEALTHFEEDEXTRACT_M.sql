USE SCHEMA BDR_DM; CREATE OR REPLACE PROCEDURE "SP_CLAIMS_I_OPTUMHEALTHFEEDEXTRACT_M"("DB_NAME" VARCHAR(16777216), "APPLICATION" VARCHAR(16777216), "WORKFLOW_NAME" VARCHAR(16777216), "OBJECT_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '

-- Original workflow: wkf_OptumHealthFeed_I_WrkTblLoad_M
-- Original mapping: m_Claims_I_OptumHealthFeedExtract_M
-- Original folder: Claims
-- Original filename: wkf_OptumHealthFeed_I_WrkTblLoad_M.XML

DECLARE


V_ROWS_INSERTED  INTEGER;
V_ROWS_UPDATED INTEGER;
V_ROWS_DELETED INTEGER;
V_LAST_QUERY_ID VARCHAR;

V_WH VARCHAR;
V_BATCH_ID INTEGER;


V_BATCH_OBJECT_START_TIME        VARCHAR;
V_STEP_START_TIME    VARCHAR;
V_STEP_NAME VARCHAR;
V_STEP_SEQ INTEGER DEFAULT 0;
V_ETL_LST_BTCH_ID INTEGER;

v_extract_date     DATE;
v_extract_key_low  NUMBER (8);
v_extract_key_high NUMBER (8);
v_start_date     DATE;
v_stop_date     DATE;
v_sql          VARCHAR;
V_OVERRIDE_IND VARCHAR;
V_RUN_VALUE_1 VARCHAR;
V_RUN_VALUE_2 VARCHAR;
V_RUN_VALUE_3 VARCHAR;
V_RUN_VALUE_4 VARCHAR;
V_EXTRACT_TYPE VARCHAR;
V_CUTOFF_DAY NUMBER;
V_ETL_CREAT_BY VARCHAR;

v_rn number;
v_EC_PART_A NUMBER;
V_BASE_PN_DP VARCHAR;
V_BASE_PN_AD VARCHAR;
V_TOS_CD_R VARCHAR;
v_TOS_GL_ACCT_CD VARCHAR;
v_TOS_CD_H VARCHAR;
v_TOS_CD_W VARCHAR;
V_BL_NO_PAY_IND_O VARCHAR;
V_BL_NO_PAY_IND_U VARCHAR;
V_TOS_CD_B4 VARCHAR;
V_TOS_CD_B5 VARCHAR;
V_ADJD_YES_NO_IND VARCHAR;
V_PRDCT VARCHAR;
V_RECEIPT_NUM NUMBER;


BEGIN

EXECUTE IMMEDIATE ''USE DATABASE ''||:DB_NAME; 

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_BATCH_OBJECT_START_TIME := (SELECT CURRENT_TIMESTAMP());



LET res1 RESULTSET := 
(

SELECT 

WH ,
BATCH_ID
  
FROM UTIL.ETL_BATCH_OBJECT_CONTROL
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
FETCH FIRST 1 ROW ONLY

)
;


LET C1 CURSOR FOR res1;
open C1;
FETCH C1 into  V_WH,V_BATCH_ID ;
close C1;


LET res2 RESULTSET := 

(

WITH PARAMETERS (OVERRIDE_IND, EXTRACT_DATE, START_DATE, STOP_DATE, RUN_VALUE_4, EXTRACT_TYPE, CUTOFF_DAY, ETL_CREAT_BY, RECEIPT_NUM) AS
(
  
SELECT * 
FROM  
(SELECT PARAMETER_NAME, PARAMETER_VALUE  FROM UTIL.ETL_OBJECT_PARAMETER_VALUE 
WHERE 1 = 1
AND APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
AND ACTIVE_FLG = ''Y''  
  
UNION ALL       

SELECT PARAMETER_NAME, PARAMETER_VALUE  FROM UTIL.ETL_GLOBAL_PARAMETER_VALUE WHERE PAR_GLOBAL_TYPE = ''PARGLOBAL_OPREPORTS'' AND ACTIVE_FLG = ''Y''
AND PARAMETER_NAME NOT IN  (
SELECT PARAMETER_NAME  FROM UTIL.ETL_OBJECT_PARAMETER_VALUE WHERE 1 = 1
AND APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
AND ACTIVE_FLG = ''Y''   ))
 
PIVOT(MAX(PARAMETER_VALUE) FOR PARAMETER_NAME IN (''OVERRIDE_IND'', ''EXTRACT_DATE'', ''START_DATE'', ''STOP_DATE'', ''RUN_VALUE_4'', ''EXTRACT_TYPE'', ''CUTOFF_DAY'', ''ETL_CREAT_BY'', ''RECEIPT_NUM'')) 

 
)  
SELECT * FROM PARAMETERS 
)  
  
;


LET C2 CURSOR FOR res2;
open C2;
FETCH C2 into  V_OVERRIDE_IND, V_RUN_VALUE_1, V_RUN_VALUE_2, V_RUN_VALUE_3, V_RUN_VALUE_4, V_EXTRACT_TYPE, V_CUTOFF_DAY, V_ETL_CREAT_BY, V_RECEIPT_NUM; 
close C2;




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:V_WH;
USE SCHEMA BDR_DM;	-------------------------------OAS ADD


INSERT INTO UTIL.ETL_BATCH_OBJECT_INCR_VALU (APPLICATION, WORKFLOW_NAME, OBJECT_NAME, INCR_COLUMN, INCR_COLUMN_VALUE )
SELECT * FROM (select :APPLICATION AS APPLICATION, :WORKFLOW_NAME AS WORKFLOW_NAME, :OBJECT_NAME AS OBJECT_NAME, ''ETL_LST_BTCH_ID'' AS INCR_COLUMN, -1 AS INCR_COLUMN_VALUE) A
WHERE NOT EXISTS (SELECT 1 FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU B WHERE B.APPLICATION = A.APPLICATION AND B.WORKFLOW_NAME = A.WORKFLOW_NAME AND B.OBJECT_NAME = A.OBJECT_NAME AND B.INCR_COLUMN = A.INCR_COLUMN)
;

V_ETL_LST_BTCH_ID :=(SELECT INCR_COLUMN_VALUE FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID'');

------------------------------------COMMENTED BY OAS---------------------------------------  
/*
CREATE OR REPLACE PACKAGE BODY DM.PKG_INGENIX_EXTRACT
IS
--
-- Purpose:  Main Procedure to Extract Claim Data, Pharmacy Claim Data, and
--           Provider Data for Ingenix
--
-- MODIFICATION HISTORY
-- Person      Date    Comments

-- ---------   ------  -------------------------------------------------------

PROCEDURE pr_driver_ms_extract(iv_Dummy IN VARCHAR2,
                               P_ToContinueStatus OUT VARCHAR2,
                               P_ErrorYNFlg OUT VARCHAR2,
                               P_ErrorStr OUT VARCHAR2)
   IS
      v_proc_name            VARCHAR2 (30)          := ''pr_driver_ms_extract'';
      v_sql                  VARCHAR2 (5000);
      v_extract_date         DATE;
     v_extract_key_low      NUMBER (8);
      v_extract_key_high     NUMBER (8);
      v_extract_type         VARCHAR2(50);
      v_cutoff_day           NUMBER;
      v_claim_file_name      VARCHAR2 (100);
      v_rx_claim_file_name   VARCHAR2 (100);
      v_member_file_name     VARCHAR2 (100);
      v_member_2_file_name   VARCHAR2 (100);
      v_run_date             DATE;
      v_override_ind         VARCHAR2(50);
      v_run_value_1          VARCHAR2(50);
      v_run_value_2          VARCHAR2(50);
      v_run_value_3          VARCHAR2(50);
      v_run_value_4          VARCHAR2(50);
      v_err_message          VARCHAR2(2000);
      v_fileexport_dateid     NUMBER(8);
      v_start_date     DATE;
      v_stop_date     DATE;




   BEGIN
    ---  EXECUTE IMMEDIATE ''ALTER SESSION SET hash_join_enabled = FALSE'';


      INSERT
    INTO
        ETL.ETL_DETAIL_LOAD_INFO
        (
            APPLICATION ,
            ETL_BATCH_ID,
            ETL_PROC_NAME ,
            ACTION ,
           STEP_INFO ,
            ROWS_AFFECTED ,
            ETL_DATETIME
        )
        VALUES
        (
            ''OPTUMHEALTHFEEDRPT'',
            NULL,
            v_proc_name,
            ''START'',
            ''MAIN PROCEDURE STARTS'',
            0,
            SYSTIMESTAMP
        );
COMMIT;

      BEGIN                                             
*/		------------------------------------COMMENTED BY OAS---------------------------------------  

 -- get job parameters
            ----- GET THE JOB PARAMETERS
			
----------------------OAS DELETE AS THE VALUES WILL BE FETCHED FROM OBJECT PARAMETER TABLE-----------------------------

/*     SELECT
        MAX(DECODE( METADATA_TYPE,''OVERRIDE_IND'',METADATA_VALUE)) AS OVERRIDE_IND ,
        MAX(DECODE( METADATA_TYPE,''EXTRACT_DATE'',METADATA_VALUE)) AS v_run_value_1,
        MAX(DECODE( METADATA_TYPE,''START_DATE'',METADATA_VALUE))   AS v_run_value_2,
        MAX(DECODE( METADATA_TYPE,''STOP_DATE'',METADATA_VALUE))    AS v_run_value_3 ,
        MAX(DECODE( METADATA_TYPE,''RUN_VALUE_4'',METADATA_VALUE))  AS v_run_value_4,
        MAX(DECODE( METADATA_TYPE,''EXTRACT_TYPE'',METADATA_VALUE))  AS v_extract_type,
        MAX(DECODE( METADATA_TYPE,''CUTOFF_DAY'',METADATA_VALUE))  AS v_cutoff_day

    INTO
        v_override_ind,
        v_run_value_1,
        v_run_value_2,
        v_run_value_3,
        v_run_value_4,
        v_extract_type,
        v_cutoff_day


    FROM
        ETL.ETL_APPLICATION_METADATA
    WHERE
        APPLICATION=''CLAIMS''
    AND METADATA_DESC=''OPTUMHEALTHFEED''; */	
	
----------------------OAS DELETE AS THE VALUES WILL BE FETCHED FROM OBJECT PARAMETER TABLE-----------------------------

		/* IF v_override_ind = ''Y''
         THEN
            v_extract_date :=LAST_DAY(ADD_MONTHS(TO_DATE(TO_CHAR(v_run_value_1),''YYYYMMDD''),-1));
         ELSE
            IF EXTRACT (DAY FROM SYSDATE) > v_cutoff_day
            THEN
               v_extract_date := LAST_DAY (SYSDATE);
            ELSE
               v_extract_date := LAST_DAY (ADD_MONTHS (SYSDATE, -1));
            END IF;
        END IF; */															----------------------------OAS DELETE
		
    v_extract_date := (SELECT 
							CASE WHEN :V_OVERRIDE_IND = ''Y'' THEN
									LAST_DAY(ADD_MONTHS(TO_DATE(TO_CHAR(:V_RUN_VALUE_1),''YYYYMMDD''),-1))
								WHEN EXTRACT (DAY FROM CURRENT_TIMESTAMP) > :V_CUTOFF_DAY THEN
									LAST_DAY (CURRENT_TIMESTAMP)
								ELSE
									LAST_DAY (ADD_MONTHS (CURRENT_TIMESTAMP, -1))
							END);												-------------------------OAS ADD

    v_extract_key_low :=
			TO_NUMBER (TO_CHAR (TRUNC (:v_extract_date, ''MM''), ''YYYYMMDD''));
    v_extract_key_high :=
            TO_NUMBER (TO_CHAR (LAST_DAY (:v_extract_date), ''YYYYMMDD''));


    IF (:V_RUN_VALUE_2 IS NOT NULL)
        THEN
           v_start_date := TRUNC (TO_DATE (TO_CHAR(:V_RUN_VALUE_2), ''YYYYMMDD''), ''MM'');
        ELSE
           v_start_date := TRUNC (ADD_MONTHS (:V_EXTRACT_DATE, -35), ''MM'');
    END IF;

    IF (:V_RUN_VALUE_3 IS NOT NULL)
        THEN
           v_stop_date := TRUNC(LAST_DAY (TO_DATE (TO_CHAR(:V_RUN_VALUE_3), ''YYYYMMDD'')), ''DD'');
        ELSE
           v_stop_date := TRUNC(LAST_DAY (:V_EXTRACT_DATE), ''DD'');
    END IF;
	
------------------------------------COMMENTED BY OAS---------------------------------------  
/*INSERT
INTO
    ETL.ETL_DETAIL_LOAD_INFO
    (
        APPLICATION ,
        ETL_BATCH_ID,
        ETL_PROC_NAME ,
        ACTION ,
        STEP_INFO ,
        ROWS_AFFECTED ,
       ETL_DATETIME
    )
    VALUES
    (
        ''OPTUMHEALTHFEED'',
        NULL,
        v_proc_name,
        ''Value of v_extract_date'',
        v_extract_date,
        0,
        SYSTIMESTAMP
    );
COMMIT;


INSERT
INTO
    ETL.ETL_DETAIL_LOAD_INFO
    (
        APPLICATION ,
        ETL_BATCH_ID,
        ETL_PROC_NAME ,
        ACTION ,
        STEP_INFO ,
        ROWS_AFFECTED ,
        ETL_DATETIME
    )
    VALUES
    (
        ''OPTUMHEALTHFEED'',
        NULL,
        v_proc_name,
        ''Value of v_extract_key_low'',
        v_extract_key_low,
        0,
        SYSTIMESTAMP
    );
COMMIT;


INSERT
INTO
    ETL.ETL_DETAIL_LOAD_INFO
    (
        APPLICATION ,
        ETL_BATCH_ID,
        ETL_PROC_NAME ,
        ACTION ,
        STEP_INFO ,
        ROWS_AFFECTED ,
        ETL_DATETIME
    )
    VALUES
    (
        ''OPTUMHEALTHFEED'',
        NULL,
        v_proc_name,
        ''Value of v_extract_key_high'',
        v_extract_key_high,
        0,
        SYSTIMESTAMP
    );
COMMIT;

INSERT
INTO
    ETL.ETL_DETAIL_LOAD_INFO
    (
        APPLICATION ,
        ETL_BATCH_ID,
        ETL_PROC_NAME ,
        ACTION ,
        STEP_INFO ,
        ROWS_AFFECTED ,
        ETL_DATETIME
    )
    VALUES
    (
        ''OPTUMHEALTHFEED'',
        NULL,
        v_proc_name,
        ''Value of v_extract_type'',
        v_extract_type,
        0,
        SYSTIMESTAMP
    );
COMMIT;


INSERT
INTO
    ETL.ETL_DETAIL_LOAD_INFO
    (
        APPLICATION ,
        ETL_BATCH_ID,
        ETL_PROC_NAME ,
        ACTION ,
        STEP_INFO ,
        ROWS_AFFECTED ,
        ETL_DATETIME
    )
    VALUES
    (
        ''OPTUMHEALTHFEED'',
        NULL,
        v_proc_name,
        ''Value of v_cutoff_day'',
        v_cutoff_day,
        0,
        SYSTIMESTAMP
    );
COMMIT;

INSERT
INTO
    ETL.ETL_DETAIL_LOAD_INFO
    (
        APPLICATION ,
        ETL_BATCH_ID,
        ETL_PROC_NAME ,
        ACTION ,
        STEP_INFO ,
        ROWS_AFFECTED ,
        ETL_DATETIME
    )
    VALUES
    (
        ''OPTUMHEALTHFEED'',
        NULL,
        v_proc_name,
        ''Value of v_cutoff_day'',
        v_cutoff_day,
        0,
        SYSTIMESTAMP
    );
COMMIT;

      END;

      BEGIN                       -- load member tables to drive claim extract
         DM.PKG_INGENIX_EXTRACT.pr_member_medsupp_insert;

         DM.PKG_INGENIX_EXTRACT.pr_member_data_medsupp_merge
                                                         (v_extract_key_low,
                                                          v_extract_key_high,
                                                          v_extract_type
                                                         );
         DM.PKG_INGENIX_EXTRACT.pr_member_accounts_medsupp_mrg
                                                          (v_extract_key_low,
                                                           v_extract_key_high,
                                                           v_extract_type
                                                          );
      END;

      BEGIN                                                -- extract from CLAIMS
         DM.PKG_INGENIX_EXTRACT.pr_extract_claims (v_extract_key_low,
                                                    v_extract_key_high,
                                                    v_extract_type,
                                                    v_extract_date
                                                   );

        DM.PKG_INGENIX_EXTRACT.pr_extract_claims_ocrs (v_extract_key_low,
                                                         v_extract_key_high,
                                                         v_extract_type,
                                                         v_extract_date
                                                        );

         DM.PKG_INGENIX_EXTRACT.pr_extract_rx_claims (v_extract_key_low,
                                                       v_extract_key_high,
                                                       v_extract_type,
                                                       v_extract_date
                                                      );
         DM.PKG_INGENIX_EXTRACT.pr_extract_rx_claims_ocrs
                                                          (v_extract_key_low,
                                                           v_extract_key_high,
                                                           v_extract_type,
                                                           v_extract_date
                                                          );




    ---------------CALL PROCEDURES TO LOAD FILE DATA INTO REPORT TABLES

            DM.PKG_INGENIX_EXTRACT.PR_LOADFILEDATA_MEMBER
                                                          (v_extract_key_low,
                                                           v_extract_key_high,
                                                           v_extract_type,
                                                           v_start_date,
                                                           v_stop_date
                                                           );

           DM.PKG_INGENIX_EXTRACT.pr_loadfiledata_claims
                                                          (
                                                           v_extract_key_low,
                                                           v_extract_key_high,
                                                           v_extract_type
                                                           );

           DM.PKG_INGENIX_EXTRACT.PR_LOADFILEDATA_RX_CLAIMS
                                                           (
                                                            v_extract_key_low,
                                                            v_extract_key_high,
                                                            v_extract_type
                                                            );
    END;


  BEGIN
     -----------UPDATE EXTRACT HIGH VALUE TO THE TABLE, WILL BE USEFUL FOR FILE GENERATION WITH THE EXTRACT DATE

         v_fileexport_dateid := TO_CHAR(TO_DATE(TO_NUMBER(:v_extract_key_high),''YYYYMMDD''),''YYYYMM'')  ;

                UPDATE ETL.ETL_APPLICATION_METADATA
                SET    METADATA_VALUE=v_fileexport_dateid
                WHERE APPLICATION = ''CLAIMS'' AND METADATA_DESC=''OPTUMHEALTHFEED'' AND METADATA_TYPE=''EXTRACTDATE_FORFILEEXP'' ;

                COMMIT;

                INSERT
        INTO
            ETL.ETL_DETAIL_LOAD_INFO
            (
                APPLICATION ,
                ETL_PROC_NAME ,
                ACTION ,
                STEP_INFO ,
                ROWS_AFFECTED ,
                ETL_DATETIME
            )
            VALUES
            (
                ''OPTUMHEALTHFEEDRPT'',
                v_proc_name,
                ''Value of EXTRACTDATE_FORFILEEXP'',
                v_fileexport_dateid,
                0,
                SYSTIMESTAMP
            );
COMMIT;

                ----------
  END;


      INSERT
        INTO
            ETL.ETL_DETAIL_LOAD_INFO
            (
                APPLICATION ,
                ETL_PROC_NAME ,
                ACTION ,
                STEP_INFO ,
                ROWS_AFFECTED ,
                ETL_DATETIME
            )
            VALUES
            (
                ''OPTUMHEALTHFEEDRPT'',
                v_proc_name,
                ''MAIN PROC ENDS'',
                ''Proc Execution Completed'',
                0,
                SYSTIMESTAMP
            );
COMMIT;


   EXCEPTION
      WHEN OTHERS
      THEN
          v_err_message :=SQLERRM;

INSERT
INTO
    ETL.ETL_DETAIL_LOAD_INFO
    (
        APPLICATION ,
        ETL_BATCH_ID,
        ETL_PROC_NAME ,
        ACTION ,
        STEP_INFO ,
        ROWS_AFFECTED ,
        ETL_DATETIME
    )
    VALUES
    (
        ''OPTUMHEALTHFEEDRPT'',
        NULL,
        v_proc_name,
        ''E'',
        v_err_message ,
        0,
        SYSTIMESTAMP   ----- pkg_cdw_ingenix_extract.pr_email_status (v_extract_date,v_extract_type,''ERROR'',v_proc_name || SQLERRM);

    );

    P_ErrorStr := ''ERROR: '' || SQLCODE || ''-'' || SQLERRM || ''-'' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE()|| Chr(10)||DBMS_UTILITY.FORMAT_ERROR_STACK();
      P_ToContinueStatus := ''N'';
      P_ErrorYNFlg := ''Y'';
      RAISE;

   END;


--------------------DM.PKG_INGENIX_EXTRACT.pr_member_medsupp_insert BEGINS--------------------

--
-- Purpose: load IGX_MEMBER_MEDSUPP
--
--
-- MODIFICATION HISTORY

-- ---------   ------  -------------------------------------------

 PROCEDURE pr_member_medsupp_insert
   IS
      v_sql             VARCHAR2 (3000);
      v_rows_inserted   NUMBER (10);
      v_run_date        DATE;
      v_proc_name       VARCHAR2 (30)   := ''pr_member_medsupp_insert'';
      v_err_message      VARCHAR2(2000);
   BEGIN


     INSERT
    INTO
        ETL.ETL_DETAIL_LOAD_INFO
        (
            APPLICATION ,
            ETL_BATCH_ID,
            ETL_PROC_NAME ,
            ACTION ,
            STEP_INFO ,
            ROWS_AFFECTED ,
            ETL_DATETIME
        )
        VALUES
        (
            ''OPTUMHEALTHFEEDRPT'',
            NULL,
            v_proc_name,
            ''START'',
            ''PROCEDURE STARTS'',
            0,
            SYSTIMESTAMP
        );
COMMIT;

      BEGIN                      
*/    
		---------------------------------------COMMENTED BY OAS------------------------------------------
	  
  -- truncate IGX_MEMBER_MEDSUPP
    
V_STEP_NAME    := ''TRUNCATE - RPT_IGX_MEMBER_MEDSUPP'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

    v_sql := ''TRUNCATE TABLE BDR_DM.RPT_IGX_MEMBER_MEDSUPP'';

    EXECUTE IMMEDIATE :v_sql;

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );


    /*     DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''RPT_IGX_MEMBER_MEDSUPP'');		


      END;

      BEGIN    */	----------------------OAS DELETE	
    
V_STEP_NAME    := ''INSERT - RPT_IGX_MEMBER_MEDSUPP'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

	  -- insert MEDSUPP
         INSERT     /*+ ENABLE_PARALLEL_DML APPEND */ INTO BDR_DM.RPT_IGX_MEMBER_MEDSUPP
                     (account_number, medicare_claim_num, last_name,
                      first_name, middle_name, gender_cd, date_of_birth,
                      address_line_1, address_line_2, city, state_cd, zip_cd,
                     daytime_phone_num, evening_phone_num, plan_cd,
                      plan_category_desc, insured_plan_effective_date,
                      insured_plan_termination_date, individual_id,
                      date_of_death, country_cd, country_name,
                      insured_plan_id, plan_display_cd, plan_category_id,
                      plan_type_id, plan_type_desc, pharmacy_flag,
                      premium_due_amt, extract_type, created_by,
                      creation_date, last_modified_by, last_modified_date)
            SELECT /*+ PARALLEL(8) */ lmm.account_number, lmm.medicare_claim_num, lmm.last_name,
                   lmm.first_name, lmm.middle_name, lmm.gender_cd,
                   lmm.date_of_birth, lmm.address_line_1, lmm.address_line_2,
                   lmm.city, lmm.state_cd, lmm.zip_cd, lmm.daytime_phone_num,
                   lmm.evening_phone_num, lmm.plan_cd,
                   lmm.plan_category_desc, lmm.insured_plan_effective_date,
                   NVL
                      (lmm.insured_plan_termination_date,
                       99991231
                      ) AS insured_plan_termination_date,
                   lmm.individual_id, lmm.date_of_death, lmm.country_cd,
                   lmm.country_name, lmm.insured_plan_id,
                   lmm.plan_display_cd, lmm.plan_category_id,
                   lmm.plan_type_id, lmm.plan_type_desc, lmm.pharmacy_flag,
                   lmm.premium_due_amt, lmm.extract_type, /* USER */:V_ETL_CREAT_BY AS created_by,
                   CURRENT_TIMESTAMP AS creation_date, /* USER */:V_ETL_CREAT_BY AS last_modified_by,
                   CURRENT_TIMESTAMP AS last_modified_date
              FROM BDR_DM.WRK_IGX_MEMBER_MEDSUPP lmm
              WHERE lmm.EXTRACT_TYPE=''MEDSUPP'';
		     	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

------------------------------------COMMENTED BY OAS---------------------------------------  
  /*       v_rows_inserted := SQL%ROWCOUNT;
         COMMIT;

  INSERT
        INTO
            ETL.ETL_DETAIL_LOAD_INFO
            (
                APPLICATION ,
                ETL_PROC_NAME ,
                ACTION ,
                STEP_INFO ,
                ROWS_AFFECTED ,
                ETL_DATETIME
            )
            VALUES
            (
                ''OPTUMHEALTHFEEDRPT'',
                v_proc_name,
                ''INSERT'',
                ''ROWS AFFECTED_MeddSupp'',
                v_rows_inserted,
                SYSTIMESTAMP
            );
COMMIT;

DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''RPT_IGX_MEMBER_MEDSUPP'');

      END;

      BEGIN   	*/	
	  ------------------------------------COMMENTED BY OAS---------------------------------------  
    
V_STEP_NAME    := ''INSERT - RPT_IGX_MEMBER_MEDSUPP'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

	  -- insert MEDSUPP RIDER
         INSERT /*+ ENABLE_PARALLEL_DML APPEND */ INTO BDR_DM.RPT_IGX_MEMBER_MEDSUPP
                 (account_number, medicare_claim_num, last_name,
                  first_name, middle_name, gender_cd, date_of_birth,
                  address_line_1, address_line_2, city, state_cd, zip_cd,
                  daytime_phone_num, evening_phone_num, plan_cd,
                  plan_category_desc, insured_plan_effective_date,
                  insured_plan_termination_date, individual_id,
                  date_of_death, country_cd, country_name,
                  insured_plan_id, plan_display_cd, plan_category_id,
                  plan_type_id, plan_type_desc, pharmacy_flag,
                  premium_due_amt, extract_type, created_by,
                  creation_date, last_modified_by, last_modified_date)
            SELECT /*+ PARALLEL(8) */ lmr.account_number, lmr.medicare_claim_num, lmr.last_name,
                lmr.first_name, lmr.middle_name, lmr.gender_cd,
                lmr.date_of_birth, lmr.address_line_1, lmr.address_line_2,
                lmr.city, lmr.state_cd, lmr.zip_cd, lmr.daytime_phone_num,
                lmr.evening_phone_num, lmr.plan_cd,
                lmr.plan_category_desc, lmr.insured_plan_effective_date,
                NVL
                   (lmr.insured_plan_termination_date,
                    99991231
                   ) AS insured_plan_termination_date,
                lmr.individual_id, lmr.date_of_death, lmr.country_cd,
                lmr.country_name, lmr.insured_plan_id,
                lmr.plan_display_cd, lmr.plan_category_id,
                lmr.plan_type_id, lmr.plan_type_desc, lmr.pharmacy_flag,
                lmr.premium_due_amt, lmr.extract_type, /*USER*/ :V_ETL_CREAT_BY AS created_by,
                CURRENT_TIMESTAMP AS creation_date, /*USER*/ :V_ETL_CREAT_BY AS last_modified_by,
                CURRENT_TIMESTAMP AS last_modified_date
                FROM BDR_DM.WRK_IGX_MEMBER_MEDSUPP lmr
                join SRC_COMPAS_D.PLAN cp on cp.PLAN_CD = lmr.PLAN_CD
                join SRC_COMPAS_D.PLAN_TYPE cpt on cpt.PLAN_TYPE_ID = cp.PLAN_TYPE_ID
                join BDR_CONF.D_PLN_BEN_MOD pbm on pbm.COMPAS_PLN_CD = cp.plan_cd
                where pbm.PRDCT_SUB_GRP = ''Med Supp Rider''
                AND lmr.EXTRACT_TYPE = ''RIDER'';                           -- Med Supp Rider
		     	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );


------------------------------------COMMENTED BY OAS---------------------------------------  
/*
         v_rows_inserted := SQL%ROWCOUNT;
         COMMIT;
  INSERT
        INTO
            ETL.ETL_DETAIL_LOAD_INFO
            (
                APPLICATION ,
                ETL_PROC_NAME ,
                ACTION ,
                STEP_INFO ,
                ROWS_AFFECTED ,
                ETL_DATETIME
            )
            VALUES
            (
                ''OPTUMHEALTHFEEDRPT'',
                v_proc_name,
                ''INSERT'',
                ''ROWS AFFECTED_Rider'',
                v_rows_inserted,
                SYSTIMESTAMP
            );
COMMIT;

DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''RPT_IGX_MEMBER_MEDSUPP'');


      END;


  INSERT
        INTO
            ETL.ETL_DETAIL_LOAD_INFO
            (
                APPLICATION ,
                ETL_PROC_NAME ,
                ACTION ,
                STEP_INFO ,
                ROWS_AFFECTED ,
                ETL_DATETIME
            )
            VALUES
            (
                ''OPTUMHEALTHFEEDRPT'',
                v_proc_name,
                ''END'',
                ''Proc Ends'',
                0,
                SYSTIMESTAMP
            );
COMMIT;

   EXCEPTION
      WHEN OTHERS
      THEN
            v_err_message :=SQLERRM;

INSERT
INTO
    ETL.ETL_DETAIL_LOAD_INFO
    (
        APPLICATION ,
        ETL_BATCH_ID,
        ETL_PROC_NAME ,
        ACTION ,
        STEP_INFO ,
        ROWS_AFFECTED ,
        ETL_DATETIME
    )
    VALUES
    (
        ''OPTUMHEALTHFEEDRPT'',
        NULL,
        v_proc_name,
        ''E'',
        v_err_message ,
        0,
        SYSTIMESTAMP
    );

DBMS_OUTPUT.PUT_LINE(''ERROR: '' || SQLCODE || ''-'' || SQLERRM || ''-'' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE()|| Chr(10)||DBMS_UTILITY.FORMAT_ERROR_STACK());
    RAISE;
   END;
    
--------------------DM.PKG_INGENIX_EXTRACT.pr_member_medsupp_insert ENDS--------------------  


--------------------DM.PKG_INGENIX_EXTRACT.pr_member_data_medsupp_merge BEGINS--------------------
 
--
-- Purpose: load dm.RPT_IGX_MEMBER_DATA_MEDSUPP  from external table
--
--

-- ---------   ------  -------------------------------------------
    PROCEDURE pr_member_data_medsupp_merge (
      p_extract_key_low    IN   NUMBER,
      p_extract_key_high   IN   NUMBER,
      p_extract_type       IN   VARCHAR2
   )
   IS
      v_sql                VARCHAR2 (3000);
      v_deleted_count      NUMBER                                        := 0;
     v_merge_count        NUMBER                                        := 0;
      v_insert_count       NUMBER                                        := 0;
      v_update_count       NUMBER                                        := 0;
      v_run_date           DATE;
      v_proc_name          VARCHAR2 (30)    := ''pr_member_data_medsupp_merge'';
      v_out_file_name      VARCHAR2 (256)
                                        := ''IGX_MEMBER_DATA_MEDSUPP_DELETED_'';
      v_out_file_dir       VARCHAR2 (256)                   := ''DAT_FILE_DIR'';
      v_output_record      VARCHAR2 (1000);
      v_output_file        UTL_FILE.file_type;
      v_extract_key_low    NUMBER (8, 0);
      v_extract_key_high   NUMBER (8, 0);
      v_extract_type       varchar2(50);
      v_err_message        varchar2(2000);
   BEGIN


     INSERT
    INTO
        ETL.ETL_DETAIL_LOAD_INFO
        (
            APPLICATION ,
            ETL_BATCH_ID,
            ETL_PROC_NAME ,
            ACTION ,
            STEP_INFO ,
            ROWS_AFFECTED ,
            ETL_DATETIME
        )
        VALUES
        (
            ''OPTUMHEALTHFEEDRPT'',
            NULL,
            v_proc_name,
            ''START'',
            ''PROCEDURE STARTS'',
            0,
            SYSTIMESTAMP
        );
COMMIT;

      BEGIN
         v_extract_key_low := p_extract_key_low;
         v_extract_key_high := p_extract_key_high;
         v_extract_type := p_extract_type;
*/	
------------------------------------COMMENTED BY OAS---------------------------------------  

            ---- Truncate duplicate records table
    
V_STEP_NAME    := ''TRUNCATE - RPT_DUPIGX_DATA_MEDDSUPP'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

         EXECUTE IMMEDIATE ''TRUNCATE TABLE BDR_DM.RPT_DUPIGX_DATA_MEDDSUPP'';

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

/*         DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''RPT_DUPIGX_DATA_MEDDSUPP'');

      END;

      BEGIN	*/	
	  ------------------------------------COMMENTED BY OAS---------------------------------------  

    
V_STEP_NAME    := ''INSERT - RPT_DUPIGX_DATA_MEDDSUPP'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

               ---------- Report duplciate records and report
           insert /*+ ENABLE_PARALLEL_DML APPEND */ into BDR_DM.RPT_DUPIGX_DATA_MEDDSUPP(ACCOUNT_NUMBER)
         SELECT /*+ PARALLEL(8) */  q1.account_number
                         FROM (SELECT DISTINCT imm.individual_id,
                                               imm.account_number
                                          FROM BDR_DM.RPT_IGX_MEMBER_MEDSUPP imm
                               UNION
                               SELECT imdm.individual_id, imdm.account_number
                                 FROM BDR_DM.RPT_IGX_MEMBER_DATA_MEDSUPP imdm) q1
                     GROUP BY q1.account_number
                       HAVING COUNT (*) > 1 ;
                     --  COMMIT;
		     	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

    
	
V_STEP_NAME    := ''DELETE - RPT_IGX_MEMBER_DATA_MEDSUPP'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

            DELETE FROM BDR_DM.RPT_IGX_MEMBER_DATA_MEDSUPP imdm
                  WHERE imdm.account_number IN ( SELECT account_number FROM BDR_DM.RPT_DUPIGX_DATA_MEDDSUPP );

		     	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_DELETED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );


------------------------------------COMMENTED BY OAS---------------------------------------  
 /*           v_deleted_count :=  SQL%ROWCOUNT;

            COMMIT;

         DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''RPT_IGX_MEMBER_DATA_MEDSUPP'');

     INSERT
    INTO
        ETL.ETL_DETAIL_LOAD_INFO
        (
            APPLICATION ,
            ETL_BATCH_ID,
            ETL_PROC_NAME ,
            ACTION ,
            STEP_INFO ,
            ROWS_AFFECTED ,
            ETL_DATETIME
        )
        VALUES
       (
           ''OPTUMHEALTHFEEDRPT'',
            NULL,
            v_proc_name,
            ''DELETE'',
            ''Value of DELETED count'',
            v_deleted_count,
            SYSTIMESTAMP
        );
COMMIT;

      END;

      BEGIN                                             -- get insert count
	  
         SELECT COUNT (*)
           INTO v_insert_count
           FROM (SELECT   imm.individual_id, imm.account_number,
                          imm.date_of_birth, imm.gender_cd,
                          imm.medicare_claim_num, imm.extract_type
                     FROM BDR_DM.RPT_IGX_MEMBER_MEDSUPP imm
                 GROUP BY imm.individual_id,
                          imm.account_number,
                          imm.date_of_birth,
                          imm.gender_cd,
                          imm.medicare_claim_num,
                          imm.extract_type) q1
          WHERE NOT EXISTS (
                   SELECT 1
                     FROM BDR_DM.RPT_IGX_MEMBER_DATA_MEDSUPP imdm
                    WHERE q1.individual_id = imdm.individual_id
                      AND q1.extract_type = imdm.extract_type);						------OAS DELETE  -- JUST TO RECORD THE INSERT COUNT IN ETL_DETAIL_LOAD_INFO


     INSERT
    INTO
        ETL.ETL_DETAIL_LOAD_INFO
        (
            APPLICATION ,
            ETL_BATCH_ID,
            ETL_PROC_NAME ,
            ACTION ,
            STEP_INFO ,
            ROWS_AFFECTED ,
            ETL_DATETIME
        )
        VALUES
        (
            ''OPTUMHEALTHFEEDRPT'',
            NULL,
            v_proc_name,
            ''INSERT'',
            ''Value of insert count'',
            v_insert_count,
            SYSTIMESTAMP
        );
COMMIT;


      END;

      BEGIN                                                -- get update count
         SELECT COUNT (*)
           INTO v_update_count
           FROM (SELECT   imm.individual_id, imm.account_number,
                          imm.date_of_birth, imm.gender_cd,
                          imm.medicare_claim_num, imm.extract_type
                     FROM BDR_DM.RPT_IGX_MEMBER_MEDSUPP imm
                 GROUP BY imm.individual_id,
                          imm.account_number,
                          imm.date_of_birth,
                          imm.gender_cd,
                          imm.medicare_claim_num,
                          imm.extract_type) q1
          WHERE EXISTS (
                   SELECT 1
                     FROM BDR_DM.RPT_IGX_MEMBER_DATA_MEDSUPP imdm
                    WHERE q1.individual_id = imdm.individual_id
                      AND q1.extract_type = imdm.extract_type);		------OAS DELETE  -- JUST TO RECORD THE UPDATE COUNT IN ETL_DETAIL_LOAD_INFO

    INSERT
    INTO
        ETL.ETL_DETAIL_LOAD_INFO
        (
            APPLICATION ,
            ETL_BATCH_ID,
            ETL_PROC_NAME ,
            ACTION ,
            STEP_INFO ,
            ROWS_AFFECTED ,
            ETL_DATETIME
        )
        VALUES
        (
            ''OPTUMHEALTHFEEDRPT'',
            NULL,
            v_proc_name,
            ''UPDATE'',
            ''Value of update count'',
            v_update_count,
            SYSTIMESTAMP
        );
COMMIT;



      END;

      BEGIN   */	
	  ------------------------------------COMMENTED BY OAS---------------------------------------              

	  -- merge  into DM.RPT_IGX_MEMBER_DATA_MEDSUPP
	      
V_STEP_NAME    := ''MERGE - RPT_IGX_MEMBER_DATA_MEDSUPP'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

         MERGE /*+ ENABLE_PARALLEL_DML */ INTO BDR_DM.RPT_IGX_MEMBER_DATA_MEDSUPP imdm
            USING (SELECT /*+ parallel(8) */  imm.individual_id, imm.account_number,
                            imm.date_of_birth, imm.gender_cd,
                            imm.medicare_claim_num, imm.extract_type
                       FROM BDR_DM.RPT_IGX_MEMBER_MEDSUPP imm
                   GROUP BY imm.individual_id,
                            imm.account_number,
                            imm.date_of_birth,
                            imm.gender_cd,
                            imm.medicare_claim_num,
                            imm.extract_type) q1
            ON (    imdm.individual_id = q1.individual_id
                AND imdm.extract_type = q1.extract_type)
            WHEN MATCHED THEN
               UPDATE
                  SET imdm.account_number = q1.account_number,
                      imdm.date_of_birth = q1.date_of_birth,
                      imdm.gender_cd = q1.gender_cd,
                      imdm.medicare_claim_num = q1.medicare_claim_num
            WHEN NOT MATCHED THEN
               INSERT (individual_id, account_number, date_of_birth,
                       gender_cd, medicare_claim_num, extract_type,
                       created_by, creation_date, last_modified_by,
                       last_modified_date)
               VALUES (q1.individual_id, q1.account_number, q1.date_of_birth,
                       q1.gender_cd, q1.medicare_claim_num, q1.extract_type,
                       --USER, SYSDATE, USER, SYSDATE);									-----------------------------------OAS DELETE
					   :V_ETL_CREAT_BY, CURRENT_TIMESTAMP, :V_ETL_CREAT_BY, CURRENT_TIMESTAMP);		-------------------------------OAS ADD
					   		     	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

V_ROWS_UPDATED := (SELECT $2 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

------------------------------------COMMENTED BY OAS---------------------------------------  
/*
         v_merge_count := SQL%ROWCOUNT;
         COMMIT;


         INSERT
    INTO
        ETL.ETL_DETAIL_LOAD_INFO
        (
            APPLICATION ,
           ETL_BATCH_ID,
            ETL_PROC_NAME ,
            ACTION ,
            STEP_INFO ,
            ROWS_AFFECTED ,
            ETL_DATETIME
        )
        VALUES
        (
            ''OPTUMHEALTHFEEDRPT'',
            NULL,
            v_proc_name,
            ''MERGE'',
            ''Value of merge count'',
            v_merge_count,
            SYSTIMESTAMP
        );
COMMIT;

      END;

      BEGIN                                                         -- analyze

      DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''RPT_IGX_MEMBER_DATA_MEDSUPP'');

      END;

      INSERT
        INTO
            ETL.ETL_DETAIL_LOAD_INFO
            (
                APPLICATION ,
                ETL_PROC_NAME ,
                ACTION ,
                STEP_INFO ,
                ROWS_AFFECTED ,
                ETL_DATETIME
            )
            VALUES
            (
                ''OPTUMHEALTHFEEDRPT'',
                v_proc_name,
                ''END'',
                ''Proc Ends'',
               0,
                SYSTIMESTAMP
            );
COMMIT;

   EXCEPTION
      WHEN OTHERS
      THEN
        v_err_message :=SQLERRM;

INSERT
INTO
    ETL.ETL_DETAIL_LOAD_INFO
    (
        APPLICATION ,
        ETL_BATCH_ID,
        ETL_PROC_NAME ,
        ACTION ,
        STEP_INFO ,
        ROWS_AFFECTED ,
        ETL_DATETIME
    )
    VALUES
    (
        ''OPTUMHEALTHFEEDRPT'',
        NULL,
        v_proc_name,
        ''E'',
        v_err_message ,
        0,
        SYSTIMESTAMP
    );


    DBMS_OUTPUT.PUT_LINE(''ERROR: '' || SQLCODE || ''-'' || SQLERRM || ''-'' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE()|| Chr(10)||DBMS_UTILITY.FORMAT_ERROR_STACK());

    RAISE;


   END;

--------------------DM.PKG_INGENIX_EXTRACT.pr_member_data_medsupp_merge ENDS--------------------


--------------------DM.PKG_INGENIX_EXTRACT.pr_member_accounts_medsupp_mrg BEGINS--------------------

--
-- Purpose: load DM.RPT_IGX_MEMBER_ACCTS_MEDSUPP
--
--

--  -------------------------------------------
     PROCEDURE pr_member_accounts_medsupp_mrg (
      p_extract_key_low    IN   NUMBER,
      p_extract_key_high   IN   NUMBER,
      p_extract_type       IN   VARCHAR2
   )
   IS
      v_sql                VARCHAR2 (3000);
      v_deleted_count      NUMBER                                        := 0;
     v_merge_count        NUMBER                                        := 0;
      v_insert_count       NUMBER                                        := 0;
      v_update_count       NUMBER                                        := 0;
      v_run_date           DATE;
      v_proc_name          VARCHAR2 (30)  := ''pr_member_accounts_medsupp_mrg'';
      v_out_file_name      VARCHAR2 (256)
                                    := ''IGX_MEMBER_ACCOUNTS_MEDSUPP_DELETED_'';
      v_out_file_dir       VARCHAR2 (256)                   := ''DAT_FILE_DIR'';
      v_output_record      VARCHAR2 (1000);
      v_output_file        UTL_FILE.file_type;
      v_extract_key_low    NUMBER (8, 0);
      v_extract_key_high   NUMBER (8, 0);
      v_extract_type       VARCHAR2(50);
      v_err_message        VARCHAR2(2000);
   BEGIN


     INSERT
    INTO
        ETL.ETL_DETAIL_LOAD_INFO
        (
            APPLICATION ,
            ETL_BATCH_ID,
            ETL_PROC_NAME ,
            ACTION ,
            STEP_INFO ,
            ROWS_AFFECTED ,
            ETL_DATETIME
        )
        VALUES
        (
            ''OPTUMHEALTHFEEDRPT'',
            NULL,
            v_proc_name,
            ''START'',
            ''PROCEDURE STARTS'',
            0,
            SYSTIMESTAMP
        );
COMMIT;


      BEGIN
         v_extract_key_low := p_extract_key_low;
         v_extract_key_high := p_extract_key_high;
         v_extract_type := p_extract_type;	*/	
		 ------------------------------------COMMENTED BY OAS---------------------------------------  

            ---- Truncate duplicate records table
    
V_STEP_NAME    := ''TRUNCATE - RPT_DUPIGX_ACCTS_MEDDSUPP'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

         EXECUTE IMMEDIATE ''TRUNCATE TABLE BDR_DM.RPT_DUPIGX_ACCTS_MEDDSUPP'';

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );


 /*     END;

      BEGIN           */	-----------------------------------OAS DELETE                    

	  -- delete duplicate rows and report
    
V_STEP_NAME    := ''INSERT - RPT_DUPIGX_ACCTS_MEDDSUPP'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

       INSERT /*+ ENABLE_PARALLEL_DML APPEND */ INTO BDR_DM.RPT_DUPIGX_ACCTS_MEDDSUPP (account_number)
        SELECT   q1.account_number
                 FROM (SELECT /*+ PARALLEL(8) */ DISTINCT imm.individual_id, imm.account_number
                                  FROM BDR_DM.RPT_IGX_MEMBER_MEDSUPP imm
                       UNION
                       SELECT imam.individual_id, imam.account_number
                         FROM BDR_DM.RPT_IGX_MEMBER_ACCTS_MEDSUPP imam) q1
             GROUP BY q1.account_number
               HAVING COUNT (*) > 1;

             --  COMMIT;
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

    
	
V_STEP_NAME    := ''DELETE - RPT_IGX_MEMBER_ACCTS_MEDSUPP'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

            DELETE FROM BDR_DM.RPT_IGX_MEMBER_ACCTS_MEDSUPP imam
                  WHERE imam.account_number IN( SELECT account_number FROM BDR_DM.RPT_DUPIGX_ACCTS_MEDDSUPP);
				  		     	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_DELETED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

------------------------------------COMMENTED BY OAS---------------------------------------  
/*
            v_deleted_count := SQL%ROWCOUNT;
            COMMIT;
                                                                       -- analyze


      DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''RPT_IGX_MEMBER_ACCTS_MEDSUPP'');

     INSERT
    INTO
        ETL.ETL_DETAIL_LOAD_INFO
        (
            APPLICATION ,
            ETL_BATCH_ID,
            ETL_PROC_NAME ,
            ACTION ,
            STEP_INFO ,
            ROWS_AFFECTED ,
            ETL_DATETIME
        )
        VALUES
        (
            ''OPTUMHEALTHFEEDRPT'',
            NULL,
            v_proc_name,
            ''DELETE'',
            ''Value of DELETED count'',
            v_deleted_count,
            SYSTIMESTAMP
        );
COMMIT;

      END;

      BEGIN                                             -- get insert count
         SELECT COUNT (*)
           INTO v_insert_count
           FROM (SELECT   imm.individual_id, imm.account_number,
                          imm.extract_type
                     FROM BDR_DM.RPT_IGX_MEMBER_MEDSUPP imm
                 GROUP BY imm.individual_id,
                          imm.account_number,
                         imm.extract_type) q1
          WHERE NOT EXISTS (
                   SELECT 1
                     FROM BDR_DM.RPT_IGX_MEMBER_ACCTS_MEDSUPP imam
                    WHERE q1.individual_id = imam.individual_id
                      AND q1.extract_type = imam.extract_type);	------OAS DELETE  -- JUST TO RECORD THE INSERT COUNT IN ETL_DETAIL_LOAD_INFO

     INSERT
    INTO
        ETL.ETL_DETAIL_LOAD_INFO
        (
            APPLICATION ,
            ETL_BATCH_ID,
            ETL_PROC_NAME ,
            ACTION ,
            STEP_INFO ,
            ROWS_AFFECTED ,
            ETL_DATETIME
        )
        VALUES
        (
            ''OPTUMHEALTHFEEDRPT'',
            NULL,
            v_proc_name,
            ''INSERT'',
            ''Value of insert count'',
            v_insert_count,
            SYSTIMESTAMP
        );
COMMIT;


      END;

      BEGIN                                               -- get update count
         SELECT COUNT (*)
           INTO v_update_count
           FROM (SELECT   imm.individual_id, imm.account_number,
                         imm.extract_type
                     FROM BDR_DM.RPT_IGX_MEMBER_MEDSUPP imm
                 GROUP BY imm.individual_id,
                          imm.account_number,
                          imm.extract_type) q1
          WHERE EXISTS (
                   SELECT 1
                     FROM BDR_DM.RPT_IGX_MEMBER_ACCTS_MEDSUPP imam
                    WHERE q1.individual_id = imam.individual_id
                      AND q1.extract_type = imam.extract_type);	------OAS DELETE  -- JUST TO RECORD THE UPDATE COUNT IN ETL_DETAIL_LOAD_INFO

        INSERT
    INTO
        ETL.ETL_DETAIL_LOAD_INFO
        (
            APPLICATION ,
            ETL_BATCH_ID,
            ETL_PROC_NAME ,
            ACTION ,
            STEP_INFO ,
            ROWS_AFFECTED ,
            ETL_DATETIME
        )
        VALUES
        (
            ''OPTUMHEALTHFEEDRPT'',
            NULL,
            v_proc_name,
            ''UPDATE'',
            ''Value of update count'',
            v_update_count,
            SYSTIMESTAMP
        );
COMMIT;


      END;

      BEGIN      */	
	  ------------------------------------COMMENTED BY OAS---------------------------------------         

	  -- merge  into DM.RPT_IGX_MEMBER_ACCTS_MEDSUPP
	      
V_STEP_NAME    := ''MERGE - RPT_IGX_MEMBER_ACCTS_MEDSUPP'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

         MERGE /*+ ENABLE_PARALLEL_DML */ INTO BDR_DM.RPT_IGX_MEMBER_ACCTS_MEDSUPP imam
            USING (SELECT /*+ PARALLEL(8) */  imm.individual_id, imm.account_number,
                            imm.extract_type
                       FROM BDR_DM.RPT_IGX_MEMBER_MEDSUPP imm
                   GROUP BY imm.individual_id,
                            imm.account_number,
                            imm.extract_type) q1
            ON (    imam.individual_id = q1.individual_id
                AND imam.extract_type = q1.extract_type)
            WHEN MATCHED THEN
               UPDATE
                  SET imam.account_number = q1.account_number
            WHEN NOT MATCHED THEN
               INSERT (individual_id, account_number, extract_type,
                       created_by, creation_date, last_modified_by,
                       last_modified_date)
               VALUES (q1.individual_id, q1.account_number, q1.extract_type,
                      -- USER, SYSDATE, USER, SYSDATE);
					  :V_ETL_CREAT_BY, CURRENT_TIMESTAMP, :V_ETL_CREAT_BY, CURRENT_TIMESTAMP);
	    	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT $1 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

V_ROWS_UPDATED := (SELECT $2 FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );
				  
	------------------------------------COMMENTED BY OAS---------------------------------------  
    /*     v_merge_count := SQL%ROWCOUNT;
         COMMIT;

         INSERT
    INTO
        ETL.ETL_DETAIL_LOAD_INFO
        (
            APPLICATION ,
            ETL_BATCH_ID,
            ETL_PROC_NAME ,
            ACTION ,
            STEP_INFO ,
            ROWS_AFFECTED ,
            ETL_DATETIME
        )
        VALUES
        (
            ''OPTUMHEALTHFEEDRPT'',
            NULL,
            v_proc_name,
            ''MERGE'',
            ''Value of merge count'',
            v_merge_count,
            SYSTIMESTAMP
        );
COMMIT;

      END;

      BEGIN                                                         -- analyze

        DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''RPT_IGX_MEMBER_ACCTS_MEDSUPP'');
      END;
INSERT
        INTO
            ETL.ETL_DETAIL_LOAD_INFO
            (
                APPLICATION ,
                ETL_PROC_NAME ,
                ACTION ,
                STEP_INFO ,
                ROWS_AFFECTED ,
                ETL_DATETIME
            )
            VALUES
            (
                ''OPTUMHEALTHFEEDRPT'',
                v_proc_name,
                ''END'',
                ''Proc Ends'',
                0,
                SYSTIMESTAMP
            );
COMMIT;

   EXCEPTION
      WHEN OTHERS
      THEN
        v_err_message :=SQLERRM;

INSERT
INTO
    ETL.ETL_DETAIL_LOAD_INFO
    (
        APPLICATION ,
        ETL_BATCH_ID,
        ETL_PROC_NAME ,
        ACTION ,
        STEP_INFO ,
        ROWS_AFFECTED ,
        ETL_DATETIME
    )
    VALUES
    (
        ''OPTUMHEALTHFEEDRPT'',
        NULL,
        v_proc_name,
        ''E'',
        v_err_message ,
        0,
        SYSTIMESTAMP
    );

DBMS_OUTPUT.PUT_LINE(''ERROR: '' || SQLCODE || ''-'' || SQLERRM || ''-'' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE()|| Chr(10)||DBMS_UTILITY.FORMAT_ERROR_STACK());
    RAISE;
        --- UTL_FILE.fclose (v_output_file);

   END;

--------------------DM.PKG_INGENIX_EXTRACT.pr_member_accounts_medsupp_mrg ENDS--------------------


--------------------DM.PKG_INGENIX_EXTRACT.pr_extract_claims BEGINS--------------------

--
-- Purpose: Extract Claims in ISDW
--
-- MODIFICATION HISTORY
-- Person      Date    Comments

-- ---------   ------  -------------------------------------------
   PROCEDURE pr_extract_claims (
      p_extract_key_low    IN   NUMBER,
      p_extract_key_high   IN   NUMBER,
      p_extract_type       IN   VARCHAR2,
      p_extract_date       IN   DATE
   )
   IS
      v_sql                VARCHAR2 (5000);
      v_rows_inserted      NUMBER;
      v_run_date           DATE;
      v_proc_name          VARCHAR2 (30)               := ''pr_extract_claims'';
      v_extract_key_low    NUMBER (8, 0);
      v_extract_key_high   NUMBER (8, 0);
      v_extract_date       DATE;
      v_extract_type       VARCHAR2(20);
      v_err_message        VARCHAR2(2000);
      V_BL_NO_PAY_IND_O VARCHAR2 (1);
      V_BL_NO_PAY_IND_U VARCHAR2 (1);
      V_TOS_CD_B4 VARCHAR2(2);
      V_TOS_CD_B5 VARCHAR2(2);
      V_ADJD_YES_NO_IND VARCHAR2(1);
      V_PRDCT VARCHAR2 (10);  */	
	  ------------------------------------COMMENTED BY OAS---------------------------------------   
      v_rn :=1;
      v_EC_PART_A :=0;
      V_BASE_PN_DP := ''DP'';
      V_BASE_PN_AD := ''AD'';
      V_TOS_CD_R := ''R'';
      v_TOS_GL_ACCT_CD := ''50300'';
      v_TOS_CD_H := ''H'';
      v_TOS_CD_W := ''W'';
	  
  	------------------------------------COMMENTED BY OAS---------------------------------------   
/*   BEGIN

      INSERT
    INTO
        ETL.ETL_DETAIL_LOAD_INFO
        (
            APPLICATION ,
            ETL_BATCH_ID,
            ETL_PROC_NAME ,
            ACTION ,
            STEP_INFO ,
            ROWS_AFFECTED ,
            ETL_DATETIME
        )
        VALUES
        (
            ''OPTUMHEALTHFEEDRPT'',
            NULL,
            v_proc_name,
            ''START'',
            ''PROCEDURE STARTS'',
            0,
            SYSTIMESTAMP
        );
COMMIT;

      BEGIN
         v_extract_key_low := p_extract_key_low;
         v_extract_key_high := p_extract_key_high;
         v_extract_type := p_extract_type;
         v_extract_date := p_extract_date;
*/	
------------------------------------COMMENTED BY OAS---------------------------------------  

      V_BL_NO_PAY_IND_O := ''0'';
      V_BL_NO_PAY_IND_U := ''U'';
      V_TOS_CD_B4 := ''B4'';
      V_TOS_CD_B5 := ''B5'';
      V_ADJD_YES_NO_IND := ''Y'';
      V_PRDCT := ''Med Supp'';

------------------------------------COMMENTED BY OAS---------------------------------------  
/*INSERT
INTO
    ETL.ETL_DETAIL_LOAD_INFO
    (
        APPLICATION ,
        ETL_BATCH_ID,
        ETL_PROC_NAME ,
       ACTION ,
        STEP_INFO ,
        ROWS_AFFECTED ,
        ETL_DATETIME
    )
    VALUES
    (
        ''OPTUMHEALTHFEEDRPT'',
        NULL,
        v_proc_name,
        ''Value of v_extract_date'',
        v_extract_date,
        0,
        SYSTIMESTAMP
    );
COMMIT;

INSERT
INTO
    ETL.ETL_DETAIL_LOAD_INFO
    (
        APPLICATION ,
        ETL_BATCH_ID,
        ETL_PROC_NAME ,
       ACTION ,
        STEP_INFO ,
        ROWS_AFFECTED ,
        ETL_DATETIME
    )
    VALUES
    (
        ''OPTUMHEALTHFEEDRPT'',
        NULL,
        v_proc_name,
        ''Value of v_extract_key_low'',
        v_extract_key_low,
        0,
        SYSTIMESTAMP
    );
COMMIT;


INSERT
INTO
    ETL.ETL_DETAIL_LOAD_INFO
    (
        APPLICATION ,
        ETL_BATCH_ID,
        ETL_PROC_NAME ,
        ACTION ,
        STEP_INFO ,
        ROWS_AFFECTED ,
        ETL_DATETIME
    )
    VALUES
    (
        ''OPTUMHEALTHFEEDRPT'',
        NULL,
        v_proc_name,
        ''Value of v_extract_key_high'',
        v_extract_key_high,
        0,
        SYSTIMESTAMP
    );
COMMIT;

INSERT
INTO
    ETL.ETL_DETAIL_LOAD_INFO
    (
        APPLICATION ,
        ETL_BATCH_ID,
        ETL_PROC_NAME ,
        ACTION ,
        STEP_INFO ,
        ROWS_AFFECTED ,
        ETL_DATETIME
    )
    VALUES
    (
        ''OPTUMHEALTHFEEDRPT'',
        NULL,
        v_proc_name,
        ''Value of v_extract_type'',
        v_extract_type,
        0,
        SYSTIMESTAMP
    );
COMMIT;

      END;


BEGIN	*/	
------------------------------------COMMENTED BY OAS---------------------------------------  

                         ----- TRUNCATE CLAIMS WORK TABLE
						    
V_STEP_NAME    := ''TRUNCATE - WRK_IGX_CLAIMS_MEDSUPP'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

v_sql := ''TRUNCATE TABLE BDR_DM.WRK_IGX_CLAIMS_MEDSUPP'';

         EXECUTE IMMEDIATE :v_sql;

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );


                                                    -- analyze WRK_IGX_CLAIMS_MEDSUPP
     --    DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''WRK_IGX_CLAIMS_MEDSUPP'');		-----------------------------------OAS DELETE

    
V_STEP_NAME    := ''INSERT - WRK_IGX_CLAIMS_MEDSUPP'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

INSERT /*+ ENABLE_PARALLEL_DML APPEND */  INTO BDR_DM.WRK_IGX_CLAIMS_MEDSUPP
(
F_CLM_HIST_SK,
    OPREC_BILL_LINE_NUMBER,
    CLAIM_NUMBER,
    ACCOUNT_NUMBER,
    ZIP_CODE,
    STATE_CODE,
    BASE_PLAN_CODE,
    CPT_CODE,
    PLAN_EFF_MONTH,
    BILL_INCURRAL_DATE,
    PROCESS_DATE,
    SERVICE_FROM_DATE,
    SERVICE_TO_DATE,
    BENEFIT_PERIOD_DAYS,
    BENEFIT_AMT,
    MEDICARE_APPROVED_AMT,
    MEDICARE_PAYMENT_AMT,
    DEDUCTIBLE_AMT,
    PART_B_DEDUCT,
    REMARK_CODE,
    BILL_ASSIGN_IND,
    CHARGE_AMT,
    PROCEDURE_CODE,
    MEDICARE_ASSIGN_IND,
    INSURED_AGE,
    MODIFIER_1,
    MODIFIER_2,
    CHECK_TYPE_IND,
    MED_COINS_AMT,
    MED_COPAY_AMT,
    RECEIPT_DATE,
    ADJUST_BENEFIT_AMOUNT,
    LOB_PLAN_CD,
    ASSIGNEE_PROVIDER_KEY,
    PROVIDER_ID,
    TAX_ID_NUMBER,
    PROVIDER_NAME,
    PROVIDER_ADDRESS_1,
    PROVIDER_ADDRESS_2,
    PROVIDER_CITY,
    PROVIDER_ZIP,
    PROVIDER_STATE,
    PROVIDER_STATE_DESC,
    PROVIDER_PHONE,
    ADD_IONS,
    EXTRACT_KEY,
    PROVIDER_ZIP_KEY,
    NATIONAL_PROV_ID,
    TAXONOMY_CD,
    REND_NATIONAL_PROV_ID,
    REND_TAXONOMY_CD,
    REND_PROV_NAME,
    EC_BL_HOSP_MEDCR_COV_DAY,
    D_TOS_SK ,
    D_UNDWR_TAG_SK ,
    D_EOB_TYP_LOOK_SK,
    D_PLSRV_SK,
    D_MBR_INFO_SK
)
SELECT
            /*+ PARALLEL(8) */ CH.F_CLM_HIST_SK ,
             BLH.BIL_LN_NBR OPREC_BILL_LINE_NUMBER,
            LPAD( BLH.CLM_NBR ,12,''0'')            CLAIM_NUMBER,
            case when MBR.CURR_ACCT_NBR = ''-1'' then NVL(BLH.ACCT_NBR, ''-1'') ELSE MBR.CURR_ACCT_NBR END   ACCOUNT_NUMBER ,
            CH.INSD_ZIP             ZIP_CODE,
            CH.INSD_ST              STATE_CODE,
            case when length(dcp.COMPAS_PLN_CD) = 3 and (dcp.COMPAS_PLN_CD like ''%02%'' or dcp.COMPAS_PLN_CD like ''%S2%'' )
                and dcp.PRDCT =''Med Supp'' and dcp.PLN_GRP like ''%Modernize%''
                then replace(dcp.COMPAS_PLN_CD, ''2'', ''1'')
                else dcp.COMPAS_PLN_CD end as BASE_PLAN_CODE,
             DCL.CPT_CD,
             TO_NUMBER (TO_CHAR(TO_DATE(TO_CHAR(DECODE(BLH.CERT_EFF_DT_ID,-1,99991231,BLH.CERT_EFF_DT_ID)),''YYYYMMDD''
            ),''YYYYMM'')) PLAN_EFF_MONTH ,
             BLH.INCUR_DT_ID        BILL_INCURRAL_DATE,
            CH.CMPL_DT_ID          PROCESS_DATE,
            BLH.SRVC_FROM_DT_ID    SERVICE_FROM_DATE,
            BLH.SRVC_TO_DT_ID      SERVICE_TO_DATE,
            BLH.BEN_PRD_DAY        BENEFIT_PERIOD_DAYS,
            BLH.BEN_AMT            BENEFIT_AMT,
            BLH.MEDCR_APRV_AMT     MEDICARE_APPROVED_AMT,
            BLH.MEDCR_PD_AMT       MEDICARE_PAYMENT_AMT,
            BLH.AARP_DED_AMT       DEDUCTIBLE_AMT,
            BLH.PART_B_DED_AMT     PART_B_DEDUCT,
             NULL                   AS REMARK_CODE,
            BLH.CLM_ASGN_IND       BILL_ASSIGN_IND,
            BLH.CHRG_AMT           CHARGE_AMT,
            NULL                   AS PROCEDURE_CODE ,
            BLH.MEDCR_ASGN_IND MEDICARE_ASSIGN_IND,
            BLH.PREM_DUE_AGE_ID AS INSURED_AGE,
            TRANSLATE( DCML.CPT_MOD_CD , ''?-'',''  '') AS MODIFIER_1 ,
            TRANSLATE( DCML2.CPT_MOD_CD , ''?-'',''  '') AS MODIFIER_2 ,
            1                         AS CHECK_TYPE_IND,
           NVL(BLH.OOP_AMT,0)           MED_COINS_AMT,
            NVL(BLH.AARP_COPAY_AMT,0)    MED_COPAY_AMT,
            CH.RECPT_DT_ID               RECEIPT_DATE,
            BLH.ADJ_BEN_AMT              ADJUST_BENEFIT_AMOUNT,
            case when length(dcp.COMPAS_PLN_CD) = 3 and (dcp.COMPAS_PLN_CD like ''%02%'' or dcp.COMPAS_PLN_CD like ''%S2%'' )
                and dcp.PRDCT =''Med Supp'' and dcp.PLN_GRP like ''%Modernize%''
                then replace(dcp.COMPAS_PLN_CD, ''2'', ''1'')
                else dcp.COMPAS_PLN_CD end as LOB_PLAN_CD,
             CASE
                WHEN BLH.CLM_ASGN_IND = ''N''
                THEN NULL
                ELSE DP.UCPS_PROV_ID
            END AS ASSIGNEE_PROVIDER_KEY ,
            CASE
                WHEN BLH.CLM_ASGN_IND = ''N''
                THEN NULL
                ELSE  DP.PROV_TYP_CD
            END AS PROVIDER_ID ,
              CASE
                WHEN BLH.CLM_ASGN_IND = ''N''
                THEN NULL
                ELSE  DP.TIN
            END AS TAX_ID_NUMBER ,

            CASE
                WHEN BLH.CLM_ASGN_IND = ''N''
                THEN NULL
                ELSE
                    CASE
                        /* WHEN TRIM(TRANSLATE(TRIM(DPA.PROV_FST_NM) || '' '' || TRIM(DPA.PROV_MIDL_NM) || '' ''
                            || TRIM(DPA.PROV_LST_NM) ,'' ?-'',''   '')) IS NULL
                        THEN TRIM(PROV_BUS_NM)
                        ELSE TRIM(TRANSLATE( TRIM(DPA.PROV_FST_NM) || '' '' || TRIM(DPA.PROV_MIDL_NM) || '' ''
                            || TRIM(DPA.PROV_LST_NM) ,'' ?-'',''   '')) */				-------------------OAS DELETE
						WHEN NULLIF(TRIM(TRANSLATE(TRIM(NVL(DPA.PROV_FST_NM, '''')) || '' '' || TRIM(NVL(DPA.PROV_MIDL_NM, '''')) || '' ''
                            || TRIM(NVL(DPA.PROV_LST_NM, '''')) ,'' ?-'',''   '')), '''') IS NULL
							THEN TRIM(PROV_BUS_NM)
                        ELSE TRIM(TRANSLATE(TRIM(NVL(DPA.PROV_FST_NM, '''')) || '' '' || TRIM(NVL(DPA.PROV_MIDL_NM, '''')) || '' ''
                            || TRIM(NVL(DPA.PROV_LST_NM, '''')) ,'' ?-'',''   ''))		--------------------OAS ADD
                    END
            END AS PROVIDER_NAME,
            CASE
                WHEN BLH.CLM_ASGN_IND = ''N''
                THEN NULL
                ELSE DPA.PROV_ADDR_LN_1
            END AS PROVIDER_ADDRESS_1 ,
            CASE
                WHEN BLH.CLM_ASGN_IND = ''N''
                THEN NULL
                ELSE DPA.PROV_ADDR_LN_2
            END AS PROVIDER_ADDRESS_2 ,
            CASE
                WHEN BLH.CLM_ASGN_IND = ''N''
                THEN NULL
                ELSE DPA.PROV_CTY
            END AS PROVIDER_CITY ,
            CASE
                WHEN BLH.CLM_ASGN_IND = ''N''
                THEN NULL
                ELSE DPA.PROV_ZIP_CD
            END AS PROVIDER_ZIP,
            CASE
                WHEN BLH.CLM_ASGN_IND = ''N''
                THEN NULL
                ELSE DPA.PROV_ST_CD
            END AS PROVIDER_STATE,
            CASE
                WHEN BLH.CLM_ASGN_IND = ''N''
                THEN NULL
                ELSE DPA.PROV_ST_NM
            END AS PROVIDER_STATE_DESC ,
            CASE
                WHEN BLH.CLM_ASGN_IND = ''N''
                THEN NULL
                ELSE DP.PROV_TEL
            END AS PROVIDER_PHONE,
            CASE
                WHEN BLH.CLM_ASGN_IND = ''N''
                THEN NULL
                ELSE DPA.CREAT_BY_ID
            END AS ADD_IONS,
            CASE
                WHEN BLH.CLM_ASGN_IND = ''N''
                THEN NULL
                ELSE CH.CLM_PD_DT_ID
            END  AS EXTRACT_KEY ,
            NULL AS PROVIDER_ZIP_KEY ,
            CASE
                WHEN BLH.CLM_ASGN_IND = ''N''
                THEN NULL
                ELSE DP.NPI
            END AS NATIONAL_PROV_ID,
            CASE
                WHEN BLH.CLM_ASGN_IND = ''N''
                THEN NULL
                ELSE DP.TXNMY_CD
            END                                                    AS TAXONOMY_CD,
            DECODE(BLH.RNDR_PROV_NPI ,-1,NULL,BLH.RNDR_PROV_NPI)    REND_NATIONAL_PROV_ID ,
            DECODE(TRIM(DP.TXNMY_CD),''Unknown'',NULL,''NA'' ,NULL,DP.TXNMY_CD)              AS REND_TAXONOMY_CD,
            BLH.RNDR_PROV_NM ,
            g.max_ben_prd_day as EC_BL_HOSP_MEDCR_COV_DAY ,
            BLH.D_TOS_SK,
            BLH.D_UNDWR_TAG_SK ,
    CH.D_EOB_TYP_LOOK_SK,
    ECBLB.EC_BL_PLSRV_CD as D_PLSRV_SK,
    MBR.D_MBR_INFO_SK
   FROM
            BDR_DM.F_CLM_HIST CH
        JOIN  BDR_DM.F_CLM_BIL_LN_HIST BLH    ON  CH.F_CLM_HIST_SK= BLH.F_CLM_HIST_SK
     --  LEFT JOIN  DM.D_EC_PART_A_BL ECBL      ON  CH.D_EC_PART_A_SK =ECBL.D_EC_PART_A_SK
     --  AND CH.D_EC_PART_A_SK > v_EC_PART_A  AND BLH.BIL_LN_NBR = ECBL.EC_BL_NBR
       LEFT JOIN BDR_DM.D_EC_PART_B_BL ECBLB  on  CH.D_EC_PART_B_SK =ECBLB.D_EC_PART_B_SK
           and CH.D_EC_PART_B_SK > :v_EC_PART_A AND BLH.BIL_LN_NBR = ECBLB.EC_BL_NBR
        JOIN BDR_CONF.D_MBR_INFO MBR ON BLH.D_MBR_INFO_SK = MBR.D_MBR_INFO_SK
        JOIN  BDR_CONF.D_PROV DP              ON  CH.D_PROV_SK = DP.D_PROV_SK
        JOIN  BDR_CONF.D_PROV_ADDR DPA        ON  DP.D_PROV_SK = DPA.D_PROV_SK
        JOIN (

               SELECT D_PROV_ADDR_SK,  D_PROV_SK,PROV_ADDR_STOP_DT,ROW_NUMBER() OVER (PARTITION BY D_PROV_SK ORDER BY PROV_ADDR_STOP_DT DESC ) AS RN  FROM BDR_CONF.D_PROV_ADDR
--               WHERE  (  v_extract_key_low BETWEEN  TO_NUMBER(TO_CHAR(PROV_ADDR_STRT_DT,''YYYYMMDD'')) AND TO_NUMBER(TO_CHAR(PROV_ADDR_STOP_DT,''YYYYMMDD''))
--                                                           OR
--                       v_extract_key_high BETWEEN  TO_NUMBER(TO_CHAR(PROV_ADDR_STRT_DT,''YYYYMMDD''))  AND TO_NUMBER(TO_CHAR(PROV_ADDR_STOP_DT,''YYYYMMDD''))  )
              )DPA1 ON DPA.D_PROV_ADDR_SK = DPA1.D_PROV_ADDR_SK AND DPA1.RN = :v_rn
        JOIN  BDR_DM.D_CPT_LOOK DCL           ON  BLH.D_CPT_LOOK_SK = DCL.D_CPT_LOOK_SK
        JOIN  BDR_DM.D_CPT_MOD_LOOK DCML      ON  BLH.D_CPT_LOOK_SK_1= DCML.D_CPT_MOD_LOOK_SK
        JOIN  BDR_DM.D_CPT_MOD_LOOK DCML2     ON  BLH.D_CPT_LOOK_SK_2= DCML2.D_CPT_MOD_LOOK_SK
        --JOIN  CONF.D_PLN_BEN_MOD PBM      ON  BLH.D_PLN_BEN_MOD_SK = PBM.D_PLN_BEN_MOD_SK
                JOIN BDR_DM.D_CLM_PLN dcp ON BLH.D_CLM_PLN_SK = dcp.D_CLM_PLN_SK

                LEFT JOIN
                                (SELECT /*+ PARALLEL(8) */ ch.CLM_NBR,
                                  tos.TOS_GL_ACCT_CD,
                                  BLH.BEN_PRD_NBR,
                                  SUBSTR (TRIM (tos.TOS_CD), 1, 1) clm_type,
                                  MAX (BLH.ben_prd_day) AS max_ben_prd_day
                             FROM BDR_DM.F_CLM_HIST CH
                               JOIN BDR_DM.F_CLM_BIL_LN_HIST BLH
                                     ON     BLH.F_CLM_HIST_SK = ch.F_CLM_HIST_SK
                              JOIN BDR_DM.D_CLM_PLN dcp ON BLH.D_CLM_PLN_SK = dcp.D_CLM_PLN_SK
                              JOIN BDR_DM.D_TOS tos
                                                    ON     tos.D_TOS_SK = BLH.D_TOS_SK
                                        AND SUBSTR (tos.TOS_CD, 1, 1) IN (:v_TOS_CD_H, :v_TOS_CD_W)
                                        AND tos.TOS_GL_ACCT_CD <> :v_TOS_GL_ACCT_CD
                             WHERE CH.ADJD_YES_NO_IND = :V_ADJD_YES_NO_IND
                              and    (BLH.BL_NO_PAY_IND IN (:V_BL_NO_PAY_IND_O,  :V_BL_NO_PAY_IND_U))
                               AND (DCP.PRDCT = :V_PRDCT
                                AND DCP.BAS_PLN_CD NOT IN (:V_BASE_PN_DP, :V_BASE_PN_AD ))
                                AND  CH.CLM_PD_DT_ID between :v_extract_key_low and  :v_extract_key_high

                         GROUP BY ch.CLM_NBR,
                                  tos.TOS_GL_ACCT_CD,
                                  BLH.BEN_PRD_NBR,
                                  SUBSTR (TRIM (tos.TOS_CD), 1, 1)) g

                                    ON     CH.CLM_NBR = g.clm_nbr
                                         AND SUBSTR (TRIM (BLH.TOS_CD), 1, 1) = g.clm_type
                                         AND BLH.BEN_PRD_NBR = g.BEN_PRD_NBR
         WHERE
             CH.ADJD_YES_NO_IND = :V_ADJD_YES_NO_IND
             and   SUBSTR (BLH.TOS_CD, 1, 1) <> :V_TOS_CD_R

        -- AND  BLH.BL_NO_PAY_IND in (''0'', ''U'')
        and    (   BLH.BL_NO_PAY_IND IN (:V_BL_NO_PAY_IND_O,  :V_BL_NO_PAY_IND_U))

             /* OR (    BLH.BL_NO_PAY_IND = V_BL_NO_PAY_IND_U
                  AND BLH.TOS_CD IN (V_TOS_CD_B4, V_TOS_CD_B5)))*/


        --AND  PBM.PRDCT_SUB_GRP =''Med Supp Base''
                AND ( DCP.PRDCT = :V_PRDCT
                                AND DCP.BAS_PLN_CD NOT IN (:V_BASE_PN_DP, :V_BASE_PN_AD ))


        /*AND CH.ETL_LST_BTCH_ID IN (
        SELECT DISTINCT EL.BATCH_ID FROM ETL.ETL_BATCH_LOG EL WHERE   EL.APPLICATION=''CDC'' AND
         TO_NUMBER(TO_CHAR(EL.BATCH_START_DATETIME,''YYYYMMDD'')) BETWEEN   v_extract_key_low and  v_extract_key_high ) */

        AND  CH.CLM_PD_DT_ID between :v_extract_key_low and  :v_extract_key_high;
    	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

------------------------------------COMMENTED BY OAS---------------------------------------  
  /*     v_rows_inserted := SQL%ROWCOUNT;

         COMMIT;

         INSERT
        INTO
            ETL.ETL_DETAIL_LOAD_INFO
            (
                APPLICATION ,
                ETL_PROC_NAME ,
                ACTION ,
                STEP_INFO ,
                ROWS_AFFECTED ,
                ETL_DATETIME
            )
            VALUES
            (
                ''OPTUMHEALTHFEEDRPT'',
                v_proc_name,
                ''WORK TABLE INSERT'',
                ''ROWS INSERTED'',
                v_rows_inserted,
                SYSTIMESTAMP
            );

        COMMIT;
                                                -- analyze WRK_IGX_CLAIMS_MEDSUPP AFTER DATA LOAD
         DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''WRK_IGX_CLAIMS_MEDSUPP'');

      END;



BEGIN	*/
	------------------------------------COMMENTED BY OAS---------------------------------------  

                         ----- TRUNCATE CLAIMS ICD WORK TABLE
						   
V_STEP_NAME    := ''TRUNCATE - WRK_IGX_ICD_MEDSUPP'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

v_sql := ''TRUNCATE TABLE BDR_DM.WRK_IGX_ICD_MEDSUPP'';

         EXECUTE IMMEDIATE :v_sql;

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

                                                    -- analyze WRK_IGX_ICD_MEDSUPP
--         DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''WRK_IGX_ICD_MEDSUPP'');	-----------------------------------OAS DELETE


V_STEP_NAME    := ''INSERT - WRK_IGX_ICD_MEDSUPP'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;


INSERT /*+ ENABLE_PARALLEL_DML APPEND */  INTO BDR_DM.WRK_IGX_ICD_MEDSUPP(F_CLM_HIST_SK,ICD_10_IND,ICD_CD,SEQ_NBR)
SELECT /*+ PARALLEL(8) */ W.F_CLM_HIST_SK ,DIC.ICD_10_IND,DIC.ICD_CD,DCI.SEQ_NBR
FROM BDR_DM.WRK_IGX_CLAIMS_MEDSUPP W
  JOIN  BDR_DM.D_CLM_ICD DCI ON W.F_CLM_HIST_SK=DCI.F_CLM_HIST_SK
   JOIN  BDR_DM.D_ICD_LOOK DIC   ON DCI.D_ICD_LOOK_SK = DIC.D_ICD_LOOK_SK;
    	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

------------------------------------COMMENTED BY OAS---------------------------------------     
/*   v_rows_inserted := SQL%ROWCOUNT;

         COMMIT;

         INSERT
        INTO
            ETL.ETL_DETAIL_LOAD_INFO
            (
                APPLICATION ,
                ETL_PROC_NAME ,
                ACTION ,
                STEP_INFO ,
                ROWS_AFFECTED ,
                ETL_DATETIME
            )
            VALUES
            (
                ''OPTUMHEALTHFEEDRPT'',
                v_proc_name,
                ''ICD WORK TABLE INSERT'',
                ''ROWS INSERTED'',
                v_rows_inserted,
                SYSTIMESTAMP
            );

        COMMIT;

                                                    -- analyze WRK_IGX_ICD_MEDSUPP
         DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''WRK_IGX_ICD_MEDSUPP'');

      END;

      BEGIN   */
	  ------------------------------------COMMENTED BY OAS---------------------------------------  

	  -- truncate IGX_CLAIMS_MEDSUPP
	    
V_STEP_NAME    := ''TRUNCATE - RPT_IGX_CLAIMS_MEDSUPP'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;
	  
         v_sql := ''TRUNCATE TABLE BDR_DM.RPT_IGX_CLAIMS_MEDSUPP'';

         EXECUTE IMMEDIATE :v_sql;

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

                                                    -- analyze IGX_CLAIMS_MEDSUPP
 /*        DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''RPT_IGX_CLAIMS_MEDSUPP'');

      END;
BEGIN */	-----------------------------------OAS DELETE

-- insert to IGX_CLAIMS_MEDSUPP
  
V_STEP_NAME    := ''INSERT - RPT_IGX_CLAIMS_MEDSUPP'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

       INSERT
       /*+ ENABLE_PARALLEL_DML APPEND */
    INTO
        BDR_DM.RPT_IGX_CLAIMS_MEDSUPP
        (
            OPREC_BILL_LINE_NUMBER,
    CLAIM_NUMBER,
    ACCOUNT_NUMBER,
    ZIP_CODE,
    STATE_CODE,
    UNDERWRITE_CODE,
    BASE_PLAN_CODE,
    TOS_CODE,
    CPT_CODE,
    ICD_1,
    ICD_2,
    ICD_3,
    ICD_IND,
    PLAN_EFF_MONTH,
    PLAN_TERM_MONTH,
    BILL_INCURRAL_DATE,
    PROCESS_DATE,
    SERVICE_FROM_DATE,
    SERVICE_TO_DATE,
    BENEFIT_PERIOD_DAYS,
    BENEFIT_AMT,
    MEDICARE_APPROVED_AMT,
    MEDICARE_PAYMENT_AMT,
    DEDUCTIBLE_AMT,
    PART_B_DEDUCT,
    REMARK_CODE,
    BILL_ASSIGN_IND,
    CHARGE_AMT,
    PROCEDURE_CODE,
    MEDICARE_ASSIGN_IND,
    INSURED_AGE,
    EOB_TYPE,
    MODIFIER_1,
    MODIFIER_2,
    HOSP_DAYS,
    SNF_DAYS,
    INDIVIDUAL_ID,
    PLACE_SERVICE_CODE,
    BL_MED_TOS_CODE,
    CHECK_TYPE_IND,
    MED_COINS_AMT,
    MED_COPAY_AMT,
    RECEIPT_DATE,
    ADJUST_BENEFIT_AMOUNT,
    LOB_PLAN_CD,
    DATE_OF_BIRTH,
    GENDER_CD,
    MEDICARE_CLAIM_NUM,
    ASSIGNEE_PROVIDER_KEY,
    PROVIDER_ID,
    TAX_ID_NUMBER,
    PROVIDER_NAME,
    PROVIDER_ADDRESS_1,
    PROVIDER_ADDRESS_2,
    PROVIDER_CITY,
    PROVIDER_ZIP,
    PROVIDER_STATE,
    PROVIDER_STATE_DESC,
    PROVIDER_PHONE,
    ADD_IONS,
    EXTRACT_KEY,
    PROVIDER_ZIP_KEY,
    NATIONAL_PROV_ID,
    TAXONOMY_CD,
    REND_NATIONAL_PROV_ID,
    REND_TAXONOMY_CD,
    REND_PROV_NAME
)
SELECT /*+ PARALLEL(8) */
                                                                    --DISTINCT
      W.OPREC_BILL_LINE_NUMBER,
      W.CLAIM_NUMBER,
      W.ACCOUNT_NUMBER,
      W.ZIP_CODE,
      W.STATE_CODE,
      CASE
         WHEN SUBSTR (UT.UNDWR_PLN_RQR_TXT, 1, 3) = ''U/W''
         THEN
            ''Y''
         WHEN SUBSTR (UT.UNDWR_PLN_RQR_TXT, 1, 7) = ''Not U/W''
         THEN
            /* CASE
               WHEN    INSTR (UT.UNDWR_PLN_RQR_TXT, ''Open Enrollment'', 8) > 0
                    OR INSTR (UT.UNDWR_PLN_RQR_TXT, ''Plan Change'', 8) > 0
               THEN
                  ''W''
               ELSE
                  ''N''
            END */				-------------OAS DELETE
			CASE WHEN (CASE WHEN POSITION(''Open Enrollment'' IN SUBSTR(UT.UNDWR_PLN_RQR_TXT, 8)) > 0
								THEN POSITION(''Open Enrollment'' IN SUBSTR(UT.UNDWR_PLN_RQR_TXT, 8)) + 7
							ELSE 0
						END) > 0 
						OR 
						(CASE WHEN POSITION(''Plan Change'' IN SUBSTR(UT.UNDWR_PLN_RQR_TXT, 8)) > 0
								THEN POSITION(''Plan Change'' IN SUBSTR(UT.UNDWR_PLN_RQR_TXT, 8)) + 7
								ELSE 0
						END) > 0 
				THEN ''W'' 
				ELSE ''N'' 
			END					------------OAS ADD
         ELSE
            ''B''
      END
         AS UNDERWRITE_CODE,
      W.BASE_PLAN_CODE,
      DT.TOS_CD,
      W.CPT_CODE,
      NVL(DECODE (ICD.ICD_1, ''-1'', ''-'', ICD.ICD_1), ''-'') ICD_1,
      NVL(DECODE (ICD.ICD_2, ''-1'', ''-'', ICD.ICD_2), ''-'') ICD_2,
      NVL(DECODE (ICD.ICD_3, ''-1'', ''-'', ICD.ICD_3), ''-'') ICD_3,
      --ICD.ICD_10_IND,
      NVL(DECODE(ICD.ICD_10_IND,null,''U'',ICD_10_IND),''U'') as ICD_10_IND,
      W.PLAN_EFF_MONTH,
            NVL(TO_NUMBER (TO_CHAR(TO_DATE(TO_CHAR(IMM.INSURED_PLAN_TERMINATION_DATE),''YYYYMMDD''),''YYYYMM'')),''999912'')
                                  PLAN_TERM_MONTH,
      W.BILL_INCURRAL_DATE,
      W.PROCESS_DATE,
      W.SERVICE_FROM_DATE,
      W.SERVICE_TO_DATE,
      W.BENEFIT_PERIOD_DAYS,
      W.BENEFIT_AMT,
      W.MEDICARE_APPROVED_AMT,
      W.MEDICARE_PAYMENT_AMT,
      W.DEDUCTIBLE_AMT,
      W.PART_B_DEDUCT,
      W.REMARK_CODE,
      W.BILL_ASSIGN_IND,
      W.CHARGE_AMT,
      W.PROCEDURE_CODE,
      W.MEDICARE_ASSIGN_IND,
      W.INSURED_AGE,
      EOB.EOB_TYP_CD EOB_TYPE,
      W.MODIFIER_1,
      W.MODIFIER_2,
      CASE
         WHEN SUBSTR (TRIM (DT.TOS_CD), 1, 1) = ''H''
         THEN
          TO_CHAR(W.EC_BL_HOSP_MEDCR_COV_DAY)
         ELSE
            ''0''
      END
         AS HOSP_DAYS,
      CASE
         WHEN SUBSTR (TRIM (DT.TOS_CD), 1, 1) = ''W''
         THEN
            TO_CHAR(W.EC_BL_HOSP_MEDCR_COV_DAY)
         ELSE
            ''0''
      END
         AS SNF_DAYS,
      case when mbr.curr_indv_id = -1 then nvl(hphm.individual_id, -1) else mbr.curr_indv_id end INDIVIDUAL_ID,
      W.D_PLSRV_SK PLACE_SERVICE_CODE,
      DT.TOS_CD BL_MED_TOS_CODE,
      W.CHECK_TYPE_IND,
      W.MED_COINS_AMT,
      W.MED_COPAY_AMT,
      W.RECEIPT_DATE,
      W.ADJUST_BENEFIT_AMOUNT,
      W.LOB_PLAN_CD,
      MBR.DOB_ID,
      MBR.GDR_CD,
      MBR.MEDCR_CLM_NBR,
      W.ASSIGNEE_PROVIDER_KEY,
      W.PROVIDER_ID,
      W.TAX_ID_NUMBER,
      W.PROVIDER_NAME,
      W.PROVIDER_ADDRESS_1,
      W.PROVIDER_ADDRESS_2,
      W.PROVIDER_CITY,
      W.PROVIDER_ZIP,
      W.PROVIDER_STATE,
      W.PROVIDER_STATE_DESC,
      W.PROVIDER_PHONE,
      W.ADD_IONS,
      W.EXTRACT_KEY,
      W.PROVIDER_ZIP_KEY,
      W.NATIONAL_PROV_ID,
      W.TAXONOMY_CD,
      W.REND_NATIONAL_PROV_ID,
      W.REND_TAXONOMY_CD,
      W.REND_PROV_NAME
FROM BDR_DM.WRK_IGX_CLAIMS_MEDSUPP W
JOIN BDR_CONF.d_mbr_info MBR ON W.d_mbr_info_sk = MBR.d_mbr_info_sk
LEFT OUTER JOIN
      (SELECT  hm.individual_id,
               hp.membership_number,
               hp.association_id,
               hm.insured_cd
         FROM SRC_COMPAS_D.household_profile hp, SRC_COMPAS_D.household_member hm
         WHERE     hp.household_id = hm.household_id
        AND :v_extract_date BETWEEN HM.HHOLD_MEMBER_START_DATE AND NVL (HM.HHOLD_MEMBER_STOP_DATE,
            TO_DATE (''31-DEC-9999'',''DD-MON-YYYY'') )
        AND :v_extract_date BETWEEN HP.HHOLD_PROFILE_START_DATE AND NVL (HP.HHOLD_PROFILE_STOP_DATE,
            TO_DATE (''31-DEC-9999'',''DD-MON-YYYY'') )
               AND NVL (hp.delete_ind, ''N'') <> ''Y'') hphm
            ON    TO_NUMBER( W.account_number) = TO_NUMBER ( NVL(TO_CHAR(hphm.MEMBERSHIP_NUMBER), '''') || NVL(TO_CHAR(hphm.ASSOCIATION_ID), '''') || NVL(TO_CHAR(hphm.INSURED_CD), '''') )

      LEFT OUTER JOIN (SELECT DISTINCT ACCOUNT_NUMBER ,
            INDIVIDUAL_ID ,
            EXTRACT_TYPE ,
            INSURED_PLAN_EFFECTIVE_DATE,
            INSURED_PLAN_TERMINATION_DATE FROM BDR_DM.RPT_IGX_MEMBER_MEDSUPP Q1
            WHERE EXTRACT_TYPE = ''MEDSUPP'' ) IMM

         ON     W.ACCOUNT_NUMBER = IMM.ACCOUNT_NUMBER
            AND hphm.individual_id = IMM.INDIVIDUAL_ID
           -- AND IMM.EXTRACT_TYPE = ''MEDSUPP''
            AND W.PLAN_EFF_MONTH =
                   SUBSTR (TO_CHAR (IMM.INSURED_PLAN_EFFECTIVE_DATE), 1, 6)
      JOIN BDR_DM.D_TOS DT ON W.D_TOS_SK = DT.D_TOS_SK
      JOIN BDR_CONF.D_UNDWR_TAG UT ON W.D_UNDWR_TAG_SK = UT.D_UNDWR_TAG_SK
      LEFT JOIN
      (  SELECT F_CLM_HIST_SK,
                MAX (DECODE (TRIM (ICD_10_IND), NULL, ''9'', ''0'')) ICD_10_IND,
               MAX (DECODE (SEQ_NBR, 1, ICD_CD, NULL)) ICD_1,
                MAX (DECODE (SEQ_NBR, 2, ICD_CD, NULL)) ICD_2,
                MAX (DECODE (SEQ_NBR, 3, ICD_CD, NULL)) ICD_3
           FROM BDR_DM.WRK_IGX_ICD_MEDSUPP
       GROUP BY F_CLM_HIST_SK) ICD
         ON W.F_CLM_HIST_SK = ICD.F_CLM_HIST_SK
      JOIN BDR_DM.D_EOB_TYP_LOOK EOB
         ON W.D_EOB_TYP_LOOK_SK = EOB.D_EOB_TYP_LOOK_SK
      --JOIN DM.D_PLSRV DPS ON W.D_PLSRV_SK = DPS.D_PLSRV_SK
WHERE DT.TOS_GL_ACCT_CD <> ''50300'';
    	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

------------------------------------COMMENTED BY OAS---------------------------------------  
/*          v_rows_inserted := SQL%ROWCOUNT;

         COMMIT;
         INSERT
       INTO
            ETL.ETL_DETAIL_LOAD_INFO
            (
                APPLICATION ,
                ETL_PROC_NAME ,
                ACTION ,
                STEP_INFO ,
                ROWS_AFFECTED ,
                ETL_DATETIME
            )
            VALUES
            (
                ''OPTUMHEALTHFEEDRPT'',
                v_proc_name,
                ''INSERT'',
                ''ROWS INSERTED'',
                v_rows_inserted,
                SYSTIMESTAMP
            );

        COMMIT;
      END;

      BEGIN
                                           -- analyze IGX_CLAIMS_MEDSUPP
         DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''RPT_IGX_CLAIMS_MEDSUPP'');


      END;

      COMMIT;
       INSERT
        INTO
            ETL.ETL_DETAIL_LOAD_INFO
            (
                APPLICATION ,
                ETL_PROC_NAME ,
                ACTION ,
                STEP_INFO ,
                ROWS_AFFECTED ,
                ETL_DATETIME
            )
            VALUES
            (
                ''OPTUMHEALTHFEEDRPT'',
                v_proc_name,
                ''END'',
                ''PROC EXECUTION COMPLETED'',
                0,
                SYSTIMESTAMP
            );

        COMMIT;
   EXCEPTION
      WHEN OTHERS
      THEN
          v_err_message :=SQLERRM;
    INSERT
    INTO
        ETL.ETL_DETAIL_LOAD_INFO
        (
            APPLICATION ,
            ETL_BATCH_ID,
            ETL_PROC_NAME ,
            ACTION ,
            STEP_INFO ,
            ROWS_AFFECTED ,
            ETL_DATETIME
        )
        VALUES
        (
            ''OPTUMHEALTHFEEDRPT'',
            NULL,
            v_proc_name,
            ''E'',
            v_err_message ,
            0,
            SYSTIMESTAMP
        );

   DBMS_OUTPUT.PUT_LINE(''ERROR: '' || SQLCODE || ''-'' || SQLERRM || ''-'' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE()|| Chr(10)||DBMS_UTILITY.FORMAT_ERROR_STACK());
    RAISE;
   END;

--------------------DM.PKG_INGENIX_EXTRACT.pr_extract_claims ENDS--------------------


--------------------DM.PKG_INGENIX_EXTRACT.pr_extract_claims_ocrs BEGINS--------------------

--
-- Purpose: Extract OCRS Claim recs
--

-- ---------   ------  -------------------------------------------
    PROCEDURE pr_extract_claims_ocrs (
      p_extract_key_low    IN   NUMBER,
      p_extract_key_high   IN   NUMBER,
      p_extract_type       IN   VARCHAR2,
      p_extract_date       IN   DATE

   )
   IS
      v_sql                VARCHAR2 (5000);
      v_rows_inserted      NUMBER;
      v_run_date           DATE;
      v_proc_name          VARCHAR2 (30)          := ''pr_extract_claims_ocrs'';
      v_extract_key_low    NUMBER (8, 0);
      v_extract_key_high   NUMBER (8, 0);
      v_extract_type       VARCHAR2(50);
      v_extract_date       DATE;
      v_err_message        VARCHAR2(2000);
      v_receipt_num  NUMBER;
   BEGIN

INSERT
    INTO
        ETL.ETL_DETAIL_LOAD_INFO
        (
            APPLICATION ,
            ETL_BATCH_ID,
            ETL_PROC_NAME ,
            ACTION ,
            STEP_INFO ,
            ROWS_AFFECTED ,
            ETL_DATETIME
        )
        VALUES
        (
            ''OPTUMHEALTHFEEDRPT'',
            NULL,
            v_proc_name,
            ''START'',
            ''PROCEDURE STARTS'',
            0,
           SYSTIMESTAMP
        );
COMMIT;

      BEGIN
         v_extract_key_low := p_extract_key_low;
         v_extract_key_high := p_extract_key_high;
         v_extract_type := p_extract_type;
         v_extract_date := p_extract_date;
         --v_receipt_num  := 500;	*/	
		 ------------------------------------COMMENTED BY OAS---------------------------------------  


-----------OAS DELETE - AS THE VALUE IS GETTING FETCHED FROM OBJECT PARAMETER TABLE---------------
    /* SELECT MAX(METADATA_VALUE)
    INTO   v_receipt_num
    FROM   ETL.ETL_APPLICATION_METADATA
    WHERE  APPLICATION=''CLAIMS''
    AND    METADATA_DESC=''OPTUMHEALTHFEED'' AND METADATA_TYPE = ''RECEIPT_NUM'';*/	
	-----------OAS DELETE - AS THE VALUE IS GETTING FETCHED FROM OBJECT PARAMETER TABLE---------------


------------------------------------COMMENTED BY OAS---------------------------------------  
/*INSERT
INTO
    ETL.ETL_DETAIL_LOAD_INFO
    (
        APPLICATION ,
        ETL_BATCH_ID,
        ETL_PROC_NAME ,
        ACTION ,
       STEP_INFO ,
        ROWS_AFFECTED ,
        ETL_DATETIME
    )
    VALUES
    (
        ''OPTUMHEALTHFEEDRPT'',
        NULL,
        v_proc_name,
        ''Value of v_extract_date'',
        v_extract_date,
        0,
        SYSTIMESTAMP
    );
COMMIT;

INSERT
INTO
    ETL.ETL_DETAIL_LOAD_INFO
    (
        APPLICATION ,
        ETL_BATCH_ID,
        ETL_PROC_NAME ,
        ACTION ,
        STEP_INFO ,
        ROWS_AFFECTED ,
        ETL_DATETIME
    )
    VALUES
    (
        ''OPTUMHEALTHFEEDRPT'',
        NULL,
        v_proc_name,
        ''Value of v_extract_key_low'',
        v_extract_key_low,
        0,
        SYSTIMESTAMP
    );
COMMIT;


INSERT
INTO
    ETL.ETL_DETAIL_LOAD_INFO
    (
        APPLICATION ,
        ETL_BATCH_ID,
        ETL_PROC_NAME ,
        ACTION ,
        STEP_INFO ,
        ROWS_AFFECTED ,
        ETL_DATETIME
    )
    VALUES
    (
        ''OPTUMHEALTHFEEDRPT'',
        NULL,
        v_proc_name,
        ''Value of v_extract_key_high'',
        v_extract_key_high,
        0,
        SYSTIMESTAMP
    );
COMMIT;

INSERT
INTO
    ETL.ETL_DETAIL_LOAD_INFO
    (
        APPLICATION ,
        ETL_BATCH_ID,
        ETL_PROC_NAME ,
        ACTION ,
        STEP_INFO ,
        ROWS_AFFECTED ,
        ETL_DATETIME
    )
    VALUES
    (
        ''OPTUMHEALTHFEEDRPT'',
        NULL,
        v_proc_name,
        ''Value of v_extract_type'',
        v_extract_type,
        0,
        SYSTIMESTAMP
    );
COMMIT;

      END;

      BEGIN             */
	  ------------------------------------COMMENTED BY OAS---------------------------------------  

	  -- truncate IGX_CLAIMS_OCRS_MEDSUPP
	    
V_STEP_NAME    := ''TRUNCATE - RPT_IGX_CLAIMS_OCRS_MEDSUPP'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

         v_sql :=
               ''TRUNCATE TABLE BDR_DM.RPT_IGX_CLAIMS_OCRS_MEDSUPP'';

         EXECUTE IMMEDIATE :v_sql;

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );



------------------------------------OAS ADD -- CREATING TEMPORARY TABLE TO HANDLE JULIAN DATE CONVERSION--------------------------------------
CREATE OR REPLACE TEMPORARY TABLE JULIAN_DATE_HANDLE AS 
(
SELECT F_OCRS_BIL_LN_HIST_SK, to_char(
			    CASE
			        WHEN to_number(substr(
			            CASE
			                WHEN substr(NVL(substr(lpad(oblh.chk_dt_id, 8, 0), 1, 3), '''')
			                            || NVL(substr(CASE WHEN D_CLM_TYP_IND = 2 THEN rpad(oblh.clm_nbr, 11, 0) 
			                            ELSE lpad(oblh.clm_nbr, 12, 0) END, 1, 4), ''''), 1, 4) > to_char(CURRENT_TIMESTAMP, ''YYYY'') THEN
			                    to_number(nvl(substr(lpad(oblh.chk_dt_id, 8, 0), 1, 3), '''')
			                              || nvl(substr(CASE WHEN D_CLM_TYP_IND = 2 THEN rpad(oblh.clm_nbr, 11, 0) ELSE lpad(oblh.clm_nbr, 12, 0) END, 1, 4), '''')) - 10000
			                ELSE
			                    to_number(nvl(substr(lpad(oblh.chk_dt_id, 8, 0), 1, 3), '''')
			                              || nvl(substr(CASE WHEN D_CLM_TYP_IND = 2 THEN rpad(oblh.clm_nbr, 11, 0) ELSE lpad(oblh.clm_nbr, 12, 0) END, 1, 4), ''''))
			            END, 5, 3)) > 366 THEN
			            to_number(
			                CASE
			                    WHEN substr(nvl(substr(lpad(oblh.chk_dt_id, 8, 0), 1, 3), '''')
			                                || nvl(substr(CASE WHEN D_CLM_TYP_IND = 2 THEN rpad(oblh.clm_nbr, 11, 0) ELSE lpad(oblh.clm_nbr, 12, 0) END, 1, 4), ''''), 1, 4) > to_char(CURRENT_TIMESTAMP, ''YYYY'') THEN
			                        to_number(nvl(substr(lpad(oblh.chk_dt_id, 8, 0), 1, 3), '''')
			                                  || nvl(substr(CASE WHEN D_CLM_TYP_IND = 2 THEN rpad(oblh.clm_nbr, 11, 0) ELSE lpad(oblh.clm_nbr, 12, 0) END, 1, 4), '''')) - 10000
			                    ELSE
			                        to_number(nvl(substr(lpad(oblh.chk_dt_id, 8, 0), 1, 3), '''')
			                                  || nvl(substr(CASE WHEN D_CLM_TYP_IND = 2 THEN rpad(oblh.clm_nbr, 11, 0) ELSE lpad(oblh.clm_nbr, 12, 0) END, 1, 4), ''''))
			                END
			            )- :V_RECEIPT_NUM
			        ELSE
			            CASE
			                WHEN substr(nvl(substr(lpad(oblh.chk_dt_id, 8, 0), 1, 3), '''')
			                            || nvl(substr(CASE WHEN D_CLM_TYP_IND = 2 THEN rpad(oblh.clm_nbr, 11, 0) ELSE lpad(oblh.clm_nbr, 12, 0) END, 1, 4), ''''), 1, 4) > to_char(CURRENT_TIMESTAMP, ''YYYY'') THEN
			                    to_number(nvl(substr(lpad(oblh.chk_dt_id, 8, 0), 1, 3), '''')
			                              || nvl(substr(CASE WHEN D_CLM_TYP_IND = 2 THEN rpad(oblh.clm_nbr, 11, 0) ELSE lpad(oblh.clm_nbr, 12, 0) END, 1, 4), '''')) - 10000
			                ELSE
			                    to_number(nvl(substr(lpad(oblh.chk_dt_id, 8, 0), 1, 3), '''')
			                              || nvl(substr(CASE WHEN D_CLM_TYP_IND = 2 THEN rpad(oblh.clm_nbr, 11, 0) ELSE lpad(oblh.clm_nbr, 12, 0) END, 1, 4), ''''))
			            END
			    END) AS RECEIPT_DATE_IP,TO_NUMBER(TO_CHAR(DATEADD(''DAY'',TO_NUMBER(SUBSTR(RECEIPT_DATE_IP, 5, 7)) - 1,  TO_DATE(SUBSTR(RECEIPT_DATE_IP, 1, 4) || ''-01-01'')), ''yyyymmdd'')) AS RECEIPT_DATE FROM BDR_DM.F_OCRS_BIL_LN_HIST OBLH);

------------------------------------OAS ADD -- CREATED TEMPORARY TABLE TO HANDLE JULIAN DATE CONVERSION--------------------------------------




                                            -- analyze IGX_CLAIMS_OCRS_MEDSUPP
 /*        DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''RPT_IGX_CLAIMS_OCRS_MEDSUPP'');

      END;
-- SCR 42885 09-May-13 For ICD-10 added icd_code_ind fields to following SQL
-- statement.
      BEGIN        */	-----------------------------------OAS DELETE                      
	  
	  -- insert to IGX_CLAIMS_OCRS_MEDSUPP
	    
V_STEP_NAME    := ''INSERT - RPT_IGX_CLAIMS_OCRS_MEDSUPP'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

         INSERT
        /*+ ENABLE_PARALLEL_DML APPEND */
    INTO
        BDR_DM.RPT_IGX_CLAIMS_OCRS_MEDSUPP
        (
            OPREC_BILL_LINE_NUMBER,
    CLAIM_NUMBER,
    ACCOUNT_NUMBER,
    ZIP_CODE,
    STATE_CODE,
    UNDERWRITE_CODE,
    BASE_PLAN_CODE,
    TOS_CODE,
    CPT_CODE,
    ICD_1,
    ICD_2,
    ICD_3,
    ICD_IND,
    PLAN_EFF_MONTH,
    PLAN_TERM_MONTH,
    BILL_INCURRAL_DATE,
    PROCESS_DATE,
    SERVICE_FROM_DATE,
    SERVICE_TO_DATE,
    BENEFIT_PERIOD_DAYS,
    BENEFIT_AMT,
    MEDICARE_APPROVED_AMT,
    MEDICARE_PAYMENT_AMT,
    DEDUCTIBLE_AMT,
    PART_B_DEDUCT,
    REMARK_CODE,
    BILL_ASSIGN_IND,
    CHARGE_AMT,
    PROCEDURE_CODE,
    MEDICARE_ASSIGN_IND,
    INSURED_AGE,
    EOB_TYPE,
    MODIFIER_1,
    MODIFIER_2,
    HOSP_DAYS,
    SNF_DAYS,
    INDIVIDUAL_ID,
    PLACE_SERVICE_CODE,
    BL_MED_TOS_CODE,
    CHECK_TYPE_IND,
    MED_COINS_AMT,
    MED_COPAY_AMT,
    RECEIPT_DATE,
    ADJUST_BENEFIT_AMOUNT,
    LOB_PLAN_CD,
    DATE_OF_BIRTH,
    GENDER_CD,
    MEDICARE_CLAIM_NUM,
    ASSIGNEE_PROVIDER_KEY,
    PROVIDER_ID,
    TAX_ID_NUMBER,
    PROVIDER_NAME,
    PROVIDER_ADDRESS_1,
    PROVIDER_ADDRESS_2,
    PROVIDER_CITY,
    PROVIDER_ZIP,
    PROVIDER_STATE,
    PROVIDER_STATE_DESC,
    PROVIDER_PHONE,
    ADD_IONS,
    EXTRACT_KEY,
    PROVIDER_ZIP_KEY,
    NATIONAL_PROV_ID,
    TAXONOMY_CD,
    REND_NATIONAL_PROV_ID,
    REND_TAXONOMY_CD,
    REND_PROV_NAME
    )
    SELECT  /*+ PARALLEL(8) */
    A.OPREC_BILL_LINE_NUMBER,
    A.CLAIM_NUMBER,
    A.ACCOUNT_NUMBER,
    A.ZIP_CODE,
    A.STATE_CODE,
    A.UNDERWRITE_CODE,
    A.BASE_PLAN_CODE,
    A.TOS_CODE,
    A.CPT_CODE,
    A.ICD_1,
    A.ICD_2,
    A.ICD_3,
    A.ICD_IND,
    A.PLAN_EFF_MONTH,
    A.PLAN_TERM_MONTH,
    A.BILL_INCURRAL_DATE,
    A.PROCESS_DATE,
    A.SERVICE_FROM_DATE,
    A.SERVICE_TO_DATE,
    A.BENEFIT_PERIOD_DAYS,
    A.BENEFIT_AMT,
    A.MEDICARE_APPROVED_AMT,
    A.MEDICARE_PAYMENT_AMT,
    A.DEDUCTIBLE_AMT,
    A.PART_B_DEDUCT,
    A.REMARK_CODE,
    A.BILL_ASSIGN_IND,
    A.CHARGE_AMT,
    A.PROCEDURE_CODE,
    A.MEDICARE_ASSIGN_IND,
    A.INSURED_AGE,
    A.EOB_TYPE,
    A.MODIFIER_1,
    A.MODIFIER_2,
    A.HOSP_DAYS,
    A.SNF_DAYS,
    CASE WHEN NVL(A.INDIVIDUAL_ID, -1) = -1 THEN nvl(hphm.individual_id, -1) ELSE A.INDIVIDUAL_ID END AS INDIVIDUAL_ID,
    A.PLACE_SERVICE_CODE,
    A.BL_MED_TOS_CODE,
    A.CHECK_TYPE_IND,
    A.MED_COINS_AMT,
    A.MED_COPAY_AMT,
    A.RECEIPT_DATE,
    A.ADJUST_BENEFIT_AMOUNT,
    A.LOB_PLAN_CD,
    A.DATE_OF_BIRTH,
    A.GENDER_CD,
    A.MEDICARE_CLAIM_NUM,
    A.ASSIGNEE_PROVIDER_KEY,
    A.PROVIDER_ID,
    A.TAX_ID_NUMBER,
    A.PROVIDER_NAME,
    A.PROVIDER_ADDRESS_1,
    A.PROVIDER_ADDRESS_2,
    A.PROVIDER_CITY,
    A.PROVIDER_ZIP,
    A.PROVIDER_STATE,
    A.PROVIDER_STATE_DESC,
    A.PROVIDER_PHONE,
    A.ADD_IONS,
    A.EXTRACT_KEY,
    A.PROVIDER_ZIP_KEY,
    A.NATIONAL_PROV_ID,
    A.TAXONOMY_CD,
    A.REND_NATIONAL_PROV_ID,
    A.REND_TAXONOMY_CD,
    A.RNDR_PROV_NM
    FROM (
            SELECT
            /*+ PARALLEL(8) */ DISTINCT
            OBLH.BIL_LN_NBR          OPREC_BILL_LINE_NUMBER,
           LPAD( OBLH.CLM_NBR ,12,''0'')            CLAIM_NUMBER,
            case when MBR.CURR_ACCT_NBR = ''-1'' then OBLH.ACCT_NBR ELSE MBR.CURR_ACCT_NBR END   ACCOUNT_NUMBER ,
             DECODE(LENGTH(TRIM(DG.ZIP_CD)),5 ,TRIM(DG.ZIP_CD),'' '' )               ZIP_CODE ,
            DG.D_ST_CD               STATE_CODE,
            CASE
                WHEN SUBSTR(UT.UNDWR_PLN_RQR_TXT,1,3) =''U/W''
                THEN ''Y''
                WHEN SUBSTR(UT.UNDWR_PLN_RQR_TXT,1,7) =''Not U/W''
                THEN
                    /* CASE
                        WHEN INSTR(UT.UNDWR_PLN_RQR_TXT,''Open Enrollment'',8)> 0
                        OR  INSTR(UT.UNDWR_PLN_RQR_TXT,''Plan Change'',8)> 0
                        THEN ''W''
                        ELSE ''N''
                    END */				-------OAS DELETE
				CASE WHEN 
						(CASE WHEN POSITION(''Open Enrollment'' IN SUBSTR(UT.UNDWR_PLN_RQR_TXT, 8)) > 0
								THEN POSITION(''Open Enrollment'' IN SUBSTR(UT.UNDWR_PLN_RQR_TXT, 8)) + 7
							ELSE 0
						END) > 0 
						OR 
						(CASE WHEN POSITION(''Plan Change'' IN SUBSTR(UT.UNDWR_PLN_RQR_TXT, 8)) > 0
								THEN POSITION(''Plan Change'' IN SUBSTR(UT.UNDWR_PLN_RQR_TXT, 8)) + 7
								ELSE 0
						END) > 0 
					THEN ''W'' 
					ELSE ''N'' 
				END					---------OAS ADD
                ELSE ''B''
            END                    AS UNDERWRITE_CODE,
            case when length(dcp.COMPAS_PLN_CD) = 3 and (dcp.COMPAS_PLN_CD like ''%02%'' or dcp.COMPAS_PLN_CD like ''%S2%'' )
                and dcp.PRDCT =''Med Supp'' and dcp.PLN_GRP like ''%Modernize%''
                then replace(dcp.COMPAS_PLN_CD, ''2'', ''1'')
                else dcp.COMPAS_PLN_CD end AS BASE_PLAN_CODE,
            DT.TOS_CD AS TOS_CODE,
            NULL CPT_CODE,
            NULL ICD_1,
            NULL ICD_2,
            NULL ICD_3,
            ''U'' ICD_IND,
            TO_NUMBER (TO_CHAR(TO_DATE(TO_CHAR(DECODE(OBLH.CERT_EFF_DT_ID,-1,99991231,OBLH.CERT_EFF_DT_ID)),''YYYYMMDD''
            ),''YYYYMM'')) PLAN_EFF_MONTH ,
            NULL PLAN_TERM_MONTH,
            OBLH.INCUR_DT_ID        BILL_INCURRAL_DATE,
            OBLH.CMPL_DT_ID         PROCESS_DATE,
            OBLH.SRVC_FROM_DT_ID    SERVICE_FROM_DATE,
            OBLH.SRVC_TO_DT_ID      SERVICE_TO_DATE,
            NULL         AS         BENEFIT_PERIOD_DAYS,
            OBLH.OCRS_BEN_AMT       BENEFIT_AMT,
            NULL         AS         MEDICARE_APPROVED_AMT,
            NULL         AS         MEDICARE_PAYMENT_AMT,
            NULL         AS         DEDUCTIBLE_AMT,
            NULL         AS         PART_B_DEDUCT,
            NULL         AS         REMARK_CODE,
            NULL         AS         BILL_ASSIGN_IND,
            NULL         AS         CHARGE_AMT,
            NULL         AS         PROCEDURE_CODE ,
            NULL         AS         MEDICARE_ASSIGN_IND,
            OBLH.PREM_DUE_AGE_ID AS INSURED_AGE,
            NULL         AS         EOB_TYPE ,
            NULL         AS         MODIFIER_1 ,
            NULL         AS         MODIFIER_2 ,
            0         AS         HOSP_DAYS ,
            0         AS         SNF_DAYS,
            MBR.CURR_INDV_ID AS INDIVIDUAL_ID,
            NULL         AS         PLACE_SERVICE_CODE,
            NULL         AS         BL_MED_TOS_CODE ,
            OBLH.D_CLM_TYP_IND      CHECK_TYPE_IND,
            NULL         AS         MED_COINS_AMT,
           0            AS         MED_COPAY_AMT,
		   
/*	-----------------OAS DELETE -- COMMENTING AS THER IS A TEMPORARY TABLE CABLE CREATED ABOVE TO FETCH VALUE FOR THIS COLUMN--------------------------
		
			to_number(to_char(to_date(
			    CASE
			        WHEN to_number(substr(
			            CASE
			                WHEN substr(NVL(substr(lpad(oblh.chk_dt_id, 8, 0), 1, 3), '''')
			                            || NVL(substr(CASE WHEN D_CLM_TYP_IND = 2 THEN rpad(oblh.clm_nbr, 11, 0) 
			                            ELSE lpad(oblh.clm_nbr, 12, 0) END, 1, 4), ''''), 1, 4) > to_char(CURRENT_TIMESTAMP, ''YYYY'') THEN
			                    to_number(nvl(substr(lpad(oblh.chk_dt_id, 8, 0), 1, 3), '''')
			                              || nvl(substr(CASE WHEN D_CLM_TYP_IND = 2 THEN rpad(oblh.clm_nbr, 11, 0) ELSE lpad(oblh.clm_nbr, 12, 0) END, 1, 4), '''')) - 10000
			                ELSE
			                    to_number(nvl(substr(lpad(oblh.chk_dt_id, 8, 0), 1, 3), '''')
			                              || nvl(substr(CASE WHEN D_CLM_TYP_IND = 2 THEN rpad(oblh.clm_nbr, 11, 0) ELSE lpad(oblh.clm_nbr, 12, 0) END, 1, 4), ''''))
			            END, 5, 3)) > 366 THEN
			            to_number(
			                CASE
			                    WHEN substr(nvl(substr(lpad(oblh.chk_dt_id, 8, 0), 1, 3), '''')
			                                || nvl(substr(CASE WHEN D_CLM_TYP_IND = 2 THEN rpad(oblh.clm_nbr, 11, 0) ELSE lpad(oblh.clm_nbr, 12, 0) END, 1, 4), ''''), 1, 4) > to_char(CURRENT_TIMESTAMP, ''YYYY'') THEN
			                        to_number(nvl(substr(lpad(oblh.chk_dt_id, 8, 0), 1, 3), '''')
			                                  || nvl(substr(CASE WHEN D_CLM_TYP_IND = 2 THEN rpad(oblh.clm_nbr, 11, 0) ELSE lpad(oblh.clm_nbr, 12, 0) END, 1, 4), '''')) - 10000
			                    ELSE
			                        to_number(nvl(substr(lpad(oblh.chk_dt_id, 8, 0), 1, 3), '''')
			                                  || nvl(substr(CASE WHEN D_CLM_TYP_IND = 2 THEN rpad(oblh.clm_nbr, 11, 0) ELSE lpad(oblh.clm_nbr, 12, 0) END, 1, 4), ''''))
			                END
			            )- :v_receipt_num
			        ELSE
			            CASE
			                WHEN substr(nvl(substr(lpad(oblh.chk_dt_id, 8, 0), 1, 3), '''')
			                            || nvl(substr(CASE WHEN D_CLM_TYP_IND = 2 THEN rpad(oblh.clm_nbr, 11, 0) ELSE lpad(oblh.clm_nbr, 12, 0) END, 1, 4), ''''), 1, 4) > to_char(CURRENT_TIMESTAMP, ''YYYY'') THEN
			                    to_number(nvl(substr(lpad(oblh.chk_dt_id, 8, 0), 1, 3), '''')
			                              || nvl(substr(CASE WHEN D_CLM_TYP_IND = 2 THEN rpad(oblh.clm_nbr, 11, 0) ELSE lpad(oblh.clm_nbr, 12, 0) END, 1, 4), '''')) - 10000
			                ELSE
			                    to_number(nvl(substr(lpad(oblh.chk_dt_id, 8, 0), 1, 3), '''')
			                              || nvl(substr(CASE WHEN D_CLM_TYP_IND = 2 THEN rpad(oblh.clm_nbr, 11, 0) ELSE lpad(oblh.clm_nbr, 12, 0) END, 1, 4), ''''))
			            END
			    END, ''yyyyddd''), ''yyyymmdd'')) AS RECEIPT_DATE,

	----------------- OAS DELETE -- COMMENTING AS THER IS A TEMPORARY TABLE CABLE CREATED ABOVE TO FETCH VALUE FOR THIS COLUMN--------------------------
*/			
			JDH.RECEIPT_DATE AS RECEIPT_DATE,	-------------------------------OAS ADD
            NULL                    AS     ADJUST_BENEFIT_AMOUNT,
            case when length(dcp.COMPAS_PLN_CD) = 3 and (dcp.COMPAS_PLN_CD like ''%02%'' or dcp.COMPAS_PLN_CD like ''%S2%'' )
                and dcp.PRDCT =''Med Supp'' and dcp.PLN_GRP like ''%Modernize%''
                then replace(dcp.COMPAS_PLN_CD, ''2'', ''1'')
                else dcp.COMPAS_PLN_CD end AS LOB_PLAN_CD,
            MBR.DOB_ID  AS DATE_OF_BIRTH,
            MBR.GDR_CD AS GENDER_CD,
            MBR.MEDCR_CLM_NBR AS MEDICARE_CLAIM_NUM,
            NULL           AS ASSIGNEE_PROVIDER_KEY ,   --- nEED CONFIRMATION, MENTIONED DIFFERENT RULE
            NULL                AS    PROVIDER_ID ,
            OBLH.TIN            AS    TAX_ID_NUMBER ,
            OBLH.PROV_NM   		AS PROVIDER_NAME,
            NULL 		      AS PROVIDER_ADDRESS_1 ,
            NULL 		      AS PROVIDER_ADDRESS_2 ,
            NULL 		      AS PROVIDER_CITY ,
            NULL 		      AS PROVIDER_ZIP,
            NULL 		      AS PROVIDER_STATE,
            NULL 		      AS PROVIDER_STATE_DESC ,
            NULL 		      AS PROVIDER_PHONE,
            NULL 		      AS ADD_IONS,
            NULL 		      AS EXTRACT_KEY , --REQUESTED LOAD DATE ID NEED CONFIRMATION
            NULL 		      AS PROVIDER_ZIP_KEY ,
            NULL 		      AS NATIONAL_PROV_ID,
            NULL 		      AS TAXONOMY_CD,
            NULL 		      AS REND_NATIONAL_PROV_ID ,
            NULL 		      AS REND_TAXONOMY_CD,
            NULL 		      AS RNDR_PROV_NM
        FROM BDR_DM.F_OCRS_BIL_LN_HIST      OBLH
		JOIN JULIAN_DATE_HANDLE JDH ON OBLH.F_OCRS_BIL_LN_HIST_SK = JDH.F_OCRS_BIL_LN_HIST_SK	-------------------OAS ADD
        JOIN  BDR_DM.D_CLM_PLN dcp      ON  OBLH.D_CLM_PLN_SK = dcp.D_CLM_PLN_SK
        JOIN BDR_DM.D_TOS DT                  ON OBLH.D_TOS_SK = DT.D_TOS_SK
        JOIN BDR_CONF.d_mbr_info MBR ON OBLH.d_mbr_info_sk = MBR.d_mbr_info_sk

     /* LEFT OUTER JOIN (SELECT DISTINCT ACCOUNT_NUMBER ,
            INDIVIDUAL_ID ,
            EXTRACT_TYPE ,
            INSURED_PLAN_EFFECTIVE_DATE,
            INSURED_PLAN_TERMINATION_DATE FROM DM.RPT_IGX_MEMBER_MEDSUPP Q1
            WHERE EXTRACT_TYPE = ''MEDSUPP'' ) IMM

         ON     MBR.CURR_ACCT_NBR = IMM.ACCOUNT_NUMBER
            AND MBR.CURR_INDV_ID = IMM.INDIVIDUAL_ID
           -- AND IMM.EXTRACT_TYPE = ''MEDSUPP''
            AND  TO_NUMBER (TO_CHAR(TO_DATE(DECODE(OBLH.CERT_EFF_DT_ID,-1,99991231,OBLH.CERT_EFF_DT_ID),''YYYYMMDD''
            ),''YYYYMM''))  = SUBSTR (TO_CHAR (IMM.INSURED_PLAN_EFFECTIVE_DATE), 1, 6)
            */


         JOIN BDR_CONF.D_UNDWR_TAG UT             ON  OBLH.D_UNDWR_TAG_SK= UT.D_UNDWR_TAG_SK
         JOIN BDR_CONF.D_GEO_XREF DG           ON  OBLH.RES_D_GEO_XREF_SK = DG.D_GEO_XREF_SK
        --- JOIN ETL.ETL_BATCH_LOG  EL        ON  OBLH.ETL_LST_BTCH_ID = EL.BATCH_ID
          WHERE
                DT.TOS_GL_ACCT_CD <>''50300''
                AND  dcp.PRDCT =''Med Supp''
                AND  OBLH.CLM_PD_DT_ID between :v_extract_key_low and  :v_extract_key_high
                ) A
                LEFT OUTER JOIN
      (SELECT hm.individual_id,
               hp.membership_number,
               hp.association_id,
               hm.insured_cd
          FROM SRC_COMPAS_D.household_profile hp, SRC_COMPAS_D.household_member hm
         WHERE     hp.household_id = hm.household_id
        AND :v_extract_date BETWEEN HM.HHOLD_MEMBER_START_DATE AND NVL (HM.HHOLD_MEMBER_STOP_DATE,
            TO_DATE (''31-DEC-9999'',''DD-MON-YYYY'') )
        AND :v_extract_date BETWEEN HP.HHOLD_PROFILE_START_DATE AND NVL (HP.HHOLD_PROFILE_STOP_DATE,
            TO_DATE (''31-DEC-9999'',''DD-MON-YYYY'') )
               AND NVL (hp.delete_ind, ''N'') <> ''Y'') hphm
            ON     TO_NUMBER(A.ACCOUNT_NUMBER) = TO_NUMBER ( NVL(TO_CHAR(hphm.MEMBERSHIP_NUMBER), '''') || NVL(TO_CHAR(hphm.ASSOCIATION_ID), '''') || NVL(TO_CHAR(hphm.INSURED_CD), '''') ) ;
    	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

-------------------COMMNETED BY OAS-----------------------
/*         v_rows_inserted := SQL%ROWCOUNT;
         COMMIT;
        INSERT
        INTO
            ETL.ETL_DETAIL_LOAD_INFO
            (
                APPLICATION ,
                ETL_PROC_NAME ,
                ACTION ,
                STEP_INFO ,
                ROWS_AFFECTED ,
                ETL_DATETIME
            )
            VALUES
            (
                ''OPTUMHEALTHFEEDRPT'',
                v_proc_name,
                ''INSERT'',
                ''ROWS INSERTED'',
                v_rows_inserted,
                SYSTIMESTAMP
            );

        COMMIT;
      END;

      BEGIN
                                           -- analyze IGX_CLAIMS_OCRS_MEDSUPP
         DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''RPT_IGX_CLAIMS_OCRS_MEDSUPP'');


      END;

      COMMIT;
       INSERT
        INTO
            ETL.ETL_DETAIL_LOAD_INFO
            (
                APPLICATION ,
                ETL_PROC_NAME ,
                ACTION ,
                STEP_INFO ,
                ROWS_AFFECTED ,
                ETL_DATETIME
            )
            VALUES
            (
                ''OPTUMHEALTHFEEDRPT'',
                v_proc_name,
                ''END'',
                ''PROC EXECUTION COMPLETED'',
                0,
                SYSTIMESTAMP
            );

        COMMIT;
   EXCEPTION
      WHEN OTHERS
      THEN
          v_err_message :=SQLERRM;
    INSERT
    INTO
        ETL.ETL_DETAIL_LOAD_INFO
        (
            APPLICATION ,
            ETL_BATCH_ID,
            ETL_PROC_NAME ,
            ACTION ,
            STEP_INFO ,
            ROWS_AFFECTED ,
            ETL_DATETIME
        )
        VALUES
        (
            ''OPTUMHEALTHFEEDRPT'',
            NULL,
            v_proc_name,
            ''E'',
            v_err_message ,
            0,
            SYSTIMESTAMP
        );

   DBMS_OUTPUT.PUT_LINE(''ERROR: '' || SQLCODE || ''-'' || SQLERRM || ''-'' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE()|| Chr(10)||DBMS_UTILITY.FORMAT_ERROR_STACK());
    RAISE;
   END;

--------------------DM.PKG_INGENIX_EXTRACT.pr_extract_claims_ocrs ENDS--------------------


--------------------DM.PKG_INGENIX_EXTRACT.pr_extract_rx_claims BEGINS--------------------

-- Purpose: Extract Pharmacy Claims
--

-- ---------   ------  -------------------------------------------

  PROCEDURE pr_extract_rx_claims (
      p_extract_key_low    IN   NUMBER,
      p_extract_key_high   IN   NUMBER,
      p_extract_type       IN   VARCHAR2,
      p_extract_date       IN   DATE
   )
   IS
      v_sql                VARCHAR2 (5000);
      v_rows_inserted      NUMBER;
      v_run_date           DATE;
      v_proc_name          VARCHAR2 (30)            := ''pr_extract_rx_claims'';
      v_extract_key_low    NUMBER (8, 0);
      v_extract_key_high   NUMBER (8, 0);
      v_extract_type       VARCHAR2(50);
      v_extract_date       DATE;
      v_err_message        VARCHAR2(2000);
      V_BL_NO_PAY_IND_O VARCHAR2 (1);
      V_BL_NO_PAY_IND_U VARCHAR2 (1);
      V_TOS_CD_B4 VARCHAR2(2);
      V_TOS_CD_B5 VARCHAR2(2);
      V_ADJD_YES_NO_IND VARCHAR2(1);
      V_PRDCT VARCHAR2 (10);
      V_TOS_GL_ACCT_CD VARCHAR2(5);

   BEGIN

INSERT
    INTO
        ETL.ETL_DETAIL_LOAD_INFO
        (
            APPLICATION ,
            ETL_BATCH_ID,
            ETL_PROC_NAME ,
            ACTION ,
            STEP_INFO ,
            ROWS_AFFECTED ,
            ETL_DATETIME
        )
        VALUES
        (
            ''OPTUMHEALTHFEEDRPT'',
            NULL,
            v_proc_name,
            ''START'',
            ''PROCEDURE STARTS'',
            0,
            SYSTIMESTAMP
        );
COMMIT;


      BEGIN
         v_extract_key_low := p_extract_key_low;
         v_extract_key_high := p_extract_key_high;
         v_extract_type := p_extract_type;
         v_extract_date := p_extract_date;			*/	
 -------------------------------------COMMENTED BY OAS---------------------------------------  -
		 
      /* V_BL_NO_PAY_IND_O := ''0'';
      V_BL_NO_PAY_IND_U := ''U'';
      V_TOS_CD_B4 := ''B4'';
      V_TOS_CD_B5 := ''B5'';
      V_ADJD_YES_NO_IND := ''Y'';
      V_PRDCT := ''Med Supp'';
      V_TOS_GL_ACCT_CD := ''50300''; */		---------------OAS DELETE---SAME VALUES ARE ALREADY ASSIGNED AT THE TOP


-------------------------------------COMMENTED BY OAS---------------------------------------  -
/*  INSERT
INTO
    ETL.ETL_DETAIL_LOAD_INFO
    (
        APPLICATION ,
        ETL_BATCH_ID,
        ETL_PROC_NAME ,
        ACTION ,
        STEP_INFO ,
        ROWS_AFFECTED ,
        ETL_DATETIME
    )
    VALUES
    (
        ''OPTUMHEALTHFEEDRPT'',
        NULL,
        v_proc_name,
        ''Value of v_extract_date'',
        v_extract_date,
        0,
        SYSTIMESTAMP
    );
COMMIT;

        INSERT
INTO
    ETL.ETL_DETAIL_LOAD_INFO
    (
        APPLICATION ,
        ETL_BATCH_ID,
        ETL_PROC_NAME ,
        ACTION ,
        STEP_INFO ,
        ROWS_AFFECTED ,
        ETL_DATETIME
    )
    VALUES
    (
        ''OPTUMHEALTHFEEDRPT'',
        NULL,
        v_proc_name,
        ''Value of v_extract_key_low'',
        v_extract_key_low,
        0,
        SYSTIMESTAMP
    );
COMMIT;


INSERT
INTO
    ETL.ETL_DETAIL_LOAD_INFO
    (
        APPLICATION ,
        ETL_BATCH_ID,
        ETL_PROC_NAME ,
        ACTION ,
        STEP_INFO ,
        ROWS_AFFECTED ,
        ETL_DATETIME
    )
    VALUES
    (
        ''OPTUMHEALTHFEEDRPT'',
        NULL,
        v_proc_name,
        ''Value of v_extract_key_high'',
        v_extract_key_high,
        0,
        SYSTIMESTAMP
    );
COMMIT;

INSERT
INTO
    ETL.ETL_DETAIL_LOAD_INFO
    (
        APPLICATION ,
        ETL_BATCH_ID,
        ETL_PROC_NAME ,
        ACTION ,
        STEP_INFO ,
        ROWS_AFFECTED ,
        ETL_DATETIME
    )
    VALUES
    (
        ''OPTUMHEALTHFEEDRPT'',
        NULL,
        v_proc_name,
        ''Value of v_extract_type'',
        v_extract_type,
        0,
        SYSTIMESTAMP
    );
COMMIT;

      END;

      BEGIN		*/		
-------------------------------------COMMENTED BY OAS---------------------------------------  -

	  -- truncate IGX_RX_CLAIMS_MEDSUPP
	    
V_STEP_NAME    := ''TRUNCATE - RPT_IGX_RX_CLAIMS_MEDSUPP'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

         v_sql :=
                 ''TRUNCATE TABLE BDR_DM.RPT_IGX_RX_CLAIMS_MEDSUPP'';

         EXECUTE IMMEDIATE :v_sql;

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

         -- analyze DM.RPT_IGX_RX_CLAIMS_MEDSUPP
/*         DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''RPT_IGX_RX_CLAIMS_MEDSUPP'');

      END;

      BEGIN		*/		--------------OAS DELETE
	    
V_STEP_NAME    := ''INSERT - RPT_IGX_RX_CLAIMS_MEDSUPP'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

    INSERT /*+ ENABLE_PARALLEL_DML APPEND */ INTO BDR_DM.RPT_IGX_RX_CLAIMS_MEDSUPP
    (
    INDIVIDUAL_ID,
    ACCOUNT_NUMBER,
    BL_DRUG_NDC_NUMBER,
    FILL_DATE,
    CHECK_TYPE_IND,
    PHARM_NBR,
    CLAIM_NUMBER,
    BILL_LINE_NUMBER,
    TOS_CODE,
    BL_DRUG_RX_NO,
    BL_DRUG_FILL_NUMBER,
    BL_DRUG_DAYS_SUPPLY,
    BL_DRUG_STRENGTH,
    BL_DRUG_QUANTITY,
    SERVICE_FROM_DATE,
    SERVICE_TO_DATE,
    CLAIM_PAID_DATE,
    ICD_1,
    ICD_IND,
    BL_DRUG_CHARGE_AMT,
    BL_DRUG_DEDUCTIBLE_AMT,
    BL_DRUG_PAYMENT_AMT,
    RX_COPAY_AMT,
    RX_DISC_AMT,
    RX_COINS_AMT,
    BASE_PLAN_CODE,
    ADJUST_BENEFIT_AMOUNT,
    LOB_PLAN_CD,
    DATE_OF_BIRTH,
    GENDER_CD,
    MEDICARE_CLAIM_NUM
    )
    SELECT /*+ PARALLEL(8) */
    case when A.INDIVIDUAL_ID = -1 then nvl(hphm.individual_id, -1) else A.INDIVIDUAL_ID end INDIVIDUAL_ID,
    A.ACCOUNT_NUMBER,
    A.BL_DRUG_NDC_NUMBER,
    A.FILL_DATE,
    A.CHECK_TYPE_IND,
    A.PHARM_NBR,
    A.CLAIM_NUMBER,
    A.BILL_LINE_NUMBER,
    A.TOS_CODE,
    A.BL_DRUG_RX_NO,
    A.BL_DRUG_FILL_NUMBER,
    A.BL_DRUG_DAYS_SUPPLY,
    A.BL_DRUG_STRENGTH,
    A.BL_DRUG_QUANTITY,
    A.SERVICE_FROM_DATE,
    A.SERVICE_TO_DATE,
    A.CLAIM_PAID_DATE,
    A.ICD_1,
    A.ICD_IND,
    A.BL_DRUG_CHARGE_AMT,
    A.BL_DRUG_DEDUCTIBLE_AMT,
    A.BL_DRUG_PAYMENT_AMT,
    A.RX_COPAY_AMT,
    A.RX_DISC_AMT,
    A.RX_COINS_AMT,
    A.BASE_PLAN_CODE,
    A.ADJUST_BENEFIT_AMOUNT,
    A.LOB_PLAN_CD,
    A.DATE_OF_BIRTH,
    A.GENDER_CD,
    A.MEDICARE_CLAIM_NUM
FROM (
            SELECT
            /*+ PARALLEL(8) */ DISTINCT
            MBR.CURR_INDV_ID AS INDIVIDUAL_ID,
            case when MBR.CURR_ACCT_NBR = ''-1'' then BLH.ACCT_NBR ELSE MBR.CURR_ACCT_NBR END   ACCOUNT_NUMBER,
            ECRXBL.EC_BL_NDC_NBR             BL_DRUG_NDC_NUMBER ,
            ECRXBL.EC_BL_DT_SRVC_FROM_ID     FILL_DATE ,
            NULL       AS                    CHECK_TYPE_IND ,
            NULL       AS                    PHARM_NBR,
            LPAD(BLH.CLM_NBR,12,''0'')         CLAIM_NUMBER,
            BLH.BIL_LN_NBR                   BILL_LINE_NUMBER,
            DT.TOS_CD                        TOS_CODE ,
            ECRXBL.EC_BL_PRSC_NBR            BL_DRUG_RX_NO,
            ECRXBL.EC_BL_FILL_NBR            BL_DRUG_FILL_NUMBER ,
            TO_NUMBER(ECRXBL.EC_BL_DAY_SPL)  BL_DRUG_DAYS_SUPPLY ,
            CASE WHEN SUBSTR(ECRXBL.EC_BL_STRGTH,LENGTH(ECRXBL.EC_BL_STRGTH),1)=''0''
                  AND SUBSTR(ECRXBL.EC_BL_STRGTH,(LENGTH(ECRXBL.EC_BL_STRGTH)-1),1)<>''.''
             THEN    LTRIM(SUBSTR(ECRXBL.EC_BL_STRGTH,1,(LENGTH(ECRXBL.EC_BL_STRGTH)-1)),''0'')
             ELSE LTRIM((ECRXBL.EC_BL_STRGTH),''0'')END AS BL_DRUG_STRENGTH ,
            --TRIM(LEADING 0 FROM TRIM(ECRXBL.EC_BL_QTY)) AS BL_DRUG_QUANTITY ,					-------------------------------OAS DELETE
			LTRIM(TRIM(ECRXBL.EC_BL_QTY), ''0'') AS BL_DRUG_QUANTITY,								-------------------------------OAS ADD
            ECRXBL.EC_BL_DT_SRVC_FROM_ID     SERVICE_FROM_DATE,
            ECRXBL.EC_BL_DT_SRVC_TO_ID       SERVICE_TO_DATE ,
            ECRXBL.EC_BL_DT_SRVC_FROM_ID     CLAIM_PAID_DATE ,
            NULL      AS                     ICD_1,
            ''U''       AS                     ICD_IND,
            ECRXBL.EC_BL_CHRG_AMT            BL_DRUG_CHARGE_AMT,
            ECRXBL.EC_BL_DED_AMT             BL_DRUG_DEDUCTIBLE_AMT ,
            ECRXBL.EC_BL_PAY_AMT             BL_DRUG_PAYMENT_AMT,
            NULL      AS                     RX_COPAY_AMT,
            NULL      AS                     RX_DISC_AMT,
            NULL      AS                     RX_COINS_AMT,
            case when length(dcp.COMPAS_PLN_CD) = 3 and (dcp.COMPAS_PLN_CD like ''%02%'' or dcp.COMPAS_PLN_CD like ''%S2%'' )
                and dcp.PRDCT =''Med Supp'' and dcp.PLN_GRP like ''%Modernize%''
                then replace(dcp.COMPAS_PLN_CD, ''2'', ''1'')
                else dcp.COMPAS_PLN_CD end BASE_PLAN_CODE,
            NULL      AS                     ADJUST_BENEFIT_AMOUNT,
            case when length(dcp.COMPAS_PLN_CD) = 3 and (dcp.COMPAS_PLN_CD like ''%02%'' or dcp.COMPAS_PLN_CD like ''%S2%'' )
                and dcp.PRDCT =''Med Supp'' and dcp.PLN_GRP like ''%Modernize%''
                then replace(dcp.COMPAS_PLN_CD, ''2'', ''1'')
                else dcp.COMPAS_PLN_CD end LOB_PLAN_CD,
            MBR.DOB_ID AS DATE_OF_BIRTH,
            MBR.GDR_CD AS GENDER_CD,
            MBR.MEDCR_CLM_NBR  AS MEDICARE_CLAIM_NUM
FROM
        BDR_DM.F_CLM_HIST CH
        JOIN  BDR_DM.F_CLM_BIL_LN_HIST BLH    ON  CH.F_CLM_HIST_SK= BLH.F_CLM_HIST_SK
       -- JOIN  CONF.D_PLN_BEN_MOD PBM      ON  BLH.D_PLN_BEN_MOD_SK = PBM.D_PLN_BEN_MOD_SK
       JOIN BDR_DM.D_CLM_PLN dcp ON BLH.D_CLM_PLN_SK = dcp.D_CLM_PLN_SK
       JOIN BDR_CONF.d_mbr_info MBR ON BLH.d_mbr_info_sk = MBR.d_mbr_info_sk

       /* LEFT OUTER JOIN (SELECT DISTINCT ACCOUNT_NUMBER ,
            INDIVIDUAL_ID ,
            EXTRACT_TYPE ,
            INSURED_PLAN_EFFECTIVE_DATE,
            INSURED_PLAN_TERMINATION_DATE FROM DM.RPT_IGX_MEMBER_MEDSUPP Q1
            WHERE EXTRACT_TYPE = ''MEDSUPP'' ) IMM

         ON     MBR.CURR_ACCT_NBR = IMM.ACCOUNT_NUMBER
            AND MBR.CURR_INDV_ID = IMM.INDIVIDUAL_ID
           -- AND IMM.EXTRACT_TYPE = ''MEDSUPP''
            AND  TO_NUMBER (TO_CHAR(TO_DATE(DECODE(BLH.CERT_EFF_DT_ID,-1,99991231,BLH.CERT_EFF_DT_ID),''YYYYMMDD''
            ),''YYYYMM''))  = SUBSTR (TO_CHAR (IMM.INSURED_PLAN_EFFECTIVE_DATE), 1, 6) */

        JOIN BDR_DM.D_TOS DT                    ON  BLH.D_TOS_SK = DT.D_TOS_SK
        LEFT JOIN BDR_DM.D_EC_RX_BL ECRXBL           ON CH.D_EC_RX_SK = ECRXBL.D_EC_RX_SK and BLH.BIL_LN_NBR = ecrxbl.ec_bl_nbr
       ---- JOIN ETL.ETL_BATCH_LOG  EL          ON  CH.ETL_LST_BTCH_ID = EL.BATCH_ID
        WHERE
              DT.TOS_GL_ACCT_CD = :V_TOS_GL_ACCT_CD
and    (   BLH.BL_NO_PAY_IND = :V_BL_NO_PAY_IND_O
              OR (  BLH.BL_NO_PAY_IND = :V_BL_NO_PAY_IND_U
                  AND BLH.TOS_CD IN (:V_TOS_CD_B4 , :V_TOS_CD_B5 )))

              AND  dcp.PRDCT = :V_PRDCT  ---- AND LENGTH(PBM.COMPAS_PLN_CD)<3
              AND  CH.CLM_PD_DT_ID between :v_extract_key_low and  :v_extract_key_high) A
      LEFT OUTER JOIN
      (SELECT  hm.individual_id,
               hp.membership_number,
               hp.association_id,
               hm.insured_cd
         FROM SRC_COMPAS_D.household_profile hp, SRC_COMPAS_D.household_member hm
         WHERE     hp.household_id = hm.household_id
        AND :v_extract_date BETWEEN HM.HHOLD_MEMBER_START_DATE AND NVL (HM.HHOLD_MEMBER_STOP_DATE,
            TO_DATE (''31-DEC-9999'',''DD-MON-YYYY'') )
        AND :v_extract_date BETWEEN HP.HHOLD_PROFILE_START_DATE AND NVL (HP.HHOLD_PROFILE_STOP_DATE,
            TO_DATE (''31-DEC-9999'',''DD-MON-YYYY'') )
               AND NVL (hp.delete_ind, ''N'') <> ''Y'') hphm
            ON    TO_NUMBER( A.ACCOUNT_NUMBER) = TO_NUMBER ( NVL(TO_CHAR(hphm.MEMBERSHIP_NUMBER), '''') || NVL(TO_CHAR(hphm.ASSOCIATION_ID), '''') || NVL(TO_CHAR(hphm.INSURED_CD), '''') ) ;
    	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

-------------------------------------COMMENTED BY OAS---------------------------------------  -
/*         v_rows_inserted := SQL%ROWCOUNT;
         COMMIT;

          INSERT
        INTO
            ETL.ETL_DETAIL_LOAD_INFO
            (
                APPLICATION ,
                ETL_PROC_NAME ,
                ACTION ,
                STEP_INFO ,
                ROWS_AFFECTED ,
                ETL_DATETIME
            )
            VALUES
            (
                ''OPTUMHEALTHFEEDRPT'',
                v_proc_name,
                ''INSERT'',
                ''pHARMACY RX ROWS INSERTED'',
                v_rows_inserted,
                SYSTIMESTAMP
            );

        COMMIT;

      END;



      BEGIN                          -- analyze DM.RPT_IGX_RX_CLAIMS_MEDSUPP
         DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''RPT_IGX_RX_CLAIMS_MEDSUPP'');
      END;

      COMMIT;

   INSERT
        INTO
            ETL.ETL_DETAIL_LOAD_INFO
            (
                APPLICATION ,
                ETL_PROC_NAME ,
                ACTION ,
                STEP_INFO ,
                ROWS_AFFECTED ,
                ETL_DATETIME
            )
            VALUES
            (
                ''OPTUMHEALTHFEEDRPT'',
                v_proc_name,
                ''END'',
                ''PROC EXECUTION COMPLETED'',
                0,
                SYSTIMESTAMP
            );

        COMMIT;

   EXCEPTION
      WHEN OTHERS
      THEN
        v_err_message :=SQLERRM;
    INSERT
    INTO
        ETL.ETL_DETAIL_LOAD_INFO
        (
            APPLICATION ,
            ETL_BATCH_ID,
            ETL_PROC_NAME ,
            ACTION ,
            STEP_INFO ,
            ROWS_AFFECTED ,
            ETL_DATETIME
        )
        VALUES
        (
            ''OPTUMHEALTHFEEDRPT'',
            NULL,
            v_proc_name,
            ''E'',
            v_err_message ,
            0,
            SYSTIMESTAMP
        );

    DBMS_OUTPUT.PUT_LINE(''ERROR: '' || SQLCODE || ''-'' || SQLERRM || ''-'' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE()|| Chr(10)||DBMS_UTILITY.FORMAT_ERROR_STACK());

    RAISE;
   END;
   
--------------------DM.PKG_INGENIX_EXTRACT.pr_extract_rx_claims ENDS--------------------


--------------------DM.PKG_INGENIX_EXTRACT.pr_extract_rx_claims_ocrs BEGINS--------------------
--
-- Purpose: Extract Pharmacy OCRS Claims
--

-- ---------   ------  -------------------------------------------

PROCEDURE pr_extract_rx_claims_ocrs (
      p_extract_key_low    IN   NUMBER,
      p_extract_key_high   IN   NUMBER,
      p_extract_type       IN   VARCHAR2,
      p_extract_date       IN   DATE
   )
   IS
      v_sql                VARCHAR2 (5000);
      v_rows_inserted      NUMBER;
      v_run_date           DATE;
      v_proc_name          VARCHAR2 (30)       := ''pr_extract_rx_claims_ocrs'';
      v_extract_key_low    NUMBER (8, 0);
     v_extract_key_high   NUMBER (8, 0);
      v_extract_date       DATE;
      v_extract_type       VARCHAR2(50);
      v_err_message        VARCHAR2(2000);
   BEGIN

     INSERT
    INTO
        ETL.ETL_DETAIL_LOAD_INFO
        (
            APPLICATION ,
            ETL_BATCH_ID,
            ETL_PROC_NAME ,
            ACTION ,
            STEP_INFO ,
            ROWS_AFFECTED ,
            ETL_DATETIME
        )
        VALUES
        (
            ''OPTUMHEALTHFEEDRPT'',
            NULL,
            v_proc_name,
            ''START'',
            ''PROCEDURE STARTS'',
            0,
            SYSTIMESTAMP
        );
COMMIT;


      BEGIN
         v_extract_key_low := p_extract_key_low;
         v_extract_key_high := p_extract_key_high;
         v_extract_type := p_extract_type;
         v_extract_date := p_extract_date;


     INSERT
INTO
    ETL.ETL_DETAIL_LOAD_INFO
    (
        APPLICATION ,
        ETL_BATCH_ID,
        ETL_PROC_NAME ,
        ACTION ,
        STEP_INFO ,
        ROWS_AFFECTED ,
        ETL_DATETIME
    )
    VALUES
    (
        ''OPTUMHEALTHFEEDRPT'',
        NULL,
        v_proc_name,
        ''Value of v_extract_date'',
        v_extract_date,
        0,
        SYSTIMESTAMP
    );
COMMIT;




        INSERT
INTO
    ETL.ETL_DETAIL_LOAD_INFO
    (
        APPLICATION ,
        ETL_BATCH_ID,
        ETL_PROC_NAME ,
        ACTION ,
        STEP_INFO ,
        ROWS_AFFECTED ,
        ETL_DATETIME
    )
    VALUES
    (
        ''OPTUMHEALTHFEEDRPT'',
        NULL,
        v_proc_name,
        ''Value of v_extract_key_low'',
        v_extract_key_low,
        0,
        SYSTIMESTAMP
    );
COMMIT;


INSERT
INTO
    ETL.ETL_DETAIL_LOAD_INFO
    (
        APPLICATION ,
        ETL_BATCH_ID,
        ETL_PROC_NAME ,
        ACTION ,
        STEP_INFO ,
        ROWS_AFFECTED ,
        ETL_DATETIME
    )
    VALUES
    (
        ''OPTUMHEALTHFEEDRPT'',
        NULL,
        v_proc_name,
        ''Value of v_extract_key_high'',
        v_extract_key_high,
        0,
        SYSTIMESTAMP
    );
COMMIT;

INSERT
INTO
    ETL.ETL_DETAIL_LOAD_INFO
    (
        APPLICATION ,
        ETL_BATCH_ID,
        ETL_PROC_NAME ,
        ACTION ,
        STEP_INFO ,
        ROWS_AFFECTED ,
        ETL_DATETIME
    )
    VALUES
    (
        ''OPTUMHEALTHFEEDRPT'',
        NULL,
        v_proc_name,
        ''Value of v_extract_type'',
        v_extract_type,
        0,
        SYSTIMESTAMP
    );
COMMIT;

      END;

      BEGIN  		*/	
  -------------------------------------COMMENTED BY OAS---------------------------------------  -

  -- truncate IGX_RX_CLAIMS_OCRS_MEDSUPP
	  	    
V_STEP_NAME    := ''TRUNCATE - RPT_IGX_RX_CLAIMS_OCRS_MEDSUPP'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

         v_sql :=
            ''TRUNCATE TABLE BDR_DM.RPT_IGX_RX_CLAIMS_OCRS_MEDSUPP'';

         EXECUTE IMMEDIATE :v_sql;

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );


/*          DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''RPT_IGX_RX_CLAIMS_OCRS_MEDSUPP'');

      END;

      BEGIN  		*/		-------------------OAS DELETE

	  -- insert pharmacy ocrs to IGX_RX_CLAIMS_OCRS_MEDSUPP
	    
V_STEP_NAME    := ''INSERT - RPT_IGX_RX_CLAIMS_OCRS_MEDSUPP'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

        INSERT /*+ ENABLE_PARALLEL_DML APPEND */ INTO BDR_DM.RPT_IGX_RX_CLAIMS_OCRS_MEDSUPP
       (
            INDIVIDUAL_ID,
            ACCOUNT_NUMBER,
            BL_DRUG_NDC_NUMBER,
            FILL_DATE,
            CHECK_TYPE_IND,
            PHARM_NBR,
            CLAIM_NUMBER,
            BILL_LINE_NUMBER,
            TOS_CODE,
            BL_DRUG_RX_NO,
            BL_DRUG_FILL_NUMBER,
            BL_DRUG_DAYS_SUPPLY,
            BL_DRUG_STRENGTH,
            BL_DRUG_QUANTITY,
            SERVICE_FROM_DATE,
            SERVICE_TO_DATE,
            CLAIM_PAID_DATE,
            ICD_1,
            ICD_IND,
            BL_DRUG_CHARGE_AMT,
            BL_DRUG_DEDUCTIBLE_AMT,
            BL_DRUG_PAYMENT_AMT,
            RX_COPAY_AMT,
            RX_DISC_AMT,
            RX_COINS_AMT,
            BASE_PLAN_CODE,
            ADJUST_BENEFIT_AMOUNT,
            LOB_PLAN_CD,
            DATE_OF_BIRTH,
            GENDER_CD,
            MEDICARE_CLAIM_NUM
       )
        SELECT /*+ PARALLEL(8) */
            case when A.INDIVIDUAL_ID = -1 then nvl(hphm.individual_id, -1) else A.INDIVIDUAL_ID end INDIVIDUAL_ID,
            A.ACCOUNT_NUMBER,
            A.BL_DRUG_NDC_NUMBER,
            A.FILL_DATE,
            A.CHECK_TYPE_IND,
            A.PHARM_NBR,
            A.CLAIM_NUMBER,
            A.BILL_LINE_NUMBER,
            A.TOS_CODE,
            A.BL_DRUG_RX_NO,
            A.BL_DRUG_FILL_NUMBER,
            A.BL_DRUG_DAYS_SUPPLY,
            A.BL_DRUG_STRENGTH,
            A.BL_DRUG_QUANTITY,
            A.SERVICE_FROM_DATE,
            A.SERVICE_TO_DATE,
            A.CLAIM_PAID_DATE,
            A.ICD_1,
            A.ICD_IND,
            A.BL_DRUG_CHARGE_AMT,
            A.BL_DRUG_DEDUCTIBLE_AMT,
            A.BL_DRUG_PAYMENT_AMT,
            A.RX_COPAY_AMT,
            A.RX_DISC_AMT,
            A.RX_COINS_AMT,
            A.BASE_PLAN_CODE,
            A.ADJUST_BENEFIT_AMOUNT,
            A.LOB_PLAN_CD,
            A.DATE_OF_BIRTH,
            A.GENDER_CD,
            A.MEDICARE_CLAIM_NUM
            FROM (
            SELECT /*+ PARALLEL(8) */
            DISTINCT
            MBR.CURR_INDV_ID  as INDIVIDUAL_ID,
            case when MBR.CURR_ACCT_NBR = ''-1'' then  OBLH.ACCT_NBR else MBR.CURR_ACCT_NBR  end ACCOUNT_NUMBER ,
            NULL       AS                     BL_DRUG_NDC_NUMBER ,
            NULL       AS                     FILL_DATE ,
            OBLH.D_CLM_TYP_IND                CHECK_TYPE_IND ,
            NULL       AS                     PHARM_NBR,
            LPAD(OBLH.CLM_NBR,12,''0'')         CLAIM_NUMBER,
            OBLH.BIL_LN_NBR+20                BILL_LINE_NUMBER,   ----- INCREMENT BY 20 TO AVOID DUPLICATE BILL LINES
            trim(DT.TOS_CD)                         TOS_CODE ,
            NULL       AS                     BL_DRUG_RX_NO,
            NULL       AS                     BL_DRUG_FILL_NUMBER ,
            NULL       AS                     BL_DRUG_DAYS_SUPPLY ,
            NULL       AS                     BL_DRUG_STRENGTH ,
            NULL       AS                     BL_DRUG_QUANTITY ,
            OBLH.SRVC_FROM_DT_ID              SERVICE_FROM_DATE,
            OBLH.SRVC_TO_DT_ID                SERVICE_TO_DATE ,
            OBLH.CLM_PD_DT_ID                 CLAIM_PAID_DATE ,
            NULL      AS                      ICD_1,
            ''U''       AS                      ICD_IND,
            NULL      AS                      BL_DRUG_CHARGE_AMT,
            NULL      AS                      BL_DRUG_DEDUCTIBLE_AMT ,
            OBLH.OCRS_BEN_AMT                 BL_DRUG_PAYMENT_AMT,
            NULL      AS                      RX_COPAY_AMT,
            NULL      AS                      RX_DISC_AMT,
            NULL      AS                      RX_COINS_AMT,
            case when length(cp.COMPAS_PLN_CD) = 3 and (cp.COMPAS_PLN_CD like ''%02%'' or cp.COMPAS_PLN_CD like ''%S2%'' )
                and cp.PRDCT =''Med Supp'' and cp.PLN_GRP like ''%Modernize%''
                then replace(trim(cp.COMPAS_PLN_CD), ''2'', ''1'')
                else trim(cp.COMPAS_PLN_CD) end as BASE_PLAN_CODE,
            NULL      AS                      ADJUST_BENEFIT_AMOUNT,
            case when length(cp.COMPAS_PLN_CD) = 3 and (cp.COMPAS_PLN_CD like ''%02%'' or cp.COMPAS_PLN_CD like ''%S2%'' )
                and cp.PRDCT =''Med Supp'' and cp.PLN_GRP like ''%Modernize%''
                then replace(cp.COMPAS_PLN_CD, ''2'', ''1'')
                else cp.COMPAS_PLN_CD end as LOB_PLAN_CD,
               MBR.DOB_ID  AS DATE_OF_BIRTH,
            MBR.GDR_CD AS GENDER_CD,
            MBR.MEDCR_CLM_NBR  AS MEDICARE_CLAIM_NUM
            FROM BDR_DM.F_OCRS_BIL_LN_HIST      OBLH
             join BDR_DM.D_CLM_PLN  cp on OBLH.D_CLM_PLN_SK= cp.D_CLM_PLN_SK
            --JOIN  CONF.D_PLN_BEN_MOD PBM      ON  OBLH.D_PLN_BEN_MOD_SK = PBM.D_PLN_BEN_MOD_SK
            JOIN BDR_DM.D_TOS DT                  ON OBLH.D_TOS_SK = DT.D_TOS_SK
             JOIN BDR_CONF.d_mbr_info MBR ON OBLH.d_mbr_info_sk = MBR.d_mbr_info_sk

        /*LEFT OUTER JOIN (SELECT DISTINCT ACCOUNT_NUMBER ,
            INDIVIDUAL_ID ,
            EXTRACT_TYPE ,
            INSURED_PLAN_EFFECTIVE_DATE,
            INSURED_PLAN_TERMINATION_DATE FROM DM.RPT_IGX_MEMBER_MEDSUPP Q1
            WHERE EXTRACT_TYPE = ''MEDSUPP'' ) IMM

         ON     MBR.CURR_ACCT_NBR = IMM.ACCOUNT_NUMBER
            AND MBR.CURR_INDV_ID = IMM.INDIVIDUAL_ID
           -- AND IMM.EXTRACT_TYPE = ''MEDSUPP''
            AND  TO_NUMBER (TO_CHAR(TO_DATE(DECODE(OBLH.CERT_EFF_DT_ID,-1,99991231, OBLH.CERT_EFF_DT_ID),''YYYYMMDD''
            ),''YYYYMM''))  = SUBSTR (TO_CHAR (IMM.INSURED_PLAN_EFFECTIVE_DATE), 1, 6) */

           ---- JOIN ETL.ETL_BATCH_LOG  EL          ON  OBLH.ETL_LST_BTCH_ID = EL.BATCH_ID

            WHERE
                DT.TOS_GL_ACCT_CD =''50300''
                AND  cp.PRDCT =''Med Supp'' -- AND LENGTH(PBM.COMPAS_PLN_CD)<3
                                AND OBLH.CLM_PD_DT_ID between :v_extract_key_low and  :v_extract_key_high) A
              LEFT OUTER JOIN
                                      (SELECT  hm.individual_id,
                                               hp.membership_number,
                                               hp.association_id,
                                               hm.insured_cd
                                         FROM SRC_COMPAS_D.household_profile hp, SRC_COMPAS_D.household_member hm
                                         WHERE     hp.household_id = hm.household_id
                                        AND :v_extract_date BETWEEN HM.HHOLD_MEMBER_START_DATE AND NVL (HM.HHOLD_MEMBER_STOP_DATE,
                                            TO_DATE (''31-DEC-9999'',''DD-MON-YYYY'') )
                                        AND :v_extract_date BETWEEN HP.HHOLD_PROFILE_START_DATE AND NVL (HP.HHOLD_PROFILE_STOP_DATE,
                                            TO_DATE (''31-DEC-9999'',''DD-MON-YYYY'') )
                                        AND NVL (hp.delete_ind, ''N'') <> ''Y'') hphm
                                                            ON     TO_NUMBER(A.ACCOUNT_NUMBER) = TO_NUMBER( NVL(TO_CHAR(hphm.MEMBERSHIP_NUMBER), '''') || NVL(TO_CHAR(hphm.ASSOCIATION_ID), '''') || NVL(TO_CHAR(hphm.INSURED_CD), '''')) ;
    	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );


-------------------------------------COMMENTED BY OAS---------------------------------------  -
 /*        v_rows_inserted := SQL%ROWCOUNT;
         COMMIT;

         INSERT
       INTO
            ETL.ETL_DETAIL_LOAD_INFO
            (
                APPLICATION ,
                ETL_PROC_NAME ,
                ACTION ,
                STEP_INFO ,
                ROWS_AFFECTED ,
                ETL_DATETIME
            )
            VALUES
            (
                ''OPTUMHEALTHFEEDRPT'',
                v_proc_name,
                ''INSERT'',
                ''PHARMACY OCRSRX ROWS INSERTED'',
                v_rows_inserted,
                SYSTIMESTAMP
            );

        COMMIT;
      END;

      BEGIN                     -- analyze DM.RPT_IGX_RX_CLAIMS_OCRS_MEDSUPP

          DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''RPT_IGX_RX_CLAIMS_OCRS_MEDSUPP'');


      END;

      COMMIT;


   INSERT
        INTO
            ETL.ETL_DETAIL_LOAD_INFO
            (
                APPLICATION ,
                ETL_PROC_NAME ,
                ACTION ,
                STEP_INFO ,
                ROWS_AFFECTED ,
                ETL_DATETIME
            )
            VALUES
            (
                ''OPTUMHEALTHFEEDRPT'',
                v_proc_name,
                ''END'',
                ''PROC EXECUTION COMPLETED'',
                0,
                SYSTIMESTAMP
            );

        COMMIT;


   EXCEPTION
      WHEN OTHERS
      THEN
          v_err_message :=SQLERRM;
    INSERT
    INTO
        ETL.ETL_DETAIL_LOAD_INFO
        (
            APPLICATION ,
            ETL_BATCH_ID,
            ETL_PROC_NAME ,
            ACTION ,
            STEP_INFO ,
            ROWS_AFFECTED ,
            ETL_DATETIME
        )
        VALUES
        (
            ''OPTUMHEALTHFEEDRPT'',
            NULL,
            v_proc_name,
            ''E'',
            v_err_message ,
            0,
            SYSTIMESTAMP
        );

   DBMS_OUTPUT.PUT_LINE(''ERROR: '' || SQLCODE || ''-'' || SQLERRM || ''-'' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE()|| Chr(10)||DBMS_UTILITY.FORMAT_ERROR_STACK());

    RAISE;
   END;

--------------------DM.PKG_INGENIX_EXTRACT.pr_extract_rx_claims_ocrs ENDS--------------------


--------------------DM.PKG_INGENIX_EXTRACT.PR_LOADFILEDATA_MEMBER BEGINS--------------------

------------ LOAD MEMBER FILE DATA

  PROCEDURE PR_LOADFILEDATA_MEMBER (
      p_extract_key_low    IN   NUMBER,
      p_extract_key_high   IN   NUMBER,
      p_extract_type       IN   VARCHAR2,
      p_start_date         IN   DATE,
      p_stop_date          IN   DATE

   )
   IS


      v_extract_key_low    NUMBER (8, 0);
      v_extract_key_high   NUMBER (8, 0);
      v_extract_type       VARCHAR2(50);
      v_proc_name          VARCHAR2 (30)                := ''PR_LOADFILEDATA_MEMBER'';
      v_err_message        VARCHAR2(2000);
       V_ROWS_AFFTD NUMBER := 0;
       v_start_date        DATE;
       v_stop_date         DATE;
   BEGIN

INSERT
    INTO
        ETL.ETL_DETAIL_LOAD_INFO
        (
            APPLICATION ,
            ETL_BATCH_ID,
            ETL_PROC_NAME ,
            ACTION ,
            STEP_INFO ,
            ROWS_AFFECTED ,
            ETL_DATETIME
        )
        VALUES
        (
            ''OPTUMHEALTHFEEDRPT'',
            NULL,
            v_proc_name,
            ''START'',
            ''PROCEDURE STARTS'',
           0,
            SYSTIMESTAMP
        );
COMMIT;

      BEGIN
         v_extract_key_low := p_extract_key_low;
         v_extract_key_high := p_extract_key_high;
         v_extract_type := p_extract_type;
         v_start_date := p_start_date;
         v_stop_date := p_stop_date;



INSERT
INTO
    ETL.ETL_DETAIL_LOAD_INFO
    (
        APPLICATION ,
        ETL_BATCH_ID,
        ETL_PROC_NAME ,
        ACTION ,
        STEP_INFO ,
        ROWS_AFFECTED ,
        ETL_DATETIME
    )
    VALUES
    (
        ''OPTUMHEALTHFEED'',
        NULL,
        v_proc_name,
        ''Value of v_extract_key_low'',
        v_extract_key_low,
        0,
        SYSTIMESTAMP
    );
COMMIT;


INSERT
INTO
    ETL.ETL_DETAIL_LOAD_INFO
    (
        APPLICATION ,
        ETL_BATCH_ID,
        ETL_PROC_NAME ,
        ACTION ,
        STEP_INFO ,
        ROWS_AFFECTED ,
        ETL_DATETIME
    )
    VALUES
    (
        ''OPTUMHEALTHFEED'',
        NULL,
        v_proc_name,
        ''Value of v_extract_key_high'',
        v_extract_key_high,
        0,
        SYSTIMESTAMP
    );
COMMIT;


INSERT
INTO
    ETL.ETL_DETAIL_LOAD_INFO
    (
        APPLICATION ,
        ETL_BATCH_ID,
        ETL_PROC_NAME ,
        ACTION ,
        STEP_INFO ,
        ROWS_AFFECTED ,
        ETL_DATETIME
    )
    VALUES
    (
        ''OPTUMHEALTHFEED'',
        NULL,
        v_proc_name,
        ''Value of v_extract_type'',
        v_extract_type,
        0,
        SYSTIMESTAMP
    );
COMMIT;



   end;		*/	
   -------------------------------------COMMENTED BY OAS---------------------------------------  -

       ----- truncate table DM.RPT_IGX_MEMBER_FILEDATA
	   	    
V_STEP_NAME    := ''TRUNCATE - RPT_IGX_MEMBER_FILEDATA'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

    EXECUTE IMMEDIATE ''TRUNCATE TABLE BDR_DM.RPT_IGX_MEMBER_FILEDATA'';

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

--      BEGIN	------------OAS DELETE

   -- Load Member File Data
												  	    
V_STEP_NAME    := ''INSERT - RPT_IGX_MEMBER_FILEDATA'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

     INSERT /*+ ENABLE_PARALLEL_DML APPEND */ INTO  BDR_DM.RPT_IGX_MEMBER_FILEDATA
   ( ACCOUNT_NUMBER,
    MEDICARE_CLAIM_NUM,
    LAST_NAME,
    FIRST_NAME,
    MIDDLE_NAME,
    GENDER_CD,
    DATE_OF_BIRTH,
    ADDRESS_LINE_1,
    ADDRESS_LINE_2,
    CITY,
    STATE_CD,
    ZIP_CD,
    DAYTIME_PHONE_NUM,
    EVENING_PHONE_NUM,
    PLAN_CATEGORY_DESC,
   INSURED_PLAN_EFFECTIVE_DATE,
    INSURED_PLAN_TERMINATION_DATE,
    INDIVIDUAL_ID,
    DATE_OF_DEATH,
    COUNTRY_CD,
    COUNTRY_NAME,
    PLAN_CATEGORY_ID,
    PHARMACY_FLAG,
    PREMIUM_DUE_AMT,
    MEMBERSHIP_PERIOD_START_DATE,
    MEMBERSHIP_PERIOD_STOP_DATE )

       SELECT  /*+ PARALLEL(8) */  q1.account_number, q1.medicare_claim_num, q1.last_name,
                      q1.first_name, q1.middle_name, q1.gender_cd,
                      q1.date_of_birth, q1.address_line_1, q1.address_line_2,
                      q1.city, q1.state_cd, q1.zip_cd, q1.daytime_phone_num,
                      q1.evening_phone_num, q1.plan_category_desc,
                      MIN
                         (q1.insured_plan_effective_date
                         ) AS insured_plan_effective_date,
                      MAX
                         (NVL (q1.insured_plan_termination_date, 99991231)
                         ) AS insured_plan_termination_date,
                      q1.individual_id, q1.date_of_death, q1.country_cd,
                      q1.country_name, q1.plan_category_id,
                      MAX (NVL (q1.pharmacy_flag, ''N'')) AS pharmacy_flag,
                      SUM (NVL (q1.premium_due_amt, 0)) AS premium_due_amt,
                      :v_extract_key_low AS membership_period_start_dt,
                      :v_extract_key_high AS membership_period_stop_dt
                 FROM (SELECT imm.account_number, imm.medicare_claim_num,
                              imm.last_name, imm.first_name, substr(imm.middle_name,1,1) as middle_name,
                              imm.gender_cd, imm.date_of_birth,
                              imm.address_line_1, imm.address_line_2,
                              imm.city, imm.state_cd, substr(imm.zip_cd,1,5) as zip_cd ,
                              imm.daytime_phone_num, imm.evening_phone_num,
                              imm.plan_cd, imm.plan_category_desc,
                              imm.insured_plan_effective_date,
                              NVL
                                 (imm.insured_plan_termination_date,
                                  99991231
                                 ) AS insured_plan_termination_date,
                              imm.individual_id, imm.date_of_death,
                              imm.country_cd, imm.country_name,
                              imm.insured_plan_id, imm.plan_display_cd,
                              imm.plan_category_id, imm.plan_type_id,
                            imm.plan_type_desc, imm.pharmacy_flag,
                              imm.premium_due_amt, imm.extract_type
                         FROM BDR_DM.RPT_IGX_MEMBER_MEDSUPP imm
                        WHERE imm.insured_plan_effective_date <
                                                            :v_extract_key_high
                          AND NVL (imm.insured_plan_termination_date,
                                   99991231) > :v_extract_key_low
                          AND imm.extract_type = :v_extract_type) q1
             GROUP BY q1.account_number,
                      q1.medicare_claim_num,
                      q1.last_name,
                      q1.first_name,
                      q1.middle_name,
                      q1.gender_cd,
                      q1.date_of_birth,
                      q1.address_line_1,
                      q1.address_line_2,
                      q1.city,
                      q1.state_cd,
                      q1.zip_cd,
                      q1.daytime_phone_num,
                      q1.evening_phone_num,
                      q1.plan_category_desc,
                      q1.individual_id,
                      q1.date_of_death,
                      q1.country_cd,
                      q1.country_name,
                      q1.plan_category_id,
                      :v_extract_key_low,
                      :v_extract_key_high ;
    	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

-------------------------------------COMMENTED BY OAS---------------------------------------  -
/*                   V_ROWS_AFFTD := SQL%ROWCOUNT;


      commit;


        INSERT
        INTO
            ETL.ETL_DETAIL_LOAD_INFO
            (
                APPLICATION ,
                ETL_PROC_NAME ,
                ACTION ,
                STEP_INFO ,
                ROWS_AFFECTED ,
                ETL_DATETIME
            )
            VALUES
            (
                ''OPTUMHEALTHFEED'',
                V_PROC_NAME,
                NULL,
                ''ROWS AFFECTED'',
                V_ROWS_AFFTD,
                SYSTIMESTAMP
            );

        COMMIT;

      END;

----analyze table after data load completion
      DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''RPT_IGX_MEMBER_FILEDATA'');


         INSERT
        INTO
            ETL.ETL_DETAIL_LOAD_INFO
            (
                APPLICATION ,
                ETL_PROC_NAME ,
                ACTION ,
                STEP_INFO ,
                ROWS_AFFECTED ,
                ETL_DATETIME
            )
            VALUES
            (
                ''OPTUMHEALTHFEED'',
                V_PROC_NAME,
                ''END'',
                ''PROC EXECUTION COMPLETED'',
                0,
                SYSTIMESTAMP
           );

        COMMIT;



   EXCEPTION
      WHEN OTHERS
      THEN
         v_err_message :=SQLERRM;

INSERT
INTO
    ETL.ETL_DETAIL_LOAD_INFO
    (
        APPLICATION ,
        ETL_BATCH_ID,
        ETL_PROC_NAME ,
        ACTION ,
        STEP_INFO ,
        ROWS_AFFECTED ,
        ETL_DATETIME
    )
    VALUES
    (
        ''OPTUMHEALTHFEEDRPT'',
        NULL,
        v_proc_name,
        ''E'',
        v_err_message ,
        0,
        SYSTIMESTAMP   ----- pkg_cdw_ingenix_extract.pr_email_status (v_extract_date,v_extract_type,''ERROR'',v_proc_name || SQLERRM);

    );

  DBMS_OUTPUT.PUT_LINE(''ERROR: '' || SQLCODE || ''-'' || SQLERRM || ''-'' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE()|| Chr(10)||DBMS_UTILITY.FORMAT_ERROR_STACK());

      RAISE;

   END;

--------------------DM.PKG_INGENIX_EXTRACT.PR_LOADFILEDATA_MEMBER ENDS--------------------


--------------------DM.PKG_INGENIX_EXTRACT.pr_loadfiledata_claims BEGINS--------------------

   --------LOAD CLAIM FILE DATA
  PROCEDURE pr_loadfiledata_claims (
      p_extract_key_low    IN   NUMBER,
      p_extract_key_high   IN   NUMBER,
      p_extract_type       IN   varchar2
   )
   IS



      v_extract_key_low        NUMBER (8, 0);
      v_extract_key_high       NUMBER (8, 0);
      v_extract_type           VARCHAR2(50);
      v_err_message            VARCHAR2(2000);
    V_ROWS_AFFTD NUMBER := 0;
      v_proc_name              VARCHAR2 (30)              := ''pr_loadfiledata_claims'';
   BEGIN

INSERT
    INTO
        ETL.ETL_DETAIL_LOAD_INFO
        (
            APPLICATION ,
            ETL_BATCH_ID,
            ETL_PROC_NAME ,
            ACTION ,
            STEP_INFO ,
            ROWS_AFFECTED ,
            ETL_DATETIME
        )
        VALUES
        (
            ''OPTUMHEALTHFEEDRPT'',
            NULL,
            v_proc_name,
            ''START'',
            ''PROCEDURE STARTS'',
            0,
            SYSTIMESTAMP
        );
COMMIT;

      BEGIN
         v_extract_key_low := p_extract_key_low;
         v_extract_key_high := p_extract_key_high;
         v_extract_type := p_extract_type;



INSERT
INTO
    ETL.ETL_DETAIL_LOAD_INFO
    (
        APPLICATION ,
        ETL_BATCH_ID,
        ETL_PROC_NAME ,
        ACTION ,
        STEP_INFO ,
        ROWS_AFFECTED ,
        ETL_DATETIME
    )
    VALUES
    (
        ''OPTUMHEALTHFEED'',
        NULL,
        v_proc_name,
        ''Value of v_extract_key_low'',
        v_extract_key_low,
        0,
        SYSTIMESTAMP
    );
COMMIT;


INSERT
INTO
    ETL.ETL_DETAIL_LOAD_INFO
    (
        APPLICATION ,
        ETL_BATCH_ID,
        ETL_PROC_NAME ,
        ACTION ,
        STEP_INFO ,
        ROWS_AFFECTED ,
        ETL_DATETIME
    )
    VALUES
    (
        ''OPTUMHEALTHFEED'',
        NULL,
        v_proc_name,
        ''Value of v_extract_key_high'',
        v_extract_key_high,
        0,
        SYSTIMESTAMP
    );
COMMIT;


INSERT
INTO
    ETL.ETL_DETAIL_LOAD_INFO
    (
        APPLICATION ,
        ETL_BATCH_ID,
        ETL_PROC_NAME ,
        ACTION ,
        STEP_INFO ,
        ROWS_AFFECTED ,
        ETL_DATETIME
    )
    VALUES
    (
        ''OPTUMHEALTHFEED'',
        NULL,
        v_proc_name,
        ''Value of v_extract_type'',
        v_extract_type,
        0,
        SYSTIMESTAMP
    );
COMMIT;



   end;	    		*/	
   -------------------------------------COMMENTED BY OAS---------------------------------------  -
   
        ----- truncate table DM.RPT_IGX_MEMBER_FILEDATA
		
V_STEP_NAME    := ''TRUNCATE - RPT_IGX_CLAIMS_FILEDATA'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

    EXECUTE IMMEDIATE ''TRUNCATE TABLE BDR_DM.RPT_IGX_CLAIMS_FILEDATA'';

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );



 --     BEGIN       ------------------OAS DELETE
 
 -- load  filedata for claims
	    
V_STEP_NAME    := ''INSERT - RPT_IGX_CLAIMS_FILEDATA'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

       INSERT /*+ ENABLE_PARALLEL_DML APPEND */ INTO BDR_DM.RPT_IGX_CLAIMS_FILEDATA
(
    OPREC_BILL_LINE_NUMBER,
    CLAIM_NUMBER,
    ACCOUNT_NUMBER,
    ZIP_CODE,
    STATE_CODE,
    UNDERWRITE_CODE,
    BASE_PLAN_CODE,
    TOS_CODE,
    CPT_CODE,
    ICD_1,
    ICD_2,
    ICD_3,
    ICD_IND,
    PLAN_EFF_MONTH,
    PLAN_TERM_MONTH,
    BILL_INCURRAL_DATE,
    PROCESS_DATE,
    SERVICE_FROM_DATE,
    SERVICE_TO_DATE,
    BENEFIT_PERIOD_DAYS,
    BENEFIT_AMT,
    MEDICARE_APPROVED_AMT,
    MEDICARE_PAYMENT_AMT,
    DEDUCTIBLE_AMT,
    PART_B_DEDUCT,
    REMARK_CODE,
    BILL_ASSIGN_IND,
    CHARGE_AMT,
    PROCEDURE_CODE,
    MEDICARE_ASSIGN_IND,
    INSURED_AGE,
    EOB_TYPE,
    MODIFIER_1,
    MODIFIER_2,
    HOSP_DAYS,
    SNF_DAYS,
    INDIVIDUAL_ID,
    PLACE_SERVICE_CODE,
    BL_MED_TOS_CODE,
    CHECK_TYPE_IND,
    MED_COINS_AMT,
    MED_COPAY_AMT,
    RECEIPT_DATE,
    ADJUST_BENEFIT_AMOUNT,
    LOB_PLAN_CD,
    DATE_OF_BIRTH,
    GENDER_CD,
    MEDICARE_CLAIM_NUM,
    ASSIGNEE_PROVIDER_KEY,
    PROVIDER_ID,
    TAX_ID_NUMBER,
    PROVIDER_NAME,
    PROVIDER_ADDRESS_1,
    PROVIDER_ADDRESS_2,
    PROVIDER_CITY,
    PROVIDER_ZIP,
    PROVIDER_STATE,
    PROVIDER_STATE_DESC,
    PROVIDER_PHONE,
    ADD_IONS,
    EXTRACT_KEY,
    PROVIDER_ZIP_KEY,
    NATIONAL_PROV_ID,
    TAXONOMY_CD,
    REND_NATIONAL_PROV_ID,
    REND_TAXONOMY_CD,
    REND_PROV_NAME
)
SELECT /*+ PARALLEL(8) */  DISTINCT
    ICM.OPREC_BILL_LINE_NUMBER,
    ICM.CLAIM_NUMBER,
    TO_NUMBER(ICM.ACCOUNT_NUMBER) ACCOUNT_NUMBER,  --- TRIM LEADING ZEROES
    ICM.ZIP_CODE,
    ICM.STATE_CODE,
    ICM.UNDERWRITE_CODE,
    ICM.BASE_PLAN_CODE,
    ICM.TOS_CODE,
    ICM.CPT_CODE,
    ICM.ICD_1,
    ICM.ICD_2,
    ICM.ICD_3,
    ICM.ICD_IND,
    ICM.PLAN_EFF_MONTH,
    ICM.PLAN_TERM_MONTH,
    ICM.BILL_INCURRAL_DATE,
    ICM.PROCESS_DATE,
    ICM.SERVICE_FROM_DATE,
    ICM.SERVICE_TO_DATE,
    ICM.BENEFIT_PERIOD_DAYS,
    ICM.BENEFIT_AMT,
    ICM.MEDICARE_APPROVED_AMT,
    ICM.MEDICARE_PAYMENT_AMT,
    ICM.DEDUCTIBLE_AMT,
    ICM.PART_B_DEDUCT,
    ICM.REMARK_CODE,
    ICM.BILL_ASSIGN_IND,
    ICM.CHARGE_AMT,
    ICM.PROCEDURE_CODE,
    ICM.MEDICARE_ASSIGN_IND,
    ICM.INSURED_AGE,
    ICM.EOB_TYPE,
    ICM.MODIFIER_1,
    ICM.MODIFIER_2,
    ICM.HOSP_DAYS,
    ICM.SNF_DAYS,
    ICM.INDIVIDUAL_ID,
    ICM.PLACE_SERVICE_CODE,
    ICM.BL_MED_TOS_CODE,
    ICM.CHECK_TYPE_IND,
    ICM.MED_COINS_AMT,
    ICM.MED_COPAY_AMT,
    ICM.RECEIPT_DATE,
    ICM.ADJUST_BENEFIT_AMOUNT,
    ICM.LOB_PLAN_CD,
    ICM.DATE_OF_BIRTH,
    ICM.GENDER_CD,
    ICM.MEDICARE_CLAIM_NUM,
    ICM.ASSIGNEE_PROVIDER_KEY,
    ICM.PROVIDER_ID,
    ICM.TAX_ID_NUMBER,
    ICM.PROVIDER_NAME,
    ICM.PROVIDER_ADDRESS_1,
    ICM.PROVIDER_ADDRESS_2,
    ICM.PROVIDER_CITY,
    ICM.PROVIDER_ZIP,
    ICM.PROVIDER_STATE,
    ICM.PROVIDER_STATE_DESC,
    ICM.PROVIDER_PHONE,
    ICM.ADD_IONS,
    ICM.EXTRACT_KEY,
    ICM.PROVIDER_ZIP_KEY,
    ICM.NATIONAL_PROV_ID,
    ICM.TAXONOMY_CD,
    ICM.REND_NATIONAL_PROV_ID,
    ICM.REND_TAXONOMY_CD,
    ICM.REND_PROV_NAME

FROM BDR_DM.RPT_IGX_CLAIMS_MEDSUPP ICM,
                    BDR_DM.RPT_IGX_MEMBER_DATA_MEDSUPP IMDM
              WHERE icm.individual_id = imdm.individual_id
                   AND IMDM.extract_type = :v_extract_type ;
    	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

-------------------------------------COMMENTED BY OAS---------------------------------------  -
 /*         V_ROWS_AFFTD := SQL%ROWCOUNT;


      commit;


        INSERT
        INTO
            ETL.ETL_DETAIL_LOAD_INFO
            (
                APPLICATION ,
                ETL_PROC_NAME ,
                ACTION ,
                STEP_INFO ,
                ROWS_AFFECTED ,
                ETL_DATETIME
            )
            VALUES
            (
                ''OPTUMHEALTHFEED'',
                V_PROC_NAME,
                NULL,
                ''CLAIMS ROWS AFFECTED'',
                V_ROWS_AFFTD,
                SYSTIMESTAMP
            );

        COMMIT;
         END;


----analyze table after data load completion
      DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''RPT_IGX_CLAIMS_FILEDATA'');

------ LOAD ocrs data into clims file table

BEGIN		*/		-------------------------------------COMMENTED BY OAS---------------------------------------  -
	    
V_STEP_NAME    := ''INSERT - RPT_IGX_CLAIMS_FILEDATA'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

INSERT /*+ ENABLE_PARALLEL_DML APPEND */ INTO BDR_DM.RPT_IGX_CLAIMS_FILEDATA
(
    OPREC_BILL_LINE_NUMBER,
    CLAIM_NUMBER,
    ACCOUNT_NUMBER,
    ZIP_CODE,
    STATE_CODE,
    UNDERWRITE_CODE,
    BASE_PLAN_CODE,
    TOS_CODE,
    CPT_CODE,
    ICD_1,
    ICD_2,
    ICD_3,
    ICD_IND,
    PLAN_EFF_MONTH,
    PLAN_TERM_MONTH,
    BILL_INCURRAL_DATE,
    PROCESS_DATE,
    SERVICE_FROM_DATE,
    SERVICE_TO_DATE,
    BENEFIT_PERIOD_DAYS,
    BENEFIT_AMT,
    MEDICARE_APPROVED_AMT,
    MEDICARE_PAYMENT_AMT,
    DEDUCTIBLE_AMT,
    PART_B_DEDUCT,
    REMARK_CODE,
    BILL_ASSIGN_IND,
    CHARGE_AMT,
    PROCEDURE_CODE,
    MEDICARE_ASSIGN_IND,
    INSURED_AGE,
    EOB_TYPE,
    MODIFIER_1,
    MODIFIER_2,
    HOSP_DAYS,
    SNF_DAYS,
    INDIVIDUAL_ID,
    PLACE_SERVICE_CODE,
    BL_MED_TOS_CODE,
    CHECK_TYPE_IND,
    MED_COINS_AMT,
    MED_COPAY_AMT,
    RECEIPT_DATE,
    ADJUST_BENEFIT_AMOUNT,
    LOB_PLAN_CD,
    DATE_OF_BIRTH,
    GENDER_CD,
    MEDICARE_CLAIM_NUM,
    ASSIGNEE_PROVIDER_KEY,
    PROVIDER_ID,
    TAX_ID_NUMBER,
    PROVIDER_NAME,
    PROVIDER_ADDRESS_1,
    PROVIDER_ADDRESS_2,
    PROVIDER_CITY,
    PROVIDER_ZIP,
    PROVIDER_STATE,
    PROVIDER_STATE_DESC,
    PROVIDER_PHONE,
    ADD_IONS,
    EXTRACT_KEY,
    PROVIDER_ZIP_KEY,
    NATIONAL_PROV_ID,
    TAXONOMY_CD,
    REND_NATIONAL_PROV_ID,
    REND_TAXONOMY_CD,
    REND_PROV_NAME
)
SELECT /*+ PARALLEL(8) */  DISTINCT
    ICOM.OPREC_BILL_LINE_NUMBER,
    ICOM.CLAIM_NUMBER,
   TO_NUMBER( ICOM.ACCOUNT_NUMBER) ACCOUNT_NUMBER,  --- TRIM LEADING ZEROES
   ICOM.ZIP_CODE,
    ICOM.STATE_CODE,
    ICOM.UNDERWRITE_CODE,
    ICOM.BASE_PLAN_CODE,
    ICOM.TOS_CODE,
    ICOM.CPT_CODE,
    ICOM.ICD_1,
    ICOM.ICD_2,
    ICOM.ICD_3,
    ICOM.ICD_IND,
    ICOM.PLAN_EFF_MONTH,
    ICOM.PLAN_TERM_MONTH,
    ICOM.BILL_INCURRAL_DATE,
    ICOM.PROCESS_DATE,
    ICOM.SERVICE_FROM_DATE,
    ICOM.SERVICE_TO_DATE,
    ICOM.BENEFIT_PERIOD_DAYS,
    ICOM.BENEFIT_AMT,
    ICOM.MEDICARE_APPROVED_AMT,
    ICOM.MEDICARE_PAYMENT_AMT,
    ICOM.DEDUCTIBLE_AMT,
    ICOM.PART_B_DEDUCT,
    ICOM.REMARK_CODE,
    ICOM.BILL_ASSIGN_IND,
    ICOM.CHARGE_AMT,
    ICOM.PROCEDURE_CODE,
    ICOM.MEDICARE_ASSIGN_IND,
    ICOM.INSURED_AGE,
    ICOM.EOB_TYPE,
    ICOM.MODIFIER_1,
    ICOM.MODIFIER_2,
    ICOM.HOSP_DAYS,
    ICOM.SNF_DAYS,
    ICOM.INDIVIDUAL_ID,
    ICOM.PLACE_SERVICE_CODE,
    ICOM.BL_MED_TOS_CODE,
    ICOM.CHECK_TYPE_IND,
    ICOM.MED_COINS_AMT,
    ICOM.MED_COPAY_AMT,
    ICOM.RECEIPT_DATE,
    ICOM.ADJUST_BENEFIT_AMOUNT,
    ICOM.LOB_PLAN_CD,
    ICOM.DATE_OF_BIRTH,
    ICOM.GENDER_CD,
    ICOM.MEDICARE_CLAIM_NUM,
    ICOM.ASSIGNEE_PROVIDER_KEY,
    ICOM.PROVIDER_ID,
    ICOM.TAX_ID_NUMBER,
    ICOM.PROVIDER_NAME,
    ICOM.PROVIDER_ADDRESS_1,
    ICOM.PROVIDER_ADDRESS_2,
    ICOM.PROVIDER_CITY,
    ICOM.PROVIDER_ZIP,
    ICOM.PROVIDER_STATE,
    ICOM.PROVIDER_STATE_DESC,
    ICOM.PROVIDER_PHONE,
    ICOM.ADD_IONS,
    ICOM.EXTRACT_KEY,
    ICOM.PROVIDER_ZIP_KEY,
    ICOM.NATIONAL_PROV_ID,
    ICOM.TAXONOMY_CD,
    ICOM.REND_NATIONAL_PROV_ID,
    ICOM.REND_TAXONOMY_CD,
    ICOM.REND_PROV_NAME

FROM               BDR_DM.RPT_IGX_CLAIMS_OCRS_MEDSUPP ICOM,
                    BDR_DM.RPT_IGX_MEMBER_DATA_MEDSUPP IMDM
              WHERE ICOM.individual_id = imdm.individual_id
                   AND IMDM.extract_type =  :v_extract_type ;
    	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

-------------------------------------COMMENTED BY OAS---------------------------------------  -
/*          V_ROWS_AFFTD := SQL%ROWCOUNT;

          COMMIT;



        INSERT
        INTO
            ETL.ETL_DETAIL_LOAD_INFO
            (
                APPLICATION ,
                ETL_PROC_NAME ,
                ACTION ,
                STEP_INFO ,
                ROWS_AFFECTED ,
                ETL_DATETIME
            )
            VALUES
            (
                ''OPTUMHEALTHFEED'',
                V_PROC_NAME,
                NULL,
                ''CLAIMS OCRS ROWS AFFECTED'',
                V_ROWS_AFFTD,
                SYSTIMESTAMP
            );

        COMMIT;

          END;

----analyze table after data load completion
      DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''RPT_IGX_CLAIMS_FILEDATA'');


         INSERT
        INTO
            ETL.ETL_DETAIL_LOAD_INFO
            (
                APPLICATION ,
                ETL_PROC_NAME ,
                ACTION ,
                STEP_INFO ,
                ROWS_AFFECTED ,
                ETL_DATETIME
            )
            VALUES
            (
                ''OPTUMHEALTHFEED'',
                V_PROC_NAME,
                ''END'',
                ''PROC EXECUTION COMPLETED'',
                0,
                SYSTIMESTAMP
            );

        COMMIT;



   EXCEPTION
      WHEN OTHERS
      THEN
         v_err_message :=SQLERRM;

INSERT
INTO
    ETL.ETL_DETAIL_LOAD_INFO
    (
        APPLICATION ,
        ETL_BATCH_ID,
        ETL_PROC_NAME ,
        ACTION ,
        STEP_INFO ,
        ROWS_AFFECTED ,
        ETL_DATETIME
    )
    VALUES
    (
        ''OPTUMHEALTHFEEDRPT'',
        NULL,
        v_proc_name,
        ''E'',
        v_err_message ,
        0,
        SYSTIMESTAMP

    );

   DBMS_OUTPUT.PUT_LINE(''ERROR: '' || SQLCODE || ''-'' || SQLERRM || ''-'' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE()|| Chr(10)||DBMS_UTILITY.FORMAT_ERROR_STACK());

      RAISE;

   END;

--------------------DM.PKG_INGENIX_EXTRACT.pr_loadfiledata_claims ENDS--------------------


--------------------DM.PKG_INGENIX_EXTRACT.PR_LOADFILEDATA_RX_CLAIMS BEGINS--------------------

  ----------------lOAD RX CLAIM FILE DATA

  PROCEDURE PR_LOADFILEDATA_RX_CLAIMS (
      p_extract_key_low    IN   NUMBER,
      p_extract_key_high   IN   NUMBER,
      p_extract_type       IN   VARCHAR2
   )
   IS

      v_extract_key_low         NUMBER (8, 0);
      v_extract_key_high        NUMBER (8, 0);
      v_extract_type            VARCHAR2(50);
      v_proc_name               VARCHAR2 (30)          := ''PR_LOADFILEDATA_RX_CLAIMS'';
        v_err_message            VARCHAR2(2000);
    V_ROWS_AFFTD NUMBER := 0;
   BEGIN

INSERT
    INTO
        ETL.ETL_DETAIL_LOAD_INFO
        (
            APPLICATION ,
            ETL_BATCH_ID,
            ETL_PROC_NAME ,
            ACTION ,
            STEP_INFO ,
            ROWS_AFFECTED ,
            ETL_DATETIME
        )
        VALUES
        (
            ''OPTUMHEALTHFEEDRPT'',
            NULL,
            v_proc_name,
            ''START'',
            ''PROCEDURE STARTS'',
            0,
            SYSTIMESTAMP
        );
COMMIT;

      BEGIN
         v_extract_key_low := p_extract_key_low;
         v_extract_key_high := p_extract_key_high;
         v_extract_type := p_extract_type;

INSERT
INTO
    ETL.ETL_DETAIL_LOAD_INFO
    (
        APPLICATION ,
        ETL_BATCH_ID,
        ETL_PROC_NAME ,
        ACTION ,
        STEP_INFO ,
        ROWS_AFFECTED ,
        ETL_DATETIME
    )
    VALUES
    (
        ''OPTUMHEALTHFEED'',
        NULL,
        v_proc_name,
        ''Value of v_extract_key_low'',
        v_extract_key_low,
        0,
        SYSTIMESTAMP
    );
COMMIT;


INSERT
INTO
    ETL.ETL_DETAIL_LOAD_INFO
    (
        APPLICATION ,
        ETL_BATCH_ID,
        ETL_PROC_NAME ,
        ACTION ,
        STEP_INFO ,
        ROWS_AFFECTED ,
        ETL_DATETIME
    )
    VALUES
    (
        ''OPTUMHEALTHFEED'',
        NULL,
        v_proc_name,
        ''Value of v_extract_key_high'',
        v_extract_key_high,
        0,
        SYSTIMESTAMP
    );
COMMIT;


INSERT
INTO
    ETL.ETL_DETAIL_LOAD_INFO
    (
        APPLICATION ,
        ETL_BATCH_ID,
        ETL_PROC_NAME ,
        ACTION ,
        STEP_INFO ,
        ROWS_AFFECTED ,
        ETL_DATETIME
    )
    VALUES
    (
        ''OPTUMHEALTHFEED'',
        NULL,
        v_proc_name,
        ''Value of v_extract_type'',
        v_extract_type,
        0,
        SYSTIMESTAMP
    );
COMMIT;

   end;		*/	
   -------------------------------------COMMENTED BY OAS---------------------------------------  -

       ----- truncate table DM.RPT_IGX_MEMBER_FILEDATA
	   	    
V_STEP_NAME    := ''TRUNCATE - RPT_IGX_RX_CLAIMS_FILEDATA'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

    EXECUTE IMMEDIATE ''TRUNCATE TABLE BDR_DM.RPT_IGX_RX_CLAIMS_FILEDATA'';

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

  --    BEGIN           -------------OAS DELETE       

  -- create pharmacy claim file
	    
V_STEP_NAME    := ''INSERT - RPT_IGX_RX_CLAIMS_FILEDATA'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

      INSERT /*+ ENABLE_PARALLEL_DML APPEND */ INTO BDR_DM.RPT_IGX_RX_CLAIMS_FILEDATA
(
    INDIVIDUAL_ID,
    ACCOUNT_NUMBER,
    BL_DRUG_NDC_NUMBER,
    FILL_DATE,
    CHECK_TYPE_IND,
    PHARM_NBR,
    CLAIM_NUMBER,
    BILL_LINE_NUMBER,
    TOS_CODE,
    BL_DRUG_RX_NO,
    BL_DRUG_FILL_NUMBER,
    BL_DRUG_DAYS_SUPPLY,
    BL_DRUG_STRENGTH,
    BL_DRUG_QUANTITY,
    SERVICE_FROM_DATE,
    SERVICE_TO_DATE,
    CLAIM_PAID_DATE,
    ICD_1,
    ICD_IND,
    BL_DRUG_CHARGE_AMT,
    BL_DRUG_DEDUCTIBLE_AMT,
    BL_DRUG_PAYMENT_AMT,
    RX_COPAY_AMT,
    RX_DISC_AMT,
    RX_COINS_AMT,
    BASE_PLAN_CODE,
    ADJUST_BENEFIT_AMOUNT,
    LOB_PLAN_CD,
    DATE_OF_BIRTH,
    GENDER_CD,
    MEDICARE_CLAIM_NUM
    )
SELECT /*+ PARALLEL(8) */ DISTINCT
    IRCM.INDIVIDUAL_ID,
   TO_NUMBER( IRCM.ACCOUNT_NUMBER) ACCOUNT_NUMBER,  ---trim leading zeroes
    IRCM.BL_DRUG_NDC_NUMBER,
    IRCM.FILL_DATE,
    IRCM.CHECK_TYPE_IND,
    IRCM.PHARM_NBR,
    IRCM.CLAIM_NUMBER,
    IRCM.BILL_LINE_NUMBER,
    IRCM.TOS_CODE,
    IRCM.BL_DRUG_RX_NO,
    IRCM.BL_DRUG_FILL_NUMBER,
    IRCM.BL_DRUG_DAYS_SUPPLY,
    IRCM.BL_DRUG_STRENGTH,
    IRCM.BL_DRUG_QUANTITY,
    IRCM.SERVICE_FROM_DATE,
    IRCM.SERVICE_TO_DATE,
    IRCM.CLAIM_PAID_DATE,
    IRCM.ICD_1,
    IRCM.ICD_IND,
    IRCM.BL_DRUG_CHARGE_AMT,
    IRCM.BL_DRUG_DEDUCTIBLE_AMT,
    IRCM.BL_DRUG_PAYMENT_AMT,
    IRCM.RX_COPAY_AMT,
    IRCM.RX_DISC_AMT,
    IRCM.RX_COINS_AMT,
    IRCM.BASE_PLAN_CODE,
    IRCM.ADJUST_BENEFIT_AMOUNT,
    IRCM.LOB_PLAN_CD,
    IRCM.DATE_OF_BIRTH,
    IRCM.GENDER_CD,
    IRCM.MEDICARE_CLAIM_NUM
FROM BDR_DM.RPT_IGX_RX_CLAIMS_MEDSUPP IRCM,
                            BDR_DM.RPT_IGX_MEMBER_DATA_MEDSUPP IMDM
                      WHERE ircm.individual_id = imdm.individual_id
                          AND IMDM.extract_type = :v_extract_type;
    	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

-------------------------------------COMMENTED BY OAS---------------------------------------  -
/*                            V_ROWS_AFFTD := SQL%ROWCOUNT;

      commit;

        INSERT
        INTO
            ETL.ETL_DETAIL_LOAD_INFO
            (
                APPLICATION ,
                ETL_PROC_NAME ,
                ACTION ,
                STEP_INFO ,
                ROWS_AFFECTED ,
                ETL_DATETIME
            )
            VALUES
            (
                ''OPTUMHEALTHFEED'',
                V_PROC_NAME,
                NULL,
                ''RX CLAIMS ROWS AFFECTED'',
                V_ROWS_AFFTD,
                SYSTIMESTAMP
            );

        COMMIT;


----analyze table after data load completion
      DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''RPT_IGX_RX_CLAIMS_FILEDATA'');

END;

---- LOAD OCRS DATA INTO THE FILE TABLE

BEGIN		*/	
	-------------------------------------COMMENTED BY OAS---------------------------------------  -
	    
V_STEP_NAME    := ''INSERT - RPT_IGX_RX_CLAIMS_FILEDATA'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

INSERT /*+ ENABLE_PARALLEL_DML APPEND */ INTO BDR_DM.RPT_IGX_RX_CLAIMS_FILEDATA
(
    INDIVIDUAL_ID,
    ACCOUNT_NUMBER,
    BL_DRUG_NDC_NUMBER,
    FILL_DATE,
    CHECK_TYPE_IND,
    PHARM_NBR,
    CLAIM_NUMBER,
    BILL_LINE_NUMBER,
    TOS_CODE,
    BL_DRUG_RX_NO,
    BL_DRUG_FILL_NUMBER,
    BL_DRUG_DAYS_SUPPLY,
    BL_DRUG_STRENGTH,
    BL_DRUG_QUANTITY,
    SERVICE_FROM_DATE,
    SERVICE_TO_DATE,
    CLAIM_PAID_DATE,
    ICD_1,
    ICD_IND,
    BL_DRUG_CHARGE_AMT,
    BL_DRUG_DEDUCTIBLE_AMT,
    BL_DRUG_PAYMENT_AMT,
    RX_COPAY_AMT,
    RX_DISC_AMT,
    RX_COINS_AMT,
    BASE_PLAN_CODE,
    ADJUST_BENEFIT_AMOUNT,
    LOB_PLAN_CD,
    DATE_OF_BIRTH,
    GENDER_CD,
    MEDICARE_CLAIM_NUM
    )
SELECT /*+ PARALLEL(8) */ DISTINCT
    IRCM.INDIVIDUAL_ID,
   TO_NUMBER( IRCM.ACCOUNT_NUMBER) ACCOUNT_NUMBER,    ---- trim leading zeroes
    IRCM.BL_DRUG_NDC_NUMBER,
    IRCM.FILL_DATE,
    IRCM.CHECK_TYPE_IND,
    IRCM.PHARM_NBR,
    IRCM.CLAIM_NUMBER,
    IRCM.BILL_LINE_NUMBER,
    IRCM.TOS_CODE,
    IRCM.BL_DRUG_RX_NO,
    IRCM.BL_DRUG_FILL_NUMBER,
    IRCM.BL_DRUG_DAYS_SUPPLY,
    IRCM.BL_DRUG_STRENGTH,
    IRCM.BL_DRUG_QUANTITY,
    IRCM.SERVICE_FROM_DATE,
  IRCM.SERVICE_TO_DATE,
    IRCM.CLAIM_PAID_DATE,
    IRCM.ICD_1,
    IRCM.ICD_IND,
    IRCM.BL_DRUG_CHARGE_AMT,
    IRCM.BL_DRUG_DEDUCTIBLE_AMT,
    IRCM.BL_DRUG_PAYMENT_AMT,
    IRCM.RX_COPAY_AMT,
    IRCM.RX_DISC_AMT,
    IRCM.RX_COINS_AMT,
    IRCM.BASE_PLAN_CODE,
    IRCM.ADJUST_BENEFIT_AMOUNT,
    IRCM.LOB_PLAN_CD,
    IRCM.DATE_OF_BIRTH,
    IRCM.GENDER_CD,
    IRCM.MEDICARE_CLAIM_NUM
FROM BDR_DM.RPT_IGX_RX_CLAIMS_OCRS_MEDSUPP IRCM,
                            BDR_DM.RPT_IGX_MEMBER_DATA_MEDSUPP IMDM
                      WHERE ircm.individual_id = imdm.individual_id
                          AND IMDM.extract_type =  :v_extract_type;
    	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

-------------------------------------COMMENTED BY OAS---------------------------------------  -
/*                            V_ROWS_AFFTD := SQL%ROWCOUNT;

      commit;

        INSERT
        INTO
            ETL.ETL_DETAIL_LOAD_INFO
            (
                APPLICATION ,
                ETL_PROC_NAME ,
                ACTION ,
                STEP_INFO ,
                ROWS_AFFECTED ,
                ETL_DATETIME
            )
            VALUES
            (
                ''OPTUMHEALTHFEED'',
                V_PROC_NAME,
                NULL,
                ''RX CLAIMS OCRS ROWS AFFECTED'',
                V_ROWS_AFFTD,
                SYSTIMESTAMP
            );

        COMMIT;


END;



----analyze table after data load completion
      DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''RPT_IGX_RX_CLAIMS_FILEDATA'');


         INSERT
        INTO
            ETL.ETL_DETAIL_LOAD_INFO
            (
                APPLICATION ,
                ETL_PROC_NAME ,
                ACTION ,
                STEP_INFO ,
                ROWS_AFFECTED ,
                ETL_DATETIME
            )
            VALUES
            (
                ''OPTUMHEALTHFEED'',
                V_PROC_NAME,
                ''END'',
                ''PROC EXECUTION COMPLETED'',
                0,
                SYSTIMESTAMP
            );

        COMMIT;

   EXCEPTION
      WHEN OTHERS
      THEN

           v_err_message :=SQLERRM;

INSERT
INTO
    ETL.ETL_DETAIL_LOAD_INFO
    (
        APPLICATION ,
        ETL_BATCH_ID,
        ETL_PROC_NAME ,
        ACTION ,
        STEP_INFO ,
        ROWS_AFFECTED ,
        ETL_DATETIME
    )
    VALUES
    (
        ''OPTUMHEALTHFEEDRPT'',
        NULL,
        v_proc_name,
        ''E'',
        v_err_message ,
        0,
        SYSTIMESTAMP   ----- pkg_cdw_ingenix_extract.pr_email_status (v_extract_date,v_extract_type,''ERROR'',v_proc_name || SQLERRM);

    );

   DBMS_OUTPUT.PUT_LINE(''ERROR: '' || SQLCODE || ''-'' || SQLERRM || ''-'' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE()|| Chr(10)||DBMS_UTILITY.FORMAT_ERROR_STACK());

      RAISE;
   END;

END;
/*/
--------------COMMENTED BY OAS------------------
--------------------DM.PKG_INGENIX_EXTRACT.PR_LOADFILEDATA_RX_CLAIMS ENDS--------------------


CALL UTIL.SP_ETL_CHECK_CONSTRAINTS(:DB_NAME , :APPLICATION , :WORKFLOW_NAME , :OBJECT_NAME , :V_BATCH_ID );		---------OAS ADD


UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''COMPLETE'', ERROR_MSG = null, BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
;
UPDATE  UTIL.ETL_BATCH_OBJECT_INCR_VALU SET INCR_COLUMN_VALUE = :V_BATCH_ID, LST_MOD_DT = CURRENT_TIMESTAMP() 
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID''
;

EXCEPTION

WHEN OTHER THEN

UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''ERROR'', ERROR_MSG = :SQLERRM,  BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
;

INSERT INTO  UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ERROR_MSG, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''ERROR'', :V_STEP_NAME, :V_STEP_SEQ, :SQLERRM, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() )
;



RAISE;

END;

';