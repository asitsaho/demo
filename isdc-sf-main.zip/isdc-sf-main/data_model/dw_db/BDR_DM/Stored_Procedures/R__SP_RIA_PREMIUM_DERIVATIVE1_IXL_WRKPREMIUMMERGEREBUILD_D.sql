USE SCHEMA BDR_DM; CREATE OR REPLACE PROCEDURE "SP_RIA_PREMIUM_DERIVATIVE1_IXL_WRKPREMIUMMERGEREBUILD_D"("DB_NAME" VARCHAR(16777216), "APPLICATION" VARCHAR(16777216), "WORKFLOW_NAME" VARCHAR(16777216), "OBJECT_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '

-- Original workflow: wkf_RIA_Premium_Derivative_IXL_TargetLoad1_D
-- Original mapping: m_RIA_Premium_Derivative1_IXL_WrkPremiumMergeRebuild_D
-- Original folder: Premium
-- Original filename: wkf_RIA_Premium_Derivative_IXL_TargetLoad1_D.XML

DECLARE


V_ROWS_INSERTED  INTEGER;
V_ROWS_UPDATED INTEGER;
V_ROWS_DELETED INTEGER;
V_LAST_QUERY_ID VARCHAR;

V_WH VARCHAR;
V_BATCH_ID INTEGER;


V_BATCH_OBJECT_START_TIME        VARCHAR;
V_STEP_START_TIME    VARCHAR;
V_STEP_NAME VARCHAR;
V_STEP_SEQ INTEGER DEFAULT 0;
V_ETL_LST_BTCH_ID INTEGER;

V_ACTIVITY_DATE VARCHAR;
V_PGD_MONTHSBACK VARCHAR;
V_PURGE_END VARCHAR;


BEGIN

EXECUTE IMMEDIATE ''USE DATABASE ''||:DB_NAME; 

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_BATCH_OBJECT_START_TIME := (SELECT CURRENT_TIMESTAMP());



LET res1 RESULTSET := 
(

SELECT 

WH ,
BATCH_ID
  
FROM UTIL.ETL_BATCH_OBJECT_CONTROL
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
FETCH FIRST 1 ROW ONLY

)
;


LET C1 CURSOR FOR res1;
open C1;
FETCH C1 into  V_WH,V_BATCH_ID ;
close C1;


LET res2 RESULTSET := 

(

WITH PARAMETERS (PGD_MONTHSBACK) AS
(
  
SELECT * 
FROM  
(SELECT PARAMETER_NAME, PARAMETER_VALUE  FROM UTIL.ETL_OBJECT_PARAMETER_VALUE 
WHERE 1 = 1
AND APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
AND ACTIVE_FLG = ''Y''  
  
UNION ALL       

SELECT PARAMETER_NAME, PARAMETER_VALUE  FROM UTIL.ETL_GLOBAL_PARAMETER_VALUE WHERE PAR_GLOBAL_TYPE = ''PARGLOBAL_OPREPORTS'' AND ACTIVE_FLG = ''Y''
AND PARAMETER_NAME NOT IN  (
SELECT PARAMETER_NAME  FROM UTIL.ETL_OBJECT_PARAMETER_VALUE WHERE 1 = 1
AND APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
AND ACTIVE_FLG = ''Y''   ))
 
PIVOT(MAX(PARAMETER_VALUE) FOR PARAMETER_NAME IN (''PGD_MONTHSBACK'')) 

 
)  
SELECT * FROM PARAMETERS 
)  
  
;


LET C2 CURSOR FOR res2;
open C2;
FETCH C2 into  V_PGD_MONTHSBACK; 
close C2;




EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:V_WH;
USE SCHEMA BDR_DM;	--OAS ADD


INSERT INTO UTIL.ETL_BATCH_OBJECT_INCR_VALU (APPLICATION, WORKFLOW_NAME, OBJECT_NAME, INCR_COLUMN, INCR_COLUMN_VALUE )
SELECT * FROM (select :APPLICATION AS APPLICATION, :WORKFLOW_NAME AS WORKFLOW_NAME, :OBJECT_NAME AS OBJECT_NAME, ''ETL_LST_BTCH_ID'' AS INCR_COLUMN, -1 AS INCR_COLUMN_VALUE) A
WHERE NOT EXISTS (SELECT 1 FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU B WHERE B.APPLICATION = A.APPLICATION AND B.WORKFLOW_NAME = A.WORKFLOW_NAME AND B.OBJECT_NAME = A.OBJECT_NAME AND B.INCR_COLUMN = A.INCR_COLUMN)
;

V_ETL_LST_BTCH_ID :=(SELECT INCR_COLUMN_VALUE FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID'');

--------------------------------COMMENTED BY OAS--------------------------------
/*
CREATE OR REPLACE PROCEDURE DM.SP_RIA_PREMIUM_WRKMERGEREBLD_D(
    iv_Dummy IN NUMBER,
    P_ToContinueStatus OUT VARCHAR2,
    P_ErrorYNFlg OUT VARCHAR2,
    P_ErrorStr OUT VARCHAR2 )
AS
  V_PROC_NAME             VARCHAR(50):=''SP_RIA_PREMIUM_WRKMERGEREBLD_D'';
  V_ROWS_AFFTD            NUMBER(20) :=0;
  V_BTCH_ID               NUMBER(10);
  v_activitydate          DATE;
  v_confmonth             DATE;
  v_uw_curretlbatchid     NUMBER(10,0);
-- v_uw_lastetlbatchid     NUMBER(10,0);	-- DISABLED FOR RetroAct+RIA MERGE
  v_etlcurrentbatchid     NUMBER(10,0);
-- v_etllastbatchid        NUMBER(10,0);	-- DISABLED FOR RetroAct+RIA MERGE
-- v_etllastdcmprocessdate DATE;			-- DISABLED FOR RetroAct+RIA MERGE
  v_etlnumberofmonthsback NUMBER(10,0);
-- v_etlapplbatchid        NUMBER(10,0);		-- DISABLED FOR RetroAct+RIA MERGE
  v_purge_start DATE;
  v_purge_end DATE;
  V_AOP_LIVE_DATE DATE;
  BEGIN
  SELECT MAX(BATCH_ID)
  INTO V_BTCH_ID
  FROM ETL.ETL_BATCH_LOG
  WHERE APPLICATION=''CDC''
  AND BATCH_STATUS =''COMPLETE'';
  INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''DERIVATIVE PREMIUM1'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''START'',
      ''PROCEDURE STARTS'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );	
*/
-------------------------------COMMENTED BY OAS-----------------------------------


/*	SELECT TO_DATE(metadata_value,''MM-DD-YYYY'')
  INTO v_activitydate
  FROM etl.etl_application_metadata
  WHERE application = ''PREMIUM''
  AND metadata_type = ''ACTIVITY_DATE''; -- GETTING UPDATED BEFORE LOADING TNA BASELINE IN INTERIM PREMIUM II
*/																		----------------------OAS DELETE

V_ACTIVITY_DATE := (SELECT CURRENT_DATE-1 FROM DUAL);		-------------------------OAS ADD

  
----------------------------------OAS COMMENTED -- NOT BEING USED IN THE PROCEDURE--------------------------------------------
/*   SELECT TO_DATE(metadata_value,''YYYY-MM-DD'')
  INTO v_confmonth
  FROM etl.etl_application_metadata
  WHERE application = ''PREMIUM''
  AND metadata_type = ''CONF_MONTH''; */				
----------------------------------OAS COMMENTED -- NOT BEING USED IN THE PROCEDURE--------------------------------------------
  
  /*SELECT metadata_value								-- DISABLED FOR RetroAct+RIA MERGE
  INTO v_etllastbatchid
  FROM etl.etl_application_metadata
  WHERE application = ''PREMIUM''
  AND metadata_type = ''PGD_ISDWETLLastBatchID''; -- GETTING UPDATED IN UPDATE PREMIUM BASELINE
  SELECT metadata_value
  INTO v_uw_lastetlbatchid
  FROM etl.etl_application_metadata
  WHERE application = ''PREMIUM''
  AND metadata_type = ''PGD_UWFactETLLastBatchID''; -- GETTING UPDATED END OF THIS PROC
  SELECT TO_DATE(metadata_value,''MM-DD-YYYY HH24:MI:SS'')
  INTO v_etllastdcmprocessdate
  FROM etl.etl_application_metadata
  WHERE application = ''PREMIUM''
  AND metadata_type = ''PGD_DCMLastDate'';*/ -- GETTING UPDATED END OF THIS PROC
  
  
----------------------------------OAS COMMENTED -- NOT BEING USED IN THE PROCEDURE--------------------------------------------
/*   SELECT MAX(batch_id)
  INTO v_uw_curretlbatchid
  FROM etl.etl_batch_log
  WHERE application = ''UNDERWRITING''
  AND batch_status  = ''COMPLETE'';
  SELECT MAX(batch_id)
  INTO v_etlcurrentbatchid
  FROM etl.etl_batch_log
  WHERE application = ''CDC''
  AND batch_status  = ''COMPLETE''; */
----------------------------------OAS COMMENTED -- NOT BEING USED IN THE PROCEDURE--------------------------------------------


----------------------------OAS COMMENTED - FETCHING THIS VALUE FROM OBJECT PARAMETER VALUE TABLE---------------------------
/*  SELECT metadata_value
  INTO v_etlnumberofmonthsback
  FROM etl.etl_application_metadata
  WHERE application = ''PREMIUM''
  AND metadata_type = ''PGD_MonthsBack''; -- Static
*/
----------------------------OAS COMMENTED - FETCHING THIS VALUE FROM OBJECT PARAMETER VALUE TABLE---------------------------
  
----------------------------------OAS COMMENTED -- NOT BEING USED IN THE PROCEDURE--------------------------------------------
/*   SELECT TO_DATE(metadata_value,''YYYY-MM-DD'')
  INTO v_purge_start
  FROM etl.etl_application_metadata
  WHERE application = ''PREMIUM''
  AND metadata_type = ''PURGE_START''; */ --Static 2009-01-01
----------------------------------OAS COMMENTED -- NOT BEING USED IN THE PROCEDURE--------------------------------------------
  
  
  /*SELECT metadata_value									-- DISABLED FOR RetroAct+RIA MERGE
  INTO v_etlapplbatchid
  FROM etl.etl_application_metadata
  WHERE application = ''PREMIUM''
  AND metadata_type = ''APPLFactETLLastBatchID''; */-- GETTING UPDATED IN UPDATE PREMIUM BASELINE

  
V_STEP_NAME    := ''DELETE - wrk_RIA_premium_data_bl_rebuild'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

delete /*+ PARALLEL (8) */ from BDR_DM.wrk_RIA_premium_data_bl_rebuild
where SRC =''RETRO'' ;
--commit;
    	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_DELETED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );


-- SELECT TO_DATE(TO_CHAR(TRUNC(add_months(v_activitydate,-1*(v_etlnumberofmonthsback)),''YEAR''),''DD/MM/YYYY''),''DD/MM/YYYY'') into v_purge_end FROM DUAL;		---------------------OAS DELETE

v_purge_end := (SELECT TO_DATE(TO_CHAR(TRUNC(add_months(:V_ACTIVITY_DATE,-1*(:V_PGD_MONTHSBACK)),''YEAR''),''DD/MM/YYYY''),''DD/MM/YYYY''));

  
V_STEP_NAME    := ''INSERT - wrk_RIA_premium_data_bl_rebuild'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

INSERT /*+ ENABLE_PARALLEL_DML APPEND */ INTO BDR_DM.wrk_RIA_premium_data_bl_rebuild
    (
      household_id,
      individual_id,
      ins_plan_billing_bucket_id,
      insured_plan_id,
      household_address_id,
      premium_due_date,
      activity_date,
      paid_cert,
      del_cert,
      term_cert,
      paid_premium_amt,
      delinquent_premium_due_amt,
      plan_cd,
      benefit_mod_category_id,
      insured_plan_effective_date,
      insured_plan_termination_date,
      cert_termination_date,
      state_cd,
      zip_cd,
      country_cd,
      issue_state,
      issue_country_cd,
      issue_zip_cd,
      gender_cd,
      date_of_birth,
      etl_lst_btch_id,
      cert_acqn_chnl_level3,
      account_number,
      termination_reason_name,
      conservation_reason_name,
      plan_group,
      product_group,
      cert_actv_lvl_3_txt,
      undwr_tag_key,
      prdct_eff_dt,
      prdct_acqn_chnl_level3,
      legal_entity_name,
      mbr_pd_prem_amt,
      mbr_delq_prem_amt,
      er_pd_prem_amt,
      er_delq_prem_amt,
      current_signature_date,
      original_signature_date,
      original_insuredplan_id,
      writing_agent,
      selling_agent,
      original_selling_agent,
      ret_typ_id,
      er_skey,
      dcm_insured_plan_id,
      dcm_insured_plan_eff_date,
      dcm_plan_cd,
      dcm_signature_date,
      dcm_writing_agent,
      dcm_derived_compas_agent,
      agt_wrt_skey,
      agt_sel_orig_skey,
      agt_sel_skey,
      agt_dcm_wrt_skey,
      D_DSCNT_ANNL_PAYR_SK,
      D_DSCNT_EFT_SK,
      D_DSCNT_ERLY_ENRL_SK,
      D_DSCNT_LNGVTY_SK,
      D_DSCNT_MULTI_INSD_SK,
      D_SURCHRG_TBCC_USER_SK,
      D_SURCHRG_TIER_SK,
      D_INSD_PLN_PRFL_SK,
      D_CALC_RT_SK,
      MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
      DSCNT_PD_ANNL_PAYR_AMT,
      DSCNT_PD_EFT_AMT,
      DSCNT_PD_ERLY_ENRL_AMT,
      DSCNT_PD_LNGVTY_AMT,
      DSCNT_PD_MULTI_INSD_AMT,
      SURCHRG_PD_TBCC_USER_AMT,
      SURCHRG_PD_TIER_AMT,
      DSCNT_DELQ_ANNL_PAYR_AMT,
      DSCNT_DELQ_EFT_AMT,
      DSCNT_DELQ_ERLY_ENRL_AMT,
      DSCNT_DELQ_LNGVTY_AMT,
      DSCNT_DELQ_MULTI_INSD_AMT,
      SURCHRG_DELQ_TBCC_USER_AMT,
      SURCHRG_DELQ_TIER_AMT,
      ORIGINAL_REFERRAL_AGENT,
      REFERRAL_AGENT,
      AGT_REF_ORIG_D_AGT_SK,
      AGT_REF_D_AGT_SK,
      D_MBR_INFO_SK,
      D_PLN_BEN_MOD_SK,
      RES_D_GEO_XREF_SK,
      PLN_ISS_D_GEO_XREF_SK,
      D_RTNG_AREA_SK,
      F_APPL_TRANS_DAY_SK,
      CERT_SALE_CHNL_LVL_1,
      CERT_SALE_CHNL_LVL_2,
      CERT_SALE_CHNL_LVL_3,
      PRDCT_SALE_CHNL_LVL_1,
      PRDCT_SALE_CHNL_LVL_2,
      PRDCT_SALE_CHNL_LVL_3,
      D_NEW_TO_MEDCR_SK,
      DSCNT_PD_NEW_TO_MEDCR_AMT,
      DSCNT_DLQNT_NEW_TO_MEDCR_AMT,
      D_UNDWR_GUID_SK,
      D_AGT_POL_SK,
      PRO_RATED_CREDIT,
      ENT_AGE_EFFDT,
      SRC,
      SRC_BLR_RN
    )
   SELECT  /*+ PARALLEL (8) */

          household_id,
      individual_id,
      ins_plan_billing_bucket_id,
      insured_plan_id,
      household_address_id,
      premium_due_date,
      activity_date,
      paid_cert,
      del_cert,
      term_cert,
      paid_premium_amt,
      delinquent_premium_due_amt,
      plan_cd,
      benefit_mod_category_id,
      insured_plan_effective_date,
      insured_plan_termination_date,
      cert_termination_date,
      state_cd,
      zip_cd,
      country_cd,
      issue_state,
      issue_country_cd,
      issue_zip_cd,
      gender_cd,
      date_of_birth,
      etl_lst_btch_id,
      cert_acqn_chnl_level3,
      account_number,
      termination_reason_name,
      conservation_reason_name,
      plan_group,
      product_group,
      cert_actv_lvl_3_txt,
      undwr_tag_key,
      prdct_eff_dt,
      prdct_acqn_chnl_level3,
      legal_entity_name,
      mbr_pd_prem_amt,
      mbr_delq_prem_amt,
      er_pd_prem_amt,
      er_delq_prem_amt,
      current_signature_date,
      original_signature_date,
      original_insuredplan_id,
      writing_agent,
      selling_agent,
      original_selling_agent,
      ret_typ_id,
      er_skey,
      dcm_insured_plan_id,
      dcm_insured_plan_eff_date,
      dcm_plan_cd,
      dcm_signature_date,
      dcm_writing_agent,
      dcm_derived_compas_agent,
      agt_wrt_skey,
      agt_sel_orig_skey,
      agt_sel_skey,
      agt_dcm_wrt_skey,
      D_DSCNT_ANNL_PAYR_SK,
      D_DSCNT_EFT_SK,
      D_DSCNT_ERLY_ENRL_SK,
      D_DSCNT_LNGVTY_SK,
      D_DSCNT_MULTI_INSD_SK,
      D_SURCHRG_TBCC_USER_SK,
      D_SURCHRG_TIER_SK,
      D_INSD_PLN_PRFL_SK,
      D_CALC_RT_SK,
      MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
      DSCNT_PD_ANNL_PAYR_AMT,
      DSCNT_PD_EFT_AMT,
      DSCNT_PD_ERLY_ENRL_AMT,
      DSCNT_PD_LNGVTY_AMT,
      DSCNT_PD_MULTI_INSD_AMT,
      SURCHRG_PD_TBCC_USER_AMT,
      SURCHRG_PD_TIER_AMT,
      DSCNT_DELQ_ANNL_PAYR_AMT,
      DSCNT_DELQ_EFT_AMT,
      DSCNT_DELQ_ERLY_ENRL_AMT,
      DSCNT_DELQ_LNGVTY_AMT,
      DSCNT_DELQ_MULTI_INSD_AMT,
      SURCHRG_DELQ_TBCC_USER_AMT,
      SURCHRG_DELQ_TIER_AMT,
      ORIGINAL_REFERRAL_AGENT,
      REFERRAL_AGENT,
      AGT_REF_ORIG_D_AGT_SK,
      AGT_REF_D_AGT_SK,
      D_MBR_INFO_SK,
      D_PLN_BEN_MOD_SK,
      RES_D_GEO_XREF_SK,
      PLN_ISS_D_GEO_XREF_SK,
      D_RTNG_AREA_SK,
      F_APPL_TRANS_DAY_SK,
      CERT_SALE_CHNL_LVL_1,
      CERT_SALE_CHNL_LVL_2,
      CERT_SALE_CHNL_LVL_3,
      PRDCT_SALE_CHNL_LVL_1,
      PRDCT_SALE_CHNL_LVL_2,
      PRDCT_SALE_CHNL_LVL_3,
      D_NEW_TO_MEDCR_SK,
      DSCNT_PD_NEW_TO_MEDCR_AMT,
      DSCNT_DLQNT_NEW_TO_MEDCR_AMT,
      -1 as D_UNDWR_GUID_SK,
      -1 as D_AGT_POL_SK,
      0 as PRO_RATED_CREDIT,
      null as ENT_AGE_EFFDT,
      ''RETRO'' as SRC,
      BLR_RN as SRC_BLR_RN
        from BDR_DM.wrk_premium_data_bl_rebuild;								-- SQL#3 STOP
    	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

--------------------------COMMENTED BY OAS------------------------------
/* V_ROWS_AFFTD:=SQL%ROWCOUNT;
  commit;
  INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''DERIVATIVE PREMIUM1'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''INSERT1'',
      ''Insert into temp table WRK_RIA_PREMIUM_DATA_BL_REBUILD'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );
  commit;
*/
--------------------------------COMMENTED BY OAS------------------------------


--  EXECUTE IMMEDIATE ''TRUNCATE TABLE DM.temp_RIA_premium_range'';
--EXECUTE IMMEDIATE ''TRUNCATE TABLE DM.wrk_RIA_individual_id_dates'';
--EXECUTE IMMEDIATE ''TRUNCATE TABLE DM.TEMP_RIA_PREM_PURGE'';
----EXECUTE IMMEDIATE ''TRUNCATE TABLE DM.WRK_PREMIUM_PURGED'';
--EXECUTE IMMEDIATE ''TRUNCATE TABLE DM.wrk_RIA_tna_individual_id_dates'';
--EXECUTE IMMEDIATE ''TRUNCATE TABLE DM.TEMP_RIA_TNA_PREM_PURGE'';
----EXECUTE IMMEDIATE ''TRUNCATE TABLE DM.WRK_PREMIUM_PURGED_TNA'';
--
--
--
--  insert into dm.temp_RIA_premium_range
--WITH dtRange(Dt) AS
--(
--    SELECT v_purge_start as Dt from dual
--    UNION ALL
--    SELECT add_months(Dt, 1)
--    FROM DtRange
--    WHERE Dt < v_purge_end )
--    select * from dtRange where Dt > = v_purge_start and  Dt < v_purge_end;
--
--    --commit;
--
--DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''TEMP_RIA_PREMIUM_RANGE'');
--
--  INSERT /*+ ENABLE_PARALLEL_DML APPEND */  INTO dm.wrk_RIA_individual_id_dates																-- SQL#5(b) START
-- SELECT /*+ parallel(8) */  demo.INDIVIDUAL_ID, demo.insuredplan_id as INSURED_PLAN_ID, min( dtRange.Dt) as min_due_date,  max(dtRange.Dt) as max_due_date
----     FROM dm.wrk_compas_demographicdata demo --------AOP De-Scope - MB/MC Premium Fact
--       FROM dm.wrk_RIA_compas_demographicdata demo --------AOP Scope - MB/MC Premium Fact
----        INNER JOIN dm.temp_baseline_rebuld_distindid indvidC     --------AOP De-Scope - MB/MC Premium Fact
--          INNER JOIN dm.TEMP_BASELINE_REBULD_DISTINDID indvid  --------AOP Scope - MB/MC Premium Fact
--  ON indvid.individual_id = demo.individual_id
----      INNER JOIN dm.temp_premium_range dtRange  --------AOP De-Scope - MB/MC Premium Fact
--		INNER JOIN dm.temp_RIA_premium_range dtRange --------AOP Scope - MB/MC Premium Fact
--  ON dtRange.DT BETWEEN demo.billingbucket_startdate AND demo.der_billingbucket_stopdate
--  group by demo.INDIVIDUAL_ID, demo.insuredplan_id;																							-- SQL#5(b) STOP
--
--  V_ROWS_AFFTD:=SQL%ROWCOUNT;
--  -- --commit;
--  INSERT INTO ETL.ETL_DETAIL_LOAD_INFO
--    (
--      APPLICATION ,
--      ETL_BATCH_ID,
--      ETL_PROC_NAME ,
--      ACTION ,
--      STEP_INFO ,
--      ROWS_AFFECTED ,
--      ETL_DATETIME
--    )
--    VALUES
--    (
--      ''DERIVATIVE PREMIUM1'',
--      V_BTCH_ID,
--      V_PROC_NAME,
--      ''INSERT'',
--      ''Insert into temp table WRK_RIA_INDIVIDUAL_ID_DATES'',
--      V_ROWS_AFFTD,
--      SYSTIMESTAMP
--    );
--  --commit;
--
--
--DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''wrk_RIA_individual_id_dates'');
--
-- INSERT /*+ ENABLE_PARALLEL_DML APPEND */  INTO DM.TEMP_RIA_PREM_PURGE
-- select /*+ parallel(8) */  distinct INDIVIDUAL_ID, INSURED_PLAN_ID, due_date from (
-- select /*+ parallel(8) */ INDIVIDUAL_ID, INSURED_PLAN_ID, min_due_date as due_date from dm.wrk_RIA_individual_id_dates
-- union all
-- select /*+ parallel(8) */ INDIVIDUAL_ID, INSURED_PLAN_ID, max_due_date as due_date from dm.wrk_RIA_individual_id_dates);
--
--   V_ROWS_AFFTD:=SQL%ROWCOUNT;
--
--  INSERT INTO ETL.ETL_DETAIL_LOAD_INFO
--    (
--      APPLICATION ,
--      ETL_BATCH_ID,
--      ETL_PROC_NAME ,
--      ACTION ,
--      STEP_INFO ,
--      ROWS_AFFECTED ,
--      ETL_DATETIME
--    )
--    VALUES
--    (
--      ''DERIVATIVE PREMIUM1'',
--      V_BTCH_ID,
--      V_PROC_NAME,
--      ''INSERT'',
--      ''Insert into temp table TEMP_RIA_PREM_PURGE'',
--      V_ROWS_AFFTD,
--      SYSTIMESTAMP
--    );
--  --commit;
--
--DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''TEMP_RIA_PREM_PURGE'');
--
--
--
--
--INSERT														-- SQL#6 START
--    /*+ ENABLE_PARALLEL_DML APPEND */
--  INTO dm.wrk_RIA_premium_data_bl_rebuild
--    (
--      household_id,
--      individual_id,
--      ins_plan_billing_bucket_id,
--      insured_plan_id,
--      household_address_id,
--      premium_due_date,
--      activity_date,
--      paid_cert,
--      del_cert,
--      term_cert,
--      paid_premium_amt,
--      delinquent_premium_due_amt,
--      plan_cd,
--      benefit_mod_category_id,
--      insured_plan_effective_date,
--      insured_plan_termination_date,
--      cert_termination_date,
--      state_cd,
--      zip_cd,
--      country_cd,
--      issue_state,
--      issue_country_cd,
--      issue_zip_cd,
--      gender_cd,
--      date_of_birth,
--      etl_lst_btch_id,
--      cert_acqn_chnl_level3,
--      account_number,
--      termination_reason_name,
--      conservation_reason_name,
--      plan_group,
--      product_group,
--      cert_actv_lvl_3_txt,
--      undwr_tag_key,
--      prdct_eff_dt,
--      prdct_acqn_chnl_level3,
--      legal_entity_name,
--      mbr_pd_prem_amt,
--      mbr_delq_prem_amt,
--      er_pd_prem_amt,
--      er_delq_prem_amt,
--      current_signature_date,
--      original_signature_date,
--      original_insuredplan_id,
--      writing_agent,
--      selling_agent,
--      original_selling_agent,
--      dcm_insured_plan_id,
--      dcm_insured_plan_eff_date,
--      dcm_plan_cd,
--      dcm_signature_date,
--      dcm_writing_agent,
--      dcm_derived_compas_agent,
--      ret_typ_id,
--      er_skey,
--      agt_wrt_skey,
--      agt_sel_orig_skey,
--      agt_sel_skey,
--      agt_dcm_wrt_skey,
--      D_DSCNT_ANNL_PAYR_SK,
--      D_DSCNT_EFT_SK,
--      D_DSCNT_ERLY_ENRL_SK,
--      D_DSCNT_LNGVTY_SK,
--      D_DSCNT_MULTI_INSD_SK,
--      D_SURCHRG_TBCC_USER_SK,
--      D_SURCHRG_TIER_SK,
--      D_INSD_PLN_PRFL_SK,
--      D_CALC_RT_SK,
--      MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
--      DSCNT_PD_ANNL_PAYR_AMT,
--      DSCNT_PD_EFT_AMT,
--      DSCNT_PD_ERLY_ENRL_AMT,
--      DSCNT_PD_LNGVTY_AMT,
--      DSCNT_PD_MULTI_INSD_AMT,
--      SURCHRG_PD_TBCC_USER_AMT,
--      SURCHRG_PD_TIER_AMT,
--      DSCNT_DELQ_ANNL_PAYR_AMT,
--      DSCNT_DELQ_EFT_AMT,
--      DSCNT_DELQ_ERLY_ENRL_AMT,
--      DSCNT_DELQ_LNGVTY_AMT,
--      DSCNT_DELQ_MULTI_INSD_AMT,
--      SURCHRG_DELQ_TBCC_USER_AMT,
--      SURCHRG_DELQ_TIER_AMT,
--      ORIGINAL_REFERRAL_AGENT,
--      REFERRAL_AGENT,
--      AGT_REF_ORIG_D_AGT_SK,
--      AGT_REF_D_AGT_SK,
--      D_MBR_INFO_SK,
--      D_PLN_BEN_MOD_SK,
--      RES_D_GEO_XREF_SK,
--      PLN_ISS_D_GEO_XREF_SK,
--      D_RTNG_AREA_SK,
--      F_APPL_TRANS_DAY_SK,
--      CERT_SALE_CHNL_LVL_1,
--      CERT_SALE_CHNL_LVL_2,
--      CERT_SALE_CHNL_LVL_3,
--      PRDCT_SALE_CHNL_LVL_1,
--      PRDCT_SALE_CHNL_LVL_2,
--      PRDCT_SALE_CHNL_LVL_3,
--      D_NEW_TO_MEDCR_SK,
--      DSCNT_PD_NEW_TO_MEDCR_AMT,
--      DSCNT_DLQNT_NEW_TO_MEDCR_AMT,
--      D_UNDWR_GUID_SK,
--      D_AGT_POL_SK,
--      PRO_RATED_CREDIT,
--      ENT_AGE_EFFDT,
--      SRC
--    )
--SELECT /*+ parallel(8) */   distinct
--         household_id as HOUSEHOLD_ID,
--    individual_id as INDIVIDUAL_ID,
--    insplan_billingbucket_id as INS_PLAN_BILLING_BUCKET_ID,
--    insuredplan_id as INSURED_PLAN_ID,
--     -1 as           HOUSEHOLD_ADDRESS_ID,
--          due_date as PREMIUM_DUE_DATE,
--          v_activitydate  as ACTIVITY_DATE,
--          paidcert,
--    delcert,
--    termcert,
--          0 as PAID_PREMIUM_AMT,
--          0 as DELINQUENT_PREMIUM_DUE_AMT,
--           PLAN_CD as PLAN_CD,
--          0 as BENEFIT_MOD_CATEGORY_ID, --default
--           insuredplan_effectivedate as INSURED_PLAN_EFFECTIVE_DATE,
--           insuredplan_terminationdate as INSURED_PLAN_TERMINATION_DATE,
--       certterminationdate,
--    ''ZZ'' as STATE_CD,
--    ''99999'' as ZIP_CD,
--    ''ZZ'' as COUNTRY_CD,
--    issue_state,
--    issue_country_cd,
--    issue_zip_cd,
--    gender_cd,
--    date_of_birth,
--    v_etlcurrentbatchid AS etl_lst_btch_id,
--    cert_acqn_chnl_level3, -- Adding Cert Channel 8/4/2015
--    ''-1'' AS ACCOUNT_NUMBER,
--     termination_reason_name as TERMINATION_REASON_NAME,
--     conservation_reason_name as CONSERVATION_REASON_NAME,
--     pln_grp as PLAN_GROUP,
--     prdct_grp as PRODUCT_GROUP,
--     NULL as CERT_ACTV_LVL_3_TXT,
--     -1 as UNDWR_TAG_KEY,
--      NULL AS prdct_eff_dt,
--      NULL AS prdct_acqn_chnl_level3,
--      NULL AS LEGAL_ENTITY_NAME,
--      0.00 mbr_pd_prem_amt,
--        0.00 mbr_delq_prem_amt,
--        0.00 emp_pd_prem_amt,
--        0.00 emp_delq_prem_amt,
--        NULL AS current_signature_date,
--        NULL AS original_signature_date,
--        NULL AS original_insured_plan_id,
--        NULL AS writing_agent,
--        NULL AS selling_agent,
--        NULL AS original_selling_agent,
--        NULL AS dcm_insured_plan_id,
--        NULL AS dcm_insd_pln_eff_dt,
--        NULL AS dcm_plan_cd,
--        NULL AS dcm_signature_date,
--        NULL AS dcm_writing_agent,
--        NULL AS dcm_derived_compas_agent,
--      ret_typ_id,
--    -2 as d_emp_sk,
--    -1   AS agt_wrt_d_agt_sk,
--    -1   AS agt_sel_orig_d_agt_sk,
--    -1   AS agt_sel_d_agt_sk,
--    -1   AS agt_dcm_wrt_d_agt_sk,
--     -1 as D_DSCNT_ANNL_PAYR_SK,
--    -1 AS D_DSCNT_EFT_SK,
--    -1 as D_DSCNT_ERLY_ENRL_SK,
--    -1 as D_DSCNT_LNGVTY_SK,
--    -1 as D_DSCNT_MULTI_INSD_SK,
--    -1 as D_SURCHRG_TBCC_USER_SK, -- SCR61587 28Jun2018
--    -1 as D_SURCHRG_TIER_SK,                  -- SCR61587 28Jun2018
--    -1 AS D_INSD_PLN_PRFL_SK,
--    -1 as D_CALC_RT_SK,
--    0 AS MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
--    0 AS DSCNT_PD_ANNL_PAYR_AMT,
--    0 AS DSCNT_PD_EFT_AMT,
--    0 AS DSCNT_PD_ERLY_ENRL_AMT,
--    0 AS DSCNT_PD_LNGVTY_AMT,
--    0 AS DSCNT_PD_MULTI_INSD_AMT,
--    0 AS SURCHRG_PD_TBCC_USER_AMT,
--    0 AS SURCHRG_PD_TIER_AMT,
--    0 AS DSCNT_DELQ_ANNL_PAYR_AMT,
--    0 AS DSCNT_DELQ_EFT_AMT,
--    0 AS DSCNT_DELQ_ERLY_ENRL_AMT,
--    0 AS DSCNT_DELQ_LNGVTY_AMT,
--    0 AS DSCNT_DELQ_MULTI_INSD_AMT,
--    0 AS SURCHRG_DELQ_TBCC_USER_AMT,
--    0 AS SURCHRG_DELQ_TIER_AMT,
--    NULL AS ORIGINAL_REFERRAL_AGENT,
--    NULL AS REFERRAL_AGENT,
--    -2   AS AGT_REF_ORIG_D_AGT_SK,
--    -2   AS AGT_REF_D_AGT_SK,
--    -1 as D_MBR_INFO_SK,
--    -1 as D_PLN_BEN_MOD_SK,
--    -1 as RES_D_GEO_XREF_SK,
--    -1 as PLN_ISS_D_GEO_XREF_SK,
--    -1 as D_RTNG_AREA_SK,
--    -1 as F_APPL_TRANS_DAY_SK,
--     null as  CERT_SALE_CHNL_LVL_1,
--     null as CERT_SALE_CHNL_LVL_2,
--     null as CERT_SALE_CHNL_LVL_3,
--     null as  PRDCT_SALE_CHNL_LVL_1,
--     null as PRDCT_SALE_CHNL_LVL_2,
--     null as PRDCT_SALE_CHNL_LVL_3,
--     1 as  D_NEW_TO_MEDCR_SK,
--     0 as  DSCNT_PD_NEW_TO_MEDCR_AMT,
--      0 as DSCNT_DLQNT_NEW_TO_MEDCR_AMT,
--      -1 as D_UNDWR_GUID_SK,
--      -1 as D_AGT_POL_SK,
--           0 as PRO_RATED_CREDIT,
--     null as ENT_AGE_EFFDT,
--     ''PURGE'' as SRC
--    from (
-- SELECT /*+ parallel(8) */
--         demo.household_id ,
--    demo.individual_id ,
--    demo.insplan_billingbucket_id ,
--    demo.insuredplan_id ,
--    bc.due_date ,
--              CASE   WHEN ( ( demo.insuredplan_terminationdate IS NULL
--      AND TO_DATE(''9999-12-31'',''YYYY-MM-DD'')    <= bc.due_date )
--      OR ( bc.due_date                          = NVL(demo.individual_profile_startdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')) ) )
--      THEN 0--''Y''
--      WHEN ( ( demo.insuredplan_terminationdate                                                                                                                                                IS NOT NULL
--      AND TRUNC(add_months(TO_DATE(REPLACE(TO_CHAR(demo.insuredplan_terminationdate,''RRRR-MM-DD HH24:MI:SS''),''9999-12-31 00:00:00'',''9999-11-30 00:00:00''),''RRRR-MM-DD HH24:MI:SS''),1),''MONTH'') <= bc.due_date )
--      OR ( bc.due_date                                                                                                                                                                         = NVL(demo.individual_profile_startdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')) ) )
--      THEN 0--''Y''
--      --WHEN ( ar.due_date IS NULL ) -- AOP De-Scope MB/MC Premium Fact
--      WHEN ( ARV.Premium_due_date IS NULL ) -- AOP Scope MB/MC Premium Fact
--      OR ( bc.due_date BETWEEN NVL(demo.individual_profile_startdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')) AND NVL(demo.individual_profile_stopdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')) )
--      THEN 0--''S''
--      ELSE
--        CASE
--         /* WHEN ( SUM(ar.due_amount) > 0  -- AOP De-Scope MB/MC Premium Fact									(MR Scope)
--          AND ( SUM(ar.paid_amount) = SUM(ar.due_amount) ) )--''N'' */ -- AOP De-Scope MB/MC Premium Fact			(MR Scope)
--		  WHEN ( SUM(ARV.BILL_PREM_AMT) > 0   -- AOP Scope MB/MC Premium Fact									(MR Scope)
--          AND ( SUM(ARV.PAY_PREM_AMT) = SUM(ARV.BILL_PREM_AMT) ) )--''N'' -- AOP Scope MB/MC Premium Fact			(MR Scope)
--          THEN 1
--          ELSE 0
--        END
--    END paidcert,
--    CASE
--      WHEN ( ( demo.insuredplan_terminationdate IS NULL
--      AND TO_DATE(''9999-12-31'',''YYYY-MM-DD'')    <= bc.due_date )
--      OR ( bc.due_date                          = NVL(demo.individual_profile_startdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')) ) )
--      THEN 0--''Y''
--      WHEN ( ( demo.insuredplan_terminationdate                                                                                                                                                IS NOT NULL
--      AND TRUNC(add_months(TO_DATE(REPLACE(TO_CHAR(demo.insuredplan_terminationdate,''RRRR-MM-DD HH24:MI:SS''),''9999-12-31 00:00:00'',''9999-11-30 00:00:00''),''RRRR-MM-DD HH24:MI:SS''),1),''MONTH'') <= bc.due_date )
--      OR ( bc.due_date                                                                                                                                                                         = NVL(demo.individual_profile_startdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')) ) )
--      THEN 0--''Y''
--      --WHEN ( ar.due_date IS NULL ) -- AOP De-Scope MB/MC Premium Fact
--      WHEN ( ARV.Premium_due_date IS NULL ) -- AOP Scope MB/MC Premium Fact
--      OR ( bc.due_date BETWEEN NVL(demo.individual_profile_startdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')) AND NVL(demo.individual_profile_stopdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')) )
--      THEN 0--''S''
--      ELSE
--        CASE
--        /*  WHEN ( SUM(ar.due_amount) > 0   -- AOP De-Scope MB/MC Premium Fact									(MR Scope)
--          AND ( SUM(ar.paid_amount) < SUM(ar.due_amount) ) )--''N'' */ -- AOP De-Scope MB/MC Premium Fact			(MR Scope)
--		  WHEN ( SUM(ARV.BILL_PREM_AMT) > 0    -- AOP Scope MB/MC Premium Fact									(MR Scope)
--          AND ( SUM(ARV.PAY_PREM_AMT) < SUM(ARV.BILL_PREM_AMT) ) )--''N''  -- AOP Scope MB/MC Premium Fact		(MR Scope)
--          THEN 1
--          ELSE 0
--        END
--    END delcert,
--    CASE
--      WHEN ( ( demo.insuredplan_terminationdate IS NULL
--      AND TO_DATE(''9999-12-31'',''YYYY-MM-DD'')    <= bc.due_date )
--      OR ( bc.due_date                          = NVL(demo.individual_profile_startdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')) ) )
--      THEN 1--''Y''
--      WHEN ( ( demo.insuredplan_terminationdate                                                                                                                                               IS NOT NULL
--      AND TRUNC(add_months(TO_DATE(REPLACE(TO_CHAR(demo.insuredplan_terminationdate,''RRRR-MM-DD HH24:MI:SS''),''9999-12-31 00:00:00'',''9999-11-30 00:00:00''),''RRRR-MM-DD HH24:MI:SS''),1),''MONTH'')<= bc.due_date )
--      OR ( bc.due_date                                                                                                                                                                        = NVL(demo.individual_profile_startdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')) ) )
--      THEN 1--''Y''
--     --WHEN ( ar.due_date IS NULL ) -- AOP De-Scope MB/MC Premium Fact
--      WHEN ( ARV.Premium_due_date IS NULL ) -- AOP Scope MB/MC Premium Fact
--      OR ( bc.due_date BETWEEN NVL(demo.individual_profile_startdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')) AND NVL(demo.individual_profile_stopdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')) )
--      THEN 0--''S''
--      ELSE 0
--    END termcert,
--          demo.PLAN_CD ,
--           demo.insuredplan_effectivedate ,
--           demo.insuredplan_terminationdate ,
--      CASE
--      WHEN ((demo.insuredplan_terminationdate IS NULL
--      AND TO_DATE(''9999-12-31'',''YYYY-MM-DD'')  <= bc.due_date)
--      OR (bc.due_date                         = NVL(demo.individual_profile_startdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD''))))
--      THEN bc.due_date
--      WHEN ((demo.insuredplan_terminationdate                                                                                                                                                  IS NOT NULL
--      AND TRUNC(add_months(TO_DATE(REPLACE(TO_CHAR(demo.insuredplan_terminationdate,''RRRR-MM-DD HH24:MI:SS''),''9999-12-31 00:00:00'',''9999-11-30 00:00:00''),''RRRR-MM-DD HH24:MI:SS''),1),''MONTH'') <= bc.due_date)
--      OR (bc.due_date                                                                                                                                                                          = NVL(demo.individual_profile_startdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD''))))
--      THEN bc.due_date
--      --WHEN ( ar.due_date IS NULL ) -- AOP De-Scope MB/MC Premium Fact
--      WHEN ( ARV.Premium_due_date IS NULL ) -- AOP Scope MB/MC Premium Fact
--      OR (bc.due_date BETWEEN NVL(demo.individual_profile_startdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')) AND NVL(demo.individual_profile_stopdate,TO_DATE(''0001-01-01'',''YYYY-MM-DD'')))
--      THEN NULL
--      ELSE NULL
--    END certterminationdate,
--    demo.issue_state,
--    demo.issue_country_cd,
--    demo.issue_zip_cd,
--    demo.gender_cd,
--    demo.date_of_birth,
--      demo.cert_acqn_chnl_level3, -- Adding Cert Channel 8/4/2015
--      demo.termination_reason_name,
--     demo.conservation_reason_name ,
--     pbm.pln_grp ,
--     pbm.prdct_grp,
--      demo.ret_typ_id
--      --demo.F_APPL_TRANS_DAY_SK
--               FROM dm.wrk_RIA_compas_demographicdata demo
------JOIN 		DM.TEMP_RIA_MONTH_DATE cd ON cd.monthdate BETWEEN demo.billingbucket_startdate AND demo.der_billingbucket_stopdate  ----Adding in US116471
--              inner join dm.TEMP_RIA_PREM_PURGE bc
--              ON bc.INDIVIDUAL_ID = demo.INDIVIDUAL_ID
--              AND bc.due_date between demo.billingbucket_startdate AND demo.der_billingbucket_stopdate
--
--   /* LEFT JOIN compas.account_receivable ar  -- AOP De-Scope MC/MB Premium_Fact  (MR Scope)
--    ON ( demo.household_id            = ar.household_id
--    AND ar.due_date                   = bc.due_date
--    AND ar.acct_receivable_type_id    = 2         -- premium
--    AND ar.responsible_party_type_id IN ( 1, 2 ) )-- household,employer */
--
--    LEFT JOIN RIA.AR_FACT ARV  -- AOP Scope MC/MB Premium_Fact  -- AR_FACT_VW REPLACED BY AR_FACT
--    ON ( demo.individual_id            = ARV.individual_id
--    AND ARV.Premium_due_date          = bc.due_date
--	AND ARV.RECEIVABLE_TYPE    = ''Medical''         -- premium
--	AND ARV.RESPONSIBLE_PARTY_ID IN ( 1, 2 ) ) -- household,employer
--
--    LEFT JOIN dm.wrk_pgd_insplanbenmod ipbenmod
--    ON ( demo.insuredplan_id = ipbenmod.insured_plan_id
--    AND bc.due_date BETWEEN ipbenmod.insplanbenmod_startdate AND ipbenmod.insplanbenmod_stopdate )
--   LEFT JOIN conf.d_pln_ben_mod pbm
--   ON NVL(demo.plan_cd,''zz'')            = NVL(pbm.compas_pln_cd,''zz'')
--   AND NVL(ipbenmod.plancd_benmodcat,0) = NVL(pbm.compas_ben_mod_catgy_id,0)
--  group by    bc.due_date,
--    demo.household_id,
--    demo.individual_id,
--    demo.insplan_billingbucket_id,
--    demo.insuredplan_id,
--    --ar.due_date, -- AOP De-Scope MC/MB Premium_Fact
--    ARV.Premium_due_date, -- AOP Scope MC/MB Premium_Fact
--    demo.plan_cd,
--    NVL(ipbenmod.plancd_benmodcat,0),
--    demo.insuredplan_effectivedate,
--    demo.insuredplan_terminationdate,
--    demo.individual_profile_startdate,
--    demo.individual_profile_stopdate,
--    demo.issue_state,
--    demo.issue_country_cd,
--    demo.issue_zip_cd,
--    demo.gender_cd,
--    demo.date_of_birth,
--    demo.cert_acqn_chnl_level3,   -- Adding Cert Channel 8/4/2015
--    demo.termination_reason_name, --Added 20150825,Cert Activity
--    demo.conservation_reason_name,
--    pbm.pln_grp,
--    pbm.prdct_grp,
--    demo.ret_typ_id,
--    demo.D_DSCNT_ANNL_PAYR_SK,
--    demo.D_DSCNT_ERLY_ENRL_SK,
--    demo.D_DSCNT_LNGVTY_SK,
--    demo.D_DSCNT_MULTI_INSD_SK,
--    demo.D_CALC_RT_SK);																		-- SQL#6 STOP
--
--
--
--
--
--   V_ROWS_AFFTD:=SQL%ROWCOUNT;
--
--  INSERT INTO ETL.ETL_DETAIL_LOAD_INFO
--    (
--      APPLICATION ,
--      ETL_BATCH_ID,
--      ETL_PROC_NAME ,
--      ACTION ,
--      STEP_INFO ,
--      ROWS_AFFECTED ,
--      ETL_DATETIME
--    )
--    VALUES
--    (
--      ''DERIVATIVE PREMIUM1'',
--      V_BTCH_ID,
--      V_PROC_NAME,
--      ''INSERT'',
--      ''Insert into PREMIUM_PURGED'',
--      V_ROWS_AFFTD,
--      SYSTIMESTAMP
--    );
--  --commit;
--
------tna records-purge --------
--
--
--
--  INSERT /*+ ENABLE_PARALLEL_DML APPEND */  INTO dm.wrk_RIA_tna_individual_id_dates													-- SQL#7 START
--
--     select /*+ parallel(8) */  ip.INDIVIDUAL_ID, ip.INSURED_PLAN_ID, min(dtRange.Dt) as min_due_date,  max(dtRange.Dt) as max_due_date
--  FROM compas.INSURED_PLAN IP
----  JOIN dm.temp_baseline_rebuld_distindid indvid    -- AOP De-Scope - MB/MC Premium Fact
--  JOIN dm.TEMP_BASELINE_REBULD_DISTINDID indvid  -- AOP Scope - MB/MC Premium Fact
--  ON indvid.individual_id = IP.individual_id
--          INNER JOIN dm.temp_RIA_premium_range DtRange
--  ON dtRange.DT BETWEEN IP.INSURED_PLAN_EFFECTIVE_DATE AND IP.INSURED_PLAN_TERMINATION_DATE
--  JOIN compas.INDIVIDUAL IND
--  ON IP.INDIVIDUAL_ID = IND.INDIVIDUAL_ID
--        JOIN compas.HOUSEHOLD_MEMBER HM
--        ON IP.INDIVIDUAL_ID = HM.INDIVIDUAL_ID
--        WHERE IP.INSURED_PLAN_EFFECTIVE_DATE = IP.INSURED_PLAN_TERMINATION_DATE
--             AND IP.INSURED_PLAN_ID NOT IN
--  (
----  SELECT DISTINCT INSURED_PLAN_ID FROM Compas.INS_PLAN_BILLING_BUCKET  --AOP De-Scope - MB/MC Premium Fact
--select  DISTINCT MD.EXT_MEMBER_ID as INSURED_PLAN_ID FROM RIA.MEMBERSHIP_DIM MD Join RIA.BCHG_FACT BF on MD.SRC_MEMBERSHIP_ID = BF.CDDGEN1_VAL WHERE MD.EXT_MEMBER_ID IS NOT NULL  ----AOP Scope - MB/MC Premium Fact
--  )
--AND IP.INSURED_PLAN_EFFECTIVE_DATE BETWEEN HM.HHOLD_MEMBER_START_DATE AND HM.HHOLD_MEMBER_STOP_DATE
--  group by ip.INDIVIDUAL_ID, ip.INSURED_PLAN_ID;																				-- SQL#7 STOP
--
--    V_ROWS_AFFTD:=SQL%ROWCOUNT;
--
--  INSERT INTO ETL.ETL_DETAIL_LOAD_INFO
--    (
--      APPLICATION ,
--      ETL_BATCH_ID,
--      ETL_PROC_NAME ,
--      ACTION ,
--      STEP_INFO ,
--      ROWS_AFFECTED ,
--      ETL_DATETIME
--    )
--    VALUES
--    (
--      ''DERIVATIVE PREMIUM1'',
--      V_BTCH_ID,
--      V_PROC_NAME,
--      ''INSERT'',
--      ''Insert into temp table WRK_RIA_TNA_INDIVIDUAL_ID_DATES'',
--      V_ROWS_AFFTD,
--      SYSTIMESTAMP
--    );
--  --commit;
--
--
--
--  INSERT /*+ ENABLE_PARALLEL_DML APPEND */  INTO DM.TEMP_RIA_TNA_PREM_PURGE
-- select /*+ parallel(8) */  distinct INDIVIDUAL_ID, INSURED_PLAN_ID, due_date from (
-- select /*+ parallel(8) */ INDIVIDUAL_ID, INSURED_PLAN_ID, min_due_date as due_date from dm.wrk_RIA_tna_individual_id_dates
--  union all
-- select /*+ parallel(8) */ INDIVIDUAL_ID, INSURED_PLAN_ID, max_due_date as due_date from dm.wrk_RIA_tna_individual_id_dates);
--
--    V_ROWS_AFFTD:=SQL%ROWCOUNT;
--
--  INSERT INTO ETL.ETL_DETAIL_LOAD_INFO
--    (
--      APPLICATION ,
--      ETL_BATCH_ID,
--      ETL_PROC_NAME ,
--      ACTION ,
--      STEP_INFO ,
--      ROWS_AFFECTED ,
--      ETL_DATETIME
--    )
--    VALUES
--    (
--      ''DERIVATIVE PREMIUM1'',
--      V_BTCH_ID,
--      V_PROC_NAME,
--      ''INSERT'',
--      ''Insert into temp table TEMP_RIA_TNA_PREM_PURGE'',
--      V_ROWS_AFFTD,
--      SYSTIMESTAMP
--    );
--
--  --commit;
--
--
--
--  /* INSERT  INTO DM.WRK_PREMIUM_PURGED_TNA
--    (HOUSEHOLD_ID , INDIVIDUAL_ID, INS_PLAN_BILLING_BUCKET_ID , INSURED_PLAN_ID , HOUSEHOLD_ADDRESS_ID , PREMIUM_DUE_DATE , INSURED_PLAN_EFFECTIVE_DATE , INSURED_PLAN_TERMINATION_DATE , CERT_TERMINATION_DATE ,
--TERMINATION_REASON_NAME , CONSERVATION_REASON_NAME, PRODUCT_GROUP, PLAN_GROUP, PLAN_CD, CERT_ACQN_CHNL_LEVEL3)
--*/
--
--INSERT																			-- SQL#8 START
--    /*+ ENABLE_PARALLEL_DML APPEND */
--  INTO dm.wrk_RIA_premium_data_bl_rebuild  -- AOP Scope - MB/MC Premium Fact
--    (
--      household_id,
--      individual_id,
--      ins_plan_billing_bucket_id,
--      insured_plan_id,
--      household_address_id,
--      premium_due_date,
--      activity_date,
--      paid_cert,
--      del_cert,
--      term_cert,
--      paid_premium_amt,
--      delinquent_premium_due_amt,
--      plan_cd,
--      benefit_mod_category_id,
--      insured_plan_effective_date,
--      insured_plan_termination_date,
--      cert_termination_date,
--      state_cd,
--      zip_cd,
--      country_cd,
--      issue_state,
--      issue_country_cd,
--      issue_zip_cd,
--      gender_cd,
--      date_of_birth,
--      etl_lst_btch_id,
--      cert_acqn_chnl_level3,
--      account_number,
--      termination_reason_name,
--      conservation_reason_name,
--      plan_group,
--      product_group,
--      cert_actv_lvl_3_txt,
--      undwr_tag_key,
--      prdct_eff_dt,
--      prdct_acqn_chnl_level3,
--      legal_entity_name,
--      mbr_pd_prem_amt,
--      mbr_delq_prem_amt,
--      er_pd_prem_amt,
--      er_delq_prem_amt,
--      current_signature_date,
--      original_signature_date,
--      original_insuredplan_id,
--      writing_agent,
--      selling_agent,
--      original_selling_agent,
--      dcm_insured_plan_id,
--      dcm_insured_plan_eff_date,
--      dcm_plan_cd,
--      dcm_signature_date,
--      dcm_writing_agent,
--      dcm_derived_compas_agent,
--      ret_typ_id,
--      er_skey,
--      agt_wrt_skey,
--      agt_sel_orig_skey,
--      agt_sel_skey,
--      agt_dcm_wrt_skey,
--      D_DSCNT_ANNL_PAYR_SK,
--      D_DSCNT_EFT_SK,
--      D_DSCNT_ERLY_ENRL_SK,
--      D_DSCNT_LNGVTY_SK,
--      D_DSCNT_MULTI_INSD_SK,
--      D_SURCHRG_TBCC_USER_SK,
--      D_SURCHRG_TIER_SK,
--      D_INSD_PLN_PRFL_SK,
--      D_CALC_RT_SK,
--      MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
--      DSCNT_PD_ANNL_PAYR_AMT,
--      DSCNT_PD_EFT_AMT,
--      DSCNT_PD_ERLY_ENRL_AMT,
--      DSCNT_PD_LNGVTY_AMT,
--      DSCNT_PD_MULTI_INSD_AMT,
--      SURCHRG_PD_TBCC_USER_AMT,
--      SURCHRG_PD_TIER_AMT,
--      DSCNT_DELQ_ANNL_PAYR_AMT,
--      DSCNT_DELQ_EFT_AMT,
--      DSCNT_DELQ_ERLY_ENRL_AMT,
--      DSCNT_DELQ_LNGVTY_AMT,
--      DSCNT_DELQ_MULTI_INSD_AMT,
--      SURCHRG_DELQ_TBCC_USER_AMT,
--      SURCHRG_DELQ_TIER_AMT,
--      ORIGINAL_REFERRAL_AGENT,
--      REFERRAL_AGENT,
--      AGT_REF_ORIG_D_AGT_SK,
--      AGT_REF_D_AGT_SK,
--      D_MBR_INFO_SK,
--      D_PLN_BEN_MOD_SK,
--      RES_D_GEO_XREF_SK,
--      PLN_ISS_D_GEO_XREF_SK,
--      D_RTNG_AREA_SK,
--      F_APPL_TRANS_DAY_SK,
--      CERT_SALE_CHNL_LVL_1,
--      CERT_SALE_CHNL_LVL_2,
--      CERT_SALE_CHNL_LVL_3,
--      PRDCT_SALE_CHNL_LVL_1,
--      PRDCT_SALE_CHNL_LVL_2,
--      PRDCT_SALE_CHNL_LVL_3,
--      D_NEW_TO_MEDCR_SK,
--      DSCNT_PD_NEW_TO_MEDCR_AMT,
--      DSCNT_DLQNT_NEW_TO_MEDCR_AMT,
--      D_UNDWR_GUID_SK,
--      D_AGT_POL_SK,
--      PRO_RATED_CREDIT,
--      ENT_AGE_EFFDT,
--      SRC
--    )
-- SELECT /*+ parallel(8) */ DISTINCT
--             HM.household_id as HOUSEHOLD_ID,
--    IP.individual_id as INDIVIDUAL_ID,
--    -1 as INS_PLAN_BILLING_BUCKET_ID,
--    IP.INSURED_PLAN_ID as INSURED_PLAN_ID,
--     -1 as           HOUSEHOLD_ADDRESS_ID,
--               NVL(IP.INSURED_PLAN_EFFECTIVE_DATE, tbc.due_date) AS PREMIUM_DUE_DATE,
--          v_activitydate as ACTIVITY_DATE,
--          0 as PAID_CERT,
--          0 as DEL_CERT,
--          1 as TERM_CERT,
--          0 as PAID_PREMIUM_AMT,
--          0 as DELINQUENT_PREMIUM_DUE_AMT,
--           IP.PLAN_CD as PLAN_CD,
--          0 as BENEFIT_MOD_CATEGORY_ID, --default
--  IP.INSURED_PLAN_EFFECTIVE_DATE   AS INSUREDPLAN_EFFECTIVEDATE ,
--  IP.INSURED_PLAN_TERMINATION_DATE AS INSUREDPLAN_TERMINATIONDATE ,
--  IP.INSURED_PLAN_TERMINATION_DATE AS CERT_TERMINATIONDATE ,
--    ''ZZ'' as STATE_CD,
--    ''99999'' as ZIP_CD,
--    ''ZZ'' as COUNTRY_CD,
--    ''ZZ'' as issue_state,
--    ''ZZ'' as issue_country_cd,
--    ''99999'' as issue_zip_cd,
--    ''U'' as gender_cd,
--    IND.DATE_OF_BIRTH,
--    v_etlcurrentbatchid AS etl_lst_btch_id,
--  NVL(IPAC.ACQUISITIONCHANNEL,''UNKNOWN'') as CERT_ACQN_CHNL_LEVEL3,
--    ''-1'' AS ACCOUNT_NUMBER,
--      TR.TERMINATION_REASON_NAME ,
--      CR.CONSERVATION_REASON_NAME ,
--     pbm.pln_grp as PLAN_GROUP,
--     pbm.prdct_grp as PRODUCT_GROUP,
--      NULL as CERT_ACTV_LVL_3_TXT,
--     -1 as UNDWR_TAG_KEY,
--      NULL AS prdct_eff_dt,
--      NULL AS prdct_acqn_chnl_level3,
--      NULL AS LEGAL_ENTITY_NAME,
--      0.00 mbr_pd_prem_amt,
--        0.00 mbr_delq_prem_amt,
--        0.00 emp_pd_prem_amt,
--        0.00 emp_delq_prem_amt,
--        NULL AS current_signature_date,
--        NULL AS original_signature_date,
--        NULL AS original_insured_plan_id,
--        NULL AS writing_agent,
--        NULL AS selling_agent,
--        NULL AS original_selling_agent,
--        NULL AS dcm_insured_plan_id,
--        NULL AS dcm_insd_pln_eff_dt,
--        NULL AS dcm_plan_cd,
--        NULL AS dcm_signature_date,
--        NULL AS dcm_writing_agent,
--        NULL AS dcm_derived_compas_agent,
--      -1 as ret_typ_id,
--    -2 as d_emp_sk,
--    -1   AS agt_wrt_d_agt_sk,
--    -1   AS agt_sel_orig_d_agt_sk,
--    -1   AS agt_sel_d_agt_sk,
--    -1   AS agt_dcm_wrt_d_agt_sk,
--     -1 as D_DSCNT_ANNL_PAYR_SK,
--    -1 AS D_DSCNT_EFT_SK,
--    -1 as D_DSCNT_ERLY_ENRL_SK,
--    -1 as D_DSCNT_LNGVTY_SK,
--    -1 as D_DSCNT_MULTI_INSD_SK,
--    -1 as D_SURCHRG_TBCC_USER_SK,
--    -1 as D_SURCHRG_TIER_SK,
--    -1 AS D_INSD_PLN_PRFL_SK,
--    -1 as D_CALC_RT_SK,
--    0 AS MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
--    0 AS DSCNT_PD_ANNL_PAYR_AMT,
--    0 AS DSCNT_PD_EFT_AMT,
--    0 AS DSCNT_PD_ERLY_ENRL_AMT,
--    0 AS DSCNT_PD_LNGVTY_AMT,
--    0 AS DSCNT_PD_MULTI_INSD_AMT,
--    0 AS SURCHRG_PD_TBCC_USER_AMT,
--    0 AS SURCHRG_PD_TIER_AMT,
--    0 AS DSCNT_DELQ_ANNL_PAYR_AMT,
--    0 AS DSCNT_DELQ_EFT_AMT,
--    0 AS DSCNT_DELQ_ERLY_ENRL_AMT,
--    0 AS DSCNT_DELQ_LNGVTY_AMT,
--    0 AS DSCNT_DELQ_MULTI_INSD_AMT,
--    0 AS SURCHRG_DELQ_TBCC_USER_AMT,
--    0 AS SURCHRG_DELQ_TIER_AMT,
--    NULL AS ORIGINAL_REFERRAL_AGENT,
--    NULL AS REFERRAL_AGENT,
--    -2   AS AGT_REF_ORIG_D_AGT_SK,
--    -2   AS AGT_REF_D_AGT_SK,
--    -1 as D_MBR_INFO_SK,
--    -1 as D_PLN_BEN_MOD_SK,
--    -1 as RES_D_GEO_XREF_SK,
--    -1 as PLN_ISS_D_GEO_XREF_SK,
--    -1 as D_RTNG_AREA_SK,
--    -1 as F_APPL_TRANS_DAY_SK,
--     null as    CERT_SALE_CHNL_LVL_1,
--     null as CERT_SALE_CHNL_LVL_2,
--     null as  CERT_SALE_CHNL_LVL_3,
--     null as PRDCT_SALE_CHNL_LVL_1,
--     null as PRDCT_SALE_CHNL_LVL_2,
--      null as PRDCT_SALE_CHNL_LVL_3,
--      1 as D_NEW_TO_MEDCR_SK,
--      0 as DSCNT_PD_NEW_TO_MEDCR_AMT,
--      0 as DSCNT_DLQNT_NEW_TO_MEDCR_AMT,
--      -1 as D_UNDWR_GUID_SK,
--      -1 as D_AGT_POL_SK,
--      0 as PRO_RATED_CREDIT,
--      null as ENT_AGE_EFFDT,
--      ''PURGE'' as SRC
--   FROM compas.INSURED_PLAN IP
-------JOIN DM.TEMP_RIA_MONTH_DATE cd  ON cd.monthdate BETWEEN IP.INSURED_PLAN_EFFECTIVE_DATE AND IP.INSURED_PLAN_TERMINATION_DATE      ----Adding in US116471
--           JOIN compas.INDIVIDUAL IND
--       ON IP.INDIVIDUAL_ID = IND.INDIVIDUAL_ID
--                INNER JOIN DM.TEMP_RIA_TNA_PREM_PURGE tbc
--          ON tbc.INDIVIDUAL_ID = IP.INDIVIDUAL_ID
--  and tbc.due_date BETWEEN IP.INSURED_PLAN_EFFECTIVE_DATE AND IP.INSURED_PLAN_TERMINATION_DATE
--        JOIN compas.HOUSEHOLD_MEMBER HM
--        ON IP.INDIVIDUAL_ID = HM.INDIVIDUAL_ID
--        LEFT JOIN compas.TERMINATION_REASON TR
--  ON IP.TERMINATION_REASON_ID = TR.TERMINATION_REASON_ID
--  LEFT JOIN compas.CONSERVATION_REASON CR
-- ON IP.CONSERVATION_REASON_ID = CR.CONSERVATION_REASON_ID
-- LEFT JOIN DM.WRK_PGD_INSPLANBENMOD IPBENMOD
-- ON (IP.INSURED_PLAN_ID = IPBENMOD.INSURED_PLAN_ID)
-- AND tbc.due_date BETWEEN IPBENMOD.INSPLANBENMOD_STARTDATE AND IPBENMOD.INSPLANBENMOD_STOPDATE
-- LEFT JOIN CONF.D_PLN_BEN_MOD PBM
-- ON NVL(IP.PLAN_CD,''ZZ'')              = NVL(PBM.COMPAS_PLN_CD,''ZZ'')
-- AND NVL(IPBENMOD.PLANCD_BENMODCAT,0) = NVL(PBM.COMPAS_BEN_MOD_CATGY_ID,0)
-- LEFT JOIN DM.WRK_IPACQUISITIONCHANNEL IPAC
-- ON IP.INSURED_PLAN_ID = IPAC.INSUREDPLANID
--        WHERE IP.INSURED_PLAN_EFFECTIVE_DATE = IP.INSURED_PLAN_TERMINATION_DATE
--             AND IP.INSURED_PLAN_ID NOT IN
--  (
--  -- SELECT DISTINCT INSURED_PLAN_ID FROM Compas.INS_PLAN_BILLING_BUCKET  --AOP De-Scope - MB/MC Premium Fact
--  select  DISTINCT MD.EXT_MEMBER_ID as INSURED_PLAN_ID FROM RIA.MEMBERSHIP_DIM MD Join RIA.BCHG_FACT BF on MD.SRC_MEMBERSHIP_ID = BF.CDDGEN1_VAL WHERE MD.EXT_MEMBER_ID IS NOT NULL  ----AOP Scope - MB/MC Premium Fact
--  )
-- AND IP.INSURED_PLAN_EFFECTIVE_DATE BETWEEN HM.HHOLD_MEMBER_START_DATE AND HM.HHOLD_MEMBER_STOP_DATE;									-- SQL#8 STOP
--
--   V_ROWS_AFFTD:=SQL%ROWCOUNT;
--
--  INSERT INTO ETL.ETL_DETAIL_LOAD_INFO
--    (
--      APPLICATION ,
--      ETL_BATCH_ID,
--      ETL_PROC_NAME ,
--      ACTION ,
--      STEP_INFO ,
--      ROWS_AFFECTED ,
--      ETL_DATETIME
--    )
--    VALUES
--    (
--      ''DERIVATIVE PREMIUM1'',
--      V_BTCH_ID,
--      V_PROC_NAME,
--      ''INSERT'',
--      ''Insert into temp table TEMP_RIA_TNA_PREM_PURGE'',
--      V_ROWS_AFFTD,
--      SYSTIMESTAMP
--    );
--
--  commit;

  
V_STEP_NAME    := ''INSERT - wrk_RIA_premium_data_bl_exp'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

  INSERT											
    /*+ ENABLE_PARALLEL_DML PARALLEL APPEND */
  INTO BDR_DM.wrk_RIA_premium_data_bl_exp
    (
      BL_RN,
      household_id,
      individual_id,
      ins_plan_billing_bucket_id,
      insured_plan_id,
      household_address_id,
      premium_due_date,
      activity_date,
      paid_cert,
      del_cert,
      term_cert,
      paid_premium_amt,
      delinquent_premium_due_amt,
      plan_cd,
      benefit_mod_category_id,
      insured_plan_effective_date,
      insured_plan_termination_date,
      cert_termination_date,
      state_cd,
      zip_cd,
      country_cd,
      issue_state,
      issue_country_cd,
      issue_zip_cd,
      gender_cd,
      date_of_birth,
      etl_lst_btch_id,
      cert_acqn_chnl_level3,
      account_number,
      termination_reason_name,
      conservation_reason_name,
      plan_group,
      product_group,
      cert_actv_lvl_3_txt,
      undwr_tag_key,
      prdct_eff_dt,
      prdct_acqn_chnl_level3,
      legal_entity_name
    )
  SELECT
    /*+ PARALLEL */
    BLR_RN,
    household_id,
    individual_id,
    ins_plan_billing_bucket_id,
    insured_plan_id,
    household_address_id,
    premium_due_date,
    activity_date,
    paid_cert,
    del_cert,
    term_cert,
    paid_premium_amt,
    delinquent_premium_due_amt,
    plan_cd,
    benefit_mod_category_id,
    insured_plan_effective_date,
    insured_plan_termination_date,
    cert_termination_date,
    state_cd,
    zip_cd,
    country_cd,
    issue_state,
    issue_country_cd,
    issue_zip_cd,
    gender_cd,
    date_of_birth,
    etl_lst_btch_id,
    cert_acqn_chnl_level3,
    account_number,
    termination_reason_name,
    conservation_reason_name,
    plan_group,
    product_group,
    cert_actv_lvl_3_txt,
    undwr_tag_key,
    prdct_eff_dt,
    prdct_acqn_chnl_level3,
    legal_entity_name
  FROM BDR_DM.wrk_RIA_premium_data_bl_rebuild
  WHERE paid_cert=0
  AND del_cert   = 0
  AND term_cert  = 0;						
    	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

----------------------------------COMMENTED BY OAS------------------------------
/*
  V_ROWS_AFFTD  :=SQL%ROWCOUNT;
  INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''DERIVATIVE PREMIUM1'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''INSERT'',
      ''Insert into temp table WRK_RIA_PREMIUM_DATA_BL_EXP'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );
  ----Delete Paid + Del + Term = 0 From BLR 11/13/2015.

     DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''WRK_RIA_PREMIUM_DATA_BL_REBUILD'');
*/
-------------------------------------COMMENTED BY OAS-------------------------------------
  
V_STEP_NAME    := ''DELETE - wrk_RIA_premium_data_bl_rebuild'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;

  DELETE
  FROM BDR_DM.wrk_RIA_premium_data_bl_rebuild
  WHERE paid_cert=0
  AND del_cert   = 0
  AND term_cert  = 0;
      	
V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_DELETED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );

INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

-------------------------------------COMMENTED BY OAS-------------------------------------
/*
  V_ROWS_AFFTD  :=SQL%ROWCOUNT;

   INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''DERIVATIVE PREMIUM1'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''DELETE'',
      ''Delete from table dm.WRK_RIA_PREMIUM_DATA_BL_REBUILD'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );

      DM.PKG_DB_UTIL.SP_GATHER_TABLE_STATS(''DM'',''WRK_RIA_PREMIUM_DATA_BL_REBUILD'');
  --DBMS_STATS.GATHER_TABLE_STATS (ownname => ''DM'',tabname => ''WRK_PREMIUM_DATA_BL_REBUILD'',partname => NULL,estimate_percent => 10, DEGREE => 4, granularity => ''ALL'', method_opt => ''FOR ALL COLUMNS SIZE 1'',CASCADE => TRUE);


 UPDATE ETL.ETL_APPLICATION_METADATA
  SET METADATA_VALUE = v_UW_CurrETLBatchID
  WHERE APPLICATION  =''PREMIUM''
  AND METADATA_TYPE  =''PGD_UWFactETLLastBatchID'';

  UPDATE ETL.ETL_APPLICATION_METADATA
  SET METADATA_VALUE =
    (SELECT TO_CHAR(MAX(LGR_ITM_DT),''MM-DD-YYYY HH24:MI:SS'')
    FROM dcm.DCM_COMM_PD
    WHERE   m_r_prdct_catgy IN (
                    ''AARP MS'',
                    ''MS''
                )
    )
  WHERE APPLICATION=''PREMIUM''
  AND METADATA_TYPE=''PGD_DCMLastDate'';
  --commit;
  INSERT
  INTO ETL.ETL_DETAIL_LOAD_INFO
    (
      APPLICATION ,
      ETL_BATCH_ID,
      ETL_PROC_NAME ,
      ACTION ,
      STEP_INFO ,
      ROWS_AFFECTED ,
      ETL_DATETIME
    )
    VALUES
    (
      ''DERIVATIVE PREMIUM1'',
      V_BTCH_ID,
      V_PROC_NAME,
      ''END'',
      ''PROCEDURE END'',
      V_ROWS_AFFTD,
      SYSTIMESTAMP
    );
  P_ToContinueStatus := ''Y'';
  P_ErrorYNFlg       := ''N'';
  P_ErrorStr         := '''';
EXCEPTION
WHEN OTHERS THEN
  P_ErrorStr         := ''ERROR: '' || SQLCODE || ''-'' || SQLERRM || ''-'' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE()|| Chr(10)||DBMS_UTILITY.FORMAT_ERROR_STACK();
  P_ToContinueStatus := ''N'';
  P_ErrorYNFlg       := ''Y'';
  ROLLBACK;
END;
/ */
-------------------------------------------COMMENTED BY OAS--------------------------------------------

CALL UTIL.SP_ETL_CHECK_CONSTRAINTS(:DB_NAME , :APPLICATION , :WORKFLOW_NAME , :OBJECT_NAME , :V_BATCH_ID );


UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''COMPLETE'', ERROR_MSG = null, BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
;
UPDATE  UTIL.ETL_BATCH_OBJECT_INCR_VALU SET INCR_COLUMN_VALUE = :V_BATCH_ID, LST_MOD_DT = CURRENT_TIMESTAMP() 
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID''
;

EXCEPTION

WHEN OTHER THEN

UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''ERROR'', ERROR_MSG = :SQLERRM,  BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
;

INSERT INTO  UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ERROR_MSG, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''ERROR'', :V_STEP_NAME, :V_STEP_SEQ, :SQLERRM, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() )
;



RAISE;

END;

';