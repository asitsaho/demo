USE SCHEMA BDR_DM;
CREATE OR REPLACE FUNCTION FN_QUERY_DELINQUENTS("P_DELINQUENT_DATE" TIMESTAMP_NTZ(9), "P_DATE_CLAUSE" VARCHAR(16777216))
RETURNS NUMBER(38,2)
LANGUAGE SQL
AS '

				SELECT /*+ PARALLEL(8) */  SUM(due) as report_this 
					FROM (
						SELECT SUM(ar.DUE_AMT ) AS due, SUM(ar.owed_AMT) AS owed,  
						SUM(ar.PD_AMT) AS paid  FROM BDR_MSOA.WRK_RIA_ACCTRECEIVABLENEW ar 
						WHERE (CASE WHEN p_date_clause = ''='' THEN ar.DUE_DT = to_date( TO_CHAR(p_delinquent_date,''mm/dd/yyyy''),''mm/dd/yyyy'') 
								   WHEN p_date_clause = ''<='' THEN ar.DUE_DT <= to_date( TO_CHAR(p_delinquent_date,''mm/dd/yyyy''),''mm/dd/yyyy'') END)
						AND ar.owed_amt <> 0)
             --      AND    ar.RECEIVABLE_TYPE = ''Medical''
             --      GROUP BY ar.indV_id, ar.DUE_DT 
             --      HAVING SUM(ar.PD_AMT ) < SUM(ar.DUE_AMT) and  SUM(ar.Due_AMT)>0);

    --pkg_letter.print_string(v_sql);

';