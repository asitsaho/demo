USE SCHEMA BDR_DM; CREATE OR REPLACE PROCEDURE "SP_RIA_PREMIUM_INTERMEDIATE3_IXL_WRK_DATA_CHANG_TRANS_D"("DB_NAME" VARCHAR(16777216), "APPLICATION" VARCHAR(16777216), "WORKFLOW_NAME" VARCHAR(16777216), "OBJECT_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS '

-- Original workflow: wkf_RIA_Premium_Intermediate_IXL_TargetLoad3_D
-- Original mapping: m_RIA_Premium_Intermediate3_IXL_WrkDataChangeTransactions_D
-- Original folder: Premium
-- Original filename: wkf_RIA_Premium_Intermediate_IXL_TargetLoad3_D.XML

DECLARE


V_ROWS_INSERTED  INTEGER;
V_ROWS_UPDATED INTEGER;
V_ROWS_DELETED INTEGER;
V_LAST_QUERY_ID VARCHAR;

V_WH VARCHAR;
V_BATCH_ID INTEGER;


V_BATCH_OBJECT_START_TIME VARCHAR;
V_STEP_START_TIME    VARCHAR;
V_STEP_NAME VARCHAR;
V_STEP_SEQ INTEGER DEFAULT 0;
V_ETL_LST_BTCH_ID INTEGER;

BEGIN

EXECUTE IMMEDIATE ''USE DATABASE ''||:DB_NAME; 

ALTER SESSION SET TIMEZONE = ''America/Chicago'';

V_BATCH_OBJECT_START_TIME := (SELECT CURRENT_TIMESTAMP());



LET res1 RESULTSET := 
(

SELECT 

WH ,
BATCH_ID
  
FROM UTIL.ETL_BATCH_OBJECT_CONTROL
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
FETCH FIRST 1 ROW ONLY

)
;


LET C1 CURSOR FOR res1;
open C1;
FETCH C1 into  V_WH,V_BATCH_ID ;
close C1;


EXECUTE IMMEDIATE ''USE WAREHOUSE ''||:V_WH;

USE SCHEMA BDR_DM;	  

INSERT INTO UTIL.ETL_BATCH_OBJECT_INCR_VALU (APPLICATION, WORKFLOW_NAME, OBJECT_NAME, INCR_COLUMN, INCR_COLUMN_VALUE )
SELECT * FROM (select :APPLICATION AS APPLICATION, :WORKFLOW_NAME AS WORKFLOW_NAME, :OBJECT_NAME AS OBJECT_NAME, ''ETL_LST_BTCH_ID'' AS INCR_COLUMN, -1 AS INCR_COLUMN_VALUE) A
WHERE NOT EXISTS (SELECT 1 FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU B WHERE B.APPLICATION = A.APPLICATION AND B.WORKFLOW_NAME = A.WORKFLOW_NAME AND B.OBJECT_NAME = A.OBJECT_NAME AND B.INCR_COLUMN = A.INCR_COLUMN)
;

V_ETL_LST_BTCH_ID :=(SELECT INCR_COLUMN_VALUE FROM UTIL.ETL_BATCH_OBJECT_INCR_VALU WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID'');

-----------------Step1

V_STEP_NAME    := ''TARGET - TRUNCATE TABLE BDR_DM.WRK_RIA_PREMIUM_DATA_CHANGE_TRANS'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;
 
  EXECUTE IMMEDIATE ''truncate table BDR_DM.WRK_RIA_PREMIUM_DATA_CHANGE_TRANS'';
 
INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );

---------------Step2

V_STEP_NAME    := ''TARGET - INSERT BDR_DM.WRK_RIA_PREMIUM_DATA_CHANGE_TRANS'';
V_STEP_SEQ     :=  V_STEP_SEQ+1;
V_STEP_START_TIME := (SELECT CURRENT_TIMESTAMP());
V_ROWS_INSERTED := null;
V_ROWS_UPDATED := null;
V_ROWS_DELETED := null;


   INSERT 
           INTO BDR_DM.WRK_RIA_PREMIUM_DATA_CHANGE_TRANS
        SELECT 
               Old.HOUSEHOLD_ID
                   AS oldHOUSEHOLD_ID,
               Old.INDIVIDUAL_ID
                   AS oldINDIVIDUAL_ID,
               Old.INS_PLAN_BILLING_BUCKET_ID
                   AS OldInsPlanBillingBucketID,
               Old.INSURED_PLAN_ID
                   AS old_INSURED_PLAN_ID,
               Old.HOUSEHOLD_ADDRESS_ID
                   AS OLD_HouseholdAddressID,
               Old.PREMIUM_DUE_DATE
                   AS OldPremiumDueDate,
               Old.ACTIVITY_DATE
                   AS OldActivityDate,
               Old.PAID_CERT
                   AS OldPaidCert,
               Old.DEL_CERT
                   AS OldDelCert,
               Old.TERM_CERT
                   AS OldTermCert,
               Old.PAID_PREMIUM_AMT
                   AS OldPaidPremiumAmt,
               Old.DELINQUENT_PREMIUM_DUE_AMT
                   AS OldDelinquentPremiumDueAmt,
               Old.PLAN_CD
                   AS OldPlanCD,
               Old.BENEFIT_MOD_CATEGORY_ID
                   AS OldBenefitModCategoryID,
               Old.INSURED_PLAN_EFFECTIVE_DATE
                   AS OldInsuredPlanEffectiveDate,
               Old.INSURED_PLAN_TERMINATION_DATE
                   AS OldInsuredPlanTerminationDate,
               Old.CERT_TERMINATION_DATE
                   AS OldCertTerminationDate,
               Old.STATE_CD
                   AS OldStateCD,
               Old.ZIP_CD
                   AS OldZipCD,
               Old.COUNTRY_CD
                   AS OldCountryCD,
               Old.ISSUE_STATE
                   AS OldIssueState,
               Old.ISSUE_COUNTRY_CD
                   AS OldIssueCountryCD,
               Old.ISSUE_ZIP_CD
                   AS OldIssueZipCD,
               Old.GENDER_CD
                   AS OldGenderCD,
               Old.DATE_OF_BIRTH
                   AS OldDateOfBirth,
               New.HOUSEHOLD_ID
                   AS NewHOUSEHOLD_ID,
               New.INS_PLAN_BILLING_BUCKET_ID
                   AS NewInsPlanBillingBucketID,
               New.ACTIVITY_DATE
                   AS NewActivityDate,
               New.PAID_CERT
                   AS NewPaidCert,
               New.DEL_CERT
                   AS NewDelCert,
               New.TERM_CERT
                   AS NewTermCert,
               New.PAID_PREMIUM_AMT
                   AS NewPaidPremiumAmt,
               New.DELINQUENT_PREMIUM_DUE_AMT
                   AS NewDelinquentPremiumDueAmt,
               New.PLAN_CD
                   AS NewPlanCD,
               New.BENEFIT_MOD_CATEGORY_ID
                   AS NewBenefitModCategoryID,
               New.INSURED_PLAN_EFFECTIVE_DATE
                   AS NewInsuredPlanEffectiveDate,
               New.INSURED_PLAN_TERMINATION_DATE
                   AS NewInsuredPlanTerminationDate,
               New.CERT_TERMINATION_DATE
                   AS NewCertTerminationDate,
               New.STATE_CD
                   AS NewStateCD,
               New.ZIP_CD
                   AS NewZipCD,
               New.COUNTRY_CD
                   AS NewCountryCD,
               New.ISSUE_STATE
                   AS NewIssueState,
               New.ISSUE_COUNTRY_CD
                   AS NewIssueCountryCD,
               New.ISSUE_ZIP_CD
                   AS NewIssueZipCD,
               New.GENDER_CD
                   AS NewGenderCD,
               New.DATE_OF_BIRTH
                   AS NewDateOfBirth,
               CASE
                   WHEN     Old.CERT_TERMINATION_DATE IS NULL
                        AND New.CERT_TERMINATION_DATE IS NOT NULL
                   THEN
                       ''Y''
                   ELSE
                       ''N''
               END
                   AS NewTermFlag,
               Old.CERT_ACQN_CHNL_LEVEL3
                   AS OLD_CERT_ACQN_CHNL_LEVEL3,
               New.CERT_ACQN_CHNL_LEVEL3
                   AS NEW_CERT_ACQN_CHNL_LEVEL3,
               Old.ACCOUNT_NUMBER
                   AS oldaccount_number,
               New.ACCOUNT_NUMBER
                   AS newaccount_number,
               Old.CERT_ACTV_LVL_3_TXT
                   AS old_CERT_ACTV_LVL_3_TXT,
               New.CERT_ACTV_LVL_3_TXT
                   AS new_CERT_ACTV_LVL_3_TXT,
               OLD.TERMINATION_REASON_NAME
                   AS OLD_TERMINATION_REASON_NAME,
               NEW.TERMINATION_REASON_NAME
                   AS NEW_TERMINATION_REASON_NAME,
               OLD.CONSERVATION_REASON_NAME
                   AS OLD_CONSERVATION_REASON_NAME,
               NEW.CONSERVATION_REASON_NAME
                   AS NEW_CONSERVATION_REASON_NAME,
               OLD.PLAN_GROUP
                   AS OLD_PLAN_GROUP,
               NEW.PLAN_GROUP
                   AS NEW_PLAN_GROUP,
               OLD.PRODUCT_GROUP
                   AS OLD_PRODUCT_GROUP,
               NEW.PRODUCT_GROUP
                   AS NEW_PRODUCT_GROUP,
               OLD.UNDWR_TAG_KEY
                   AS OLD_UNDWR_TAG_KEY,
               New.UNDWR_TAG_KEY
                   AS New_UNDWR_TAG_KEY,
               New.HOUSEHOLD_ADDRESS_ID
                   AS New_HOUSEHOLD_ADDRESS_ID,
               Old.PRDCT_EFF_DT
                   AS Old_PRDCT_EFF_DT,
               New.PRDCT_EFF_DT
                   AS New_PRDCT_EFF_DT,
               Old.PRDCT_ACQN_CHNL_LEVEL3
                   AS Old_PRDCT_ACQN_CHNL_LEVEL3,
               New.PRDCT_ACQN_CHNL_LEVEL3
                   AS New_PRDCT_ACQN_CHNL_LEVEL3,
               Old.LEGAL_ENTITY_NAME
                   AS Old_LEGAL_ENTITY_NAME,
               New.LEGAL_ENTITY_NAME
                   AS New_LEGAL_ENTITY_NAME,
               Old.MBR_PD_PREM_AMT
                   AS Old_MBR_PD_PREM_AMT,
               New.MBR_PD_PREM_AMT
                   AS New_MBR_PD_PREM_AMT,
               Old.MBR_DELQ_PREM_AMT
                   AS Old_MBR_DELQ_PREM_AMT,
               New.MBR_DELQ_PREM_AMT
                   AS New_MBR_DELQ_PREM_AMT,
               Old.ER_PD_PREM_AMT
                   AS Old_ER_PD_PREM_AMT,
               New.ER_PD_PREM_AMT
                   AS New_ER_PD_PREM_AMT,
               Old.ER_DELQ_PREM_AMT
                   AS Old_ER_DELQ_PREM_AMT,
               New.ER_DELQ_PREM_AMT
                   AS New_ER_DELQ_PREM_AMT,
               Old.CURRENT_SIGNATURE_DATE
                   AS Old_CURRENT_SIGNATURE_DATE,
               New.CURRENT_SIGNATURE_DATE
                   AS New_CURRENT_SIGNATURE_DATE,
               Old.ORIGINAL_SIGNATURE_DATE
                   AS Old_ORIGINAL_SIGNATURE_DATE,
               New.ORIGINAL_SIGNATURE_DATE
                   AS New_ORIGINAL_SIGNATURE_DATE,
               Old.ORIGINAL_INSURED_PLAN_ID
                   AS Old_ORIGINAL_INSURED_PLAN_ID,
               New.ORIGINAL_INSUREDPLAN_ID
                   AS New_ORIGINAL_INSUREDPLAN_ID,
               Old.WRITING_AGENT
                   AS Old_WRITING_AGENT,
               New.WRITING_AGENT
                   AS New_WRITING_AGENT,
               Old.SELLING_AGENT
                   AS Old_SELLING_AGENT,
               New.SELLING_AGENT
                   AS New_SELLING_AGENT,
               Old.ORIGINAL_SELLING_AGENT
                   AS Old_ORIGINAL_SELLING_AGENT,
               New.ORIGINAL_SELLING_AGENT
                   AS New_ORIGINAL_SELLING_AGENT,
               Old.DCM_INSURED_PLAN_ID
                   AS Old_DCM_INSURED_PLAN_ID,
               New.DCM_INSURED_PLAN_ID
                   AS New_DCM_INSURED_PLAN_ID,
               Old.DCM_INSURED_PLAN_EFF_DATE
                   AS Old_DCM_INSURED_PLAN_EFF_DATE,
               New.DCM_INSURED_PLAN_EFF_DATE
                   AS New_DCM_INSURED_PLAN_EFF_DATE,
               Old.DCM_PLAN_CD
                   AS Old_DCM_PLAN_CD,
               New.DCM_PLAN_CD
                   AS New_DCM_PLAN_CD,
               Old.DCM_SIGNATURE_DATE
                   AS Old_DCM_SIGNATURE_DATE,
               New.DCM_SIGNATURE_DATE
                   AS New_DCM_SIGNATURE_DATE,
               Old.DCM_WRITING_AGENT
                   AS Old_DCM_WRITING_AGENT,
               New.DCM_WRITING_AGENT
                   AS New_DCM_WRITING_AGENT,
               Old.DCM_DERIVED_COMPAS_AGENT
                   AS Old_DCM_DERIVED_COMPAS_AGENT,
               New.DCM_DERIVED_COMPAS_AGENT
                   AS New_DCM_DERIVED_COMPAS_AGENT,
               Old.RET_TYP_ID
                   AS Old_RET_TYP_ID,
               New.RET_TYP_ID
                   AS New_RET_TYP_ID,
               Old.ER_SKEY
                   AS Old_ER_SKEY,
               New.ER_SKEY
                   AS New_ER_SKEY,
               Old.AGT_WRT_SKEY
                   AS Old_AGT_WRT_SKEY,
               New.AGT_WRT_SKEY
                   AS New_AGT_WRT_SKEY,
               Old.AGT_SEL_ORIG_SKEY
                   AS Old_AGT_SEL_ORIG_SKEY,
               New.AGT_SEL_ORIG_SKEY
                   AS New_AGT_SEL_ORIG_SKEY,
               Old.AGT_SEL_SKEY
                   AS Old_AGT_SEL_SKEY,
               New.AGT_SEL_SKEY
                   AS New_AGT_SEL_SKEY,
               Old.AGT_DCM_WRT_SKEY
                   AS Old_AGT_DCM_WRT_SKEY,
               New.AGT_DCM_WRT_SKEY
                   AS New_AGT_DCM_WRT_SKEY,
               Old.D_DSCNT_ANNL_PAYR_SK,
               Old.D_DSCNT_EFT_SK,
               Old.D_DSCNT_ERLY_ENRL_SK,
               Old.D_DSCNT_LNGVTY_SK,
               Old.D_DSCNT_MULTI_INSD_SK,
               Old.D_SURCHRG_TBCC_USER_SK,
               Old.D_SURCHRG_TIER_SK,
               Old.D_INSD_PLN_PRFL_SK,
               Old.D_CALC_RT_SK,
               Old.MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
               Old.DSCNT_PD_ANNL_PAYR_AMT,
               Old.DSCNT_PD_EFT_AMT,
               Old.DSCNT_PD_ERLY_ENRL_AMT,
               Old.DSCNT_PD_LNGVTY_AMT,
               Old.DSCNT_PD_MULTI_INSD_AMT,
               Old.SURCHRG_PD_TBCC_USER_AMT,
               Old.SURCHRG_PD_TIER_AMT,
               Old.DSCNT_DELQ_ANNL_PAYR_AMT,
               Old.DSCNT_DELQ_EFT_AMT,
               Old.DSCNT_DELQ_ERLY_ENRL_AMT,
               Old.DSCNT_DELQ_LNGVTY_AMT,
               Old.DSCNT_DELQ_MULTI_INSD_AMT,
               Old.SURCHRG_DELQ_TBCC_USER_AMT,
               Old.SURCHRG_DELQ_TIER_AMT,
               New.D_DSCNT_ANNL_PAYR_SK,
               New.D_DSCNT_EFT_SK,
               New.D_DSCNT_ERLY_ENRL_SK,
               New.D_DSCNT_LNGVTY_SK,
               New.D_DSCNT_MULTI_INSD_SK,
               New.D_SURCHRG_TBCC_USER_SK,
               New.D_SURCHRG_TIER_SK,
               New.D_INSD_PLN_PRFL_SK,
               New.D_CALC_RT_SK,
               New.MEDSUP_PLN_ENT_AGE_LOOK_FRAC,
               New.DSCNT_PD_ANNL_PAYR_AMT,
               New.DSCNT_PD_EFT_AMT,
               New.DSCNT_PD_ERLY_ENRL_AMT,
               New.DSCNT_PD_LNGVTY_AMT,
               New.DSCNT_PD_MULTI_INSD_AMT,
               New.SURCHRG_PD_TBCC_USER_AMT,
               New.SURCHRG_PD_TIER_AMT,
               New.DSCNT_DELQ_ANNL_PAYR_AMT,
               New.DSCNT_DELQ_EFT_AMT,
               New.DSCNT_DELQ_ERLY_ENRL_AMT,
               New.DSCNT_DELQ_LNGVTY_AMT,
               New.DSCNT_DELQ_MULTI_INSD_AMT,
               New.SURCHRG_DELQ_TBCC_USER_AMT,
               New.SURCHRG_DELQ_TIER_AMT,
               Old.ORIGINAL_REFERRAL_AGENT
                   AS O_ORIGINAL_REFERRAL_AGENT,
               New.ORIGINAL_REFERRAL_AGENT
                   AS N_ORIGINAL_REFERRAL_AGENT,
               Old.REFERRAL_AGENT
                   AS O_REFERRAL_AGENT,
               New.REFERRAL_AGENT
                   AS N_REFERRAL_AGENT,
               Old.AGT_REF_ORIG_D_AGT_SK
                   AS O_AGT_REF_ORIG_D_AGT_SK,
               New.AGT_REF_ORIG_D_AGT_SK
                   AS N_AGT_REF_ORIG_D_AGT_SK,
               Old.AGT_REF_D_AGT_SK
                   AS O_AGT_REF_D_AGT_SK,
               New.AGT_REF_D_AGT_SK
                   AS N_AGT_REF_D_AGT_SK,
               Old.D_MBR_INFO_SK
                   AS O_D_MBR_INFO_SK,
               New.D_MBR_INFO_SK
                   AS N_D_MBR_INFO_SK,
               Old.D_PLN_BEN_MOD_SK
                   AS O_D_PLN_BEN_MOD_SK,
               New.D_PLN_BEN_MOD_SK
                   AS N_D_PLN_BEN_MOD_SK,
               Old.RES_D_GEO_XREF_SK
                   AS O_RES_D_GEO_XREF_SK,
               New.RES_D_GEO_XREF_SK
                   AS N_RES_D_GEO_XREF_SK,
               Old.PLN_ISS_D_GEO_XREF_SK
                   AS O_PLN_ISS_D_GEO_XREF_SK,
               New.PLN_ISS_D_GEO_XREF_SK
                   AS N_PLN_ISS_D_GEO_XREF_SK,
               Old.D_RTNG_AREA_SK
                   AS O_D_RTNG_AREA_SK,
               New.D_RTNG_AREA_SK
                   AS N_D_RTNG_AREA_SK,
               Old.F_APPL_TRANS_DAY_SK
                   AS O_F_APPL_TRANS_DAY_SK,
               New.F_APPL_TRANS_DAY_SK
                   AS N_F_APPL_TRANS_DAY_SK,
               New.CERT_SALE_CHNL_LVL_1
                   N_CERT_SALE_CHNL_LVL_1,
               Old.CERT_SALE_CHNL_LVL_1
                   O_CERT_SALE_CHNL_LVL_1,
               New.CERT_SALE_CHNL_LVL_2
                   N_CERT_SALE_CHNL_LVL_2,
               Old.CERT_SALE_CHNL_LVL_2
                   O_CERT_SALE_CHNL_LVL_2,
               New.CERT_SALE_CHNL_LVL_3
                   N_CERT_SALE_CHNL_LVL_3,
               Old.CERT_SALE_CHNL_LVL_3
                   O_CERT_SALE_CHNL_LVL_3,
               New.PRDCT_SALE_CHNL_LVL_1
                   N_PRDCT_SALE_CHNL_LVL_1,
               Old.PRDCT_SALE_CHNL_LVL_1
                   O_PRDCT_SALE_CHNL_LVL_1,
               New.PRDCT_SALE_CHNL_LVL_2
                   N_PRDCT_SALE_CHNL_LVL_2,
               Old.PRDCT_SALE_CHNL_LVL_2
                   O_PRDCT_SALE_CHNL_LVL_2,
               New.PRDCT_SALE_CHNL_LVL_3
                   N_PRDCT_SALE_CHNL_LVL_3,
               Old.PRDCT_SALE_CHNL_LVL_3
                   O_PRDCT_SALE_CHNL_LVL_3,
               Old.D_NEW_TO_MEDCR_SK
                   AS O_D_NEW_TO_MEDCR_SK,
               Old.DSCNT_PD_NEW_TO_MEDCR_AMT
                   AS O_DSCNT_PD_NEW_TO_MEDCR_AMT,
               Old.DSCNT_DLQNT_NEW_TO_MEDCR_AMT
                   AS O_DSCNT_DLQNT_NEW_TO_MEDCR_AMT,
               New.D_NEW_TO_MEDCR_SK
                   AS N_D_NEW_TO_MEDCR_SK,
               New.DSCNT_PD_NEW_TO_MEDCR_AMT
                   AS N_DSCNT_PD_NEW_TO_MEDCR_AMT,
               New.DSCNT_DLQNT_NEW_TO_MEDCR_AMT
                   AS N_DSCNT_DLQNT_NEW_TO_MEDCR_AMT,
               Old.D_UNDWR_GUID_SK
                   AS O_D_UNDWR_GUID_SK,
               New.D_UNDWR_GUID_SK
                   AS N_D_UNDWR_GUID_SK,
               Old.D_AGT_POL_SK
                   AS O_D_AGT_POL_SK,
               New.D_AGT_POL_SK
                   AS N_D_AGT_POL_SK,
               New.PRO_RATED_CREDIT
                   AS N_PRO_RATED_CREDIT,
               Old.PRO_RATED_CREDIT
                   AS O_PRO_RATED_CREDIT,
               New.ENT_AGE_EFFDT
                   AS N_ENT_AGE_EFFDT,
               Old.ENT_AGE_EFFDT
                   AS O_ENT_AGE_EFFDT
          FROM BDR_DM.WRK_RIA_PREMIUM_DATA_BL_REBUILD  New
               INNER JOIN BDR_DM.WRK_PREMIUM_DATA_BASELINE Old
                      ON  New.INSURED_PLAN_ID = Old.INSURED_PLAN_ID
                      AND New.PREMIUM_DUE_DATE = Old.PREMIUM_DUE_DATE
                      AND New.INDIVIDUAL_ID = Old.INDIVIDUAL_ID
         WHERE    Old.HOUSEHOLD_ID
               || Old.PAID_CERT
               || Old.DEL_CERT
               || Old.TERM_CERT
               || Old.PAID_PREMIUM_AMT
               || Old.DELINQUENT_PREMIUM_DUE_AMT
               || Old.PLAN_CD
               || Old.BENEFIT_MOD_CATEGORY_ID
               || Old.INSURED_PLAN_EFFECTIVE_DATE
               || NVL (Old.INSURED_PLAN_TERMINATION_DATE,
                       New.INSURED_PLAN_TERMINATION_DATE)
               || Old.ZIP_CD
               || Old.STATE_CD
               || Old.COUNTRY_CD
               || Old.ISSUE_STATE
               || Old.ISSUE_COUNTRY_CD
               || Old.ISSUE_ZIP_CD
               || Old.GENDER_CD
               || Old.DATE_OF_BIRTH
               || Old.CERT_ACQN_CHNL_LEVEL3
               || Old.ACCOUNT_NUMBER
               || Old.CERT_ACTV_LVL_3_TXT
               || Old.UNDWR_TAG_KEY
               || old.HOUSEHOLD_ADDRESS_ID
               || Old.PRDCT_EFF_DT
               || Old.PRDCT_ACQN_CHNL_LEVEL3
               || NVL (Old.LEGAL_ENTITY_NAME, ''UNKNOWN'')
               || Old.MBR_PD_PREM_AMT
               || Old.MBR_DELQ_PREM_AMT
               || Old.ER_PD_PREM_AMT
               || Old.ER_DELQ_PREM_AMT
               || Old.RET_TYP_ID
               || Old.ER_SKEY
               || NVL (Old.AGT_WRT_SKEY, -1)
               || NVL (Old.AGT_SEL_ORIG_SKEY, -1)
               || NVL (Old.AGT_SEL_SKEY, -1)
               || NVL (Old.AGT_DCM_WRT_SKEY, -1)
               || Old.D_DSCNT_ANNL_PAYR_SK
               || Old.D_DSCNT_EFT_SK
               || Old.D_DSCNT_ERLY_ENRL_SK
               || Old.D_DSCNT_LNGVTY_SK
               || Old.D_DSCNT_MULTI_INSD_SK
               || Old.D_SURCHRG_TBCC_USER_SK
               || Old.D_SURCHRG_TIER_SK
               || Old.D_INSD_PLN_PRFL_SK
               || Old.D_CALC_RT_SK
               || Old.MEDSUP_PLN_ENT_AGE_LOOK_FRAC
               || Old.DSCNT_PD_ANNL_PAYR_AMT
               || Old.DSCNT_PD_EFT_AMT
               || Old.DSCNT_PD_ERLY_ENRL_AMT
               || Old.DSCNT_PD_LNGVTY_AMT
               || Old.DSCNT_PD_MULTI_INSD_AMT
               || Old.SURCHRG_PD_TBCC_USER_AMT
               || Old.SURCHRG_PD_TIER_AMT
               || Old.DSCNT_DELQ_ANNL_PAYR_AMT
               || Old.DSCNT_DELQ_EFT_AMT
               || Old.DSCNT_DELQ_ERLY_ENRL_AMT
               || Old.DSCNT_DELQ_LNGVTY_AMT
               || Old.DSCNT_DELQ_MULTI_INSD_AMT
               || Old.SURCHRG_DELQ_TBCC_USER_AMT
               || Old.SURCHRG_DELQ_TIER_AMT
               || NVL (Old.AGT_REF_ORIG_D_AGT_SK, -2)
               || NVL (Old.AGT_REF_D_AGT_SK, -2)
               || Old.D_MBR_INFO_SK
               || Old.D_PLN_BEN_MOD_SK
               || Old.RES_D_GEO_XREF_SK
               || Old.PLN_ISS_D_GEO_XREF_SK
               || Old.D_RTNG_AREA_SK
               || Old.F_APPL_TRANS_DAY_SK
               || Old.D_NEW_TO_MEDCR_SK
               || Old.DSCNT_PD_NEW_TO_MEDCR_AMT
               || Old.DSCNT_DLQNT_NEW_TO_MEDCR_AMT
               || Old.D_UNDWR_GUID_SK
               || Old.D_AGT_POL_SK
               || NVL (Old.PRO_RATED_CREDIT, 0)
               || Old.ENT_AGE_EFFDT <>
                  New.HOUSEHOLD_ID
               || New.PAID_CERT
               || New.DEL_CERT
               || New.TERM_CERT
               || New.PAID_PREMIUM_AMT
               || New.DELINQUENT_PREMIUM_DUE_AMT
               || New.PLAN_CD
               || New.BENEFIT_MOD_CATEGORY_ID
               || New.INSURED_PLAN_EFFECTIVE_DATE
               || NVL (New.INSURED_PLAN_TERMINATION_DATE,
                       Old.INSURED_PLAN_TERMINATION_DATE)
               || New.ZIP_CD
               || New.STATE_CD
               || New.COUNTRY_CD
               || New.ISSUE_STATE
               || New.ISSUE_COUNTRY_CD
               || New.ISSUE_ZIP_CD
               || New.GENDER_CD
               || New.DATE_OF_BIRTH
               || New.CERT_ACQN_CHNL_LEVEL3
               || New.ACCOUNT_NUMBER
               || New.CERT_ACTV_LVL_3_TXT
               || New.UNDWR_TAG_KEY
               || NEW.HOUSEHOLD_ADDRESS_ID
               || New.PRDCT_EFF_DT
               || New.PRDCT_ACQN_CHNL_LEVEL3
               || NVL (New.LEGAL_ENTITY_NAME, ''UNKNOWN'')
               || New.MBR_PD_PREM_AMT
               || New.MBR_DELQ_PREM_AMT
               || New.ER_PD_PREM_AMT
               || New.ER_DELQ_PREM_AMT
               || New.RET_TYP_ID
               || New.ER_SKEY
               || NVL (New.AGT_WRT_SKEY, -1)
               || NVL (New.AGT_SEL_ORIG_SKEY, -1)
               || NVL (New.AGT_SEL_SKEY, -1)
               || NVL (New.AGT_DCM_WRT_SKEY, -1)
               || New.D_DSCNT_ANNL_PAYR_SK
               || New.D_DSCNT_EFT_SK
               || New.D_DSCNT_ERLY_ENRL_SK
               || New.D_DSCNT_LNGVTY_SK
               || New.D_DSCNT_MULTI_INSD_SK
               || New.D_SURCHRG_TBCC_USER_SK
               || New.D_SURCHRG_TIER_SK
               || New.D_INSD_PLN_PRFL_SK
               || New.D_CALC_RT_SK
               || New.MEDSUP_PLN_ENT_AGE_LOOK_FRAC
               || New.DSCNT_PD_ANNL_PAYR_AMT
               || New.DSCNT_PD_EFT_AMT
               || New.DSCNT_PD_ERLY_ENRL_AMT
               || New.DSCNT_PD_LNGVTY_AMT
               || New.DSCNT_PD_MULTI_INSD_AMT
               || New.SURCHRG_PD_TBCC_USER_AMT
               || New.SURCHRG_PD_TIER_AMT
               || New.DSCNT_DELQ_ANNL_PAYR_AMT
               || New.DSCNT_DELQ_EFT_AMT
               || New.DSCNT_DELQ_ERLY_ENRL_AMT
               || New.DSCNT_DELQ_LNGVTY_AMT
               || New.DSCNT_DELQ_MULTI_INSD_AMT
               || New.SURCHRG_DELQ_TBCC_USER_AMT
               || New.SURCHRG_DELQ_TIER_AMT
               || NVL (New.AGT_REF_ORIG_D_AGT_SK, -2)
               || NVL (New.AGT_REF_D_AGT_SK, -2)
               || New.D_MBR_INFO_SK
               || New.D_PLN_BEN_MOD_SK
               || New.RES_D_GEO_XREF_SK
               || New.PLN_ISS_D_GEO_XREF_SK
               || New.D_RTNG_AREA_SK
               || New.F_APPL_TRANS_DAY_SK
               || New.D_NEW_TO_MEDCR_SK
               || New.DSCNT_PD_NEW_TO_MEDCR_AMT
               || New.DSCNT_DLQNT_NEW_TO_MEDCR_AMT
               || New.D_UNDWR_GUID_SK
               || New.D_AGT_POL_SK
               || NVL (New.PRO_RATED_CREDIT, 0)
               || New.ENT_AGE_EFFDT;

V_LAST_QUERY_ID := (SELECT LAST_QUERY_ID()) ;

V_ROWS_INSERTED := (SELECT * FROM TABLE ( RESULT_SCAN (:V_LAST_QUERY_ID)) );


INSERT INTO UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ROWS_INSERTED, ROWS_UPDATED, ROWS_DELETED, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''COMPLETE'', :V_STEP_NAME, :V_STEP_SEQ, :V_ROWS_INSERTED, :V_ROWS_UPDATED, :V_ROWS_DELETED, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() );


UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''COMPLETE'', ERROR_MSG = null, BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME
;
UPDATE  UTIL.ETL_BATCH_OBJECT_INCR_VALU SET INCR_COLUMN_VALUE = :V_BATCH_ID, LST_MOD_DT = CURRENT_TIMESTAMP() 
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME AND INCR_COLUMN = ''ETL_LST_BTCH_ID''
;

EXCEPTION

WHEN OTHER THEN

UPDATE  UTIL.ETL_BATCH_OBJECT_CONTROL SET STATUS = ''ERROR'', ERROR_MSG = :SQLERRM,  BATCH_OBJECT_START_DATETIME = :V_BATCH_OBJECT_START_TIME, BATCH_OBJECT_END_DATETIME = CURRENT_TIMESTAMP()
WHERE APPLICATION = :APPLICATION AND WORKFLOW_NAME = :WORKFLOW_NAME AND OBJECT_NAME = :OBJECT_NAME 
;

INSERT INTO  UTIL.ETL_BATCH_OBJECT_CONTROL_LOG (APPLICATION, WORKFLOW_NAME, TABLE_NAME, BATCH_ID, STATUS, STEP, SEQ, ERROR_MSG, STEP_START_DATETIME, STEP_END_DATETIME)
VALUES (:APPLICATION, :WORKFLOW_NAME, :OBJECT_NAME, :V_BATCH_ID, ''ERROR'', :V_STEP_NAME, :V_STEP_SEQ, :SQLERRM, :V_STEP_START_TIME,  CURRENT_TIMESTAMP() )
;



RAISE;

END;

';