USE SCHEMA BDR_DM;
create or replace view VC_APPL_RSN_CURR COPY GRANTS AS 

SELECT
     A.F_APPL_TRANS_DAY_SK
    ,A.APPL_ID
    ,A.ACTV_DT_ID
    ,A.APPL_RECPT_DT_ID
    ,A.APPL_ADJD_DT_ID
    ,A.REQ_EFF_DT_ID
    ,A.INSD_PLN_EFF_DT_ID
    ,A.D_ADJD_CD_SK
    ,A.D_GEO_XREF_SK
    ,A.D_APPL_MECH_SK
    ,A.D_APPL_CNTC_TYP_SK
    ,A.D_APPL_PROC_SK
    ,A.D_APPL_ACTOR_SK
    ,A.D_ACQN_CHNL_SK
    ,A.PLN_REQ_1
    ,A.PLN_REQ_BEN_MOD_SK_1
    ,A.PLN_REQ_2
    ,A.PLN_REQ_BEN_MOD_SK_2
    ,A.RIDE_REQ_1
    ,A.RIDE_REQ_BEN_MOD_SK_1
    ,A.RIDE_REQ_2
    ,A.RIDE_REQ_BEN_MOD_SK_2
    ,A.RIDE_REQ_3
    ,A.RIDE_REQ_BEN_MOD_SK_3
    ,A.RIDE_REQ_4
    ,A.RIDE_REQ_BEN_MOD_SK_4
    ,A.RECV_QTY
    ,A.PND_QTY
    ,A.ACPT_QTY
    ,A.DENY_QTY
    ,A.WTHDR_QTY
    ,A.APPL_IMAG_NBR_ORIG
    ,A.APPL_DATA_SRC
    ,A.NEG_ROW_FLG
    ,A.CURR_ROW_FLG
    ,AR.F_APPL_RSN_TRANS_DAY_SK as AR_F_APPL_RSN_TRANS_DAY_SK
    ,AR.APPL_ID as AR_APPL_ID
    ,AR.ACTV_DT_ID as AR_ACTV_DT_ID
    ,AR.D_ADJD_CD_SK as AR_D_ADJD_CD_SK
    ,AR.D_APPL_RSN_SK as AR_D_APPL_RSN_SK
    ,AR.RECV_QTY as AR_RECV_QTY
    ,AR.PND_QTY as AR_PND_QTY
    ,AR.ACPT_QTY as AR_ACPT_QTY
    ,AR.DENY_QTY as AR_DENY_QTY
    ,AR.WTHDR_QTY as AR_WTHDR_QTY
    ,A.D_MBR_INFO_SK
 FROM
    BDR_DM.F_APPL_RSN_TRANS_DAY AR,
    BDR_DM.F_APPL_TRANS_DAY A
 WHERE
    A.APPL_ID = AR.APPL_ID
 AND A.CURR_ROW_FLG = 'Y'
;
create or replace view VC_PREM_MO_EMP_MBR COPY GRANTS AS 

SELECT
         PREM_DUE_MO_ID
        ,EMP_ID
        ,EMP_NM
        ,EMP_EFF_DT_ID
        ,EMP_CLOS_DT_ID
        ,CNNCTR_MDL_ELIG_FLG
        ,EMP_SBSD_TYP
        ,BR_ID
        ,BR_NM
        ,BR_NBR
        ,BIL_GRP_ID
        ,BIL_GRP_NBR
        ,BIL_GRP_NM
        ,MBR_PD_PREM_AMT
        ,MBR_DELQ_PREM_AMT
        ,EMP_PD_PREM_AMT
        ,EMP_DELQ_PREM_AMT
        ,COMPAS_PLN_DSPL_CD
        ,COMPAS_PLN_CD
        ,PRDCT
        ,PRDCT_GRP
        ,PRDCT_TYP
        ,COMPAS_PLN_DESC
        ,COMPAS_PLN_TYP_DESC
        ,INSD_PLN_EFF_DT
        ,INSD_PLN_TRM_DT
        ,TRM_RSN_NM
        ,RET_TYP
        ,MBRSHP_NBR
        ,FST_NM
        ,LST_NM
        ,GDR_CD
        ,DOB
        ,DOD
        ,PREM_DUE_AGE_ID
        ,MEDCR_CLM_NBR
        ,EA_ID
        ,ADDR_LN_1
        ,CTY
        ,ST_CD
        ,ZIP_CD
        ,ETL_LST_BTCH_ID
        ,ACTV_MO_ID
 FROM BDR_DM.PREM_MO_EMP_MBR
 WHERE RET_TYP = 'RETIREE' OR RET_TYP = 'NON-RETIREE'
;
create or replace view V_DELINQUENT_PREM_MO COPY GRANTS COPY GRANTS (
	MONTH,
	ST_CD,
	LGL_ENTY_NM,
	PROD_GRP,
	PROD_INFO,
	SUM_OF_DELQ_PREM_AMT
) as
SELECT
prem.PREM_DUE_MO_ID as MONTH,
geo.D_ST_CD as ST_CD,
case when lgl.LGL_ENTY_NM='UHC NY' then 'NY'
when lgl.LGL_ENTY_NM='UHCA' then 'NLE'
else 'ALL OTHER' end as LGL_ENTY_NM,
lkp.PRDCT_GRP as PROD_GRP,
lkp.PRDCT_INFO as PROD_INFO,
sum(DELQ_PREM_AMT) as SUM_OF_DELQ_PREM_AMT
FROM BDR_DM.F_PREM_TRANS_MO prem
INNER JOIN BDR_CONF.D_GEO_XREF geo
ON prem.RES_D_GEO_XREF_SK = geo.D_GEO_XREF_SK
INNER JOIN BDR_CONF.D_LGL_ENTY lgl
ON prem.D_LGL_ENTY_SK = lgl.D_LGL_ENTY_SK
INNER JOIN BDR_CONF.D_PLN_BEN_MOD ben
ON prem.D_PLN_BEN_MOD_SK = ben.D_PLN_BEN_MOD_SK
INNER JOIN BDR_CONF.PRDCT_GRP_INFO lkp
ON ben.PLN_TYP = lkp.PLN_TYP
AND ben.PLN_GRP = lkp.PLN_GRP
WHERE prem.ACTV_MO_ID <= TO_NUMBER(TO_CHAR(add_months(TRUNC(CURRENT_TIMESTAMP,'MM'), -1),'YYYYMM'))
and (prem.PREM_DUE_MO_ID >= TO_NUMBER(TO_CHAR(add_months(TRUNC(CURRENT_TIMESTAMP,'MM'), -6),'YYYYMM'))
AND prem.PREM_DUE_MO_ID < TO_NUMBER(TO_CHAR(TRUNC(CURRENT_TIMESTAMP, 'DD'),'YYYYMM')))
GROUP BY
prem.PREM_DUE_MO_ID,
geo.D_ST_CD,
case when lgl.LGL_ENTY_NM='UHC NY' then 'NY'
when lgl.LGL_ENTY_NM='UHCA' then 'NLE'
else 'ALL OTHER' end,
lkp.PRDCT_GRP,
lkp.PRDCT_INFO;
create or replace view V_DELQ_CERT_QTY_AND_DELQ_PREM_AMT COPY GRANTS (
	PRDCT_COMBO_CD,
	PLN_CMPST_CD,
	PREM_DUE_MO_ID,
	DELQ_CERT_QTY,
	DELQ_PREM_AMT
) as
WITH
        base
        AS
            (  SELECT DISTINCT a14.PLN_TYP,
                               a14.PLN_GRP,
                               a14.pln_lvl,
                               a14.PLN_LVL_DESC,
                               a11.prem_due_mo_id,
                               SUM (a11.DELQ_CERT_QTY)     AS DELQ_CERT_QTY,
                               SUM (a11.DELQ_PREM_AMT)     AS DELQ_PREM_AMT
                 FROM bdr_dm.F_PREM_trans_mo a11
                      LEFT JOIN bdr_conf.D_PLN_BEN_MOD a14
                          ON a11.D_PLN_BEN_MOD_SK = a14.D_PLN_BEN_MOD_SK
                WHERE     a11.PREM_DUE_MO_ID BETWEEN TO_NUMBER (
                                                         TO_CHAR (
                                                             TRUNC (
                                                                 ADD_MONTHS (
                                                                     CURRENT_DATE,
                                                                     -12),
                                                                 'YEAR'),
                                                             'yyyymm'))
                                                 AND TO_NUMBER (
                                                         TO_CHAR (
                                                             ADD_MONTHS (
                                                                 CURRENT_DATE,
                                                                 -1),
                                                             'yyyymm'))
                      AND a11.actv_mo_id <=
                          TO_NUMBER (
                              TO_CHAR (ADD_MONTHS (CURRENT_DATE, -1), 'yyyymm'))
             GROUP BY a14.PLN_TYP,
                      a14.PLN_GRP,
                      a14.pln_lvl,
                      a14.PLN_LVL_DESC,
                      a11.prem_due_mo_id
               HAVING     SUM (a11.DELQ_CERT_QTY) <> 0
                      AND SUM (a11.DELQ_PREM_AMT) <> 0)
      SELECT CASE WHEN b.PLN_TYP NOT IN ('Default') THEN 'CASE' END
                 AS PRDCT_COMBO_CD,
             CASE WHEN b.pln_lvl NOT IN ('ZZ') THEN 'NOLS + PPPM+ PPPL' END
                 AS PLN_CMPST_CD,
             b.prem_due_mo_id,
             SUM (b.DELQ_CERT_QTY)
                 AS DELQ_CERT_QTY,
             SUM (b.DELQ_PREM_AMT)
                 AS DELQ_PREM_AMT
        FROM base b
       WHERE (b.PLN_TYP NOT IN ('Default') OR b.pln_lvl NOT IN ('ZZ'))
    GROUP BY CASE WHEN b.PLN_TYP NOT IN ('Default') THEN 'CASE' END,
             CASE WHEN b.pln_lvl NOT IN ('ZZ') THEN 'NOLS + PPPM+ PPPL' END,
             b.prem_due_mo_id
    UNION ALL
      SELECT CASE
                 WHEN     (   b.PLN_TYP LIKE '%Modernized%'
                           OR b.PLN_TYP LIKE '%Standardized%'
                           OR b.PLN_TYP LIKE '%Pre-Standardized%')
                      AND b.PLN_TYP NOT LIKE '%Select%'
                 THEN
                     'MEDC'
             END                      AS PRDCT_COMBO_CD,
             CASE
                 WHEN     (   b.PLN_TYP LIKE '%Modernized%'
                           OR b.PLN_TYP LIKE '%Standardized%'
                           OR b.PLN_TYP LIKE '%Pre-Standardized%')
                      AND b.PLN_TYP NOT LIKE '%Select%'
                 THEN
                     'TMED + TTOD + MCPG'
             END                      AS PLN_CMPST_CD,
             b.prem_due_mo_id,
             SUM (b.DELQ_CERT_QTY)    AS DELQ_CERT_QTY,
             SUM (b.DELQ_PREM_AMT)    AS DELQ_PREM_AMT
        FROM base b
       WHERE     (   b.PLN_TYP LIKE '%Modernized%'
                  OR b.PLN_TYP LIKE '%Standardized%'
                  OR b.PLN_TYP LIKE '%Pre-Standardized%')
             AND b.PLN_TYP NOT LIKE '%Select%'
    GROUP BY CASE
                 WHEN     (   b.PLN_TYP LIKE '%Modernized%'
                           OR b.PLN_TYP LIKE '%Standardized%'
                           OR b.PLN_TYP LIKE '%Pre-Standardized%')
                      AND b.PLN_TYP NOT LIKE '%Select%'
                 THEN
                     'MEDC'
             END,
             CASE
                 WHEN     (   b.PLN_TYP LIKE '%Modernized%'
                           OR b.PLN_TYP LIKE '%Standardized%'
                           OR b.PLN_TYP LIKE '%Pre-Standardized%')
                      AND b.PLN_TYP NOT LIKE '%Select%'
                 THEN
                     'TMED + TTOD + MCPG'
             END,
             b.prem_due_mo_id
    UNION ALL
      SELECT CASE WHEN b.PLN_LVL_DESC LIKE '%Select%' THEN 'TSEL' END
                 AS PRDCT_COMBO_CD,
             CASE
                 WHEN b.PLN_LVL_DESC LIKE '%Select%'
                 THEN
                     'Med Select (SELB..SELJ, SW/TW, WO Rider)'
             END
                 AS PLN_CMPST_CD,
             b.prem_due_mo_id,
             SUM (b.DELQ_CERT_QTY)
                 AS DELQ_CERT_QTY,
             SUM (b.DELQ_PREM_AMT)
                 AS DELQ_PREM_AMT
        FROM base b
       WHERE b.PLN_LVL_DESC LIKE '%Select%'
    GROUP BY CASE WHEN b.PLN_LVL_DESC LIKE '%Select%' THEN 'TSEL' END,
             CASE
                 WHEN b.PLN_LVL_DESC LIKE '%Select%'
                 THEN
                     'Med Select (SELB..SELJ, SW/TW, WO Rider)'
             END,
             b.prem_due_mo_id
    UNION ALL
      SELECT CASE
                 WHEN b.PLN_GRP IN ('HIP Base Plans',
                                    'HAP Plans',
                                    'HIP Riders',
                                    'HIP EP Base Plans',
                                    'EHIP Plans',
                                    'MAP/EPHIP Plans')
                 THEN
                     'HIPC'
             END                      AS PRDCT_COMBO_CD,
             CASE
                 WHEN b.PLN_GRP IN ('HIP Base Plans',
                                    'HAP Plans',
                                    'HIP Riders',
                                    'HIP EP Base Plans',
                                    'EHIP Plans',
                                    'MAP/EPHIP Plans')
                 THEN
                     'HIPS + HCPG'
             END                      AS PLN_CMPST_CD,
             b.prem_due_mo_id,
             SUM (b.DELQ_CERT_QTY)    AS DELQ_CERT_QTY,
             SUM (b.DELQ_PREM_AMT)    AS DELQ_PREM_AMT
        FROM base b
       WHERE b.PLN_GRP IN ('HIP Base Plans',
                           'HAP Plans',
                           'HIP Riders',
                           'HIP EP Base Plans',
                           'EHIP Plans',
                           'MAP/EPHIP Plans')
    GROUP BY CASE
                 WHEN b.PLN_GRP IN ('HIP Base Plans',
                                    'HAP Plans',
                                    'HIP Riders',
                                    'HIP EP Base Plans',
                                    'EHIP Plans',
                                    'MAP/EPHIP Plans')
                 THEN
                     'HIPC'
             END,
             CASE
                 WHEN b.PLN_GRP IN ('HIP Base Plans',
                                    'HAP Plans',
                                    'HIP Riders',
                                    'HIP EP Base Plans',
                                    'EHIP Plans',
                                    'MAP/EPHIP Plans')
                 THEN
                     'HIPS + HCPG'
             END,
             b.prem_due_mo_id
    UNION ALL
      SELECT CASE WHEN b.pln_grp = 'PHIP' THEN 'TPPO' END
                 AS PRDCT_COMBO_CD,
             CASE WHEN b.pln_grp = 'PHIP' THEN 'All PPO Plans' END
                 AS PLN_CMPST_CD,
             b.prem_due_mo_id,
             SUM (b.DELQ_CERT_QTY)
                 AS DELQ_CERT_QTY,
             SUM (b.DELQ_PREM_AMT)
                 AS DELQ_PREM_AMT
        FROM base b
       WHERE b.pln_grp = 'PHIP'
    GROUP BY CASE WHEN b.pln_grp = 'PHIP' THEN 'TPPO' END,
             CASE WHEN b.pln_grp = 'PHIP' THEN 'All PPO Plans' END,
             b.prem_due_mo_id;
create or replace view V_D_CHANGERS_BI COPY GRANTS 
	  
	  
	  AS SELECT DISTINCT FPTM1.F_PREM_TRANS_MO_SK,
                     FPTM1.PREM_DUE_MO_ID,
                     FPTM1.D_MBR_INFO_SK,
                     FPTM1.D_PLN_BEN_MOD_SK,
                     FPTM1.CERT_EFF_MO_ID,
                     FPTM1.CERT_TRM_MO_ID,
                     FPTM1.RES_D_GEO_XREF_SK,
                     FPTM1.PLN_ISS_D_GEO_XREF_SK,
                     FPTM1.D_RTNG_AREA_SK,
                     FPTM1.PREM_DUE_AGE_ID,
                     FPTM1.D_GDR_ID_SK,
                     FPTM1.PD_CERT_QTY,
                     FPTM1.DELQ_CERT_QTY,
                     FPTM1.TERM_CERT_QTY,
                     FPTM1.PD_PREM_AMT,
                     FPTM1.DELQ_PREM_AMT,
                     FPTM1.COMPAS_INSD_PLN_ID,
                     FPTM1.ACTV_MO_ID,
                     FPTM1.XCLD_FROM_DFLT_FLG,
                     FPTM1.ETL_LST_BTCH_ID,
                     FPTM1.PRDCT_D_ACQN_CHNL_SK,
                     FPTM1.CERT_D_ACQN_CHNL_SK,
                     FPTM1.MBR_D_ACQN_CHNL_SK,
                     FPTM1.ACCT_NBR,
                     FPTM1.D_CERT_ACTV_SK,
                     FPTM1.D_UNDWR_TAG_SK,
                     FPTM1.PRDCT_EFF_MO_ID,
                     FPTM1.D_LGL_ENTY_SK,
                     FPTM1.MBR_PD_PREM_AMT,
                     FPTM1.MBR_DELQ_PREM_AMT,
                     FPTM1.EMP_PD_PREM_AMT,
                     FPTM1.EMP_DELQ_PREM_AMT,
                     FPTM1.AGT_WRT_D_AGT_SK,
                     FPTM1.AGT_SEL_ORIG_D_AGT_SK,
                     FPTM1.AGT_SEL_D_AGT_SK,
                     FPTM1.D_RET_TYP_SK,
                     FPTM1.D_EMP_SK,
                     FPTM1.AGT_DCM_WRT_D_AGT_SK
       FROM BDR_DM.F_PREM_TRANS_MO FPTM1, BDR_DM.F_PREM_TRANS_MO FPTM2
      WHERE     FPTM2.D_MBR_INFO_SK = FPTM1.D_MBR_INFO_SK
            AND FPTM2.D_PLN_BEN_MOD_SK = FPTM1.D_PLN_BEN_MOD_SK
            AND FPTM2.CERT_EFF_MO_ID = FPTM1.CERT_EFF_MO_ID
            AND FPTM2.COMPAS_INSD_PLN_ID = FPTM1.COMPAS_INSD_PLN_ID
            AND FPTM2.PREM_DUE_MO_ID = FPTM1.PREM_DUE_MO_ID
            AND FPTM2.ACTV_MO_ID = FPTM1.ACTV_MO_ID
            AND FPTM2.ETL_LST_BTCH_ID = FPTM1.ETL_LST_BTCH_ID
            AND FPTM2.D_CERT_ACTV_SK = FPTM1.D_CERT_ACTV_SK
            AND FPTM1.PREM_DUE_MO_ID = FPTM1.ACTV_MO_ID
            AND FPTM1.D_CERT_ACTV_SK = 50                       -- paid/delinq
            AND FPTM2.F_PREM_TRANS_MO_SK <> FPTM1.F_PREM_TRANS_MO_SK -- not the same row
            --/* Note: a PTM row which just flips between paid and delinq can have
                  --   negative and positive metrics on one row */
            AND (   (    (FPTM1.PD_CERT_QTY + FPTM1.DELQ_CERT_QTY + FPTM1.TERM_CERT_QTY) >
                             0
                     AND (  FPTM2.PD_CERT_QTY
                          + FPTM2.DELQ_CERT_QTY
                          + FPTM2.TERM_CERT_QTY) < 0)
                 OR (    (FPTM2.PD_CERT_QTY + FPTM2.DELQ_CERT_QTY + FPTM2.TERM_CERT_QTY) >
                             0
                     AND (  FPTM1.PD_CERT_QTY
                          + FPTM1.DELQ_CERT_QTY
                          + FPTM1.TERM_CERT_QTY) < 0));
create or replace view BDR_DM.V_HDG_GRC_PRD_SW COPY GRANTS (
	APPL_ID,
	D_MBR_INFO_SK,
	COMPAS_INSD_PLN_ID,
	D_PLN_BEN_MOD_SK,
	PLN_CD_BEN_MOD,
	D_CERT_ACTV_SK,
	CERT_ACTV_LVL_3_TXT,
	CERT_EFF_DT_ID,
	CERT_TRM_DT_ID,
	GRACE_PERIOD_SWITCH_IND,
	F_PREM_TRANS_DAY_SK,
	F_PREM_TRANS_MO_SK
) as
WITH
        PREM_TRANS_SK
        AS
            (SELECT /*+ PARALLEL */
                    F_PREM_TRANS_DAY_SK,
                    D_MBR_INFO_SK,
                    COMPAS_INSD_PLN_ID,
                    D_PLN_BEN_MOD_SK,
                    D_CERT_ACTV_SK,
                    CERT_EFF_DT_ID,
                    CERT_TRM_DT_ID,
                    F_APPL_TRANS_DAY_SK
               FROM (SELECT ROW_NUMBER ()
                                OVER (
                                    PARTITION BY D_MBR_INFO_SK,
                                                 COMPAS_INSD_PLN_ID,
                                                 D_CERT_ACTV_SK
                                    ORDER BY ACTV_DT_ID DESC,F_PREM_TRANS_DAY_SK DESC)    RN,
                            F_PREM_TRANS_DAY_SK,
                            D_MBR_INFO_SK,
                            COMPAS_INSD_PLN_ID,
                            D_PLN_BEN_MOD_SK,
                            D_CERT_ACTV_SK,
                            CERT_EFF_DT_ID,
                            CERT_TRM_DT_ID,
                            F_APPL_TRANS_DAY_SK
                       FROM BDR_DM.F_PREM_TRANS_DAY
                      WHERE     TERM_CERT_QTY <> '-1'
                            AND DELQ_CERT_QTY <> '-1'
                            AND PD_CERT_QTY <> '-1')
              WHERE RN = 1),
        PREM_TRANS_MO_SK
        AS
            (SELECT /*+ PARALLEL */
                    F_PREM_TRANS_MO_SK,
                    D_MBR_INFO_SK,
                    COMPAS_INSD_PLN_ID,
                    D_CERT_ACTV_SK
               FROM (SELECT ROW_NUMBER ()
                                OVER (
                                    PARTITION BY D_MBR_INFO_SK,
                                                 COMPAS_INSD_PLN_ID,
                                                 D_CERT_ACTV_SK
                                    ORDER BY ACTV_MO_ID DESC,F_PREM_TRANS_MO_SK DESC)    RN,
                            D_MBR_INFO_SK,
                            COMPAS_INSD_PLN_ID,
                            F_PREM_TRANS_MO_SK,
                            D_CERT_ACTV_SK
                       FROM BDR_DM.F_PREM_TRANS_MO
                      WHERE     TERM_CERT_QTY <> '-1'
                            AND DELQ_CERT_QTY <> '-1'
                            AND PD_CERT_QTY <> '-1')
              WHERE RN = 1)
    SELECT /*+ PARALLEL */
           FA.APPL_ID,
           FP.D_MBR_INFO_SK,
           FP.COMPAS_INSD_PLN_ID,
           FP.D_PLN_BEN_MOD_SK,
           PBM.PLN_CD_BEN_MOD,
           FP.D_CERT_ACTV_SK,
           CA.CERT_ACTV_LVL_3_TXT,
           FP.CERT_EFF_DT_ID,
           FP.CERT_TRM_DT_ID,
           CASE
               WHEN ENRL_PROCESSING_EVENT_MASK >= 512 THEN 'Y'
               WHEN ENRL_PROCESSING_EVENT_MASK < 512 THEN 'N'
               ELSE 'NA'
           END    AS GRACE_PERIOD_SWITCH_IND,
           FP.F_PREM_TRANS_DAY_SK,
           NVL(PTM.F_PREM_TRANS_MO_SK,-1) F_PREM_TRANS_MO_SK
      FROM PREM_TRANS_SK  FP
           INNER JOIN BDR_DM.F_APPL_TRANS_DAY FA
               ON FP.F_APPL_TRANS_DAY_SK = FA.F_APPL_TRANS_DAY_SK
           LEFT OUTER JOIN BDR_CONF.D_PLN_BEN_MOD PBM
               ON PBM.D_PLN_BEN_MOD_SK = FP.D_PLN_BEN_MOD_SK
           LEFT OUTER JOIN BDR_CONF.D_CERT_ACTV CA
               ON CA.D_CERT_ACTV_SK = FP.D_CERT_ACTV_SK
           LEFT OUTER JOIN SRC_COMPAS_D.APPLICATION A
               ON FA.APPL_ID = A.APPLICATION_ID
           LEFT OUTER JOIN PREM_TRANS_MO_SK PTM
               ON     PTM.D_MBR_INFO_SK = FP.D_MBR_INFO_SK
                  AND PTM.COMPAS_INSD_PLN_ID = FP.COMPAS_INSD_PLN_ID
                  AND PTM.D_CERT_ACTV_SK = FP.D_CERT_ACTV_SK
     WHERE FA.CURR_ROW_FLG = 'Y';
create or replace view V_LEGAL_ENTITY COPY GRANTS (
	MONTH,
	ST_CD,
	PLN_CD,
	LGL_ENTY_NM,
	SUM_OF_BEN_AMT
) as
SELECT
CD.D_CAL_MO_ID as MONTH,
CR.ST_CD as ST_CD,
PB.PLN_CD_BEN_MOD as PLN_CD,
L.LGL_ENTY_SHRT_DESC as LGL_ENTY_NM,
SUM(CBL.ADJ_BEN_AMT) as SUM_OF_BEN_AMT
FROM
BDR_DM.F_CLM_BIL_LN_HIST CBL
INNER JOIN BDR_CONF.D_CALC_RT CR ON CR.D_CALC_RT_SK = CBL.D_CALC_RT_SK
INNER JOIN BDR_CONF.D_PLN_BEN_MOD PB ON PB.D_PLN_BEN_MOD_SK = CBL.D_PLN_BEN_MOD_SK
INNER JOIN BDR_CONF.D_CAL_DT CD ON CD.D_CAL_DT_ID = CBL.CLM_PD_DT_ID
INNER JOIN BDR_CONF.D_LGL_ENTY L ON L.D_LGL_ENTY_SK = CBL.D_LGL_ENTY_SK
WHERE
TO_NUMBER(TO_CHAR(DATEADD('DD', -1, TRUNC(CURRENT_TIMESTAMP,'MM')),'YYYYMM')) = CD.D_CAL_MO_ID
GROUP BY
CD.D_CAL_MO_ID,
CR.ST_CD,
PB.PLN_CD_BEN_MOD,
L.LGL_ENTY_SHRT_DESC;
create or replace view V_PAID_INFO_MO COPY GRANTS (
	MONTH,
	SOURCE,
	PRDCT,
	BEN_ID_DESC,
	SUM_OF_BEN_AMT
) as
SELECT
CD.D_CAL_MO_ID as MONTH,
'CLM_BIL_LN' as SOURCE,
B.PRDCT as PRDCT,
B.BEN_ID_DESC as BEN_ID_DESC,
SUM(CBL.ADJ_BEN_AMT) as SUM_OF_BEN_AMT
FROM
BDR_DM.F_CLM_BIL_LN_HIST CBL
LEFT OUTER JOIN BDR_CONF.D_BEN B on B.D_BEN_SK = CBL.D_BEN_SK
INNER JOIN BDR_CONF.D_CAL_DT CD ON CD.D_CAL_DT_ID = CBL.CLM_PD_DT_ID
WHERE
CD.D_CAL_MO_ID = TO_NUMBER(TO_CHAR(add_months(TRUNC(CURRENT_TIMESTAMP,'MM'), -1),'YYYYMM'))
GROUP BY
CD.D_CAL_MO_ID,
B.PRDCT,
B.BEN_ID_DESC
UNION
SELECT
CD.D_CAL_MO_ID as MONTH,
'OCRS_BIL_LN' as SOURCE,
B.PRDCT as PRDCT,
B.BEN_ID_DESC as BEN_ID_DESC,
SUM(OBL.OCRS_BEN_AMT) as SUM_OF_BEN_AMT
FROM
BDR_DM.F_OCRS_BIL_LN_HIST OBL
LEFT OUTER JOIN BDR_CONF.D_BEN B on B.D_BEN_SK = OBL.D_BEN_SK
INNER JOIN BDR_CONF.D_CAL_DT CD ON CD.D_CAL_DT_ID = OBL.CLM_PD_DT_ID
WHERE
CD.D_CAL_MO_ID = TO_NUMBER(TO_CHAR(add_months(TRUNC(CURRENT_TIMESTAMP,'MM'), -1),'YYYYMM'))
GROUP BY
CD.D_CAL_MO_ID,
B.PRDCT,
B.BEN_ID_DESC;
create or replace view V_RPT_MED_SEL_SV COPY GRANTS (
	RPT_YR,
	RPT_MO,
	PAT_PARG_CD,
	ACCT_NBR,
	CLM_NBR,
	BIL_LN_NBR,
	PCT_PD,
	EC_BL_HOSP_DED_FLG,
	CLM_PD_DT_ID,
	CMPL_DT_ID,
	COMPAS_PLN_CD,
	TOS_CD,
	SRVC_FROM_DT_ID,
	SRVC_TO_DT_ID,
	D_CHRG_TYP_IND,
	D_HOSP_SNF_DAY_IND,
	TIN,
	RNDR_PROV_NM,
	SRVC_ACCUM_1_NBR,
	SRVC_ACCUM_2_NBR,
	BEN_PRD_NBR,
	BEN_PRD_DAY,
	BEN_AMT,
	CHRG_AMT,
	EC_BL_HOSP_DED_AMT,
	EC_BL_HOSP_COINS_AMT,
	PROJ_SV,
	EC_TOT_COINS_AMT,
	COV_EXPN_AMT,
	HOSP_DAY_BEN_AMT,
	ADJ_BEN_AMT,
	SBMT_CHRG_AMT,
	PROV_BUS_NM
) as
SELECT
        substr(a.clm_pd_dt_id, 1, 4)   AS rpt_yr,
        substr(a.clm_pd_dt_id, 5, 2)   AS rpt_mo,
        d.pat_parg_cd,
        a.acct_nbr,
        a.clm_nbr,
        a.bil_ln_nbr,
        a.pct_pd,
        epab.ec_bl_hosp_ded_flg,
        a.clm_pd_dt_id,
        a.cmpl_dt_id,
        b.compas_pln_cd,
        a.tos_cd,
        a.srvc_from_dt_id,
        a.srvc_to_dt_id,
        a.d_chrg_typ_ind,
        a.d_hosp_snf_day_ind,
        pr.tin,
        a.rndr_prov_nm,
        a.srvc_accum_1_nbr,
        a.srvc_accum_2_nbr,
        a.ben_prd_nbr,
        a.ben_prd_day,
        SUM(a.ben_amt)                 AS ben_amt,
        SUM(a.chrg_amt)                AS chrg_amt,
        SUM(epab.ec_bl_hosp_ded_amt)   AS ec_bl_hosp_ded_amt,
        SUM(epab.ec_bl_hosp_coins_amt) AS ec_bl_hosp_coins_amt,
        SUM(
            CASE
                WHEN coalesce(ec_bl_hosp_ded_amt, 0) > 0 THEN
                    ec_bl_hosp_ded_amt - ben_amt
                WHEN coalesce(ec_bl_hosp_ded_amt, 0) = 0
                     AND coalesce(ec_bl_hosp_coins_amt, 0) > 0 THEN
                    ec_bl_hosp_coins_amt - ben_amt
                WHEN coalesce(ec_bl_hosp_ded_amt, 0) = 0
                     AND coalesce(ec_bl_hosp_coins_amt, 0) = 0 THEN
                    a.chrg_amt - a.ben_amt
            END
        )                              AS proj_sv,
        SUM(epa.ec_tot_coins_amt)      AS ec_tot_coins_amt,
        SUM(a.cov_expn_amt)            AS cov_expn_amt,
        SUM(a.hosp_day_ben_amt)        AS hosp_day_ben_amt,
        SUM(a.adj_ben_amt)             AS adj_ben_amt,
        SUM(a.sbmt_chrg_amt)           AS sbmt_chrg_amt,
        MAX(pa.prov_bus_nm)            AS prov_bus_nm
    FROM
             bdr_dm.f_clm_bil_ln_hist a
        JOIN bdr_dm.f_clm_hist                   fch ON a.f_clm_hist_sk = fch.f_clm_hist_sk
        JOIN bdr_dm.d_ec_part_a                  epa ON fch.d_ec_part_a_sk = epa.d_ec_part_a_sk
        LEFT OUTER JOIN bdr_dm.d_ec_part_a_bl               epab ON epa.d_ec_part_a_sk = epab.d_ec_part_a_sk
        JOIN bdr_conf.d_pln_ben_mod              b ON a.d_pln_ben_mod_sk = b.d_pln_ben_mod_sk
        JOIN bdr_conf.d_prov                     pr ON fch.d_prov_sk = pr.d_prov_sk
        JOIN bdr_conf.d_prov_addr                pa ON pr.d_prov_sk = pa.d_prov_sk
        LEFT OUTER JOIN bdr_dm.brdg_f_clm_bl_hist_d_pat_parg c ON a.f_clm_bil_ln_hist_sk = c.f_clm_bil_ln_hist_sk
        LEFT OUTER JOIN bdr_dm.d_pat_parg                   d ON c.d_pat_parg_sk = d.d_pat_parg_sk
    WHERE
        a.clm_pd_dt_id BETWEEN TO_NUMBER(to_char(trunc(add_months(current_date, - 1),
                                                       'mm'),
                                                 'yyyymmdd')) AND TO_NUMBER(to_char(last_day(add_months(current_date, - 1)),
                                                                                    'yyyymmdd'))
        AND a.tos_cd LIKE 'H%'
        AND a.bl_no_pay_ind = '0'
        AND b.pln_lvl_desc LIKE '%Select%'
        AND d.pat_parg_cd IN ( '97200', '97209', '97400', '97409', '97600',
                               '97700', '97800', '97900' )
    GROUP BY
        substr(a.clm_pd_dt_id, 1, 4),
        substr(a.clm_pd_dt_id, 5, 2),
        d.pat_parg_cd,
        a.acct_nbr,
        a.clm_nbr,
        a.bil_ln_nbr,
        a.pct_pd,
        epab.ec_bl_hosp_ded_flg,
        a.clm_pd_dt_id,
        a.cmpl_dt_id,
        b.compas_pln_cd,
        a.tos_cd,
        a.srvc_from_dt_id,
        a.srvc_to_dt_id,
        a.d_chrg_typ_ind,
        a.d_hosp_snf_day_ind,
        pr.tin,
        a.rndr_prov_nm,
        a.srvc_accum_1_nbr,
        a.srvc_accum_2_nbr,
        a.ben_prd_nbr,
        a.ben_prd_day;
create or replace view V_RPT_MO_CLM_DOL_PLN_PAY COPY GRANTS (
	D_ST_CD,
	PRDCT_GRP,
	PLN_GRP,
	PLN_CD_BEN_MOD_DESC,
	CLM_PD_MO_ID,
	ADJ_BEN_AMT
) as
select
    b.d_st_cd,
    b.prdct_grp ,
    b.pln_grp ,
    b.PLN_CD_BEN_MOD_DESC,
    b.clm_pd_mo_id,
    coalesce(sum(b.adj_ben_amt),0) as adj_ben_amt
from
    (select
        a13.d_st_cd,
        a12.prdct_grp ,
        a12.pln_grp ,
        a12.PLN_CD_BEN_MOD_DESC,
        floor(a11.clm_pd_dt_id/100) as clm_pd_mo_id,
        sum(a11.adj_ben_amt) as adj_ben_amt
    from BDR_dm.f_clm_bil_ln_hist a11
        join BDR_CONF.D_PLN_BEN_MOD a12 on a11.d_pln_ben_mod_sk = a12.d_pln_ben_mod_sk
        join BDR_CONF.D_GEO_XREF a13 on a11.pln_iss_D_GEO_XREF_SK = a13.D_GEO_XREF_SK
    where
        a11.clm_pd_dt_id between to_number(to_char(trunc(add_months(current_date,-13),'MM'),'yyyymmdd')) and to_number(to_char(last_day(add_months(current_date,-1)),'yyyymmdd'))
    group by
        a13.d_st_cd,
        a12.prdct_grp ,
        a12.pln_grp ,
        a12.PLN_CD_BEN_MOD_DESC,
        floor(a11.clm_pd_dt_id/100)
    having
        sum(a11.adj_ben_amt)<>0
    UNION ALL
    select
        a13.d_st_cd,
        a12.prdct_grp ,
        a12.pln_grp ,
        a12.PLN_CD_BEN_MOD_DESC,
        floor(a11.clm_pd_dt_id/100) as clm_pd_mo_id,
        sum(a11.ocrs_ben_amt) as adj_ben_amt
    from BDR_dm.f_ocrs_bil_ln_hist a11
        join BDR_CONF.D_PLN_BEN_MOD a12 on a11.d_pln_ben_mod_sk = a12.d_pln_ben_mod_sk
        join BDR_CONF.D_GEO_XREF a13 on a11.pln_iss_D_GEO_XREF_SK = a13.D_GEO_XREF_SK
    where
        a11.clm_pd_dt_id between to_number(to_char(trunc(add_months(current_date,-13),'MM'),'yyyymmdd')) and to_number(to_char(last_day(add_months(current_date,-1)),'yyyymmdd'))
    group by
        a13.d_st_cd,
        a12.prdct_grp ,
        a12.pln_grp ,
        a12.PLN_CD_BEN_MOD_DESC,
        floor(a11.clm_pd_dt_id/100)
    having
        sum(a11.ocrs_ben_amt)<>0 )b
group by
    b.d_st_cd,
    b.prdct_grp ,
    b.pln_grp ,
    b.PLN_CD_BEN_MOD_DESC,
    b.clm_pd_mo_id
order by
    b.d_st_cd,
    b.prdct_grp ,
    b.pln_grp ,
    b.PLN_CD_BEN_MOD_DESC,
    b.clm_pd_mo_id;
create or replace view V_ACTV_CERTS_BY_ST COPY GRANTS (
	PRDCT_GRP,
	PLN_GRP,
	PLN_LVL_DESC,
	RES_ST_NM,
	ST_CD,
	D_LGL_ENTY_SK,
	PLN_CD_BEN_MOD,
	ACTV_CERTS
) as
SELECT
        a12.prdct_grp,
        a12.pln_grp,
        a12.pln_lvl_desc,
        a15.st_nm                                AS res_st_nm,
        a13.d_st_cd                              AS st_cd,
        a11.d_lgl_enty_sk,
        a12.pln_cd_ben_mod,
        SUM(a11.pd_cert_qty + a11.delq_cert_qty) AS actv_certs
    FROM
        bdr_dm.f_prem_trans_mo a11
        LEFT JOIN  bdr_conf.d_pln_ben_mod a12 ON a11.d_pln_ben_mod_sk = a12.d_pln_ben_mod_sk
        LEFT JOIN  bdr_conf.d_geo_xref    a13 ON a11.res_d_geo_xref_sk = a13.d_geo_xref_sk
        LEFT JOIN  bdr_conf.d_st          a15 ON a13.d_st_cd = a15.d_st_cd
    WHERE
            a11.prem_due_mo_id = to_char(add_months(CURRENT_TIMESTAMP, - 1),
                                         'YYYYMM')
        AND a11.actv_mo_id <= to_char(add_months(CURRENT_TIMESTAMP, - 1),
                                      'YYYYMM')
    GROUP BY
        a12.prdct_grp,
        a12.pln_grp,
        a12.pln_lvl_desc,
        a15.st_nm,
        a13.d_st_cd,
        a11.d_lgl_enty_sk,
        a12.pln_cd_ben_mod
    ORDER BY
        a15.st_nm;
create or replace view V_PAID_PREM_MO COPY GRANTS (
	ST_CD,
	LGL_ENTY_NM,
	PROD_INFO,
	SUM_OF_PD_PREM_AMT
) as
SELECT
geo.D_ST_CD as ST_CD,
case when lgl.LGL_ENTY_NM='UHC NY' then 'NY'
when lgl.LGL_ENTY_NM='UHCA' then 'NLE'
else 'ALL OTHER' end as LGL_ENTY_NM,
lkp.PRDCT_INFO as PROD_INFO,
sum(PD_PREM_AMT) as SUM_OF_PD_PREM_AMT
FROM BDR_DM.F_PREM_TRANS_MO prem
INNER JOIN BDR_CONF.D_GEO_XREF geo
ON prem.RES_D_GEO_XREF_SK = geo.D_GEO_XREF_SK
INNER JOIN BDR_CONF.D_LGL_ENTY lgl
ON prem.D_LGL_ENTY_SK = lgl.D_LGL_ENTY_SK
INNER JOIN BDR_CONF.D_PLN_BEN_MOD ben
ON prem.D_PLN_BEN_MOD_SK = ben.D_PLN_BEN_MOD_SK
INNER JOIN BDR_CONF.PRDCT_GRP_INFO lkp
ON ben.PLN_TYP = lkp.PLN_TYP
AND ben.PLN_GRP = lkp.PLN_GRP
WHERE (prem.Prem_due_mo_id = TO_NUMBER(TO_CHAR(add_months(TRUNC(CURRENT_TIMESTAMP,'MM'), -1),'YYYYMM'))
OR (prem.Actv_mo_id = TO_NUMBER(TO_CHAR(add_months(TRUNC(CURRENT_TIMESTAMP,'MM'), -1),'YYYYMM'))
AND prem.prem_due_mo_id < TO_NUMBER(TO_CHAR(add_months(TRUNC(CURRENT_TIMESTAMP,'MM'), -1),'YYYYMM'))))
GROUP BY geo.D_ST_CD,
case when lgl.LGL_ENTY_NM='UHC NY' then 'NY'
when lgl.LGL_ENTY_NM='UHCA' then 'NLE'
else 'ALL OTHER' end,
lkp.PRDCT_INFO;