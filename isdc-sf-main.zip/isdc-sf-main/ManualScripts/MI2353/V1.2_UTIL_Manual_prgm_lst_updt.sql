
-- Dups claim2 adding current date parameter
UPDATE UTIL.PROGRAM_LIST 
SET OBJECT_SIGNATURE = '($PIPELINE_ID, $PIPELINE_NAME, ''UBLIA_PRD_ISDC_PRD_DB'', ''UTIL'' , ''LZ_FOX'', ''LZ_ISDW'', ''SRC_EDI_837'',  ''@UTIL.STAGE_AZURE_ISDC'',  ''UBLIA_PRD_ETL_XS_WH'', null)'  
where OBJECT_NAME = 'SP_DUPLICATE_CLAIMS_2_FINAL_REPORT_GEN' ; 

--MBI
-- updating the file format and current date parameter
update util.program_list set object_signature='($PIPELINE_ID, $PIPELINE_NAME, ''UBLIA_PRD_ISDC_PRD_DB'', ''UTIL'', ''LZ_EDI_837'' ,''MEMBER_STG'', ''mbi'', ''cmsrespons'', ''@UTIL.STAGE_AZURE_ISDC'', ''UTIL.FF_FIX_WIDTH_BILLING_NO_HEADER'')' where sub_process_name='MEMBER_STG' ; 

update util.program_list set object_signature='($PIPELINE_ID, $PIPELINE_NAME, ''UBLIA_PRD_ISDC_PRD_DB'', ''UTIL'', ''SRC_EDI_837'' , ''SRC_EDI_837'', ''LZ_EDI_837'', ''UBLIA_PRD_ETL_XS_WH'', ''@UTIL.STAGE_AZURE_ISDC'',null )' where sub_process_name='MBI_EXTRACT' ; 
