USE SCHEMA UTIL;

ALTER SESSION SET TIMEZONE = 'America/Chicago';

-- Insert into PROCESS_RUN_LOGS table 
INSERT INTO  util.PROCESS_RUN_LOGS (PIPELINE_ID, PIPELINE_NAME,APP_NAME,PROCESS_NAME,SUB_PROCESS_NAME,START_DATETIME)
VALUES ( 'f2d1a2fa-93de-4f5b-66ba-9fcc3c84c97a', 'Remove_Dup_837_raw_files','PRE_CLM',  'Remove dup 837 files', 'Remove dup 837 files',current_timestamp());

-- Get files from bdpaas archive folder
list @UTIL.STAGE_AZURE_ISDC/bdpaas_archive/raw_claim/ pattern = '.*.txt';
   CREATE OR REPLACE TEMPORARY TABLE tmp_archivefie
   AS 
   SELECT * FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));

-- Get files from edi landing folder
list @UTIL.STAGE_AZURE_ISDC/landing/edi/raw/ pattern = '.*.txt';
   CREATE OR REPLACE TEMPORARY TABLE tmp_archivefie_ln
   AS 
   SELECT * FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));

-- Get duplicate files from bdpass archive and edi landing folders
CREATE OR REPLACE TEMPORARY TABLE tmp_rm_fl 
AS   
   select name from (
   select split("name",'/')[10]::STRING as name from tmp_archivefie
  intersect
   select split("name",'/')[8]::STRING from tmp_archivefie_ln)
   ;
   
-- Anonymous block to Remove duplicate files
DECLARE
    lv_start_tm timestamp;
    lv_fl_nm VARCHAR(100);
    lv_query_id VARCHAR2(100);
BEGIN
  LET res RESULTSET := (SELECT * from tmp_rm_fl);
  FOR flNm IN res DO
    lv_start_tm := current_timestamp();
    lv_fl_nm := flNm.name;
    EXECUTE IMMEDIATE 'remove  @UTIL.STAGE_AZURE_ISDC/landing/edi/raw/'||flNm.name||'.BDPAAS.ctl';
    EXECUTE IMMEDIATE 'remove  @UTIL.STAGE_AZURE_ISDC/landing/edi/raw/'||flNm.name;
    lv_query_id := LAST_QUERY_ID();
    CALL UTIL.SP_PROCESS_RUN_LOGS_DTL (current_database(), 'UTIL', 'PRE_CLM',  'f2d1a2fa-93de-4f5b-66ba-9fcc3c84c97a', 'Remove_Dup_837_raw_files', 
                                       'Remove dup 837 files', 'Remove dup 837 files', 'Step 1', ' Removed @UTIL.STAGE_AZURE_ISDC/landing/edi/raw/'||:lv_fl_nm,
                                       :lv_start_tm, CURRENT_TIMESTAMP(), 'SUCCESS', :lv_query_id, Null, Null, NULL, NULL, NULL);
  END FOR;

  EXCEPTION WHEN OTHER THEN
         CALL UTIL.SP_PROCESS_RUN_LOGS_DTL (current_database(), 'UTIL', 'PRE_CLM',  'f2d1a2fa-93de-4f5b-66ba-9fcc3c84c97a', 'Remove_Dup_837_raw_files', 
                                            'Remove dup 837 files', 'Remove dup 837 files', 'Step 1', '@UTIL.STAGE_AZURE_ISDC/landing/edi/raw/'||:lv_fl_nm, 
                                            :lv_start_tm, CURRENT_TIMESTAMP(), 'FAILED', :lv_query_id, Null, Null, :SQLERRM, :SQLCODE, :SQLSTATE);
  RAISE;
END;

-- Update PROCESS_RUN_LOGS table
UPDATE util.PROCESS_RUN_LOGS
set END_DATETIME= CURRENT_TIMESTAMP(),
status='SUCCESS'
where PIPELINE_ID='f2d1a2fa-93de-4f5b-66ba-9fcc3c84c97a';
