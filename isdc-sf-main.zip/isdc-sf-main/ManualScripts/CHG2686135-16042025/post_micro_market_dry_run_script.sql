USE SCHEMA UTIL;

ALTER SESSION SET TIMEZONE = 'America/Chicago';

set adfenv = CASE current_database() 
                  WHEN 'UBLIA_TST_ISDC_DEV_DB'      THEN 'adf-isdc-analytics-nonprod-dev'
                  WHEN 'UBLIA_TST_ISDC_TST_DB'      THEN 'adf-isdc-analytics-nonprod-tst'
                  WHEN 'UBLIA_PRD_ISDC_PRD_DB'      THEN 'adf-isdc-analytics-prod-prd'
             END;
set db     = current_database();
set wh     = CASE current_database() 
                  WHEN 'UBLIA_TST_ISDC_DEV_DB'      THEN 'UBLIA_TST_ETL_XS_WH'
                  WHEN 'UBLIA_TST_ISDC_TST_DB'      THEN 'UBLIA_TST_ETL_XS_WH'
                  WHEN 'UBLIA_PRD_ISDC_PRD_DB'      THEN 'UBLIA_PRD_ETL_XS_WH'
             END;
set rg     = CASE current_database() 
                  WHEN 'UBLIA_TST_ISDC_DEV_DB'      THEN 'rg-isdc-nonprod'
                  WHEN 'UBLIA_TST_ISDC_TST_DB'      THEN 'rg-isdc-nonprod'
                  WHEN 'UBLIA_PRD_ISDC_PRD_DB'      THEN 'rg-isdc-prod'
             END;  
set sub_id     = CASE current_database() 
                  WHEN 'UBLIA_TST_ISDC_DEV_DB'      THEN 'df55fbe1-ac66-4549-a170-1a3bbb27a6bf'
                  WHEN 'UBLIA_TST_ISDC_TST_DB'      THEN 'df55fbe1-ac66-4549-a170-1a3bbb27a6bf'
                  WHEN 'UBLIA_PRD_ISDC_PRD_DB'      THEN '3d58a242-5793-4087-947a-0ca97fbe8fb6'
             END;  

UPDATE UBLIA_PRD_ISDC_PRD_DB.UTIL.PROGRAM_LIST_ANALYTICS 
SET OBJECT_SIGNATURE = ' ''' || $db || ''', ''UTIL'', ''BDR_FFP_DA'', ''BDR_FFP_DA_WRK'', ''BDR_SMART'', ''SRC_UCEE'', ''BDR_CONF'', ''' || $wh || ''', null ' 
WHERE SUB_PROCESS_NAME = 'MICRO_MARKET_PROCESS' ;
