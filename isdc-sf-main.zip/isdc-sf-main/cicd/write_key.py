#!python
from os import environ

raw_key = environ.get("SNOWFLAKE_PRIVATE_KEY")
key_path = environ.get("SNOWFLAKE_PRIVATE_KEY_PATH")

print("Writing key file for schemachange.")
with open(key_path, 'w') as f:
    f.write(raw_key)
